<?php
$srv="/usr/local/bin/".(basename($_SERVER['PHP_SELF'],'.php'))." ";

// AJAX call back server side
if (($cmd = (isset($_POST['cmd']) ? $_POST['cmd'] : null)) != null) {
	if ($cmd == "lp") $cmd .= ",".$_SERVER['REMOTE_ADDR'].":".$_SERVER['REMOTE_PORT'];
	passthru($srv.$cmd);
	return;
}

function dhdr()
{
	global	$srv;
	echo '<meta name=viewport content="width=device-width, initial-scale=1.0" />';
	echo '<title>'.(basename($srv)).'</title>';
}

/*
 * Java Script
 */
function djsc()
{
	echo "<script language=javascript type=text/javascript>";

	echo <<<EOSCRIPT
function srvpost(cmd,ans) {
	var r;
	try { r = new XMLHttpRequest(); }
	catch (e) { try { r = new ActiveXObject("MSXML2.XMLHTTP"); }
	catch (e) { try { r = new ActiveXObject("Microsoft.XMLHTTP"); }
	catch (e) { alert("Browser broken or ancient!"); return null; }
	}}
	r.onreadystatechange = function() { if (r.readyState == 4) ans(r.responseText.trim(),r.status); }
	// IE caches GET requests but not POST requests...
	r.open("POST",location.href.split("/").slice(-1),true);
	r.setRequestHeader("Content-type","application/x-www-form-urlencoded");
	r.timeout = 60000;
	r.send('cmd='+cmd);
}
var cph = 0;
if (document.addEventListener)
	document.addEventListener("click",clickevent,true);
else	document.attachEvent("onclick",clickevent);	// IE8
function clickevent(e) { cph = e.clientX; }
function settext(nm,txt) { var el = document.getElementById(nm); if (el != null) el.innerHTML = txt; }
function gettext(nm)     { var el = document.getElementById(nm); return el != null ? el.innerHTML : null; }
function setclas(nm,cls) { var el = document.getElementById(nm); if (el != null) el.className = cls; return el; }
function setrclass(nm,val) {
	switch (val) {
	case "0": return setclas(nm,"btn"); break;
	case "1": return setclas(nm,"btg"); break;
	default:  return setclas(nm,"btr"); break;
	}
	return null;
}
function clk2str(sec) {
	var t, h, m, s;
	t = "";
	if (sec == "" || sec <= 0) return t;
	h = parseInt(sec/3600);
	s = parseInt(sec%3600);
	m = parseInt(s/60);
	s %= 60;
	if (h < 10) t += "&nbsp"; t += h + ":";
	if (m < 10) t += 0; t += m + ":";
	if (s < 10) t += 0; t += s;
	return t;
}
var wclk = 0;
var t_wclk = 0; function upd_wclk(val,inc) {
	if (inc) wclk++;
	t_wclk = val;
	settext('stat',clk2str(wclk));
}
var t_udot = 0; function upd_udot(val) {
	t_udot = val;
	if (t_udot <= 0)
		settext('gst.a','');
	else	settext('gst.a','&#x25cf');
}
var vlmc = 0;
function rupd(vrb,vec,tbl) {
	var i, c, r;
	if (tbl != null)
		switch (vrb) {
		case "v,": tbl[ 8].cells[1].innerHTML = vec; break;
		case "r,": tbl[ 9].cells[1].innerHTML = vec; break;
		case "b,": tbl[10].cells[1].innerHTML = vec; break;
		}
	for (r = 0, i = vec.length; --i >= 0; ) 
		if ((c = vec.substr(i,1)) == ".") continue;
		else if (setrclass(vrb+i,c) == null) r++;
	if (r != 0 && (vrb == "v," || vrb == "r,")) vlmc++;
}
var rtscn = 0;
function tscn(vec) {
	var el, v, i, n, a;
	rtscn = 0;
	v = vec.split(",");
	if (v.length < 3 || v[0] != "T") return;
	for (n = 0, i = 1; i < v.length; i++) {
		a = v[i++];
		if (a.substr(0,2) == "TS") {
			i++; /* skip data readout of new sensor */
			if ((el = document.getElementById("tsu"+n)) == null) break;
			el.innerHTML = a.substring(2)+" "+v[i];
			n++;
		}
	}
	while (n < 5 && (el = document.getElementById("tsu"+n)) != null) el.innerHTML = "", n++;
}
function rsho(ans) {
	var s, a, tbl, i, pn, pv;
	a = ans.split(",");
	if (a.length == 24 && a[0] === "S") {
		upd_udot(2);
		s = a[4].split(":");
		if (s.length >= 3) {
			wclk = parseInt(s[0])*3600+parseInt(s[1])*60+parseInt(s[2]);
			upd_wclk(60,0);
		}
		else settext('stat',"");
		rupd("v,",a[7],null);
		rupd("r,",a[8],null);
		rupd("b,",a[9],null);
		for (i = a[22].length; --i >= 0; ) setrclass('ip'+i,a[22].substr(i,1));
		switch (a[3]) {
		case '1': a[3] = "1 Sunday"; break;
		case '2': a[3] = "2 Monday"; break;
		case '3': a[3] = "3 Tuesday"; break;
		case '4': a[3] = "4 Wednesday"; break;
		case '5': a[3] = "5 Thursday"; break;
		case '6': a[3] = "6 Friday"; break;
		case '7': a[3] = "7 Saturday"; break;
		}
		if ((tbl = document.getElementById('stb').rows) != null)
			for (i = 0; i < 24; i++) tbl[i+1].cells[1].innerHTML = a[i];
		return;
	}
	if (a.length == 2) {
		if (a[0] === "L") { 
			setrclass('l,7',a[1]);
			setrclass('l,15',a[1]);
			return;
		}
		tbl = document.getElementById('stb').rows;
		if (a[0] === "V") { rupd("v,",a[1],tbl); return; }
		if (a[0] === "R") { rupd("r,",a[1],tbl); return; }
		if (a[0] === "B") { rupd("b,",a[1],tbl); return; }
	}
	if (a.length >= 3 && a[0] === "P") {
		for (i = 1; i < a.length; ) {
			pn = a[i++];
			pv = a[i++];
			if (pn.substring(0,2) == "ap") pv = pv+","+a[i++];
			else if (pn == "tsu") pv = pv == "C" ? "Celsius":"Farenheit";
			if ((el = document.getElementById(pn)) != null) el.innerHTML = pv;
		}
		if (rtscn != 0) rtscn = 0, srvpost('t',tscn);
		return;
	}
}
function pchg(el) {
	var v, dsc;
	if ((dsc = gettext(el.id+'.d')) == 0) dsc = el.id;
	if ((v = prompt(dsc,el.innerHTML)) == null) return;
	if (el.innerHTML != v) el.innerHTML = "wait...", srvpost("p,"+el.id+","+v,rsho);
	if (el.id.substring(0,2) == "ts") rtscn = 1;
}
function rchg(el) {
	var r, n, k;
	k = ((cph - el.offsetLeft) < (el.offsetWidth/4)) ? true : false;
	if (el.id.substr(0,1) == 'v' && el.className != "btn" && k == true) n = 0;
	else switch (el.className) {
	default:    n = 0; break;
	case "btn": n = 1; break;
	case "btg": n = el.id.substr(0,1) == 'v' ? 2 : 0; break;
	case "btr": n = 1; break;
	}
	el.className = "btw";
	srvpost(el.id+","+n,rsho);
}
function lchg(el) {
	var n;
	switch (el.className) {
	default:    n = 0; break;
	case "btn": n = 1; break;
	case "btg": n = 2; break;
	case "btr": n = 0; break;
	}
	el.className = "btw";
	srvpost("l,"+n,rsho);
}
function pclick(nm) {
	var h;
	if ((h = document.getElementById(nm)) == null) return;
	h.className = h.className == 'hide' ? 'show' : 'hide';
}
function cdown() {
	setTimeout(cdown,1000);
	if (t_wclk > 0) upd_wclk(t_wclk-1,1);
	if (t_udot > 0) upd_udot(t_udot-1);
	if (vlmc != 0) vlmc = 0, window.location.reload(true);
}
function proc_lp(ans,status) {
	if (status == 200 && ans.length >= 2) rsho(ans);
	srvpost("lp",proc_lp);
}
EOSCRIPT;

	echo "</script>";
}

function rlbi2d($idx)
{
	$d = "";
	switch ($idx) {
	case  0: $d .= "Record ID"; break;
	case  1: $d .= "Sequence #"; break;
	case  2: $d .= "Application mode"; break;
	case  3: $d .= "Day of week"; break;
	case  4: $d .= "Wall clock"; break;
	case  5: $d .= "RTC status"; break;
	case  6: $d .= "Error status";
		 $d .= "<br>bit 0 w1bus";
		 $d .= "<br>bit 1 clock";
		 $d .= "<br>bit 2 level";
		 $d .= "<br>bit 3 i2cbus";
		 $d .= "<br>bit 4 24VAC";
		 break;
	case  7: $d .= "Valve status"; break;
	case  8: $d .= "Relay status"; break;
	case  9: $d .= "Powercenter status"; break;
	case 10: $d .= "Analog input 0"; break;
	case 11: $d .= "Analog input 1"; break;
	case 12: $d .= "Analog input 2"; break;
	case 13: $d .= "Analog input 3"; break;
	case 14: $d .= "12VDC supply"; break;
	case 15: $d .= "Controller temperature"; break;
	case 16: $d .= "Temperature sensor 1"; break;
	case 17: $d .= "Temperature sensor 2"; break;
	case 18: $d .= "Temperature sensor 3"; break;
	case 19: $d .= "Temperature sensor 4"; break;
	case 20: $d .= "Temperature sensor 5"; break;
	case 21: $d .= "Level, average"; break;
	case 22: $d .= "Digital input status"; break;
	case 23: $d .= "Level, filtered"; break;
	}
	return $d;
}

function pnm2ds($pnm)
{
	switch ($pnm) {
	case "adj": $ds="Clock adjustment, positive values slow it down, negative values speed it up"; break;
	case "vlm": $ds="Valve mask (hex)"; break;
	case "vcf": $ds="Valve mask (bin)"; break;
	case "ctl": $ds="Pentair bus: address of this controller (hex)"; break;
	case "srv": $ds="Pentair bus: time server address (hex)"; break;
	case "ap0": $ds="Analog input 0 offset,scale"; break;
	case "ap1": $ds="Analog input 1 offset,scale"; break;
	case "ap2": $ds="Analog input 2 offset,scale"; break;
	case "ap3": $ds="Analog input 3 offset,scale"; break;
	case "ap4": $ds="Analog input 4 offset,scale"; break;
	case "aps": $ds="12V DC power feed offset,scale"; break;
	case "son": $ds="Sonar reference level in [inch]"; break;
	case "tsu": $ds="Temp. units"; break;
	case "ts0": $ds="Temp. sensor 0"; break;
	case "ts1": $ds="Temp. sensor 1"; break;
	case "ts2": $ds="Temp. sensor 2"; break;
	case "ts3": $ds="Temp. sensor 3"; break;
	case "ts4": $ds="Temp. sensor 4"; break;
	case "ts5": $ds="Temp. sensor 5"; break;
	default:    $ds="unknown"; break;
	}
	return $ds;
}

function dhtm()
{
	global $srv;

	$si = explode(" ",exec($srv."Y"));	// rlb server revision
	if (count($si) == 2) $cpr = "&#169RusseWorks ".$si[0]." ".$si[1]; else return;
	$fw = exec($srv."y");			// relay board firmware revision
	$si = explode(",",$sv=exec($srv."s"));	// status vector split into fields
	$ci = explode(",",$pv=exec($srv."p"));	// config vector split into fields

	echo "<div id=main>";

		echo "<p style='text-align:center; font-size:12pt;'>$fw</p>";

		echo "<div class=bts id=gst onclick=pclick('hgst')>";
			echo "<div class=ibl>Status</div>";
			echo "<div class=ibt id=stat>status</div>";
			echo "<div class=ibd id=gst.a></div>";
		echo "</div>";
		echo "<div class=hide id=hgst onclick=srvpost('s',rsho)>";
			echo "<table id=stb><tr><th>[]</th><th>Value</th><th>Description</th></tr>";
			for ($i=0; $i < count($si); $i++) {
				$dsc = rlbi2d($i);
				echo "<tr><td class=tci>$i</td><td class=tcv></td><td class=tcd>$dsc</td></tr>";
			}
			echo "</table>";
		echo "</div>";

		echo "<div class=bts id=cfg onclick=pclick('hcfg')>";
			echo "<div class=ibl>Configuration</div>";
		echo "</div>";
		echo "<div class=hide id=hcfg>";
			echo "<table id=ctb><tr><th>Name</th><th>Value</th><th>Description</th></tr>";
			for ($i=1; $i < count($ci); ) {
				$pnm = $ci[$i++]; $i++;
				if (strncmp("ap",$pnm,2) == 0) $i++;
				$dsc = pnm2ds($pnm);
				$dlb = $pnm.".d";
				echo "<tr>";
				echo "<td class=tci>$pnm</td>";
				echo "<td class=tcv id=$pnm onclick=pchg(this)></td>";
				echo "<td class=tcd id=$dlb>$dsc</td>";
				echo "</tr>";
			}
			echo "</table>";
			for ($i=0; $i<5; $i++) echo "<div id=tsu$i></div>";
		echo "</div>";

		echo "<div class=bts onclick=location.href=('hrlb.php')>";
			echo "<div class=ibl>History</div>";
		echo "</div>";

		$ip = $si[22];
		$n = strlen($ip);
		echo "<div style='margin:0; padding-left:10px;'>";
		for ($i = 0; $i < $n; $i++) {
			echo "<div id=ip$i class=btn style='margin:0 5px; float:left; width:30px; height:0;' >";
				echo "<div class=ibc style='padding-left:0; padding-right:0;'>$i</div>";
			echo "</div>";
		}
		echo "<div class=ibb></div>";
		echo "</div>";

		$vr = $si[7];
		$n = strlen($vr);
		for ($i = 0; $i < $n; $i++)
			if ($vr[$i] == ".") {
				$r = $i * 2;
				echo "<div id=r,$r class=btn onclick=rchg(this)><div class=ibc>Relay $r</div></div>"; $r++;
				echo "<div id=r,$r class=btn onclick=rchg(this)><div class=ibc>Relay $r</div></div>";
			}
			else	echo "<div id=v,$i class=btn onclick=rchg(this)><div class=ibc>Valve $i</div></div>";

		$n = strlen($si[9]);
		for ($i=0; $i < $n; $i++)
			if (($i%8) != 7)
				echo "<div id=b,$i class=btn onclick=rchg(this)><div class=ibc>Power $i</div></div>";
			else	echo "<div id=l,$i class=btn onclick=lchg(this)><div class=ibc>Remote LED</div></div>";

		echo "<div style='margin: 0.5em auto; font-size: 8pt;'>$cpr</div>";

	echo "</div>";

	echo "<script>cdown()</script>";
	echo "<script>rsho('$pv');</script>";
	echo "<script>proc_lp('$sv',200);</script>";
	echo "<script>srvpost('t',tscn);</script>";
}

/*
 * CSS
 */
function dcss()
{
	echo "<style>";

// Note: outside in order: margin->border->padding->element
// Note: margin/padding args: <t> <r> <b> <l> | <t> <r> <b> | <t,b> <r,l> | <t,b,r,l>
	echo <<<EOSTYLE
body { background-color: #000; color: white; }
#main {
	max-width: 310px;
	margin: 0 auto;
	font-family: arial;
	text-decoration: none;
	text-align: center;
}
.btr, .btg, .btw, .bti, .bts,
.btn {
	width: 95%;
	border-radius: 10px;
	border: 4px solid #4e6096;
	box-shadow: 0px 0px 0px 2px #9fb4f2;
	font-size: 16pt;
	text-shadow: 2px 2px 0px #283966;
	cursor: pointer;
	background: #7892c2;
	margin: 0.5em auto;
	padding: 1.00em 0;
}
.btr { background: #c00000; }
.btg { background: #00c000; }
.btw { background: #808080; }
.bts { background: #476e9e; }
.bts { border: 4px solid #3e5086; }
.bti { background: #000000; text-shadow: none; }
.bti { font-size: 14pt; font-weight: bold; }
.bti { font-family: "Courier new"; }
.ibl, .ibt, .ibs { float: left; text-align: left; padding-left: 6pt; }
.iba { float: right; text-align: right; padding-right: 6pt; }
.ibi { float: left; width: 15%; }
.ibc { float: left; text-align: center; width: 96%; }
.ibd { float: right; text-align: right; padding-right: 0pt; color:#fff; }
.ibr { float: right; text-align: right; }
.ibb { clear: both; height: 0.25em; }
.ibt, .ibs, .iba { text-shadow: none; color: #000; }
.ibt { font-size: 12pt; font-weight: bold; margin: -0.45em auto 0.5em auto; }
.ibs, .iba { font-size:  8pt; font-weight: bold; margin: -1.80em auto 0 auto; padding-top: 2pt; }
.ibs, .iba { color: #ddd; }
.ibl, .ibc, .ibr { padding: 0.15em 0.30em; margin: -0.75em auto 0.5em auto; }
.ibi { padding: 0 0; margin: -0.80em auto 0.5em auto; }
.hide { display: none; }
.show { display: block; width: 98%; margin: 0 auto 0 auto; }
table { width: 98%; margin: 0.5em auto; }
table, th, td { font-size: 10pt; color: #000; background-color: lightblue; border: 1px solid blue; }
td { padding:0.25em 0.5em; }
.tci { text-align: center; }
.tcv { text-align: left; }
.tcd { text-align: left; }
EOSTYLE;
//	echo ".ibl, .ibc, .ibr, .ibi, .ibt, .ibb, .ibs, .iba, .ibd { border: 1px solid white; }";
//	echo "img { border: 1px solid red; }";
//	echo "#main { background: red; }";
	echo "</style>";
}

?>
<!DOCTYPE html>
<html>
<head>
<?php dhdr(); ?>
<?php dcss(); ?>
</head>
<body>
<?php djsc(); ?>
<?php dhtm(); ?>
</body>
</html>

