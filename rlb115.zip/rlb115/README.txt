
20161109

All necessary files come in a zip archive. At the point of this writing the
revision of the software is 115, the corresponding archive is rlb115.zip.

sh> unzip rlb115.zip

What's in the archive?
README.txt		        this file
INSTALL.INC, install.rlb        installation scripts
# binaries for ARM processors
rlb.arm				rlb server binary, compiled for an ARM proc
idsrlb.arm                      rlb board identification without server
l2grlb.arm			log processor, a parser for server log files
# binaries for i686 processors
rlb.i686			rlb server binary, compiled for an i686 proc
idsrlb.i686                     rlb board identification without server
l2grlb.i686			log processor, a parser for server log files
# bash scripts
rlbplg                          script executed on USB insertion of rlb board
rlbmap                          script for multiple board map
# system files
8192cu.conf			configuration file for Edimax WiFi dongle
51-rlb.rules			udev rules file to create relay board device
# systemd support files
51-rlb.sd.rules			udev rules file to create relay board device with systemd
rlb@.service			systemd unit file
# firmware
fmwrlbX.hex			firmware for relay board revision X
# local website
www/index.html			pointer to web page
www/rlb.php			web page to access relay board with browser
www/hrlb.php			web page to access history


Fresh Raspberry Pi SD
=====================

Unzip the archive downloaded
Here is how to copy the Raspbian image to a Micro SD on a Linux box:
	sh> sudo dd if=2016-11-25-raspbian-jessie-lite.img of=/dev/sdX bs=4M
On a Windows system one can copy it with Win32DiskImager

Then stick the Micro SD into the RaspberryPi and power it up WITHOUT anything
connected (NO network, NO relayboard, just keyboard and monitor).
It boots into console mode (FAT16 in partition 1) and will 'auto resize' the
file system.
To get the basics right use raspi-config...
sh> sudo raspi-config
  - set timezone
  - change hostname to <YOUR HOSTNAME>
  - reboot
then plug in the network cable

On a new system you need to install 'apache2', 'php5' and 'avrdude packages:

sh> sudo apt-get update
sh> sudo apt-get install apache2 -y
sh> sudo apt-get install php5 -y

At this point you might want to install the MYSQL as well...

then finish up with:
sh> sudo apt-get install avrdude -y
sh> sync
sh> sudo reboot


rlb, installation on a Linux based system
=========================================

sh> cd rlb115
sh> sudo ./install.rlb

The installation script checks if 'avrdude' is installed on your system,
if so, it will verify the revision of the firmware of attached relay boards and
update any that is out of date.

The website to access the relay board from a browser is programmed in PHP and
uses Java Script. Of course you need to run apache properly configured to use
it. The installation script will put a symbolic link to the www directory of
the extracted archive into the default web directory of your system. This way
you can reach it with a browser by referencing http://<yourmachine>/rlb
The web page is nothing special, it is supposed to give you some ideas what
one can do with very little resources and also to answer some of the questions
on how the rlb server is accessed from a web page.

Since this revision you can connect multiple relayboards. The software uses
the script 'rlbplg' to generate names and unique ports for the server
instances. The script 'rlbmap' manages a serial to server index map used
by 'rlbplg'.


rlb, relay board server/client examples
=======================================

rlb is a server/client program for the MiruRLB relay board. Here is a basic
'howto' to make use of the relay board functions on a Linux system.

rlb is started as a server by the udev subsystem

As a client, rlb acts through the server as an agent between a socket and the
hardware. The server command socket has a default port number 13330. The client
has an optional first argument which is used to contact a remote rlb server.
For example 'rlb -h raspberrypi2 s' would contact a rlb server on raspberrypi2
to execute the command 's'.

The rlb server answers to some commands directly, otheres are passed to the
firmware of the locally attached hardware, in which case the firmware will
answer the command through the server.


client examples:
================

Valves and relays
-----------------
The board the example responses were taken from is configured to have
2 valves and 12 relays. The relay board can be configured with 0..8 valves,
the remaining outputs are relays by default.
Valves are numbered 0...7, relays are numbered 0...15 and power center bits are
numbered 0...7.

get general status
> rlb s
 S,215,0,2,00:00:00,5,10,00......,....000000000000,00000000,0,0,0,0,0,32.3C,,,,,31.3C,5.20,000000,5.20
0 1   2 3 4        5 6  7        8                9        0 1 2 3 4 5     67890     1    2      3    4

get status of all valves
> rlb v
V,00......

get status of all relays
> rlb r
R,....000000000000

set status of relay 5
> rlb r 5 1
R,....010000000000

set status of valve 1
> rlb v 1 2
V,02......
this activated output 2 of valve 1 and shows that valve 0 is not fed any power

get general status
> rlb s
 S,215,0,2,00:00:00,5,10,02......,....010000000000,00000000,0,0,0,0,0,32.3C,,,,,31.3C,5.20,000000,5.20
0 1   2 3 4        5 6  7        8                9        0 1 2 3 4 5     67890     1    2      3    4
as you can see the general status reflects the changes in field 7 and 8.

Temperature sensors
-------------------
The DS18x20 temperature sensors used in this project have 64 bit addresses.
The firmware maintains a table of these addresses to associate the
measurements with positions in the general status vector. Fields 15...20
in the general status vector reflect the measurements. The firmware can scan
the One Wire Bus to find sensor addresses not in its table.

> t
T,ts0,63.1F,TS28FF925154140019,150155007FFF0C10,63.2F,TS28FF85292D04000D,1A0155007FFF0C10,63.7F
This scan found the sensor assigned to slot 0 and two sensors it does not
know about. The unknown sensors have a 3 field response, the first is the
sensor address, the second is the scratch pad read from the sensor and the
third is the temperature measurement of that sensor.

The following command will add one of the unknown sensors into slot 2:
> p ts2 28FF925154140019

Note: The relay board has an onboard sensor, it is assigned to slot 0.
      The address of this sensor sans the CRC byte is the serial number of
      the board.
Note: You can assign the same sensor to multiple slots.
Note: The firmware starts a temperature measurement cycle every 10 seconds at
      (wcs%10)==9

To kill a sensor assignement use:
> p ts2 x
The response is the confirmation of the slot clearance

Level sensor
------------

The firmware supports the Parallax Sonar sensor (3 pin, single data line).
There are plans to support the much cheaper HC-SR04 (4 pin, 0.3cm).
There are plans to support the much cheaper HC-SR05 (4 pin, 0.3cm).
The sonar sensor measurement is triggered every second.

Analog sensors
--------------
The relay board has 5 analog inputs, A0, A1, A2, A3 and AS. Their measurements
are reflected in fields 10...14 of the general status vector. AS is connected
to a resistor network powered by the 12VDC connector. Every analog input has a
couple of variables associated with it that allow transformation of the
measurement into the general status vector. At the point of this writing there
is an offset and a scale. The reference voltage used for digitization is 5V.
The firmware triggers a read cycle of all analog inputs every 5 seconds
at (wcs%5)==3.

Remote Spa Control
------------------
The relay board has an interface for a 'standard' remote spa control with
4 buttons and a lamp. The status of the remote control buttons is reflected in
the first 4 digits of field 22 of the general status vector.

The lamp is controlled with the 'l' command:
> l	query status
L,0 or L,1 or L,2
> l 0	turns it off
L,0
> l 1	turns it on
L,1
> l 2	turns it on blinking
L,2

Note: the button status will reflect simultaneous activations.

Smart pump control
------------------
The firmware can interact with smart pumps and provide the necessary
communication to make the pumps happy and follow instructions from the
controller. To enable the firmware to 'talk' to a pump it needs to have
a controller address on the RS485 bus that does not interfere with
other controllers.
> p ctl 14
will assign hex 14 to the controller.
Smart pumps are numbered 1...16. The firmware 'm' commands take a postfix,
which is interpreted as the pump number, a 'm1' will address pump #1. If you
issue a 'm?' the firmaware will try to obtain a status report from each of the
16 possible pumps.
There is only one pump command that is used to control a pump. The argument to
the command allows the firmware to distinguish between the different pump types.
All pump types honor a '0' argument, which stops the pump. An argument in the
range of 1...4 will start the respective external control program on the pump.
An argument in the range of 25...70 is taken as the flow rate (GPM) for a VF
pump. An argument in the range of 450...3450 is taken as the speed (RPM) for
a VS pump.

The following command will start a Pentair VS pump 3 to run at 2000 RPM:
> m3 2000
to change speed on the fly issue:
> m3 1800
to stop the pump issue:
> m3 0

The firmware will turn off the panel of the pump once it is under firmware
control. A 0 argument will stop the pump and release it from firmware control.

