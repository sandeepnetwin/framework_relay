
function srvpost(cmd,ans) {
	var r;
	try { r = new XMLHttpRequest(); }
	catch (e) { try { r = new ActiveXObject("MSXML2.XMLHTTP"); }
	catch (e) { try { r = new ActiveXObject("Microsoft.XMLHTTP"); }
	catch (e) { alert("Browser is broken or ancient!"); return null; } }}
	r.onreadystatechange = function() { if (r.readyState == 4) ans(r.responseText.trim(),r.status); }
	// IE caches GET requests but not POST requests...
	r.open("POST",location.href.split("/").slice(-1),true);
	r.setRequestHeader("Content-type","application/x-www-form-urlencoded");
//	r.setRequestHeader("Cache-Control","no-cache");	// Safari caches POST requests...
//	r.send('cmd='+cmd+"&time="+Date.now());
	r.timeout = 60000;
	r.send('cmd='+cmd);
}
