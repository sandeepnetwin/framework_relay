<?php
include 'rlb.php';

function dowi2d($v)
{
	switch ($v) {
	default:
	case 0: $d = "0 Sunday"; break;
	case 1: $d = "1 Monday"; break;
	case 2: $d = "2 Tuesday"; break;
	case 3: $d = "3 Wednesday"; break;
	case 4: $d = "4 Thursday"; break;
	case 5: $d = "5 Friday"; break;
	case 6: $d = "6 Saturday"; break;
	case 7: $d = "7 Sunday"; break;
	}
	return "<br>".$d;
}

function rlbi2d($i,$v)
{
	$d = "";
	switch ($i) {
	case  0: $d .= "Record ID"; break;
	case  1: $d .= "Sequence #"; break;
	case  2: $d .= "Mode<br> 0 manual<br> 1 auto"; break;
	case  3: $d .= "Day of week".dowi2d($v); break;
	case  4: $d .= "Wall clock"; break;
	case  5: $d .= "RTC status"; break;
	case  6: $d .= "Error status";
		 $d .= "<br> bit 0 w1bus";
		 $d .= "<br> bit 1 clock";
		 $d .= "<br> bit 2 level";
		 $d .= "<br> bit 3 i2cbus";
		 $d .= "<br> bit 4 24VAC";
		 break;
	case  7: $d .= "Valve status"; break;
	case  8: $d .= "Relay status"; break;
	case  9: $d .= "Powercenter status"; break;
	case 10: $d .= "Analog input 0"; break;
	case 11: $d .= "Analog input 1"; break;
	case 12: $d .= "Analog input 2"; break;
	case 13: $d .= "Analog input 3"; break;
	case 14: $d .= "DC supply voltage"; break;
	case 15: $d .= "Controller temperature"; break;
	case 16: $d .= "Temperature sensor 1"; break;
	case 17: $d .= "Temperature sensor 2"; break;
	case 18: $d .= "Temperature sensor 3"; break;
	case 19: $d .= "Temperature sensor 4"; break;
	case 20: $d .= "Temperature sensor 5"; break;
	case 21: $d .= "Level sensor (instant)"; break;
	case 22: $d .= "Remote Spa Control status"; break;
	case 23: $d .= "Level sensor (average)"; break;
	case 24: $d .= "Pump sequencer 0 status"; break;
	case 25: $d .= "Pump sequencer 1 status"; break;
	case 26: $d .= "Pump sequencer 2 status"; break;
	}
	return $d;
}

function spri2d($i,$v)
{
	$d = "";
	switch ($i) {
	case  0: $d .= "Record ID"; break;
	case  1: $d .= "Sequence #"; break;
	case  2: $d .= "Mode<br> bit 0 auto<br> bit 1 rain"; break;
	case  3: $d .= "Day of week".dowi2d($v); break;
	case  4: $d .= "Wall clock"; break;
	case  5: $d .= "RTC status"; break;
	case  6: $d .= "Error status";
		 $d .= "<br> bit 0 w1bus";
		 $d .= "<br> bit 1 clock";
		 $d .= "<br> bit 3 i2cbus";
		 $d .= "<br> bit 4 24VAC";
		 break;
	case  7: $d .= "Schedule status"; break;
	case  8: $d .= "Station status"; break;
	case  9: $d .= "Powercenter status"; break;
	case 10: $d .= "Analog input 0"; break;
	case 11: $d .= "Analog input 1"; break;
	case 12: $d .= "Analog input 2"; break;
	case 13: $d .= "Analog input 3"; break;
	case 14: $d .= "DC supply voltage"; break;
	case 15: $d .= "Controller temperature"; break;
	case 16: $d .= "Temperature sensor 1"; break;
	case 17: $d .= "Temperature sensor 2"; break;
	case 18: $d .= "Rain gauge residual"; break;
	}
	return $d;
}
?>
<!DOCTYPE html>
<html>
<head>
<meta name=viewport content="width=device-width, initial-scale=1.0" />
<meta name=format-detection content="telephone=no" />
<title>RLB Status</title>
<link rel=stylesheet type=text/css href=rlb.css>
<style>
table { width: 98%; margin: 0.5em auto; }
table, th, td { font-size: 10pt; color: #000; background-color: lightblue; border: 1px solid blue; }
td { padding:0.25em 0.5em; }
.tci { text-align: center; }
.tcv { text-align: left; }
.tcd { text-align: left; }
</style>
</head>
<body>
<div id=main>
<?php
	$dat = exec('date');
	$fmw = exec($rlb."y");
	$sti = explode(" ",$fmw);
	if ($sti[0] == "fmwspr") $i2d = spri2d;
	else $i2d = rlbi2d;
	$stv = exec($rlb."s");
	$dsc = wordwrap($stv,38,"<br>",true);
	echo "<table><tr><th>$dat</th><tr><tr><th>$fmw</th><tr><tr><th>$dsc</th></tr></table>";
	echo "<table><tr><th>[]</th><th>Value</th><th>Description</th></tr>";
	$sti = explode(",",$stv);
	$n = count($sti);
	for ($i=0; $i<$n; $i++) {
		$val = $sti[$i];
		$dsc = $i2d($i,$val);
		echo "<tr><td class=tci>$i</td><td class=tcv>$val</td><td class=tcd>$dsc</td></tr>";
	}
	echo "</table>";
	$cpr = get_cpr();
	echo "<div class=rf>$cpr</div><br>";
?>
</div>
</body>
</html>
