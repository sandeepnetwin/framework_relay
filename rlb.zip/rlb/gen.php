<?php
include 'rlb.php';
// AJAX ...
if (($cmd = $_POST['cmd']) != null) {
	if ($cmd == "lp") $cmd .= ",".$_SERVER['REMOTE_ADDR'].":".$_SERVER['REMOTE_PORT'];
	passthru($rlb.$cmd);
	return;
}

/*
 * Java Script
 */
function djsc()
{
	echo "<script language=javascript type=text/javascript>";

// click event
	echo <<<EOSCRIPT
	var cph = 0;
	if (document.addEventListener)
		document.addEventListener("click",clickevent,true);
	else	document.attachEvent("onclick",clickevent);	// IE8
	function clickevent(e) { cph = e.clientX; }

EOSCRIPT;

	echo <<<EOSCRIPT
	function rupd(vrb,vec) {
		var i, c;
		for (i = vec.length; --i >= 0; )
			if ((c = document.getElementById(vrb+i)) != null)
				switch (vec.substr(i,1)) {
				case "0": c.className = "r0"; break;
				case "1": c.className = "r1"; break;
				case "2": c.className = "r2"; break;
				}
	}
	function rsho(ans) {
		var el;
		var a = ans.split(",");
		if (a[0] === "S") {
			if (a.length < 10) return;
			rupd("v,",a[7]);
			rupd("r,",a[8]);
			rupd("b,",a[9]);
			if ((el = document.getElementById('stat')) != null)
				el.innerHTML = a[4]+" "+a[15];
		}
		else if (a.length != 2) return;
		else if (a[0] === "V") rupd("v,",a[1]);
		else if (a[0] === "R") rupd("r,",a[1]);
		else if (a[0] === "B") rupd("b,",a[1]);
		else if (a[0] === "L" && (el = document.getElementById('rled')) != null)
			switch (a[1]) {
			default:  el.className = "r0"; break;
			case "0": el.className = "r0"; break;
			case "1": el.className = "r1"; break;
			case "2": el.className = "r2"; break;
		}
	}
	function rchg(el) {
		var r, n, k;
		k = ((cph - el.offsetLeft) < (el.offsetWidth/4)) ? true : false;
		if (el.id.substr(0,1) == 'v' && el.className != "r0" && k == true) n = 0;
		else switch (el.className) {
		default:   n = 0; break;
		case "r0": n = 1; break;
		case "r1": n = el.id.substr(0,1) == 'v' ? 2 : 0; break;
		case "r2": n = 1; break;
		}
		el.className = "rw";
		srvpost(el.id+","+n,rsho);
	}
	function lchg(el) {
		var n;
		switch (el.className) {
		default:   n = 0; break;
		case "r0": n = 1; break;
		case "r1": n = 2; break;
		case "r2": n = 0; break;
		}
		el.className = "rw";
		srvpost("l,"+n,rsho);
	}
	function strt_lp() { srvpost("lp",proc_lp); }
	function proc_lp(vec) {
		rsho(vec);
		strt_lp();
	}
EOSCRIPT;
	echo "</script>";
}

function rgen()
{
	global $rlb;

	$si = explode(" ",$fm = exec($rlb."y"));
	if (strncmp($si[0],"fmwrlb",6)) { echo "<h2 style='text-align:center;'>$fm</h2>"; return; }

	$si = explode(",",$sv = exec($rlb."s"));
	if ($sv[0] !== "S" || count($si) < 18) { echo "<h3>$sv</h3>"; return; }

	if (count($si) < 9) { echo "<h2>bad sv: $sv</h2>"; return; }
	echo "<div id=main>";
		echo "<h2 style='text-align:center;'>Valves and Relays</h2>";
		echo "<div id=stat class=rs>WAIT...</div>";

		$vv = $si[7];
		$vr = $si[8];
		for ($i = 0; $i < 8; $i++)
			if ($vv[$i] == ".") {
				$r = $i * 2;
				echo "<div id=\"r,$r\" class=r$vr[$r] onclick=rchg(this)><div class=icc>Relay $r</div></div>";
				$r++;
				echo "<div id=\"r,$r\" class=r$vr[$r] onclick=rchg(this)><div class=icc>Relay $r</div></div>";
			}
			else	echo "<div id=\"v,$i\" class=r$vv[$i] onclick=rchg(this)><div class=icc>Valve $i</div></div>";

		if (($n = strlen($vec=$si[9])) <= 0) echo "<p>no power bits configured</p>";
		else {	
			for ($i=0; $i<$n && $i < 7; $i++)
				echo "<div id=\"b,$i\" class=r$vec[$i] onclick=rchg(this)><div class=icc>Power $i</div></div>";
			if ($i < $n)
				echo "<div id=\"rled\" class=r$vec[$i] onclick=lchg(this)><div class=icc>Remote LED</div></div>";
		}
		$rv = get_cpr();
		echo "<div class=rf>$rv</div>";
	echo "</div>";
	echo "<script>rsho('$sv');</script>";
	echo "<script>strt_lp();</script>";
}
?>
<!DOCTYPE html>
<html>
<head>
<meta name=viewport content="width=device-width, initial-scale=1.0" />
<title>RLB Relays</title>
<link rel=stylesheet type=text/css href=rlb.css>
</head>
<body>
<script src=rlb.js type=text/javascript></script>
<?php djsc(); ?>
<?php rgen(); ?>
</body>
</html>
