<?php include 'rlb.php'; ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">

<head>
<meta name=viewport content="width=device-width, initial-scale=1.0" />
<meta name=format-detection content="telephone=no" />
<title>RLB</title>
<link rel=stylesheet type=text/css href=rlb.css>
<style>
.r0 { padding: 1.5em 0;}
</style>
</head>

<body>
<?php
	$fmw = exec($rlb."y");
	echo "<div id=main>";
		echo "<p style='text-align:center; font-size:12pt;'>$fmw</p>";
		echo "<div class=r0 onclick=location.href=('gst.php')><div class=icc>RLB status</div></div>";
		echo "<div class=r0 onclick=location.href=('cfg.php')><div class=icc>Configuration</div></div>";
		echo "<div class=r0 onclick=location.href=('gen.php')><div class=icc>Valves and Relays</div></div>";
		$cpr = get_cpr(); echo "<div class=rf>$cpr</div><br>";
	echo "</div>";
?>
</body>

</html>
