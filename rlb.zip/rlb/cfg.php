<?php
include 'rlb.php';
// AJAX ...
if (($cmd = $_POST['cmd']) != null) {
	if ($cmd == "lp") $cmd .= ",".$_SERVER['REMOTE_ADDR'].":".$_SERVER['REMOTE_PORT'];
	passthru($rlb.$cmd);
	return;
}

/*
 * CSS
 */
function dcss()
{
	echo "<style>";

	echo <<<EOSTYLE
.mb1, .mb2, .mb3 {
	box-shadow:0px 0px 0px 2px #9fb4f2;
	border-radius:8px;
	background-color:#7892c2;
	border:2px solid #4e6096;
	cursor:auto;
	color:#000;
	font-size:12pt;
	text-shadow:0px 0px 3px #283966;
	float: left;
	padding: 0.25em 0.2em;
	margin: 0.3em 0.2em; // vertical/horizontal spacing
	text-overflow: ellipsis;
	overflow: hidden;
}
.mb2:hover { background-color:#476e9e; }
.mb1 { width:10%; text-align:center; }
.mb2 { width:25%; text-align:left; color:#fff; }
.mb3 { width:48%; text-align:left; }
.mbw { text-align:left; }
.fll { float: left; }
.flr { float: right; }
.flc { clear: both; }
//#main { background: red; }
EOSTYLE;
	echo "</style>";
}

/*
 * Java Script
 */
function djsc()
{
	echo "<script language=javascript type=text/javascript>";

echo <<<EOSCRIPT
	var rtscn = 0;
	function psho(pmsg) {
		var el, pn, pv, a, i;
		a = pmsg.split(",");
		if (a.length < 3 || a[0] != "P") alert("reply: "+pmsg);
		else for (i = 1; i < a.length; ) {
			pn = a[i++];
			pv = a[i++];
			if (pn.substring(0,2) == "ap") pv = pv+","+a[i++];
			else if (pn == "tsu") pv = pv == "C" ? "Celsius":"Farenheit";
			if ((el = document.getElementById(pn)) == null) alert("unknown parameter: "+pn);
			else el.innerHTML = pv;
			if (rtscn) rtscn = 0, srvpost('t',tscn);
		}
	}
	function tscn(vec) {
		var el, v, i, n, a;
		rtscn = 0;
		v = vec.split(",");
		if (v.length < 3 || v[0] != "T") return;
		for (n = 0, i = 1; i < v.length; i++) {
			a = v[i++];
			if (a.substr(0,2) == "TS") {
				i++; /* skip data readout of new sensor */
				if ((el = document.getElementById("tsu"+n)) == null) break;
				el.innerHTML = a.substring(2)+" "+v[i];
				n++;
			}
		}
		while (n < 5) if ((el = document.getElementById("tsu"+n)) == null) break; else el.innerHTML = "", n++;
	}
	function pchg(el) {
		var vl, q;
		vl = prompt(document.getElementById("d"+el.id).innerHTML,el.innerHTML);
		if (vl == null || vl == "") return;
		q = "p,"+el.id+","+vl;
		el.blur(); el.value = "";
		srvpost(q,psho);
		if (el.id.substring(0,2) == "ts") rtscn = 1;
	}
EOSCRIPT;

	echo "</script>";
}

function nm2ds($nm)
{
	switch ($nm) {
	case "adj": $ds="Clock adjustment, positive values slow it down, negative values speed it up"; break;
	case "vlm": $ds="Valve mask (hex)"; break;
	case "npc": $ds="# Powercenter bits"; break;
	case "ctl": $ds="Pentair bus: this controllers address"; break;
	case "srv": $ds="Pentair bus: time server address"; break;
	case "pm0": $ds="Pentair bus: pump 0 address"; break;
	case "pm1": $ds="Pentair bus: pump 1 address"; break;
	case "pm2": $ds="Pentair bus: pump 2 address"; break;
	case "ap0": $ds="Analog input 0 offset,scale"; break;
	case "ap1": $ds="Analog input 1 offset,scale"; break;
	case "ap2": $ds="Analog input 2 offset,scale"; break;
	case "ap3": $ds="Analog input 3 offset,scale"; break;
	case "ap4": $ds="Analog input 4 offset,scale"; break;
	case "aps": $ds="12V DC power feed offset,scale"; break;
	case "son": $ds="Sonar reference level in [inch]"; break;
	case "tsu": $ds="Temp. units"; break;
	case "ts0": $ds="Temp. sensor 0"; break;
	case "ts1": $ds="Temp. sensor 1"; break;
	case "ts2": $ds="Temp. sensor 2"; break;
	case "ts3": $ds="Temp. sensor 3"; break;
	case "ts4": $ds="Temp. sensor 4"; break;
	case "ts5": $ds="Temp. sensor 5"; break;
	case "nsc": $ds="# Schedules"; break;
	case "nst": $ds="# Stations"; break;
	default:    $ds="unknown"; break;
	}
	return $ds;
}

function pgen()
{
	global $rlb;

	$si = explode(" ",$fm = exec($rlb."y"));
	if (strncmp($si[0],"fmwrlb",6)) { echo "<h2 style='text-align:center;'>$fm</h2>"; return; }
	echo "<div id=main>";
		echo "<h2 style='text-align:center;'>Configuration $si[0]</h2>";
		$pmi = explode(",",$pmv = exec($rlb."p"));
		if ($pmi[0] !== "P" || ($n = count($pmi)) < 3) echo "<h2>$pmv</h2>";
		else {
			for ($i=1; $i<$n; $i++) {
				$pnm = $pmi[$i++];
				if (strncmp("ap",$pnm,2) == 0) $i++;
				$pds = nm2ds($pnm);
				echo "<div class=mb1>$pnm</div>";
				echo "<div id=$pnm class=mb2 onclick=pchg(this)></div>";
				echo "<div id=d$pnm class=mb3>$pds</div>";
				echo "<div class=flc></div>";
			}
			for ($i=0; $i<5; $i++) echo "<div id=tsu$i></div>";
		}
		$cpr = get_cpr(); echo "<div class=rf>$cpr</div><br>";
	echo "</div>";
	echo "<script>psho('$pmv');</script>";
	echo "<script>srvpost('t',tscn);</script>";
}
?>
<!DOCTYPE html>
<html>
<head>
<meta name=viewport content="width=device-width, initial-scale=1" />
<title>RLB Configuration</title>
<link rel=stylesheet type=text/css href=rlb.css>
<?php dcss(); ?>
</head>
<body>
<script src=rlb.js type=text/javascript></script>
<?php djsc(); ?>
<?php pgen(); ?>
<br>
</body>
</html>
