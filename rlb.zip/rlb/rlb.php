<?php
switch (0) {
default:
case 0: $rlb="/usr/local/bin/rlb "; break;
case 1: $rlb="/usr/local/bin/rlb -h rpi "; break;
case 2: $rlb="/usr/local/bin/rlb -h gway "; break;
}
$cpr = "rlb &#169RusseWorks 20150715";
function get_cpr()
{
	global $rlb, $cpr;

	$syv = exec($rlb."Y");
	$syi = explode(" ",$syv);
	if (count($syi) == 2) return $syi[0]." &#169RusseWorks ".$syi[1];
	return $cpr;
}
?>
