<?php
    /**
    * @Programmer: Dhiraj S.
    * @Created: 21 July 2015
    * @Modified: 
    * @Description: Webservice to on/off Devices and Get status of Devices.
    **/
    
    if (!defined('BASEPATH'))
        exit('No direct script access allowed');
    
    class Web extends CI_Controller
    {
        protected $isHTTPSRequired          = FALSE; // Define whether an HTTPS connection is required
        protected $isAuthenticationRequired = FALSE; // Define whether user authentication is required
        
        // Define API response codes and their related HTTP response
        public $aApiResponseCode = array(
                                            0 => array('HTTP Response' => 400, 'Message' => 'Unknown Error'),
                                            1 => array('HTTP Response' => 200, 'Message' => 'Success'),
                                            2 => array('HTTP Response' => 403, 'Message' => 'HTTPS Required'),
                                            3 => array('HTTP Response' => 401, 'Message' => 'Authentication Required'),
                                            4 => array('HTTP Response' => 401, 'Message' => 'Authentication Failed'),
                                            5 => array('HTTP Response' => 404, 'Message' => 'Invalid Request'),
                                            6 => array('HTTP Response' => 400, 'Message' => 'Invalid Response Format')
                                        );
        
        public function __construct() 
        {
            parent::__construct(); // Parent Contructor Call
            $this->load->helper('common_functions'); // Loaded helper : To get all functions accessible from common_functions file.
            
        } // END : function __construct()
        
        public function changeDeviceStatus()
        {
            // Set default HTTP response of 'ok'
            $aResponse              =   array();
            $aResponse['code']      =   0;
            $aResponse['status']    =   404;
            $aResponse['data']      =   NULL;
            $sformat                =   isset($_REQUEST['format']) ? $_REQUEST['format'] : '' ; // Get response Format (json,xml,html etc.)
            $sAuth                  =   isset($_REQUEST['auth']) ? $_REQUEST['auth'] : '' ;// Check if Authentication is required.
            $this->isAuthenticationRequired =   $sAuth;
                
            // Optionally require connections to be made via HTTPS
            if( $this->isHTTPSRequired && $_SERVER['HTTPS'] != 'on' )
            {
                $aResponse['code']      = 2;
                $aResponse['status']    = $aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
                $aResponse['data']      = $aApiResponseCode[ $aResponse['code'] ]['Message'];

                // Return Response to browser. This will exit the script.
                $this->webResponse($sformat, $aResponse);
            }
            
            if($this->isAuthenticationRequired)
            {
                //START : Authorisation
                $sUsername       = isset($_REQUEST['username']) ? $_REQUEST['username'] : '' ;   // Get the username of webservice 
                $sPassword       = isset($_REQUEST['password']) ? $_REQUEST['password'] : '' ;   // Get the password of webservice 
                $this->webAuthorisation($sUsername, $sPassword,$sformat); // Check if username and password is valid.
                // END : Authorisation
            }
            
            #INPUTS
            $sDevice         = isset($_REQUEST['dvc']) ? $_REQUEST['dvc'] : '' ; // Get the Device(ie. R=Relay,V=Valve,PC=Power Center)
            $sDeviceNo       = isset($_REQUEST['dn'])  ? $_REQUEST['dn'] : '' ;  // Get the Device No.
            $iDeviceStatus   = isset($_REQUEST['ds']) ? $_REQUEST['ds'] : '' ;   // Get the status to which Device will be changed         
            
            $aResult            = array();
            $aResult['msg']     = "";
            $aResult['response']  = 0;
            $aDeviceStatus      = array('0', '1', '2'); //respective values of status.
                     
            $this->load->model('home_model');
            $iActiveMode =  $this->home_model->getActiveMode();
                        
            //if($iActiveMode == 2) // START : If Mode is Manual.
            {
                if($sDeviceNo != '' && in_array($iDeviceStatus, $aDeviceStatus) && $sDevice != '') 
                {
                    $sResponse      =   get_rlb_status(); // Get the relay borad response from server.
                    $sValves        =   $sResponse['valves']; // Valve Devices.
                    $sRelays        =   $sResponse['relay'];  // Relay Devices.
                    $sPowercenter   =   $sResponse['powercenter']; // Power Center Devices.
                    $sRelayNewResp  =   '';
                    
                    if($sDevice == 'R') // START : If Device is Relay.
                    {
                        if($sRelays != '') // START : Check if Relay devices are available.
                        {
                            $iRelayCount    = strlen($sRelays); // Count of Relay Devices.
                            if( $sDeviceNo > ($iRelayCount-1) || $sDeviceNo < 0)
                            {
                                $aResponse['code']      = 5;
                                $aResponse['status']    = $this->aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
                                $aResponse['data']      = 'Invalid relay number.';

                                // Return Response to browser. This will exit the script.
                                $this->webResponse($sformat, $aResponse);
                            } // END : if( $sDeviceNo > ($iRelayCount-1) || $sDeviceNo < 0)
                            else
                            {
                                $sRelayNewResp = replace_return($sRelays, $iDeviceStatus, $sDeviceNo ); // Change the status with the sent status for the device no.
                                onoff_rlb_relay($sRelayNewResp); // Send the request to change the status on server.		
                                //$aResult['response'] = 1;
                                //$aResult['msg'] = "Relay status changed successfully.";
                                $aResponse['code']      = 1;
                                $aResponse['status']    = $this->aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
                                $aResponse['data']      = 'Relay status changed successfully.';

                                // Return Response to browser. This will exit the script.
                                $this->webResponse($sformat, $aResponse);
                            } // END : else of if( $sDeviceNo > ($iRelayCount-1) || $sDeviceNo < 0)
                        }
                        else
                        {
                            $aResponse['code']      = 5;
                            $aResponse['status']    = $this->aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
                            $aResponse['data']      = 'Relay devices not available.';

                            // Return Response to browser. This will exit the script.
                            $this->webResponse($sformat, $aResponse);
                        }
                    } // END : if($sDevice == 'R')
                                        
                    if($sDevice == 'PC') // START : If Device is Power Center.
                    {
                        if($sPowercenter != '') // START : Check if Power Center devices are available.
                        {
                            $iPowerCenterCount    = strlen($sPowercenter); // Count of Power Center Devices.
                            if( $sDeviceNo > ($iPowerCenterCount-1) || $sDeviceNo < 0)
                            {
                                $aResponse['code']      = 5;
                                $aResponse['status']    = $this->aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
                                $aResponse['data']      = 'Invalid Power Center number.';

                                // Return Response to browser. This will exit the script.
                                $this->webResponse($sformat, $aResponse);
                            } // END : if( $sDeviceNo > ($iPowerCenterCount-1) || $sDeviceNo < 0)
                            else
                            {
                                $sRelayNewResp = replace_return($sPowercenter, $iDeviceStatus, $sDeviceNo ); // Change the status with the sent status for the device no.
                                onoff_rlb_powercenter($sRelayNewResp); // Send the request to change the status on server.		
                                //$aResult['response'] = 1;
                                //$aResult['msg'] = "Power Center status changed successfully.";
                                $aResponse['code']      = 1;
                                $aResponse['status']    = $this->aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
                                $aResponse['data']      = 'Power Center status changed successfully.';

                                // Return Response to browser. This will exit the script.
                                $this->webResponse($sformat, $aResponse);
                            } // END : else of if( $sDeviceNo > ($iPowerCenterCount-1) || $sDeviceNo < 0)
                        }
                        else
                        {
                            $aResponse['code']      = 5;
                            $aResponse['status']    = $this->aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
                            $aResponse['data']      = 'Power Center devices not available.';

                            // Return Response to browser. This will exit the script.
                            $this->webResponse($sformat, $aResponse);
                        }
                    } // END : if($sDevice == 'PC')
                                        
                    if($sDevice == 'V') // START : If Device is Power Center.
                    {
						if($sValves != '') // START : Check if Valve devices are available.
                        {
                            $iValveCount    = strlen($sValves); // Count of Power Center Devices.
                            if( $sDeviceNo > ($iValveCount-1) || $sDeviceNo < 0)
                            {
                                $aResponse['code']      = 5;
                                $aResponse['status']    = $this->aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
                                $aResponse['data']      = 'Invalid Valve number.';

                                // Return Response to browser. This will exit the script.
                                $this->webResponse($sformat, $aResponse);
                            } // END : if( $sDeviceNo > ($iValveCount-1) || $sDeviceNo < 0)
                            else
                            {
                                $sRelayNewResp = replace_return($sValves, $iDeviceStatus, $sDeviceNo ); // Change the status with the sent status for the device no.
                                onoff_rlb_valve($sRelayNewResp); // Send the request to change the status on server.		
                                //$aResult['response'] = 1;
                                //$aResult['msg'] = "Valve status changed successfully.";
                                $aResponse['code']      = 1;
                                $aResponse['status']    = $this->aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
                                $aResponse['data']      = 'Valve status changed successfully.';

                                // Return Response to browser. This will exit the script.
                                $this->webResponse($sformat, $aResponse);
                            } // END : else of if( $sDeviceNo > ($iValveCount-1) || $sDeviceNo < 0)
                        }
                        else
                        {
                            //$aResult['msg'] = "Valve devices not available."; 
                            $aResponse['code']      = 5;
                            $aResponse['status']    = $this->aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
                            $aResponse['data']      = 'Valve devices not available.';

                            // Return Response to browser. This will exit the script.
                            $this->webResponse($sformat, $aResponse);
                        }
                    } // END : if($sDevice == 'V')
					
					if($sDevice == 'PS')
					{
						$sPump	=	'';
						if(isset($sResponse['pump_seq_'.$sDeviceNo.'_st']))
							$sPump = $sResponse['pump_seq_'.$sDeviceNo.'_st'];
						
						if($sPump != '')
						{		
							$aPumpDetails = $this->home_model->getPumpDetails($sDeviceNo);
							//Variable Initialization to blank.
							$sPumpNumber  	= '';
							$sPumpType  	= '';
							$sPumpSubType  	= '';
							$sPumpSpeed  	= '';
							$sPumpFlow 		= '';
							$sPumpClosure   = '';
							$sRelayNumber  	= '';

							if(is_array($aPumpDetails) && !empty($aPumpDetails))
							{
							  foreach($aPumpDetails as $aResultEdit)
							  { 
								$sPumpNumber  = $aResultEdit->pump_number;
								$sPumpType    = $aResultEdit->pump_type;
								$sPumpSubType = $aResultEdit->pump_sub_type;
								$sPumpSpeed   = $aResultEdit->pump_speed;
								$sPumpFlow    = $aResultEdit->pump_flow;
								$sPumpClosure = $aResultEdit->pump_closure;
								$sRelayNumber = $aResultEdit->relay_number;
							  }
							}
							else
							{
								$aResponse['code']      = 5;
								$aResponse['status']    = $this->aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
								$aResponse['data']      = 'Pump devices not configured properly.';

								// Return Response to browser. This will exit the script.
								$this->webResponse($sformat, $aResponse);
							}
							
							if($sPumpType != '' && $sPumpClosure == '1')
							{
								if($sPumpType == '12' || $sPumpType == '24')
								{
									if($sPumpType == '24')
									{
										$sNewResp = replace_return($sRelays, $iDeviceStatus, $sRelayNumber );
										onoff_rlb_relay($sNewResp);
										$this->home_model->updateDeviceRunTime($sDeviceNo,$sDevice,$iDeviceStatus);
									}
									else if($sPumpType == '12')
									{
										$sNewResp = replace_return($sPowercenter, $iDeviceStatus, $sRelayNumber );
										onoff_rlb_powercenter($sNewResp);
									}
									
									$aResponse['code']      = 1;
									$aResponse['status']    = $this->aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
									$aResponse['data']      = 'Pump status changed successfully.';
								}
								else
								{
									if(preg_match('/Emulator/',$sPumpType))
									{
										$sNewResp = '';

										if($iDeviceStatus == '0')
											$sNewResp =  $sDeviceNo.' '.$iDeviceStatus;
										else if($iDeviceStatus == '1')
										{
											$sType          =   '';
											if($sPumpSubType == 'VS')
												$sType  =   '2'.' '.$sPumpSpeed;
											elseif ($sPumpSubType == 'VF')
												$sType  =   '3'.' '.$sPumpFlow;

											$sNewResp =  $sDeviceNo.' '.$sType;    
										}
										
										onoff_rlb_pump($sNewResp);
										
										if($sPumpType == 'Emulator12')
										{
											$sNewResp12 = replace_return($sPowercenter, $iDeviceStatus, $sRelayNumber );
											onoff_rlb_powercenter($sNewResp12);
										}
										if($sPumpType == 'Emulator24')
										{
											$sNewResp24 = replace_return($sRelays, $iDeviceStatus, $sRelayNumber );
											onoff_rlb_relay($sNewResp24);
											$this->home_model->updateDeviceRunTime($sRelayNumber,'R',$iDeviceStatus);
										}
										$aResponse['code']      = 1;
										$aResponse['status']    = $this->aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
										$aResponse['data']      = 'Pump status changed successfully.';
									}
									else if(preg_match('/Intellicom/',$sPumpType))
									{
										$sNewResp = '';

										if($iDeviceStatus == '0')
											$sNewResp =  $sDeviceNo.' '.$iDeviceStatus;
										else if($iDeviceStatus == '1')
										{
											$sType  =   '2'.' '.$sPumpSpeed;
											$sNewResp =  $sDeviceNo.' '.$sType;    
										}
										
										onoff_rlb_pump($sNewResp);
										
										if($sPumpType == 'Intellicom12')
										{
											$sNewResp12 = replace_return($sPowercenter, $iDeviceStatus, $sRelayNumber );
											onoff_rlb_powercenter($sNewResp12);
										}
										if($sPumpType == 'Intellicom24')
										{
											$sNewResp24 = replace_return($sRelays, $iDeviceStatus, $sRelayNumber );
											onoff_rlb_relay($sNewResp24);
											$this->home_model->updateDeviceRunTime($sRelayNumber,'R',$iDeviceStatus);
										}
										$aResponse['code']      = 1;
										$aResponse['status']    = $this->aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
										$aResponse['data']      = 'Pump status changed successfully.';
									}
								}
							}
							else
							{
								$aResponse['code']      = 5;
								$aResponse['status']    = $this->aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
								$aResponse['data']      = 'Pump devices not configured properly or Closure is set to 0.';

								// Return Response to browser. This will exit the script.
								$this->webResponse($sformat, $aResponse);
							}
							
						}
						else
                        {
                            $aResponse['code']      = 5;
                            $aResponse['status']    = $this->aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
                            $aResponse['data']      = 'Pump devices not available.';

                            // Return Response to browser. This will exit the script.
                            $this->webResponse($sformat, $aResponse);
                        }
					}						
					
                } // END : if($sDeviceNo != '' && in_array($iDeviceStatus, $aDeviceStatus) && $sDevice != '')
                else
                {
                    $aResponse['code']      = 5;
                    $aResponse['status']    = $this->aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
                    $aResponse['data']      = 'Invalid Device number Or Device status OR Device Type.';

                    // Return Response to browser. This will exit the script.
                    $this->webResponse($sformat, $aResponse);
                }
            } // END : if($iActiveMode == 2)
            /*else
            {
                $aResponse['code']      = 5;
                $aResponse['status']    = $this->aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
                $aResponse['data']      = 'Invalid mode to perform this operation.';

                // Return Response to browser. This will exit the script.
                $this->webResponse($sformat, $aResponse);
            }*/
            //$aResult['msg'] = "Invalid mode to perform this operation.";
        } //END : function changeDeviceStatus()
        
         public function getDeviceStatus()
         {
            // Set default HTTP response of 'ok'
            $aResponse              =   array();
            $aResponse['code']      =   0;
            $aResponse['status']    =   404;
            $aResponse['data']      =   NULL;
            $sformat                =   isset($_REQUEST['format']) ? $_REQUEST['format'] : '' ; // Get response Format (json,xml,html etc.)
            $sAuth                  =   isset($_REQUEST['auth']) ? $_REQUEST['auth'] : '' ;// Check if Authentication is required.
            $this->isAuthenticationRequired =   $sAuth;
            
            // Optionally require connections to be made via HTTPS
            if( $this->isHTTPSRequired && $_SERVER['HTTPS'] != 'on' )
            {
                $aResponse['code']      = 2;
                $aResponse['status']    = $aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
                $aResponse['data']      = $aApiResponseCode[ $aResponse['code'] ]['Message'];

                // Return Response to browser. This will exit the script.
                $this->webResponse($sformat, $aResponse);
            }
            
            if($this->isAuthenticationRequired)
            {
                //START : Authorisation
                $sUsername       = isset($_REQUEST['username']) ? $_REQUEST['username'] : '' ;   // Get the username of webservice 
                $sPassword       = isset($_REQUEST['password']) ? $_REQUEST['password'] : '' ;   // Get the password of webservice 
                $this->webAuthorisation($sUsername, $sPassword,$sformat); // Check if username and password is valid.
                // END : Authorisation
            }
             
            #INPUTS
            $sDevice         = isset($_REQUEST['dvc']) ? $_REQUEST['dvc'] : '' ;
            
            $aResult            = array();
            $aResult['msg']     = "";
            $aResult['response']= 0;
            $aResult['status']  = 0;
            
            $sValves            = ""; // Valve Devices Initialization.
            $sRelays            = "";  // Relay Devices Initialization.
            $sPowercenter       = ""; // Power Center Devices Initialization.
            $iCntValves         = "0"; // Valve Devices Count Initialization.
            $iCntRelays         = "0";  // Relay Devices Count Initialization.
            $iCntPowercenter    = "0"; // Power Center Devices Initialization.
            
            $this->load->model('home_model');
            $iActiveMode =  $this->home_model->getActiveMode();
            
            //if($iActiveMode == 2) // START : If Mode is Manual.
            {
                if($sDevice != '') // START : If device type is not empty
                {
                    $sResponse      =   get_rlb_status(); // Get the relay borad response from server.
                    if($sDevice == "V") // START : If Device is Valve
                    {
                        if($sResponse['valves'] != '') // START : Checked if Valve Devices are available
                        {
                            $sValves        =   $sResponse['valves']; // Valve Devices.
                            $iCntValves     =   strlen($sValves); // Count of Valve Devices.
                            
                            $aResponse['code']      = 1;
                            $aResponse['status']    = $this->aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
                            $aResponse['data']      = $sValves;

                            // Return Response to browser. This will exit the script.
                            $this->webResponse($sformat, $aResponse);
                        } // END : Checked if Valve Devices are available
                        else
                        {
                            $aResponse['code']      = 5;
                            $aResponse['status']    = $this->aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
                            $aResponse['data']      = 'Valve devices not available.';

                            // Return Response to browser. This will exit the script.
                            $this->webResponse($sformat, $aResponse);
                        }
                    } // if($sDevice == "V") END : If Device is Valve
                    else if($sDevice == "R") // START : If Device is Relay.
                    {
                        if($sResponse['relay'] != '')
                        {
                            $sRelays        =   $sResponse['relay'];  // Relay Devices.
                            $iCntRelays     =   strlen($sRelays); // Count of Relay Devices.
                            
                            $aResponse['code']      = 1;
                            $aResponse['status']    = $this->aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
                            $aResponse['data']      = $sRelays;
                            
                            $this->webResponse($sformat, $aResponse);
                        }
                        else
                        {
                            $aResponse['code']      = 5;
                            $aResponse['status']    = $this->aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
                            $aResponse['data']      = 'Relay devices not available.';

                            // Return Response to browser. This will exit the script.
                            $this->webResponse($sformat, $aResponse);
                        }
                    } // END : If Device is Relay.
                    else if($sDevice == "PC") // START : If Device is Power Center.
                    {
                        if($sResponse['powercenter'] != '')
                        {
                            $sPowercenter   =   $sResponse['powercenter']; // Power Center Devices.
                            $iCntPowercenter=   strlen($sPowercenter); // Count of Power Center Devices.
                            
                            $aResponse['code']      = 1;
                            $aResponse['status']    = $this->aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
                            $aResponse['data']      = $sPowercenter;
                            
                            $this->webResponse($sformat, $aResponse);
                        }
                        else
                        {    
                            $aResponse['code']      = 5;
                            $aResponse['status']    = $this->aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
                            $aResponse['data']      = 'Power Center devices not available.';

                            // Return Response to browser. This will exit the script.
                            $this->webResponse($sformat, $aResponse);
                        }
                    } // END : If Device is Power Center.
					else if($sDevice == "PS")// START : If Device is PUMPS.
					{
						$sPumps 		= '';
						for($i=0;$i<3;$i++)
						{
							$aPumpDetails = $this->home_model->getPumpDetails($i);
							//Variable Initialization to blank.
							$sPumpNumber  	= '';
							$sPumpType  	= '';
							$relay_number   = '';
							
							if(is_array($aPumpDetails) && !empty($aPumpDetails))
							{
							  foreach($aPumpDetails as $aResultEdit)
							  { 
								$sPumpNumber  = $aResultEdit->pump_number;
								$sPumpType    = $aResultEdit->pump_type;
								$relay_number = $aResultEdit->relay_number;
								$sPumpClosure = $aResultEdit->pump_closure;
								
								if($sPumpType != '' && $sPumpClosure == '1')
								{
									if($sPumpType == '12' || $sPumpType == '24')
									{
										if($sPumpType == '24')
										{
											if($sResponse['relay'] != '')
											{
												$sRelays        =   $sResponse['relay'];  // Relay Devices.
												if(isset($sRelays[$relay_number]) && $sRelays[$relay_number] != '')
												{    
													$sPumps      .= $sRelays[$relay_number];
												}
												else
												{
													$aResponse['code']      = 5;
													$aResponse['status']    = $this->aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
													$aResponse['data']      = 'Device Number is not Valid';

													$this->webResponse($sformat, $aResponse);
												}
											}
											else
											{
												$aResponse['code']      = 5;
												$aResponse['status']    = $this->aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
												$aResponse['data']      = 'Devices not available.';

												$this->webResponse($sformat, $aResponse);
											}
										}
										else if($sPumpType == '12')
										{
											
											if($sResponse['powercenter'] != '')
											{
												$sPowercenter   =   $sResponse['powercenter']; // Power Center Devices.
												if(isset($sPowercenter[$relay_number]) && $sPowercenter[$relay_number] != '')
												{    
													$sPumps      .= $sPowercenter[$relay_number];
												}
												else
												{
													$aResponse['code']      = 5;
													$aResponse['status']    = $this->aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
													$aResponse['data']      = 'Device Number is not Valid';

													$this->webResponse($sformat, $aResponse);
												}
											}
											else
											{
												$aResponse['code']      = 5;
												$aResponse['status']    = $this->aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
												$aResponse['data']      = 'Device not available.';

												$this->webResponse($sformat, $aResponse);
											}
										}
									}
									else
									{
										if(preg_match('/Emulator/',$sPumpType) || preg_match('/Intellicom/',$sPumpType))
										{
											if($sResponse['pump_seq_'.$sPumpNumber.'_st'] > 0)
												$sPumps .= 1;
											else 
												$sPumps .= 0;
										}
									}
								}
								else
								{
									$aResponse['code']      = 5;
									$aResponse['status']    = $this->aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
									$aResponse['data']      = 'Pump devices not configured properly or Closure is set to 0.';

									// Return Response to browser. This will exit the script.
									$this->webResponse($sformat, $aResponse);
								}
							  }
							}
							else
							{
								if(isset($sResponse['pump_seq_'.$i.'_st']))
								{
									$sPumps .= '.';
								}
							}
						}
						$aResponse['code']      = 1;
						$aResponse['status']    = $this->aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
						$aResponse['data']      = $sPumps;
					
						$this->webResponse($sformat, $aResponse);
						
					}// END : If Device is PUMPS.
					else if($sDevice == "T")// START : If Device is PUMPS.
					{
						$sTemprature	= 	array();
						$sTemprature[0] = $sResponse['TS0'];
						$sTemprature[1] = $sResponse['TS1'];
						$sTemprature[2] = $sResponse['TS2'];
						$sTemprature[3] = $sResponse['TS3'];
						$sTemprature[4] = $sResponse['TS4'];
						$sTemprature[5] = $sResponse['TS5'];
						
						$aResponse['code']      = 1;
						$aResponse['status']    = $this->aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
						$aResponse['data']      = json_encode($sTemprature);
						
						$this->webResponse($sformat, $aResponse);
						
					}// END : If Device is PUMPS.
                } // END : If device type is not empty. if($sDevice != '')
                else
                {
                    $aResponse['code']      = 5;
                    $aResponse['status']    = $this->aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
                    $aResponse['data']      = 'Invalid Device Type.';

                    // Return Response to browser. This will exit the script.
                    $this->webResponse($sformat, $aResponse);
                }
            } // END : If Mode is Manual.
            /*else
            {
                $aResponse['code']      = 5;
                $aResponse['status']    = $this->aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
                $aResponse['data']      = 'Invalid mode to perform this operation.';

                // Return Response to browser. This will exit the script.
                $this->webResponse($sformat, $aResponse);
            }*/
            
         } // END : getDeviceStatus()
         
         public function getDeviceNumberStatus()
         {
             // Set default HTTP response of 'ok'
            $aResponse              =   array();
            $aResponse['code']      =   0;
            $aResponse['status']    =   404;
            $aResponse['data']      =   NULL;
            $sformat                =   isset($_REQUEST['format']) ? $_REQUEST['format'] : '' ; // Get response Format (json,xml,html etc.)
            $sAuth                  =   isset($_REQUEST['auth']) ? $_REQUEST['auth'] : '' ;// Check if Authentication is required.
            $this->isAuthenticationRequired =   $sAuth;
            
            // Optionally require connections to be made via HTTPS
            if( $this->isHTTPSRequired && $_SERVER['HTTPS'] != 'on' )
            {
                $aResponse['code']      = 2;
                $aResponse['status']    = $aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
                $aResponse['data']      = $aApiResponseCode[ $aResponse['code'] ]['Message'];

                // Return Response to browser. This will exit the script.
                $this->webResponse($sformat, $aResponse);
            }
            
            if($this->isAuthenticationRequired)
            {
                //START : Authorisation
                $sUsername       = isset($_REQUEST['username']) ? $_REQUEST['username'] : '' ;   // Get the username of webservice 
                $sPassword       = isset($_REQUEST['password']) ? $_REQUEST['password'] : '' ;   // Get the password of webservice 
                $this->webAuthorisation($sUsername, $sPassword,$sformat); // Check if username and password is valid.
                // END : Authorisation
            }
            
            #INPUTS
            $sDevice         = isset($_REQUEST['dvc']) ? $_REQUEST['dvc'] : '' ;  // Get the Device(ie. R=Relay,V=Valve,PC=Power Center)
            $sDeviceNo       = isset($_REQUEST['dn'])  ? $_REQUEST['dn'] : '' ;  // Get the Device No.
            
            $aResult            = array();
            $aResult['msg']     = "";
            $aResult['status']  = 0;
            $aResult['response']="0";
            $sValves            = ""; // Valve Devices Initialization.
            $sRelays            = "";  // Relay Devices Initialization.
            $sPowercenter       = ""; // Power Center Devices Initialization.
            
            $this->load->model('home_model');
            $iActiveMode =  $this->home_model->getActiveMode();
            
            //if($iActiveMode == 2) // START : If Mode is Manual.
            {
                if($sDevice != '' && $sDeviceNo != '') // START : If device type is not empty and Valid Device number is there.
                {
                    $sResponse      =   get_rlb_status(); // Get the relay borad response from server.
                    if($sDevice == "V") // START : If Device is Valve
                    {
                        if($sResponse['valves'] != '') // START : Checked if Valve Devices are available
                        {
                            $sValves        =   $sResponse['valves']; // Valve Devices.
                            if(isset($sValves[$sDeviceNo]) && $sValves[$sDeviceNo] != '')
                            {    
                                $aResponse['code']      = 1;
                                $aResponse['status']    = $this->aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
                                $aResponse['data']      = $sValves[$sDeviceNo];
                                
                                $this->webResponse($sformat, $aResponse);
                            }
                            else
                            {
                                $aResponse['code']      = 5;
                                $aResponse['status']    = $this->aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
                                $aResponse['data']      = 'Device Number is not Valid';
                                
                                $this->webResponse($sformat, $aResponse);
                            }
                        } // END : Checked if Valve Devices are available
                        else
                        {
                            $aResponse['code']      = 5;
                            $aResponse['status']    = $this->aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
                            $aResponse['data']      = 'Valve devices not available.';

                            $this->webResponse($sformat, $aResponse);
                        }
                    } // if($sDevice == "V") END : If Device is Valve
                    else if($sDevice == "R") // START : If Device is Relay.
                    {
                        if($sResponse['relay'] != '')
                        {
                            $sRelays        =   $sResponse['relay'];  // Relay Devices.
                            if(isset($sRelays[$sDeviceNo]) && $sRelays[$sDeviceNo] != '')
                            {    
                                $aResponse['code']      = 1;
                                $aResponse['status']    = $this->aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
                                $aResponse['data']      = $sRelays[$sDeviceNo];

                                $this->webResponse($sformat, $aResponse);
                            }
                            else
                            {
                                $aResponse['code']      = 5;
                                $aResponse['status']    = $this->aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
                                $aResponse['data']      = 'Device Number is not Valid';

                                $this->webResponse($sformat, $aResponse);
                            }
                        }
                        else
                        {
                            $aResponse['code']      = 5;
                            $aResponse['status']    = $this->aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
                            $aResponse['data']      = 'Relay devices not available.';

                            $this->webResponse($sformat, $aResponse);
                        }
                    } // END : If Device is Relay.
                    else if($sDevice == "PC") // START : If Device is Power Center.
                    {
                        if($sResponse['powercenter'] != '')
                        {
                            $sPowercenter   =   $sResponse['powercenter']; // Power Center Devices.
                            if(isset($sPowercenter[$sDeviceNo]) && $sPowercenter[$sDeviceNo] != '')
                            {    
                                $aResponse['code']      = 1;
                                $aResponse['status']    = $this->aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
                                $aResponse['data']      = $sPowercenter[$sDeviceNo];

                                $this->webResponse($sformat, $aResponse);
                            }
                            else
                            {
                                $aResponse['code']      = 5;
                                $aResponse['status']    = $this->aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
                                $aResponse['data']      = 'Device Number is not Valid';

                                $this->webResponse($sformat, $aResponse);
                            }
                        }
                        else
                        {
                            $aResponse['code']      = 5;
                            $aResponse['status']    = $this->aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
                            $aResponse['data']      = 'Power Center devices not available.';

                            $this->webResponse($sformat, $aResponse);
                        }
                    } // END : If Device is Power Center.
					else if($sDevice == "PS")// START : If Device is PUMPS.
					{
						$sPumps = '';
						$aPumpDetails = $this->home_model->getPumpDetails($sDeviceNo);
						//Variable Initialization to blank.
						$sPumpNumber  	= '';
						$sPumpType  	= '';
						$relay_number   = '';
						
						if(is_array($aPumpDetails) && !empty($aPumpDetails))
						{
						  foreach($aPumpDetails as $aResultEdit)
						  { 
							$sPumpNumber  = $aResultEdit->pump_number;
							$sPumpType    = $aResultEdit->pump_type;
							$relay_number = $aResultEdit->relay_number;
							$sPumpClosure = $aResultEdit->pump_closure;
							
							if($sPumpType != '' && $sPumpClosure == '1')
							{
								if($sPumpType == '12' || $sPumpType == '24')
								{
									if($sPumpType == '24')
									{
										if($sResponse['relay'] != '')
										{
											$sRelays        =   $sResponse['relay'];  // Relay Devices.
											if(isset($sRelays[$relay_number]) && $sRelays[$relay_number] != '')
											{    
												$sPumps      = $sRelays[$relay_number];
											}
											else
											{
												$aResponse['code']      = 5;
												$aResponse['status']    = $this->aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
												$aResponse['data']      = 'Device Number is not Valid';

												$this->webResponse($sformat, $aResponse);
											}
										}
										else
										{
											$aResponse['code']      = 5;
											$aResponse['status']    = $this->aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
											$aResponse['data']      = 'Devices not available.';

											$this->webResponse($sformat, $aResponse);
										}
									}
									else if($sPumpType == '12')
									{
										
										if($sResponse['powercenter'] != '')
										{
											$sPowercenter   =   $sResponse['powercenter']; // Power Center Devices.
											if(isset($sPowercenter[$relay_number]) && $sPowercenter[$relay_number] != '')
											{    
												$sPumps      = $sPowercenter[$relay_number];
											}
											else
											{
												$aResponse['code']      = 5;
												$aResponse['status']    = $this->aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
												$aResponse['data']      = 'Device Number is not Valid';

												$this->webResponse($sformat, $aResponse);
											}
										}
										else
										{
											$aResponse['code']      = 5;
											$aResponse['status']    = $this->aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
											$aResponse['data']      = 'Device not available.';

											$this->webResponse($sformat, $aResponse);
										}
									}
								}
								else
								{
									$sResponse['pump_seq_'.$sPumpNumber.'_st'];
									if($sResponse['pump_seq_'.$sPumpNumber.'_st'] > 0)
										$sPumps = 1;
									else if($sResponse['pump_seq_'.$sPumpNumber.'_st'] == 0)
										$sPumps = 0;
									
								}
							}
							else
							{
								$aResponse['code']      = 5;
								$aResponse['status']    = $this->aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
								$aResponse['data']      = 'Pump devices not configured properly or Closure is set to 0.';

								// Return Response to browser. This will exit the script.
								$this->webResponse($sformat, $aResponse);
							}
						  }
						}
						else
						{
							if(isset($sResponse['pump_seq_'.$sDeviceNo.'_st']))
							{
								$sPumps = '.';
							}
						}
						
						if($sPumps != '' || $sPumps == 0)
						{
							$aResponse['code']      = 1;
							$aResponse['status']    = $this->aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
							$aResponse['data']      = $sPumps;
							
							$this->webResponse($sformat, $aResponse);
						}
						else
						{
							$aResponse['code']      = 5;
                            $aResponse['status']    = $this->aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
                            $aResponse['data']      = 'Pump devices not available.';

                            $this->webResponse($sformat, $aResponse);
						}
					}// END : If Device is PUMPS.
					else if($sDevice == "T")// START : If Device is Temperature.
					{
						$sTemprature = '';
						if(isset($sResponse['TS'.$sDeviceNo]))
						{
							$sTemprature	= 	$sResponse['TS'.$sDeviceNo];
						}
						
						if($sTemprature != '')
						{
							$aResponse['code']      = 1;
							$aResponse['status']    = $this->aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
							$aResponse['data']      = $sTemprature;
							
							$this->webResponse($sformat, $aResponse);
						}
						else
						{
							$aResponse['code']      = 5;
                            $aResponse['status']    = $this->aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
                            $aResponse['data']      = 'Temperature devices not available.';

                            $this->webResponse($sformat, $aResponse);
						}
					}// END : If Device is Temperature.
                } // if($sDevice != '')  END : If device type is not empty and Valid Device number is there. 
                else
                {
                    $aResponse['code']      = 5;
                    $aResponse['status']    = $this->aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
                    $aResponse['data']      = 'Invalid Device Type or Device Number.';

                    $this->webResponse($sformat, $aResponse);
                    
                }
            } // END : If Mode is Manual.
            /*else
            {
                $aResponse['code']      = 5;
                $aResponse['status']    = $this->aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
                $aResponse['data']      = 'Invalid mode to perform this operation.';

                $this->webResponse($sformat, $aResponse);
            }*/
            
         } // END : function getDeviceNumberStatus()
         
         public function webAuthorisation($sUsername,$sPassword,$sFormat)
         {
             $aResponse             =   array();
             
             if( $sPassword == '' )
             {
                $aResponse['code'] = 3;
                $aResponse['status'] = $this->aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
                $aResponse['data'] = $this->aApiResponseCode[ $aResponse['code'] ]['Message'];

                // Return Response to browser
                $this->webResponse($sFormat, $aResponse);
             }
             if( $sPassword != 'bar' )
             {
                $aResponse['code'] = 4;
                $aResponse['status'] = $this->aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
                $aResponse['data'] = $this->aApiResponseCode[ $aResponse['code'] ]['Message'];

                // Return Response to browser
                $this->webResponse($sFormat, $aResponse);
             }
             
         }
         
        public function getActiveMode() //START : Function to get the active mode for web service.
         {
            // Set default HTTP response of 'ok'
            $aResponse              =   array();
            $aResponse['code']      =   0;
            $aResponse['status']    =   404;
            $aResponse['data']      =   NULL;
            $sformat                =   isset($_REQUEST['format']) ? $_REQUEST['format'] : '' ; // Get response Format (json,xml,html etc.)
            $sAuth                  =   isset($_REQUEST['auth']) ? $_REQUEST['auth'] : '' ;// Check if Authentication is required.
            $this->isAuthenticationRequired =   $sAuth;
            
            // Optionally require connections to be made via HTTPS
            if( $this->isHTTPSRequired && $_SERVER['HTTPS'] != 'on' )
            {
                $aResponse['code']      = 2;
                $aResponse['status']    = $aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
                $aResponse['data']      = $aApiResponseCode[ $aResponse['code'] ]['Message'];

                // Return Response to browser. This will exit the script.
                $this->webResponse($sformat, $aResponse);
            }
            
            if($this->isAuthenticationRequired)
            {
                //START : Authorisation
                $sUsername       = isset($_REQUEST['username']) ? $_REQUEST['username'] : '' ;   // Get the username of webservice 
                $sPassword       = isset($_REQUEST['password']) ? $_REQUEST['password'] : '' ;   // Get the password of webservice 
                $this->webAuthorisation($sUsername, $sPassword,$sformat); // Check if username and password is valid.
                // END : Authorisation
            }
             
            $aResult            = array();
            $aResult['msg']     = "";
            $aResult['response']= 0;
            $aResult['status']  = 0;
            
            
            $this->load->model('home_model');
            //Get the mode from Database.
            $iActiveMode =  $this->home_model->getActiveMode();
            
            if($iActiveMode != '')
            {
                $aResponse['code']      = 1;
                $aResponse['status']    = $this->aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
                $aResponse['data']      = $iActiveMode;
                // Return Response to browser. This will exit the script.
                $this->webResponse($sformat, $aResponse);
            }
            else
            {
                $aResponse['code']      = 5;
                $aResponse['status']    = $this->aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
                $aResponse['data']      = 'Invalid mode.';
                // Return Response to browser. This will exit the script.
                $this->webResponse($sformat, $aResponse);
            }
         } //END : Function to get the active mode for web service.
		 
		 public function changeActiveMode() //START : Function to change the active mode for web service.
         {
            // Set default HTTP response of 'ok'
            $aResponse              =   array();
            $aResponse['code']      =   0;
            $aResponse['status']    =   404;
            $aResponse['data']      =   NULL;
            $sformat                =   isset($_REQUEST['format']) ? $_REQUEST['format'] : '' ; // Get response Format (json,xml,html etc.)
            $sAuth                  =   isset($_REQUEST['auth']) ? $_REQUEST['auth'] : '' ;// Check if Authentication is required.
            $this->isAuthenticationRequired =   $sAuth;
			
			//INPUTS
			$iMode	=	trim($_REQUEST['md']);
            
            // Optionally require connections to be made via HTTPS
            if( $this->isHTTPSRequired && $_SERVER['HTTPS'] != 'on' )
            {
                $aResponse['code']      = 2;
                $aResponse['status']    = $aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
                $aResponse['data']      = $aApiResponseCode[ $aResponse['code'] ]['Message'];

                // Return Response to browser. This will exit the script.
                $this->webResponse($sformat, $aResponse);
            }
            
            if($this->isAuthenticationRequired)
            {
                //START : Authorisation
                $sUsername       = isset($_REQUEST['username']) ? $_REQUEST['username'] : '' ;   // Get the username of webservice 
                $sPassword       = isset($_REQUEST['password']) ? $_REQUEST['password'] : '' ;   // Get the password of webservice 
                $this->webAuthorisation($sUsername, $sPassword,$sformat); // Check if username and password is valid.
                // END : Authorisation
            }
             
            $aResult            = array();
            $aResult['msg']     = "";
            $aResult['response']= 0;
            $aResult['status']  = 0;
            
            
            $this->load->model('home_model');
            //Get the mode from Database.
            $iActiveMode =  $this->home_model->getActiveMode();
            
            if($iMode != '')
            {
				if($iMode != $iActiveMode)
				{
					$this->home_model->updateMode($iMode);

					$sResponse      =   get_rlb_status();
					$sValves        =   $sResponse['valves'];
					$sRelays        =   $sResponse['relay'];
					$sPowercenter   =   $sResponse['powercenter'];

					if($iMode == 3 || $iMode == 1)
					{ //1-auto, 2-manual, 3-timeout
						//off all relays
						if($sRelays != '')
						{
							$sRelayNewResp = str_replace('1','0',$sRelays);
							//onoff_rlb_relay($sRelayNewResp);
						}
						
						//off all valves
						if($sValves != '')
						{
							$sValveNewResp = str_replace(array('1','2'), '0', $sValves);
							//onoff_rlb_valve($sValveNewResp);  
						}
						
						//off all power center
						if($sPowercenter != '')
						{
							$sPowerNewResp = str_replace('1','0',$sPowercenter);  
							//onoff_rlb_powercenter($sPowerNewResp); 
						}

					}
					
					$aResponse['code']      = 1;
					$aResponse['status']    = $this->aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
					$aResponse['data']      = $iMode;
					// Return Response to browser. This will exit the script.
					$this->webResponse($sformat, $aResponse);
				}
				else
				{
					$aResponse['code']      = 1;
					$aResponse['status']    = $this->aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
					$aResponse['data']      = 'Mode already activated!';
					// Return Response to browser. This will exit the script.
					$this->webResponse($sformat, $aResponse);
				}
            }
            else
            {
                $aResponse['code']      = 5;
                $aResponse['status']    = $this->aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
                $aResponse['data']      = 'Please enter Valid mode.';
                // Return Response to browser. This will exit the script.
                $this->webResponse($sformat, $aResponse);
            }
         } //END : Function to get the active mode for web service.
         
         public function webResponse($sformat, $aApiResponse)
         {
           // Define HTTP responses
            $http_response_code = array(
                                        200 => 'OK',
                                        400 => 'Bad Request',
                                        401 => 'Unauthorized',
                                        403 => 'Forbidden',
                                        404 => 'Not Found'
                                       );

            // Set HTTP Response
            header('HTTP/1.1 '.$aApiResponse['status'].' '.$http_response_code[ $aApiResponse['status'] ]);

            // Process different content types
            if( strcasecmp($sformat,'json') == 0 )
            {
                // Set HTTP Response Content Type
                header('Content-Type: application/json; charset=utf-8');

                // Format data into a JSON response
                $json_response = json_encode($aApiResponse);

                // Deliver formatted data
                echo $json_response;

            }
            elseif( strcasecmp($sformat,'xml') == 0 )
            {
                // Set HTTP Response Content Type
                header('Content-Type: application/xml; charset=utf-8');

                // Format data into an XML response (This is only good at handling string data, not arrays)
                $xml_response = '<?xml version="1.0" encoding="UTF-8"?>'."\n".
                    '<response>'."\n".
                    "\t".'<code>'.$aApiResponse['code'].'</code>'."\n".
                    "\t".'<data>'.$aApiResponse['data'].'</data>'."\n".
                    '</response>';

                // Deliver formatted data
                echo $xml_response;
            }
            else
            {
                // Set HTTP Response Content Type (This is only good at handling string data, not arrays)
                header('Content-Type: text/html; charset=utf-8');

                // Deliver formatted data
                echo $aApiResponse['data'];

            }

            // End script process
            exit;
        }
		
		function saveProgramWeb()
		{
			// Set default HTTP response of 'ok'
            $aResponse              =   array();
            $aResponse['code']      =   0;
            $aResponse['status']    =   404;
            $aResponse['data']      =   NULL;
            $sformat                =   isset($_REQUEST['format']) ? $_REQUEST['format'] : '' ; // Get response Format (json,xml,html etc.)
            $sAuth                  =   isset($_REQUEST['auth']) ? $_REQUEST['auth'] : '' ;// Check if Authentication is required.
            $this->isAuthenticationRequired =   $sAuth;
            
            // Optionally require connections to be made via HTTPS
            if( $this->isHTTPSRequired && $_SERVER['HTTPS'] != 'on' )
            {
                $aResponse['code']      = 2;
                $aResponse['status']    = $aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
                $aResponse['data']      = $aApiResponseCode[ $aResponse['code'] ]['Message'];

                // Return Response to browser. This will exit the script.
                $this->webResponse($sformat, $aResponse);
            }
            
            if($this->isAuthenticationRequired)
            {
                //START : Authorisation
                $sUsername       = isset($_REQUEST['username']) ? $_REQUEST['username'] : '' ;   // Get the username of webservice 
                $sPassword       = isset($_REQUEST['password']) ? $_REQUEST['password'] : '' ;   // Get the password of webservice 
                $this->webAuthorisation($sUsername, $sPassword,$sformat); // Check if username and password is valid.
                // END : Authorisation
            }
             
            $aResult            = array();
            $aResult['msg']     = "";
            $aResult['response']= 0;
            $aResult['status']  = 0;
                       
            $this->load->model('home_model');
			
			$sProgramName 		= trim($_REQUEST['sProgramName']);
			$sRelayNumber 		= trim($_REQUEST['sRelayNumber']);
			$sProgramType 		= trim($_REQUEST['sProgramType']);
			if($sProgramType == 2)
			$sProgramDays 		= explode(",",trim($_REQUEST['sProgramDays']));
			else
			$sProgramDays 		= 0;	
		
			$sStartTime 		= trim($_REQUEST['sStartTime']);
			$sEndTime		 	= trim($_REQUEST['sEndTime']);
			$isAbsoluteProgram 	= trim($_REQUEST['isAbsoluteProgram']);
			$sType				= trim($_REQUEST['type']);
			
			
			$sErrorMsg			=	'';
			
			if($sProgramName == '')
			{
				$sErrorMsg			.=	'Please enter Program Name.<br />';
			}
			if($sRelayNumber == '')
			{
				$sErrorMsg			.=	'Please enter Device Number.<br />';
			}
			if($sProgramType == '')
			{
				$sErrorMsg			.=	'Please select Program Type.<br />';
			}
			if($sProgramType == '2')
			{
				if(empty($sProgramDays))
				{
					$sErrorMsg			.=	'Please select Program Days.<br />';
				}
			}
			if($sStartTime == '')
			{
				$sErrorMsg			.=	'Please select Program Start Time.<br />';
			}
			if($sEndTime == '')
			{
				$sErrorMsg			.=	'Please select Program End Time.<br />';
			}
			if($isAbsoluteProgram == '')
			{
				$sErrorMsg			.=	'Please select Program Absolute.<br />';
			}
			if($sType == '')
			{
				$sErrorMsg			.=	'Please enter Program Device Type.<br />';
			}
			
			if($sErrorMsg != '')
			{
				$aResponse['code']      = 5;
				$aResponse['status']    = $this->aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
				$aResponse['data']      = $sErrorMsg;

				$this->webResponse($sformat, $aResponse);
				exit;
			}
			
			$startTime		=  $sStartTime.':00';	
			$endTime		=  $sEndTime.':00';		
			
			
			//START : CHECK if program time is already assined to another program.
				$sProgramDetails	=	$this->home_model->getProgramDetailsForDevice($sRelayNumber,$sType);
				$alreadyExists		=	0;
				if(is_array($sProgramDetails) && !empty($sProgramDetails))
				{
					$cntDevicePrograms  = count($sProgramDetails);
					$aAllDays           = array( 1 => 'Monday', 2 => 'Tuesday', 3 => 'Wednesday', 4 => 'Thursday', 5 => 'Friday', 6 => 'Saturday', 7 => 'Sunday');
					foreach($sProgramDetails as $aResult)
					{
						if($sProgramType == '1')
						{
							if($startTime >= $aResult->start_time && $startTime <= $aResult->end_time)
							{
								$alreadyExists = 1;
								break;
							}
							else if($endTime >= $aResult->start_time && $endTime <= $aResult->end_time)
							{
								$alreadyExists = 1;
								break;
							}
							else if($startTime < $aResult->start_time && $endTime > $aResult->end_time)
							{
								$alreadyExists = 1;
								break;
							}
						}
						else if($sProgramType == '2')
						{
							$checkDaysExists	=	0;
							$existDays = explode(',',$aResult->program_days);
							if(!empty($sProgramDays))
							{
								foreach($sProgramDays as $days)
								{
									if(in_array($days,$existDays))
									{
										$checkDaysExists = 1;
										break;
									}
								}
								
								if($checkDaysExists == 1)
								{
									if($startTime >= $aResult->start_time && $startTime <= $aResult->end_time)
									{
										$alreadyExists = 1;
										break;
									}
									else if($endTime >= $aResult->start_time && $endTime <= $aResult->end_time)
									{
										$alreadyExists = 1;
										break;
									}
									else if($startTime < $aResult->start_time && $endTime > $aResult->end_time)
									{
										$alreadyExists = 1;
										break;
									}
								}
							}
							
						}
					}
				}
			//END : CHECK if program time is already assined to another program.
			if($alreadyExists == '1')
			{
				$aResponse['code']      = 5;
				$aResponse['status']    = $this->aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
				$aResponse['data']      = 'Selected Time is already assigned to other program!';

				$this->webResponse($sformat, $aResponse);
			}
			else
			{
				$aPost				= array('sProgramName'=>$sProgramName,
											'sProgramType'=>$sProgramType,
											'sProgramDays'=>$sProgramDays,
											'sStartTime'=>$sStartTime,
											'sEndTime'=>$sEndTime,
											'isAbsoluteProgram'=>$isAbsoluteProgram);
				
				$id =	$this->home_model->saveProgramDetails($aPost,$sRelayNumber,$sType);
				
				$aResponse['code']      = 1;
                $aResponse['status']    = $this->aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
                $aResponse['data']      = $id;
                // Return Response to browser. This will exit the script.
                $this->webResponse($sformat, $aResponse);
			}
            
		}
		
		function getAllProgramDetails()
		{
			// Set default HTTP response of 'ok'
            $aResponse              =   array();
            $aResponse['code']      =   0;
            $aResponse['status']    =   404;
            $aResponse['data']      =   NULL;
            $sformat                =   isset($_REQUEST['format']) ? $_REQUEST['format'] : '' ; // Get response Format (json,xml,html etc.)
            $sAuth                  =   isset($_REQUEST['auth']) ? $_REQUEST['auth'] : '' ;// Check if Authentication is required.
            $this->isAuthenticationRequired =   $sAuth;
            
            // Optionally require connections to be made via HTTPS
            if( $this->isHTTPSRequired && $_SERVER['HTTPS'] != 'on' )
            {
                $aResponse['code']      = 2;
                $aResponse['status']    = $aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
                $aResponse['data']      = $aApiResponseCode[ $aResponse['code'] ]['Message'];

                // Return Response to browser. This will exit the script.
                $this->webResponse($sformat, $aResponse);
            }
            
			$sRelayNumber 		= trim($_REQUEST['sRelayNumber']);
			$sType				= trim($_REQUEST['type']);
			
			if($this->isAuthenticationRequired)
            {
                //START : Authorisation
                $sUsername       = isset($_REQUEST['username']) ? $_REQUEST['username'] : '' ;   // Get the username of webservice 
                $sPassword       = isset($_REQUEST['password']) ? $_REQUEST['password'] : '' ;   // Get the password of webservice 
                $this->webAuthorisation($sUsername, $sPassword,$sformat); // Check if username and password is valid.
                // END : Authorisation
            }
			
			if($sRelayNumber == '')
			{
				$aResponse['code']      = 5;
				$aResponse['status']    = $this->aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
				$aResponse['data']      = 'Please enter valid Device number!';

				$this->webResponse($sformat, $aResponse);
			}
			if($sType == '')
			{
				$aResponse['code']      = 5;
				$aResponse['status']    = $this->aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
				$aResponse['data']      = 'Please enter valid Program type!';

				$this->webResponse($sformat, $aResponse);
			}
             
            $aResult            = array();
            $aResult['msg']     = "";
            $aResult['response']= 0;
            $aResult['status']  = 0;
                       
            $this->load->model('home_model');
			
			$sDetails = $this->home_model->getProgramDetailsForDevice($sRelayNumber,$sType);
			
			if(!empty($sDetails))
			{
				$aResponse['code']      = 1;
				$aResponse['status']    = $this->aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
				$aResponse['data']      = json_encode($sDetails);
				// Return Response to browser. This will exit the script.
				$this->webResponse($sformat, $aResponse);		
			}
			else
			{
				$aResponse['code']      = 5;
				$aResponse['status']    = $this->aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
				$aResponse['data']      = 'No Program Available!';

				$this->webResponse($sformat, $aResponse);
			}
			
		}
		
		
		function updateProgramDetails()
		{
			// Set default HTTP response of 'ok'
            $aResponse              =   array();
            $aResponse['code']      =   0;
            $aResponse['status']    =   404;
            $aResponse['data']      =   NULL;
            $sformat                =   isset($_REQUEST['format']) ? $_REQUEST['format'] : '' ; // Get response Format (json,xml,html etc.)
            $sAuth                  =   isset($_REQUEST['auth']) ? $_REQUEST['auth'] : '' ;// Check if Authentication is required.
            $this->isAuthenticationRequired =   $sAuth;
            
            // Optionally require connections to be made via HTTPS
            if( $this->isHTTPSRequired && $_SERVER['HTTPS'] != 'on' )
            {
                $aResponse['code']      = 2;
                $aResponse['status']    = $aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
                $aResponse['data']      = $aApiResponseCode[ $aResponse['code'] ]['Message'];

                // Return Response to browser. This will exit the script.
                $this->webResponse($sformat, $aResponse);
            }
            
			if($this->isAuthenticationRequired)
            {
                //START : Authorisation
                $sUsername       = isset($_REQUEST['username']) ? $_REQUEST['username'] : '' ;   // Get the username of webservice 
                $sPassword       = isset($_REQUEST['password']) ? $_REQUEST['password'] : '' ;   // Get the password of webservice 
                $this->webAuthorisation($sUsername, $sPassword,$sformat); // Check if username and password is valid.
                // END : Authorisation
            }
			
			$aResult            = array();
            $aResult['msg']     = "";
            $aResult['response']= 0;
            $aResult['status']  = 0;
			
			$sProgramID 		= trim($_REQUEST['sProgramID']);
			$sProgramName 		= trim($_REQUEST['sProgramName']);
			$sRelayNumber 		= trim($_REQUEST['sRelayNumber']);
			$sProgramType 		= trim($_REQUEST['sProgramType']);
			if($sProgramType == 2)
			$sProgramDays 		= explode(",",trim($_REQUEST['sProgramDays']));
			else
			$sProgramDays 		= 0;	
		
			$sStartTime 		= trim($_REQUEST['sStartTime']);
			$sEndTime		 	= trim($_REQUEST['sEndTime']);
			$isAbsoluteProgram 	= trim($_REQUEST['isAbsoluteProgram']);
			$sType				= trim($_REQUEST['type']);
						
			$sErrorMsg			=	'';
			
			if($sProgramID == '')
			{
				$sErrorMsg			.=	'Please enter Program ID.<br />';
			}
			if($sProgramName == '')
			{
				$sErrorMsg			.=	'Please enter Program Name.<br />';
			}
			if($sRelayNumber == '')
			{
				$sErrorMsg			.=	'Please enter Device Number.<br />';
			}
			if($sProgramType == '')
			{
				$sErrorMsg			.=	'Please select Program Type.<br />';
			}
			if($sProgramType == '2')
			{
				if(empty($sProgramDays))
				{
					$sErrorMsg			.=	'Please select Program Days.<br />';
				}
			}
			if($sStartTime == '')
			{
				$sErrorMsg			.=	'Please select Program Start Time.<br />';
			}
			if($sEndTime == '')
			{
				$sErrorMsg			.=	'Please select Program End Time.<br />';
			}
			if($isAbsoluteProgram == '')
			{
				$sErrorMsg			.=	'Please select Program Absolute.<br />';
			}
			if($sType == '')
			{
				$sErrorMsg			.=	'Please enter Program Device Type.<br />';
			}
			
			if($sErrorMsg != '')
			{
				$aResponse['code']      = 5;
				$aResponse['status']    = $this->aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
				$aResponse['data']      = $sErrorMsg;

				$this->webResponse($sformat, $aResponse);
				exit;
			}
			
			$startTime		=  $sStartTime.':00';	
			$endTime		=  $sEndTime.':00';
			
			//START : CHECK if program time is already assined to another program.
				$sProgramDetails	=	$this->home_model->getProgramDetailsForDevice($sRelayNumber,$sType);
				$alreadyExists		=	0;
				if(is_array($sProgramDetails) && !empty($sProgramDetails))
				{
					$cntDevicePrograms  = count($sProgramDetails);
					$aAllDays           = array( 1 => 'Monday', 2 => 'Tuesday', 3 => 'Wednesday', 4 => 'Thursday', 5 => 'Friday', 6 => 'Saturday', 7 => 'Sunday');
					foreach($sProgramDetails as $aResult)
					{
						if($sProgramType == '1')
						{
							if($startTime >= $aResult->start_time && $startTime <= $aResult->end_time)
							{
								$alreadyExists = 1;
								break;
							}
							else if($endTime >= $aResult->start_time && $endTime <= $aResult->end_time)
							{
								$alreadyExists = 1;
								break;
							}
							else if($startTime < $aResult->start_time && $endTime > $aResult->end_time)
							{
								$alreadyExists = 1;
								break;
							}
						}
						else if($sProgramType == '2')
						{
							$checkDaysExists	=	0;
							$existDays = explode(',',$aResult->program_days);
							if(!empty($sProgramDays))
							{
								foreach($sProgramDays as $days)
								{
									if(in_array($days,$existDays))
									{
										$checkDaysExists = 1;
										break;
									}
								}
								
								if($checkDaysExists == 1)
								{
									if($startTime >= $aResult->start_time && $startTime <= $aResult->end_time)
									{
										$alreadyExists = 1;
										break;
									}
									else if($endTime >= $aResult->start_time && $endTime <= $aResult->end_time)
									{
										$alreadyExists = 1;
										break;
									}
									else if($startTime < $aResult->start_time && $endTime > $aResult->end_time)
									{
										$alreadyExists = 1;
										break;
									}
								}
							}
							
						}
					}
				}
			//END : CHECK if program time is already assined to another program.
			if($alreadyExists == '1')
			{
				$aResponse['code']      = 5;
				$aResponse['status']    = $this->aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
				$aResponse['data']      = 'Selected Time is already assigned to other program!';

				$this->webResponse($sformat, $aResponse);
			}
			else
			{
				$aPost				= array('sProgramName'=>$sProgramName,
											'sProgramType'=>$sProgramType,
											'sProgramDays'=>$sProgramDays,
											'sStartTime'=>$sStartTime,
											'sEndTime'=>$sEndTime,
											'isAbsoluteProgram'=>$isAbsoluteProgram);
				
				$this->home_model->updateProgramDetails($aPost,$sProgramID,$sRelayNumber,$sType);
				
				$aResponse['code']      = 1;
                $aResponse['status']    = $this->aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
                $aResponse['data']      = 'Program Details Updated Succesfully!';
                // Return Response to browser. This will exit the script.
                $this->webResponse($sformat, $aResponse);
			}
			
			
			
			
                       
		}
		
		function deleteProgram()
		{
			// Set default HTTP response of 'ok'
            $aResponse              =   array();
            $aResponse['code']      =   0;
            $aResponse['status']    =   404;
            $aResponse['data']      =   NULL;
            $sformat                =   isset($_REQUEST['format']) ? $_REQUEST['format'] : '' ; // Get response Format (json,xml,html etc.)
            $sAuth                  =   isset($_REQUEST['auth']) ? $_REQUEST['auth'] : '' ;// Check if Authentication is required.
            $this->isAuthenticationRequired =   $sAuth;
            
            // Optionally require connections to be made via HTTPS
            if( $this->isHTTPSRequired && $_SERVER['HTTPS'] != 'on' )
            {
                $aResponse['code']      = 2;
                $aResponse['status']    = $aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
                $aResponse['data']      = $aApiResponseCode[ $aResponse['code'] ]['Message'];

                // Return Response to browser. This will exit the script.
                $this->webResponse($sformat, $aResponse);
            }
            
			$sProgramID 		= trim($_REQUEST['sProgramID']);
			
			if($this->isAuthenticationRequired)
            {
                //START : Authorisation
                $sUsername       = isset($_REQUEST['username']) ? $_REQUEST['username'] : '' ;   // Get the username of webservice 
                $sPassword       = isset($_REQUEST['password']) ? $_REQUEST['password'] : '' ;   // Get the password of webservice 
                $this->webAuthorisation($sUsername, $sPassword,$sformat); // Check if username and password is valid.
                // END : Authorisation
            }
			
			if($sProgramID == '')
			{
				$aResponse['code']      = 5;
				$aResponse['status']    = $this->aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
				$aResponse['data']      = 'Please enter valid Program ID!';

				$this->webResponse($sformat, $aResponse);
			}
		 
            $aResult            = array();
            $aResult['msg']     = "";
            $aResult['response']= 0;
            $aResult['status']  = 0;
                       
            $this->load->model('home_model');
			
			$sDetails = $this->home_model->deleteProgramDetails($sProgramID);
			
			$aResponse['code']      = 1;
			$aResponse['status']    = $this->aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
			$aResponse['data']      = "Program Deleted Succesfully!";
			// Return Response to browser. This will exit the script.
			$this->webResponse($sformat, $aResponse);		
			
		}
		
		
		function getParticularProgramDetails()
		{
			// Set default HTTP response of 'ok'
            $aResponse              =   array();
            $aResponse['code']      =   0;
            $aResponse['status']    =   404;
            $aResponse['data']      =   NULL;
            $sformat                =   isset($_REQUEST['format']) ? $_REQUEST['format'] : '' ; // Get response Format (json,xml,html etc.)
            $sAuth                  =   isset($_REQUEST['auth']) ? $_REQUEST['auth'] : '' ;// Check if Authentication is required.
            $this->isAuthenticationRequired =   $sAuth;
            
            // Optionally require connections to be made via HTTPS
            if( $this->isHTTPSRequired && $_SERVER['HTTPS'] != 'on' )
            {
                $aResponse['code']      = 2;
                $aResponse['status']    = $aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
                $aResponse['data']      = $aApiResponseCode[ $aResponse['code'] ]['Message'];

                // Return Response to browser. This will exit the script.
                $this->webResponse($sformat, $aResponse);
            }
            
			$sProgramID 		= trim($_REQUEST['sProgramID']);
			
			if($this->isAuthenticationRequired)
            {
                //START : Authorisation
                $sUsername       = isset($_REQUEST['username']) ? $_REQUEST['username'] : '' ;   // Get the username of webservice 
                $sPassword       = isset($_REQUEST['password']) ? $_REQUEST['password'] : '' ;   // Get the password of webservice 
                $this->webAuthorisation($sUsername, $sPassword,$sformat); // Check if username and password is valid.
                // END : Authorisation
            }
			
			if($sProgramID == '')
			{
				$aResponse['code']      = 5;
				$aResponse['status']    = $this->aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
				$aResponse['data']      = 'Please enter valid Program ID!';

				$this->webResponse($sformat, $aResponse);
			}
		 
            $aResult            = array();
            $aResult['msg']     = "";
            $aResult['response']= 0;
            $aResult['status']  = 0;
                       
            $this->load->model('home_model');
			
			$sDetails = $this->home_model->getProgramDetails($sProgramID);
			
			if(!empty($sDetails))
			{
				$aResponse['code']      = 1;
				$aResponse['status']    = $this->aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
				$aResponse['data']      = "Program Deleted Succesfully!";
				// Return Response to browser. This will exit the script.
				$this->webResponse($sformat, $aResponse);		
			}
			else
			{
				$aResponse['code']      = 5;
				$aResponse['status']    = $this->aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
				$aResponse['data']      = 'Details Not available for the Program!';

				$this->webResponse($sformat, $aResponse);
			}
		}
		
		
        
    } //END : Class Service
    
    /* End of file web.php */
    /* Location: ./application/controllers/web.php */
?>
