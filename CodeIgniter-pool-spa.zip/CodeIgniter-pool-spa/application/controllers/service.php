<?php
    /**
    * @Programmer: Dhiraj S.
    * @Created: 21 July 2015
    * @Modified: 
    * @Description: Webservice to on/off Devices and Get status of Devices.
    **/
    
    if (!defined('BASEPATH'))
        exit('No direct script access allowed');
    
    class Service extends CI_Controller
    {
        public function __construct() 
        {
            parent::__construct(); // Parent Contructor Call
            $this->load->helper('common_functions'); // Loaded helper : To get all functions accessible from common_functions file.
            
        } // END : function __construct()
        
        public function changeDeviceStatus()
        {
            echo 'HERE';
            die;
            #INPUTS
            $sDevice         = isset($_REQUEST['dvc']) ? $_REQUEST['dvc'] : '' ; // Get the Device(ie. R=Relay,V=Valve,PC=Power Center)
            $sDeviceNo       = isset($_REQUEST['rn'])  ? $_REQUEST['rn'] : '' ;  // Get the Device No.
            $iDeviceStatus   = isset($_REQUEST['rs']) ? $_REQUEST['rs'] : '' ;   // Get the status to which Device will be changed         
            
            $aResult            = array();
            $aResult['msg']     = "";
            $aResult['status']  = 0;
            $aDeviceStatus      = array('0', '1', '2'); //respective values of status.
            
            $this->load->model('home_model');
            $iActiveMode =  $this->home_model->getActiveMode();
            
            if($iActiveMode == 2) // START : If Mode is Manual.
            {
                if($sDeviceNo != '' && in_array($iDeviceStatus, $aDeviceStatus) && $sDevice != '') 
                {
                    $sResponse      =   get_rlb_status(); // Get the relay borad response from server.
                    $sValves        =   $sResponse['valves']; // Valve Devices.
                    $sRelays        =   $sResponse['relay'];  // Relay Devices.
                    $sPowercenter   =   $sResponse['powercenter']; // Power Center Devices.
                    $sRelayNewResp  =   '';
                    
                    if($sDevice == 'R' && $sRelays != '') // START : If Device is Relay.
                    {
                        $iRelayCount    = strlen($sRelays); // Count of Relay Devices.
                        if( $sDeviceNo > ($iRelayCount-1) || $sDeviceNo < 0)
                        {
                                $aResult['msg'] = "Invalid relay number.";
                        } // END : if( $sDeviceNo > ($iRelayCount-1) || $sDeviceNo < 0)
                        else
                        {
                                $sRelayNewResp = replace_return($sRelays, $iDeviceStatus, $sDeviceNo ); // Change the status with the sent status for the device no.
                                onoff_rlb_relay($sRelayNewResp); // Send the request to change the status on server.		
                                $aResult['status'] = 1;
                        } // END : else of if( $sDeviceNo > ($iRelayCount-1) || $sDeviceNo < 0)
                        
                    } // END : if($sDevice == 'R')
                    
                    if($sDevice == 'PC' && $sPowercenter != '') // START : If Device is Power Center.
                    {
                        $iPowerCenterCount    = strlen($sPowercenter); // Count of Power Center Devices.
                        if( $sDeviceNo > ($iPowerCenterCount-1) || $sDeviceNo < 0)
                        {
                                $aResult['msg'] = "Invalid Power Center number.";
                        } // END : if( $sDeviceNo > ($iPowerCenterCount-1) || $sDeviceNo < 0)
                        else
                        {
                                $sRelayNewResp = replace_return($sPowercenter, $iDeviceStatus, $sDeviceNo ); // Change the status with the sent status for the device no.
                                onoff_rlb_powercenter($sRelayNewResp); // Send the request to change the status on server.		
                                $aResult['status'] = 1;
                        } // END : else of if( $sDeviceNo > ($iPowerCenterCount-1) || $sDeviceNo < 0)
                        
                    } // END : if($sDevice == 'PC')
                    
                    
                    
                } // END : if($sDeviceNo != '' && in_array($iDeviceStatus, $aDeviceStatus) && $sDevice != '')
                else
                    $aResult['msg'] = "Invalid Device number Or Device status OR Device Type.";
            } // END : if($iActiveMode == 2)
            else
                $aResult['msg'] = "Invalid mode to perform this operation.";
            
            #OUTPUT
            echo json_encode($aResult);
            
        } //END : function changeDeviceStatus()
        
    } //END : Class Service
    
    /* End of file service.php */
    /* Location: ./application/controllers/service.php */
?>
