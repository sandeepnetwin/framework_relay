<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Access_model extends CI_Model 
{
    public function __construct() 
    {
        parent::__construct();
    }
	
	public function changePermission($userID,$moduleID,$sPermission)
	{
		$sqlCheck	=	"SELECT id FROM rlb_access_permissions WHERE user_id =".$userID." AND module_id =".$moduleID;
		$query      =   $this->db->query($sqlCheck);
       
        if ($query->num_rows() > 0)
        {
            foreach($query->result() as $rowResult)
			{
				$sqlUpdate	=	"UPDATE rlb_access_permissions SET access ='".$sPermission."', modified_date ='".date('Y-m-d H:i:s')."' WHERE id =".$rowResult->id;
				$this->db->query($sqlUpdate);
			}
        }
		else
		{
			$sqlInsert	=	"INSERT INTO rlb_access_permissions(user_id,module_id,access,modified_date) VALUES('".$userID."','".$moduleID."','".$sPermission."','".date('Y-m-d H:i:s')."')";
			$this->db->query($sqlInsert);
		}
	}
	
	public function getPermissionForModule($userID,$moduleID)
	{
		$sAccess	=	'';
		$sqlCheck	=	"SELECT id,access FROM rlb_access_permissions WHERE user_id =".$userID." AND module_id =".$moduleID;
		$query      =   $this->db->query($sqlCheck);
       
        if ($query->num_rows() > 0)
        {
            foreach($query->result() as $rowResult)
			{
				$sAccess	=	$rowResult->access;
			}
        }
		
		return $sAccess;
	}
	
	function getPermission($userID)
	{
		$sqlGetPermission	=	"SELECT module_id,access FROM rlb_access_permissions WHERE user_id = '".$userID."' and (access = '1' OR access = '2')";
		$query      =   $this->db->query($sqlGetPermission);
       
        if ($query->num_rows() > 0)
        {
            return $query->result();
        }
		
		return '';
	}
	
    
}

/* End of file access_model.php */
/* Location: ./application/models/access_model.php */