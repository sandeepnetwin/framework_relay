<?php
$this->load->view('Header');

$sModuleID			= '';
$sModuleName		= '';
$sModuleActive 		= '';

if(!empty($moduleDetails))
{
	foreach($moduleDetails as $Module)
	{
		$sModuleID		= $Module->id;
		$sModuleName	= $Module->module_name;
		$sModuleActive 	= $Module->module_active;
	}
}

$sButtonText	=	'';
if($sModuleID == '')
	$sButtonText = 'Save Module';
else if($sModuleID != '')
	$sButtonText = 'Update Module';

?>
    <div id="page-wrapper">
        <div class="row">
          <div class="col-lg-12">
            <ol class="breadcrumb">
              <li><a href="<?php echo base_url('dashboard/module'); ?>"><i class="icon-dashboard"></i>All Modules</a></li>
			  <li class="active"><i class="icon-file-alt"></i> Add/Edit Module</li>
			  
            </ol>
          </div>
        </div><!-- /.row -->
        <div class="row">
          <div class="col-lg-12">
            <div class="panel panel-primary">
              <div class="panel-heading">
                <h3 class="panel-title">Add/Edit Page</h3>
              </div>
              <div class="panel-body">
                <div id="morris-chart-area">
                  <form action="<?php echo site_url('dashboard/moduleAddEdit');?>" method="post">
				  <input type="hidden" name="moduleID" value="<?php echo $sModuleID;?>">
                    <table border="0" cellspacing="0" cellpadding="0" width="100%">
                      <tr>
                        <td width="24%"><strong>Name:</strong></td>
                        <td width="1%">&nbsp;</td>
                        <td width="75%"><input type="text" class="form-control" placeholder="Enter Module Name" name="sModuleName" value="<?php echo $sModuleName;?>" id="sModuleName" required></td>
                      </tr>
                      <tr><td colspan="3">&nbsp;</td></tr>
                      <tr>
                        <td width="10%"><strong>Active:</strong></td>
                        <td width="1%">&nbsp;</td>
                        <td width="89%"><input type="radio" name="sModuleActive" value="0" <?php if($sModuleActive == '0'|| $sModuleActive == ''){echo 'checked="checked"';} ?> checked="checked">&nbsp;No&nbsp;&nbsp;&nbsp;&nbsp;<input type="radio" <?php if($sModuleActive == '1'){echo 'checked="checked"';} ?> name="sModuleActive" value="1">&nbsp;Yes</td>
                      </tr>
                      <tr><td colspan="3">&nbsp;</td></tr>
                      <tr><td colspan="3"><input type="submit" name="command" value="<?php echo $sButtonText;?>" class="btn btn-success" onclick="return checkForm();"></td></tr>
                      
                    </table>
                  </form>
                </div>
              </div>
            </div>
          </div>
        </div><!-- /.row -->
      </div><!-- /#page-wrapper -->
<script type="text/javascript">
$(document).ready(function (){
	
});
  function checkForm()
  {
	return true;
  }
</script>
<hr>
<?php
$this->load->view('Footer');
?>