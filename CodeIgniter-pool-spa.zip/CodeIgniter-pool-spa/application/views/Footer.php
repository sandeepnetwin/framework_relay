     <footer>
     <p>&nbsp; &copy; <?php echo date('Y') ?> Crystal Properties & Investments, Inc. All rights reserved. </p>
      </footer>
     
    <!-- Placed at the end of the document so the pages load faster -->
    </div><!-- /#wrapper -->
    <script src="<?php echo HTTP_JS_PATH; ?>tablesorter/jquery.tablesorter.js"></script>
    <script src="<?php echo HTTP_JS_PATH; ?>tablesorter/tables.js"></script>
    
  </body>
</html>