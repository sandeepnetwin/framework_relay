<html>
 <head>
  <script src="<?php echo HTTP_JS_PATH; ?>jquery-1.10.2.js"></script>
<script type="text/javascript">
$( document ).ready(function() {
$( "#submit" ).trigger( "click" );
});
</script>
</head>

<body>
<form action="<?php echo base_url();?>dashboard/login" method="post">
<input type="submit" id="submit" style="display: none;">
</form>
</body>
</html>