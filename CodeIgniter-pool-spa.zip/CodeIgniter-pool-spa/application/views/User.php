<?php
$this->load->view('Header');

$sUserID		= '';
$sUserName 		= '';
$sUserEmail 	= '';
$sUserUsername 	= '';
$sUserPassword 	= '';
$sUserActive 	= '';

if(!empty($userDetails))
{
	foreach($userDetails as $User)
	{
		$sUserID		= $User->id;
		$sUserName 		= $User->name;
		$sUserEmail 	= $User->email;
		$sUserUsername 	= $User->username;
		$sUserPassword 	= base64_decode($User->password);
		$sUserActive 	= $User->block;
	}
}

$sButtonText	=	'';
if($sUserID == '')
	$sButtonText = 'Save User';
else if($sUserID != '')
	$sButtonText = 'Update User';

?>
    <div id="page-wrapper">
        <div class="row">
          <div class="col-lg-12">
            <ol class="breadcrumb">
              <li><a href="<?php echo base_url('dashboard/users'); ?>"><i class="icon-dashboard"></i>All Users</a></li>
			  <li class="active"><i class="icon-file-alt"></i> Add/Edit User</li>
			  
            </ol>
          </div>
        </div><!-- /.row -->
        <div class="row">
          <div class="col-lg-12">
            <div class="panel panel-primary">
              <div class="panel-heading">
                <h3 class="panel-title">Add/Edit Page</h3>
              </div>
              <div class="panel-body">
                <div id="morris-chart-area">
                  <form action="<?php echo site_url('dashboard/userAddEdit');?>" method="post">
				  <input type="hidden" name="userID" value="<?php echo $sUserID;?>">
                    <table border="0" cellspacing="0" cellpadding="0" width="100%">
                      <tr>
                        <td width="24%"><strong>Name:</strong></td>
                        <td width="1%">&nbsp;</td>
                        <td width="75%"><input type="text" class="form-control" placeholder="Enter Name" name="sUserName" value="<?php echo $sUserName;?>" id="sUserName" required></td>
                      </tr>
                      <tr><td colspan="3">&nbsp;</td></tr>
                      <tr>
                        <td width="10%"><strong>Email:</strong></td>
                        <td width="1%">&nbsp;</td>
                        <td width="89%"><input type="text" class="form-control" placeholder="Enter Email" name="sUserEmail" value="<?php echo $sUserEmail;?>" id="sUserEmail" required></td>
                      </tr>
					  <tr><td colspan="3">&nbsp;</td></tr>
                      <tr>
                        <td width="10%"><strong>Username:</strong></td>
                        <td width="1%">&nbsp;</td>
                        <td width="89%"><input type="text" class="form-control" placeholder="Enter Username" name="sUserUsername" value="<?php echo $sUserUsername;?>" id="sUserUsername" required></td>
                      </tr>
					  <tr><td colspan="3">&nbsp;</td></tr>
                      <tr>
                        <td width="10%"><strong>Password:</strong></td>
                        <td width="1%">&nbsp;</td>
                        <td width="89%"><input type="password" class="form-control" placeholder="Enter Password" name="sUserPassword" value="<?php echo $sUserPassword;?>" id="sUserPassword" required></td>
                      </tr>
					  <tr><td colspan="3">&nbsp;</td></tr>
                      <tr>
                        <td width="10%"><strong>Block:</strong></td>
                        <td width="1%">&nbsp;</td>
                        <td width="89%"><input type="radio" name="sUserActive" value="0" <?php if($sUserActive == '0'|| $sUserActive == ''){echo 'checked="checked"';} ?> checked="checked">&nbsp;No&nbsp;&nbsp;&nbsp;&nbsp;<input type="radio" <?php if($sUserActive == '1'){echo 'checked="checked"';} ?> name="sUserActive" value="1">&nbsp;Yes</td>
                      </tr>
                      <tr><td colspan="3">&nbsp;</td></tr>
                      <tr><td colspan="3"><input type="submit" name="command" value="<?php echo $sButtonText;?>" class="btn btn-success" onclick="return checkForm();"></td></tr>
                      
                    </table>
                  </form>
                </div>
              </div>
            </div>
          </div>
        </div><!-- /.row -->
      </div><!-- /#page-wrapper -->
<script type="text/javascript">
$(document).ready(function (){
	
});
  function checkForm()
  {
	  var sEmail	=	$("#sUserEmail").val();
	  if( !validateEmail(sEmail)) 
	  {
		  alert("Please enter Valid Email ID!");
		  $("#sUserEmail").css('border','1px solid Red');
		  return false;
	  }
	  else
		  $("#sUserEmail").css('border','');
	  
    return true;
  }
  
  function validateEmail($email) 
  {
	var emailReg = /^([\w-\.]+@([\w-]+\.)+[\w-]{2,4})?$/;
	return emailReg.test( $email );
  }
</script>
<hr>
<?php
$this->load->view('Footer');
?>