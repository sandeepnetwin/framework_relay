<?php
$this->load->view('Header');

?>
    <div id="page-wrapper">
        <div class="row">
          <div class="col-lg-12">
            <ol class="breadcrumb">
              <li><a href="<?php echo base_url('dashboard/users'); ?>"><i class="icon-dashboard"></i>All Users</a></li>
			  <li class="active"><i class="icon-file-alt"></i> Permissions </li>
			  <div style="clear: both;"></div>
            </ol>
          </div>
        </div><!-- /.row -->
        <div class="row">
          <div class="col-lg-12">
            <div class="panel panel-primary">
              <div class="panel-heading">
                <h3 class="panel-title">View Permissions</h3>
              </div>
              <div class="panel-body">
                <div id="morris-chart-area">
                    <table class="table table-bordered table-striped tablesorter">
					<thead>
					  <tr>
						<th class="header">Module Name&nbsp;<i class="fa fa-sort"></i></th>
						<th class="header">Block</th>
						<th class="header">View</th>
						<th class="header">View & Change</th>
						
					  </tr>
					</thead>
					<?php if(!empty($allActiveModules))
						  {
							  foreach($allActiveModules as $Module)
							  {
								  $sPermission	=	$this->access_model->getPermissionForModule($userID,$Module->id)
					?>			 <tr>
									<td><?php echo $Module->module_name;?></td>
									<td><?php if($sPermission == '0' || $sPermission == ''){?><i class="fa fa-check"></i><?php } else {?>
									<i class="fa fa-ban"></i><?php }?></td>
									<td><?php if($sPermission == '1'){?><i class="fa fa-check"></i><?php } else {?>
									<i class="fa fa-ban"></i><?php }?></td>
									<td><?php if($sPermission == '2'){?><i class="fa fa-check"></i><?php } else {?>
									<i class="fa fa-ban"></i><?php }?></td>
								 </tr>
					<?php	  }
						  }
					?>	  
					<tbody>
					</tbody>
					</table>
                  
                </div>
              </div>
            </div>
          </div>
        </div><!-- /.row -->
	  </div><!-- /#page-wrapper -->
<script type="text/javascript">
$(document).ready(function (){
	
});
  function checkForm()
  {
	return true;
  }
</script>
<hr>
<?php
$this->load->view('Footer');
?>