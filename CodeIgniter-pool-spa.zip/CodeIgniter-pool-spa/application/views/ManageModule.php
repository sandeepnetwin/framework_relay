<?php
$this->load->view('Header');
?>
<!--  
Author : Dhiraj S.
-->

      <div id="page-wrapper">

        <div class="row">
          <div class="col-lg-12">
            <h1>Modules <small>Manage Site Module</small></h1>
            <ol class="breadcrumb">
              <li><a href="<?php echo base_url('dashboard/users'); ?>"><i class="icon-dashboard"></i> All Modules</a></li>
              <button class="btn btn-primary" type="button" style="float:right;" onclick="javascript:location.href='<?php echo base_url('dashboard/moduleAddEdit/'); ?>';">Add New Module</button>
              <div style="clear: both;"></div>
            </ol>
			<?php if($msg != '') { ?>
              <div class="alert alert-success alert-dismissable">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                <?php echo $msg;?>
              </div>
            <?php } ?>
			<?php if($err != '') { ?>
              <div class="alert alert-success alert-dismissable" style="background-color: #FFC0CB;border: 1px solid #FFC0CB; color:red;">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                <?php echo $err;?>
              </div>
            <?php } ?>
          </div>
        </div><!-- /.row -->
            <div class="table-responsive">
              <table class="table table-hover tablesorter">
                <thead>
                  <tr>
                    <th class="header">Module Name <i class="fa fa-sort"></i></th>
					<th class="header">Status</th>
                    <th class="header">Action</th>
                  </tr>
                </thead>
                <tbody>
				<?php if(!empty($allModules))
					  { 
						foreach($allModules as $Module) 
						{
				?>
                  <tr>
                    <td><?php echo $Module->module_name;?></td>
					<td><?php if($Module->module_active){echo '<span style="font-weight:bold;color: 	#006400;">Active</span>';} else {echo '<span style="font-weight:bold;color: 	 	 	#FF0000;">Inactive</span>';}?></td>
                   <td><a class="btn btn-primary btn-xs" href="<?php echo site_url('dashboard/moduleAddEdit/'.base64_encode($Module->id).'/');?>">Edit</a> &nbsp; <a class="btn btn-primary btn-xs" href="<?php echo site_url('dashboard/moduleDelete/'.base64_encode($Module->id).'/');?>">Delete</a></td>
                  </tr>
				<?php 	}
					  } 
					  else 
					  { 
				  ?>  
                  <tr>
					<td colspan="5"><span style="color:red; font-weight:bold;">No Modules Available!</span></td>
                   </tr>
				<?php } ?>
                </tbody>
              </table>
            </div>
      </div><!-- /#page-wrapper -->
<script type="text/javascript">
  
</script>
<hr>
<?php
$this->load->view('Footer');
?>