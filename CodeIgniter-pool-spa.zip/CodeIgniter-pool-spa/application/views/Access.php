<?php
$this->load->view('Header');

?>
    <div id="page-wrapper">
        <div class="row">
          <div class="col-lg-12">
            <ol class="breadcrumb">
              <li><a href="<?php echo base_url('dashboard/users'); ?>"><i class="icon-dashboard"></i>All Users</a></li>
			  <li class="active"><i class="icon-file-alt"></i> Permissions </li>
			  <button class="btn btn-primary" type="button" style="float:right;" onclick="javascript:document.permissionForm.submit();">Update Permissions</button>
              <div style="clear: both;"></div>
            </ol>
          </div>
        </div><!-- /.row -->
        <div class="row">
          <div class="col-lg-12">
            <div class="panel panel-primary">
              <div class="panel-heading">
                <h3 class="panel-title">Manage Permissions</h3>
              </div>
              <div class="panel-body">
                <div id="morris-chart-area">
                  <form name="permissionForm" id="permissionForm" action="<?php echo site_url('dashboard/accessAddEdit/'.base64_encode($userID));?>" method="post">
				    <input type="hidden" name="userID" value="<?php echo $userID; ?>">
				    <table class="table table-bordered table-striped tablesorter">
					<thead>
					  <tr>
						<th class="header">Module Name&nbsp;<i class="fa fa-sort"></i></th>
						<th class="header">Block</th>
						<th class="header">View</th>
						<th class="header">View & Change</th>
						
					  </tr>
					</thead>
					<?php if(!empty($allActiveModules))
						  {
							  foreach($allActiveModules as $Module)
							  {
								  $sPermission	=	$this->access_model->getPermissionForModule($userID,$Module->id)
					?>			 <tr>
									<td><?php echo $Module->module_name;?></td>
									<td><input type="radio" name="radioAccess_<?php echo $Module->id;?>" value="0" checked="checked" <?php if($sPermission == '0') {echo 'checked="checked"';} ?>>
									</td>
									<td><input type="radio" name="radioAccess_<?php echo $Module->id;?>" value="1" <?php if($sPermission == '1') {echo 'checked="checked"';} ?>></td>
									<td><input type="radio" name="radioAccess_<?php echo $Module->id;?>" value="2" <?php if($sPermission == '2') {echo 'checked="checked"';} ?>></td>
									
								 </tr>
					<?php	  }
						  }
					?>	  
					<tbody>
					</tbody>
					</table>
                  </form>
                </div>
              </div>
            </div>
          </div>
        </div><!-- /.row -->
		<div class="row">
          <div class="col-lg-12">
            <ol class="breadcrumb">
              <button class="btn btn-primary" type="button" style="float:right;" onclick="javascript:document.permissionForm.submit();">Update Permissions</button>
              <div style="clear: both;"></div>
            </ol>
          </div>
        </div><!-- /.row -->
      </div><!-- /#page-wrapper -->
<script type="text/javascript">
$(document).ready(function (){
	
});
  function checkForm()
  {
	return true;
  }
</script>
<hr>
<?php
$this->load->view('Footer');
?>