<?php
$this->load->view('Header');
?>
<!--  
Author : Dhiraj S.
-->

      <div id="page-wrapper">

        <div class="row">
          <div class="col-lg-12">
            <h1>Users <small>Manage Users Module</small></h1>
            <ol class="breadcrumb">
              <li><a href="<?php echo base_url('dashboard/users'); ?>"><i class="icon-dashboard"></i> All Users</a></li>
              <button class="btn btn-primary" type="button" style="float:right;" onclick="javascript:location.href='<?php echo base_url('dashboard/userAddEdit/'); ?>';">Add New User</button>
              <div style="clear: both;"></div>
            </ol>
			<?php if($msg != '') { ?>
              <div class="alert alert-success alert-dismissable">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                <?php echo $msg;?>
              </div>
            <?php } ?>
			<?php if($err != '') { ?>
              <div class="alert alert-success alert-dismissable" style="background-color: #FFC0CB;border: 1px solid #FFC0CB; color:red;">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                <?php echo $err;?>
              </div>
            <?php } ?>
          </div>
        </div><!-- /.row -->
            <div class="table-responsive">
              <table class="table table-hover tablesorter">
                <thead>
                  <tr>
                    <th class="header">UserName <i class="fa fa-sort"></i></th>
                    <th class="header">Email <i class="fa fa-sort"></i></th>
                    <th class="header">Last Login <i class="fa fa-sort"></i></th>
                    <th class="header">Signup Date<i class="fa fa-sort"></i></th>
					<th class="header">Permission</th>
					<th class="header">Action</th>
                  </tr>
                </thead>
                <tbody>
				<?php if(!empty($allUser))
					  { 
						foreach($allUser as $User) 
						{
				?>
                  <tr>
                    <td><?php echo $User->username;?></td>
                    <td><?php echo $User->email;?></td>
                    <td><?php echo $User->last_login;?></td>
                    <td><?php echo $User->created_date;?></td>
					<td><a class="btn btn-primary btn-xs" href="<?php echo site_url('dashboard/accessAddEdit/'.base64_encode($User->id).'/');?>">Change Access</a> &nbsp; <a class="btn btn-primary btn-xs" href="<?php echo site_url('dashboard/accessCheck/'.base64_encode($User->id).'/');?>">View Permission</a></td>
					<td><a class="btn btn-primary btn-xs" href="<?php echo site_url('dashboard/userAddEdit/'.base64_encode($User->id).'/');?>">Edit</a> &nbsp; <a class="btn btn-primary btn-xs" href="<?php echo site_url('dashboard/userDelete/'.base64_encode($User->id).'/');?>">Delete</a></td>
                  </tr>
				<?php 	}
					  } 
					  else 
					  { 
				  ?>  
                  <tr>
					<td colspan="5"><span style="color:red; font-weight:bold;">No Users Available!</span></td>
                   </tr>
				<?php } ?>
                </tbody>
              </table>
            </div>
      </div><!-- /#page-wrapper -->
<script type="text/javascript">
  
</script>
<hr>
<?php
$this->load->view('Footer');
?>