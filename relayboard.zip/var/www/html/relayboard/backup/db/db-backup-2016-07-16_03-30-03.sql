
/*---------------------------------------------------------------
  SQL DB BACKUP 16.07.2016 03:30 
  TABLES: *
  ---------------------------------------------------------------*/

/*---------------------------------------------------------------
  TABLE: `ci_sessions`
  ---------------------------------------------------------------*/
DROP TABLE IF EXISTS `ci_sessions`;
CREATE TABLE `ci_sessions` (
  `session_id` varchar(40) NOT NULL DEFAULT '0',
  `ip_address` varchar(45) NOT NULL DEFAULT '0',
  `user_agent` varchar(120) NOT NULL,
  `last_activity` int(10) unsigned NOT NULL DEFAULT '0',
  `user_data` text NOT NULL,
  PRIMARY KEY (`session_id`),
  KEY `last_activity_idx` (`last_activity`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*---------------------------------------------------------------
  TABLE: `rlb_access_permissions`
  ---------------------------------------------------------------*/
DROP TABLE IF EXISTS `rlb_access_permissions`;
CREATE TABLE `rlb_access_permissions` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `user_id` int(5) NOT NULL,
  `module_id` int(5) NOT NULL,
  `access` enum('0','1','2') NOT NULL DEFAULT '0' COMMENT '0=block,1=View,2=View and change',
  `modified_date` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=latin1;
INSERT INTO `rlb_access_permissions` VALUES   ('1','4','2','1','2015-08-24 08:14:43');
INSERT INTO `rlb_access_permissions` VALUES ('2','4','3','1','2015-08-24 08:14:43');
INSERT INTO `rlb_access_permissions` VALUES ('3','4','4','1','2015-08-24 08:14:44');
INSERT INTO `rlb_access_permissions` VALUES ('4','4','5','0','2015-08-24 08:14:44');
INSERT INTO `rlb_access_permissions` VALUES ('5','4','6','0','2015-08-24 08:14:44');
INSERT INTO `rlb_access_permissions` VALUES ('6','4','7','2','2015-08-24 08:14:44');
INSERT INTO `rlb_access_permissions` VALUES ('7','4','8','1','2015-08-24 08:14:44');
INSERT INTO `rlb_access_permissions` VALUES ('8','4','9','1','2015-08-24 08:14:44');
INSERT INTO `rlb_access_permissions` VALUES ('9','4','10','1','2015-08-24 08:14:44');
INSERT INTO `rlb_access_permissions` VALUES ('10','4','11','1','2015-08-24 08:14:44');
INSERT INTO `rlb_access_permissions` VALUES ('11','4','12','1','2015-08-24 08:14:44');
INSERT INTO `rlb_access_permissions` VALUES ('12','4','13','0','2015-08-24 08:14:44');
INSERT INTO `rlb_access_permissions` VALUES ('13','5','2','1','2015-12-28 07:28:21');
INSERT INTO `rlb_access_permissions` VALUES ('14','5','3','1','2015-12-28 07:28:21');
INSERT INTO `rlb_access_permissions` VALUES ('15','5','4','0','2015-12-28 07:28:21');
INSERT INTO `rlb_access_permissions` VALUES ('16','5','5','1','2015-12-28 07:28:21');
INSERT INTO `rlb_access_permissions` VALUES ('17','5','6','0','2015-12-28 07:28:21');
INSERT INTO `rlb_access_permissions` VALUES ('18','5','7','0','2015-12-28 07:28:21');
INSERT INTO `rlb_access_permissions` VALUES ('19','5','8','1','2015-12-28 07:28:22');
INSERT INTO `rlb_access_permissions` VALUES ('20','5','9','1','2015-12-28 07:28:22');
INSERT INTO `rlb_access_permissions` VALUES ('21','5','10','1','2015-12-28 07:28:22');
INSERT INTO `rlb_access_permissions` VALUES ('22','5','11','0','2015-12-28 07:28:22');
INSERT INTO `rlb_access_permissions` VALUES ('23','5','12','0','2015-12-28 07:28:22');
INSERT INTO `rlb_access_permissions` VALUES ('24','5','13','0','2015-12-28 07:28:22');
INSERT INTO `rlb_access_permissions` VALUES ('25','5','15','0','2015-12-28 07:28:22');
INSERT INTO `rlb_access_permissions` VALUES ('26','5','16','0','2015-12-28 07:28:22');
INSERT INTO `rlb_access_permissions` VALUES ('27','5','17','0','2015-12-28 07:28:22');
INSERT INTO `rlb_access_permissions` VALUES ('28','5','18','0','2015-12-28 07:28:22');
INSERT INTO `rlb_access_permissions` VALUES ('29','5','19','0','2015-12-28 07:28:22');
INSERT INTO `rlb_access_permissions` VALUES ('30','5','20','0','2015-12-28 07:28:23');
INSERT INTO `rlb_access_permissions` VALUES ('31','5','21','1','2015-12-28 07:28:23');

/*---------------------------------------------------------------
  TABLE: `rlb_admin_users`
  ---------------------------------------------------------------*/
DROP TABLE IF EXISTS `rlb_admin_users`;
CREATE TABLE `rlb_admin_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(150) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `block` tinyint(4) NOT NULL DEFAULT '0',
  `user_type` enum('SA','A') DEFAULT 'SA' COMMENT 'SA: Super Admin,A: Admin',
  `name` varchar(250) NOT NULL,
  `created_date` datetime NOT NULL,
  `parent_id` int(5) NOT NULL,
  `last_login` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;
INSERT INTO `rlb_admin_users` VALUES   ('1','admin','dhiraj.netwin@yahoo.com','YWRtaW4xMjM=','0','SA','Admin','0000-00-00 00:00:00','0','2016-07-15 05:55:28');
INSERT INTO `rlb_admin_users` VALUES ('5','test','test@test.com','dGVzdDEyMw==','0','A','Test','2015-10-05 08:04:18','1','2016-01-22 08:22:34');

/*---------------------------------------------------------------
  TABLE: `rlb_analog_device`
  ---------------------------------------------------------------*/
DROP TABLE IF EXISTS `rlb_analog_device`;
CREATE TABLE `rlb_analog_device` (
  `analog_id` int(10) NOT NULL AUTO_INCREMENT,
  `analog_input` int(10) NOT NULL,
  `analog_name` varchar(150) NOT NULL,
  `analog_device` varchar(100) NOT NULL,
  `analog_device_type` varchar(100) NOT NULL,
  `device_direction` int(5) NOT NULL,
  `analog_device_modified_date` datetime NOT NULL,
  `ip_id` int(5) NOT NULL,
  PRIMARY KEY (`analog_id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;
INSERT INTO `rlb_analog_device` VALUES   ('1','0','AP0','10','R','0','2016-01-22 11:19:21','1');
INSERT INTO `rlb_analog_device` VALUES ('2','1','AP1','0','V','1','2016-01-22 11:19:21','1');
INSERT INTO `rlb_analog_device` VALUES ('3','2','AP2','0','P','0','2016-01-22 11:19:21','1');
INSERT INTO `rlb_analog_device` VALUES ('4','3','AP3','0','L','0','2016-01-22 11:19:22','1');
INSERT INTO `rlb_analog_device` VALUES ('5','0','AP0','1','R','0','2016-01-22 11:19:22','2');
INSERT INTO `rlb_analog_device` VALUES ('6','1','AP1','1','P','0','2016-01-22 11:19:22','2');
INSERT INTO `rlb_analog_device` VALUES ('7','2','AP2','2','V','2','2016-01-22 11:19:22','2');
INSERT INTO `rlb_analog_device` VALUES ('8','3','AP3','1','L','0','2016-01-22 11:19:22','2');

/*---------------------------------------------------------------
  TABLE: `rlb_board_ip`
  ---------------------------------------------------------------*/
DROP TABLE IF EXISTS `rlb_board_ip`;
CREATE TABLE `rlb_board_ip` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `ip` varchar(150) NOT NULL,
  `name` text NOT NULL,
  `status` enum('0','1') NOT NULL DEFAULT '0',
  `ssh_port` varchar(10) DEFAULT NULL,
  `local_port` int(5) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
INSERT INTO `rlb_board_ip` VALUES   ('1','192.168.0.103','Device1','1','','2222');
INSERT INTO `rlb_board_ip` VALUES ('2','192.168.0.115','Device2','1','','222');

/*---------------------------------------------------------------
  TABLE: `rlb_custom_program`
  ---------------------------------------------------------------*/
DROP TABLE IF EXISTS `rlb_custom_program`;
CREATE TABLE `rlb_custom_program` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `g_id` int(10) NOT NULL,
  `program_details` text NOT NULL,
  `is_on` enum('0','1') NOT NULL,
  `isremoved` enum('0','1') NOT NULL DEFAULT '0',
  `display_access` enum('0','1') NOT NULL DEFAULT '0',
  `already_running` enum('0','1') NOT NULL DEFAULT '0',
  `unique_id` varchar(255) NOT NULL,
  `program_start` varchar(250) DEFAULT NULL,
  `program_end` varchar(250) DEFAULT NULL,
  `afterProgram` enum('0','1') NOT NULL DEFAULT '0',
  `previousState` text NOT NULL,
  `is_schedule` enum('0','1') NOT NULL DEFAULT '0',
  `program_schedule_start` varchar(100) NOT NULL,
  `program_schedule_end` varchar(100) NOT NULL,
  `schedule_run` enum('0','1') NOT NULL DEFAULT '0',
  `program_type` int(2) NOT NULL COMMENT '0 - Daily,1 - Weekly',
  `program_days` varchar(50) NOT NULL COMMENT '0 - All, 1- Mon ... 7- Sat',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=47 DEFAULT CHARSET=latin1;
INSERT INTO `rlb_custom_program` VALUES   ('1','15','{\"g_id\":\"15\",\"g_custom_mode_name\":\"Indoor_Spa_On\\/Off_\",\"g_rlb_pump_list\":\"1_2\",\"g_pump_sq\":\"7\",\"g_pump_time\":\"55\",\"g_rlb_valve_list\":\"1_2_4,1_1_5,1_2_6,2_2_0,2_2_3,2_1_4,2_2_5\",\"g_valve_sq\":\"3,6,6,1,2,4,5\",\"g_valve_time\":\"1,1,1,1,1,1,1\",\"g_custom_max_time\":\"400\",\"g_rlb_relay_list\":\"1_15\",\"g_relay_sq\":\"7\",\"g_relay_time\":\"55\",\"g_rlb_powercenter_list\":\"1_0\",\"g_powercenter_sq\":\"7\",\"g_powercenter_time\":\"55\"}','0','0','1','0','','2016-07-11 22:28:05','2016-07-12 05:08:05','0','a:7:{i:0;s:5:\"1_0_4\";i:1;s:5:\"1_0_5\";i:2;s:5:\"1_0_6\";i:3;s:5:\"2_0_0\";i:4;s:5:\"2_2_3\";i:5;s:5:\"2_0_4\";i:6;s:5:\"2_0_5\";}','0','0000-00-00 00:00:00','0000-00-00 00:00:00','0','0','');
INSERT INTO `rlb_custom_program` VALUES ('2','15','{\"g_id\":\"15\",\"g_custom_mode_name\":\"Outdoor_Spa_2\",\"g_rlb_pump_list\":\"1_2\",\"g_pump_sq\":\"10\",\"g_pump_time\":\"90\",\"g_rlb_valve_list\":\"1_2_4,1_2_5,1_1_6,2_2_0,2_1_2,2_1_3,2_2_4,2_1_5\",\"g_valve_sq\":\"1,2,3,4,5,6,7,8\",\"g_valve_time\":\"1,1,1,1,1,1,1,1\",\"g_custom_max_time\":\"500\",\"g_rlb_relay_list\":\"1_6\",\"g_relay_sq\":\"10\",\"g_relay_time\":\"90\",\"g_rlb_powercenter_list\":\"1_0\",\"g_powercenter_sq\":\"10\",\"g_powercenter_time\":\"90\"}','0','0','0','0','','2016-06-22 14:09:35','2016-06-22 20:09:35','0','a:8:{i:0;s:5:\"1_0_4\";i:1;s:5:\"1_0_5\";i:2;s:5:\"1_0_6\";i:3;s:5:\"2_0_0\";i:4;s:5:\"2_0_2\";i:5;s:5:\"2_0_3\";i:6;s:5:\"2_0_4\";i:7;s:5:\"2_0_5\";}','0','0000-00-00 00:00:00','0000-00-00 00:00:00','0','0','');
INSERT INTO `rlb_custom_program` VALUES ('3','15','{\"g_id\":\"15\",\"g_custom_mode_name\":\"Indoor_Spa_Fill_10_Minute\",\"g_rlb_pump_list\":\"1_1\",\"g_pump_sq\":\"4\",\"g_pump_time\":\"10\",\"g_rlb_valve_list\":\"1_1_0,1_1_4,2_2_0,2_1_4,2_2_5\",\"g_valve_sq\":\"1,1,2,3,3\",\"g_valve_time\":\"1,1,1,1,1\",\"g_custom_max_time\":\"20\",\"g_rlb_relay_list\":\"null\",\"g_relay_sq\":\"\",\"g_relay_time\":\"\",\"g_rlb_powercenter_list\":\"null\",\"g_powercenter_sq\":\"\",\"g_powercenter_time\":\"\"}','0','0','1','0','','2016-07-09 16:40:36','2016-07-09 17:00:36','0','a:5:{i:0;s:5:\"1_2_5\";i:1;s:5:\"1_1_6\";i:2;s:5:\"2_0_1\";i:3;s:5:\"2_0_2\";i:4;s:3:\"_0_\";}','0','0000-00-00 00:00:00','0000-00-00 00:00:00','0','0','');
INSERT INTO `rlb_custom_program` VALUES ('4','10','{\"g_id\":\"10\",\"g_custom_mode_name\":\"Custom_program_From_Local\",\"g_rlb_pump_list\":\"1_1,1_2\",\"g_pump_sq\":\"1,3\",\"g_pump_time\":\"10,1\",\"g_rlb_valve_list\":\"1_2_0,1_1_4\",\"g_valve_sq\":\"2,1\",\"g_valve_time\":\"20,5\",\"g_custom_max_time\":\"40\",\"g_rlb_relay_list\":\"null\",\"g_relay_sq\":\"\",\"g_relay_time\":\"\",\"g_rlb_powercenter_list\":\"null\",\"g_powercenter_sq\":\"\",\"g_powercenter_time\":\"\"}','0','0','1','0','',NULL,NULL,'0','','0','0000-00-00 00:00:00','0000-00-00 00:00:00','0','0','');
INSERT INTO `rlb_custom_program` VALUES ('5','10','{\"g_id\":\"10\",\"g_custom_mode_name\":\"custom_program_local\",\"g_rlb_pump_list\":\"1_1\",\"g_pump_sq\":\"1\",\"g_pump_time\":\"10\",\"g_rlb_valve_list\":\"1_1_0,1_2_0\",\"g_valve_sq\":\"1,4\",\"g_valve_time\":\"20,1\",\"g_custom_max_time\":\"41\",\"g_rlb_relay_list\":\"1_7\",\"g_relay_sq\":\"2\",\"g_relay_time\":\"10\",\"g_rlb_powercenter_list\":\"1_1\",\"g_powercenter_sq\":\"3\",\"g_powercenter_time\":\"10\"}','0','0','1','0','',NULL,NULL,'0','','0','0000-00-00 00:00:00','0000-00-00 00:00:00','0','0','');
INSERT INTO `rlb_custom_program` VALUES ('6','15','{\"g_id\":\"15\",\"g_custom_mode_name\":\"Waterfalls\",\"g_rlb_pump_list\":\"1_2\",\"g_pump_sq\":\"3\",\"g_pump_time\":\"60\",\"g_rlb_valve_list\":\"1_2_5,1_1_6,2_1_1,2_2_2\",\"g_valve_sq\":\"2,2,1,1\",\"g_valve_time\":\"1,1,1,1\",\"g_custom_max_time\":\"70\",\"g_rlb_relay_list\":\"null\",\"g_relay_sq\":\"\",\"g_relay_time\":\"\",\"g_rlb_powercenter_list\":\"null\",\"g_powercenter_sq\":\"\",\"g_powercenter_time\":\"\"}','0','0','1','0','','2016-07-09 18:08:54','2016-07-09 19:18:54','0','a:4:{i:0;s:5:\"1_0_4\";i:1;s:5:\"1_0_5\";i:2;s:5:\"1_0_6\";i:3;s:5:\"2_2_0\";}','0','0000-00-00 00:00:00','0000-00-00 00:00:00','0','0','');
INSERT INTO `rlb_custom_program` VALUES ('43','10','{\"g_id\":\"10\",\"g_custom_mode_name\":\"30_Jun_Local\",\"g_custom_max_time\":\"20\",\"g_rlb_pump_list\":\"1_1\",\"g_pump_sq\":\"1\",\"g_pump_time\":\"1\",\"g_rlb_valve_list\":\"2_2_0\",\"g_valve_sq\":\"2\",\"g_valve_time\":\"1\",\"g_rlb_relay_list\":\"1_7,2_15\",\"g_relay_sq\":\"3,4\",\"g_relay_time\":\"1,1\",\"g_rlb_powercenter_list\":\"1_1\",\"g_powercenter_sq\":\"5\",\"g_powercenter_time\":\"1\"}','0','0','0','0','',NULL,NULL,'0','','0','0000-00-00 00:00:00','0000-00-00 00:00:00','0','0','');
INSERT INTO `rlb_custom_program` VALUES ('44','16','{\"g_id\":\"16\",\"g_custom_mode_name\":\"Testing__Custom_program_\",\"g_custom_max_time\":\"200\",\"g_rlb_pump_list\":\"1_2\",\"g_pump_sq\":\"1\",\"g_pump_time\":\"1\",\"g_rlb_valve_list\":\"1_1_0\",\"g_valve_sq\":\"2\",\"g_valve_time\":\"1\",\"g_rlb_relay_list\":\"1_6,2_12\",\"g_relay_sq\":\"3,4\",\"g_relay_time\":\"1,1\",\"g_rlb_powercenter_list\":\"null\",\"g_powercenter_sq\":\"\",\"g_powercenter_time\":\"\"}','0','0','0','0','',NULL,NULL,'0','','0','0000-00-00 00:00:00','0000-00-00 00:00:00','0','0','');
INSERT INTO `rlb_custom_program` VALUES ('45','15','{\"g_id\":\"15\",\"g_custom_mode_name\":\"Spa_2_Clean_1_hr\",\"g_rlb_pump_list\":\"1_1\",\"g_pump_sq\":\"6\",\"g_pump_time\":\"1\",\"g_rlb_valve_list\":\"1_2_4,1_2_5,1_1_6,2_2_0,2_1_2,2_1_3,2_2_4,2_1_5\",\"g_valve_sq\":\"4,1,2,3,2,3,5,4\",\"g_valve_time\":\"1,1,1,1,1,1,1,1\",\"g_custom_max_time\":\"480\",\"g_rlb_relay_list\":\"null\",\"g_relay_sq\":\"\",\"g_relay_time\":\"\",\"g_rlb_powercenter_list\":\"null\",\"g_powercenter_sq\":\"\",\"g_powercenter_time\":\"\"}','0','0','1','0','','2016-07-08 09:12:25','2016-07-08 17:12:25','0','a:8:{i:0;s:5:\"1_0_4\";i:1;s:5:\"1_0_5\";i:2;s:5:\"1_0_6\";i:3;s:5:\"2_0_0\";i:4;s:5:\"2_0_2\";i:5;s:5:\"2_0_3\";i:6;s:5:\"2_0_4\";i:7;s:5:\"2_0_5\";}','0','0000-00-00 00:00:00','0000-00-00 00:00:00','0','0','');
INSERT INTO `rlb_custom_program` VALUES ('46','15','{\"g_id\":\"15\",\"g_custom_mode_name\":\"Spa_1_and_Waterfall_(no_jets)\",\"g_custom_max_time\":\"120\",\"g_rlb_pump_list\":\"1_2\",\"g_pump_sq\":\"8\",\"g_pump_time\":\"1\",\"g_rlb_valve_list\":\"1_2_4,1_2_5,1_1_6,2_2_0,2_1_1,2_2_2,2_2_3,2_1_4,2_2_5\",\"g_valve_sq\":\"2,6,1,1,3,5,2,3,4\",\"g_valve_time\":\"1,1,1,1,1,1,1,1,1\",\"g_rlb_relay_list\":\"1_15\",\"g_relay_sq\":\"7\",\"g_relay_time\":\"1\",\"g_rlb_powercenter_list\":\"1_0\",\"g_powercenter_sq\":\"8\",\"g_powercenter_time\":\"1\"}','0','0','0','0','',NULL,NULL,'0','','0','0000-00-00 00:00:00','0000-00-00 00:00:00','0','0','');

/*---------------------------------------------------------------
  TABLE: `rlb_custom_program_after`
  ---------------------------------------------------------------*/
DROP TABLE IF EXISTS `rlb_custom_program_after`;
CREATE TABLE `rlb_custom_program_after` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `program_id` int(10) NOT NULL,
  `current_on_device` varchar(150) NOT NULL,
  `device_type` varchar(10) NOT NULL,
  `device_number` int(5) NOT NULL,
  `current_on_time` datetime NOT NULL,
  `current_off_time` datetime NOT NULL,
  `current_device_complete` enum('0','1') NOT NULL DEFAULT '0',
  `current_sequence` varchar(10) NOT NULL,
  `ip_id` int(5) NOT NULL,
  `unique_id` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*---------------------------------------------------------------
  TABLE: `rlb_custom_program_current`
  ---------------------------------------------------------------*/
DROP TABLE IF EXISTS `rlb_custom_program_current`;
CREATE TABLE `rlb_custom_program_current` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `program_id` int(10) NOT NULL,
  `current_on_device` varchar(150) NOT NULL,
  `device_type` varchar(10) NOT NULL,
  `device_number` int(5) NOT NULL,
  `current_on_time` datetime NOT NULL,
  `current_off_time` datetime NOT NULL,
  `current_device_complete` enum('0','1') NOT NULL DEFAULT '0',
  `current_sequence` varchar(10) NOT NULL,
  `ip_id` int(5) NOT NULL,
  `unique_id` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*---------------------------------------------------------------
  TABLE: `rlb_custom_program_log`
  ---------------------------------------------------------------*/
DROP TABLE IF EXISTS `rlb_custom_program_log`;
CREATE TABLE `rlb_custom_program_log` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `program_id` int(10) NOT NULL,
  `device` varchar(150) NOT NULL,
  `device_type` varchar(10) NOT NULL,
  `device_number` int(5) NOT NULL,
  `device_start` datetime NOT NULL,
  `device_stop` datetime NOT NULL,
  `device_complete_run` enum('0','1') NOT NULL DEFAULT '0',
  `current_sequence` varchar(5) NOT NULL,
  `ip_id` int(5) NOT NULL,
  `unique_id` varchar(255) NOT NULL,
  `afterDevice` enum('0','1') NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=983 DEFAULT CHARSET=latin1;
INSERT INTO `rlb_custom_program_log` VALUES   ('1','1','Valve 0','V','0','2016-06-22 02:23:01','2016-06-22 02:24:01','1','1','1','89750901466587379','0');
INSERT INTO `rlb_custom_program_log` VALUES ('2','1','Valve 2','V','2','2016-06-22 02:24:04','2016-06-22 02:25:04','1','2','1','89750901466587379','0');
INSERT INTO `rlb_custom_program_log` VALUES ('3','1','Valve 6','V','6','2016-06-22 02:26:02','2016-06-22 02:27:02','1','3','1','89750901466587379','0');
INSERT INTO `rlb_custom_program_log` VALUES ('4','1','Valve 0','V','0','2016-06-22 02:27:02','2016-06-22 02:28:02','1','4','2','89750901466587379','0');
INSERT INTO `rlb_custom_program_log` VALUES ('5','1','Relay 6','R','6','2016-06-22 02:29:02','2016-06-22 02:30:02','1','5','1','89750901466587379','0');
INSERT INTO `rlb_custom_program_log` VALUES ('6','1','Valve 0','V','0','2016-06-22 02:30:04','2016-06-22 02:31:04','1','1','1','89750901466587379','1');
INSERT INTO `rlb_custom_program_log` VALUES ('7','1','Valve 2','V','2','2016-06-22 02:32:02','2016-06-22 02:33:02','1','2','1','89750901466587379','1');
INSERT INTO `rlb_custom_program_log` VALUES ('8','1','Valve 6','V','6','2016-06-22 02:33:02','2016-06-22 02:34:02','1','3','1','89750901466587379','1');
INSERT INTO `rlb_custom_program_log` VALUES ('9','1','Valve 0','V','0','2016-06-22 02:34:02','2016-06-22 02:35:02','1','4','2','89750901466587379','1');
INSERT INTO `rlb_custom_program_log` VALUES ('10','1','Valve 0','V','0','2016-06-22 02:52:02','2016-06-22 02:53:02','1','1','1','59171031466589121','0');
INSERT INTO `rlb_custom_program_log` VALUES ('11','1','Valve 2','V','2','2016-06-22 02:53:03','2016-06-22 02:54:03','1','2','1','59171031466589121','0');
INSERT INTO `rlb_custom_program_log` VALUES ('12','1','Valve 0','V','0','2016-06-22 03:10:07','2016-06-22 03:11:07','1','1','1','58799671466590207','0');
INSERT INTO `rlb_custom_program_log` VALUES ('13','1','Valve 2','V','2','2016-06-22 03:12:02','2016-06-22 03:13:02','1','2','1','58799671466590207','0');
INSERT INTO `rlb_custom_program_log` VALUES ('14','1','Valve 6','V','6','2016-06-22 03:13:02','2016-06-22 03:14:02','1','3','1','58799671466590207','0');
INSERT INTO `rlb_custom_program_log` VALUES ('15','1','Valve 0','V','0','2016-06-22 03:14:02','2016-06-22 03:15:02','1','4','2','58799671466590207','0');
INSERT INTO `rlb_custom_program_log` VALUES ('16','1','Relay 6','R','6','2016-06-22 03:15:02','2016-06-22 03:16:02','1','5','1','58799671466590207','0');
INSERT INTO `rlb_custom_program_log` VALUES ('17','1','Valve 0','V','0','2016-06-22 03:16:05','2016-06-22 03:17:05','1','1','1','58799671466590207','1');
INSERT INTO `rlb_custom_program_log` VALUES ('18','1','Valve 0','V','0','2016-06-22 03:18:00','2016-06-22 03:19:00','1','1','1','46765201466590676','0');
INSERT INTO `rlb_custom_program_log` VALUES ('19','1','Valve 2','V','2','2016-06-22 03:19:06','2016-06-22 03:20:06','1','2','1','46765201466590676','0');
INSERT INTO `rlb_custom_program_log` VALUES ('20','1','Valve 0','V','0','2016-06-22 03:20:02','2016-06-22 03:21:02','1','1','1','46765201466590676','1');
INSERT INTO `rlb_custom_program_log` VALUES ('21','1','Valve 2','V','2','2016-06-22 03:21:02','2016-06-22 03:22:02','1','2','1','46765201466590676','1');
INSERT INTO `rlb_custom_program_log` VALUES ('22','1','Valve 6','V','6','2016-06-22 03:22:02','2016-06-22 03:23:02','1','3','1','46765201466590676','1');
INSERT INTO `rlb_custom_program_log` VALUES ('23','1','Valve 0','V','0','2016-06-22 03:23:02','2016-06-22 03:24:02','1','4','2','46765201466590676','1');
INSERT INTO `rlb_custom_program_log` VALUES ('24','1','Valve 0','V','0','2016-06-22 03:30:48','2016-06-22 03:31:48','1','1','1','63120041466591447','0');
INSERT INTO `rlb_custom_program_log` VALUES ('25','1','Valve 2','V','2','2016-06-22 03:32:05','2016-06-22 03:33:05','1','2','1','63120041466591447','0');
INSERT INTO `rlb_custom_program_log` VALUES ('26','1','Valve 6','V','6','2016-06-22 03:34:05','2016-06-22 03:35:05','1','3','1','63120041466591447','0');
INSERT INTO `rlb_custom_program_log` VALUES ('27','1','Valve 0','V','0','2016-06-22 03:36:05','2016-06-22 03:37:05','1','4','2','63120041466591447','0');
INSERT INTO `rlb_custom_program_log` VALUES ('28','1','Relay 6','R','6','2016-06-22 03:38:04','2016-06-22 03:39:04','1','5','1','63120041466591447','0');
INSERT INTO `rlb_custom_program_log` VALUES ('29','1','Valve 0','V','0','2016-06-22 03:40:06','2016-06-22 03:41:06','1','1','1','63120041466591447','1');
INSERT INTO `rlb_custom_program_log` VALUES ('30','1','Valve 2','V','2','2016-06-22 03:42:02','2016-06-22 03:43:02','1','2','1','63120041466591447','1');
INSERT INTO `rlb_custom_program_log` VALUES ('31','1','Valve 6','V','6','2016-06-22 03:43:02','2016-06-22 03:44:02','1','3','1','63120041466591447','1');
INSERT INTO `rlb_custom_program_log` VALUES ('32','1','Valve 0','V','0','2016-06-22 03:44:02','2016-06-22 03:45:02','1','4','2','63120041466591447','1');
INSERT INTO `rlb_custom_program_log` VALUES ('33','1','Valve 3','V','3','2016-06-22 10:30:00','2016-06-22 10:31:00','1','1','2','14338191466616600','0');
INSERT INTO `rlb_custom_program_log` VALUES ('34','1','Valve 0','V','0','2016-06-22 10:31:02','2016-06-22 10:32:02','1','2','2','14338191466616600','0');
INSERT INTO `rlb_custom_program_log` VALUES ('35','1','Valve 4','V','4','2016-06-22 10:32:02','2016-06-22 10:33:02','1','3','1','14338191466616600','0');
INSERT INTO `rlb_custom_program_log` VALUES ('36','1','Valve 4','V','4','2016-06-22 10:33:02','2016-06-22 10:34:02','1','4','2','14338191466616600','0');
INSERT INTO `rlb_custom_program_log` VALUES ('37','1','Valve 5','V','5','2016-06-22 10:33:02','2016-06-22 10:34:02','1','4','2','14338191466616600','0');
INSERT INTO `rlb_custom_program_log` VALUES ('38','1','Valve 5','V','5','2016-06-22 10:33:02','2016-06-22 10:34:02','1','4','2','14338191466616600','0');
INSERT INTO `rlb_custom_program_log` VALUES ('39','1','Pump 1','PS','1','2016-06-22 10:34:02','2016-06-22 10:35:02','1','5','1','14338191466616600','0');
INSERT INTO `rlb_custom_program_log` VALUES ('40','1','Relay 15','R','15','2016-06-22 10:35:02','2016-06-22 10:36:02','1','6','1','14338191466616600','0');
INSERT INTO `rlb_custom_program_log` VALUES ('41','1','Valve 3','V','3','2016-06-22 10:36:02','2016-06-22 10:37:02','1','1','2','14338191466616600','1');
INSERT INTO `rlb_custom_program_log` VALUES ('42','1','Valve 0','V','0','2016-06-22 10:38:02','2016-06-22 10:39:02','1','2','2','14338191466616600','1');
INSERT INTO `rlb_custom_program_log` VALUES ('43','1','Valve 4','V','4','2016-06-22 10:39:03','2016-06-22 10:40:03','1','3','1','14338191466616600','1');
INSERT INTO `rlb_custom_program_log` VALUES ('44','1','Valve 5','V','5','2016-06-22 10:41:02','2016-06-22 10:42:02','1','4','2','14338191466616600','1');
INSERT INTO `rlb_custom_program_log` VALUES ('45','1','Valve 0','V','0','2016-06-22 10:51:39','2016-06-22 10:52:39','1','1','2','17543371466617899','0');
INSERT INTO `rlb_custom_program_log` VALUES ('46','1','Valve 3','V','3','2016-06-22 10:53:02','2016-06-22 10:54:02','1','2','2','17543371466617899','0');
INSERT INTO `rlb_custom_program_log` VALUES ('47','1','Valve 4','V','4','2016-06-22 10:54:02','2016-06-22 10:55:02','1','3','1','17543371466617899','0');
INSERT INTO `rlb_custom_program_log` VALUES ('48','1','Valve 4','V','4','2016-06-22 10:55:02','2016-06-22 10:56:02','1','4','2','17543371466617899','0');
INSERT INTO `rlb_custom_program_log` VALUES ('49','1','Pump 1','PS','1','2016-06-22 10:56:02','2016-06-22 10:57:02','1','5','1','17543371466617899','0');
INSERT INTO `rlb_custom_program_log` VALUES ('50','1','Valve 5','V','5','2016-06-22 10:56:02','2016-06-22 10:57:02','1','5','2','17543371466617899','0');
INSERT INTO `rlb_custom_program_log` VALUES ('51','1','Relay 15','R','15','2016-06-22 10:57:08','2016-06-22 10:58:08','1','6','1','17543371466617899','0');
INSERT INTO `rlb_custom_program_log` VALUES ('52','1','Valve 0','V','0','2016-06-22 10:59:06','2016-06-22 11:00:06','1','1','2','17543371466617899','1');
INSERT INTO `rlb_custom_program_log` VALUES ('53','1','Valve 3','V','3','2016-06-22 11:01:03','2016-06-22 11:02:03','1','2','2','17543371466617899','1');
INSERT INTO `rlb_custom_program_log` VALUES ('54','1','Valve 4','V','4','2016-06-22 11:03:02','2016-06-22 11:04:02','1','3','1','17543371466617899','1');
INSERT INTO `rlb_custom_program_log` VALUES ('55','1','Valve 4','V','4','2016-06-22 11:04:02','2016-06-22 11:05:02','1','4','2','17543371466617899','1');
INSERT INTO `rlb_custom_program_log` VALUES ('56','1','Valve 5','V','5','2016-06-22 11:05:02','2016-06-22 11:06:02','1','5','2','17543371466617899','1');
INSERT INTO `rlb_custom_program_log` VALUES ('57','1','Valve 0','V','0','2016-06-22 11:10:37','2016-06-22 11:11:37','1','1','2','10054521466619036','0');
INSERT INTO `rlb_custom_program_log` VALUES ('58','1','Valve 3','V','3','2016-06-22 11:12:03','2016-06-22 11:13:03','1','2','2','10054521466619036','0');
INSERT INTO `rlb_custom_program_log` VALUES ('59','1','Valve 4','V','4','2016-06-22 11:13:05','2016-06-22 11:14:05','1','3','1','10054521466619036','0');
INSERT INTO `rlb_custom_program_log` VALUES ('60','1','Valve 4','V','4','2016-06-22 11:15:07','2016-06-22 11:16:07','1','4','2','10054521466619036','0');
INSERT INTO `rlb_custom_program_log` VALUES ('61','1','Valve 5','V','5','2016-06-22 11:17:02','2016-06-22 11:18:02','1','5','2','10054521466619036','0');
INSERT INTO `rlb_custom_program_log` VALUES ('62','1','Pump 1','PS','1','2016-06-22 11:18:02','2016-06-22 12:18:02','1','6','1','10054521466619036','0');
INSERT INTO `rlb_custom_program_log` VALUES ('63','1','Relay 15','R','15','2016-06-22 11:18:02','2016-06-22 12:18:02','1','6','1','10054521466619036','0');
INSERT INTO `rlb_custom_program_log` VALUES ('64','1','Valve 0','V','0','2016-06-22 11:20:02','2016-06-22 11:21:02','1','1','2','10054521466619036','1');
INSERT INTO `rlb_custom_program_log` VALUES ('65','1','Valve 3','V','3','2016-06-22 11:21:02','2016-06-22 11:22:02','1','2','2','10054521466619036','1');
INSERT INTO `rlb_custom_program_log` VALUES ('66','1','Valve 4','V','4','2016-06-22 11:22:02','2016-06-22 11:23:02','1','3','1','10054521466619036','1');
INSERT INTO `rlb_custom_program_log` VALUES ('67','1','Valve 4','V','4','2016-06-22 11:23:02','2016-06-22 11:24:02','1','4','2','10054521466619036','1');
INSERT INTO `rlb_custom_program_log` VALUES ('68','1','Valve 5','V','5','2016-06-22 11:24:02','2016-06-22 11:25:02','1','5','2','10054521466619036','1');
INSERT INTO `rlb_custom_program_log` VALUES ('69','2','Valve 4','V','4','2016-06-22 11:27:41','2016-06-22 11:28:41','1','1','1','28135331466620061','0');
INSERT INTO `rlb_custom_program_log` VALUES ('70','2','Valve 5','V','5','2016-06-22 11:29:01','2016-06-22 11:30:01','1','2','1','28135331466620061','0');
INSERT INTO `rlb_custom_program_log` VALUES ('71','2','Valve 6','V','6','2016-06-22 11:30:01','2016-06-22 11:31:01','1','3','1','28135331466620061','0');
INSERT INTO `rlb_custom_program_log` VALUES ('72','2','Valve 0','V','0','2016-06-22 11:31:01','2016-06-22 11:32:01','1','4','2','28135331466620061','0');
INSERT INTO `rlb_custom_program_log` VALUES ('73','2','Valve 3','V','3','2016-06-22 11:32:02','2016-06-22 11:33:02','1','5','2','28135331466620061','0');
INSERT INTO `rlb_custom_program_log` VALUES ('74','2','Valve 4','V','4','2016-06-22 11:33:02','2016-06-22 11:34:02','1','6','2','28135331466620061','0');
INSERT INTO `rlb_custom_program_log` VALUES ('75','2','Valve 5','V','5','2016-06-22 11:34:02','2016-06-22 11:35:02','1','7','2','28135331466620061','0');
INSERT INTO `rlb_custom_program_log` VALUES ('76','2','Pump 1','PS','1','2016-06-22 11:35:02','2016-06-22 11:36:02','1','8','1','28135331466620061','0');
INSERT INTO `rlb_custom_program_log` VALUES ('77','2','Pump 2','PS','2','2016-06-22 11:35:02','2016-06-22 11:36:02','1','8','1','28135331466620061','0');
INSERT INTO `rlb_custom_program_log` VALUES ('78','2','Pump 2','PS','2','2016-06-22 11:35:02','2016-06-22 11:36:02','1','8','1','28135331466620061','0');
INSERT INTO `rlb_custom_program_log` VALUES ('79','2','Relay 6','R','6','2016-06-22 11:36:03','2016-06-22 11:37:03','1','9','1','28135331466620061','0');
INSERT INTO `rlb_custom_program_log` VALUES ('80','2','Valve 4','V','4','2016-06-22 11:38:02','2016-06-22 11:39:02','1','1','1','28135331466620061','1');
INSERT INTO `rlb_custom_program_log` VALUES ('81','2','Valve 4','V','4','2016-06-22 11:41:17','2016-06-22 11:42:17','1','1','1','81358431466620877','0');
INSERT INTO `rlb_custom_program_log` VALUES ('82','2','Valve 5','V','5','2016-06-22 11:43:02','2016-06-22 11:44:02','1','2','1','81358431466620877','0');
INSERT INTO `rlb_custom_program_log` VALUES ('83','2','Valve 6','V','6','2016-06-22 11:44:02','2016-06-22 11:45:02','1','3','1','81358431466620877','0');
INSERT INTO `rlb_custom_program_log` VALUES ('84','2','Valve 0','V','0','2016-06-22 11:45:02','2016-06-22 11:46:02','1','4','2','81358431466620877','0');
INSERT INTO `rlb_custom_program_log` VALUES ('85','2','Valve 3','V','3','2016-06-22 11:46:02','2016-06-22 11:47:02','1','5','2','81358431466620877','0');
INSERT INTO `rlb_custom_program_log` VALUES ('86','2','Valve 4','V','4','2016-06-22 11:47:02','2016-06-22 11:48:02','1','6','2','81358431466620877','0');
INSERT INTO `rlb_custom_program_log` VALUES ('87','2','Valve 5','V','5','2016-06-22 11:48:02','2016-06-22 11:49:02','1','7','2','81358431466620877','0');
INSERT INTO `rlb_custom_program_log` VALUES ('88','2','Pump 1','PS','1','2016-06-22 11:49:02','2016-06-22 11:50:02','1','8','1','81358431466620877','0');
INSERT INTO `rlb_custom_program_log` VALUES ('89','2','Pump 2','PS','2','2016-06-22 11:49:03','2016-06-22 11:50:03','1','8','1','81358431466620877','0');
INSERT INTO `rlb_custom_program_log` VALUES ('90','2','Pump 2','PS','2','2016-06-22 11:49:03','2016-06-22 11:50:03','1','8','1','81358431466620877','0');
INSERT INTO `rlb_custom_program_log` VALUES ('91','2','Valve 2','V','2','2016-06-22 11:49:03','2016-06-22 11:50:03','1','8','2','81358431466620877','0');
INSERT INTO `rlb_custom_program_log` VALUES ('92','2','Valve 4','V','4','2016-06-22 11:51:02','2016-06-22 11:52:02','1','1','1','81358431466620877','1');
INSERT INTO `rlb_custom_program_log` VALUES ('93','2','Valve 5','V','5','2016-06-22 11:52:02','2016-06-22 11:53:02','1','2','1','81358431466620877','1');
INSERT INTO `rlb_custom_program_log` VALUES ('94','2','Valve 6','V','6','2016-06-22 11:53:02','2016-06-22 11:54:02','1','3','1','81358431466620877','1');
INSERT INTO `rlb_custom_program_log` VALUES ('95','2','Valve 0','V','0','2016-06-22 11:54:02','2016-06-22 11:55:02','1','4','2','81358431466620877','1');
INSERT INTO `rlb_custom_program_log` VALUES ('96','2','Valve 3','V','3','2016-06-22 11:55:02','2016-06-22 11:56:02','1','5','2','81358431466620877','1');
INSERT INTO `rlb_custom_program_log` VALUES ('97','2','Valve 4','V','4','2016-06-22 11:56:02','2016-06-22 11:57:02','1','6','2','81358431466620877','1');
INSERT INTO `rlb_custom_program_log` VALUES ('98','2','Valve 5','V','5','2016-06-22 11:57:02','2016-06-22 11:58:02','1','7','2','81358431466620877','1');
INSERT INTO `rlb_custom_program_log` VALUES ('99','2','Valve 5','V','5','2016-06-22 11:58:02','2016-06-22 11:59:02','1','2','1','81358431466620877','1');
INSERT INTO `rlb_custom_program_log` VALUES ('100','2','Valve 6','V','6','2016-06-22 11:59:02','2016-06-22 12:00:02','1','3','1','81358431466620877','1');
INSERT INTO `rlb_custom_program_log` VALUES ('101','2','Valve 4','V','4','2016-06-22 12:04:09','2016-06-22 12:05:09','1','1','1','99767521466622246','0');
INSERT INTO `rlb_custom_program_log` VALUES ('102','2','Valve 5','V','5','2016-06-22 12:06:02','2016-06-22 12:07:02','1','2','1','99767521466622246','0');
INSERT INTO `rlb_custom_program_log` VALUES ('103','2','Valve 6','V','6','2016-06-22 12:08:04','2016-06-22 12:09:04','1','3','1','99767521466622246','0');
INSERT INTO `rlb_custom_program_log` VALUES ('104','2','Valve 0','V','0','2016-06-22 12:10:03','2016-06-22 12:11:03','1','4','2','99767521466622246','0');
INSERT INTO `rlb_custom_program_log` VALUES ('105','2','Valve 2','V','2','2016-06-22 12:12:02','2016-06-22 12:13:02','1','5','2','99767521466622246','0');
INSERT INTO `rlb_custom_program_log` VALUES ('106','2','Valve 3','V','3','2016-06-22 12:13:02','2016-06-22 12:14:02','1','6','2','99767521466622246','0');
INSERT INTO `rlb_custom_program_log` VALUES ('107','2','Valve 4','V','4','2016-06-22 12:14:02','2016-06-22 12:15:02','1','7','2','99767521466622246','0');
INSERT INTO `rlb_custom_program_log` VALUES ('108','2','Valve 5','V','5','2016-06-22 12:15:02','2016-06-22 12:16:02','1','8','2','99767521466622246','0');
INSERT INTO `rlb_custom_program_log` VALUES ('109','2','Pump 1','PS','1','2016-06-22 12:16:03','2016-06-22 12:17:03','1','10','1','99767521466622246','0');
INSERT INTO `rlb_custom_program_log` VALUES ('110','2','Pump 2','PS','2','2016-06-22 12:16:03','2016-06-22 12:17:03','1','10','1','99767521466622246','0');
INSERT INTO `rlb_custom_program_log` VALUES ('111','2','Pump 2','PS','2','2016-06-22 12:16:03','2016-06-22 12:17:03','1','10','1','99767521466622246','0');
INSERT INTO `rlb_custom_program_log` VALUES ('112','2','Relay 6','R','6','2016-06-22 12:18:03','2016-06-22 12:19:03','1','11','1','99767521466622246','0');
INSERT INTO `rlb_custom_program_log` VALUES ('113','2','Valve 4','V','4','2016-06-22 12:20:03','2016-06-22 12:21:03','1','1','1','99767521466622246','1');
INSERT INTO `rlb_custom_program_log` VALUES ('114','2','Valve 5','V','5','2016-06-22 12:22:02','2016-06-22 12:23:02','1','2','1','99767521466622246','1');
INSERT INTO `rlb_custom_program_log` VALUES ('115','2','Valve 6','V','6','2016-06-22 12:23:02','2016-06-22 12:24:02','1','3','1','99767521466622246','1');
INSERT INTO `rlb_custom_program_log` VALUES ('116','2','Valve 0','V','0','2016-06-22 12:24:02','2016-06-22 12:25:02','1','4','2','99767521466622246','1');
INSERT INTO `rlb_custom_program_log` VALUES ('117','2','Valve 2','V','2','2016-06-22 12:25:02','2016-06-22 12:26:02','1','5','2','99767521466622246','1');
INSERT INTO `rlb_custom_program_log` VALUES ('118','2','Valve 3','V','3','2016-06-22 12:26:02','2016-06-22 12:27:02','1','6','2','99767521466622246','1');
INSERT INTO `rlb_custom_program_log` VALUES ('119','2','Valve 4','V','4','2016-06-22 12:27:02','2016-06-22 12:28:02','1','7','2','99767521466622246','1');
INSERT INTO `rlb_custom_program_log` VALUES ('120','2','Valve 5','V','5','2016-06-22 12:28:02','2016-06-22 12:29:02','1','8','2','99767521466622246','1');
INSERT INTO `rlb_custom_program_log` VALUES ('121','2','Valve 4','V','4','2016-06-22 12:41:17','2016-06-22 12:42:17','1','1','1','66604331466624475','0');
INSERT INTO `rlb_custom_program_log` VALUES ('122','2','Valve 5','V','5','2016-06-22 12:43:05','2016-06-22 12:44:05','1','2','1','66604331466624475','0');
INSERT INTO `rlb_custom_program_log` VALUES ('123','2','Valve 6','V','6','2016-06-22 12:45:02','2016-06-22 12:46:02','1','3','1','66604331466624475','0');
INSERT INTO `rlb_custom_program_log` VALUES ('124','2','Valve 0','V','0','2016-06-22 12:47:02','2016-06-22 12:48:02','1','4','2','66604331466624475','0');
INSERT INTO `rlb_custom_program_log` VALUES ('125','2','Valve 2','V','2','2016-06-22 12:48:02','2016-06-22 12:49:02','1','5','2','66604331466624475','0');
INSERT INTO `rlb_custom_program_log` VALUES ('126','2','Valve 3','V','3','2016-06-22 12:49:02','2016-06-22 12:50:02','1','6','2','66604331466624475','0');
INSERT INTO `rlb_custom_program_log` VALUES ('127','2','Valve 4','V','4','2016-06-22 12:50:02','2016-06-22 12:51:02','1','7','2','66604331466624475','0');
INSERT INTO `rlb_custom_program_log` VALUES ('128','2','Valve 5','V','5','2016-06-22 12:52:02','2016-06-22 12:53:02','1','8','2','66604331466624475','0');
INSERT INTO `rlb_custom_program_log` VALUES ('129','2','Pump 1','PS','1','2016-06-22 12:53:02','2016-06-22 14:23:02','1','10','1','66604331466624475','0');
INSERT INTO `rlb_custom_program_log` VALUES ('130','2','Pump 2','PS','2','2016-06-22 12:53:03','2016-06-22 14:23:03','1','10','1','66604331466624475','0');
INSERT INTO `rlb_custom_program_log` VALUES ('131','2','Pump 2','PS','2','2016-06-22 12:53:03','2016-06-22 14:23:03','1','10','1','66604331466624475','0');
INSERT INTO `rlb_custom_program_log` VALUES ('132','2','Valve 4','V','4','2016-06-22 13:05:02','2016-06-22 13:06:02','1','1','1','66604331466624475','1');
INSERT INTO `rlb_custom_program_log` VALUES ('133','2','Valve 5','V','5','2016-06-22 13:06:02','2016-06-22 13:07:02','1','2','1','66604331466624475','1');
INSERT INTO `rlb_custom_program_log` VALUES ('134','2','Valve 6','V','6','2016-06-22 13:07:02','2016-06-22 13:08:02','1','3','1','66604331466624475','1');
INSERT INTO `rlb_custom_program_log` VALUES ('135','2','Valve 0','V','0','2016-06-22 13:08:02','2016-06-22 13:09:02','1','4','2','66604331466624475','1');
INSERT INTO `rlb_custom_program_log` VALUES ('136','2','Valve 2','V','2','2016-06-22 13:09:02','2016-06-22 13:10:02','1','5','2','66604331466624475','1');
INSERT INTO `rlb_custom_program_log` VALUES ('137','2','Valve 3','V','3','2016-06-22 13:10:02','2016-06-22 13:11:02','1','6','2','66604331466624475','1');
INSERT INTO `rlb_custom_program_log` VALUES ('138','2','Valve 4','V','4','2016-06-22 14:09:36','2016-06-22 14:10:36','1','1','1','25134891466629775','0');
INSERT INTO `rlb_custom_program_log` VALUES ('139','2','Valve 5','V','5','2016-06-22 14:11:02','2016-06-22 14:12:02','1','2','1','25134891466629775','0');
INSERT INTO `rlb_custom_program_log` VALUES ('140','2','Valve 6','V','6','2016-06-22 14:12:02','2016-06-22 14:13:02','1','3','1','25134891466629775','0');
INSERT INTO `rlb_custom_program_log` VALUES ('141','2','Valve 0','V','0','2016-06-22 14:13:02','2016-06-22 14:14:02','1','4','2','25134891466629775','0');
INSERT INTO `rlb_custom_program_log` VALUES ('142','2','Valve 2','V','2','2016-06-22 14:15:02','2016-06-22 14:16:02','1','5','2','25134891466629775','0');
INSERT INTO `rlb_custom_program_log` VALUES ('143','2','Valve 3','V','3','2016-06-22 14:16:02','2016-06-22 14:17:02','1','6','2','25134891466629775','0');
INSERT INTO `rlb_custom_program_log` VALUES ('144','2','Valve 4','V','4','2016-06-22 14:17:02','2016-06-22 14:18:02','1','7','2','25134891466629775','0');
INSERT INTO `rlb_custom_program_log` VALUES ('145','2','Valve 5','V','5','2016-06-22 14:18:03','2016-06-22 14:19:03','1','8','2','25134891466629775','0');
INSERT INTO `rlb_custom_program_log` VALUES ('146','2','Pump 1','PS','1','2016-06-22 14:19:05','2016-06-22 15:49:05','1','10','1','25134891466629775','0');
INSERT INTO `rlb_custom_program_log` VALUES ('147','2','Pump 2','PS','2','2016-06-22 14:19:07','2016-06-22 15:49:07','1','10','1','25134891466629775','0');
INSERT INTO `rlb_custom_program_log` VALUES ('148','2','Pump 2','PS','2','2016-06-22 14:19:07','2016-06-22 15:49:07','1','10','1','25134891466629775','0');
INSERT INTO `rlb_custom_program_log` VALUES ('149','2','Valve 4','V','4','2016-06-22 15:29:02','2016-06-22 15:30:02','1','1','1','25134891466629775','1');
INSERT INTO `rlb_custom_program_log` VALUES ('150','2','Valve 5','V','5','2016-06-22 15:30:02','2016-06-22 15:31:02','1','2','1','25134891466629775','1');
INSERT INTO `rlb_custom_program_log` VALUES ('151','2','Valve 6','V','6','2016-06-22 15:31:02','2016-06-22 15:32:02','1','3','1','25134891466629775','1');
INSERT INTO `rlb_custom_program_log` VALUES ('152','2','Valve 0','V','0','2016-06-22 15:32:02','2016-06-22 15:33:02','1','4','2','25134891466629775','1');
INSERT INTO `rlb_custom_program_log` VALUES ('153','2','Valve 2','V','2','2016-06-22 15:33:02','2016-06-22 15:34:02','1','5','2','25134891466629775','1');
INSERT INTO `rlb_custom_program_log` VALUES ('154','1','Valve 0','V','0','2016-06-22 15:37:04','2016-06-22 15:38:04','1','1','2','34382601466635023','0');
INSERT INTO `rlb_custom_program_log` VALUES ('155','1','Valve 3','V','3','2016-06-22 15:39:02','2016-06-22 15:40:02','1','2','2','34382601466635023','0');
INSERT INTO `rlb_custom_program_log` VALUES ('156','1','Valve 4','V','4','2016-06-22 15:40:02','2016-06-22 15:41:02','1','3','1','34382601466635023','0');
INSERT INTO `rlb_custom_program_log` VALUES ('157','1','Valve 4','V','4','2016-06-22 15:41:02','2016-06-22 15:42:02','1','4','2','34382601466635023','0');
INSERT INTO `rlb_custom_program_log` VALUES ('158','1','Valve 5','V','5','2016-06-22 15:42:02','2016-06-22 15:43:02','1','5','2','34382601466635023','0');
INSERT INTO `rlb_custom_program_log` VALUES ('159','1','Valve 0','V','0','2016-06-22 15:51:14','2016-06-22 15:52:14','1','1','2','81736201466635874','0');
INSERT INTO `rlb_custom_program_log` VALUES ('160','1','Valve 3','V','3','2016-06-22 15:53:01','2016-06-22 15:54:01','1','2','2','81736201466635874','0');
INSERT INTO `rlb_custom_program_log` VALUES ('161','1','Valve 0','V','0','2016-06-22 15:59:17','2016-06-22 16:00:17','1','1','2','90924281466636356','0');
INSERT INTO `rlb_custom_program_log` VALUES ('162','1','Valve 3','V','3','2016-06-22 16:01:02','2016-06-22 16:02:02','1','2','2','90924281466636356','0');
INSERT INTO `rlb_custom_program_log` VALUES ('163','1','Valve 4','V','4','2016-06-22 16:02:02','2016-06-22 16:03:02','1','3','1','90924281466636356','0');
INSERT INTO `rlb_custom_program_log` VALUES ('164','1','Valve 4','V','4','2016-06-22 16:03:02','2016-06-22 16:04:02','1','4','2','90924281466636356','0');
INSERT INTO `rlb_custom_program_log` VALUES ('165','1','Valve 5','V','5','2016-06-22 16:04:02','2016-06-22 16:05:02','1','5','2','90924281466636356','0');
INSERT INTO `rlb_custom_program_log` VALUES ('166','1','Valve 0','V','0','2016-06-22 16:12:51','2016-06-22 16:13:51','1','1','2','37059441466637170','0');
INSERT INTO `rlb_custom_program_log` VALUES ('167','1','Valve 0','V','0','2016-06-22 16:14:02','2016-06-22 16:15:02','1','1','2','37059441466637170','1');
INSERT INTO `rlb_custom_program_log` VALUES ('168','1','Valve 3','V','3','2016-06-22 16:15:02','2016-06-22 16:16:02','1','2','2','37059441466637170','1');
INSERT INTO `rlb_custom_program_log` VALUES ('169','1','Valve 4','V','4','2016-06-22 16:16:03','2016-06-22 16:17:03','1','3','1','37059441466637170','1');
INSERT INTO `rlb_custom_program_log` VALUES ('170','1','Valve 4','V','4','2016-06-22 16:18:02','2016-06-22 16:19:02','1','4','2','37059441466637170','1');
INSERT INTO `rlb_custom_program_log` VALUES ('171','1','Valve 5','V','5','2016-06-22 16:19:02','2016-06-22 16:20:02','1','5','2','37059441466637170','1');
INSERT INTO `rlb_custom_program_log` VALUES ('172','3','Pump 1','PS','1','2016-06-23 03:13:16','2016-06-23 03:14:16','1','1','1','92425531466676790','0');
INSERT INTO `rlb_custom_program_log` VALUES ('173','3','Pump 1','PS','1','2016-06-23 03:31:34','2016-06-23 03:32:34','1','1','1','92425531466676791','0');
INSERT INTO `rlb_custom_program_log` VALUES ('174','3','Valve 0','V','0','2016-06-23 03:34:21','2016-06-23 03:35:21','1','2','1','92425531466676791','0');
INSERT INTO `rlb_custom_program_log` VALUES ('175','3','Relay 6','R','6','2016-06-23 03:48:54','2016-06-23 03:53:54','1','3','1','92425531466676791','0');
INSERT INTO `rlb_custom_program_log` VALUES ('176','3','Power Center 0','P','0','2016-06-23 03:48:55','2016-06-23 03:53:55','1','3','1','92425531466676791','0');
INSERT INTO `rlb_custom_program_log` VALUES ('177','3','Pump 1','PS','1','2016-06-23 05:05:20','2016-06-23 05:06:20','1','1','1','97496391466683517','0');
INSERT INTO `rlb_custom_program_log` VALUES ('178','3','Valve 0','V','0','2016-06-23 05:08:06','2016-06-23 05:09:06','1','2','1','97496391466683517','0');
INSERT INTO `rlb_custom_program_log` VALUES ('179','3','Relay 6','R','6','2016-06-23 05:10:02','2016-06-23 05:10:02','1','3','1','97496391466683517','0');
INSERT INTO `rlb_custom_program_log` VALUES ('180','3','Power Center 0','P','0','2016-06-23 05:11:02','2016-06-23 05:11:02','1','4','1','97496391466683517','0');
INSERT INTO `rlb_custom_program_log` VALUES ('181','3','Pump 1','PS','1','2016-06-23 05:16:26','2016-06-23 05:17:26','1','1','1','38308181466684184','0');
INSERT INTO `rlb_custom_program_log` VALUES ('182','3','Pump 1','PS','1','2016-06-23 05:21:47','2016-06-23 05:22:47','1','1','1','36490781466684506','0');
INSERT INTO `rlb_custom_program_log` VALUES ('183','1','Valve 0','V','0','2016-06-23 09:37:31','2016-06-23 09:38:31','1','1','2','22995911466699850','0');
INSERT INTO `rlb_custom_program_log` VALUES ('184','1','Valve 3','V','3','2016-06-23 09:39:02','2016-06-23 09:40:02','1','2','2','22995911466699850','0');
INSERT INTO `rlb_custom_program_log` VALUES ('185','1','Valve 4','V','4','2016-06-23 09:40:03','2016-06-23 09:41:03','1','3','1','22995911466699850','0');
INSERT INTO `rlb_custom_program_log` VALUES ('186','1','Valve 4','V','4','2016-06-23 09:42:02','2016-06-23 09:43:02','1','4','2','22995911466699850','0');
INSERT INTO `rlb_custom_program_log` VALUES ('187','1','Valve 5','V','5','2016-06-23 09:43:02','2016-06-23 09:44:02','1','5','2','22995911466699850','0');
INSERT INTO `rlb_custom_program_log` VALUES ('188','1','Valve 0','V','0','2016-06-23 09:45:02','2016-06-23 09:46:02','1','1','2','22995911466699850','0');
INSERT INTO `rlb_custom_program_log` VALUES ('189','1','Valve 3','V','3','2016-06-23 09:46:02','2016-06-23 09:47:02','1','1','2','22995911466699850','1');
INSERT INTO `rlb_custom_program_log` VALUES ('190','1','Valve 5','V','5','2016-06-23 09:47:02','2016-06-23 09:48:02','1','5','2','22995911466699850','1');
INSERT INTO `rlb_custom_program_log` VALUES ('191','1','Valve 0','V','0','2016-06-23 09:49:59','2016-06-23 09:50:59','1','1','2','84483801466700598','0');
INSERT INTO `rlb_custom_program_log` VALUES ('192','1','Valve 3','V','3','2016-06-23 09:51:02','2016-06-23 09:52:02','1','2','2','84483801466700598','0');
INSERT INTO `rlb_custom_program_log` VALUES ('193','1','Valve 4','V','4','2016-06-23 09:52:02','2016-06-23 09:53:02','1','3','1','84483801466700598','0');
INSERT INTO `rlb_custom_program_log` VALUES ('194','1','Valve 4','V','4','2016-06-23 09:53:02','2016-06-23 09:54:02','1','4','2','84483801466700598','0');
INSERT INTO `rlb_custom_program_log` VALUES ('195','1','Valve 5','V','5','2016-06-23 09:54:02','2016-06-23 09:55:02','1','5','2','84483801466700598','0');
INSERT INTO `rlb_custom_program_log` VALUES ('196','1','Valve 0','V','0','2016-06-23 09:56:02','2016-06-23 09:57:02','1','1','2','84483801466700598','0');
INSERT INTO `rlb_custom_program_log` VALUES ('197','1','Valve 3','V','3','2016-06-23 09:57:02','2016-06-23 09:58:02','1','1','2','84483801466700598','1');
INSERT INTO `rlb_custom_program_log` VALUES ('198','1','Valve 5','V','5','2016-06-23 09:58:02','2016-06-23 09:59:02','1','5','2','84483801466700598','1');
INSERT INTO `rlb_custom_program_log` VALUES ('199','1','Valve 0','V','0','2016-06-23 10:17:58','2016-06-23 10:18:58','1','1','2','89742981466702278','0');
INSERT INTO `rlb_custom_program_log` VALUES ('200','1','Valve 3','V','3','2016-06-23 10:19:02','2016-06-23 10:20:02','1','2','2','89742981466702278','0');
INSERT INTO `rlb_custom_program_log` VALUES ('201','1','Valve 4','V','4','2016-06-23 10:20:02','2016-06-23 10:21:02','1','3','1','89742981466702278','0');
INSERT INTO `rlb_custom_program_log` VALUES ('202','1','Valve 4','V','4','2016-06-23 10:22:02','2016-06-23 10:23:02','1','4','2','89742981466702278','0');
INSERT INTO `rlb_custom_program_log` VALUES ('203','1','Valve 5','V','5','2016-06-23 10:23:03','2016-06-23 10:24:03','1','5','2','89742981466702278','0');
INSERT INTO `rlb_custom_program_log` VALUES ('204','1','Pump 1','PS','1','2016-06-23 10:25:02','2016-06-23 11:25:02','1','6','1','89742981466702278','0');
INSERT INTO `rlb_custom_program_log` VALUES ('205','1','Power Center 0','P','0','2016-06-23 10:25:02','2016-06-23 11:25:02','1','6','1','89742981466702278','0');
INSERT INTO `rlb_custom_program_log` VALUES ('206','1','Valve 0','V','0','2016-06-23 10:30:09','2016-06-23 10:31:09','1','1','2','55988771466703008','0');
INSERT INTO `rlb_custom_program_log` VALUES ('207','1','Valve 3','V','3','2016-06-23 10:32:02','2016-06-23 10:33:02','1','2','2','55988771466703008','0');
INSERT INTO `rlb_custom_program_log` VALUES ('208','1','Valve 4','V','4','2016-06-23 10:33:02','2016-06-23 10:34:02','1','3','1','55988771466703008','0');
INSERT INTO `rlb_custom_program_log` VALUES ('209','1','Valve 4','V','4','2016-06-23 10:34:02','2016-06-23 10:35:02','1','4','2','55988771466703008','0');
INSERT INTO `rlb_custom_program_log` VALUES ('210','1','Valve 5','V','5','2016-06-23 10:35:02','2016-06-23 10:36:02','1','5','2','55988771466703008','0');
INSERT INTO `rlb_custom_program_log` VALUES ('211','1','Valve 0','V','0','2016-06-23 10:36:10','2016-06-23 10:37:10','1','1','2','86783131466703369','0');
INSERT INTO `rlb_custom_program_log` VALUES ('212','1','Valve 3','V','3','2016-06-23 10:38:02','2016-06-23 10:39:02','1','2','2','86783131466703369','0');
INSERT INTO `rlb_custom_program_log` VALUES ('213','1','Valve 4','V','4','2016-06-23 10:39:02','2016-06-23 10:40:02','1','3','1','86783131466703369','0');
INSERT INTO `rlb_custom_program_log` VALUES ('214','1','Valve 4','V','4','2016-06-23 10:40:02','2016-06-23 10:41:02','1','4','2','86783131466703369','0');
INSERT INTO `rlb_custom_program_log` VALUES ('215','1','Valve 5','V','5','2016-06-23 10:41:02','2016-06-23 10:42:02','1','5','2','86783131466703369','0');
INSERT INTO `rlb_custom_program_log` VALUES ('216','1','Valve 0','V','0','2016-06-23 10:43:02','2016-06-23 10:44:02','1','1','2','86783131466703369','0');
INSERT INTO `rlb_custom_program_log` VALUES ('217','1','Valve 3','V','3','2016-06-23 10:44:02','2016-06-23 10:45:02','1','1','2','86783131466703369','1');
INSERT INTO `rlb_custom_program_log` VALUES ('218','1','Valve 5','V','5','2016-06-23 10:45:02','2016-06-23 10:46:02','1','5','2','86783131466703369','1');
INSERT INTO `rlb_custom_program_log` VALUES ('219','1','Valve 0','V','0','2016-06-23 10:52:20','2016-06-23 10:53:20','1','1','2','39688921466704340','0');
INSERT INTO `rlb_custom_program_log` VALUES ('220','1','Valve 3','V','3','2016-06-23 10:54:02','2016-06-23 10:55:02','1','2','2','39688921466704340','0');
INSERT INTO `rlb_custom_program_log` VALUES ('221','1','Valve 4','V','4','2016-06-23 10:55:03','2016-06-23 10:56:03','1','3','1','39688921466704340','0');
INSERT INTO `rlb_custom_program_log` VALUES ('222','1','Valve 4','V','4','2016-06-23 10:56:03','2016-06-23 10:57:03','1','4','2','39688921466704340','0');
INSERT INTO `rlb_custom_program_log` VALUES ('223','1','Valve 5','V','5','2016-06-23 10:58:02','2016-06-23 10:59:02','1','5','2','39688921466704340','0');
INSERT INTO `rlb_custom_program_log` VALUES ('224','1','Pump 1','PS','1','2016-06-23 10:59:04','2016-06-23 11:59:04','1','6','1','39688921466704340','0');
INSERT INTO `rlb_custom_program_log` VALUES ('225','1','Pump 2','PS','2','2016-06-23 10:59:04','2016-06-23 11:54:04','1','6','1','39688921466704340','0');
INSERT INTO `rlb_custom_program_log` VALUES ('226','1','Relay 15','R','15','2016-06-23 10:59:04','2016-06-23 11:54:04','1','6','1','39688921466704340','0');
INSERT INTO `rlb_custom_program_log` VALUES ('227','1','Pump 1','PS','1','2016-06-23 10:59:04','2016-06-23 11:59:04','1','6','1','39688921466704340','0');
INSERT INTO `rlb_custom_program_log` VALUES ('228','1','Power Center 0','P','0','2016-06-23 10:59:04','2016-06-23 11:59:04','1','6','1','39688921466704340','0');
INSERT INTO `rlb_custom_program_log` VALUES ('229','1','Valve 3','V','3','2016-06-23 12:00:02','2016-06-23 12:01:02','1','1','2','39688921466704340','1');
INSERT INTO `rlb_custom_program_log` VALUES ('230','1','Valve 5','V','5','2016-06-23 12:01:02','2016-06-23 12:02:02','1','5','2','39688921466704340','1');
INSERT INTO `rlb_custom_program_log` VALUES ('231','3','Power Center 1','P','1','2016-06-24 03:28:12','2016-06-24 03:29:12','1','1','1','89298801466764092','0');
INSERT INTO `rlb_custom_program_log` VALUES ('232','3','Power Center 2','P','2','2016-06-24 03:28:13','2016-06-24 03:29:13','1','1','1','89298801466764092','0');
INSERT INTO `rlb_custom_program_log` VALUES ('233','3','Power Center 2','P','2','2016-06-24 03:28:13','2016-06-24 03:29:13','1','1','1','89298801466764092','0');
INSERT INTO `rlb_custom_program_log` VALUES ('234','3','Relay 14','R','14','2016-06-24 03:30:03','2016-06-24 03:31:03','1','2','1','89298801466764092','0');
INSERT INTO `rlb_custom_program_log` VALUES ('235','3','Power Center 1','P','1','2016-06-24 03:33:02','2016-06-24 03:34:02','1','1','1','89298801466764092','0');
INSERT INTO `rlb_custom_program_log` VALUES ('236','3','Power Center 2','P','2','2016-06-24 03:33:02','2016-06-24 03:34:02','1','1','1','89298801466764092','0');
INSERT INTO `rlb_custom_program_log` VALUES ('237','3','Power Center 2','P','2','2016-06-24 03:33:02','2016-06-24 03:34:02','1','1','1','89298801466764092','0');
INSERT INTO `rlb_custom_program_log` VALUES ('238','3','Power Center 0','P','0','2016-06-24 03:47:34','2016-06-24 03:48:34','1','1','1','8929880146676409211','0');
INSERT INTO `rlb_custom_program_log` VALUES ('239','3','Power Center 0','P','0','2016-06-24 04:41:00','2016-06-24 04:42:00','1','1','1','35523011466768460','0');
INSERT INTO `rlb_custom_program_log` VALUES ('240','3','Relay 6','R','6','2016-06-24 04:42:33','2016-06-24 04:43:33','1','2','1','35523011466768460','0');
INSERT INTO `rlb_custom_program_log` VALUES ('241','3','Pump 2','PS','2','2016-06-24 05:07:49','2016-06-24 05:08:49','1','3','1','35523011466768460','0');
INSERT INTO `rlb_custom_program_log` VALUES ('242','3','Pump 1','PS','1','2016-06-24 05:09:18','2016-06-24 05:10:18','1','4','1','35523011466768460','0');
INSERT INTO `rlb_custom_program_log` VALUES ('243','3','Power Center 0','P','0','2016-06-24 05:15:09','2016-06-24 05:16:09','1','1','1','40389111466770509','0');
INSERT INTO `rlb_custom_program_log` VALUES ('244','3','Relay 6','R','6','2016-06-24 05:17:02','2016-06-24 05:18:02','1','2','1','40389111466770509','0');
INSERT INTO `rlb_custom_program_log` VALUES ('245','3','Pump 2','PS','2','2016-06-24 05:18:03','2016-06-24 05:28:03','1','3','1','40389111466770509','0');
INSERT INTO `rlb_custom_program_log` VALUES ('246','3','Pump 1','PS','1','2016-06-24 05:29:02','2016-06-24 05:39:02','1','4','1','40389111466770509','0');
INSERT INTO `rlb_custom_program_log` VALUES ('247','1','Valve 0','V','0','2016-06-27 09:29:35','2016-06-27 09:30:35','1','1','2','43834421467044975','0');
INSERT INTO `rlb_custom_program_log` VALUES ('248','1','Valve 3','V','3','2016-06-27 09:31:02','2016-06-27 09:32:02','1','2','2','43834421467044975','0');
INSERT INTO `rlb_custom_program_log` VALUES ('249','1','Valve 4','V','4','2016-06-27 09:32:02','2016-06-27 09:33:02','1','3','1','43834421467044975','0');
INSERT INTO `rlb_custom_program_log` VALUES ('250','1','Valve 4','V','4','2016-06-27 09:33:02','2016-06-27 09:34:02','1','4','2','43834421467044975','0');
INSERT INTO `rlb_custom_program_log` VALUES ('251','1','Valve 5','V','5','2016-06-27 09:34:02','2016-06-27 09:35:02','1','5','2','43834421467044975','0');
INSERT INTO `rlb_custom_program_log` VALUES ('252','1','Pump 1','PS','1','2016-06-27 09:35:03','2016-06-27 10:35:03','1','6','1','43834421467044975','0');
INSERT INTO `rlb_custom_program_log` VALUES ('253','1','Pump 2','PS','2','2016-06-27 09:35:03','2016-06-27 10:30:03','1','6','1','43834421467044975','0');
INSERT INTO `rlb_custom_program_log` VALUES ('254','1','Pump 2','PS','2','2016-06-27 09:35:03','2016-06-27 10:30:03','1','6','1','43834421467044975','0');
INSERT INTO `rlb_custom_program_log` VALUES ('255','1','Relay 15','R','15','2016-06-27 09:35:03','2016-06-27 10:30:03','1','6','1','43834421467044975','0');
INSERT INTO `rlb_custom_program_log` VALUES ('256','1','Power Center 0','P','0','2016-06-27 09:35:03','2016-06-27 10:35:03','1','6','1','43834421467044975','0');
INSERT INTO `rlb_custom_program_log` VALUES ('257','1','Valve 3','V','3','2016-06-27 09:40:02','2016-06-27 09:41:02','1','1','2','43834421467044975','1');
INSERT INTO `rlb_custom_program_log` VALUES ('258','1','Valve 4','V','4','2016-06-27 09:41:02','2016-06-27 09:42:02','1','3','1','43834421467044975','1');
INSERT INTO `rlb_custom_program_log` VALUES ('259','1','Valve 0','V','0','2016-06-27 09:49:38','2016-06-27 09:50:38','1','1','2','44708561467046176','0');
INSERT INTO `rlb_custom_program_log` VALUES ('260','1','Valve 3','V','3','2016-06-27 09:51:02','2016-06-27 09:52:02','1','2','2','44708561467046176','0');
INSERT INTO `rlb_custom_program_log` VALUES ('261','1','Valve 4','V','4','2016-06-27 09:52:03','2016-06-27 09:53:03','1','3','1','44708561467046176','0');
INSERT INTO `rlb_custom_program_log` VALUES ('262','1','Valve 4','V','4','2016-06-27 09:54:02','2016-06-27 09:55:02','1','4','2','44708561467046176','0');
INSERT INTO `rlb_custom_program_log` VALUES ('263','1','Valve 5','V','5','2016-06-27 09:55:03','2016-06-27 09:56:03','1','5','2','44708561467046176','0');
INSERT INTO `rlb_custom_program_log` VALUES ('264','1','Valve 5','V','5','2016-06-27 09:57:03','2016-06-27 09:58:03','1','6','1','44708561467046176','0');
INSERT INTO `rlb_custom_program_log` VALUES ('265','1','Valve 6','V','6','2016-06-27 09:57:03','2016-06-27 09:58:03','1','6','1','44708561467046176','0');
INSERT INTO `rlb_custom_program_log` VALUES ('266','1','Valve 6','V','6','2016-06-27 09:57:03','2016-06-27 09:58:03','1','6','1','44708561467046176','0');
INSERT INTO `rlb_custom_program_log` VALUES ('267','1','Pump 1','PS','1','2016-06-27 09:59:03','2016-06-27 10:59:03','1','7','1','44708561467046176','0');
INSERT INTO `rlb_custom_program_log` VALUES ('268','1','Pump 2','PS','2','2016-06-27 09:59:03','2016-06-27 10:54:03','1','7','1','44708561467046176','0');
INSERT INTO `rlb_custom_program_log` VALUES ('269','1','Pump 2','PS','2','2016-06-27 09:59:03','2016-06-27 10:54:03','1','7','1','44708561467046176','0');
INSERT INTO `rlb_custom_program_log` VALUES ('270','1','Relay 15','R','15','2016-06-27 09:59:03','2016-06-27 10:54:03','1','7','1','44708561467046176','0');
INSERT INTO `rlb_custom_program_log` VALUES ('271','1','Power Center 0','P','0','2016-06-27 09:59:03','2016-06-27 10:59:03','1','7','1','44708561467046176','0');
INSERT INTO `rlb_custom_program_log` VALUES ('272','1','Valve 4','V','4','2016-06-27 10:10:02','2016-06-27 10:11:02','1','1','1','44708561467046176','1');
INSERT INTO `rlb_custom_program_log` VALUES ('273','1','Valve 0','V','0','2016-06-27 10:29:45','2016-06-27 10:30:45','1','1','2','98075381467048585','0');
INSERT INTO `rlb_custom_program_log` VALUES ('274','1','Valve 3','V','3','2016-06-27 10:31:02','2016-06-27 10:32:02','1','2','2','98075381467048585','0');
INSERT INTO `rlb_custom_program_log` VALUES ('275','1','Valve 4','V','4','2016-06-27 10:32:02','2016-06-27 10:33:02','1','3','1','98075381467048585','0');
INSERT INTO `rlb_custom_program_log` VALUES ('276','1','Valve 4','V','4','2016-06-27 10:33:02','2016-06-27 10:34:02','1','4','2','98075381467048585','0');
INSERT INTO `rlb_custom_program_log` VALUES ('277','1','Valve 5','V','5','2016-06-27 10:34:02','2016-06-27 10:35:02','1','5','2','98075381467048585','0');
INSERT INTO `rlb_custom_program_log` VALUES ('278','1','Valve 5','V','5','2016-06-27 10:35:02','2016-06-27 10:36:02','1','6','1','98075381467048585','0');
INSERT INTO `rlb_custom_program_log` VALUES ('279','1','Valve 6','V','6','2016-06-27 10:35:02','2016-06-27 10:36:02','1','6','1','98075381467048585','0');
INSERT INTO `rlb_custom_program_log` VALUES ('280','1','Valve 6','V','6','2016-06-27 10:35:02','2016-06-27 10:36:02','1','6','1','98075381467048585','0');
INSERT INTO `rlb_custom_program_log` VALUES ('281','1','Pump 1','PS','1','2016-06-27 10:36:03','2016-06-27 11:36:03','1','7','1','98075381467048585','0');
INSERT INTO `rlb_custom_program_log` VALUES ('282','1','Pump 2','PS','2','2016-06-27 10:36:03','2016-06-27 11:31:03','1','7','1','98075381467048585','0');
INSERT INTO `rlb_custom_program_log` VALUES ('283','1','Pump 2','PS','2','2016-06-27 10:36:03','2016-06-27 11:31:03','1','7','1','98075381467048585','0');
INSERT INTO `rlb_custom_program_log` VALUES ('284','1','Relay 15','R','15','2016-06-27 10:36:03','2016-06-27 11:31:03','1','7','1','98075381467048585','0');
INSERT INTO `rlb_custom_program_log` VALUES ('285','1','Power Center 0','P','0','2016-06-27 10:36:03','2016-06-27 11:31:03','1','7','1','98075381467048585','0');
INSERT INTO `rlb_custom_program_log` VALUES ('286','1','Valve 0','V','0','2016-06-27 10:54:03','2016-06-27 10:55:03','1','1','2','98075381467048585','1');
INSERT INTO `rlb_custom_program_log` VALUES ('287','1','Valve 0','V','0','2016-06-27 10:54:13','2016-06-27 10:55:13','1','1','2','21632711467050052','0');
INSERT INTO `rlb_custom_program_log` VALUES ('288','1','Valve 0','V','0','2016-06-27 10:55:02','2016-06-27 10:56:02','1','1','2','21632711467050052','1');
INSERT INTO `rlb_custom_program_log` VALUES ('289','1','Valve 4','V','4','2016-06-27 10:56:02','2016-06-27 10:57:02','1','3','1','21632711467050052','1');
INSERT INTO `rlb_custom_program_log` VALUES ('290','1','Valve 0','V','0','2016-06-27 11:02:37','2016-06-27 11:03:37','1','1','2','35834431467050556','0');
INSERT INTO `rlb_custom_program_log` VALUES ('291','1','Valve 3','V','3','2016-06-27 11:04:02','2016-06-27 11:05:02','1','2','2','35834431467050556','0');
INSERT INTO `rlb_custom_program_log` VALUES ('292','1','Valve 4','V','4','2016-06-27 11:05:02','2016-06-27 11:06:02','1','3','1','35834431467050556','0');
INSERT INTO `rlb_custom_program_log` VALUES ('293','1','Valve 4','V','4','2016-06-27 11:06:03','2016-06-27 11:07:03','1','4','2','35834431467050556','0');
INSERT INTO `rlb_custom_program_log` VALUES ('294','1','Valve 5','V','5','2016-06-27 11:08:02','2016-06-27 11:09:02','1','5','2','35834431467050556','0');
INSERT INTO `rlb_custom_program_log` VALUES ('295','1','Valve 5','V','5','2016-06-27 11:09:02','2016-06-27 11:10:02','1','6','1','35834431467050556','0');
INSERT INTO `rlb_custom_program_log` VALUES ('296','1','Valve 6','V','6','2016-06-27 11:09:02','2016-06-27 11:10:02','1','6','1','35834431467050556','0');
INSERT INTO `rlb_custom_program_log` VALUES ('297','1','Valve 6','V','6','2016-06-27 11:09:02','2016-06-27 11:10:02','1','6','1','35834431467050556','0');
INSERT INTO `rlb_custom_program_log` VALUES ('298','1','Pump 1','PS','1','2016-06-27 11:10:02','2016-06-27 12:10:02','1','7','1','35834431467050556','0');
INSERT INTO `rlb_custom_program_log` VALUES ('299','1','Pump 2','PS','2','2016-06-27 11:10:03','2016-06-27 12:05:03','1','7','1','35834431467050556','0');
INSERT INTO `rlb_custom_program_log` VALUES ('300','1','Pump 2','PS','2','2016-06-27 11:10:03','2016-06-27 12:05:03','1','7','1','35834431467050556','0');
INSERT INTO `rlb_custom_program_log` VALUES ('301','1','Relay 15','R','15','2016-06-27 11:10:03','2016-06-27 12:05:03','1','7','1','35834431467050556','0');
INSERT INTO `rlb_custom_program_log` VALUES ('302','1','Power Center 0','P','0','2016-06-27 11:10:03','2016-06-27 12:05:03','1','7','1','35834431467050556','0');
INSERT INTO `rlb_custom_program_log` VALUES ('303','1','Valve 0','V','0','2016-06-27 11:12:02','2016-06-27 11:13:02','1','1','2','35834431467050556','1');
INSERT INTO `rlb_custom_program_log` VALUES ('304','1','Valve 4','V','4','2016-06-27 11:13:02','2016-06-27 11:14:02','1','3','1','35834431467050556','1');
INSERT INTO `rlb_custom_program_log` VALUES ('305','6','Valve 1','V','1','2016-06-27 11:17:57','2016-06-27 11:18:57','1','1','2','17412101467051477','0');
INSERT INTO `rlb_custom_program_log` VALUES ('306','6','Valve 5','V','5','2016-06-27 11:19:02','2016-06-27 11:20:02','1','2','1','17412101467051477','0');
INSERT INTO `rlb_custom_program_log` VALUES ('307','6','Valve 6','V','6','2016-06-27 11:19:02','2016-06-27 11:20:02','1','2','1','17412101467051477','0');
INSERT INTO `rlb_custom_program_log` VALUES ('308','6','Valve 6','V','6','2016-06-27 11:19:02','2016-06-27 11:20:02','1','2','1','17412101467051477','0');
INSERT INTO `rlb_custom_program_log` VALUES ('309','6','Pump 2','PS','2','2016-06-27 11:20:02','2016-06-27 11:45:02','1','3','1','17412101467051477','0');
INSERT INTO `rlb_custom_program_log` VALUES ('310','6','Valve 1','V','1','2016-06-27 11:21:02','2016-06-27 11:22:02','1','1','2','17412101467051477','1');
INSERT INTO `rlb_custom_program_log` VALUES ('311','1','Valve 0','V','0','2016-06-27 11:24:37','2016-06-27 11:25:37','1','1','2','99452241467051876','0');
INSERT INTO `rlb_custom_program_log` VALUES ('312','1','Valve 3','V','3','2016-06-27 11:26:02','2016-06-27 11:27:02','1','2','2','99452241467051876','0');
INSERT INTO `rlb_custom_program_log` VALUES ('313','1','Valve 4','V','4','2016-06-27 11:28:02','2016-06-27 11:29:02','1','3','1','99452241467051876','0');
INSERT INTO `rlb_custom_program_log` VALUES ('314','1','Valve 4','V','4','2016-06-27 11:29:03','2016-06-27 11:30:03','1','4','2','99452241467051876','0');
INSERT INTO `rlb_custom_program_log` VALUES ('315','1','Valve 5','V','5','2016-06-27 11:31:02','2016-06-27 11:32:02','1','5','2','99452241467051876','0');
INSERT INTO `rlb_custom_program_log` VALUES ('316','1','Valve 5','V','5','2016-06-27 11:32:02','2016-06-27 11:33:02','1','6','1','99452241467051876','0');
INSERT INTO `rlb_custom_program_log` VALUES ('317','1','Valve 6','V','6','2016-06-27 11:32:02','2016-06-27 11:33:02','1','6','1','99452241467051876','0');
INSERT INTO `rlb_custom_program_log` VALUES ('318','1','Valve 6','V','6','2016-06-27 11:32:02','2016-06-27 11:33:02','1','6','1','99452241467051876','0');
INSERT INTO `rlb_custom_program_log` VALUES ('319','1','Pump 1','PS','1','2016-06-27 11:33:02','2016-06-27 12:33:02','1','7','1','99452241467051876','0');
INSERT INTO `rlb_custom_program_log` VALUES ('320','1','Pump 2','PS','2','2016-06-27 11:33:02','2016-06-27 12:28:02','1','7','1','99452241467051876','0');
INSERT INTO `rlb_custom_program_log` VALUES ('321','1','Pump 2','PS','2','2016-06-27 11:33:02','2016-06-27 12:28:02','1','7','1','99452241467051876','0');
INSERT INTO `rlb_custom_program_log` VALUES ('322','1','Relay 15','R','15','2016-06-27 11:33:03','2016-06-27 12:28:03','1','7','1','99452241467051876','0');
INSERT INTO `rlb_custom_program_log` VALUES ('323','1','Power Center 0','P','0','2016-06-27 11:33:03','2016-06-27 12:28:03','1','7','1','99452241467051876','0');
INSERT INTO `rlb_custom_program_log` VALUES ('324','1','Valve 0','V','0','2016-06-27 11:36:02','2016-06-27 11:37:02','1','1','2','99452241467051876','1');
INSERT INTO `rlb_custom_program_log` VALUES ('325','1','Valve 4','V','4','2016-06-27 11:37:02','2016-06-27 11:38:02','1','3','1','99452241467051876','1');
INSERT INTO `rlb_custom_program_log` VALUES ('326','1','Valve 6','V','6','2016-06-27 11:38:02','2016-06-27 11:39:02','1','6','1','99452241467051876','1');
INSERT INTO `rlb_custom_program_log` VALUES ('327','1','Valve 0','V','0','2016-06-27 14:01:52','2016-06-27 14:02:52','1','1','2','43635461467061312','0');
INSERT INTO `rlb_custom_program_log` VALUES ('328','1','Valve 3','V','3','2016-06-27 14:03:02','2016-06-27 14:04:02','1','2','2','43635461467061312','0');
INSERT INTO `rlb_custom_program_log` VALUES ('329','1','Valve 4','V','4','2016-06-27 14:04:02','2016-06-27 14:05:02','1','3','1','43635461467061312','0');
INSERT INTO `rlb_custom_program_log` VALUES ('330','1','Valve 4','V','4','2016-06-27 14:05:02','2016-06-27 14:06:02','1','4','2','43635461467061312','0');
INSERT INTO `rlb_custom_program_log` VALUES ('331','1','Valve 5','V','5','2016-06-27 14:06:04','2016-06-27 14:07:04','1','5','2','43635461467061312','0');
INSERT INTO `rlb_custom_program_log` VALUES ('332','1','Valve 5','V','5','2016-06-27 14:08:04','2016-06-27 14:09:04','1','6','1','43635461467061312','0');
INSERT INTO `rlb_custom_program_log` VALUES ('333','1','Valve 6','V','6','2016-06-27 14:08:05','2016-06-27 14:09:05','1','6','1','43635461467061312','0');
INSERT INTO `rlb_custom_program_log` VALUES ('334','1','Valve 6','V','6','2016-06-27 14:08:05','2016-06-27 14:09:05','1','6','1','43635461467061312','0');
INSERT INTO `rlb_custom_program_log` VALUES ('335','1','Pump 1','PS','1','2016-06-27 14:10:05','2016-06-27 15:10:05','1','7','1','43635461467061312','0');
INSERT INTO `rlb_custom_program_log` VALUES ('336','1','Pump 2','PS','2','2016-06-27 14:10:05','2016-06-27 15:05:05','1','7','1','43635461467061312','0');
INSERT INTO `rlb_custom_program_log` VALUES ('337','1','Pump 2','PS','2','2016-06-27 14:10:05','2016-06-27 15:05:05','1','7','1','43635461467061312','0');
INSERT INTO `rlb_custom_program_log` VALUES ('338','1','Relay 15','R','15','2016-06-27 14:10:05','2016-06-27 15:05:05','1','7','1','43635461467061312','0');
INSERT INTO `rlb_custom_program_log` VALUES ('339','1','Power Center 0','P','0','2016-06-27 14:10:05','2016-06-27 15:05:05','1','7','1','43635461467061312','0');
INSERT INTO `rlb_custom_program_log` VALUES ('340','1','Valve 3','V','3','2016-06-27 14:26:04','2016-06-27 14:27:04','1','1','2','43635461467061312','1');
INSERT INTO `rlb_custom_program_log` VALUES ('341','1','Valve 4','V','4','2016-06-27 14:28:05','2016-06-27 14:29:05','1','4','2','43635461467061312','1');
INSERT INTO `rlb_custom_program_log` VALUES ('342','1','Valve 5','V','5','2016-06-27 14:30:04','2016-06-27 14:31:04','1','5','2','43635461467061312','1');
INSERT INTO `rlb_custom_program_log` VALUES ('343','1','Valve 6','V','6','2016-06-27 14:32:03','2016-06-27 14:33:03','1','6','1','43635461467061312','1');
INSERT INTO `rlb_custom_program_log` VALUES ('344','1','Valve 0','V','0','2016-06-27 21:47:26','2016-06-27 21:48:26','1','1','2','19811321467089245','0');
INSERT INTO `rlb_custom_program_log` VALUES ('345','1','Valve 3','V','3','2016-06-27 21:49:02','2016-06-27 21:50:02','1','1','2','19811321467089245','1');
INSERT INTO `rlb_custom_program_log` VALUES ('346','1','Valve 4','V','4','2016-06-27 21:50:02','2016-06-27 21:51:02','1','4','2','19811321467089245','1');
INSERT INTO `rlb_custom_program_log` VALUES ('347','1','Valve 5','V','5','2016-06-27 21:51:02','2016-06-27 21:52:02','1','5','2','19811321467089245','1');
INSERT INTO `rlb_custom_program_log` VALUES ('348','1','Valve 0','V','0','2016-06-27 21:51:21','2016-06-27 21:52:21','1','1','2','72276971467089480','0');
INSERT INTO `rlb_custom_program_log` VALUES ('349','1','Valve 3','V','3','2016-06-27 21:53:02','2016-06-27 21:54:02','1','2','2','72276971467089480','0');
INSERT INTO `rlb_custom_program_log` VALUES ('350','1','Valve 4','V','4','2016-06-27 21:54:02','2016-06-27 21:55:02','1','3','1','72276971467089480','0');
INSERT INTO `rlb_custom_program_log` VALUES ('351','1','Valve 4','V','4','2016-06-27 21:55:02','2016-06-27 21:56:02','1','4','2','72276971467089480','0');
INSERT INTO `rlb_custom_program_log` VALUES ('352','1','Valve 5','V','5','2016-06-27 21:56:02','2016-06-27 21:57:02','1','5','2','72276971467089480','0');
INSERT INTO `rlb_custom_program_log` VALUES ('353','1','Valve 5','V','5','2016-06-27 21:58:02','2016-06-27 21:59:02','1','6','1','72276971467089480','0');
INSERT INTO `rlb_custom_program_log` VALUES ('354','1','Valve 6','V','6','2016-06-27 21:58:02','2016-06-27 21:59:02','1','6','1','72276971467089480','0');
INSERT INTO `rlb_custom_program_log` VALUES ('355','1','Valve 6','V','6','2016-06-27 21:58:02','2016-06-27 21:59:02','1','6','1','72276971467089480','0');
INSERT INTO `rlb_custom_program_log` VALUES ('356','1','Pump 1','PS','1','2016-06-27 21:59:02','2016-06-27 22:59:02','1','7','1','72276971467089480','0');
INSERT INTO `rlb_custom_program_log` VALUES ('357','1','Pump 2','PS','2','2016-06-27 21:59:02','2016-06-27 22:54:02','1','7','1','72276971467089480','0');
INSERT INTO `rlb_custom_program_log` VALUES ('358','1','Pump 2','PS','2','2016-06-27 21:59:02','2016-06-27 22:54:02','1','7','1','72276971467089480','0');
INSERT INTO `rlb_custom_program_log` VALUES ('359','1','Relay 15','R','15','2016-06-27 21:59:02','2016-06-27 22:54:02','1','7','1','72276971467089480','0');
INSERT INTO `rlb_custom_program_log` VALUES ('360','1','Power Center 0','P','0','2016-06-27 21:59:02','2016-06-27 22:54:02','1','7','1','72276971467089480','0');
INSERT INTO `rlb_custom_program_log` VALUES ('361','1','Valve 3','V','3','2016-06-27 22:08:02','2016-06-27 22:09:02','1','1','2','72276971467089480','1');
INSERT INTO `rlb_custom_program_log` VALUES ('362','1','Valve 4','V','4','2016-06-27 22:10:02','2016-06-27 22:11:02','1','4','2','72276971467089480','1');
INSERT INTO `rlb_custom_program_log` VALUES ('363','1','Valve 5','V','5','2016-06-27 22:11:02','2016-06-27 22:12:02','1','5','2','72276971467089480','1');
INSERT INTO `rlb_custom_program_log` VALUES ('364','1','Valve 6','V','6','2016-06-27 22:12:02','2016-06-27 22:13:02','1','6','1','72276971467089480','1');
INSERT INTO `rlb_custom_program_log` VALUES ('365','3','Power Center 0','P','0','2016-06-28 00:08:06','2016-06-28 00:09:06','1','1','1','92212181467097686','0');
INSERT INTO `rlb_custom_program_log` VALUES ('366','3','Relay 6','R','6','2016-06-28 00:10:02','2016-06-28 00:11:02','1','2','1','92212181467097686','0');
INSERT INTO `rlb_custom_program_log` VALUES ('367','3','Pump 2','PS','2','2016-06-28 00:11:02','2016-06-28 00:21:02','1','3','1','92212181467097686','0');
INSERT INTO `rlb_custom_program_log` VALUES ('368','1','Valve 0','V','0','2016-06-28 03:55:24','2016-06-28 03:56:24','1','1','2','38750151467111324','0');
INSERT INTO `rlb_custom_program_log` VALUES ('369','1','Valve 3','V','3','2016-06-28 03:57:02','2016-06-28 03:58:02','1','2','2','38750151467111324','0');
INSERT INTO `rlb_custom_program_log` VALUES ('370','1','Valve 4','V','4','2016-06-28 03:58:03','2016-06-28 03:59:03','1','3','1','38750151467111324','0');
INSERT INTO `rlb_custom_program_log` VALUES ('371','1','Valve 4','V','4','2016-06-28 04:00:02','2016-06-28 04:01:02','1','4','2','38750151467111324','0');
INSERT INTO `rlb_custom_program_log` VALUES ('372','1','Valve 5','V','5','2016-06-28 04:01:04','2016-06-28 04:02:04','1','5','2','38750151467111324','0');
INSERT INTO `rlb_custom_program_log` VALUES ('373','1','Valve 5','V','5','2016-06-28 04:03:04','2016-06-28 04:04:04','1','6','1','38750151467111324','0');
INSERT INTO `rlb_custom_program_log` VALUES ('374','1','Valve 6','V','6','2016-06-28 04:03:05','2016-06-28 04:04:05','1','6','1','38750151467111324','0');
INSERT INTO `rlb_custom_program_log` VALUES ('375','1','Valve 6','V','6','2016-06-28 04:03:05','2016-06-28 04:04:05','1','6','1','38750151467111324','0');
INSERT INTO `rlb_custom_program_log` VALUES ('376','1','Pump 1','PS','1','2016-06-28 04:04:05','2016-06-28 05:04:05','1','7','1','38750151467111324','0');
INSERT INTO `rlb_custom_program_log` VALUES ('377','1','Pump 2','PS','2','2016-06-28 04:04:06','2016-06-28 04:59:06','1','7','1','38750151467111324','0');
INSERT INTO `rlb_custom_program_log` VALUES ('378','1','Relay 15','R','15','2016-06-28 04:04:06','2016-06-28 04:59:06','1','7','1','38750151467111324','0');
INSERT INTO `rlb_custom_program_log` VALUES ('379','1','Power Center 0','P','0','2016-06-28 04:04:06','2016-06-28 04:59:06','1','7','1','38750151467111324','0');
INSERT INTO `rlb_custom_program_log` VALUES ('380','1','Pump 1','PS','1','2016-06-28 04:04:05','2016-06-28 05:04:05','1','7','1','38750151467111324','0');
INSERT INTO `rlb_custom_program_log` VALUES ('381','1','Valve 3','V','3','2016-06-28 05:05:07','2016-06-28 05:06:07','1','1','2','38750151467111324','1');
INSERT INTO `rlb_custom_program_log` VALUES ('382','1','Valve 0','V','0','2016-06-28 05:05:45','2016-06-28 05:06:45','1','1','2','64857141467115539','0');
INSERT INTO `rlb_custom_program_log` VALUES ('383','1','Valve 3','V','3','2016-06-28 05:07:04','2016-06-28 05:08:04','1','2','2','64857141467115539','0');
INSERT INTO `rlb_custom_program_log` VALUES ('384','1','Valve 4','V','4','2016-06-28 05:09:06','2016-06-28 05:10:06','1','3','1','64857141467115539','0');
INSERT INTO `rlb_custom_program_log` VALUES ('385','1','Valve 4','V','4','2016-06-28 05:11:04','2016-06-28 05:12:04','1','4','2','64857141467115539','0');
INSERT INTO `rlb_custom_program_log` VALUES ('386','1','Valve 5','V','5','2016-06-28 05:13:04','2016-06-28 05:14:04','1','5','2','64857141467115539','0');
INSERT INTO `rlb_custom_program_log` VALUES ('387','1','Valve 5','V','5','2016-06-28 05:15:07','2016-06-28 05:16:07','1','6','1','64857141467115539','0');
INSERT INTO `rlb_custom_program_log` VALUES ('388','1','Valve 6','V','6','2016-06-28 05:15:07','2016-06-28 05:16:07','1','6','1','64857141467115539','0');
INSERT INTO `rlb_custom_program_log` VALUES ('389','1','Valve 6','V','6','2016-06-28 05:15:07','2016-06-28 05:16:07','1','6','1','64857141467115539','0');
INSERT INTO `rlb_custom_program_log` VALUES ('390','1','Pump 1','PS','1','2016-06-28 05:17:07','2016-06-28 06:17:07','1','7','1','64857141467115539','0');
INSERT INTO `rlb_custom_program_log` VALUES ('391','1','Pump 2','PS','2','2016-06-28 05:17:09','2016-06-28 06:12:09','1','7','1','64857141467115539','0');
INSERT INTO `rlb_custom_program_log` VALUES ('392','1','Pump 2','PS','2','2016-06-28 05:17:09','2016-06-28 06:12:09','1','7','1','64857141467115539','0');
INSERT INTO `rlb_custom_program_log` VALUES ('393','1','Relay 15','R','15','2016-06-28 05:17:10','2016-06-28 06:12:10','1','7','1','64857141467115539','0');
INSERT INTO `rlb_custom_program_log` VALUES ('394','1','Power Center 0','P','0','2016-06-28 05:17:11','2016-06-28 06:12:11','1','7','1','64857141467115539','0');
INSERT INTO `rlb_custom_program_log` VALUES ('395','1','Valve 3','V','3','2016-06-28 05:48:02','2016-06-28 05:49:02','1','1','2','64857141467115539','1');
INSERT INTO `rlb_custom_program_log` VALUES ('396','1','Valve 4','V','4','2016-06-28 05:50:01','2016-06-28 05:51:01','1','4','2','64857141467115539','1');
INSERT INTO `rlb_custom_program_log` VALUES ('397','1','Valve 5','V','5','2016-06-28 05:51:03','2016-06-28 05:52:03','1','5','2','64857141467115539','1');
INSERT INTO `rlb_custom_program_log` VALUES ('398','1','Valve 0','V','0','2016-06-28 05:54:32','2016-06-28 05:55:32','1','1','2','63858771467118470','0');
INSERT INTO `rlb_custom_program_log` VALUES ('399','1','Valve 3','V','3','2016-06-28 05:56:03','2016-06-28 05:57:03','1','1','2','63858771467118470','1');
INSERT INTO `rlb_custom_program_log` VALUES ('400','1','Valve 4','V','4','2016-06-28 05:57:05','2016-06-28 05:58:05','1','4','2','63858771467118470','1');
INSERT INTO `rlb_custom_program_log` VALUES ('401','1','Valve 5','V','5','2016-06-28 05:59:02','2016-06-28 06:00:02','1','5','2','63858771467118470','1');
INSERT INTO `rlb_custom_program_log` VALUES ('402','1','Valve 0','V','0','2016-06-28 23:30:22','2016-06-28 23:31:22','1','1','2','27214981467181822','0');
INSERT INTO `rlb_custom_program_log` VALUES ('403','1','Valve 3','V','3','2016-06-28 23:32:02','2016-06-28 23:33:02','1','2','2','27214981467181822','0');
INSERT INTO `rlb_custom_program_log` VALUES ('404','1','Valve 4','V','4','2016-06-28 23:33:02','2016-06-28 23:34:02','1','3','1','27214981467181822','0');
INSERT INTO `rlb_custom_program_log` VALUES ('405','1','Valve 4','V','4','2016-06-28 23:34:02','2016-06-28 23:35:02','1','4','2','27214981467181822','0');
INSERT INTO `rlb_custom_program_log` VALUES ('406','1','Valve 5','V','5','2016-06-28 23:35:02','2016-06-28 23:36:02','1','5','2','27214981467181822','0');
INSERT INTO `rlb_custom_program_log` VALUES ('407','1','Valve 5','V','5','2016-06-28 23:36:02','2016-06-28 23:37:02','1','6','1','27214981467181822','0');
INSERT INTO `rlb_custom_program_log` VALUES ('408','1','Valve 6','V','6','2016-06-28 23:36:02','2016-06-28 23:37:02','1','6','1','27214981467181822','0');
INSERT INTO `rlb_custom_program_log` VALUES ('409','1','Valve 6','V','6','2016-06-28 23:36:02','2016-06-28 23:37:02','1','6','1','27214981467181822','0');
INSERT INTO `rlb_custom_program_log` VALUES ('410','1','Pump 1','PS','1','2016-06-28 23:37:03','2016-06-29 00:37:03','1','7','1','27214981467181822','0');
INSERT INTO `rlb_custom_program_log` VALUES ('411','1','Pump 2','PS','2','2016-06-28 23:37:03','2016-06-29 00:32:03','1','7','1','27214981467181822','0');
INSERT INTO `rlb_custom_program_log` VALUES ('412','1','Pump 2','PS','2','2016-06-28 23:37:03','2016-06-29 00:32:03','1','7','1','27214981467181822','0');
INSERT INTO `rlb_custom_program_log` VALUES ('413','1','Relay 15','R','15','2016-06-28 23:37:03','2016-06-29 00:32:03','1','7','1','27214981467181822','0');
INSERT INTO `rlb_custom_program_log` VALUES ('414','1','Power Center 0','P','0','2016-06-28 23:37:03','2016-06-29 00:32:03','1','7','1','27214981467181822','0');
INSERT INTO `rlb_custom_program_log` VALUES ('415','1','Valve 0','V','0','2016-06-28 23:44:02','2016-06-28 23:45:02','1','1','2','27214981467181822','1');
INSERT INTO `rlb_custom_program_log` VALUES ('416','1','Valve 4','V','4','2016-06-28 23:45:02','2016-06-28 23:46:02','1','3','1','27214981467181822','1');
INSERT INTO `rlb_custom_program_log` VALUES ('417','1','Valve 5','V','5','2016-06-28 23:46:02','2016-06-28 23:47:02','1','5','2','27214981467181822','1');
INSERT INTO `rlb_custom_program_log` VALUES ('418','1','Valve 0','V','0','2016-06-28 23:56:03','2016-06-28 23:57:03','1','1','2','45611421467183358','0');
INSERT INTO `rlb_custom_program_log` VALUES ('419','1','Valve 0','V','0','2016-06-28 23:57:02','2016-06-28 23:58:02','1','1','2','45611421467183358','1');
INSERT INTO `rlb_custom_program_log` VALUES ('420','1','Valve 4','V','4','2016-06-28 23:58:02','2016-06-28 23:59:02','1','3','1','45611421467183358','1');
INSERT INTO `rlb_custom_program_log` VALUES ('421','1','Valve 0','V','0','2016-06-29 00:12:20','2016-06-29 00:13:20','1','1','2','99825831467184338','0');
INSERT INTO `rlb_custom_program_log` VALUES ('422','1','Valve 0','V','0','2016-06-29 00:14:03','2016-06-29 00:15:03','1','1','2','99825831467184338','1');
INSERT INTO `rlb_custom_program_log` VALUES ('423','1','Valve 4','V','4','2016-06-29 00:15:05','2016-06-29 00:16:05','1','3','1','99825831467184338','1');
INSERT INTO `rlb_custom_program_log` VALUES ('424','1','Valve 0','V','0','2016-06-29 11:35:20','2016-06-29 11:36:20','1','1','2','30920031467225320','0');
INSERT INTO `rlb_custom_program_log` VALUES ('425','1','Valve 3','V','3','2016-06-29 11:37:02','2016-06-29 11:38:02','1','2','2','30920031467225320','0');
INSERT INTO `rlb_custom_program_log` VALUES ('426','1','Valve 4','V','4','2016-06-29 11:38:02','2016-06-29 11:39:02','1','3','1','30920031467225320','0');
INSERT INTO `rlb_custom_program_log` VALUES ('427','1','Valve 4','V','4','2016-06-29 11:39:02','2016-06-29 11:40:02','1','4','2','30920031467225320','0');
INSERT INTO `rlb_custom_program_log` VALUES ('428','1','Valve 5','V','5','2016-06-29 11:40:02','2016-06-29 11:41:02','1','5','2','30920031467225320','0');
INSERT INTO `rlb_custom_program_log` VALUES ('429','1','Valve 5','V','5','2016-06-29 11:42:02','2016-06-29 11:43:02','1','6','1','30920031467225320','0');
INSERT INTO `rlb_custom_program_log` VALUES ('430','1','Valve 6','V','6','2016-06-29 11:42:02','2016-06-29 11:43:02','1','6','1','30920031467225320','0');
INSERT INTO `rlb_custom_program_log` VALUES ('431','1','Valve 6','V','6','2016-06-29 11:42:02','2016-06-29 11:43:02','1','6','1','30920031467225320','0');
INSERT INTO `rlb_custom_program_log` VALUES ('432','1','Valve 0','V','0','2016-06-29 12:19:16','2016-06-29 12:20:16','1','1','2','58825661467227955','0');
INSERT INTO `rlb_custom_program_log` VALUES ('433','1','Valve 3','V','3','2016-06-29 12:21:02','2016-06-29 12:22:02','1','2','2','58825661467227955','0');
INSERT INTO `rlb_custom_program_log` VALUES ('434','1','Valve 4','V','4','2016-06-29 12:22:02','2016-06-29 12:23:02','1','3','1','58825661467227955','0');
INSERT INTO `rlb_custom_program_log` VALUES ('435','1','Valve 4','V','4','2016-06-29 12:24:02','2016-06-29 12:25:02','1','4','2','58825661467227955','0');
INSERT INTO `rlb_custom_program_log` VALUES ('436','1','Valve 5','V','5','2016-06-29 12:25:02','2016-06-29 12:26:02','1','5','2','58825661467227955','0');
INSERT INTO `rlb_custom_program_log` VALUES ('437','1','Valve 5','V','5','2016-06-29 12:26:02','2016-06-29 12:27:02','1','6','1','58825661467227955','0');
INSERT INTO `rlb_custom_program_log` VALUES ('438','1','Valve 6','V','6','2016-06-29 12:26:02','2016-06-29 12:27:02','1','6','1','58825661467227955','0');
INSERT INTO `rlb_custom_program_log` VALUES ('439','1','Valve 6','V','6','2016-06-29 12:26:02','2016-06-29 12:27:02','1','6','1','58825661467227955','0');
INSERT INTO `rlb_custom_program_log` VALUES ('440','3','Relay 6','R','6','2016-06-30 02:56:58','2016-06-30 03:46:58','1','1','2','98660791467280618','0');
INSERT INTO `rlb_custom_program_log` VALUES ('441','3','Relay 6','R','6','2016-06-30 03:06:38','2016-06-30 03:56:38','1','1','1','57628541467281198','0');
INSERT INTO `rlb_custom_program_log` VALUES ('442','3','Relay 6','R','6','2016-06-30 03:39:51','2016-06-30 04:29:51','1','1','1','11321601467283190','0');
INSERT INTO `rlb_custom_program_log` VALUES ('443','3','Relay 6','R','6','2016-06-30 03:51:04','2016-06-30 04:41:04','1','1','1','35759981467283863','0');
INSERT INTO `rlb_custom_program_log` VALUES ('444','3','Power Center 0','P','0','2016-07-01 04:48:33','2016-07-01 04:53:33','1','1','1','23000391467373713','0');
INSERT INTO `rlb_custom_program_log` VALUES ('445','3','Power Center 0','P','0','2016-07-01 04:51:52','2016-07-01 04:56:52','1','1','1','38239441467373911','0');
INSERT INTO `rlb_custom_program_log` VALUES ('446','3','Power Center 0','P','0','2016-07-01 05:01:59','2016-07-01 05:06:59','1','1','1','51413011467374516','0');
INSERT INTO `rlb_custom_program_log` VALUES ('447','3','Power Center 0','P','0','2016-07-01 05:27:02','2016-07-01 05:32:02','1','1','1','38060461467375971','0');
INSERT INTO `rlb_custom_program_log` VALUES ('448','3','Power Center 0','P','0','2016-07-01 05:29:02','2016-07-01 05:34:02','1','1','1','13783261467376089','0');
INSERT INTO `rlb_custom_program_log` VALUES ('449','3','Power Center 0','P','0','2016-07-01 05:30:02','2016-07-01 05:35:02','1','1','1','86180371467376179','0');
INSERT INTO `rlb_custom_program_log` VALUES ('450','3','Power Center 0','P','0','2016-07-01 05:31:31','2016-07-01 05:36:31','1','1','1','59263441467376291','0');
INSERT INTO `rlb_custom_program_log` VALUES ('451','3','Power Center 0','P','0','2016-07-01 05:35:19','2016-07-01 05:40:19','1','1','1','98779241467376519','0');
INSERT INTO `rlb_custom_program_log` VALUES ('452','3','Power Center 0','P','0','2016-07-01 05:40:08','2016-07-01 05:45:08','1','1','1','51074111467376807','0');
INSERT INTO `rlb_custom_program_log` VALUES ('453','3','Relay 14','R','14','2016-07-01 05:46:04','2016-07-01 05:51:04','1','2','1','51074111467376807','0');
INSERT INTO `rlb_custom_program_log` VALUES ('454','3','Power Center 0','P','0','2016-07-01 05:54:08','2016-07-01 05:59:08','1','1','1','82163291467377647','0');
INSERT INTO `rlb_custom_program_log` VALUES ('455','3','Relay 14','R','14','2016-07-01 06:00:02','2016-07-01 06:05:02','1','2','1','82163291467377647','0');
INSERT INTO `rlb_custom_program_log` VALUES ('456','3','Power Center 0','P','0','2016-07-01 06:06:34','2016-07-01 06:11:34','1','1','1','49183781467378394','0');
INSERT INTO `rlb_custom_program_log` VALUES ('457','3','Power Center 0','P','0','2016-07-01 06:09:52','2016-07-01 06:14:52','1','1','1','93484431467378588','0');
INSERT INTO `rlb_custom_program_log` VALUES ('458','3','Power Center 0','P','0','2016-07-01 06:13:39','2016-07-01 06:18:39','1','1','1','47923751467378818','0');
INSERT INTO `rlb_custom_program_log` VALUES ('459','3','Power Center 0','P','0','2016-07-01 06:21:28','2016-07-01 06:26:28','1','1','1','60495551467379286','0');
INSERT INTO `rlb_custom_program_log` VALUES ('460','45','Valve 5','V','5','2016-07-01 08:52:24','2016-07-01 08:53:24','1','1','1','98195001467388342','0');
INSERT INTO `rlb_custom_program_log` VALUES ('461','45','Valve 6','V','6','2016-07-01 08:54:04','2016-07-01 08:55:04','1','2','1','98195001467388342','0');
INSERT INTO `rlb_custom_program_log` VALUES ('462','45','Valve 2','V','2','2016-07-01 08:54:05','2016-07-01 08:55:05','1','2','2','98195001467388342','0');
INSERT INTO `rlb_custom_program_log` VALUES ('463','45','Valve 2','V','2','2016-07-01 08:54:05','2016-07-01 08:55:05','1','2','2','98195001467388342','0');
INSERT INTO `rlb_custom_program_log` VALUES ('464','45','Valve 0','V','0','2016-07-01 08:56:02','2016-07-01 08:57:02','1','3','2','98195001467388342','0');
INSERT INTO `rlb_custom_program_log` VALUES ('465','45','Valve 3','V','3','2016-07-01 08:56:02','2016-07-01 08:57:02','1','3','2','98195001467388342','0');
INSERT INTO `rlb_custom_program_log` VALUES ('466','45','Valve 3','V','3','2016-07-01 08:56:02','2016-07-01 08:57:02','1','3','2','98195001467388342','0');
INSERT INTO `rlb_custom_program_log` VALUES ('467','45','Valve 4','V','4','2016-07-01 08:57:02','2016-07-01 08:58:02','1','4','1','98195001467388342','0');
INSERT INTO `rlb_custom_program_log` VALUES ('468','45','Valve 5','V','5','2016-07-01 08:57:02','2016-07-01 08:58:02','1','4','2','98195001467388342','0');
INSERT INTO `rlb_custom_program_log` VALUES ('469','45','Valve 5','V','5','2016-07-01 08:57:02','2016-07-01 08:58:02','1','4','2','98195001467388342','0');
INSERT INTO `rlb_custom_program_log` VALUES ('470','45','Valve 4','V','4','2016-07-01 08:59:03','2016-07-01 09:00:03','1','5','2','98195001467388342','0');
INSERT INTO `rlb_custom_program_log` VALUES ('471','45','Pump 1','PS','1','2016-07-01 09:01:02','2016-07-01 10:01:02','1','6','1','98195001467388342','0');
INSERT INTO `rlb_custom_program_log` VALUES ('472','45','Pump 2','PS','2','2016-07-01 09:01:03','2016-07-01 09:16:03','1','6','1','98195001467388342','0');
INSERT INTO `rlb_custom_program_log` VALUES ('473','45','Pump 1','PS','1','2016-07-01 09:01:02','2016-07-01 10:01:02','1','6','1','98195001467388342','0');
INSERT INTO `rlb_custom_program_log` VALUES ('474','45','Valve 5','V','5','2016-07-01 10:01:07','2016-07-01 10:02:07','1','1','1','98195001467388342','1');
INSERT INTO `rlb_custom_program_log` VALUES ('475','45','Valve 2','V','2','2016-07-01 10:03:04','2016-07-01 10:04:04','1','2','2','98195001467388342','1');
INSERT INTO `rlb_custom_program_log` VALUES ('476','45','Valve 3','V','3','2016-07-01 10:05:05','2016-07-01 10:06:05','1','3','2','98195001467388342','1');
INSERT INTO `rlb_custom_program_log` VALUES ('477','45','Valve 4','V','4','2016-07-01 10:07:04','2016-07-01 10:08:04','1','4','1','98195001467388342','1');
INSERT INTO `rlb_custom_program_log` VALUES ('478','45','Valve 4','V','4','2016-07-01 10:09:02','2016-07-01 10:10:02','1','5','2','98195001467388342','1');
INSERT INTO `rlb_custom_program_log` VALUES ('479','45','Valve 5','V','5','2016-07-01 15:49:09','2016-07-01 15:50:09','1','1','1','19204361467413349','0');
INSERT INTO `rlb_custom_program_log` VALUES ('480','45','Valve 6','V','6','2016-07-01 15:51:06','2016-07-01 15:52:06','1','2','1','19204361467413349','0');
INSERT INTO `rlb_custom_program_log` VALUES ('481','45','Valve 2','V','2','2016-07-01 15:51:06','2016-07-01 15:52:06','1','2','2','19204361467413349','0');
INSERT INTO `rlb_custom_program_log` VALUES ('482','45','Valve 2','V','2','2016-07-01 15:51:06','2016-07-01 15:52:06','1','2','2','19204361467413349','0');
INSERT INTO `rlb_custom_program_log` VALUES ('483','45','Valve 0','V','0','2016-07-01 15:53:03','2016-07-01 15:54:03','1','3','2','19204361467413349','0');
INSERT INTO `rlb_custom_program_log` VALUES ('484','45','Valve 3','V','3','2016-07-01 15:53:03','2016-07-01 15:54:03','1','3','2','19204361467413349','0');
INSERT INTO `rlb_custom_program_log` VALUES ('485','45','Valve 3','V','3','2016-07-01 15:53:03','2016-07-01 15:54:03','1','3','2','19204361467413349','0');
INSERT INTO `rlb_custom_program_log` VALUES ('486','45','Valve 4','V','4','2016-07-01 15:54:07','2016-07-01 15:55:07','1','4','1','19204361467413349','0');
INSERT INTO `rlb_custom_program_log` VALUES ('487','45','Valve 5','V','5','2016-07-01 15:54:08','2016-07-01 15:55:08','1','4','2','19204361467413349','0');
INSERT INTO `rlb_custom_program_log` VALUES ('488','45','Valve 5','V','5','2016-07-01 15:54:08','2016-07-01 15:55:08','1','4','2','19204361467413349','0');
INSERT INTO `rlb_custom_program_log` VALUES ('489','45','Valve 4','V','4','2016-07-01 15:56:06','2016-07-01 15:57:06','1','5','2','19204361467413349','0');
INSERT INTO `rlb_custom_program_log` VALUES ('490','45','Pump 1','PS','1','2016-07-01 15:58:04','2016-07-01 16:58:04','1','6','1','19204361467413349','0');
INSERT INTO `rlb_custom_program_log` VALUES ('491','45','Pump 2','PS','2','2016-07-01 15:58:06','2016-07-01 16:13:06','1','6','1','19204361467413349','0');
INSERT INTO `rlb_custom_program_log` VALUES ('492','45','Pump 1','PS','1','2016-07-01 15:58:04','2016-07-01 16:58:04','1','6','1','19204361467413349','0');
INSERT INTO `rlb_custom_program_log` VALUES ('493','45','Valve 5','V','5','2016-07-01 16:54:39','2016-07-01 16:55:39','1','1','1','61622631467417278','0');
INSERT INTO `rlb_custom_program_log` VALUES ('494','45','Valve 6','V','6','2016-07-01 16:56:05','2016-07-01 16:57:05','1','2','1','61622631467417278','0');
INSERT INTO `rlb_custom_program_log` VALUES ('495','45','Valve 2','V','2','2016-07-01 16:56:05','2016-07-01 16:57:05','1','2','2','61622631467417278','0');
INSERT INTO `rlb_custom_program_log` VALUES ('496','45','Valve 2','V','2','2016-07-01 16:56:05','2016-07-01 16:57:05','1','2','2','61622631467417278','0');
INSERT INTO `rlb_custom_program_log` VALUES ('497','45','Valve 0','V','0','2016-07-01 16:58:02','2016-07-01 16:59:02','1','3','2','61622631467417278','0');
INSERT INTO `rlb_custom_program_log` VALUES ('498','45','Valve 3','V','3','2016-07-01 16:58:03','2016-07-01 16:59:03','1','3','2','61622631467417278','0');
INSERT INTO `rlb_custom_program_log` VALUES ('499','45','Valve 3','V','3','2016-07-01 16:58:03','2016-07-01 16:59:03','1','3','2','61622631467417278','0');
INSERT INTO `rlb_custom_program_log` VALUES ('500','45','Valve 4','V','4','2016-07-01 17:00:02','2016-07-01 17:01:02','1','4','1','61622631467417278','0');
INSERT INTO `rlb_custom_program_log` VALUES ('501','45','Valve 5','V','5','2016-07-01 17:00:02','2016-07-01 17:01:02','1','4','2','61622631467417278','0');
INSERT INTO `rlb_custom_program_log` VALUES ('502','45','Valve 5','V','5','2016-07-01 17:00:02','2016-07-01 17:01:02','1','4','2','61622631467417278','0');
INSERT INTO `rlb_custom_program_log` VALUES ('503','45','Valve 4','V','4','2016-07-01 17:01:02','2016-07-01 17:02:02','1','5','2','61622631467417278','0');
INSERT INTO `rlb_custom_program_log` VALUES ('504','45','Pump 1','PS','1','2016-07-01 17:02:03','2016-07-01 18:02:03','1','6','1','61622631467417278','0');
INSERT INTO `rlb_custom_program_log` VALUES ('505','45','Pump 2','PS','2','2016-07-01 17:02:03','2016-07-01 17:17:03','1','6','1','61622631467417278','0');
INSERT INTO `rlb_custom_program_log` VALUES ('506','45','Pump 2','PS','2','2016-07-01 17:02:03','2016-07-01 17:17:03','1','6','1','61622631467417278','0');
INSERT INTO `rlb_custom_program_log` VALUES ('507','45','Valve 5','V','5','2016-07-01 17:14:03','2016-07-01 17:15:03','1','1','1','61622631467417278','1');
INSERT INTO `rlb_custom_program_log` VALUES ('508','45','Valve 6','V','6','2016-07-01 17:15:03','2016-07-01 17:16:03','1','2','1','61622631467417278','1');
INSERT INTO `rlb_custom_program_log` VALUES ('509','6','Valve 1','V','1','2016-07-01 17:16:20','2016-07-01 17:17:20','1','1','2','17307761467418575','0');
INSERT INTO `rlb_custom_program_log` VALUES ('510','6','Valve 2','V','2','2016-07-01 17:16:21','2016-07-01 17:17:21','1','1','2','17307761467418575','0');
INSERT INTO `rlb_custom_program_log` VALUES ('511','6','Valve 2','V','2','2016-07-01 17:16:21','2016-07-01 17:17:21','1','1','2','17307761467418575','0');
INSERT INTO `rlb_custom_program_log` VALUES ('512','6','Valve 5','V','5','2016-07-01 17:18:02','2016-07-01 17:19:02','1','2','1','17307761467418575','0');
INSERT INTO `rlb_custom_program_log` VALUES ('513','6','Valve 6','V','6','2016-07-01 17:18:02','2016-07-01 17:19:02','1','2','1','17307761467418575','0');
INSERT INTO `rlb_custom_program_log` VALUES ('514','6','Valve 6','V','6','2016-07-01 17:18:02','2016-07-01 17:19:02','1','2','1','17307761467418575','0');
INSERT INTO `rlb_custom_program_log` VALUES ('515','6','Pump 2','PS','2','2016-07-01 17:19:02','2016-07-01 18:19:02','1','3','1','17307761467418575','0');
INSERT INTO `rlb_custom_program_log` VALUES ('516','6','Valve 6','V','6','2016-07-01 18:19:09','2016-07-01 18:20:09','1','1','1','17307761467418575','1');
INSERT INTO `rlb_custom_program_log` VALUES ('517','1','Valve 0','V','0','2016-07-04 13:45:04','2016-07-04 13:46:04','1','1','2','29662001467665104','0');
INSERT INTO `rlb_custom_program_log` VALUES ('518','6','Valve 1','V','1','2016-07-04 13:45:20','2016-07-04 13:46:20','1','1','2','76860221467665120','0');
INSERT INTO `rlb_custom_program_log` VALUES ('519','6','Valve 2','V','2','2016-07-04 13:45:21','2016-07-04 13:46:21','1','1','2','76860221467665120','0');
INSERT INTO `rlb_custom_program_log` VALUES ('520','6','Valve 2','V','2','2016-07-04 13:45:21','2016-07-04 13:46:21','1','1','2','76860221467665120','0');
INSERT INTO `rlb_custom_program_log` VALUES ('521','1','Valve 0','V','0','2016-07-04 13:46:02','2016-07-04 13:47:02','1','1','2','29662001467665104','1');
INSERT INTO `rlb_custom_program_log` VALUES ('522','1','Valve 0','V','0','2016-07-04 13:46:48','2016-07-04 13:47:48','1','1','2','86151471467665207','0');
INSERT INTO `rlb_custom_program_log` VALUES ('523','6','Valve 6','V','6','2016-07-04 13:47:02','2016-07-04 13:48:02','1','1','1','76860221467665120','1');
INSERT INTO `rlb_custom_program_log` VALUES ('524','1','Valve 3','V','3','2016-07-04 13:48:02','2016-07-04 13:49:02','1','2','2','86151471467665207','0');
INSERT INTO `rlb_custom_program_log` VALUES ('525','1','Valve 4','V','4','2016-07-04 13:49:02','2016-07-04 13:50:02','1','3','1','86151471467665207','0');
INSERT INTO `rlb_custom_program_log` VALUES ('526','1','Valve 4','V','4','2016-07-04 13:50:02','2016-07-04 13:51:02','1','4','2','86151471467665207','0');
INSERT INTO `rlb_custom_program_log` VALUES ('527','1','Valve 5','V','5','2016-07-04 13:52:02','2016-07-04 13:53:02','1','5','2','86151471467665207','0');
INSERT INTO `rlb_custom_program_log` VALUES ('528','1','Valve 5','V','5','2016-07-04 13:53:02','2016-07-04 13:54:02','1','6','1','86151471467665207','0');
INSERT INTO `rlb_custom_program_log` VALUES ('529','1','Valve 6','V','6','2016-07-04 13:53:02','2016-07-04 13:54:02','1','6','1','86151471467665207','0');
INSERT INTO `rlb_custom_program_log` VALUES ('530','1','Valve 6','V','6','2016-07-04 13:53:02','2016-07-04 13:54:02','1','6','1','86151471467665207','0');
INSERT INTO `rlb_custom_program_log` VALUES ('531','1','Pump 2','PS','2','2016-07-04 13:54:04','2016-07-04 13:55:04','1','7','1','86151471467665207','0');
INSERT INTO `rlb_custom_program_log` VALUES ('532','1','Relay 15','R','15','2016-07-04 13:54:04','2016-07-04 14:49:04','1','7','1','86151471467665207','0');
INSERT INTO `rlb_custom_program_log` VALUES ('533','1','Power Center 0','P','0','2016-07-04 13:54:05','2016-07-04 14:49:05','1','7','1','86151471467665207','0');
INSERT INTO `rlb_custom_program_log` VALUES ('534','1','Valve 0','V','0','2016-07-04 13:57:02','2016-07-04 13:58:02','1','1','2','86151471467665207','1');
INSERT INTO `rlb_custom_program_log` VALUES ('535','1','Valve 4','V','4','2016-07-04 13:58:02','2016-07-04 13:59:02','1','3','1','86151471467665207','1');
INSERT INTO `rlb_custom_program_log` VALUES ('536','1','Valve 5','V','5','2016-07-04 14:00:03','2016-07-04 14:01:03','1','5','2','86151471467665207','1');
INSERT INTO `rlb_custom_program_log` VALUES ('537','45','Valve 5','V','5','2016-07-04 14:06:06','2016-07-04 14:07:06','1','1','1','47124181467666364','0');
INSERT INTO `rlb_custom_program_log` VALUES ('538','45','Valve 6','V','6','2016-07-04 14:08:01','2016-07-04 14:09:01','1','2','1','47124181467666364','0');
INSERT INTO `rlb_custom_program_log` VALUES ('539','45','Valve 2','V','2','2016-07-04 14:08:02','2016-07-04 14:09:02','1','2','2','47124181467666364','0');
INSERT INTO `rlb_custom_program_log` VALUES ('540','45','Valve 2','V','2','2016-07-04 14:08:02','2016-07-04 14:09:02','1','2','2','47124181467666364','0');
INSERT INTO `rlb_custom_program_log` VALUES ('541','45','Valve 0','V','0','2016-07-04 14:09:02','2016-07-04 14:10:02','1','3','2','47124181467666364','0');
INSERT INTO `rlb_custom_program_log` VALUES ('542','45','Valve 3','V','3','2016-07-04 14:09:02','2016-07-04 14:10:02','1','3','2','47124181467666364','0');
INSERT INTO `rlb_custom_program_log` VALUES ('543','45','Valve 3','V','3','2016-07-04 14:09:02','2016-07-04 14:10:02','1','3','2','47124181467666364','0');
INSERT INTO `rlb_custom_program_log` VALUES ('544','45','Valve 4','V','4','2016-07-04 14:11:02','2016-07-04 14:12:02','1','4','1','47124181467666364','0');
INSERT INTO `rlb_custom_program_log` VALUES ('545','45','Valve 5','V','5','2016-07-04 14:11:03','2016-07-04 14:12:03','1','4','2','47124181467666364','0');
INSERT INTO `rlb_custom_program_log` VALUES ('546','45','Valve 5','V','5','2016-07-04 14:11:03','2016-07-04 14:12:03','1','4','2','47124181467666364','0');
INSERT INTO `rlb_custom_program_log` VALUES ('547','45','Valve 4','V','4','2016-07-04 14:13:02','2016-07-04 14:14:02','1','5','2','47124181467666364','0');
INSERT INTO `rlb_custom_program_log` VALUES ('548','45','Pump 1','PS','1','2016-07-04 14:14:02','2016-07-04 15:14:02','1','6','1','47124181467666364','0');
INSERT INTO `rlb_custom_program_log` VALUES ('549','45','Pump 2','PS','2','2016-07-04 14:14:03','2016-07-04 14:29:03','1','6','1','47124181467666364','0');
INSERT INTO `rlb_custom_program_log` VALUES ('550','45','Pump 1','PS','1','2016-07-04 14:14:02','2016-07-04 15:14:02','1','6','1','47124181467666364','0');
INSERT INTO `rlb_custom_program_log` VALUES ('551','45','Valve 5','V','5','2016-07-04 14:31:02','2016-07-04 14:32:02','1','1','1','47124181467666364','1');
INSERT INTO `rlb_custom_program_log` VALUES ('552','45','Valve 2','V','2','2016-07-04 14:32:02','2016-07-04 14:33:02','1','2','2','47124181467666364','1');
INSERT INTO `rlb_custom_program_log` VALUES ('553','45','Valve 3','V','3','2016-07-04 14:33:02','2016-07-04 14:34:02','1','3','2','47124181467666364','1');
INSERT INTO `rlb_custom_program_log` VALUES ('554','45','Valve 4','V','4','2016-07-04 14:35:03','2016-07-04 14:36:03','1','4','1','47124181467666364','1');
INSERT INTO `rlb_custom_program_log` VALUES ('555','45','Valve 4','V','4','2016-07-04 14:37:02','2016-07-04 14:38:02','1','5','2','47124181467666364','1');
INSERT INTO `rlb_custom_program_log` VALUES ('556','1','Valve 0','V','0','2016-07-04 14:38:09','2016-07-04 14:39:09','1','1','2','92299561467668288','0');
INSERT INTO `rlb_custom_program_log` VALUES ('557','1','Valve 3','V','3','2016-07-04 14:40:02','2016-07-04 14:41:02','1','2','2','92299561467668288','0');
INSERT INTO `rlb_custom_program_log` VALUES ('558','1','Valve 4','V','4','2016-07-04 14:42:02','2016-07-04 14:43:02','1','3','1','92299561467668288','0');
INSERT INTO `rlb_custom_program_log` VALUES ('559','1','Valve 4','V','4','2016-07-04 14:43:02','2016-07-04 14:44:02','1','4','2','92299561467668288','0');
INSERT INTO `rlb_custom_program_log` VALUES ('560','1','Valve 5','V','5','2016-07-04 14:45:03','2016-07-04 14:46:03','1','5','2','92299561467668288','0');
INSERT INTO `rlb_custom_program_log` VALUES ('561','1','Valve 5','V','5','2016-07-04 14:47:02','2016-07-04 14:48:02','1','6','1','92299561467668288','0');
INSERT INTO `rlb_custom_program_log` VALUES ('562','1','Valve 6','V','6','2016-07-04 14:47:02','2016-07-04 14:48:02','1','6','1','92299561467668288','0');
INSERT INTO `rlb_custom_program_log` VALUES ('563','1','Valve 6','V','6','2016-07-04 14:47:02','2016-07-04 14:48:02','1','6','1','92299561467668288','0');
INSERT INTO `rlb_custom_program_log` VALUES ('564','1','Pump 2','PS','2','2016-07-04 14:48:02','2016-07-04 14:49:02','1','7','1','92299561467668288','0');
INSERT INTO `rlb_custom_program_log` VALUES ('565','6','Valve 1','V','1','2016-07-04 14:58:24','2016-07-04 14:59:24','1','1','2','18022111467669503','0');
INSERT INTO `rlb_custom_program_log` VALUES ('566','6','Valve 2','V','2','2016-07-04 14:58:24','2016-07-04 14:59:24','1','1','2','18022111467669503','0');
INSERT INTO `rlb_custom_program_log` VALUES ('567','6','Valve 2','V','2','2016-07-04 14:58:24','2016-07-04 14:59:24','1','1','2','18022111467669503','0');
INSERT INTO `rlb_custom_program_log` VALUES ('568','6','Valve 5','V','5','2016-07-04 15:00:03','2016-07-04 15:01:03','1','2','1','18022111467669503','0');
INSERT INTO `rlb_custom_program_log` VALUES ('569','6','Valve 6','V','6','2016-07-04 15:00:04','2016-07-04 15:01:04','1','2','1','18022111467669503','0');
INSERT INTO `rlb_custom_program_log` VALUES ('570','6','Valve 6','V','6','2016-07-04 15:00:04','2016-07-04 15:01:04','1','2','1','18022111467669503','0');
INSERT INTO `rlb_custom_program_log` VALUES ('571','1','Relay 15','R','15','2016-07-04 14:48:02','2016-07-04 15:43:02','1','7','1','92299561467668288','0');
INSERT INTO `rlb_custom_program_log` VALUES ('572','1','Power Center 0','P','0','2016-07-04 14:48:02','2016-07-04 15:43:02','1','7','1','92299561467668288','0');
INSERT INTO `rlb_custom_program_log` VALUES ('573','1','Valve 0','V','0','2016-07-04 15:04:02','2016-07-04 15:05:02','1','1','2','92299561467668288','1');
INSERT INTO `rlb_custom_program_log` VALUES ('574','1','Valve 4','V','4','2016-07-04 15:05:02','2016-07-04 15:06:02','1','3','1','92299561467668288','1');
INSERT INTO `rlb_custom_program_log` VALUES ('575','1','Valve 5','V','5','2016-07-04 15:06:02','2016-07-04 15:07:02','1','5','2','92299561467668288','1');
INSERT INTO `rlb_custom_program_log` VALUES ('576','6','Pump 2','PS','2','2016-07-04 15:02:03','2016-07-04 16:02:03','1','3','1','18022111467669503','0');
INSERT INTO `rlb_custom_program_log` VALUES ('577','6','Valve 6','V','6','2016-07-04 15:40:02','2016-07-04 15:41:02','1','1','1','18022111467669503','1');
INSERT INTO `rlb_custom_program_log` VALUES ('578','6','Valve 1','V','1','2016-07-04 20:34:45','2016-07-04 20:35:45','1','1','2','66557401467689685','0');
INSERT INTO `rlb_custom_program_log` VALUES ('579','6','Valve 2','V','2','2016-07-04 20:34:46','2016-07-04 20:35:46','1','1','2','66557401467689685','0');
INSERT INTO `rlb_custom_program_log` VALUES ('580','6','Valve 2','V','2','2016-07-04 20:34:46','2016-07-04 20:35:46','1','1','2','66557401467689685','0');
INSERT INTO `rlb_custom_program_log` VALUES ('581','6','Valve 5','V','5','2016-07-04 20:36:02','2016-07-04 20:37:02','1','2','1','66557401467689685','0');
INSERT INTO `rlb_custom_program_log` VALUES ('582','6','Valve 6','V','6','2016-07-04 20:36:02','2016-07-04 20:37:02','1','2','1','66557401467689685','0');
INSERT INTO `rlb_custom_program_log` VALUES ('583','6','Valve 6','V','6','2016-07-04 20:36:02','2016-07-04 20:37:02','1','2','1','66557401467689685','0');
INSERT INTO `rlb_custom_program_log` VALUES ('584','6','Pump 2','PS','2','2016-07-04 20:38:02','2016-07-04 21:38:02','1','3','1','66557401467689685','0');
INSERT INTO `rlb_custom_program_log` VALUES ('585','6','Valve 6','V','6','2016-07-04 21:38:02','2016-07-04 21:39:02','1','1','1','66557401467689685','1');
INSERT INTO `rlb_custom_program_log` VALUES ('586','6','Valve 1','V','1','2016-07-04 22:08:56','2016-07-04 22:09:56','1','1','2','79526881467695335','0');
INSERT INTO `rlb_custom_program_log` VALUES ('587','6','Valve 2','V','2','2016-07-04 22:08:56','2016-07-04 22:09:56','1','1','2','79526881467695335','0');
INSERT INTO `rlb_custom_program_log` VALUES ('588','6','Valve 2','V','2','2016-07-04 22:08:56','2016-07-04 22:09:56','1','1','2','79526881467695335','0');
INSERT INTO `rlb_custom_program_log` VALUES ('589','6','Valve 5','V','5','2016-07-04 22:10:02','2016-07-04 22:11:02','1','2','1','79526881467695335','0');
INSERT INTO `rlb_custom_program_log` VALUES ('590','6','Valve 6','V','6','2016-07-04 22:10:02','2016-07-04 22:11:02','1','2','1','79526881467695335','0');
INSERT INTO `rlb_custom_program_log` VALUES ('591','6','Valve 6','V','6','2016-07-04 22:10:02','2016-07-04 22:11:02','1','2','1','79526881467695335','0');
INSERT INTO `rlb_custom_program_log` VALUES ('592','6','Pump 2','PS','2','2016-07-04 22:11:03','2016-07-04 23:11:03','1','3','1','79526881467695335','0');
INSERT INTO `rlb_custom_program_log` VALUES ('593','6','Valve 6','V','6','2016-07-04 23:12:02','2016-07-04 23:13:02','1','1','1','79526881467695335','1');
INSERT INTO `rlb_custom_program_log` VALUES ('594','1','Valve 0','V','0','2016-07-06 17:12:53','2016-07-06 17:13:53','1','1','2','74724021467850373','0');
INSERT INTO `rlb_custom_program_log` VALUES ('595','1','Valve 3','V','3','2016-07-06 17:14:02','2016-07-06 17:15:02','1','2','2','74724021467850373','0');
INSERT INTO `rlb_custom_program_log` VALUES ('596','1','Valve 4','V','4','2016-07-06 17:15:02','2016-07-06 17:16:02','1','3','1','74724021467850373','0');
INSERT INTO `rlb_custom_program_log` VALUES ('597','1','Valve 4','V','4','2016-07-06 17:16:02','2016-07-06 17:17:02','1','4','2','74724021467850373','0');
INSERT INTO `rlb_custom_program_log` VALUES ('598','1','Valve 5','V','5','2016-07-06 17:17:02','2016-07-06 17:18:02','1','5','2','74724021467850373','0');
INSERT INTO `rlb_custom_program_log` VALUES ('599','1','Valve 5','V','5','2016-07-06 17:18:02','2016-07-06 17:19:02','1','6','1','74724021467850373','0');
INSERT INTO `rlb_custom_program_log` VALUES ('600','1','Valve 6','V','6','2016-07-06 17:18:02','2016-07-06 17:19:02','1','6','1','74724021467850373','0');
INSERT INTO `rlb_custom_program_log` VALUES ('601','1','Valve 6','V','6','2016-07-06 17:18:02','2016-07-06 17:19:02','1','6','1','74724021467850373','0');
INSERT INTO `rlb_custom_program_log` VALUES ('602','1','Pump 2','PS','2','2016-07-06 17:19:03','2016-07-06 17:20:03','1','7','1','74724021467850373','0');
INSERT INTO `rlb_custom_program_log` VALUES ('603','1','Relay 15','R','15','2016-07-06 17:19:03','2016-07-06 18:14:03','1','7','1','74724021467850373','0');
INSERT INTO `rlb_custom_program_log` VALUES ('604','1','Power Center 0','P','0','2016-07-06 17:19:03','2016-07-06 18:14:03','1','7','1','74724021467850373','0');
INSERT INTO `rlb_custom_program_log` VALUES ('605','1','Valve 4','V','4','2016-07-06 17:21:02','2016-07-06 17:22:02','1','1','1','74724021467850373','1');
INSERT INTO `rlb_custom_program_log` VALUES ('606','6','Valve 1','V','1','2016-07-06 17:20:43','2016-07-06 17:21:43','1','1','2','82987981467850842','0');
INSERT INTO `rlb_custom_program_log` VALUES ('607','6','Valve 2','V','2','2016-07-06 17:20:43','2016-07-06 17:21:43','1','1','2','82987981467850842','0');
INSERT INTO `rlb_custom_program_log` VALUES ('608','6','Valve 2','V','2','2016-07-06 17:20:43','2016-07-06 17:21:43','1','1','2','82987981467850842','0');
INSERT INTO `rlb_custom_program_log` VALUES ('609','1','Valve 6','V','6','2016-07-06 17:22:03','2016-07-06 17:23:03','1','6','1','74724021467850373','1');
INSERT INTO `rlb_custom_program_log` VALUES ('610','6','Valve 5','V','5','2016-07-06 17:22:04','2016-07-06 17:23:04','1','2','1','82987981467850842','0');
INSERT INTO `rlb_custom_program_log` VALUES ('611','6','Valve 6','V','6','2016-07-06 17:22:04','2016-07-06 17:23:04','1','2','1','82987981467850842','0');
INSERT INTO `rlb_custom_program_log` VALUES ('612','6','Valve 6','V','6','2016-07-06 17:22:04','2016-07-06 17:23:04','1','2','1','82987981467850842','0');
INSERT INTO `rlb_custom_program_log` VALUES ('613','45','Valve 5','V','5','2016-07-07 10:36:50','2016-07-07 10:37:50','1','1','1','46924031467913010','0');
INSERT INTO `rlb_custom_program_log` VALUES ('614','45','Valve 6','V','6','2016-07-07 10:38:03','2016-07-07 10:39:03','1','2','1','46924031467913010','0');
INSERT INTO `rlb_custom_program_log` VALUES ('615','45','Valve 2','V','2','2016-07-07 10:38:03','2016-07-07 10:39:03','1','2','2','46924031467913010','0');
INSERT INTO `rlb_custom_program_log` VALUES ('616','45','Valve 2','V','2','2016-07-07 10:38:03','2016-07-07 10:39:03','1','2','2','46924031467913010','0');
INSERT INTO `rlb_custom_program_log` VALUES ('617','45','Valve 0','V','0','2016-07-07 10:40:02','2016-07-07 10:41:02','1','3','2','46924031467913010','0');
INSERT INTO `rlb_custom_program_log` VALUES ('618','45','Valve 3','V','3','2016-07-07 10:40:02','2016-07-07 10:41:02','1','3','2','46924031467913010','0');
INSERT INTO `rlb_custom_program_log` VALUES ('619','45','Valve 3','V','3','2016-07-07 10:40:02','2016-07-07 10:41:02','1','3','2','46924031467913010','0');
INSERT INTO `rlb_custom_program_log` VALUES ('620','45','Valve 4','V','4','2016-07-07 10:41:02','2016-07-07 10:42:02','1','4','1','46924031467913010','0');
INSERT INTO `rlb_custom_program_log` VALUES ('621','45','Valve 5','V','5','2016-07-07 10:41:03','2016-07-07 10:42:03','1','4','2','46924031467913010','0');
INSERT INTO `rlb_custom_program_log` VALUES ('622','45','Valve 5','V','5','2016-07-07 10:41:03','2016-07-07 10:42:03','1','4','2','46924031467913010','0');
INSERT INTO `rlb_custom_program_log` VALUES ('623','45','Valve 4','V','4','2016-07-07 10:43:02','2016-07-07 10:44:02','1','5','2','46924031467913010','0');
INSERT INTO `rlb_custom_program_log` VALUES ('624','45','Pump 1','PS','1','2016-07-07 10:44:03','2016-07-07 11:44:03','1','6','1','46924031467913010','0');
INSERT INTO `rlb_custom_program_log` VALUES ('625','45','Pump 2','PS','2','2016-07-07 10:44:03','2016-07-07 10:59:03','1','6','1','46924031467913010','0');
INSERT INTO `rlb_custom_program_log` VALUES ('626','45','Pump 2','PS','2','2016-07-07 10:44:03','2016-07-07 10:59:03','1','6','1','46924031467913010','0');
INSERT INTO `rlb_custom_program_log` VALUES ('627','45','Valve 5','V','5','2016-07-07 10:48:02','2016-07-07 10:49:02','1','1','1','46924031467913010','1');
INSERT INTO `rlb_custom_program_log` VALUES ('628','45','Valve 2','V','2','2016-07-07 10:49:02','2016-07-07 10:50:02','1','2','2','46924031467913010','1');
INSERT INTO `rlb_custom_program_log` VALUES ('629','45','Valve 3','V','3','2016-07-07 10:50:02','2016-07-07 10:51:02','1','3','2','46924031467913010','1');
INSERT INTO `rlb_custom_program_log` VALUES ('630','45','Valve 5','V','5','2016-07-07 10:51:02','2016-07-07 10:52:02','1','4','2','46924031467913010','1');
INSERT INTO `rlb_custom_program_log` VALUES ('631','45','Valve 4','V','4','2016-07-07 10:52:02','2016-07-07 10:53:02','1','5','2','46924031467913010','1');
INSERT INTO `rlb_custom_program_log` VALUES ('632','1','Valve 0','V','0','2016-07-07 10:55:08','2016-07-07 10:56:08','1','1','2','73360801467914107','0');
INSERT INTO `rlb_custom_program_log` VALUES ('633','1','Valve 3','V','3','2016-07-07 10:57:02','2016-07-07 10:58:02','1','2','2','73360801467914107','0');
INSERT INTO `rlb_custom_program_log` VALUES ('634','1','Valve 4','V','4','2016-07-07 10:59:02','2016-07-07 11:00:02','1','3','1','73360801467914107','0');
INSERT INTO `rlb_custom_program_log` VALUES ('635','1','Valve 4','V','4','2016-07-07 11:00:02','2016-07-07 11:01:02','1','4','2','73360801467914107','0');
INSERT INTO `rlb_custom_program_log` VALUES ('636','1','Valve 5','V','5','2016-07-07 11:02:02','2016-07-07 11:03:02','1','5','2','73360801467914107','0');
INSERT INTO `rlb_custom_program_log` VALUES ('637','1','Valve 5','V','5','2016-07-07 11:03:02','2016-07-07 11:04:02','1','6','1','73360801467914107','0');
INSERT INTO `rlb_custom_program_log` VALUES ('638','1','Valve 6','V','6','2016-07-07 11:03:02','2016-07-07 11:04:02','1','6','1','73360801467914107','0');
INSERT INTO `rlb_custom_program_log` VALUES ('639','1','Valve 6','V','6','2016-07-07 11:03:02','2016-07-07 11:04:02','1','6','1','73360801467914107','0');
INSERT INTO `rlb_custom_program_log` VALUES ('640','1','Pump 2','PS','2','2016-07-07 11:04:02','2016-07-07 11:05:02','1','7','1','73360801467914107','0');
INSERT INTO `rlb_custom_program_log` VALUES ('641','6','Valve 1','V','1','2016-07-07 11:27:59','2016-07-07 11:28:59','1','1','2','38328531467916078','0');
INSERT INTO `rlb_custom_program_log` VALUES ('642','6','Valve 2','V','2','2016-07-07 11:27:59','2016-07-07 11:28:59','1','1','2','38328531467916078','0');
INSERT INTO `rlb_custom_program_log` VALUES ('643','6','Valve 2','V','2','2016-07-07 11:27:59','2016-07-07 11:28:59','1','1','2','38328531467916078','0');
INSERT INTO `rlb_custom_program_log` VALUES ('644','6','Valve 5','V','5','2016-07-07 11:29:02','2016-07-07 11:30:02','1','2','1','38328531467916078','0');
INSERT INTO `rlb_custom_program_log` VALUES ('645','6','Valve 6','V','6','2016-07-07 11:29:03','2016-07-07 11:30:03','1','2','1','38328531467916078','0');
INSERT INTO `rlb_custom_program_log` VALUES ('646','6','Valve 6','V','6','2016-07-07 11:29:03','2016-07-07 11:30:03','1','2','1','38328531467916078','0');
INSERT INTO `rlb_custom_program_log` VALUES ('647','6','Valve 5','V','5','2016-07-07 11:30:02','2016-07-07 11:31:02','1','1','1','38328531467916078','1');
INSERT INTO `rlb_custom_program_log` VALUES ('648','6','Valve 1','V','1','2016-07-07 11:50:18','2016-07-07 11:51:18','1','1','2','44421861467917418','0');
INSERT INTO `rlb_custom_program_log` VALUES ('649','6','Valve 2','V','2','2016-07-07 11:50:18','2016-07-07 11:51:18','1','1','2','44421861467917418','0');
INSERT INTO `rlb_custom_program_log` VALUES ('650','6','Valve 2','V','2','2016-07-07 11:50:18','2016-07-07 11:51:18','1','1','2','44421861467917418','0');
INSERT INTO `rlb_custom_program_log` VALUES ('651','6','Valve 5','V','5','2016-07-07 11:52:03','2016-07-07 11:53:03','1','2','1','44421861467917418','0');
INSERT INTO `rlb_custom_program_log` VALUES ('652','6','Valve 6','V','6','2016-07-07 11:52:03','2016-07-07 11:53:03','1','2','1','44421861467917418','0');
INSERT INTO `rlb_custom_program_log` VALUES ('653','6','Valve 6','V','6','2016-07-07 11:52:03','2016-07-07 11:53:03','1','2','1','44421861467917418','0');
INSERT INTO `rlb_custom_program_log` VALUES ('654','1','Relay 15','R','15','2016-07-07 11:04:02','2016-07-07 11:59:02','1','7','1','73360801467914107','0');
INSERT INTO `rlb_custom_program_log` VALUES ('655','1','Power Center 0','P','0','2016-07-07 11:04:04','2016-07-07 11:59:04','1','7','1','73360801467914107','0');
INSERT INTO `rlb_custom_program_log` VALUES ('656','1','Valve 4','V','4','2016-07-07 12:00:03','2016-07-07 12:01:03','1','1','1','73360801467914107','1');
INSERT INTO `rlb_custom_program_log` VALUES ('657','1','Valve 6','V','6','2016-07-07 12:02:02','2016-07-07 12:03:02','1','6','1','73360801467914107','1');
INSERT INTO `rlb_custom_program_log` VALUES ('658','6','Pump 2','PS','2','2016-07-07 11:54:03','2016-07-07 12:54:03','1','3','1','44421861467917418','0');
INSERT INTO `rlb_custom_program_log` VALUES ('659','6','Valve 5','V','5','2016-07-07 12:55:02','2016-07-07 12:56:02','1','1','1','44421861467917418','1');
INSERT INTO `rlb_custom_program_log` VALUES ('660','3','Valve 0','V','0','2016-07-07 16:01:29','2016-07-07 16:02:29','1','1','1','41662961467932488','0');
INSERT INTO `rlb_custom_program_log` VALUES ('661','3','Valve 4','V','4','2016-07-07 16:01:30','2016-07-07 16:02:30','1','1','1','41662961467932488','0');
INSERT INTO `rlb_custom_program_log` VALUES ('662','3','Valve 4','V','4','2016-07-07 16:01:30','2016-07-07 16:02:30','1','1','1','41662961467932488','0');
INSERT INTO `rlb_custom_program_log` VALUES ('663','3','Valve 0','V','0','2016-07-07 16:03:02','2016-07-07 16:04:02','1','2','2','41662961467932488','0');
INSERT INTO `rlb_custom_program_log` VALUES ('664','3','Valve 4','V','4','2016-07-07 16:04:02','2016-07-07 16:05:02','1','3','2','41662961467932488','0');
INSERT INTO `rlb_custom_program_log` VALUES ('665','3','Valve 5','V','5','2016-07-07 16:04:02','2016-07-07 16:05:02','1','3','2','41662961467932488','0');
INSERT INTO `rlb_custom_program_log` VALUES ('666','3','Valve 5','V','5','2016-07-07 16:04:02','2016-07-07 16:05:02','1','3','2','41662961467932488','0');
INSERT INTO `rlb_custom_program_log` VALUES ('667','3','Pump 1','PS','1','2016-07-07 16:05:02','2016-07-07 16:06:02','1','4','1','41662961467932488','0');
INSERT INTO `rlb_custom_program_log` VALUES ('668','3','Valve 0','V','0','2016-07-07 16:16:23','2016-07-07 16:17:23','1','1','1','10268661467933383','0');
INSERT INTO `rlb_custom_program_log` VALUES ('669','3','Valve 4','V','4','2016-07-07 16:16:24','2016-07-07 16:17:24','1','1','1','10268661467933383','0');
INSERT INTO `rlb_custom_program_log` VALUES ('670','3','Valve 4','V','4','2016-07-07 16:16:24','2016-07-07 16:17:24','1','1','1','10268661467933383','0');
INSERT INTO `rlb_custom_program_log` VALUES ('671','3','Valve 0','V','0','2016-07-07 16:18:02','2016-07-07 16:19:02','1','2','2','10268661467933383','0');
INSERT INTO `rlb_custom_program_log` VALUES ('672','3','Valve 4','V','4','2016-07-07 16:19:02','2016-07-07 16:20:02','1','3','2','10268661467933383','0');
INSERT INTO `rlb_custom_program_log` VALUES ('673','3','Valve 5','V','5','2016-07-07 16:19:02','2016-07-07 16:20:02','1','3','2','10268661467933383','0');
INSERT INTO `rlb_custom_program_log` VALUES ('674','3','Valve 5','V','5','2016-07-07 16:19:02','2016-07-07 16:20:02','1','3','2','10268661467933383','0');
INSERT INTO `rlb_custom_program_log` VALUES ('675','3','Pump 1','PS','1','2016-07-07 16:20:02','2016-07-07 16:21:02','1','4','1','10268661467933383','0');
INSERT INTO `rlb_custom_program_log` VALUES ('676','3','Valve 0','V','0','2016-07-07 16:25:00','2016-07-07 16:26:00','1','1','1','26321361467933899','0');
INSERT INTO `rlb_custom_program_log` VALUES ('677','3','Valve 4','V','4','2016-07-07 16:25:00','2016-07-07 16:26:00','1','1','1','26321361467933899','0');
INSERT INTO `rlb_custom_program_log` VALUES ('678','3','Valve 4','V','4','2016-07-07 16:25:00','2016-07-07 16:26:00','1','1','1','26321361467933899','0');
INSERT INTO `rlb_custom_program_log` VALUES ('679','3','Valve 0','V','0','2016-07-07 16:26:02','2016-07-07 16:27:02','1','2','2','26321361467933899','0');
INSERT INTO `rlb_custom_program_log` VALUES ('680','3','Valve 4','V','4','2016-07-07 16:27:03','2016-07-07 16:28:03','1','3','2','26321361467933899','0');
INSERT INTO `rlb_custom_program_log` VALUES ('681','3','Valve 5','V','5','2016-07-07 16:27:03','2016-07-07 16:28:03','1','3','2','26321361467933899','0');
INSERT INTO `rlb_custom_program_log` VALUES ('682','3','Valve 5','V','5','2016-07-07 16:27:03','2016-07-07 16:28:03','1','3','2','26321361467933899','0');
INSERT INTO `rlb_custom_program_log` VALUES ('683','3','Pump 1','PS','1','2016-07-07 16:29:03','2016-07-07 16:30:03','1','4','1','26321361467933899','0');
INSERT INTO `rlb_custom_program_log` VALUES ('684','3','Valve 0','V','0','2016-07-07 16:33:55','2016-07-07 16:34:55','1','1','1','15882121467934435','0');
INSERT INTO `rlb_custom_program_log` VALUES ('685','3','Valve 4','V','4','2016-07-07 16:33:56','2016-07-07 16:34:56','1','1','1','15882121467934435','0');
INSERT INTO `rlb_custom_program_log` VALUES ('686','3','Valve 4','V','4','2016-07-07 16:33:56','2016-07-07 16:34:56','1','1','1','15882121467934435','0');
INSERT INTO `rlb_custom_program_log` VALUES ('687','3','Valve 0','V','0','2016-07-07 16:35:02','2016-07-07 16:36:02','1','2','2','15882121467934435','0');
INSERT INTO `rlb_custom_program_log` VALUES ('688','3','Valve 4','V','4','2016-07-07 16:36:02','2016-07-07 16:37:02','1','3','2','15882121467934435','0');
INSERT INTO `rlb_custom_program_log` VALUES ('689','3','Valve 5','V','5','2016-07-07 16:36:03','2016-07-07 16:37:03','1','3','2','15882121467934435','0');
INSERT INTO `rlb_custom_program_log` VALUES ('690','3','Valve 5','V','5','2016-07-07 16:36:03','2016-07-07 16:37:03','1','3','2','15882121467934435','0');
INSERT INTO `rlb_custom_program_log` VALUES ('691','3','Pump 1','PS','1','2016-07-07 16:38:03','2016-07-07 16:48:03','1','4','1','15882121467934435','0');
INSERT INTO `rlb_custom_program_log` VALUES ('692','45','Valve 5','V','5','2016-07-07 17:05:59','2016-07-07 17:06:59','1','1','1','80982391467936359','0');
INSERT INTO `rlb_custom_program_log` VALUES ('693','45','Valve 6','V','6','2016-07-07 17:07:02','2016-07-07 17:08:02','1','2','1','80982391467936359','0');
INSERT INTO `rlb_custom_program_log` VALUES ('694','45','Valve 2','V','2','2016-07-07 17:07:02','2016-07-07 17:08:02','1','2','2','80982391467936359','0');
INSERT INTO `rlb_custom_program_log` VALUES ('695','45','Valve 2','V','2','2016-07-07 17:07:02','2016-07-07 17:08:02','1','2','2','80982391467936359','0');
INSERT INTO `rlb_custom_program_log` VALUES ('696','45','Valve 0','V','0','2016-07-07 17:08:02','2016-07-07 17:09:02','1','3','2','80982391467936359','0');
INSERT INTO `rlb_custom_program_log` VALUES ('697','45','Valve 3','V','3','2016-07-07 17:08:02','2016-07-07 17:09:02','1','3','2','80982391467936359','0');
INSERT INTO `rlb_custom_program_log` VALUES ('698','45','Valve 3','V','3','2016-07-07 17:08:02','2016-07-07 17:09:02','1','3','2','80982391467936359','0');
INSERT INTO `rlb_custom_program_log` VALUES ('699','45','Valve 4','V','4','2016-07-07 17:09:03','2016-07-07 17:10:03','1','4','1','80982391467936359','0');
INSERT INTO `rlb_custom_program_log` VALUES ('700','45','Valve 5','V','5','2016-07-07 17:09:03','2016-07-07 17:10:03','1','4','2','80982391467936359','0');
INSERT INTO `rlb_custom_program_log` VALUES ('701','45','Valve 5','V','5','2016-07-07 17:09:03','2016-07-07 17:10:03','1','4','2','80982391467936359','0');
INSERT INTO `rlb_custom_program_log` VALUES ('702','45','Valve 4','V','4','2016-07-07 17:11:02','2016-07-07 17:12:02','1','5','2','80982391467936359','0');
INSERT INTO `rlb_custom_program_log` VALUES ('703','45','Pump 1','PS','1','2016-07-07 17:12:02','2016-07-07 17:13:02','1','6','1','80982391467936359','0');
INSERT INTO `rlb_custom_program_log` VALUES ('704','45','Valve 5','V','5','2016-07-07 17:13:03','2016-07-07 17:14:03','1','1','1','80982391467936359','1');
INSERT INTO `rlb_custom_program_log` VALUES ('705','45','Valve 2','V','2','2016-07-07 17:15:02','2016-07-07 17:16:02','1','2','2','80982391467936359','1');
INSERT INTO `rlb_custom_program_log` VALUES ('706','45','Valve 3','V','3','2016-07-07 17:17:02','2016-07-07 17:18:02','1','3','2','80982391467936359','1');
INSERT INTO `rlb_custom_program_log` VALUES ('707','45','Valve 5','V','5','2016-07-07 17:19:02','2016-07-07 17:20:02','1','4','2','80982391467936359','1');
INSERT INTO `rlb_custom_program_log` VALUES ('708','45','Valve 4','V','4','2016-07-07 17:20:02','2016-07-07 17:21:02','1','5','2','80982391467936359','1');
INSERT INTO `rlb_custom_program_log` VALUES ('709','6','Valve 1','V','1','2016-07-07 20:06:22','2016-07-07 20:07:22','1','1','2','48743291467947180','0');
INSERT INTO `rlb_custom_program_log` VALUES ('710','6','Valve 2','V','2','2016-07-07 20:06:23','2016-07-07 20:07:23','1','1','2','48743291467947180','0');
INSERT INTO `rlb_custom_program_log` VALUES ('711','6','Valve 2','V','2','2016-07-07 20:06:23','2016-07-07 20:07:23','1','1','2','48743291467947180','0');
INSERT INTO `rlb_custom_program_log` VALUES ('712','6','Valve 5','V','5','2016-07-07 20:08:02','2016-07-07 20:09:02','1','2','1','48743291467947180','0');
INSERT INTO `rlb_custom_program_log` VALUES ('713','6','Valve 6','V','6','2016-07-07 20:08:02','2016-07-07 20:09:02','1','2','1','48743291467947180','0');
INSERT INTO `rlb_custom_program_log` VALUES ('714','6','Valve 6','V','6','2016-07-07 20:08:02','2016-07-07 20:09:02','1','2','1','48743291467947180','0');
INSERT INTO `rlb_custom_program_log` VALUES ('715','6','Pump 2','PS','2','2016-07-07 20:09:02','2016-07-07 21:09:02','1','3','1','48743291467947180','0');
INSERT INTO `rlb_custom_program_log` VALUES ('716','6','Valve 5','V','5','2016-07-07 20:12:02','2016-07-07 20:13:02','1','1','1','48743291467947180','1');
INSERT INTO `rlb_custom_program_log` VALUES ('717','45','Valve 5','V','5','2016-07-08 09:12:25','2016-07-08 09:13:25','1','1','1','29341061467994345','0');
INSERT INTO `rlb_custom_program_log` VALUES ('718','45','Valve 6','V','6','2016-07-08 09:14:03','2016-07-08 09:15:03','1','2','1','29341061467994345','0');
INSERT INTO `rlb_custom_program_log` VALUES ('719','45','Valve 2','V','2','2016-07-08 09:14:03','2016-07-08 09:15:03','1','2','2','29341061467994345','0');
INSERT INTO `rlb_custom_program_log` VALUES ('720','45','Valve 2','V','2','2016-07-08 09:14:03','2016-07-08 09:15:03','1','2','2','29341061467994345','0');
INSERT INTO `rlb_custom_program_log` VALUES ('721','45','Valve 0','V','0','2016-07-08 09:15:03','2016-07-08 09:16:03','1','3','2','29341061467994345','0');
INSERT INTO `rlb_custom_program_log` VALUES ('722','45','Valve 3','V','3','2016-07-08 09:15:03','2016-07-08 09:16:03','1','3','2','29341061467994345','0');
INSERT INTO `rlb_custom_program_log` VALUES ('723','45','Valve 3','V','3','2016-07-08 09:15:03','2016-07-08 09:16:03','1','3','2','29341061467994345','0');
INSERT INTO `rlb_custom_program_log` VALUES ('724','45','Valve 4','V','4','2016-07-08 09:17:02','2016-07-08 09:18:02','1','4','1','29341061467994345','0');
INSERT INTO `rlb_custom_program_log` VALUES ('725','45','Valve 5','V','5','2016-07-08 09:17:02','2016-07-08 09:18:02','1','4','2','29341061467994345','0');
INSERT INTO `rlb_custom_program_log` VALUES ('726','45','Valve 5','V','5','2016-07-08 09:17:02','2016-07-08 09:18:02','1','4','2','29341061467994345','0');
INSERT INTO `rlb_custom_program_log` VALUES ('727','45','Valve 4','V','4','2016-07-08 09:18:02','2016-07-08 09:19:02','1','5','2','29341061467994345','0');
INSERT INTO `rlb_custom_program_log` VALUES ('728','45','Pump 1','PS','1','2016-07-08 09:19:02','2016-07-08 09:20:02','1','6','1','29341061467994345','0');
INSERT INTO `rlb_custom_program_log` VALUES ('729','45','Valve 5','V','5','2016-07-08 09:20:02','2016-07-08 09:21:02','1','1','1','29341061467994345','1');
INSERT INTO `rlb_custom_program_log` VALUES ('730','45','Valve 2','V','2','2016-07-08 09:21:04','2016-07-08 09:22:04','1','2','2','29341061467994345','1');
INSERT INTO `rlb_custom_program_log` VALUES ('731','6','Valve 1','V','1','2016-07-08 19:46:27','2016-07-08 19:47:27','1','1','2','66952181468032386','0');
INSERT INTO `rlb_custom_program_log` VALUES ('732','6','Valve 2','V','2','2016-07-08 19:46:27','2016-07-08 19:47:27','1','1','2','66952181468032386','0');
INSERT INTO `rlb_custom_program_log` VALUES ('733','6','Valve 2','V','2','2016-07-08 19:46:27','2016-07-08 19:47:27','1','1','2','66952181468032386','0');
INSERT INTO `rlb_custom_program_log` VALUES ('734','6','Valve 5','V','5','2016-07-08 19:47:01','2016-07-08 19:48:01','1','1','1','66952181468032386','1');
INSERT INTO `rlb_custom_program_log` VALUES ('735','1','Valve 0','V','0','2016-07-08 19:46:56','2016-07-08 19:47:56','1','1','2','25212311468032416','0');
INSERT INTO `rlb_custom_program_log` VALUES ('736','6','Valve 1','V','1','2016-07-08 19:47:13','2016-07-08 19:48:13','1','1','2','48537361468032432','0');
INSERT INTO `rlb_custom_program_log` VALUES ('737','6','Valve 2','V','2','2016-07-08 19:47:13','2016-07-08 19:48:13','1','1','2','48537361468032432','0');
INSERT INTO `rlb_custom_program_log` VALUES ('738','6','Valve 2','V','2','2016-07-08 19:47:13','2016-07-08 19:48:13','1','1','2','48537361468032432','0');
INSERT INTO `rlb_custom_program_log` VALUES ('739','6','Valve 5','V','5','2016-07-08 19:49:03','2016-07-08 19:50:03','1','2','1','48537361468032432','0');
INSERT INTO `rlb_custom_program_log` VALUES ('740','6','Valve 6','V','6','2016-07-08 19:49:03','2016-07-08 19:50:03','1','2','1','48537361468032432','0');
INSERT INTO `rlb_custom_program_log` VALUES ('741','6','Valve 6','V','6','2016-07-08 19:49:03','2016-07-08 19:50:03','1','2','1','48537361468032432','0');
INSERT INTO `rlb_custom_program_log` VALUES ('742','1','Valve 3','V','3','2016-07-08 19:48:07','2016-07-08 19:49:07','1','2','2','25212311468032416','0');
INSERT INTO `rlb_custom_program_log` VALUES ('743','6','Valve 1','V','1','2016-07-08 19:49:56','2016-07-08 19:50:56','1','1','2','97651321468032596','0');
INSERT INTO `rlb_custom_program_log` VALUES ('744','6','Valve 2','V','2','2016-07-08 19:49:56','2016-07-08 19:50:56','1','1','2','97651321468032596','0');
INSERT INTO `rlb_custom_program_log` VALUES ('745','6','Valve 2','V','2','2016-07-08 19:49:56','2016-07-08 19:50:56','1','1','2','97651321468032596','0');
INSERT INTO `rlb_custom_program_log` VALUES ('746','1','Valve 4','V','4','2016-07-08 19:50:02','2016-07-08 19:51:02','1','3','1','25212311468032416','0');
INSERT INTO `rlb_custom_program_log` VALUES ('747','6','Valve 5','V','5','2016-07-08 19:51:02','2016-07-08 19:52:02','1','2','1','97651321468032596','0');
INSERT INTO `rlb_custom_program_log` VALUES ('748','6','Valve 6','V','6','2016-07-08 19:51:02','2016-07-08 19:52:02','1','2','1','97651321468032596','0');
INSERT INTO `rlb_custom_program_log` VALUES ('749','6','Valve 6','V','6','2016-07-08 19:51:02','2016-07-08 19:52:02','1','2','1','97651321468032596','0');
INSERT INTO `rlb_custom_program_log` VALUES ('750','1','Valve 4','V','4','2016-07-08 19:52:02','2016-07-08 19:53:02','1','4','2','25212311468032416','0');
INSERT INTO `rlb_custom_program_log` VALUES ('751','1','Valve 5','V','5','2016-07-08 19:53:02','2016-07-08 19:54:02','1','5','2','25212311468032416','0');
INSERT INTO `rlb_custom_program_log` VALUES ('752','1','Valve 5','V','5','2016-07-08 19:54:02','2016-07-08 19:55:02','1','6','1','25212311468032416','0');
INSERT INTO `rlb_custom_program_log` VALUES ('753','1','Valve 6','V','6','2016-07-08 19:54:02','2016-07-08 19:55:02','1','6','1','25212311468032416','0');
INSERT INTO `rlb_custom_program_log` VALUES ('754','1','Valve 6','V','6','2016-07-08 19:54:02','2016-07-08 19:55:02','1','6','1','25212311468032416','0');
INSERT INTO `rlb_custom_program_log` VALUES ('755','6','Pump 2','PS','2','2016-07-08 19:52:03','2016-07-08 20:52:03','1','3','1','97651321468032596','0');
INSERT INTO `rlb_custom_program_log` VALUES ('756','1','Pump 2','PS','2','2016-07-08 19:56:03','2016-07-08 19:57:03','1','7','1','25212311468032416','0');
INSERT INTO `rlb_custom_program_log` VALUES ('757','1','Relay 15','R','15','2016-07-08 19:56:03','2016-07-08 20:51:03','1','7','1','25212311468032416','0');
INSERT INTO `rlb_custom_program_log` VALUES ('758','1','Power Center 0','P','0','2016-07-08 19:56:03','2016-07-08 20:51:03','1','7','1','25212311468032416','0');
INSERT INTO `rlb_custom_program_log` VALUES ('759','1','Valve 0','V','0','2016-07-08 19:57:39','2016-07-08 19:58:39','1','1','2','21410621468033058','0');
INSERT INTO `rlb_custom_program_log` VALUES ('760','6','Valve 1','V','1','2016-07-08 19:57:49','2016-07-08 19:58:49','1','1','2','10510371468033069','0');
INSERT INTO `rlb_custom_program_log` VALUES ('761','6','Valve 2','V','2','2016-07-08 19:57:50','2016-07-08 19:58:50','1','1','2','10510371468033069','0');
INSERT INTO `rlb_custom_program_log` VALUES ('762','6','Valve 2','V','2','2016-07-08 19:57:50','2016-07-08 19:58:50','1','1','2','10510371468033069','0');
INSERT INTO `rlb_custom_program_log` VALUES ('763','6','Valve 5','V','5','2016-07-08 19:59:03','2016-07-08 20:00:03','1','2','1','10510371468033069','0');
INSERT INTO `rlb_custom_program_log` VALUES ('764','6','Valve 6','V','6','2016-07-08 19:59:03','2016-07-08 20:00:03','1','2','1','10510371468033069','0');
INSERT INTO `rlb_custom_program_log` VALUES ('765','6','Valve 6','V','6','2016-07-08 19:59:03','2016-07-08 20:00:03','1','2','1','10510371468033069','0');
INSERT INTO `rlb_custom_program_log` VALUES ('766','1','Valve 3','V','3','2016-07-08 19:59:02','2016-07-08 20:00:02','1','2','2','21410621468033058','0');
INSERT INTO `rlb_custom_program_log` VALUES ('767','6','Valve 1','V','1','2016-07-08 19:59:58','2016-07-08 20:00:58','1','1','2','41797281468033198','0');
INSERT INTO `rlb_custom_program_log` VALUES ('768','6','Valve 2','V','2','2016-07-08 19:59:58','2016-07-08 20:00:58','1','1','2','41797281468033198','0');
INSERT INTO `rlb_custom_program_log` VALUES ('769','6','Valve 2','V','2','2016-07-08 19:59:58','2016-07-08 20:00:58','1','1','2','41797281468033198','0');
INSERT INTO `rlb_custom_program_log` VALUES ('770','1','Valve 4','V','4','2016-07-08 20:00:02','2016-07-08 20:01:02','1','1','1','21410621468033058','1');
INSERT INTO `rlb_custom_program_log` VALUES ('771','3','Valve 0','V','0','2016-07-08 19:59:12','2016-07-08 20:00:12','1','1','1','83853071468033152','0');
INSERT INTO `rlb_custom_program_log` VALUES ('772','3','Valve 4','V','4','2016-07-08 19:59:12','2016-07-08 20:00:12','1','1','1','83853071468033152','0');
INSERT INTO `rlb_custom_program_log` VALUES ('773','3','Valve 4','V','4','2016-07-08 19:59:12','2016-07-08 20:00:12','1','1','1','83853071468033152','0');
INSERT INTO `rlb_custom_program_log` VALUES ('774','1','Valve 6','V','6','2016-07-08 20:01:02','2016-07-08 20:02:02','1','6','1','21410621468033058','1');
INSERT INTO `rlb_custom_program_log` VALUES ('775','6','Valve 5','V','5','2016-07-08 20:01:03','2016-07-08 20:02:03','1','1','1','41797281468033198','1');
INSERT INTO `rlb_custom_program_log` VALUES ('776','3','Valve 0','V','0','2016-07-08 20:01:03','2016-07-08 20:02:03','1','2','2','83853071468033152','0');
INSERT INTO `rlb_custom_program_log` VALUES ('777','1','Valve 0','V','0','2016-07-08 20:02:40','2016-07-08 20:03:40','1','1','2','31610251468033360','0');
INSERT INTO `rlb_custom_program_log` VALUES ('778','6','Valve 1','V','1','2016-07-08 20:02:44','2016-07-08 20:03:44','1','1','2','96966421468033364','0');
INSERT INTO `rlb_custom_program_log` VALUES ('779','6','Valve 2','V','2','2016-07-08 20:02:45','2016-07-08 20:03:45','1','1','2','96966421468033364','0');
INSERT INTO `rlb_custom_program_log` VALUES ('780','6','Valve 2','V','2','2016-07-08 20:02:45','2016-07-08 20:03:45','1','1','2','96966421468033364','0');
INSERT INTO `rlb_custom_program_log` VALUES ('781','1','Valve 3','V','3','2016-07-08 20:04:02','2016-07-08 20:05:02','1','2','2','31610251468033360','0');
INSERT INTO `rlb_custom_program_log` VALUES ('782','3','Valve 4','V','4','2016-07-08 20:03:03','2016-07-08 20:04:03','1','3','2','83853071468033152','0');
INSERT INTO `rlb_custom_program_log` VALUES ('783','3','Valve 5','V','5','2016-07-08 20:03:03','2016-07-08 20:04:03','1','3','2','83853071468033152','0');
INSERT INTO `rlb_custom_program_log` VALUES ('784','3','Valve 5','V','5','2016-07-08 20:03:03','2016-07-08 20:04:03','1','3','2','83853071468033152','0');
INSERT INTO `rlb_custom_program_log` VALUES ('785','6','Valve 5','V','5','2016-07-08 20:04:02','2016-07-08 20:05:02','1','2','1','96966421468033364','0');
INSERT INTO `rlb_custom_program_log` VALUES ('786','6','Valve 6','V','6','2016-07-08 20:04:02','2016-07-08 20:05:02','1','2','1','96966421468033364','0');
INSERT INTO `rlb_custom_program_log` VALUES ('787','6','Valve 6','V','6','2016-07-08 20:04:02','2016-07-08 20:05:02','1','2','1','96966421468033364','0');
INSERT INTO `rlb_custom_program_log` VALUES ('788','1','Valve 4','V','4','2016-07-08 20:05:02','2016-07-08 20:06:02','1','3','1','31610251468033360','0');
INSERT INTO `rlb_custom_program_log` VALUES ('789','1','Valve 4','V','4','2016-07-08 20:06:02','2016-07-08 20:07:02','1','4','2','31610251468033360','0');
INSERT INTO `rlb_custom_program_log` VALUES ('790','1','Valve 5','V','5','2016-07-08 20:07:02','2016-07-08 20:08:02','1','5','2','31610251468033360','0');
INSERT INTO `rlb_custom_program_log` VALUES ('791','1','Valve 5','V','5','2016-07-08 20:08:02','2016-07-08 20:09:02','1','6','1','31610251468033360','0');
INSERT INTO `rlb_custom_program_log` VALUES ('792','1','Valve 6','V','6','2016-07-08 20:08:02','2016-07-08 20:09:02','1','6','1','31610251468033360','0');
INSERT INTO `rlb_custom_program_log` VALUES ('793','1','Valve 6','V','6','2016-07-08 20:08:02','2016-07-08 20:09:02','1','6','1','31610251468033360','0');
INSERT INTO `rlb_custom_program_log` VALUES ('794','1','Pump 2','PS','2','2016-07-08 20:09:03','2016-07-08 20:10:03','1','7','1','31610251468033360','0');
INSERT INTO `rlb_custom_program_log` VALUES ('795','3','Pump 1','PS','1','2016-07-08 20:05:02','2016-07-08 20:15:02','1','4','1','83853071468033152','0');
INSERT INTO `rlb_custom_program_log` VALUES ('796','6','Pump 2','PS','2','2016-07-08 20:05:03','2016-07-08 21:05:03','1','3','1','96966421468033364','0');
INSERT INTO `rlb_custom_program_log` VALUES ('797','6','Valve 1','V','1','2016-07-08 20:49:54','2016-07-08 20:50:54','1','1','2','96752961468036194','0');
INSERT INTO `rlb_custom_program_log` VALUES ('798','6','Valve 2','V','2','2016-07-08 20:49:55','2016-07-08 20:50:55','1','1','2','96752961468036194','0');
INSERT INTO `rlb_custom_program_log` VALUES ('799','6','Valve 2','V','2','2016-07-08 20:49:55','2016-07-08 20:50:55','1','1','2','96752961468036194','0');
INSERT INTO `rlb_custom_program_log` VALUES ('800','6','Valve 5','V','5','2016-07-08 20:51:03','2016-07-08 20:52:03','1','2','1','96752961468036194','0');
INSERT INTO `rlb_custom_program_log` VALUES ('801','6','Valve 6','V','6','2016-07-08 20:51:03','2016-07-08 20:52:03','1','2','1','96752961468036194','0');
INSERT INTO `rlb_custom_program_log` VALUES ('802','6','Valve 6','V','6','2016-07-08 20:51:03','2016-07-08 20:52:03','1','2','1','96752961468036194','0');
INSERT INTO `rlb_custom_program_log` VALUES ('803','6','Pump 2','PS','2','2016-07-08 20:53:03','2016-07-08 21:53:03','1','3','1','96752961468036194','0');
INSERT INTO `rlb_custom_program_log` VALUES ('804','6','Valve 1','V','1','2016-07-08 20:53:28','2016-07-08 20:54:28','1','1','2','90219251468036408','0');
INSERT INTO `rlb_custom_program_log` VALUES ('805','6','Valve 2','V','2','2016-07-08 20:53:29','2016-07-08 20:54:29','1','1','2','90219251468036408','0');
INSERT INTO `rlb_custom_program_log` VALUES ('806','6','Valve 2','V','2','2016-07-08 20:53:29','2016-07-08 20:54:29','1','1','2','90219251468036408','0');
INSERT INTO `rlb_custom_program_log` VALUES ('807','6','Valve 5','V','5','2016-07-08 20:55:03','2016-07-08 20:56:03','1','2','1','90219251468036408','0');
INSERT INTO `rlb_custom_program_log` VALUES ('808','6','Valve 6','V','6','2016-07-08 20:55:03','2016-07-08 20:56:03','1','2','1','90219251468036408','0');
INSERT INTO `rlb_custom_program_log` VALUES ('809','6','Valve 6','V','6','2016-07-08 20:55:03','2016-07-08 20:56:03','1','2','1','90219251468036408','0');
INSERT INTO `rlb_custom_program_log` VALUES ('810','1','Relay 15','R','15','2016-07-08 20:09:03','2016-07-08 21:04:03','1','7','1','31610251468033360','0');
INSERT INTO `rlb_custom_program_log` VALUES ('811','1','Power Center 0','P','0','2016-07-08 20:09:03','2016-07-08 21:04:03','1','7','1','31610251468033360','0');
INSERT INTO `rlb_custom_program_log` VALUES ('812','1','Valve 4','V','4','2016-07-08 21:05:02','2016-07-08 21:06:02','1','1','1','31610251468033360','1');
INSERT INTO `rlb_custom_program_log` VALUES ('813','1','Valve 6','V','6','2016-07-08 21:07:02','2016-07-08 21:08:02','1','6','1','31610251468033360','1');
INSERT INTO `rlb_custom_program_log` VALUES ('814','6','Pump 2','PS','2','2016-07-08 20:57:02','2016-07-08 21:57:02','1','3','1','90219251468036408','0');
INSERT INTO `rlb_custom_program_log` VALUES ('815','6','Valve 5','V','5','2016-07-08 21:57:03','2016-07-08 21:58:03','1','1','1','90219251468036408','1');
INSERT INTO `rlb_custom_program_log` VALUES ('816','1','Valve 0','V','0','2016-07-08 22:07:24','2016-07-08 22:08:24','1','1','2','50284611468040844','0');
INSERT INTO `rlb_custom_program_log` VALUES ('817','3','Valve 0','V','0','2016-07-08 22:07:31','2016-07-08 22:08:31','1','1','1','32611031468040851','0');
INSERT INTO `rlb_custom_program_log` VALUES ('818','3','Valve 4','V','4','2016-07-08 22:07:32','2016-07-08 22:08:32','1','1','1','32611031468040851','0');
INSERT INTO `rlb_custom_program_log` VALUES ('819','3','Valve 4','V','4','2016-07-08 22:07:32','2016-07-08 22:08:32','1','1','1','32611031468040851','0');
INSERT INTO `rlb_custom_program_log` VALUES ('820','6','Valve 1','V','1','2016-07-08 22:07:28','2016-07-08 22:08:28','1','1','2','75274201468040848','0');
INSERT INTO `rlb_custom_program_log` VALUES ('821','6','Valve 2','V','2','2016-07-08 22:07:28','2016-07-08 22:08:28','1','1','2','75274201468040848','0');
INSERT INTO `rlb_custom_program_log` VALUES ('822','6','Valve 2','V','2','2016-07-08 22:07:28','2016-07-08 22:08:28','1','1','2','75274201468040848','0');
INSERT INTO `rlb_custom_program_log` VALUES ('823','6','Valve 5','V','5','2016-07-08 22:09:02','2016-07-08 22:10:02','1','2','1','75274201468040848','0');
INSERT INTO `rlb_custom_program_log` VALUES ('824','6','Valve 6','V','6','2016-07-08 22:09:02','2016-07-08 22:10:02','1','2','1','75274201468040848','0');
INSERT INTO `rlb_custom_program_log` VALUES ('825','1','Valve 3','V','3','2016-07-08 22:09:01','2016-07-08 22:10:01','1','2','2','50284611468040844','0');
INSERT INTO `rlb_custom_program_log` VALUES ('826','6','Valve 6','V','6','2016-07-08 22:09:02','2016-07-08 22:10:02','1','2','1','75274201468040848','0');
INSERT INTO `rlb_custom_program_log` VALUES ('827','3','Valve 0','V','0','2016-07-08 22:09:02','2016-07-08 22:10:02','1','2','2','32611031468040851','0');
INSERT INTO `rlb_custom_program_log` VALUES ('828','1','Valve 4','V','4','2016-07-08 22:10:02','2016-07-08 22:11:02','1','3','1','50284611468040844','0');
INSERT INTO `rlb_custom_program_log` VALUES ('829','3','Valve 4','V','4','2016-07-08 22:10:02','2016-07-08 22:11:02','1','3','2','32611031468040851','0');
INSERT INTO `rlb_custom_program_log` VALUES ('830','3','Valve 5','V','5','2016-07-08 22:10:02','2016-07-08 22:11:02','1','3','2','32611031468040851','0');
INSERT INTO `rlb_custom_program_log` VALUES ('831','3','Valve 5','V','5','2016-07-08 22:10:02','2016-07-08 22:11:02','1','3','2','32611031468040851','0');
INSERT INTO `rlb_custom_program_log` VALUES ('832','6','Valve 5','V','5','2016-07-08 22:10:02','2016-07-08 22:11:02','1','1','1','75274201468040848','1');
INSERT INTO `rlb_custom_program_log` VALUES ('833','1','Valve 4','V','4','2016-07-08 22:11:01','2016-07-08 22:12:01','1','1','1','50284611468040844','1');
INSERT INTO `rlb_custom_program_log` VALUES ('834','1','Valve 6','V','6','2016-07-08 22:12:02','2016-07-08 22:13:02','1','6','1','50284611468040844','1');
INSERT INTO `rlb_custom_program_log` VALUES ('835','1','Valve 0','V','0','2016-07-08 22:20:42','2016-07-08 22:21:42','1','1','2','69959521468041642','0');
INSERT INTO `rlb_custom_program_log` VALUES ('836','6','Valve 1','V','1','2016-07-08 22:20:56','2016-07-08 22:21:56','1','1','2','81947821468041656','0');
INSERT INTO `rlb_custom_program_log` VALUES ('837','6','Valve 2','V','2','2016-07-08 22:20:57','2016-07-08 22:21:57','1','1','2','81947821468041656','0');
INSERT INTO `rlb_custom_program_log` VALUES ('838','6','Valve 2','V','2','2016-07-08 22:20:57','2016-07-08 22:21:57','1','1','2','81947821468041656','0');
INSERT INTO `rlb_custom_program_log` VALUES ('839','1','Valve 3','V','3','2016-07-08 22:22:02','2016-07-08 22:23:02','1','2','2','69959521468041642','0');
INSERT INTO `rlb_custom_program_log` VALUES ('840','1','Valve 4','V','4','2016-07-08 22:23:02','2016-07-08 22:24:02','1','3','1','69959521468041642','0');
INSERT INTO `rlb_custom_program_log` VALUES ('841','6','Valve 5','V','5','2016-07-08 22:22:03','2016-07-08 22:23:03','1','2','1','81947821468041656','0');
INSERT INTO `rlb_custom_program_log` VALUES ('842','6','Valve 6','V','6','2016-07-08 22:22:03','2016-07-08 22:23:03','1','2','1','81947821468041656','0');
INSERT INTO `rlb_custom_program_log` VALUES ('843','6','Valve 6','V','6','2016-07-08 22:22:03','2016-07-08 22:23:03','1','2','1','81947821468041656','0');
INSERT INTO `rlb_custom_program_log` VALUES ('844','1','Valve 4','V','4','2016-07-08 22:24:02','2016-07-08 22:25:02','1','4','2','69959521468041642','0');
INSERT INTO `rlb_custom_program_log` VALUES ('845','1','Valve 5','V','5','2016-07-08 22:25:02','2016-07-08 22:26:02','1','5','2','69959521468041642','0');
INSERT INTO `rlb_custom_program_log` VALUES ('846','1','Valve 5','V','5','2016-07-08 22:26:02','2016-07-08 22:27:02','1','6','1','69959521468041642','0');
INSERT INTO `rlb_custom_program_log` VALUES ('847','1','Valve 6','V','6','2016-07-08 22:26:02','2016-07-08 22:27:02','1','6','1','69959521468041642','0');
INSERT INTO `rlb_custom_program_log` VALUES ('848','1','Valve 6','V','6','2016-07-08 22:26:02','2016-07-08 22:27:02','1','6','1','69959521468041642','0');
INSERT INTO `rlb_custom_program_log` VALUES ('849','1','Pump 2','PS','2','2016-07-08 22:27:02','2016-07-08 22:28:02','1','7','1','69959521468041642','0');
INSERT INTO `rlb_custom_program_log` VALUES ('850','1','Relay 15','R','15','2016-07-08 22:27:02','2016-07-08 23:22:02','1','7','1','69959521468041642','0');
INSERT INTO `rlb_custom_program_log` VALUES ('851','1','Power Center 0','P','0','2016-07-08 22:27:02','2016-07-08 23:22:02','1','7','1','69959521468041642','0');
INSERT INTO `rlb_custom_program_log` VALUES ('852','1','Valve 4','V','4','2016-07-08 23:22:02','2016-07-08 23:23:02','1','1','1','69959521468041642','1');
INSERT INTO `rlb_custom_program_log` VALUES ('853','1','Valve 6','V','6','2016-07-08 23:23:02','2016-07-08 23:24:02','1','6','1','69959521468041642','1');
INSERT INTO `rlb_custom_program_log` VALUES ('854','6','Pump 2','PS','2','2016-07-08 22:24:02','2016-07-08 23:24:02','1','3','1','81947821468041656','0');
INSERT INTO `rlb_custom_program_log` VALUES ('855','6','Valve 5','V','5','2016-07-08 23:24:02','2016-07-08 23:25:02','1','1','1','81947821468041656','1');
INSERT INTO `rlb_custom_program_log` VALUES ('856','1','Valve 0','V','0','2016-07-09 10:40:21','2016-07-09 10:41:21','1','1','2','90449231468086021','0');
INSERT INTO `rlb_custom_program_log` VALUES ('857','6','Valve 1','V','1','2016-07-09 10:40:47','2016-07-09 10:41:47','1','1','2','45607181468086047','0');
INSERT INTO `rlb_custom_program_log` VALUES ('858','6','Valve 2','V','2','2016-07-09 10:40:47','2016-07-09 10:41:47','1','1','2','45607181468086047','0');
INSERT INTO `rlb_custom_program_log` VALUES ('859','6','Valve 2','V','2','2016-07-09 10:40:47','2016-07-09 10:41:47','1','1','2','45607181468086047','0');
INSERT INTO `rlb_custom_program_log` VALUES ('860','1','Valve 3','V','3','2016-07-09 10:42:02','2016-07-09 10:43:02','1','2','2','90449231468086021','0');
INSERT INTO `rlb_custom_program_log` VALUES ('861','1','Valve 4','V','4','2016-07-09 10:43:02','2016-07-09 10:44:02','1','3','1','90449231468086021','0');
INSERT INTO `rlb_custom_program_log` VALUES ('862','6','Valve 5','V','5','2016-07-09 10:42:03','2016-07-09 10:43:03','1','2','1','45607181468086047','0');
INSERT INTO `rlb_custom_program_log` VALUES ('863','6','Valve 6','V','6','2016-07-09 10:42:03','2016-07-09 10:43:03','1','2','1','45607181468086047','0');
INSERT INTO `rlb_custom_program_log` VALUES ('864','6','Valve 6','V','6','2016-07-09 10:42:03','2016-07-09 10:43:03','1','2','1','45607181468086047','0');
INSERT INTO `rlb_custom_program_log` VALUES ('865','1','Valve 4','V','4','2016-07-09 10:44:02','2016-07-09 10:45:02','1','4','2','90449231468086021','0');
INSERT INTO `rlb_custom_program_log` VALUES ('866','1','Valve 5','V','5','2016-07-09 10:45:02','2016-07-09 10:46:02','1','5','2','90449231468086021','0');
INSERT INTO `rlb_custom_program_log` VALUES ('867','1','Valve 5','V','5','2016-07-09 10:46:02','2016-07-09 10:47:02','1','6','1','90449231468086021','0');
INSERT INTO `rlb_custom_program_log` VALUES ('868','1','Valve 6','V','6','2016-07-09 10:46:02','2016-07-09 10:47:02','1','6','1','90449231468086021','0');
INSERT INTO `rlb_custom_program_log` VALUES ('869','1','Valve 6','V','6','2016-07-09 10:46:02','2016-07-09 10:47:02','1','6','1','90449231468086021','0');
INSERT INTO `rlb_custom_program_log` VALUES ('870','1','Pump 2','PS','2','2016-07-09 10:47:02','2016-07-09 10:48:02','1','7','1','90449231468086021','0');
INSERT INTO `rlb_custom_program_log` VALUES ('871','1','Relay 15','R','15','2016-07-09 10:47:02','2016-07-09 11:42:02','1','7','1','90449231468086021','0');
INSERT INTO `rlb_custom_program_log` VALUES ('872','1','Power Center 0','P','0','2016-07-09 10:47:03','2016-07-09 11:42:03','1','7','1','90449231468086021','0');
INSERT INTO `rlb_custom_program_log` VALUES ('873','1','Valve 4','V','4','2016-07-09 11:43:02','2016-07-09 11:44:02','1','1','1','90449231468086021','1');
INSERT INTO `rlb_custom_program_log` VALUES ('874','6','Pump 2','PS','2','2016-07-09 10:44:02','2016-07-09 11:44:02','1','3','1','45607181468086047','0');
INSERT INTO `rlb_custom_program_log` VALUES ('875','1','Valve 6','V','6','2016-07-09 11:44:02','2016-07-09 11:45:02','1','6','1','90449231468086021','1');
INSERT INTO `rlb_custom_program_log` VALUES ('876','6','Valve 5','V','5','2016-07-09 11:44:02','2016-07-09 11:45:02','1','1','1','45607181468086047','1');
INSERT INTO `rlb_custom_program_log` VALUES ('877','1','Valve 0','V','0','2016-07-09 15:30:20','2016-07-09 15:31:20','1','1','2','61927491468103420','0');
INSERT INTO `rlb_custom_program_log` VALUES ('878','6','Valve 1','V','1','2016-07-09 15:30:24','2016-07-09 15:31:24','1','1','2','84462931468103423','0');
INSERT INTO `rlb_custom_program_log` VALUES ('879','6','Valve 2','V','2','2016-07-09 15:30:24','2016-07-09 15:31:24','1','1','2','84462931468103423','0');
INSERT INTO `rlb_custom_program_log` VALUES ('880','6','Valve 2','V','2','2016-07-09 15:30:24','2016-07-09 15:31:24','1','1','2','84462931468103423','0');
INSERT INTO `rlb_custom_program_log` VALUES ('881','1','Valve 3','V','3','2016-07-09 15:32:03','2016-07-09 15:33:03','1','2','2','61927491468103420','0');
INSERT INTO `rlb_custom_program_log` VALUES ('882','6','Valve 5','V','5','2016-07-09 15:32:04','2016-07-09 15:33:04','1','2','1','84462931468103423','0');
INSERT INTO `rlb_custom_program_log` VALUES ('883','6','Valve 6','V','6','2016-07-09 15:32:04','2016-07-09 15:33:04','1','2','1','84462931468103423','0');
INSERT INTO `rlb_custom_program_log` VALUES ('884','6','Valve 6','V','6','2016-07-09 15:32:04','2016-07-09 15:33:04','1','2','1','84462931468103423','0');
INSERT INTO `rlb_custom_program_log` VALUES ('885','1','Valve 4','V','4','2016-07-09 15:33:03','2016-07-09 15:34:03','1','3','1','61927491468103420','0');
INSERT INTO `rlb_custom_program_log` VALUES ('886','1','Valve 4','V','4','2016-07-09 15:35:02','2016-07-09 15:36:02','1','4','2','61927491468103420','0');
INSERT INTO `rlb_custom_program_log` VALUES ('887','1','Valve 5','V','5','2016-07-09 15:36:03','2016-07-09 15:37:03','1','5','2','61927491468103420','0');
INSERT INTO `rlb_custom_program_log` VALUES ('888','3','Valve 0','V','0','2016-07-09 15:36:37','2016-07-09 15:37:37','1','1','1','48887791468103795','0');
INSERT INTO `rlb_custom_program_log` VALUES ('889','3','Valve 4','V','4','2016-07-09 15:36:37','2016-07-09 15:37:37','1','1','1','48887791468103795','0');
INSERT INTO `rlb_custom_program_log` VALUES ('890','3','Valve 4','V','4','2016-07-09 15:36:37','2016-07-09 15:37:37','1','1','1','48887791468103795','0');
INSERT INTO `rlb_custom_program_log` VALUES ('891','1','Valve 5','V','5','2016-07-09 15:38:05','2016-07-09 15:39:05','1','6','1','61927491468103420','0');
INSERT INTO `rlb_custom_program_log` VALUES ('892','1','Valve 6','V','6','2016-07-09 15:38:05','2016-07-09 15:39:05','1','6','1','61927491468103420','0');
INSERT INTO `rlb_custom_program_log` VALUES ('893','1','Valve 6','V','6','2016-07-09 15:38:05','2016-07-09 15:39:05','1','6','1','61927491468103420','0');
INSERT INTO `rlb_custom_program_log` VALUES ('894','3','Valve 0','V','0','2016-07-09 15:38:11','2016-07-09 15:39:11','1','2','2','48887791468103795','0');
INSERT INTO `rlb_custom_program_log` VALUES ('895','1','Pump 2','PS','2','2016-07-09 15:40:08','2016-07-09 15:41:08','1','7','1','61927491468103420','0');
INSERT INTO `rlb_custom_program_log` VALUES ('896','3','Valve 4','V','4','2016-07-09 15:40:14','2016-07-09 15:41:14','1','3','2','48887791468103795','0');
INSERT INTO `rlb_custom_program_log` VALUES ('897','3','Valve 5','V','5','2016-07-09 15:40:15','2016-07-09 15:41:15','1','3','2','48887791468103795','0');
INSERT INTO `rlb_custom_program_log` VALUES ('898','3','Valve 5','V','5','2016-07-09 15:40:15','2016-07-09 15:41:15','1','3','2','48887791468103795','0');
INSERT INTO `rlb_custom_program_log` VALUES ('899','3','Pump 1','PS','1','2016-07-09 15:42:11','2016-07-09 15:52:11','1','4','1','48887791468103795','0');
INSERT INTO `rlb_custom_program_log` VALUES ('900','6','Pump 2','PS','2','2016-07-09 15:33:04','2016-07-09 16:33:04','1','3','1','84462931468103423','0');
INSERT INTO `rlb_custom_program_log` VALUES ('901','6','Valve 5','V','5','2016-07-09 16:34:02','2016-07-09 16:35:02','1','1','1','84462931468103423','1');
INSERT INTO `rlb_custom_program_log` VALUES ('902','1','Relay 15','R','15','2016-07-09 15:40:09','2016-07-09 16:35:09','1','7','1','61927491468103420','0');
INSERT INTO `rlb_custom_program_log` VALUES ('903','1','Power Center 0','P','0','2016-07-09 15:40:10','2016-07-09 16:35:10','1','7','1','61927491468103420','0');
INSERT INTO `rlb_custom_program_log` VALUES ('904','1','Valve 4','V','4','2016-07-09 16:36:02','2016-07-09 16:37:02','1','1','1','61927491468103420','1');
INSERT INTO `rlb_custom_program_log` VALUES ('905','1','Valve 6','V','6','2016-07-09 16:37:03','2016-07-09 16:38:03','1','6','1','61927491468103420','1');
INSERT INTO `rlb_custom_program_log` VALUES ('906','1','Valve 0','V','0','2016-07-09 16:37:31','2016-07-09 16:38:31','1','1','2','47807641468107450','0');
INSERT INTO `rlb_custom_program_log` VALUES ('907','6','Valve 1','V','1','2016-07-09 16:37:42','2016-07-09 16:38:42','1','1','2','65568671468107461','0');
INSERT INTO `rlb_custom_program_log` VALUES ('908','6','Valve 2','V','2','2016-07-09 16:37:42','2016-07-09 16:38:42','1','1','2','65568671468107461','0');
INSERT INTO `rlb_custom_program_log` VALUES ('909','6','Valve 2','V','2','2016-07-09 16:37:42','2016-07-09 16:38:42','1','1','2','65568671468107461','0');
INSERT INTO `rlb_custom_program_log` VALUES ('910','1','Valve 3','V','3','2016-07-09 16:39:02','2016-07-09 16:40:02','1','2','2','47807641468107450','0');
INSERT INTO `rlb_custom_program_log` VALUES ('911','1','Valve 4','V','4','2016-07-09 16:40:02','2016-07-09 16:41:02','1','3','1','47807641468107450','0');
INSERT INTO `rlb_custom_program_log` VALUES ('912','6','Valve 5','V','5','2016-07-09 16:39:03','2016-07-09 16:40:03','1','2','1','65568671468107461','0');
INSERT INTO `rlb_custom_program_log` VALUES ('913','6','Valve 6','V','6','2016-07-09 16:39:03','2016-07-09 16:40:03','1','2','1','65568671468107461','0');
INSERT INTO `rlb_custom_program_log` VALUES ('914','6','Valve 6','V','6','2016-07-09 16:39:03','2016-07-09 16:40:03','1','2','1','65568671468107461','0');
INSERT INTO `rlb_custom_program_log` VALUES ('915','1','Valve 0','V','0','2016-07-09 16:40:40','2016-07-09 16:41:40','1','1','2','59998711468107639','0');
INSERT INTO `rlb_custom_program_log` VALUES ('916','3','Valve 0','V','0','2016-07-09 16:40:35','2016-07-09 16:41:35','1','1','1','95696161468107635','0');
INSERT INTO `rlb_custom_program_log` VALUES ('917','3','Valve 4','V','4','2016-07-09 16:40:36','2016-07-09 16:41:36','1','1','1','95696161468107635','0');
INSERT INTO `rlb_custom_program_log` VALUES ('918','3','Valve 4','V','4','2016-07-09 16:40:36','2016-07-09 16:41:36','1','1','1','95696161468107635','0');
INSERT INTO `rlb_custom_program_log` VALUES ('919','6','Valve 1','V','1','2016-07-09 16:40:48','2016-07-09 16:41:48','1','1','2','16789001468107647','0');
INSERT INTO `rlb_custom_program_log` VALUES ('920','6','Valve 2','V','2','2016-07-09 16:40:48','2016-07-09 16:41:48','1','1','2','16789001468107647','0');
INSERT INTO `rlb_custom_program_log` VALUES ('921','6','Valve 2','V','2','2016-07-09 16:40:48','2016-07-09 16:41:48','1','1','2','16789001468107647','0');
INSERT INTO `rlb_custom_program_log` VALUES ('922','1','Valve 3','V','3','2016-07-09 16:42:02','2016-07-09 16:43:02','1','2','2','59998711468107639','0');
INSERT INTO `rlb_custom_program_log` VALUES ('923','3','Valve 0','V','0','2016-07-09 16:42:02','2016-07-09 16:43:02','1','2','2','95696161468107635','0');
INSERT INTO `rlb_custom_program_log` VALUES ('924','6','Valve 5','V','5','2016-07-09 16:42:03','2016-07-09 16:43:03','1','2','1','16789001468107647','0');
INSERT INTO `rlb_custom_program_log` VALUES ('925','6','Valve 6','V','6','2016-07-09 16:42:03','2016-07-09 16:43:03','1','2','1','16789001468107647','0');
INSERT INTO `rlb_custom_program_log` VALUES ('926','6','Valve 6','V','6','2016-07-09 16:42:03','2016-07-09 16:43:03','1','2','1','16789001468107647','0');
INSERT INTO `rlb_custom_program_log` VALUES ('927','1','Valve 4','V','4','2016-07-09 16:43:02','2016-07-09 16:44:02','1','3','1','59998711468107639','0');
INSERT INTO `rlb_custom_program_log` VALUES ('928','3','Valve 4','V','4','2016-07-09 16:43:02','2016-07-09 16:44:02','1','3','2','95696161468107635','0');
INSERT INTO `rlb_custom_program_log` VALUES ('929','3','Valve 5','V','5','2016-07-09 16:43:02','2016-07-09 16:44:02','1','3','2','95696161468107635','0');
INSERT INTO `rlb_custom_program_log` VALUES ('930','3','Valve 5','V','5','2016-07-09 16:43:02','2016-07-09 16:44:02','1','3','2','95696161468107635','0');
INSERT INTO `rlb_custom_program_log` VALUES ('931','1','Valve 4','V','4','2016-07-09 16:44:02','2016-07-09 16:45:02','1','4','2','59998711468107639','0');
INSERT INTO `rlb_custom_program_log` VALUES ('932','1','Valve 5','V','5','2016-07-09 16:45:03','2016-07-09 16:46:03','1','5','2','59998711468107639','0');
INSERT INTO `rlb_custom_program_log` VALUES ('933','1','Valve 5','V','5','2016-07-09 16:47:03','2016-07-09 16:48:03','1','6','1','59998711468107639','0');
INSERT INTO `rlb_custom_program_log` VALUES ('934','1','Valve 6','V','6','2016-07-09 16:47:03','2016-07-09 16:48:03','1','6','1','59998711468107639','0');
INSERT INTO `rlb_custom_program_log` VALUES ('935','1','Valve 6','V','6','2016-07-09 16:47:03','2016-07-09 16:48:03','1','6','1','59998711468107639','0');
INSERT INTO `rlb_custom_program_log` VALUES ('936','1','Pump 2','PS','2','2016-07-09 16:49:03','2016-07-09 16:50:03','1','7','1','59998711468107639','0');
INSERT INTO `rlb_custom_program_log` VALUES ('937','3','Pump 1','PS','1','2016-07-09 16:44:03','2016-07-09 16:54:03','1','4','1','95696161468107635','0');
INSERT INTO `rlb_custom_program_log` VALUES ('938','6','Pump 2','PS','2','2016-07-09 16:43:03','2016-07-09 17:43:03','1','3','1','16789001468107647','0');
INSERT INTO `rlb_custom_program_log` VALUES ('939','1','Relay 15','R','15','2016-07-09 16:49:03','2016-07-09 17:44:03','1','7','1','59998711468107639','0');
INSERT INTO `rlb_custom_program_log` VALUES ('940','1','Power Center 0','P','0','2016-07-09 16:49:03','2016-07-09 17:44:03','1','7','1','59998711468107639','0');
INSERT INTO `rlb_custom_program_log` VALUES ('941','6','Valve 5','V','5','2016-07-09 17:44:03','2016-07-09 17:45:03','1','1','1','16789001468107647','1');
INSERT INTO `rlb_custom_program_log` VALUES ('942','1','Valve 4','V','4','2016-07-09 17:45:03','2016-07-09 17:46:03','1','1','1','59998711468107639','1');
INSERT INTO `rlb_custom_program_log` VALUES ('943','1','Valve 6','V','6','2016-07-09 17:47:02','2016-07-09 17:48:02','1','6','1','59998711468107639','1');
INSERT INTO `rlb_custom_program_log` VALUES ('944','1','Valve 0','V','0','2016-07-09 18:08:23','2016-07-09 18:09:23','1','1','2','44166711468112902','0');
INSERT INTO `rlb_custom_program_log` VALUES ('945','6','Valve 1','V','1','2016-07-09 18:08:53','2016-07-09 18:09:53','1','1','2','32014871468112931','0');
INSERT INTO `rlb_custom_program_log` VALUES ('946','6','Valve 2','V','2','2016-07-09 18:08:54','2016-07-09 18:09:54','1','1','2','32014871468112931','0');
INSERT INTO `rlb_custom_program_log` VALUES ('947','6','Valve 2','V','2','2016-07-09 18:08:54','2016-07-09 18:09:54','1','1','2','32014871468112931','0');
INSERT INTO `rlb_custom_program_log` VALUES ('948','1','Valve 3','V','3','2016-07-09 18:10:02','2016-07-09 18:11:02','1','2','2','44166711468112902','0');
INSERT INTO `rlb_custom_program_log` VALUES ('949','1','Valve 4','V','4','2016-07-09 18:11:02','2016-07-09 18:12:02','1','3','1','44166711468112902','0');
INSERT INTO `rlb_custom_program_log` VALUES ('950','6','Valve 5','V','5','2016-07-09 18:10:03','2016-07-09 18:11:03','1','2','1','32014871468112931','0');
INSERT INTO `rlb_custom_program_log` VALUES ('951','6','Valve 6','V','6','2016-07-09 18:10:03','2016-07-09 18:11:03','1','2','1','32014871468112931','0');
INSERT INTO `rlb_custom_program_log` VALUES ('952','6','Valve 6','V','6','2016-07-09 18:10:03','2016-07-09 18:11:03','1','2','1','32014871468112931','0');
INSERT INTO `rlb_custom_program_log` VALUES ('953','1','Valve 4','V','4','2016-07-09 18:12:04','2016-07-09 18:13:04','1','4','2','44166711468112902','0');
INSERT INTO `rlb_custom_program_log` VALUES ('954','1','Valve 5','V','5','2016-07-09 18:14:02','2016-07-09 18:15:02','1','5','2','44166711468112902','0');
INSERT INTO `rlb_custom_program_log` VALUES ('955','1','Valve 5','V','5','2016-07-09 18:15:04','2016-07-09 18:16:04','1','6','1','44166711468112902','0');
INSERT INTO `rlb_custom_program_log` VALUES ('956','1','Valve 6','V','6','2016-07-09 18:15:04','2016-07-09 18:16:04','1','6','1','44166711468112902','0');
INSERT INTO `rlb_custom_program_log` VALUES ('957','1','Valve 6','V','6','2016-07-09 18:15:04','2016-07-09 18:16:04','1','6','1','44166711468112902','0');
INSERT INTO `rlb_custom_program_log` VALUES ('958','1','Pump 2','PS','2','2016-07-09 18:17:03','2016-07-09 18:18:03','1','7','1','44166711468112902','0');
INSERT INTO `rlb_custom_program_log` VALUES ('959','1','Relay 15','R','15','2016-07-09 18:17:03','2016-07-09 19:12:03','1','7','1','44166711468112902','0');
INSERT INTO `rlb_custom_program_log` VALUES ('960','1','Power Center 0','P','0','2016-07-09 18:17:03','2016-07-09 19:12:03','1','7','1','44166711468112902','0');
INSERT INTO `rlb_custom_program_log` VALUES ('961','6','Pump 2','PS','2','2016-07-09 18:12:04','2016-07-09 19:12:04','1','3','1','32014871468112931','0');
INSERT INTO `rlb_custom_program_log` VALUES ('962','1','Valve 4','V','4','2016-07-09 19:13:02','2016-07-09 19:14:02','1','1','1','44166711468112902','1');
INSERT INTO `rlb_custom_program_log` VALUES ('963','1','Valve 6','V','6','2016-07-09 19:14:02','2016-07-09 19:15:02','1','6','1','44166711468112902','1');
INSERT INTO `rlb_custom_program_log` VALUES ('964','6','Valve 5','V','5','2016-07-09 19:13:03','2016-07-09 19:14:03','1','1','1','32014871468112931','1');
INSERT INTO `rlb_custom_program_log` VALUES ('965','1','Valve 0','V','0','2016-07-11 22:21:03','2016-07-11 22:22:03','1','1','2','41510791468300861','0');
INSERT INTO `rlb_custom_program_log` VALUES ('966','1','Valve 0','V','0','2016-07-11 22:21:03','2016-07-11 22:22:03','1','1','2','41510791468300861','0');
INSERT INTO `rlb_custom_program_log` VALUES ('967','1','Valve 3','V','3','2016-07-11 22:23:02','2016-07-11 22:24:02','1','2','2','41510791468300861','0');
INSERT INTO `rlb_custom_program_log` VALUES ('968','1','Valve 4','V','4','2016-07-11 22:23:02','2016-07-11 22:24:02','1','1','1','41510791468300861','1');
INSERT INTO `rlb_custom_program_log` VALUES ('969','1','Valve 6','V','6','2016-07-11 22:24:02','2016-07-11 22:25:02','1','6','1','41510791468300861','1');
INSERT INTO `rlb_custom_program_log` VALUES ('970','1','Valve 0','V','0','2016-07-11 22:28:05','2016-07-11 22:29:05','1','1','2','91974141468301285','0');
INSERT INTO `rlb_custom_program_log` VALUES ('971','1','Valve 3','V','3','2016-07-11 22:30:02','2016-07-11 22:31:02','1','2','2','91974141468301285','0');
INSERT INTO `rlb_custom_program_log` VALUES ('972','1','Valve 4','V','4','2016-07-11 22:31:02','2016-07-11 22:32:02','1','3','1','91974141468301285','0');
INSERT INTO `rlb_custom_program_log` VALUES ('973','1','Valve 4','V','4','2016-07-11 22:32:02','2016-07-11 22:33:02','1','4','2','91974141468301285','0');
INSERT INTO `rlb_custom_program_log` VALUES ('974','1','Valve 5','V','5','2016-07-11 22:33:02','2016-07-11 22:34:02','1','5','2','91974141468301285','0');
INSERT INTO `rlb_custom_program_log` VALUES ('975','1','Valve 5','V','5','2016-07-11 22:34:02','2016-07-11 22:35:02','1','6','1','91974141468301285','0');
INSERT INTO `rlb_custom_program_log` VALUES ('976','1','Valve 6','V','6','2016-07-11 22:34:03','2016-07-11 22:35:03','1','6','1','91974141468301285','0');
INSERT INTO `rlb_custom_program_log` VALUES ('977','1','Valve 6','V','6','2016-07-11 22:34:03','2016-07-11 22:35:03','1','6','1','91974141468301285','0');
INSERT INTO `rlb_custom_program_log` VALUES ('978','1','Pump 2','PS','2','2016-07-11 22:36:03','2016-07-11 23:31:03','1','7','1','91974141468301285','0');
INSERT INTO `rlb_custom_program_log` VALUES ('979','1','Relay 15','R','15','2016-07-11 22:36:03','2016-07-11 23:31:03','1','7','1','91974141468301285','0');
INSERT INTO `rlb_custom_program_log` VALUES ('980','1','Power Center 0','P','0','2016-07-11 22:36:03','2016-07-11 23:31:03','1','7','1','91974141468301285','0');
INSERT INTO `rlb_custom_program_log` VALUES ('981','1','Valve 4','V','4','2016-07-11 23:32:03','2016-07-11 23:33:03','1','1','1','91974141468301285','1');
INSERT INTO `rlb_custom_program_log` VALUES ('982','1','Valve 6','V','6','2016-07-11 23:34:02','2016-07-11 23:35:02','1','6','1','91974141468301285','1');

/*---------------------------------------------------------------
  TABLE: `rlb_device`
  ---------------------------------------------------------------*/
DROP TABLE IF EXISTS `rlb_device`;
CREATE TABLE `rlb_device` (
  `device_id` int(10) NOT NULL AUTO_INCREMENT,
  `device_number` int(10) NOT NULL,
  `device_name` varchar(150) NOT NULL,
  `device_type` varchar(100) NOT NULL,
  `device_power_type` varchar(10) DEFAULT NULL COMMENT '0=24VAC,1=12VDC',
  `device_position` text,
  `device_total_time` varchar(100) NOT NULL,
  `device_start_time` varchar(100) NOT NULL,
  `device_end_time` varchar(100) NOT NULL,
  `last_updated_date` datetime NOT NULL,
  `is_pool_or_spa` enum('0','1','2') NOT NULL DEFAULT '0' COMMENT '0=Other,1=Spa,2=Pool',
  `valve_relay_number` varchar(150) NOT NULL,
  `light_relay_number` text NOT NULL,
  `ip_id` int(5) NOT NULL,
  `show_dashboard` enum('0','1') NOT NULL DEFAULT '0',
  `valvePump` text NOT NULL,
  `temperature_offset` float(10,2) NOT NULL,
  PRIMARY KEY (`device_id`)
) ENGINE=InnoDB AUTO_INCREMENT=165 DEFAULT CHARSET=latin1;
INSERT INTO `rlb_device` VALUES   ('1','0','Spa Heater','P',NULL,NULL,'','','','2016-06-22 15:33:30','2','','','1','0','','0.00');
INSERT INTO `rlb_device` VALUES ('2','0','RelayName0','R',NULL,NULL,'20','','','2015-10-05 11:20:33','0','','','1','0','','0.00');
INSERT INTO `rlb_device` VALUES ('3','1','Pool Heater','P',NULL,NULL,'','','','2016-06-22 15:33:55','2','','','1','0','','0.00');
INSERT INTO `rlb_device` VALUES ('4','1','Test Relay 2','R',NULL,NULL,'','','','2015-09-19 13:25:31','1','','','1','0','','0.00');
INSERT INTO `rlb_device` VALUES ('8','2','','R',NULL,NULL,'30','','','2015-10-07 13:30:36','1','','','1','0','','0.00');
INSERT INTO `rlb_device` VALUES ('9','10','','R',NULL,NULL,'','08:13:57','08:23:57','2015-08-21 14:20:01','0','','','1','0','','0.00');
INSERT INTO `rlb_device` VALUES ('10','0','Board Temperature','T',NULL,NULL,'','','','2015-11-06 11:10:14','0','','0000000000000000','1','0','','0.00');
INSERT INTO `rlb_device` VALUES ('11','12','','R','0',NULL,'','','','2015-08-12 10:22:14','0','','','1','0','','0.00');
INSERT INTO `rlb_device` VALUES ('12','2','','P','1',NULL,'','','','2015-09-23 10:30:03','0','','','1','0','','0.00');
INSERT INTO `rlb_device` VALUES ('15','6','Spa 2 Blower','R',NULL,NULL,'20','','','2016-06-22 10:17:01','1','','','1','0','','0.00');
INSERT INTO `rlb_device` VALUES ('31','3','','P',NULL,NULL,'','','','2015-09-21 08:41:48','2','','','1','0','','0.00');
INSERT INTO `rlb_device` VALUES ('34','1','Temprature2','T',NULL,NULL,'','','','2016-01-05 11:53:52','0','','','1','1','','3.50');
INSERT INTO `rlb_device` VALUES ('35','3','','R',NULL,NULL,'','','','2015-09-23 07:12:35','1','','','1','0','','0.00');
INSERT INTO `rlb_device` VALUES ('36','2','Test','T',NULL,NULL,'','','','2016-06-22 15:40:26','0','','28FF2070501400B4','1','1','','0.00');
INSERT INTO `rlb_device` VALUES ('40','0','Garage Light','L',NULL,NULL,'','','','2016-07-01 04:50:39','1','','a:6:{s:10:\"sRelayType\";s:2:\"12\";s:12:\"sRelayNumber\";s:1:\"7\";s:11:\"Temeprature\";N;s:4:\"Pump\";N;s:7:\"maxTemp\";N;s:10:\"desireTemp\";N;}','1','0','','0.00');
INSERT INTO `rlb_device` VALUES ('44','0','Pool Heater','H',NULL,NULL,'','','','2016-07-14 03:20:06','1','','a:7:{s:10:\"sRelayType\";s:2:\"12\";s:12:\"sRelayNumber\";s:1:\"1\";s:11:\"Temeprature\";s:1:\"2\";s:4:\"Pump\";s:1:\"1\";s:7:\"maxTemp\";s:3:\"100\";s:10:\"desireTemp\";s:2:\"90\";s:6:\"maxRun\";s:2:\"50\";}','1','0','','0.00');
INSERT INTO `rlb_device` VALUES ('93','1','Spa Heater','H',NULL,NULL,'','','','2016-07-14 03:21:06','0','','a:7:{s:10:\"sRelayType\";s:2:\"12\";s:12:\"sRelayNumber\";s:1:\"0\";s:11:\"Temeprature\";s:1:\"1\";s:4:\"Pump\";s:1:\"1\";s:7:\"maxTemp\";s:3:\"100\";s:10:\"desireTemp\";s:2:\"83\";s:6:\"maxRun\";s:2:\"60\";}','1','0','','0.00');
INSERT INTO `rlb_device` VALUES ('98','0','','B',NULL,NULL,'','','','2016-01-21 14:07:25','1','','a:2:{s:10:\"sRelayType\";s:2:\"12\";s:12:\"sRelayNumber\";s:1:\"1\";}','1','0','','0.00');
INSERT INTO `rlb_device` VALUES ('100','0','misc1','M',NULL,NULL,'','','','2016-06-24 00:21:35','1','','a:2:{s:10:\"sRelayType\";s:2:\"24\";s:12:\"sRelayNumber\";s:2:\"14\";}','1','0','','0.00');
INSERT INTO `rlb_device` VALUES ('101','1','misc2','M',NULL,NULL,'','','','2016-06-24 00:21:14','2','','a:2:{s:10:\"sRelayType\";s:2:\"24\";s:12:\"sRelayNumber\";s:1:\"7\";}','1','0','','0.00');
INSERT INTO `rlb_device` VALUES ('118','4','','R',NULL,NULL,'','','','0000-00-00 00:00:00','0','','','1','0','','0.00');
INSERT INTO `rlb_device` VALUES ('119','7','Auto fill Indoor Pool','R',NULL,NULL,'','','','2016-06-22 10:15:05','1','','','1','0','','0.00');
INSERT INTO `rlb_device` VALUES ('120','0','RelayName1Device2','R',NULL,NULL,'20','','','2016-01-25 11:39:39','2','','','2','0','','0.00');
INSERT INTO `rlb_device` VALUES ('122','0','Testing','P',NULL,NULL,'','','','2016-01-14 11:20:41','1','','','2','0','','0.00');
INSERT INTO `rlb_device` VALUES ('123','1','','P',NULL,NULL,'','','','2016-01-14 11:08:56','2','','','2','0','','0.00');
INSERT INTO `rlb_device` VALUES ('124','0','Board Temperature','T',NULL,NULL,'','','','2016-01-14 12:46:39','0','','','2','0','','0.00');
INSERT INTO `rlb_device` VALUES ('129','0','#13 Solar On Off','V',NULL,'a:2:{s:9:\"position1\";s:2:\"20\";s:9:\"position2\";s:2:\"19\";}','','','','2016-06-22 10:12:31','2','a:2:{s:6:\"Relay1\";s:1:\"0\";s:6:\"Relay2\";s:1:\"1\";}','','1','0','{\"pump\":\"1\",\"valve_type\":\"1\"}','0.00');
INSERT INTO `rlb_device` VALUES ('131','0','','B',NULL,NULL,'','','','2016-06-24 00:19:52','2','','a:2:{s:10:\"sRelayType\";s:2:\"24\";s:12:\"sRelayNumber\";s:2:\"13\";}','2','0','','0.00');
INSERT INTO `rlb_device` VALUES ('134','1','','L',NULL,NULL,'','','','2016-06-24 00:20:44','2','','a:2:{s:10:\"sRelayType\";s:2:\"24\";s:12:\"sRelayNumber\";s:2:\"15\";}','2','0','','0.00');
INSERT INTO `rlb_device` VALUES ('135','0','','L',NULL,NULL,'','','','2016-02-02 12:35:50','1','','a:2:{s:10:\"sRelayType\";s:2:\"12\";s:12:\"sRelayNumber\";s:1:\"0\";}','2','0','','0.00');
INSERT INTO `rlb_device` VALUES ('142','14','F Pool Pump','R',NULL,NULL,'35','','','2016-06-22 10:14:10','0','','','1','0','','0.00');
INSERT INTO `rlb_device` VALUES ('143','0','#9 Pump 1 Return Spa or Pool','V',NULL,'a:2:{s:9:\"position1\";s:1:\"2\";s:9:\"position2\";s:1:\"3\";}','','','','2016-06-22 09:31:50','0','a:2:{s:6:\"Relay1\";s:1:\"0\";s:6:\"Relay2\";s:1:\"1\";}','','2','0','{\"pump\":\"2\",\"valve_type\":\"0\"}','0.00');
INSERT INTO `rlb_device` VALUES ('144','1','','H',NULL,NULL,'','','','2016-02-02 11:37:40','0','','a:2:{s:10:\"sRelayType\";s:2:\"12\";s:12:\"sRelayNumber\";s:1:\"1\";}','2','0','','0.00');
INSERT INTO `rlb_device` VALUES ('145','0','Testing','M',NULL,NULL,'','','','2016-06-24 00:21:36','0','','a:2:{s:10:\"sRelayType\";s:2:\"24\";s:12:\"sRelayNumber\";s:2:\"14\";}','2','0','','0.00');
INSERT INTO `rlb_device` VALUES ('146','1','Pump 1','PS',NULL,NULL,'','','','2016-06-29 12:00:58','1','','','1','0','','0.00');
INSERT INTO `rlb_device` VALUES ('147','2','Jet Pump','PS',NULL,NULL,'','','','2016-07-01 17:21:01','0','','','1','0','','0.00');
INSERT INTO `rlb_device` VALUES ('148','1','#1 return f Pool waterfall or Jet stream','V',NULL,'a:2:{s:9:\"position1\";s:2:\"17\";s:9:\"position2\";s:2:\"18\";}','','','','2016-06-22 10:09:16','0','a:2:{s:6:\"Relay1\";s:1:\"2\";s:6:\"Relay2\";s:1:\"3\";}','','1','0','{\"pump\":\"3\",\"valve_type\":\"1\"}','0.00');
INSERT INTO `rlb_device` VALUES ('149','2','#2 Return F Pool or F Waterfall','V',NULL,'a:2:{s:9:\"position1\";s:2:\"17\";s:9:\"position2\";s:2:\"16\";}','','','','2016-06-22 10:00:22','0','a:2:{s:6:\"Relay1\";s:1:\"4\";s:6:\"Relay2\";s:1:\"5\";}','','1','0','{\"pump\":\"3\",\"valve_type\":\"1\"}','0.00');
INSERT INTO `rlb_device` VALUES ('150','4','#7 Pump 1 suction Spa or Pool','V',NULL,'a:2:{s:9:\"position1\";s:1:\"2\";s:9:\"position2\";s:1:\"3\";}','','','','2016-06-22 10:01:51','0','a:2:{s:6:\"Relay1\";s:1:\"8\";s:6:\"Relay2\";s:1:\"9\";}','','1','0','{\"pump\":\"1\",\"valve_type\":\"0\"}','0.00');
INSERT INTO `rlb_device` VALUES ('151','5','#5 Jet Pump Return  Spa 1 or Spa 2','V',NULL,'a:2:{s:9:\"position1\";s:2:\"10\";s:9:\"position2\";s:2:\"11\";}','','','','2016-06-22 10:03:50','0','a:2:{s:6:\"Relay1\";s:2:\"10\";s:6:\"Relay2\";s:2:\"11\";}','','1','0','{\"pump\":\"2\",\"valve_type\":\"1\"}','0.00');
INSERT INTO `rlb_device` VALUES ('152','6','#6 Jet Pump Suction Spa1 or Spa 2','V',NULL,'a:2:{s:9:\"position1\";s:2:\"11\";s:9:\"position2\";s:2:\"10\";}','','','','2016-06-22 10:05:20','0','a:2:{s:6:\"Relay1\";s:2:\"12\";s:6:\"Relay2\";s:2:\"13\";}','','1','0','{\"pump\":\"2\",\"valve_type\":\"0\"}','0.00');
INSERT INTO `rlb_device` VALUES ('153','1','#3 Waterfall on or off','V',NULL,'a:2:{s:9:\"position1\";s:2:\"14\";s:9:\"position2\";s:2:\"15\";}','','','','2016-06-22 09:49:02','0','a:2:{s:6:\"Relay1\";s:1:\"2\";s:6:\"Relay2\";s:1:\"3\";}','','2','0','{\"pump\":\"1\",\"valve_type\":\"1\"}','0.00');
INSERT INTO `rlb_device` VALUES ('154','2','#4 Spa 2 Jets on and off','V',NULL,'a:2:{s:9:\"position1\";s:2:\"12\";s:9:\"position2\";s:2:\"13\";}','','','','2016-06-22 09:46:27','0','a:2:{s:6:\"Relay1\";s:1:\"4\";s:6:\"Relay2\";s:1:\"5\";}','','2','0','','0.00');
INSERT INTO `rlb_device` VALUES ('155','3','#8 Suction spa 1 or spa 2','V',NULL,'a:2:{s:9:\"position1\";s:2:\"11\";s:9:\"position2\";s:2:\"10\";}','','','','2016-06-22 09:42:54','0','a:2:{s:6:\"Relay1\";s:1:\"6\";s:6:\"Relay2\";s:1:\"7\";}','','2','0','{\"pump\":\"1\",\"valve_type\":\"0\"}','0.00');
INSERT INTO `rlb_device` VALUES ('156','4','#10 Spa 1 Return On or Off','V',NULL,'a:2:{s:9:\"position1\";s:1:\"6\";s:9:\"position2\";s:1:\"7\";}','','','','2016-06-22 09:35:18','0','a:2:{s:6:\"Relay1\";s:1:\"8\";s:6:\"Relay2\";s:1:\"9\";}','','2','0','','0.00');
INSERT INTO `rlb_device` VALUES ('157','5','#11 Spa 2 Return','V',NULL,'a:2:{s:9:\"position1\";s:1:\"8\";s:9:\"position2\";s:1:\"9\";}','','','','2016-06-22 09:37:26','0','a:2:{s:6:\"Relay1\";s:2:\"10\";s:6:\"Relay2\";s:2:\"11\";}','','2','0','','0.00');
INSERT INTO `rlb_device` VALUES ('158','15','Spa 1 Blower','R',NULL,NULL,'','','','2016-06-22 10:16:14','0','','','1','0','','0.00');
INSERT INTO `rlb_device` VALUES ('159','14','Auto fill f pool','R',NULL,NULL,'','','','2016-06-22 10:18:16','0','','','2','0','','0.00');
INSERT INTO `rlb_device` VALUES ('160','15','Auto fill Spa 2','R',NULL,NULL,'','','','2016-06-22 10:18:46','0','','','2','0','','0.00');
INSERT INTO `rlb_device` VALUES ('161','3','Fiberglass Pool Pump','PS',NULL,NULL,'','','','2016-06-27 11:06:00','0','','','1','0','','0.00');
INSERT INTO `rlb_device` VALUES ('162','3','Spa 1','T',NULL,NULL,'','','','2016-06-29 12:03:43','0','','','1','1','','0.00');
INSERT INTO `rlb_device` VALUES ('163','4','','T',NULL,NULL,'','','','0000-00-00 00:00:00','0','','','1','1','','0.00');
INSERT INTO `rlb_device` VALUES ('164','5','','T',NULL,NULL,'','','','0000-00-00 00:00:00','0','','','1','1','','0.00');

/*---------------------------------------------------------------
  TABLE: `rlb_device_last_run_details`
  ---------------------------------------------------------------*/
DROP TABLE IF EXISTS `rlb_device_last_run_details`;
CREATE TABLE `rlb_device_last_run_details` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `device_number` int(5) NOT NULL,
  `device_type` varchar(100) NOT NULL,
  `device_position` varchar(100) NOT NULL,
  `ip_id` int(5) NOT NULL,
  `added_date` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=latin1;
INSERT INTO `rlb_device_last_run_details` VALUES   ('1','2','V','1','1','2016-07-08 09:23:31');
INSERT INTO `rlb_device_last_run_details` VALUES ('2','0','V','1','2','2016-07-14 14:55:52');
INSERT INTO `rlb_device_last_run_details` VALUES ('3','5','V','1','2','2016-07-14 14:56:08');
INSERT INTO `rlb_device_last_run_details` VALUES ('4','1','V','1','1','2016-07-08 09:22:57');
INSERT INTO `rlb_device_last_run_details` VALUES ('5','6','V','1','1','2016-07-06 13:35:35');
INSERT INTO `rlb_device_last_run_details` VALUES ('6','0','V','1','1','2016-06-30 02:00:09');
INSERT INTO `rlb_device_last_run_details` VALUES ('8','4','V','2','1','2016-07-14 14:55:12');
INSERT INTO `rlb_device_last_run_details` VALUES ('9','5','V','1','1','2016-07-01 15:12:05');
INSERT INTO `rlb_device_last_run_details` VALUES ('10','4','V','2','2','2016-07-14 14:56:01');
INSERT INTO `rlb_device_last_run_details` VALUES ('11','3','V','1','2','2016-07-14 14:55:44');
INSERT INTO `rlb_device_last_run_details` VALUES ('12','2','V','2','2','2016-07-06 17:36:32');
INSERT INTO `rlb_device_last_run_details` VALUES ('13','1','V','1','2','2016-07-01 15:07:33');

/*---------------------------------------------------------------
  TABLE: `rlb_exclude_device`
  ---------------------------------------------------------------*/
DROP TABLE IF EXISTS `rlb_exclude_device`;
CREATE TABLE `rlb_exclude_device` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `exclude_devices` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
INSERT INTO `rlb_exclude_device` VALUES   ('1','a:8:{s:1:\"R\";a:3:{i:0;s:3:\"7_1\";i:1;s:4:\"14_2\";i:2;s:4:\"15_2\";}s:1:\"P\";b:0;s:1:\"V\";b:0;s:2:\"PS\";b:0;s:1:\"H\";b:0;s:1:\"B\";b:0;s:1:\"L\";b:0;s:1:\"M\";b:0;}');

/*---------------------------------------------------------------
  TABLE: `rlb_heater_run`
  ---------------------------------------------------------------*/
DROP TABLE IF EXISTS `rlb_heater_run`;
CREATE TABLE `rlb_heater_run` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `heaterNumber` int(5) NOT NULL,
  `ip_id` int(5) NOT NULL,
  `heaterRun` enum('0','1') NOT NULL DEFAULT '0',
  `heaterStart` datetime NOT NULL,
  `heaterEnd` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;
INSERT INTO `rlb_heater_run` VALUES   ('1','1','1','0','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `rlb_heater_run` VALUES ('2','0','1','0','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `rlb_heater_run` VALUES ('3','1','2','0','0000-00-00 00:00:00','0000-00-00 00:00:00');

/*---------------------------------------------------------------
  TABLE: `rlb_mode_questions`
  ---------------------------------------------------------------*/
DROP TABLE IF EXISTS `rlb_mode_questions`;
CREATE TABLE `rlb_mode_questions` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `general` text NOT NULL,
  `device` text NOT NULL,
  `heater` text NOT NULL,
  `more` text NOT NULL,
  `added_date` datetime NOT NULL,
  `last_modified` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
INSERT INTO `rlb_mode_questions` VALUES   ('1','a:11:{s:4:\"type\";s:4:\"pool\";s:13:\"pool_max_temp\";s:2:\"50\";s:9:\"pool_temp\";s:2:\"50\";s:11:\"pool_manual\";s:2:\"50\";s:12:\"spa_max_temp\";s:0:\"\";s:15:\"spa_temperature\";s:0:\"\";s:10:\"spa_manual\";s:0:\"\";s:12:\"temperature1\";s:3:\"0_1\";s:12:\"temperature2\";s:3:\"0_1\";s:17:\"display_pool_temp\";s:3:\"Yes\";s:16:\"display_spa_temp\";s:3:\"Yes\";}','','','','2016-07-11 21:29:26','2016-07-14 08:31:32');

/*---------------------------------------------------------------
  TABLE: `rlb_modes`
  ---------------------------------------------------------------*/
DROP TABLE IF EXISTS `rlb_modes`;
CREATE TABLE `rlb_modes` (
  `mode_id` int(11) NOT NULL AUTO_INCREMENT,
  `mode_name` varchar(255) NOT NULL,
  `mode_status` int(1) NOT NULL DEFAULT '0',
  `start_time` datetime NOT NULL,
  `timer_total` varchar(150) NOT NULL,
  `timer_start` varchar(150) NOT NULL,
  `timer_end` varchar(150) NOT NULL,
  `unique_id` varchar(100) NOT NULL,
  PRIMARY KEY (`mode_id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;
INSERT INTO `rlb_modes` VALUES   ('1','Auto','1','2016-07-14 15:45:02','','','','');
INSERT INTO `rlb_modes` VALUES ('2','Manual','0','0000-00-00 00:00:00','50','2016-07-14 14:54:36','2016-07-14 15:44:36','');
INSERT INTO `rlb_modes` VALUES ('3','Time-Out','0','0000-00-00 00:00:00','','','','');

/*---------------------------------------------------------------
  TABLE: `rlb_pool_spa_current`
  ---------------------------------------------------------------*/
DROP TABLE IF EXISTS `rlb_pool_spa_current`;
CREATE TABLE `rlb_pool_spa_current` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `mode_id` int(5) NOT NULL,
  `current_on_device` varchar(255) NOT NULL,
  `device_type` varchar(10) NOT NULL,
  `device_number` varchar(10) NOT NULL,
  `current_on_time` datetime NOT NULL,
  `current_off_time` datetime NOT NULL,
  `current_device_complete` enum('0','1') NOT NULL,
  `current_unique_id` varchar(100) NOT NULL,
  `current_sequence` int(5) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*---------------------------------------------------------------
  TABLE: `rlb_pool_spa_log`
  ---------------------------------------------------------------*/
DROP TABLE IF EXISTS `rlb_pool_spa_log`;
CREATE TABLE `rlb_pool_spa_log` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `mode_id` int(5) NOT NULL,
  `unique_id` varchar(100) NOT NULL,
  `device` varchar(150) NOT NULL,
  `device_type` varchar(10) NOT NULL,
  `device_number` varchar(10) NOT NULL,
  `device_start` datetime NOT NULL,
  `device_stop` datetime NOT NULL,
  `device_complete_run` enum('0','1','2') NOT NULL DEFAULT '0',
  `current_sequence` int(5) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*---------------------------------------------------------------
  TABLE: `rlb_pool_spa_mode`
  ---------------------------------------------------------------*/
DROP TABLE IF EXISTS `rlb_pool_spa_mode`;
CREATE TABLE `rlb_pool_spa_mode` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `mode_name` varchar(150) NOT NULL,
  `mode_status` enum('0','1') NOT NULL DEFAULT '0',
  `total_run_time` varchar(100) NOT NULL,
  `last_start_date` datetime NOT NULL,
  `last_end_date` datetime NOT NULL,
  `unique_id` varchar(100) NOT NULL,
  `all_device_on` enum('0','1') NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
INSERT INTO `rlb_pool_spa_mode` VALUES   ('1','Pool','1','','0000-00-00 00:00:00','0000-00-00 00:00:00','','0');
INSERT INTO `rlb_pool_spa_mode` VALUES ('2','Spa','0','','0000-00-00 00:00:00','0000-00-00 00:00:00','','0');
INSERT INTO `rlb_pool_spa_mode` VALUES ('3','Both','0','','0000-00-00 00:00:00','0000-00-00 00:00:00','','0');
INSERT INTO `rlb_pool_spa_mode` VALUES ('4','Pool Auto','0','','0000-00-00 00:00:00','0000-00-00 00:00:00','','0');

/*---------------------------------------------------------------
  TABLE: `rlb_position`
  ---------------------------------------------------------------*/
DROP TABLE IF EXISTS `rlb_position`;
CREATE TABLE `rlb_position` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `position_name` varchar(250) NOT NULL,
  `position_device` varchar(100) NOT NULL,
  `position_active` enum('0','1') NOT NULL DEFAULT '0',
  `position_added_date` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=latin1;
INSERT INTO `rlb_position` VALUES   ('2','Pool','','1','2015-12-04 07:51:03');
INSERT INTO `rlb_position` VALUES ('3','Spa','','1','2015-12-04 07:51:08');
INSERT INTO `rlb_position` VALUES ('4','Other','','1','2015-12-04 07:51:16');
INSERT INTO `rlb_position` VALUES ('5','Waterfall','','1','2015-12-04 07:55:54');
INSERT INTO `rlb_position` VALUES ('6','Spa 1 Open','','1','2016-06-22 09:34:15');
INSERT INTO `rlb_position` VALUES ('7','Spa 1 Closed','','1','2016-06-22 09:34:33');
INSERT INTO `rlb_position` VALUES ('8','Spa 2 open','','1','2016-06-22 09:36:23');
INSERT INTO `rlb_position` VALUES ('9','Spa 2 closed','','1','2016-06-22 09:36:36');
INSERT INTO `rlb_position` VALUES ('10','Spa 1 ','','1','2016-06-22 09:39:24');
INSERT INTO `rlb_position` VALUES ('11','Spa 2','','1','2016-06-22 09:39:34');
INSERT INTO `rlb_position` VALUES ('12','Spa 2 Jets On','','1','2016-06-22 09:45:28');
INSERT INTO `rlb_position` VALUES ('13','Spa 2 Jets Off','','1','2016-06-22 09:45:39');
INSERT INTO `rlb_position` VALUES ('14','Waterfall on','','1','2016-06-22 09:48:39');
INSERT INTO `rlb_position` VALUES ('15','Waterfall off','','1','2016-06-22 09:48:48');
INSERT INTO `rlb_position` VALUES ('16','F Pool Return','','1','2016-06-22 09:53:41');
INSERT INTO `rlb_position` VALUES ('17','F Pool Waterfall','','1','2016-06-22 09:59:16');
INSERT INTO `rlb_position` VALUES ('18','Jet Stream','','1','2016-06-22 10:08:53');
INSERT INTO `rlb_position` VALUES ('19','Solar On','','1','2016-06-22 10:11:09');
INSERT INTO `rlb_position` VALUES ('20','Solar Off','','1','2016-06-22 10:11:22');

/*---------------------------------------------------------------
  TABLE: `rlb_powercenters`
  ---------------------------------------------------------------*/
DROP TABLE IF EXISTS `rlb_powercenters`;
CREATE TABLE `rlb_powercenters` (
  `powercenter_id` int(11) NOT NULL AUTO_INCREMENT,
  `powercenter_number` int(11) NOT NULL,
  `powercenter_name` varchar(100) NOT NULL,
  PRIMARY KEY (`powercenter_id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
INSERT INTO `rlb_powercenters` VALUES   ('1','0','Test powercenter0');
INSERT INTO `rlb_powercenters` VALUES ('2','4','pc4 edit');
INSERT INTO `rlb_powercenters` VALUES ('3','2','Testing');
INSERT INTO `rlb_powercenters` VALUES ('4','1','PowerCenter1');

/*---------------------------------------------------------------
  TABLE: `rlb_program`
  ---------------------------------------------------------------*/
DROP TABLE IF EXISTS `rlb_program`;
CREATE TABLE `rlb_program` (
  `program_id` int(11) NOT NULL AUTO_INCREMENT,
  `program_name` varchar(255) NOT NULL,
  `device_number` varchar(8) NOT NULL,
  `device_type` varchar(8) NOT NULL,
  `program_type` int(2) NOT NULL COMMENT '1-Daily, 2-Weekly',
  `program_days` varchar(255) NOT NULL COMMENT '0-All, 1-Mon, 2-Tue...7-Sun',
  `start_time` varchar(255) NOT NULL,
  `end_time` varchar(255) NOT NULL,
  `program_created_date` datetime NOT NULL,
  `program_modified_date` datetime NOT NULL,
  `program_delete` int(1) NOT NULL DEFAULT '0',
  `program_active` int(1) NOT NULL DEFAULT '0',
  `program_absolute` enum('0','1') NOT NULL DEFAULT '0',
  `program_absolute_start_time` varchar(100) DEFAULT NULL,
  `program_absolute_end_time` varchar(100) DEFAULT NULL,
  `program_absolute_total_time` varchar(100) DEFAULT NULL,
  `program_absolute_run_time` varchar(100) DEFAULT NULL,
  `program_absolute_start_date` date DEFAULT NULL,
  `program_absolute_run` enum('0','1') NOT NULL DEFAULT '0',
  `is_on_after_reboot` enum('0','1') NOT NULL DEFAULT '0',
  `program_work_in_mode` enum('0','1') NOT NULL DEFAULT '0',
  `ip_id` int(5) NOT NULL,
  `valvePosition` int(5) NOT NULL DEFAULT '0',
  PRIMARY KEY (`program_id`)
) ENGINE=MyISAM AUTO_INCREMENT=32 DEFAULT CHARSET=latin1;
INSERT INTO `rlb_program` VALUES   ('1','Daily Filtering','1','PS','1','0','06:00:00','12:00:00','2016-06-22 16:17:41','2016-06-23 09:01:42','1','0','0',NULL,NULL,'06:00:00',NULL,NULL,'0','0','0','1','0');
INSERT INTO `rlb_program` VALUES ('2','Daily Filtering F Pool','3','PS','1','0','11:05:00','20:05:00','2016-06-22 16:21:13','0000-00-00 00:00:00','0','0','0',NULL,NULL,'09:00:00',NULL,NULL,'0','0','1','1','0');
INSERT INTO `rlb_program` VALUES ('3','Spa 2 Filtering','4','V','1','0','11:00:00','12:00:00','2016-06-23 09:03:07','0000-00-00 00:00:00','1','0','',NULL,NULL,'01:00:00',NULL,NULL,'0','0','0','1','2');
INSERT INTO `rlb_program` VALUES ('4','Daily Filtering','3','V','1','0','11:00:00','12:05:00','2016-06-23 09:04:28','0000-00-00 00:00:00','1','0','',NULL,NULL,'01:05:00',NULL,NULL,'0','0','0','2','1');
INSERT INTO `rlb_program` VALUES ('5','Daily 11:00 Filtering Start','0','V','1','0','11:01:00','12:00:00','2016-06-23 09:06:33','0000-00-00 00:00:00','1','0','',NULL,NULL,'00:59:00',NULL,NULL,'0','0','0','2','1');
INSERT INTO `rlb_program` VALUES ('6','Daily 11:00 Filtering Start','5','V','1','0','11:01:00','12:00:00','2016-06-23 09:08:26','0000-00-00 00:00:00','1','0','',NULL,NULL,'00:59:00',NULL,NULL,'0','0','0','2','1');
INSERT INTO `rlb_program` VALUES ('7','Daily 11:00 Filtering Start','4','V','1','0','11:01:00','12:00:00','2016-06-23 09:09:37','0000-00-00 00:00:00','1','0','',NULL,NULL,'00:59:00',NULL,NULL,'0','0','0','2','2');
INSERT INTO `rlb_program` VALUES ('8','Daily 11:00 Filtering End','4','V','1','0','12:05:00','12:10:00','2016-06-23 09:11:26','0000-00-00 00:00:00','1','0','',NULL,NULL,'00:05:00',NULL,NULL,'0','0','0','2','1');
INSERT INTO `rlb_program` VALUES ('9','Daily 11:00 Filtering End','5','V','1','0','12:05:00','12:10:00','2016-06-23 09:12:56','0000-00-00 00:00:00','1','0','',NULL,NULL,'00:05:00',NULL,NULL,'0','0','0','2','2');
INSERT INTO `rlb_program` VALUES ('10','Daily 11:00 Filtering End','4','V','1','0','12:05:00','12:10:00','2016-06-23 09:14:09','0000-00-00 00:00:00','1','0','',NULL,NULL,'00:05:00',NULL,NULL,'0','0','0','1','1');
INSERT INTO `rlb_program` VALUES ('11','Daily 11:00 Filtering End','0','V','1','0','12:04:00','12:10:00','2016-06-23 09:16:27','0000-00-00 00:00:00','1','0','',NULL,NULL,'00:06:00',NULL,NULL,'0','0','0','2','1');
INSERT INTO `rlb_program` VALUES ('12','Daily 11:00 Filtering End','3','V','1','0','12:05:00','12:10:00','2016-06-23 09:17:49','0000-00-00 00:00:00','1','0','',NULL,NULL,'00:05:00',NULL,NULL,'0','0','0','2','2');
INSERT INTO `rlb_program` VALUES ('13','Test Program','0','V','1','0','01:00:00','01:10:00','2016-06-24 01:17:39','0000-00-00 00:00:00','1','0','',NULL,NULL,'00:10:00',NULL,NULL,'0','0','0','1','1');
INSERT INTO `rlb_program` VALUES ('14','Test Program','1','PS','1','0','01:05:00','01:10:00','2016-06-24 01:18:08','0000-00-00 00:00:00','1','0','',NULL,NULL,'00:05:00',NULL,NULL,'0','0','0','1','0');
INSERT INTO `rlb_program` VALUES ('15','Test Program','6','R','1','0','01:05:00','01:10:00','2016-06-24 01:18:59','0000-00-00 00:00:00','1','0','',NULL,NULL,'00:05:00',NULL,NULL,'0','0','0','1','0');
INSERT INTO `rlb_program` VALUES ('16','Test Program','1','PS','1','0','04:35:00','05:55:00','2016-06-24 02:01:29','2016-06-24 04:35:26','1','0','1','','','01:20:00','','2016-06-24','1','0','1','1','0');
INSERT INTO `rlb_program` VALUES ('17','Test Program','0','V','1','0','03:15:00','03:50:00','2016-06-24 02:02:12','2016-06-24 03:15:42','1','0','0','','','00:35:00','00:00:00','2016-06-24','0','0','0','1','1');
INSERT INTO `rlb_program` VALUES ('18','Test Program','6','R','1','0','01:00:00','01:10:00','2016-06-24 02:02:55','0000-00-00 00:00:00','0','0','',NULL,NULL,'00:10:00',NULL,NULL,'0','0','0','1','0');
INSERT INTO `rlb_program` VALUES ('19','Test Program 2','2','PS','1','0','04:30:00','05:55:00','2016-06-24 03:26:07','2016-06-24 04:35:53','0','0','0',NULL,NULL,'01:25:00',NULL,NULL,'0','0','0','1','0');
INSERT INTO `rlb_program` VALUES ('31','test 1','4','V','1','0','22:20:00','22:35:00','2016-06-27 22:14:56','0000-00-00 00:00:00','1','0','',NULL,NULL,'00:15:00',NULL,NULL,'0','0','1','1','1');
INSERT INTO `rlb_program` VALUES ('20','Daily Filtering','1','PS','1','0','11:40:00','16:40:00','2016-06-27 11:36:36','2016-06-27 22:18:52','0','0','1','','','05:00:00','','2016-06-27','1','0','1','1','0');
INSERT INTO `rlb_program` VALUES ('21','Spa 2 Filtering On','4','V','1','0','12:00:00','12:01:00','2016-06-27 11:40:24','2016-06-27 11:42:08','1','0','',NULL,NULL,'00:01:00',NULL,NULL,'0','0','1','1','2');
INSERT INTO `rlb_program` VALUES ('22','Spa 2 Daily Filtering','4','V','1','0','13:01:00','13:02:00','2016-06-27 11:43:19','0000-00-00 00:00:00','1','0','',NULL,NULL,'00:01:00',NULL,NULL,'0','0','1','1','1');
INSERT INTO `rlb_program` VALUES ('23','Spa 2 Daily Filtering','3','V','1','0','12:01:00','12:02:00','2016-06-27 11:44:46','0000-00-00 00:00:00','1','0','',NULL,NULL,'00:01:00',NULL,NULL,'0','0','1','2','1');
INSERT INTO `rlb_program` VALUES ('24','Spa 2 Daily Filtering Off','3','V','1','0','13:01:00','13:02:00','2016-06-27 11:45:31','0000-00-00 00:00:00','1','0','',NULL,NULL,'00:01:00',NULL,NULL,'0','0','1','2','2');
INSERT INTO `rlb_program` VALUES ('25','Spa 2 Daily Filtering','0','V','1','0','12:03:00','12:04:00','2016-06-27 11:46:28','0000-00-00 00:00:00','1','0','',NULL,NULL,'00:01:00',NULL,NULL,'0','0','1','2','2');
INSERT INTO `rlb_program` VALUES ('26','Spa 2 Daily Filtering Off','0','V','1','0','13:03:00','13:04:00','2016-06-27 11:47:33','0000-00-00 00:00:00','1','0','',NULL,NULL,'00:01:00',NULL,NULL,'0','0','1','2','1');
INSERT INTO `rlb_program` VALUES ('27','Spa 2 Daily Filtering','5','V','1','0','12:04:00','12:05:00','2016-06-27 11:48:58','0000-00-00 00:00:00','1','0','',NULL,NULL,'00:01:00',NULL,NULL,'0','0','1','2','1');
INSERT INTO `rlb_program` VALUES ('28','Spa 2 Daily Filtering Off','5','V','1','0','13:04:00','13:05:00','2016-06-27 11:49:44','0000-00-00 00:00:00','1','0','',NULL,NULL,'00:01:00',NULL,NULL,'0','0','1','2','1');
INSERT INTO `rlb_program` VALUES ('29','Spa 2 Daily Filtering','4','V','1','0','12:04:00','12:05:00','2016-06-27 11:50:40','0000-00-00 00:00:00','1','0','',NULL,NULL,'00:01:00',NULL,NULL,'0','0','1','2','2');
INSERT INTO `rlb_program` VALUES ('30','Spa 2 Daily Filtering Off','4','V','1','0','13:04:00','13:05:00','2016-06-27 11:51:07','0000-00-00 00:00:00','1','0','',NULL,NULL,'00:01:00',NULL,NULL,'0','0','1','2','1');

/*---------------------------------------------------------------
  TABLE: `rlb_pump_device`
  ---------------------------------------------------------------*/
DROP TABLE IF EXISTS `rlb_pump_device`;
CREATE TABLE `rlb_pump_device` (
  `pump_id` int(10) NOT NULL AUTO_INCREMENT,
  `pump_number` int(5) NOT NULL,
  `pump_type` enum('12','24','Intellicom','Emulator','Intellicom12','Intellicom24','Emulator12','Emulator24','2Speed') NOT NULL,
  `pump_sub_type` enum('VS','VF','12','24') NOT NULL,
  `pump_speed` varchar(150) NOT NULL,
  `pump_flow` varchar(250) NOT NULL,
  `pump_closure` varchar(150) NOT NULL,
  `relay_number` varchar(10) NOT NULL,
  `pump_address` varchar(50) NOT NULL,
  `pump_modified_date` datetime NOT NULL,
  `relay_number_1` varchar(10) NOT NULL,
  `status` enum('0','1','2') NOT NULL DEFAULT '0',
  `ip_id` int(5) NOT NULL,
  `pump_on` enum('0','1') NOT NULL DEFAULT '0',
  PRIMARY KEY (`pump_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;
INSERT INTO `rlb_pump_device` VALUES   ('1','1','Emulator','VS','3110','','1','','60','2016-06-21 23:29:32','','1','1','0');
INSERT INTO `rlb_pump_device` VALUES ('2','2','Emulator','VS','3100','','0','','61','2016-06-22 10:33:30','','0','1','0');
INSERT INTO `rlb_pump_device` VALUES ('3','3','24','','','','1','14','','2016-06-22 16:19:09','','0','1','0');

/*---------------------------------------------------------------
  TABLE: `rlb_pump_heater`
  ---------------------------------------------------------------*/
DROP TABLE IF EXISTS `rlb_pump_heater`;
CREATE TABLE `rlb_pump_heater` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `pump` varchar(10) NOT NULL,
  `end_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*---------------------------------------------------------------
  TABLE: `rlb_pump_response`
  ---------------------------------------------------------------*/
DROP TABLE IF EXISTS `rlb_pump_response`;
CREATE TABLE `rlb_pump_response` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `pump_number` int(5) NOT NULL,
  `pump_response_time` datetime NOT NULL,
  `pump_response` varchar(255) DEFAULT NULL,
  `ip_id` int(5) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*---------------------------------------------------------------
  TABLE: `rlb_reboot_history`
  ---------------------------------------------------------------*/
DROP TABLE IF EXISTS `rlb_reboot_history`;
CREATE TABLE `rlb_reboot_history` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `details` text NOT NULL,
  `ip_id` int(5) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=49 DEFAULT CHARSET=latin1;
INSERT INTO `rlb_reboot_history` VALUES   ('1','a:5:{s:9:\"sResponse\";s:120:\"S,145,0,1,12:22:00,3,06,000.000.,......00......00,00000000,0,0,0,0,12515,98.9F,89.0F,,87.6F,88.7F,85.3F,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"000.000.\";s:7:\"sRelays\";s:16:\"......00......00\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','1');
INSERT INTO `rlb_reboot_history` VALUES ('2','a:5:{s:9:\"sResponse\";s:101:\"S,181,0,1,12:21:54,3,06,000000..,............0000,00000000,0,0,0,0,12515,100.0F,,,,,,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"000000..\";s:7:\"sRelays\";s:16:\"............0000\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','2');
INSERT INTO `rlb_reboot_history` VALUES ('3','a:5:{s:9:\"sResponse\";s:126:\"S,003,0,0,11:39:13,3,06,000.000.,......00......10,00000000,0,0,0,0,12531,101.5F,86.9F,86.8F,85.7F,81.5F,84.7F,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"000.000.\";s:7:\"sRelays\";s:16:\"......00......10\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:3:{i:0;s:1:\"1\";i:1;s:1:\"2\";i:2;s:1:\"3\";}}','1');
INSERT INTO `rlb_reboot_history` VALUES ('4','a:5:{s:9:\"sResponse\";s:100:\"S,192,0,0,11:39:14,3,06,000000..,............0000,00000000,0,0,0,0,12531,98.8F,,,,,,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"000000..\";s:7:\"sRelays\";s:16:\"............0000\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','2');
INSERT INTO `rlb_reboot_history` VALUES ('5','a:5:{s:9:\"sResponse\";s:126:\"S,006,0,0,23:54:36,3,06,000.000.,......00......00,00000000,0,0,0,0,12515,101.4F,86.5F,86.6F,84.9F,86.0F,84.0F,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"000.000.\";s:7:\"sRelays\";s:16:\"......00......00\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','1');
INSERT INTO `rlb_reboot_history` VALUES ('6','a:5:{s:9:\"sResponse\";s:100:\"S,146,0,1,11:38:52,3,06,000000..,............0000,00000000,0,0,0,0,12515,97.8F,,,,,,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"000000..\";s:7:\"sRelays\";s:16:\"............0000\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','2');
INSERT INTO `rlb_reboot_history` VALUES ('7','a:5:{s:9:\"sResponse\";s:126:\"S,065,0,0,23:59:17,3,06,000.000.,......00......00,00000000,0,0,0,0,12500,100.0F,83.9F,84.0F,83.2F,84.2F,83.0F,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"000.000.\";s:7:\"sRelays\";s:16:\"......00......00\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','1');
INSERT INTO `rlb_reboot_history` VALUES ('8','a:5:{s:9:\"sResponse\";s:100:\"S,111,0,2,11:38:31,3,06,000000..,............0000,00000000,0,0,0,0,12515,97.8F,,,,,,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"000000..\";s:7:\"sRelays\";s:16:\"............0000\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','2');
INSERT INTO `rlb_reboot_history` VALUES ('9','a:5:{s:9:\"sResponse\";s:126:\"S,023,0,0,23:59:19,3,06,000.000.,......00......00,00000000,0,0,0,0,12515,102.5F,86.8F,87.2F,85.7F,86.9F,85.2F,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"000.000.\";s:7:\"sRelays\";s:16:\"......00......00\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','1');
INSERT INTO `rlb_reboot_history` VALUES ('10','a:5:{s:9:\"sResponse\";s:100:\"S,175,0,3,11:38:10,3,06,000000..,............0000,00000000,0,0,0,0,12531,98.8F,,,,,,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"000000..\";s:7:\"sRelays\";s:16:\"............0000\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','2');
INSERT INTO `rlb_reboot_history` VALUES ('11','a:5:{s:9:\"sResponse\";s:126:\"S,244,0,0,23:59:16,3,06,000.000.,......00......00,00000000,0,0,0,0,12500,103.6F,86.0F,86.1F,85.8F,86.0F,86.2F,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"000.000.\";s:7:\"sRelays\";s:16:\"......00......00\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','1');
INSERT INTO `rlb_reboot_history` VALUES ('12','a:5:{s:9:\"sResponse\";s:101:\"S,006,0,4,11:37:48,3,06,000000..,............0000,00000000,0,0,0,0,12531,103.3F,,,,,,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"000000..\";s:7:\"sRelays\";s:16:\"............0000\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','2');
INSERT INTO `rlb_reboot_history` VALUES ('13','a:5:{s:9:\"sResponse\";s:125:\"S,143,0,0,23:59:19,3,06,000.000.,......00......00,00000000,0,0,0,0,12500,99.2F,92.1F,92.6F,90.3F,92.3F,93.0F,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"000.000.\";s:7:\"sRelays\";s:16:\"......00......00\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','1');
INSERT INTO `rlb_reboot_history` VALUES ('14','a:5:{s:9:\"sResponse\";s:101:\"S,078,0,5,11:37:27,3,06,000000..,............0000,00000000,0,0,0,0,12515,103.4F,,,,,,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"000000..\";s:7:\"sRelays\";s:16:\"............0000\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','2');
INSERT INTO `rlb_reboot_history` VALUES ('15','a:5:{s:9:\"sResponse\";s:125:\"S,026,0,0,23:59:24,3,06,000.000.,......00......00,00000000,0,0,0,0,12500,93.4F,85.8F,86.3F,86.0F,86.0F,86.6F,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"000.000.\";s:7:\"sRelays\";s:16:\"......00......00\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','1');
INSERT INTO `rlb_reboot_history` VALUES ('16','a:5:{s:9:\"sResponse\";s:100:\"S,213,0,6,11:37:06,3,06,000000..,............0000,00000000,0,0,0,0,12515,97.5F,,,,,,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"000000..\";s:7:\"sRelays\";s:16:\"............0000\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','2');
INSERT INTO `rlb_reboot_history` VALUES ('17','a:5:{s:9:\"sResponse\";s:125:\"S,189,0,0,23:59:19,3,06,000.000.,......00......00,01000000,0,0,0,0,12484,97.6F,88.7F,88.5F,86.9F,88.7F,90.1F,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"000.000.\";s:7:\"sRelays\";s:16:\"......00......00\";s:12:\"sPowercenter\";s:8:\"01000000\";s:5:\"sPump\";a:0:{}}','1');
INSERT INTO `rlb_reboot_history` VALUES ('18','a:5:{s:9:\"sResponse\";s:101:\"S,014,0,7,11:36:45,3,06,000000..,............0000,00000000,0,0,0,0,12515,101.2F,,,,,,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"000000..\";s:7:\"sRelays\";s:16:\"............0000\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','2');
INSERT INTO `rlb_reboot_history` VALUES ('19','a:5:{s:9:\"sResponse\";s:125:\"S,085,0,0,23:59:25,3,06,000.000.,......00......00,00000000,0,0,0,0,12484,83.6F,74.4F,73.2F,74.1F,77.0F,76.9F,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"000.000.\";s:7:\"sRelays\";s:16:\"......00......00\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','1');
INSERT INTO `rlb_reboot_history` VALUES ('20','a:5:{s:9:\"sResponse\";s:100:\"S,210,0,1,11:36:28,3,06,000000..,............0000,00000000,0,0,0,0,12515,87.8F,,,,,,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"000000..\";s:7:\"sRelays\";s:16:\"............0000\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','2');
INSERT INTO `rlb_reboot_history` VALUES ('21','a:5:{s:9:\"sResponse\";s:125:\"S,226,0,0,19:37:08,3,06,000.000.,......00......00,00000000,0,0,0,0,12484,89.4F,80.0F,80.0F,80.8F,80.6F,82.9F,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"000.000.\";s:7:\"sRelays\";s:16:\"......00......00\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','1');
INSERT INTO `rlb_reboot_history` VALUES ('22','a:5:{s:9:\"sResponse\";s:100:\"S,252,0,0,19:37:04,3,06,000000..,............0000,00000000,0,0,0,0,12500,93.3F,,,,,,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"000000..\";s:7:\"sRelays\";s:16:\"............0000\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','2');
INSERT INTO `rlb_reboot_history` VALUES ('23','a:5:{s:9:\"sResponse\";s:125:\"S,138,0,0,23:59:22,3,06,000.000.,......00......00,00000000,0,0,0,0,12484,92.4F,85.6F,86.1F,84.9F,86.0F,86.7F,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"000.000.\";s:7:\"sRelays\";s:16:\"......00......00\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','1');
INSERT INTO `rlb_reboot_history` VALUES ('24','a:5:{s:9:\"sResponse\";s:100:\"S,169,0,1,19:36:45,3,06,000000..,............0000,00000000,0,0,0,0,12500,96.5F,,,,,,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"000000..\";s:7:\"sRelays\";s:16:\"............0000\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','2');
INSERT INTO `rlb_reboot_history` VALUES ('25','a:5:{s:9:\"sResponse\";s:125:\"S,030,0,0,23:59:19,3,06,000.000.,......00......00,00000000,0,0,0,0,12500,91.2F,84.4F,84.5F,83.8F,84.2F,85.4F,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"000.000.\";s:7:\"sRelays\";s:16:\"......00......00\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','1');
INSERT INTO `rlb_reboot_history` VALUES ('26','a:5:{s:9:\"sResponse\";s:100:\"S,078,0,2,19:36:26,3,06,010000..,............0000,00000000,0,0,0,0,12515,95.5F,,,,,,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"010000..\";s:7:\"sRelays\";s:16:\"............0000\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','2');
INSERT INTO `rlb_reboot_history` VALUES ('27','a:5:{s:9:\"sResponse\";s:125:\"S,117,0,0,23:59:18,3,06,000.100.,......00......00,00000000,0,0,0,0,12500,90.5F,84.1F,84.1F,82.6F,79.7F,84.5F,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"000.100.\";s:7:\"sRelays\";s:16:\"......00......00\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:1:{i:0;s:1:\"1\";}}','1');
INSERT INTO `rlb_reboot_history` VALUES ('28','a:5:{s:9:\"sResponse\";s:100:\"S,152,0,3,19:36:08,3,06,210202..,............0000,00000000,0,0,0,0,12515,95.9F,,,,,,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"210202..\";s:7:\"sRelays\";s:16:\"............0000\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','2');
INSERT INTO `rlb_reboot_history` VALUES ('29','a:5:{s:9:\"sResponse\";s:125:\"S,148,0,0,23:59:24,3,06,000.000.,......00......00,00000000,0,0,0,0,12500,88.8F,82.1F,82.1F,80.9F,77.9F,83.3F,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"000.000.\";s:7:\"sRelays\";s:16:\"......00......00\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:1:{i:0;s:1:\"1\";}}','1');
INSERT INTO `rlb_reboot_history` VALUES ('30','a:5:{s:9:\"sResponse\";s:100:\"S,169,0,4,19:35:51,3,06,000000..,............0000,00000000,0,0,0,0,12515,92.9F,,,,,,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"000000..\";s:7:\"sRelays\";s:16:\"............0000\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','2');
INSERT INTO `rlb_reboot_history` VALUES ('31','a:5:{s:9:\"sResponse\";s:125:\"S,127,0,0,23:59:26,3,06,100.000.,......00......00,00000000,0,0,0,0,12500,90.4F,83.1F,83.1F,81.5F,82.4F,83.8F,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"100.000.\";s:7:\"sRelays\";s:16:\"......00......00\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','1');
INSERT INTO `rlb_reboot_history` VALUES ('32','a:5:{s:9:\"sResponse\";s:100:\"S,003,0,5,19:35:33,3,06,010000..,............0000,00000000,0,0,0,0,12515,94.1F,,,,,,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"010000..\";s:7:\"sRelays\";s:16:\"............0000\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','2');
INSERT INTO `rlb_reboot_history` VALUES ('33','a:5:{s:9:\"sResponse\";s:125:\"S,163,0,0,23:59:24,3,06,000.001.,......00......00,00000000,0,0,0,0,12500,96.0F,83.9F,84.0F,81.6F,83.3F,82.2F,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"000.001.\";s:7:\"sRelays\";s:16:\"......00......00\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','1');
INSERT INTO `rlb_reboot_history` VALUES ('34','a:5:{s:9:\"sResponse\";s:100:\"S,075,0,6,19:35:16,3,06,000000..,............0000,00000000,0,0,0,0,12531,94.8F,,,,,,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"000000..\";s:7:\"sRelays\";s:16:\"............0000\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','2');
INSERT INTO `rlb_reboot_history` VALUES ('35','a:5:{s:9:\"sResponse\";s:125:\"S,147,0,0,23:59:19,3,06,000.001.,......00......00,00000000,0,0,0,0,12500,92.3F,83.9F,84.0F,82.7F,83.3F,82.0F,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"000.001.\";s:7:\"sRelays\";s:16:\"......00......00\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','1');
INSERT INTO `rlb_reboot_history` VALUES ('36','a:5:{s:9:\"sResponse\";s:100:\"S,172,0,7,19:34:57,3,06,000000..,............0000,00000000,0,0,0,0,12531,94.2F,,,,,,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"000000..\";s:7:\"sRelays\";s:16:\"............0000\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','2');
INSERT INTO `rlb_reboot_history` VALUES ('37','a:5:{s:9:\"sResponse\";s:125:\"S,062,0,0,23:59:28,3,06,000.000.,......00......00,00000000,0,0,0,0,12500,93.9F,79.7F,79.4F,80.7F,78.8F,78.4F,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"000.000.\";s:7:\"sRelays\";s:16:\"......00......00\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','1');
INSERT INTO `rlb_reboot_history` VALUES ('38','a:5:{s:9:\"sResponse\";s:100:\"S,237,0,1,19:34:40,3,06,000000..,............0000,00000000,0,0,0,0,12531,90.6F,,,,,,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"000000..\";s:7:\"sRelays\";s:16:\"............0000\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','2');
INSERT INTO `rlb_reboot_history` VALUES ('39','a:5:{s:9:\"sResponse\";s:125:\"S,249,0,0,23:59:22,3,06,000.000.,......00......00,00000000,0,0,0,0,12484,94.3F,82.2F,82.4F,81.6F,81.5F,81.1F,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"000.000.\";s:7:\"sRelays\";s:16:\"......00......00\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','1');
INSERT INTO `rlb_reboot_history` VALUES ('40','a:5:{s:9:\"sResponse\";s:100:\"S,150,0,2,19:34:23,3,06,000200..,............0000,00000000,0,0,0,0,12531,93.7F,,,,,,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"000200..\";s:7:\"sRelays\";s:16:\"............0000\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','2');
INSERT INTO `rlb_reboot_history` VALUES ('41','a:5:{s:9:\"sResponse\";s:125:\"S,071,0,0,23:59:17,3,06,000.000.,......00......00,00000000,0,0,0,0,12500,96.6F,83.3F,83.6F,81.5F,78.8F,81.7F,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"000.000.\";s:7:\"sRelays\";s:16:\"......00......00\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','1');
INSERT INTO `rlb_reboot_history` VALUES ('42','a:5:{s:9:\"sResponse\";s:100:\"S,253,0,3,19:34:04,3,06,000200..,............0000,00000000,0,0,0,0,12515,95.3F,,,,,,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"000200..\";s:7:\"sRelays\";s:16:\"............0000\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','2');
INSERT INTO `rlb_reboot_history` VALUES ('43','a:5:{s:9:\"sResponse\";s:125:\"S,015,0,0,23:59:21,3,06,000.000.,......00......00,00000000,0,0,0,0,12515,98.7F,81.6F,81.3F,80.7F,81.5F,81.8F,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"000.000.\";s:7:\"sRelays\";s:16:\"......00......00\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','1');
INSERT INTO `rlb_reboot_history` VALUES ('44','a:5:{s:9:\"sResponse\";s:100:\"S,100,0,4,19:33:46,3,06,000200..,............0000,00000000,0,0,0,0,12531,97.5F,,,,,,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"000200..\";s:7:\"sRelays\";s:16:\"............0000\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','2');
INSERT INTO `rlb_reboot_history` VALUES ('45','a:5:{s:9:\"sResponse\";s:126:\"S,153,0,0,23:59:15,3,06,000.100.,......00......00,00000000,0,0,0,0,12515,101.4F,84.3F,84.3F,83.2F,79.7F,83.4F,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"000.100.\";s:7:\"sRelays\";s:16:\"......00......00\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:1:{i:0;s:1:\"1\";}}','1');
INSERT INTO `rlb_reboot_history` VALUES ('46','a:5:{s:9:\"sResponse\";s:100:\"S,047,0,5,19:33:26,3,06,200212..,............0000,00000000,0,0,0,0,12515,98.7F,,,,,,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"200212..\";s:7:\"sRelays\";s:16:\"............0000\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','2');
INSERT INTO `rlb_reboot_history` VALUES ('47','a:5:{s:9:\"sResponse\";s:125:\"S,185,0,0,23:59:20,3,06,000.000.,......00......00,00000000,0,0,0,0,12500,95.8F,87.6F,87.6F,86.6F,86.9F,84.7F,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"000.000.\";s:7:\"sRelays\";s:16:\"......00......00\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:1:{i:0;s:1:\"1\";}}','1');
INSERT INTO `rlb_reboot_history` VALUES ('48','a:5:{s:9:\"sResponse\";s:100:\"S,113,0,6,19:33:06,3,06,200212..,............0000,00000000,0,0,0,0,12515,99.6F,,,,,,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"200212..\";s:7:\"sRelays\";s:16:\"............0000\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','2');

/*---------------------------------------------------------------
  TABLE: `rlb_relay_prog`
  ---------------------------------------------------------------*/
DROP TABLE IF EXISTS `rlb_relay_prog`;
CREATE TABLE `rlb_relay_prog` (
  `relay_prog_id` int(11) NOT NULL AUTO_INCREMENT,
  `relay_prog_name` varchar(255) NOT NULL,
  `relay_number` varchar(8) NOT NULL,
  `relay_prog_type` int(2) NOT NULL COMMENT '1-Daily, 2-Weekly',
  `relay_prog_days` varchar(255) NOT NULL COMMENT '0-All, 1-Mon, 2-Tue...7-Sun',
  `relay_start_time` varchar(255) NOT NULL,
  `relay_end_time` varchar(255) NOT NULL,
  `relay_prog_created_date` datetime NOT NULL,
  `relay_prog_modified_date` datetime NOT NULL,
  `relay_prog_delete` int(1) NOT NULL DEFAULT '0',
  `relay_prog_active` int(1) NOT NULL DEFAULT '0',
  `relay_prog_absolute` enum('0','1') NOT NULL DEFAULT '0',
  `relay_prog_absolute_start_time` varchar(100) DEFAULT NULL,
  `relay_prog_absolute_end_time` varchar(100) DEFAULT NULL,
  `relay_prog_absolute_total_time` varchar(100) DEFAULT NULL,
  `relay_prog_absolute_run_time` varchar(100) DEFAULT NULL,
  `relay_prog_absolute_start_date` date DEFAULT NULL,
  `relay_prog_absolute_run` enum('0','1') NOT NULL DEFAULT '0',
  PRIMARY KEY (`relay_prog_id`)
) ENGINE=MyISAM AUTO_INCREMENT=12 DEFAULT CHARSET=latin1;
INSERT INTO `rlb_relay_prog` VALUES   ('1','test','0','1','0','23:00:00','23:30:00','2015-04-03 15:40:46','2015-07-10 12:37:12','0','0','0',NULL,NULL,NULL,NULL,NULL,'0');
INSERT INTO `rlb_relay_prog` VALUES ('2','newtest1','0','2','2,3,6','14:00:00','20:00:00','2015-04-07 00:00:00','2015-04-07 00:00:00','0','0','0',NULL,NULL,NULL,NULL,NULL,'0');
INSERT INTO `rlb_relay_prog` VALUES ('3','testrelay0','0','2','1,4,5','22:00:00','23:30:00','2015-04-07 00:00:00','2015-04-07 00:00:00','0','0','0',NULL,NULL,NULL,NULL,NULL,'0');
INSERT INTO `rlb_relay_prog` VALUES ('4','testrelay1','1','1','0','10:00:00','13:00:00','2015-04-08 00:00:00','2015-04-08 00:00:00','0','0','0',NULL,NULL,NULL,NULL,NULL,'0');
INSERT INTO `rlb_relay_prog` VALUES ('5','Weeklytest','0','2','2,6','01:00:00','01:30:00','2015-04-20 00:00:00','2015-04-20 00:00:00','1','0','0',NULL,NULL,NULL,NULL,NULL,'0');
INSERT INTO `rlb_relay_prog` VALUES ('6','</>','0','1','0','</>','</>','2015-04-24 00:00:00','2015-04-24 00:00:00','1','0','0',NULL,NULL,NULL,NULL,NULL,'0');
INSERT INTO `rlb_relay_prog` VALUES ('7','dhiraj Test','0','1','0','02:00:00','02:30:00','2015-07-06 00:00:00','2015-07-13 12:50:40','0','0','1',NULL,NULL,'00:30:00','',NULL,'0');
INSERT INTO `rlb_relay_prog` VALUES ('8','Test','0','2','2,4,6','00:00:00','01:00:00','2015-07-09 07:31:37','0000-00-00 00:00:00','1','0','0',NULL,NULL,NULL,NULL,NULL,'0');
INSERT INTO `rlb_relay_prog` VALUES ('9','Test Relay 1','1','2','2,3,4','00:30:00','01:00:00','2015-07-09 08:38:46','2015-07-09 08:40:21','1','0','0',NULL,NULL,NULL,NULL,NULL,'0');
INSERT INTO `rlb_relay_prog` VALUES ('10','Program2','1','2','2,3','02:00:00','04:00:00','2015-07-09 09:05:11','2015-07-09 09:05:23','0','0','0',NULL,NULL,NULL,NULL,NULL,'0');
INSERT INTO `rlb_relay_prog` VALUES ('11','Test Relay Number','0','2','3','01:00:00','02:00:00','2015-07-09 11:41:53','2015-07-10 14:56:21','0','0','1',NULL,NULL,'01:00:00',NULL,NULL,'0');

/*---------------------------------------------------------------
  TABLE: `rlb_relays`
  ---------------------------------------------------------------*/
DROP TABLE IF EXISTS `rlb_relays`;
CREATE TABLE `rlb_relays` (
  `relay_id` int(11) NOT NULL AUTO_INCREMENT,
  `relay_number` int(11) NOT NULL,
  `relay_name` varchar(100) NOT NULL,
  PRIMARY KEY (`relay_id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;
INSERT INTO `rlb_relays` VALUES   ('1','0','Test Realy 1');
INSERT INTO `rlb_relays` VALUES ('2','2','Test for relay 2');
INSERT INTO `rlb_relays` VALUES ('3','3','Test for relay3 editedaf');
INSERT INTO `rlb_relays` VALUES ('4','5','rl5');
INSERT INTO `rlb_relays` VALUES ('5','10','relay 10');
INSERT INTO `rlb_relays` VALUES ('6','1','Test Relay 11111');

/*---------------------------------------------------------------
  TABLE: `rlb_run_after_heater`
  ---------------------------------------------------------------*/
DROP TABLE IF EXISTS `rlb_run_after_heater`;
CREATE TABLE `rlb_run_after_heater` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `heaterNumber` int(10) NOT NULL,
  `pumpNumber` int(10) NOT NULL,
  `heaterStopTime` datetime NOT NULL,
  `PumpStopTime` datetime NOT NULL,
  `ip_id` int(5) NOT NULL,
  `runComplete` enum('0','1') NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
INSERT INTO `rlb_run_after_heater` VALUES   ('1','0','1','2016-07-01 03:47:49','2016-07-01 03:52:49','1','1');
INSERT INTO `rlb_run_after_heater` VALUES ('2','1','1','2016-07-14 04:10:22','2016-07-14 04:15:22','1','1');

/*---------------------------------------------------------------
  TABLE: `rlb_setting`
  ---------------------------------------------------------------*/
DROP TABLE IF EXISTS `rlb_setting`;
CREATE TABLE `rlb_setting` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `ip_address` varchar(100) DEFAULT NULL,
  `port_no` varchar(100) DEFAULT NULL,
  `port_no_2` varchar(150) NOT NULL,
  `extra` text NOT NULL,
  `ip_external` varchar(150) NOT NULL,
  `old_ip` varchar(200) NOT NULL,
  `is_updated` enum('0','1') NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
INSERT INTO `rlb_setting` VALUES   ('1','192.168.0.103','13330','13331','a:23:{s:9:\"Pool_Temp\";s:1:\"1\";s:17:\"Pool_Temp_Address\";s:3:\"TS0\";s:8:\"Spa_Temp\";s:1:\"0\";s:16:\"Spa_Temp_Address\";s:0:\"\";s:11:\"PumpsNumber\";s:1:\"3\";s:11:\"ValveNumber\";s:1:\"6\";s:10:\"Remote_Spa\";s:1:\"1\";s:11:\"LightNumber\";s:1:\"1\";s:12:\"HeaterNumber\";s:1:\"2\";s:12:\"BlowerNumber\";s:1:\"1\";s:10:\"MiscNumber\";s:1:\"2\";s:18:\"Remote_Spa_display\";s:1:\"1\";s:12:\"PumpsNumber2\";s:1:\"1\";s:12:\"ValveNumber2\";s:1:\"6\";s:12:\"LightNumber2\";s:1:\"2\";s:13:\"HeaterNumber2\";s:1:\"1\";s:13:\"BlowerNumber2\";s:1:\"4\";s:11:\"MiscNumber2\";s:1:\"1\";s:11:\"Remote_Spa2\";s:1:\"0\";s:19:\"Remote_Spa_display2\";s:1:\"0\";s:8:\"SecondIP\";s:1:\"1\";s:15:\"showTemperature\";s:1:\"1\";s:16:\"showTemperature2\";s:1:\"1\";}','72.193.38.98','72.193.38.98','0');

/*---------------------------------------------------------------
  TABLE: `rlb_site_modules`
  ---------------------------------------------------------------*/
DROP TABLE IF EXISTS `rlb_site_modules`;
CREATE TABLE `rlb_site_modules` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `module_name` varchar(250) NOT NULL,
  `module_active` enum('0','1') NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=latin1;
INSERT INTO `rlb_site_modules` VALUES   ('2','24V AC Relay','1');
INSERT INTO `rlb_site_modules` VALUES ('3','12V DC Power Center Relay','1');
INSERT INTO `rlb_site_modules` VALUES ('4','Modes','1');
INSERT INTO `rlb_site_modules` VALUES ('5','Lights','1');
INSERT INTO `rlb_site_modules` VALUES ('6','Spa Devices','1');
INSERT INTO `rlb_site_modules` VALUES ('7','Pool Devices','1');
INSERT INTO `rlb_site_modules` VALUES ('8','Valve','1');
INSERT INTO `rlb_site_modules` VALUES ('9','Pump','1');
INSERT INTO `rlb_site_modules` VALUES ('10','Temperature Sensors','1');
INSERT INTO `rlb_site_modules` VALUES ('11','Input','1');
INSERT INTO `rlb_site_modules` VALUES ('12','Settings','1');
INSERT INTO `rlb_site_modules` VALUES ('13','Status','1');
INSERT INTO `rlb_site_modules` VALUES ('15','Log','1');
INSERT INTO `rlb_site_modules` VALUES ('16','Light','1');
INSERT INTO `rlb_site_modules` VALUES ('17','Heater','1');
INSERT INTO `rlb_site_modules` VALUES ('18','Pool and Spa','1');
INSERT INTO `rlb_site_modules` VALUES ('19','Blower','1');
INSERT INTO `rlb_site_modules` VALUES ('20','Miscellaneous','1');
INSERT INTO `rlb_site_modules` VALUES ('21','Advance Settings','1');

/*---------------------------------------------------------------
  TABLE: `rlb_valves`
  ---------------------------------------------------------------*/
DROP TABLE IF EXISTS `rlb_valves`;
CREATE TABLE `rlb_valves` (
  `valve_id` int(11) NOT NULL AUTO_INCREMENT,
  `valve_number` int(11) NOT NULL,
  `valve_name` varchar(100) NOT NULL,
  PRIMARY KEY (`valve_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
