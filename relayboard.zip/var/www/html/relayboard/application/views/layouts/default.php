<?php include_once('Header.php');?>
<?php echo $template['body']; ?>		
<?php include_once('Footer.php');?>	
