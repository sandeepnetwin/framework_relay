<?php
	
	/**
    * @Programmer: Dhiraj S.
    * @Created: 13 July 2015
    * @Modified: 
    * @Description: Home View for dashboard and device details.
    **/
	
	$strRole	=	'';
	if($this->session->userdata('user_type') == 'SA')
	{
		$strRole	=	'Super Admin';
	}
	else
	{
		$strRole	=	'Admin';
	}
	
	$sIPOptions	=	'';
	$iFirstIPId	=	'';	
	
	if($sBoard != '')
	{
		$iFirstIPId	=	$sBoard;	
	}
	
	
	if(!empty($aIPDetails))
	{
		foreach($aIPDetails as $aIP)
		{
			//First IP ID to show selected.
			if($iFirstIPId == '')
				$iFirstIPId = $aIP->id;
							
			$sDetails	=	$aIP->ip;
			if($aIP->name != '')
			{
				$sDetails .= ' ('.$aIP->name.')';
			}
			
			$sShow		=	'display:none';
			$sSelected	=	'';
			if($iFirstIPId == $aIP->id)
			{ 
				$sShow		=	'';
				$sSelected	=	'selected="selected"';
			} 
			
			$sIPOptions.='<option value="'.$aIP->id.'" '.$sSelected.'>'.$sDetails.'</option>';
		}
	}
	
?>
	<style>
	.fancybox-inner 
	{
		height:40px !important;
	}
	
	.custom-panel-heading
	{
		height : 132px !important;
	}
	
	.navbar-toggle {
		background-color: transparent !important;
		background-image: none !important;
		border: 1px solid transparent !important;
		border-radius: 4px !important;
		float: left !important;
		margin-bottom: 8px !important;
		margin-right: 15px !important;
		margin-top: 8px !important;
		padding: 9px 10px !important;
		position: relative !important;
	}
	
	.navbar-toggle .icon-bar {
		border-radius: 1px !important;
		display: block !important;
		height: 2px !important;
		width: 22px !important;
	}

	.clock {width:800px; margin:0 auto; padding:30px; border:1px solid #333; color:#fff; }

	#Date {  font-size:12px; text-align:center;  }
	/* text-shadow:0 0 5px #00c6ff; */

	.ulClock { margin:0 auto; padding:0px; list-style:none; text-align:center; }
	.ulClock > li { display:inline; font-size:22px; text-align:center; }

	/* text-shadow:0 0 5px #00c6ff; */

	#point { position:relative; -moz-animation:mymove 1s ease infinite; -webkit-animation:mymove 1s ease infinite; padding-left:2px; padding-right:2px; }

	@-webkit-keyframes mymove 
	{
	0% {opacity:1.0; text-shadow:0 0 20px #00c6ff;}
	50% {opacity:0; text-shadow:none; }
	100% {opacity:1.0; text-shadow:0 0 20px #00c6ff; }	
	}


	@-moz-keyframes mymove 
	{
	0% {opacity:1.0; text-shadow:0 0 20px #00c6ff;}
	50% {opacity:0; text-shadow:none; }
	100% {opacity:1.0; text-shadow:0 0 20px #00c6ff; }	
	}

	.deviceOff
	{
		color:#1A315F !important;
		font-size:38px !important;
	}
	.deviceOn
	{
		font-size:38px !important;
	}

	.customClock
	{
		float:right;
	}

	.customRole
	{
		text-align:left;
	}
	.customMessage
	{
		text-align:left;
	}

	@media (max-width:450px)
	{
		.customClock
		{
			float:left;
			margin-top:5px;
			margin-bottom:5px;
			width:100%;
		}
		.customRole
		{
			text-align:center;
		}
		.customMessage
		{
			text-align:center;
		}
	}
	@media (max-width:360px)
	{
		.tempName
		{
			width:60% !important;
		}
		
	}
	/* Remote Switch */
	.circle-container {
		position: relative;
		width: 22em;
		height: 22em;
		padding: 2.8em; /*= 2em * 1.4 (2em = half the width of an img, 1.4 = sqrt(2))*/
		border: dashed 1px;
		border-radius: 50%;
		margin: 1.75em auto 0;
	}
	.circle-container a {
		display: block;
		overflow: hidden;
		position: absolute;
		top: 50%; left: 50%;
		width: 10em; height: 5em;
		margin: -1em -2em -2em; /* 2em = 4em/2 */ /* half the width */
		
	}
	.circle-container img { display: block; width: 100%; }
	.deg0 { transform: translate(7em); } /* 12em = half the width of the wrapper */
	.deg45 { transform: rotate(90deg) translate(7em) rotate(-90deg); }
	.deg135 { transform: rotate(135deg) translate(12em) rotate(-135deg); }
	.deg180 { transform: translate(-7em); }
	.deg225 { transform: rotate(270deg) translate(7em) rotate(-270deg); }
	.deg315 { transform: rotate(315deg) translate(12em) rotate(-315deg); }

	@media (max-width:480px)
	{
		.circle-container 
		{
			position: relative;
			width: 16em !important;
			height: 16em !important;
			padding: 2.8em; /*= 2em * 1.4 (2em = half the width of an img, 1.4 = sqrt(2))*/
			border: dashed 1px;
			border-radius: 50%;
			margin: 1.75em auto 0;
		}
		.deg0 { transform: translate(5em); } 
		.deg45 { transform: rotate(90deg) translate(5em) rotate(-90deg); }
		.deg135 { transform: rotate(135deg) translate(12em) rotate(-135deg); }
		.deg180 { transform: translate(-5em); }
		.deg225 { transform: rotate(270deg) translate(6em) rotate(-270deg); }
		.deg315 { transform: rotate(315deg) translate(12em) rotate(-315deg); }
		
		.customPrice
		{
			width:100%;
		}
	}
	/* Remote Switch */

	</style>
	<script type="text/javascript" src="<?php echo HTTP_ASSETS_PATH.'fancybox/source/jquery.fancybox.js?v=2.1.5';?>"></script>
	<link rel="stylesheet" type="text/css" href="<?php echo HTTP_ASSETS_PATH.'fancybox/source/jquery.fancybox.css?v=2.1.5';?>" media="screen" />
	<script type="text/javascript">
	//var $a = $.noConflict();
	$(document).ready(function() {
		$('.fancybox').fancybox({'closeBtn' : false,'helpers': {'overlay' : {'closeClick': false}}
		});
	});
	</script>
	
<script type="text/javascript">
jQuery(document).ready(function() {
var cntOnPrograms 	= '<?php echo $cntOnPrograms;?>';
var confirmMessage = '';
// Create two variable with the names of the months and days in an array
var monthNames = [ "January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December" ]; 
var dayNames= ["Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"]

// Create a newDate() object
var newDate = new Date();
// Extract the current date from Date object
newDate.setDate(newDate.getDate());
// Output the day, date, month and year    
jQuery('#Date').html(dayNames[newDate.getDay()] + " " + newDate.getDate() + ' ' + monthNames[newDate.getMonth()] + ' ' + newDate.getFullYear());

	setInterval( function() {
	var IpId = $("#IpId").val();	
	jQuery.getJSON('<?php echo site_url('home/getCurrentServerTime/');?>', function(json) {
		//$("#clock1").html(json.time);
		var sTime			=	json.time;
		var aTimeDetails	=	sTime.split(':');
		jQuery("#hours_"+IpId).html(aTimeDetails[0]);
		jQuery("#min_"+IpId).html(aTimeDetails[1]);
		jQuery("#sec_"+IpId).html(aTimeDetails[2]);
	});
	},1000);
setInterval( function() {
	jQuery.getJSON('<?php echo site_url('home/getModeTime/');?>', function(json) {
		jQuery("#welcomeMessage").html(json.message);
	});
	},60000);

setInterval( function() {
	var IpId = $("#IpId").val();
	$.ajax({
				type: "POST",
                url: "<?php echo site_url('home/getAllDeviceStatus/');?>", 
                data: {IpId:IpId},
                success: function(data) {
					
					var obj = jQuery.parseJSON( data );
					var analog = obj.arrStatus;
					
					var strMode = '';
					if(obj.iActiveMode == '1') 
					{
						strMode = 'Pool Mode Auto';
					}
					else if(obj.iActiveMode == '2') 
					{
						strMode = 'Pool Mode Manual';
					}
					else if(obj.iActiveMode == '3') 
					{
						strMode = 'Time-out';
					}
					
					if(obj.welcome_message != '')
					{
						$(".welcomeMessageAjax").html(obj.welcome_message);
					}
					else
					{
						$(".welcomeMessageAjax").html('Welcome to Crystal Properties!');
					}
					
					$(".activeModeMini").html(strMode);
					
					$.each(analog, function(index,value){
						var strChk	=	'';
						if(value.status == '1')
							strChk	=	'class="checked"';
						
						$("#deviceInput"+index+"_"+IpId).html('<div class="custom-checkbox"><input type="checkbox" value="'+index+'|||'+value.device+'|||'+IpId+'" id="relay-'+index+'-'+IpId+'" name="relay-'+index+'" class="relayButton" hidefocus="true" style="outline: medium none;" onclick="onoffAnalog(this.value);"><label '+strChk+' id="lableRelay-'+index+'-'+IpId+'" for="relay-'+index+'-'+IpId+'"></label></div>');
						
						$("#deviceInputName"+index+"_"+IpId).html(value.name);
						
						strChk	=	'';
					});
					//24V AC Relays Status
					$("#deviceTotalRelays_"+IpId).html('Total : '+obj.relay_count);
					$("#deviceActiveRelays_"+IpId).html('Active : '+obj.activeCountRelay);
					$("#deviceOnRelays_"+IpId).html('ON : '+obj.OnCountRelay);
					$("#deviceOffRelays_"+IpId).html('OFF : '+obj.OFFCountRelay);
					
					//12V DC Relays Status
					$("#deviceTotalPower_"+IpId).html('Total : '+obj.power_count);
					//$("#deviceActivePower").html('Active : '+obj.activeCountRelay);
					$("#deviceOnPower_"+IpId).html('ON : '+obj.OnCountPower);
					$("#deviceOffPower_"+IpId).html('OFF : '+obj.OFFCountPower);
					
					//Valve Status
					$("#deviceTotalValve_"+IpId).html('Total : '+obj.valve_count);
					$("#deviceActiveValve_"+IpId).html('Active : '+obj.activeCountValve);
					$("#deviceOnValve_"+IpId).html('ON : '+obj.OnCountValve);
					$("#deviceOffValve_"+IpId).html('OFF : '+obj.OFFCountValve);
					
					//Pump Status
					$("#deviceTotalPump_"+IpId).html('Total : '+obj.pump_count);
					$("#deviceActivePump_"+IpId).html('Active : '+obj.activeCountPump);
					$("#deviceOnPump_"+IpId).html('ON : '+obj.OnCountPump);
					$("#deviceOffPump_"+IpId).html('OFF : '+obj.OFFCountPump);
					
					//Temperature Status
					$("#deviceTotalTemp_"+IpId).html('Total : '+obj.temprature_count);
					$("#deviceActiveTemp_"+IpId).html('Active : '+obj.activeCountTemperature);
					
					//Temperature Block
					$("#temperatureblock_"+IpId).html(obj.tempDetails);
				}
		});
	
	},30000); 	

	$(".relayButton").click(function()
	{
		var iActiveMode = $("#hidActiveMode").val();
		var chkConfirm = true;
		if(cntOnPrograms >= 1 || iActiveMode == 1)
		{
			if(confirmMessage != '1')
			{
				chkConfirm = confirm("Are you sure you want to make this device ON/OFF?\nThis will stop all Custom Programs/Programs running in background!");
				confirmMessage	=	'1';
			}
		}
		
		if(chkConfirm)
		{
			if(iActiveMode != 3)
			{
				if(iActiveMode != 2)
				{
					changeModeToManual();
				}
				
				var clkVal		=	$(this).val();
				var aDetails	=	clkVal.split('|||');
				
				var input		=	aDetails[0];
				var device		=	aDetails[1];
				var ipID		=	aDetails[2];
				var status		=	'';
				
				if($("#lableRelay-"+input+"-"+ipID).hasClass('checked'))
				{	
					status	=	0;
					$("#lableRelay-"+input+"-"+ipID).removeClass('checked');
				}
				else
				{
					status = 1;
					$("#lableRelay-"+input+"-"+ipID).addClass('checked');
				}
				
				$.ajax({
						type: "POST",
						url: "<?php echo site_url('home/makeInputDeviceOnOff');?>", 
						data: {input:input,device:device,status:status,sIdIP:ipID},
						success: function(data) 
						{
							/* if($("#lableRelay-"+input+"-"+ipID).hasClass('checked'))
							{	
								$("#lableRelay-"+input+"-"+ipID).removeClass('checked');
							}
							else
							{
								$("#lableRelay-"+input+"-"+ipID).addClass('checked');
							} */
						}
				}); 
			}
		}
	});
});

function changeModeToManual()
{
	$.ajax({
				type: "POST",
				url: "<?php echo site_url('analog/changeMode');?>", 
				data: {iMode:'2'},
				success: function(data) {
					$("#hidActiveMode").val('2');
				}
		   });
} 

function onoffAnalog(clkVal)
{
	var iActiveMode = $("#hidActiveMode").val();
	var chkConfirm = true;
	if(cntOnPrograms >= 1 || iActiveMode == 1)
	{
		if(confirmMessage != '1')
		{
			chkConfirm = confirm("Are you sure you want to make this device ON/OFF?\nThis will stop all Custom Programs/Programs running in background!");
			confirmMessage	=	'1';
		}
	}
	
	if(chkConfirm)
	{
		if(iActiveMode != 3)
		{
			if(iActiveMode != 2)
			{
				changeModeToManual();
			}
			var aDetails	=	clkVal.split('|||');
			
			var input		=	aDetails[0];
			var device		=	aDetails[1];
			var ipID		=	aDetails[2];
			var status		=	'';
			
			if($("#lableRelay-"+input+"-"+ipID).hasClass('checked'))
			{	
				status	=	0;
				$("#lableRelay-"+input+"-"+ipID).removeClass('checked');
			}
			else
			{
				status = 1;
				$("#lableRelay-"+input+"-"+ipID).addClass('checked');
			}
			
			$.ajax({
					type: "POST",
					async:false,
					url: "<?php echo site_url('home/makeInputDeviceOnOff');?>", 
					data: {input:input,device:device,status:status,sIdIP:ipID},
					success: function(data) 
					{}
			});
		}
	}
}
function showBoardDetails(board)
{
	if(board == '')
	{
		alert("Please select IP first!");
		return false;
	}
	
	$("#checkLink").trigger('click'); 
			
	$("#IpId").val(board);
	
	var IpId = $("#IpId").val();
	location.href='<?php echo base_url('home/index');?>'+'/'+Base64.encode(IpId);
}
</script>
<div class="row">
	<div class="col-sm-12">
	<span style="color:#FFF; font-weight:bold;">Select Board : </span>
	<select name="selPort" id="selPort" onchange="showBoardDetails(this.value)">
		<option value="">--IP(Name)--</option>
		<?php echo $sIPOptions;?>
	</select>	
	</div>
</div>
<div class="row">
	<div class="col-sm-12">
	&nbsp;
	</div>
</div>
<input type="hidden" id="hidActiveMode" value="<?php echo $iActiveMode;?>">	

<?php
	if(!empty($aIPDetails))
	{
		foreach($aIPDetails as $aIP)
		{
			if($aIP->id == 1)
			$showTemperature = $extraDetails['showTemperature'];
			else 
			$showTemperature = $extraDetails['showTemperature2'];
		
			$sTempratureDetails = '';
			if($showTemperature == '1')
			{
				foreach(${"Temperature".$aIP->id} as $i => $Temperature)
				{
					$sTempratureShow =  $this->home_model->getDeviceShowOnDashboard($i,'T',$aIP->id);
					
					if($sTempratureShow == '1')
					{
						//If temperature is in Celcius convert it to Fahrenheit.
						if(preg_match('/C/',$Temperature))
						{
							$Temperature = str_replace('C','',$Temperature);
							$Temperature = celciustofahrenheit($Temperature).'F';
						}
						//Get Name
						$sName =  $this->home_model->getDeviceName($i,'T',$aIP->id);
						
						if($sName == '')
							$sName = 'Temperature Sensor '.$i;
						if($Temperature != '' && $Temperature > 0)
							$sTempratureDetails .= '<span style="float:left" class="tempName">'.$sName.'</span><span style="float:right">'.$Temperature.'</span>'.'<br>';
					}
				}
			}
			
	?>
<div class="row" id="remotebuttons_<?php echo $aIP->id;?>" style="display:<?php if($aIP->id != $iFirstIPId){ echo 'none';} ?>">	
<?php if(${"Remote_Spa_display".$aIP->id} == 1) { ?>
	<div class="col-sm-6">
		<div class="tab-pane fade in active" id="remote">
			<?php
				
				$iResultCnt =   count(${"aAPResult".$aIP->id});
				$arrStatus	=	array();
				
				for($i=0; $i<$iResultCnt; $i++)
				{
					if(${"aAPResult".$aIP->id}[$i] != '')
					{
						//Get port number of each remote switch.
						$arrStatus[$i]['port'] =	$this->home_model->getAnalogDevicePorts($i);
					
						$arrStatus[$i]['device']	=	${"aAPResult".$aIP->id}[$i];
						$aDevice = explode('_',${"aAPResult".$aIP->id}[$i]);
						
						
						if($aDevice[1] != '')
						{
							if($aDevice[1] == 'R')
							{
								if(${"sRelays".$aIP->id}[$aDevice[0]] != '' && ${"sRelays".$aIP->id}[$aDevice[0]] != '.')
								{
									
									$arrStatus[$i]['status']	=	${"sRelays".$aIP->id}[$aDevice[0]];
									$arrStatus[$i]['name']		=	$this->home_model->getDeviceName($aDevice[0],'R',$aIP->id);
									if($arrStatus[$i]['name'] == '')
										$arrStatus[$i]['name'] = 'Relay '.$aDevice[0];
									
								}
								//exex('rlb m 0 2 1');
							}
							if($aDevice[1] == 'P')
							{
								$arrStatus[$i]['status']	=	${"sPowercenter".$aIP->id}[$aDevice[0]];
								$arrStatus[$i]['name']		=	$this->home_model->getDeviceName($aDevice[0],'P',$aIP->id);
								
								if($arrStatus[$i]['name'] == '')
										$arrStatus[$i]['name'] = 'PowerCenter'.$aDevice[0];
							}
							if($aDevice[1] == 'V')
							{
								if(${"sValves".$aIP->id}[$aDevice[0]] != '' && ${"sValves".$aIP->id}[$aDevice[0]] != '.')
								{
									$arrStatus[$i]['status']	=	${"sValves".$aIP->id}[$aDevice[0]];
									$arrStatus[$i]['name']		=	$this->home_model->getDeviceName($aDevice[0],'V',$aIP->id);
									if($arrStatus[$i]['name'] == '')
										$arrStatus[$i]['name'] = 'Valve '.$aDevice[0];
								}
							}
							if($aDevice[1] == 'PS')
							{
								$arrStatus[$i]['status']	=	${"sPump".$aIP->id}[$aDevice[0]];
								$arrStatus[$i]['name']		=	$this->home_model->getDeviceName($aDevice[0],'PS',$aIP->id);
								if($arrStatus[$i]['name'] == '')
									$arrStatus[$i]['name'] = 'Pump '.$aDevice[0];
							}
							if($aDevice[1] == 'B')
							{
								$arrStatus[$i]['status']	=	0;
								$aBlowerDetails  =   $this->home_model->getBlowerDeviceDetails($aDevice[0],$aIP->id);
								if(!empty($aBlowerDetails))
								{
									foreach($aBlowerDetails as $aBlower)
									{
										$sBlowerStatus	=	'';
										$sRelayDetails  =   unserialize($aBlower->light_relay_number);
										
										//Blower Operated Type and Relay
										$sRelayType     =   $sRelayDetails['sRelayType'];
										$sRelayNumber   =   $sRelayDetails['sRelayNumber'];
										
										if($sRelayType == '24')
										{
											$sBlowerStatus   =   ${"sRelays".$aIP->id}[$sRelayNumber];
										}
										if($sRelayType == '12')
										{
											$sBlowerStatus   =   ${"sPowercenter".$aIP->id}[$sRelayNumber];
										}
									
										$arrStatus[$i]['status'] = $sBlowerStatus;
									}
								}
								$arrStatus[$i]['name']		=	$this->home_model->getDeviceName($aDevice[0],'B',$aIP->id);
								if($arrStatus[$i]['name'] == '')
									$arrStatus[$i]['name'] = 'Blower '.$aDevice[0];
							}
							if($aDevice[1] == 'L')
							{
								$arrStatus[$i]['status']	=	0;
								$aLightDetails  =   $this->home_model->getLightDeviceDetails($aDevice[0],$aIP->id);
								if(!empty($aLightDetails))
								{
									foreach($aLightDetails as $aLight)
									{
										$sLightStatus	=	'';
										$sRelayDetails  =   unserialize($aLight->light_relay_number);
										
										//Blower Operated Type and Relay
										$sRelayType     =   $sRelayDetails['sRelayType'];
										$sRelayNumber   =   $sRelayDetails['sRelayNumber'];
										
										if($sRelayType == '24')
										{
											$sLightStatus   =   ${"sRelays".$aIP->id}[$sRelayNumber];
										}
										if($sRelayType == '12')
										{
											$sLightStatus   =   ${"sPowercenter".$aIP->id}[$sRelayNumber];
										}
									
										$arrStatus[$i]['status'] = $sLightStatus;
									}
								}
								$arrStatus[$i]['name']		=	$this->home_model->getDeviceName($aDevice[0],'L',$aIP->id);
								if($arrStatus[$i]['name'] == '')
									$arrStatus[$i]['name'] = 'Light '.$aDevice[0];
							}
							if($aDevice[1] == 'H')
							{
								$arrStatus[$i]['status']	=	0;
								$aHeaterDetails  =   $this->home_model->getHeaterDeviceDetails($aDevice[0],$aIP->id);
								if(!empty($aHeaterDetails))
								{
									foreach($aHeaterDetails as $aHeater)
									{
										$sHeaterStatus	=	'';
										$sRelayDetails  =   unserialize($aHeater->light_relay_number);
										
										//Blower Operated Type and Relay
										$sRelayType     =   $sRelayDetails['sRelayType'];
										$sRelayNumber   =   $sRelayDetails['sRelayNumber'];
										
										if($sRelayType == '24')
										{
											$sHeaterStatus   =   ${"sRelays".$aIP->id}[$sRelayNumber];
										}
										if($sRelayType == '12')
										{
											$sHeaterStatus   =   ${"sPowercenter".$aIP->id}[$sRelayNumber];
										}
									
										$arrStatus[$i]['status'] = $sHeaterStatus;
									}
								}
								
								$arrStatus[$i]['name']		=	$this->home_model->getDeviceName($aDevice[0],'H',$aIP->id);
								if($arrStatus[$i]['name'] == '')
									$arrStatus[$i]['name'] = 'Heater '.$aDevice[0];
							}
							if($aDevice[1] == 'M')
							{
								$arrStatus[$i]['status']	=	0;
								$aMiscDetails  =   $this->home_model->getMiscDeviceDetails($aDevice[0],$aIP->id);
								if(!empty($aMiscDetails))
								{
									foreach($aMiscDetails as $aMisc)
									{
										$sMiscStatus	=	'';
										$sRelayDetails  =   unserialize($aMisc->light_relay_number);
										
										//Blower Operated Type and Relay
										$sRelayType     =   $sRelayDetails['sRelayType'];
										$sRelayNumber   =   $sRelayDetails['sRelayNumber'];
										
										if($sRelayType == '24')
										{
											$sMiscStatus   =   ${"sRelays".$aIP->id}[$sRelayNumber];
										}
										if($sRelayType == '12')
										{
											$sMiscStatus   =   ${"sPowercenter".$aIP->id}[$sRelayNumber];
										}
									
										$arrStatus[$i]['status'] = $sMiscStatus;
									}
								}
								
								$arrStatus[$i]['name']		=	$this->home_model->getDeviceName($aDevice[0],'M',$aIP->id);
								if($arrStatus[$i]['name'] == '')
									$arrStatus[$i]['name'] = 'Misc '.$aDevice[0];
							}
							
						}
					}
				}
			?>
			<!-- content to be placed inside <body>…</body> -->
			<div class="controls boxed" style="min-height:210px;">
				<div style="text-align:center;">
					<h3 class="profile-title"><strong style="color:#9CD70E;">Remote Switch</strong></h3>
					<div class='circle-container'>
						
						<a href="javascript:void(0);" class='deg225' >
							
							<div class="rowCheckbox switch" id="deviceInput0_<?php echo $aIP->id;?>">
								<div class="custom-checkbox"><input type="checkbox" value="0|||<?php echo $arrStatus[0]['device'];?>|||<?php echo $aIP->id;?>" id="relay-0-<?php echo $aIP->id;?>" name="relay-0" class="relayButton" hidefocus="true" style="outline: medium none;">
								<label <?php if($arrStatus[0]['status']){ echo 'class="checked"';}?> id="lableRelay-0-<?php echo $aIP->id;?>" for="relay-0-<?php echo $aIP->id;?>"></label>
								</div>
							</div>
						
						</a>
						<a class="deg225" style="margin-top: 15px; margin-left: -60px;"><span id="deviceInputName0_<?php echo $aIP->id;?>"><?php echo $arrStatus[0]['name'];?></span></a>
						
						<a href="javascript:void(0);" class="deg0" style="margin-left:-30px;">
						
							<div class="rowCheckbox switch" id="deviceInput1_<?php echo $aIP->id;?>">
								<div class="custom-checkbox"><input type="checkbox" value="1|||<?php echo $arrStatus[1]['device'];?>|||<?php echo $aIP->id;?>" id="relay-1-<?php echo $aIP->id;?>" name="relay-1-<?php echo $aIP->id;?>" class="relayButton" hidefocus="true" style="outline: medium none;">
									<label <?php if($arrStatus[1]['status']){ echo 'class="checked"';}?> id="lableRelay-1-<?php echo $aIP->id;?>" for="relay-1-<?php echo $aIP->id;?>"></label>
								</div>
							</div>
						
						</a>
						<a class="deg0" style="margin-top: 15px; margin-left: -70px;"><span id="deviceInputName1_<?php echo $aIP->id;?>"><?php echo $arrStatus[1]['name'];?></span></a>
						
						<a href="javascript:void(0);" class='deg45' >
						
							<div class="rowCheckbox switch" id="deviceInput2_<?php echo $aIP->id;?>">
								<div class="custom-checkbox"><input type="checkbox" value="2|||<?php echo $arrStatus[2]['device'];?>|||<?php echo $aIP->id;?>" id="relay-2-<?php echo $aIP->id;?>" name="relay-2-<?php echo $aIP->id;?>" class="relayButton" hidefocus="true" style="outline: medium none;">
									<label <?php if($arrStatus[2]['status']){ echo 'class="checked"';}?> id="lableRelay-2-<?php echo $aIP->id;?>" for="relay-2-<?php echo $aIP->id;?>"></label>
								</div>
							</div>
						
						</a>
						<a class="deg45" style="margin-top: 15px; margin-left: -60px;"><span id="deviceInputName2_<?php echo $aIP->id;?>"><?php echo $arrStatus[2]['name'];?></span></a>
						
						<a href="javascript:void(0);" class='deg180'>
						
							<div class="rowCheckbox switch" id="deviceInput3_<?php echo $aIP->id;?>">
								<div class="custom-checkbox"><input type="checkbox" value="3|||<?php echo $arrStatus[3]['device'];?>|||-<?php echo $aIP->id;?>" id="relay-3-<?php echo $aIP->id;?>" name="relay-3-<?php echo $aIP->id;?>" class="relayButton" hidefocus="true" style="outline: medium none;">
									<label <?php if($arrStatus[3]['status']){ echo 'class="checked"';}?> id="lableRelay-3-<?php echo $aIP->id;?>" for="relay-3-<?php echo $aIP->id;?>"></label>
								</div>
							</div>
						
						</a>
						<a class="deg180" style="margin-top: 15px; margin-left: -60px;"><span id="deviceInputName3_<?php echo $aIP->id;?>"><?php echo $arrStatus[3]['name'];?></span></a>
					</div>
				</div>
			</div>
		</div>
	</div>
	<div class="col-sm-6">
	<!-- Profile -->
		<div class="controls boxed blue-line" style="min-height:150px;">
			<div class="inner">
				<h5 class="profile-title customRole"><strong><?php echo $this->session->userdata('username');?></strong>&nbsp;(Role : <?php echo $strRole;?>)
				<div class="customClock"><div id="Date"></div><span class="profile-subtitle" style="font-style:normal; color:#1D4B72;">	
					<ul class="ulClock" style="margin-top:-5px;">
						<li id="hours_<?php echo $aIP->id;?>" class="liClock"> </li>
						<li id="point" class="liClock">:</li>
						<li id="min_<?php echo $aIP->id;?>" class="liClock"> </li>
						<li id="point" class="liClock">:</li>
						<li id="sec_<?php echo $aIP->id;?>" class="liClock"> </li>
					</ul>
				</span>	</div></h5>
				<div class="comment-text customMessage">
					<div class="comment-author"><a href="#" style="border-bottom: 1px solid #d0dbe7;color: #164c87;display: inline-block;float: none;font-size: 22px;  padding-bottom: 10px;">System Message</a></div>
					<div class="comment-entry welcomeMessageAjax" style="font-size: 12px;line-height: 16px;"><?php if($welcome_message == '' ){ echo 'Welcome to Crystal Properties!'; } else { echo $welcome_message;} ?></div>
				</div>
			</div>
		</div>
		<?php 
				
			  $strTempUrl	=	'onClick="location.href=\''.base_url('home/setting/T/').'\'"'; 	
			  if(!empty($aModules))
			  {
				if(!in_array(10,$aModules->ids)) 
				{
					$strTempUrl = 'onClick="showRestrict();"'; 
				} 
			  }
			  
		?>
		<div class="controls boxed blue-line" style="min-height:161px; <?php if($showTemperature != '1') { echo 'display:none;';}?>">
			<div class="inner">
				<h3 class="profile-title"><strong style="color:#9CD70E;">Temperature</strong></h3>
				<span class="price-title" id="temperatureblock_<?php echo $aIP->id;?>"><strong><?php echo $sTempratureDetails;?></strong></span>
				<div class="price-bottom clearfix" style="margin-top:25px;"><a href="#" hidefocus="true" style="outline: medium none;">
						</a><a class="price-reserve" <?php echo $strTempUrl;?> href="javascript:void(0);" hidefocus="true" style="outline: medium none; font-size:13px;">Temperature Sensors</a>
					</div>
			</div>
		</div>
		<!--/ Profile -->
	</div>
	<?php } else if(${"Remote_Spa_display".$aIP->id} == 0) { ?>
	
	<div class="col-sm-<?php if($showTemperature == '1') { echo '6';} else { echo '12';}?>">
		<div class="controls boxed blue-line" style="min-height:150px;">
			<div class="inner">
				<h5 class="profile-title customRole"><strong><?php echo $this->session->userdata('username');?></strong>&nbsp;(Role : <?php echo $strRole;?>)
				<div class="customClock"><div id="Date"></div><span class="profile-subtitle" style="font-style:normal; color:#1D4B72;">	
					<ul class="ulClock" style="margin-top:-5px;">
						<li id="hours_<?php echo $aIP->id;?>" class="liClock"> </li>
						<li id="point" class="liClock">:</li>
						<li id="min_<?php echo $aIP->id;?>" class="liClock"> </li>
						<li id="point" class="liClock">:</li>
						<li id="sec_<?php echo $aIP->id;?>" class="liClock"> </li>
					</ul>
				</span>	</div></h5>
				<div class="comment-text customMessage">
					<div class="comment-author"><a href="#" style="border-bottom: 1px solid #d0dbe7;color: #164c87;display: inline-block;float: none;font-size: 22px;  padding-bottom: 10px;">System Message</a></div>
					<div class="comment-entry welcomeMessageAjax" style="font-size: 12px;line-height: 16px;"><?php if($welcome_message == '' ){ echo 'Welcome to Crystal Properties!'; } else { echo $welcome_message;} ?></div>
				</div>
			</div>
		</div>
	</div>
	<?php if($showTemperature == '1') { ?>
		<?php 
				
			  $strTempUrl	=	'onClick="location.href=\''.base_url('home/setting/T/').'\'"'; 	
			  if(!empty($aModules))
			  {
				if(!in_array(10,$aModules->ids)) 
				{
					$strTempUrl = 'onClick="showRestrict();"'; 
				} 
			  }
			  
		?>
		<div class="col-sm-6" >
			<div class="controls boxed blue-line" style="min-height:161px;">
				<div class="inner">
					<h3 class="profile-title"><strong style="color:#9CD70E;">Temperature</strong></h3>
					<span class="price-title" id="temperatureblock_<?php echo $aIP->id;?>"><strong><?php echo $sTempratureDetails;?></strong></span>
					<div class="price-bottom clearfix" style="margin-top:25px;"><a href="#" hidefocus="true" style="outline: medium none;">
							</a><a class="price-reserve" <?php echo $strTempUrl;?> href="javascript:void(0);" hidefocus="true" style="outline: medium none; font-size:13px;">Temperature Sensors</a>
					</div>
				</div>
			</div>
		</div>
	<?php } ?>
	<?php } ?>
	</div>
<?php 	} 
	}?>		


<!-- row Level 2 -->
<div class="row">
	<!-- Tabs -->
	<?php
	if(!empty($aIPDetails))
	{
		foreach($aIPDetails as $aIP)
		{
	
	?>	
	<div class="col-sm-8" id="IpDeviceTab_<?php echo $aIP->id;?>" style="display:<?php if($iFirstIPId != $aIP->id){ echo 'none';}?>">
		<div class="tabs-framed tabs-small boxed green-line">
			<ul class="tabs clearfix">
				<li class="active"><a href="#24VAC<?php echo $aIP->id;?>" data-toggle="tab">Switches</a></li>
				<li><a href="#Valve<?php echo $aIP->id;?>" data-toggle="tab">Valves</a></li>
				<li><a href="#Pump<?php echo $aIP->id;?>" data-toggle="tab">Pumps</a></li>
				<li><a href="#Temperature<?php echo $aIP->id;?>" data-toggle="tab">Temperature</a></li>
			</ul>
			<div class="tab-content">
				<div class="tab-pane fade in active" id="24VAC<?php echo $aIP->id;?>">
					<!-- Price item -->
					<?php 
							$strRelayUrl	=	'onClick="location.href=\''.base_url('home/setting/R/').'\'"'; 	
							if(!empty($aModules))
							{
								if(!in_array(2,$aModules->ids)) 
								{
									$strRelayUrl = 'onClick="showRestrict();"'; 
								} 
							}
							  
							$strPowerUrl	=	'onClick="location.href=\''.base_url('home/setting/P/').'\'"'; 	
							if(!empty($aModules))
							{
								if(!in_array(3,$aModules->ids)) 
								{
									$strPowerUrl = 'onClick="showRestrict();"'; 
								} 
							}
						?>
					<div class="price-item style4">
						<div class="price-content clearfix">
							<div class="price-content-left">
								<div class="price-image">
									<img src="<?php echo HTTP_IMAGES_PATH;?>temp/rlb.jpg" alt="" />
								</div>
							</div>
							<div class="price-content-right">
								<h2 class="price-title">
								<p>24V AC Relays<span class="price-info" style="cursor:pointer; float:right;" <?php echo $strRelayUrl;?> >Configure</span></p>
								<a href="#"><span id="deviceTotalRelays_<?php echo $aIP->id;?>" style="color:#1A315F;font-size:19px;" >Total : <?php echo ${"relay_count".$aIP->id};?></span></a>&nbsp;&nbsp;<a href="#"><span style="color:#9CD70E;font-size:19px;" id="deviceActiveRelays_<?php echo $aIP->id;?>">Active : <?php echo ${"activeCountRelay".$aIP->id};?></span></h2>
								<div class="price clearfix">
									<strong style="font-size:34px;" id="deviceOnRelays_<?php echo $aIP->id;?>">ON : <?php echo ${"OnCountRelay".$aIP->id};?></strong><strong style="color:#1A315F; margin-left:10px;font-size:34px;" id="deviceOffRelays_<?php echo $aIP->id;?>">OFF : <?php echo ${"OFFCountRelay".$aIP->id};?></strong>
								</div>
								<div class="price-desc"></div>
								
								<h2 class="price-title"><p>12V DC Relays<span class="price-info" style="cursor:pointer; float:right;" <?php echo $strPowerUrl;?> >Configure</span></p><a href="#"><span style="color:#1A315F;font-size:19px;" id="deviceTotalPower_<?php echo $aIP->id;?>">Total : <?php echo ${"power_count".$aIP->id};?></span></a>&nbsp;&nbsp;<a href="#"><span style="color:#9CD70E;font-size:19px;" id="deviceActivePower_<?php echo $aIP->id;?>">Active : <?php echo 8?></span></h2>
								
								<div class="price clearfix">
									<strong style="font-size:34px;" id="deviceOnPower_<?php echo $aIP->id;?>">ON : <?php echo ${"OnCountPower".$aIP->id};?></strong><strong style="color:#1A315F; margin-left:10px;font-size:34px;" id="deviceOffPower_<?php echo $aIP->id;?>">OFF : <?php echo ${"OFFCountPower".$aIP->id};?></strong>
								</div>
							</div>
						</div>
						
						<div class="price-bottom clearfix">
							
							<a href="javascript:void(0);" <?php echo $strRelayUrl;?> class="price-reserve customPrice" style="float:left;">Switch ON/OFF 24V AC Relays</a>&nbsp;&nbsp;
							<a href="javascript:void(0);" <?php echo $strPowerUrl;?> class="price-reserve customPrice">Switch ON/OFF 12V DC Relays</a>
						</div>
					</div>
					<!--/ Price item -->
				</div>
				
				<div class="tab-pane fade in" id="Valve<?php echo $aIP->id;?>">
					<!-- Price item -->
					<div class="price-item style4">
						<div class="price-content clearfix">
							<div class="price-content-left">
								<div class="price-image">
									<img src="<?php echo HTTP_IMAGES_PATH;?>temp/left_valve.png" alt="" />
								</div>
							</div>
							<div class="price-content-right">
								<h2 class="price-title"><a href="#"><span style="color:#1A315F" id="deviceTotalValve_<?php echo $aIP->id;?>">Total : <?php echo ${"valve_count".$aIP->id};?></span></a>&nbsp;&nbsp;&nbsp;&nbsp;<a href="#"><span style="color:#9CD70E;" id="deviceActiveValve_<?php echo $aIP->id;?>">Active : <?php echo ${"activeCountValve".$aIP->id}?></span></h2>
								<div class="price-desc">
								
								</div>
								<div class="price clearfix">
									<strong class="deviceOn" id="deviceOnValve_<?php echo $aIP->id;?>">ON : <?php echo ${"OnCountValve".$aIP->id}?></strong>
									<strong class="deviceOff" id="deviceOffValve_<?php echo $aIP->id;?>">OFF : <?php echo ${"OFFCountValve".$aIP->id}?></strong>
								</div>
							</div>
						</div>
						<?php 
									
								  $strValveUrl	=	'onClick="location.href=\''.base_url('home/setting/V/').'\'"'; 	
								  if(!empty($aModules))
								  {
									if(!in_array(8,$aModules->ids)) 
									{
										$strValveUrl = 'onClick="showRestrict();"'; 
									} 
								  }
								  
							?>
						<div class="price-bottom clearfix">
							<span class="price-info" style="cursor:pointer;" <?php echo $strValveUrl;?>>Configure</span>
							<a <?php echo $strValveUrl;?> href="javascript:void(0);" class="price-reserve">Switch ON/OFF</a>
						</div>
					</div>
					<!--/ Price item -->
				</div>
				
				<div class="tab-pane fade in" id="Pump<?php echo $aIP->id;?>">
					<!-- Price item -->
					<div class="price-item style4">
						<div class="price-content clearfix">
							<div class="price-content-left">
								<div class="price-image">
									<img src="<?php echo HTTP_IMAGES_PATH;?>temp/motor_image.png" alt="" />
								</div>
							</div>
							<div class="price-content-right">
								<h2 class="price-title"><a href="#"><span style="color:#1A315F" id="deviceTotalPump_<?php echo $aIP->id;?>">Total : <?php echo ${"pump_count".$aIP->id};?></span></a>&nbsp;&nbsp;&nbsp;&nbsp;<a href="#"><span style="color:#9CD70E;" id="deviceActivePump_<?php echo $aIP->id;?>">Active : <?php echo $activeCountPump;?></span></h2>
								<div class="price-desc">
								
								</div>
								<div class="price clearfix">
									<strong class="deviceOn" id="deviceOnPump_<?php echo $aIP->id;?>" >ON : <?php echo $OnCountPump?></strong>
									<strong class="deviceOff" id="deviceOffPump_<?php echo $aIP->id;?>">OFF : <?php echo $OFFCountPump?></strong>
								</div>
							</div>
						</div>
						<?php 
									
								  $strPumpUrl	=	'onClick="location.href=\''.base_url('home/setting/PS/').'\'"'; 	
								  if(!empty($aModules))
								  {
									if(!in_array(9,$aModules->ids)) 
									{
										$strPumpUrl = 'onClick="showRestrict();"'; 
									} 
								  }
								  
							?>
						<div class="price-bottom clearfix">
							<span class="price-info" style="cursor:pointer;" <?php echo $strPumpUrl;?>>Configure</span>
							<a <?php echo $strPumpUrl;?> href="javascript:void(0);" class="price-reserve">Switch ON/OFF</a>
						</div>
					</div>
					<!--/ Price item -->
				</div>
				
				<div class="tab-pane fade in" id="Temperature<?php echo $aIP->id;?>">
					<!-- Price item -->
					<div class="price-item style4">
						<div class="price-content clearfix">
							<div class="price-content-left">
								<div class="price-image">
									<img src="<?php echo HTTP_IMAGES_PATH;?>temp/rlb.jpg" alt="" />
								</div>
							</div>
							<div class="price-content-right">
								<h2 class="price-title"><a href="#"><span style="color:#1A315F" id="deviceTotalTemp_<?php echo $aIP->id;?>">Total : <?php echo ${"temprature_count".$aIP->id};?></span></a>&nbsp;&nbsp;&nbsp;&nbsp;<a href="#"><span style="color:#9CD70E;" id="deviceActiveTemp_<?php echo $aIP->id;?>">Active : <?php echo ${"activeCountTemperature".$aIP->id};?></span></h2>
							</div>
						</div>
						<?php 
									
								  $strTempUrl	=	'onClick="location.href=\''.base_url('home/setting/T/').'\'"'; 	
								  if(!empty($aModules))
								  {
									if(!in_array(10,$aModules->ids)) 
									{
										$strTempUrl = 'onClick="showRestrict();"'; 
									} 
								  }
								  
							?>
						<div class="price-bottom clearfix">
							<span class="price-info" style="cursor:pointer;" <?php echo $strTempUrl;?>>Configure</span>
							<a <?php echo $strTempUrl;?> href="javascript:void(0);" class="price-reserve">Temperature Sensors</a>
						</div>
					</div>
					<!--/ Price item -->
				</div>
			</div>
		</div>
	</div>
	<!--/ Tabs -->
<?php 	}
	}
?>
	<div class="col-sm-4">
		<!-- Ribbons -->
		<div class="ribbons boxed blue-line">
			<?php 
								
				  $strModeUrl	= 'href="'.base_url('analog/changeModeManual').'"'; 
				  $strSpaUrl	= 'href="'.base_url('home/SpaDevice/').'"';
				  $strPoolUrl	= 'href="'.base_url('home/PoolDevice/').'"'; 
				  $strLightUrl	= 'href="'.base_url('analog/showLight').'"'	;			  
				  
				  $strUserUrl	= 'href="'.base_url('dashboard/users/').'"'; 
				  $strModuleUrl	= 'href="'.base_url('dashboard/module/').'"';
				  $strInputUrl	= 'href="'.base_url('analog/').'"';	

				  if(!empty($aModules))
				  {
					if(!in_array(4,$aModules->ids)) 
					{
						$strModeUrl = 'href="javascript:void(0);" onClick="showRestrict();"'; 
					} 
					if(!in_array(6,$aModules->ids)) 
					{
						$strSpaUrl = 'href="javascript:void(0);" onClick="showRestrict();"'; 
					}
					if(!in_array(7,$aModules->ids)) 
					{
						$strPoolUrl = 'href="javascript:void(0);" onClick="showRestrict();"'; 
					}
					if(!in_array(5,$aModules->ids)) 
					{
						$strLightUrl = 'href="javascript:void(0);" onClick="showRestrict();"'; 
					}
					if(!in_array(11,$aModules->ids)) 
					{
						$strInputUrl = 'href="javascript:void(0);" onClick="showRestrict();"'; 
					}
				  }
				  
			?>
			<div class="inner">
				<div class="ribbon" style="width:90%"><a <?php echo $strModeUrl;?>><span style="color:#000;">Modes</span></a></div>
			</div>
			<div class="inner">
				<div class="ribbon ribbon-green" style="width:90%"><a <?php echo $strLightUrl;?>><span>Lights</span></a></div>
			</div>
			<div class="inner">
				<div class="ribbon" style="width:90%"><a <?php echo $strSpaUrl;?>><span style="color:#000;">Spa Devices</span></a></div>
			</div>
			<div class="inner">
				<div class="ribbon ribbon-green" style="width:90%"><a <?php echo $strPoolUrl;?>><span>Pool Devices</span></a></div>
			</div>
			<div class="inner">
				<div class="ribbon" style="width:90%"><a <?php echo $strInputUrl;?>><span>Input Device</span></a></div>
			</div>
		</div>
		<!--/ Ribbons -->
	</div>
</div>
<input type="hidden" id="IpId" value="<?php echo $iFirstIPId;?>">
<a class="fancybox" id="checkLink" href="#inline1" style="display:none;">&nbsp;</a>
<div id="inline1" style="text-align:center !important; display:none;"><!--<div class="loading-progress"></div>--><img src="<?php echo HTTP_ASSETS_PATH.'images/loading.gif';?>" width="32" alt="loading..."></div>

<!--/ row Level 2 -->

		