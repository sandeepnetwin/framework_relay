<?php
/**
 *	Project : Relayboard 
 *	Program/Module Name : Import/Export 
 *	Author : Dhiraj S. 
 *	Creation Date : 23/06/2016 
 *	Description : Import/Export Setting related to the relayboard.
 *	Modification History : 
 *	Change Date: 	Name: 
**/

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Importexport extends CI_Controller 
{
    public $userID,$aPermissions,$aModules,$aAllActiveModule;
	
    public function __construct()  
    {
		parent::__construct();
		$this->load->library('form_validation');
        $this->load->helper('common_functions'); //Common functions will be available for all functions in the file.
		
        if (!$this->session->userdata('is_admin_login')) //START : Check if user login or not.
        {
            redirect('dashboard/login/');
            die;
        }  //END : Check if user login or not. 
		
        //Get Permission Details
        if($this->userID == '')
        $this->userID = $this->session->userdata('id');

        if($this->aPermissions == '')
        {
            $this->aPermissions 	= json_decode(getPermissionOfModule($this->userID));
            $this->aModules 		= $this->aPermissions->sPermissionModule;	
            $this->aAllActiveModule     = $this->aPermissions->sActiveModule;
        }
   }

    public function index() //START : Function for dashboard
    {
		$this->load->model('home_model');
		$error['error']  = '';
		$error['option'] = '2';
		$error['success']= '';
		if($this->input->post('command') && $this->input->post('command') == 'Export Selected')
		{
			$isBasic 	= $this->input->post('basic') ? $this->input->post('basic') : 0;
			$isProgram 	= $this->input->post('program') ? $this->input->post('program') : 0;
			$isDevice 	= $this->input->post('device') ? $this->input->post('device') : 0;
			$isAdvance 	= $this->input->post('advance') ? $this->input->post('advance') : 0;
			$isExclude 	= $this->input->post('exclude') ? $this->input->post('exclude') : 0;
			
			$basicTable 	= array('rlb_setting','rlb_board_ip','rlb_modes','rlb_mode_questions');
			$programTable 	= array('rlb_program','rlb_custom_program','rlb_custom_program_after','rlb_custom_program_current','rlb_custom_program_log','rlb_device');
			$deviceTable 	= array('rlb_device','rlb_position','rlb_pump_device','rlb_pump_heater','rlb_valves');
			$advanceTable 	= array('rlb_mode_questions','rlb_site_modules');
			$excludeTable 	= array('rlb_exclude_device');
			
			if($isBasic)
			{
				if($tables == '')
					$tables .= implode(",",$basicTable);
				else 
					$tables .= ",".implode(",",$basicTable);
			}
			if($isProgram)
			{
				if($tables == '')
					$tables .= implode(",",$programTable);
				else 
					$tables .= ",".implode(",",$programTable);
			}
			if($isDevice)
			{
				if($tables == '')
					$tables .= implode(",",$deviceTable);
				else 
					$tables .= ",".implode(",",$deviceTable);
			}
			if($isAdvance)
			{	
				if($tables == '')
					$tables .= implode(",",$advanceTable);
				else 
					$tables .= ",".implode(",",$advanceTable);
			}
			if($isExclude)
			{	
				if($tables == '')
					$tables .= implode(",",$excludeTable);
				else 
					$tables .= ",".implode(",",$excludeTable);
			}
			
			
			$contents = $this->backup_tables($tables);
			//save file
			  $filename = 'backup/db-backup-'.time().'-'.(md5(implode(',',$tables))).'.sql';	
			  $handle = fopen($filename,'w+');
			  fwrite($handle,$contents);
			  fclose($handle);
			  
			  Header('Content-type: application/octet-stream');
			  Header('Content-Disposition: attachment; filename='.$filename);
			  echo $contents;
			  unlink($filename);
			  
			  exit;
		}
		if($this->input->post('command') && $this->input->post('command') == 'Export Complete Database')
		{
			$contents = $this->backup_tables();
			//save file
			  $filename = 'backup/db-backup-'.time().'.sql';	
			  $handle = fopen($filename,'w+');
			  fwrite($handle,$contents);
			  fclose($handle);
			  
			  Header('Content-type: application/octet-stream');
			  Header('Content-Disposition: attachment; filename='.$filename);
			  echo $contents;
			  unlink($filename);
			  
			  exit;
		}
		if($this->input->post('command') && $this->input->post('command') == 'Import')
		{
			$error['option'] = '1';
			$filenametemp = $_FILES['importFile']['name'];
			$target_file   = 'backup/upload/'.$filenametemp; 
			
			$arrFileDetails = explode(".",$filenametemp);
			
			if(end($arrFileDetails) != 'sql')
			{
				$error['error'] = 'The filetype you are attempting to upload is not allowed.';
			}
			
			if($error['error'] == '')
			{
				  if (move_uploaded_file($_FILES["importFile"]["tmp_name"], $target_file)) 
				  {
						$filename	=	$target_file;
						$templine = '';
						$lines = file($filename);
						$arrDetails = array();
						foreach ($lines as $line)
						{
							if (substr($line, 0, 2) == '--' || $line == '')
								continue;
							$templine .= $line;
							
							if (substr(trim($line), -1, 1) == ';')
							{
								$arrDetails[] = $templine;
								if(!preg_match("/(update|delete|alter|drop)/i", $templine))
								{
									$this->db->query($templine);
								}
								$templine = '';
							}
						}
						$error['success'] = 'Tables Imported Successfully!';
				  } 
				  else 
				  {
						$error['error'] = 'Sorry, there was an error uploading your file.';
				  }
			}
			
		}
		$this->template->build("ImportExport",$error);
	}
	
	function &backup_tables($tables = '*')
	{
	  $data = "\n/*---------------------------------------------------------------".
			  "\n  SQL DB BACKUP ".date("d.m.Y H:i")." ".
			  "\n  TABLES: {$tables}".
			  "\n  ---------------------------------------------------------------*/\n";
	  
	  $this->db->query( "SET NAMES `utf8` COLLATE `utf8_general_ci`"); 

	  if($tables == '*')
	  { //get all of the tables
		$tables = array();
		$result = $this->db->query("SHOW TABLES");
		
		if ($result->num_rows() > 0)
		{
		   foreach($result->result_array() as $row)
		   {		   
			$tables[] = $row['Tables_in_relay_db'];
			}
		}
	  }else{
		$tables = is_array($tables) ? $tables : explode(',',$tables);
	  }

		foreach($tables as $table)
		{
			$data.= "\n/*---------------------------------------------------------------".
					"\n  TABLE: `{$table}`".
					"\n  ---------------------------------------------------------------*/\n";           
			$data.= "DROP TABLE IF EXISTS `{$table}`;\n";
			$res = $this->db->query("SHOW CREATE TABLE `{$table}`");
		
			if ($res->num_rows() > 0)
			{
				foreach($res->result_array() as $row)
				{
					$data.= $row['Create Table'].";\n";
				}
			}

			$result = $this->db->query("SELECT * FROM `{$table}`");
			$num_rows = $result->num_rows();    

			if($num_rows>0)
			{
			  $vals = Array(); $z=0;
			  foreach($result->result_array() as $items)
			  {
				  $vals[$z]="(";
				  $numItems = count($items);
				  $i = 0;
				  foreach($items as $column => $value)
				  {
					  if (isset($value)) 
					  {	
						$vals[$z].= "'".mysql_real_escape_string($value)."'"; 
					  }	
					  else 
					  { 
						$vals[$z].= "NULL"; 
					  }
					  
					  if(++$i === $numItems) {}
					  else
					  {
						$vals[$z].= ","; 
					  }
				  }
				  
				$vals[$z].= ")"; $z++;
			  }
			  $data.= "INSERT INTO `{$table}` VALUES ";      
			  $data .= "  ".implode(";\nINSERT INTO `{$table}` VALUES ", $vals).";\n";
			}
		  }
		 return $data;
	 }
	
	public function importData()
	{
		$filename	=	"backup/backup_db-backup-1467098764-d41d8cd98f00b204e9800998ecf8427e.sql";
		$templine = '';
		$lines = file($filename);
		$arrDetails = array();
		foreach ($lines as $line)
		{
			if (substr($line, 0, 2) == '--' || $line == '')
				continue;
			$templine .= $line;
			
			if (substr(trim($line), -1, 1) == ';')
			{
				$arrDetails[] = $templine;
				// Perform the query
				mysql_query($templine) or print('Error performing query \'<strong>' . $templine . '\': ' . mysql_error() . '<br /><br />');
				
				$templine = '';
			}
		}
		//echo '<pre>';print_r($arrDetails);echo '</pre>';
		//die('STOP');
		echo "Tables imported successfully";	
	}	
	
}//END : Class Importexport

/* End of file importexport.php */
/* Location: ./application/controllers/home.php */