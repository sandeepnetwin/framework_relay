<?php

	$sAccess 		=	'';
	$sModule	    =	12;

	//Get Permission Details
	$userID 		= $this->session->userdata('id');
	$aPermissions 	= json_decode(getPermissionOfModule($userID));

	$aModules 			= $aPermissions->sPermissionModule;	
	$aAllActiveModule 	= $aPermissions->sActiveModule;

	$sAccessKey		= 'access_'.$sModule;
			  
	if(!empty($aModules))
	{
		if(in_array($sModule,$aModules->ids))
		{
			$sAccess = $aModules->$sAccessKey;
		}
		else if(!in_array($sModule,$aModules->ids)) 
		{
			$sAccess = '0'; 
		}
	}

	if($sAccess == '')
		$sAccess = '2' ; 

	if($sAccess == '0') 
	{
		redirect(site_url('home/'));
	}


	if($sIP == '')
	  $sIP =  IP_ADDRESS;

	if($sPort == '')
	  $sPort =  PORT_NO; 

	$numPumps		=	0;
	$numValve		=	0;
	$numLight		=	0;
	$numHeater		=	0;
	$numBlower		=	0;
	$numSolarHeater =	0;

	if(isset($extra['PumpsNumber']))
		$numPumps		=	$extra['PumpsNumber'];
	if(isset($extra['ValveNumber']))
		$numValve		=	$extra['ValveNumber'];
	if(isset($extra['LightNumber']))
		$numLight		=	$extra['LightNumber'];
	if(isset($extra['HeaterNumber']))
		$numHeater		=	$extra['HeaterNumber'];
	if(isset($extra['SolarHeaterNumber']))
		$numSolarHeater	=	$extra['SolarHeaterNumber'];
	if(isset($extra['BlowerNumber']))
		$numBlower		=	$extra['BlowerNumber'];
	if(isset($extra['MiscNumber']))
		$numMisc		=	$extra['MiscNumber'];
	
	//Create IP and Board Name Variables.
	if(!empty($aIPDetails))
	{
		$i	=	1;
		foreach($aIPDetails as $aIP)
		{
			${"sIP". $i} = $aIP->ip;
			${"sBoardName". $i} = $aIP->name;
			${"sShh". $i} = $aIP->ssh_port;
			$i++;
		}
	}
	
?>
<style>
.inputBox
{
	width: 180px !important;
	display:inline-block;
}
.manualMsg
{
	float:left;
	margin-left:10px;
	width: 350px;
	line-height: 20px;
}
.tipso_style_custom 
{
    border-bottom: medium none !important;
	vertical-align:middle;
}
@media (max-width:480px)
{
	.inputBox
	{
		width: 130px !important;
		display:inline-block;
	}
	.manualMsg
	{
		margin-left:0px !important;
		width: 180px !important;
	}
}
</style>

<link rel="stylesheet" href="<?php echo HTTP_ASSETS_PATH.'/tipso-master/tipso.css';?>">
<script src="<?php echo HTTP_ASSETS_PATH.'/tipso-master/tipso.js';?>"></script>

    <div id="page-wrapper">
        <div class="row">
          <div class="col-lg-12">
            <ol class="breadcrumb">
			  <li><img src="<?php echo HTTP_IMAGES_PATH.'icons/home.png';?>" width="24" style="vertical-align: middle !important;">&nbsp;<a href="<?php echo site_url();?>">Home</a> </li>
			  <li class="active">Setting</li>
			</ol>
            <?php if($sucess == '1') { ?>
              <div class="alert alert-success alert-dismissable">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                Details saved successfully! 
              </div>
            <?php } ?>
            <?php if($err_sucess == '1') { ?>
              <div class="alert alert-success alert-dismissable" style="background-color: #FFC0CB;border: 1px solid #FFC0CB; color:red;">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                IP and Port details required! 
              </div>
            <?php } ?>
            
          </div>
        </div><!-- /.row -->
        <div class="row">
          <div class="col-lg-12">
            <div class="panel panel-primary">
              <div class="panel-heading" style="border-top-left-radius: 0px;border-top-right-radius: 0px;">
                <h3 class="panel-title" style="color:#FFF;">Settings Page</h3>
              </div>
              <div class="panel-body">
                <div id="morris-chart-area">
                <form action="<?php if($sAccess == 2) {echo site_url('home/setting');}?>" method="post" name="settingForm" id="settingForm">
				<input type="hidden" id="command" name="command" value="">
                <table border="0" cellspacing="0" cellpadding="0" width="100%">
                    <tr>
                        <td width="24%"><strong>IP ADDRESS RLB BOARD 1:</strong></td>
                        <td width="1%">&nbsp;</td>
                        <td width="75%">
							<input type="text" class="form-control inputBox" placeholder="Enter ip address for RLB BOARD 1" name="relay_ip_address" value="<?php echo $sIP1;?>" id="relay_ip_address" <?php if($sAccess == 1) { echo 'disabled="disabled"';} ?>>&nbsp;&nbsp;
							<img src="<?php echo HTTP_ASSETS_PATH.'/images/help.png';?>" alt="Help" class="top-right tipso_style_custom" data-tipso="ENTER THE LOCAL IP ADDRESS WHERE YOUR RLB BOARD 1 IS LOCATED. e.g.192.168.1.50" style="width:32px;">
							<?php if(IS_LOCAL == '1') { ?>
								&nbsp;<input type="text" class="form-control inputBox" name="relay_ip_address_ssh1" value="<?php echo $sShh1;?>" id="relay_ip_address_ssh1" <?php if($sAccess == 1) { echo 'disabled="disabled"';} ?> style="width:60px !important;">&nbsp;&nbsp;
								<img src="<?php echo HTTP_ASSETS_PATH.'/images/help.png';?>" alt="Help" class="top-right tipso_style_custom" data-tipso="ENTER SSH PORT FOR IP. e.g.22" style="width:32px;">
							<?php } ?>
						</td>
                    </tr>
					
                    <tr><td colspan="3">&nbsp;</td></tr>
					
					 <tr>
                        <td width="24%"><strong>NAME RLB BOARD 1:</strong></td>
                        <td width="1%">&nbsp;</td>
                        <td width="75%">
							<input type="text" class="form-control inputBox" placeholder="Enter name for RLB BOARD 1" name="relay_board_name1" value="<?php echo $sBoardName1;?>" id="relay_board_name1" <?php if($sAccess == 1) { echo 'disabled="disabled"';} ?>>
							&nbsp;&nbsp;
							<img src="<?php echo HTTP_ASSETS_PATH.'/images/help.png';?>" alt="Help" class="top-right tipso_style_custom" data-tipso="ENTER NAME FOR RLB BOARD 1(OPTIONAL). e.g.Relayboard1" style="width:32px;">
						</td>
                    </tr>
					
                    <tr><td colspan="3">&nbsp;</td></tr>
					
					<tr>
                        <td width="24%"><strong>IP ADDRESS RLB BOARD 2:</strong></td>
                        <td width="1%">&nbsp;</td>
                        <td width="75%">
							<input type="text" class="form-control inputBox" placeholder="Enter ip address for RLB BOARD 2" name="relay_ip_address2" value="<?php echo $sIP2;?>" id="relay_ip_address2" <?php if($sAccess == 1) { echo 'disabled="disabled"';} ?>>&nbsp;&nbsp;
							<img src="<?php echo HTTP_ASSETS_PATH.'/images/help.png';?>" alt="Help" class="top-right tipso_style_custom" data-tipso="ENTER THE LOCAL IP ADDRESS WHERE YOUR RLB BOARD 2 IS LOCATED.(OPTIONAL) e.g.192.168.1.50" style="width:32px;">
							<?php if(IS_LOCAL == '1') { ?>
								&nbsp;<input type="text" class="form-control inputBox" name="relay_ip_address_ssh2" value="<?php echo $sShh2;?>" id="relay_ip_address_ssh2" <?php if($sAccess == 1) { echo 'disabled="disabled"';} ?> style="width:60px !important;">&nbsp;&nbsp;
								<img src="<?php echo HTTP_ASSETS_PATH.'/images/help.png';?>" alt="Help" class="top-right tipso_style_custom" data-tipso="ENTER SSH PORT FOR IP. e.g.23" style="width:32px;">
							<?php } ?>
							
						</td>
                    </tr>
					
                    <tr><td colspan="3">&nbsp;</td></tr>
					
					<tr>
                        <td width="24%"><strong>NAME RLB BOARD 2:</strong></td>
                        <td width="1%">&nbsp;</td>
                        <td width="75%">
							<input type="text" class="form-control inputBox" placeholder="Enter name for RLB BOARD 2" name="relay_board_name2" value="<?php echo $sBoardName2;?>" id="relay_board_name2" <?php if($sAccess == 1) { echo 'disabled="disabled"';} ?>>
							&nbsp;&nbsp;
							<img src="<?php echo HTTP_ASSETS_PATH.'/images/help.png';?>" alt="Help" class="top-right tipso_style_custom" data-tipso="ENTER NAME FOR RLB BOARD 2(OPTIONAL). e.g.Relayboard2" style="width:32px;">
						</td>
                    </tr>
					
                    <tr><td colspan="3">&nbsp;</td></tr>
					
                    <tr>
                        <td width="10%"><strong>PORT NO:</strong></td>
                        <td width="1%">&nbsp;</td>
                        <td width="89%">
							<input type="text" class="form-control inputBox" placeholder="Enter port no" name="relay_port_no" value="<?php echo $sPort;?>" id="relay_port_no" <?php if($sAccess == 1) { echo 'disabled="disabled"';} ?>>
							&nbsp;&nbsp;
							<img src="<?php echo HTTP_ASSETS_PATH.'/images/help.png';?>" alt="Help" class="top-right tipso_style_custom" data-tipso="ENTER PORT NO. FOR FIRST RLB BOARD. e.g.13330" style="width:32px;">
						</td>
                    </tr>
					
					<!--<tr><td colspan="3">&nbsp;</td></tr>
                    <tr>
                        <td width="10%"><strong>PORT NO(Relayboard 2):</strong></td>
                        <td width="1%">&nbsp;</td>
                        <td width="89%">
							<input type="text" class="form-control inputBox" placeholder="Enter port no" name="relay_port_no_2" value="<?php// echo $sPort2;?>" id="relay_port_no_2" <?php //if($sAccess == 1) { echo 'disabled="disabled"';} ?>>
							&nbsp;&nbsp;
							<img src="<?php //echo HTTP_ASSETS_PATH.'/images/help.png';?>" alt="Help" class="top-right tipso_style_custom" data-tipso="ENTER PORT NO. FOR SECOND RLB BOARD. e.g.13330" style="width:32px;">
						</td>
                    </tr>-->
                    
					<tr><td colspan="3">&nbsp;</td></tr>
                    <tr>
                        <td width="10%"><strong>Display Desired Pool Temp on Home Page:</strong></td>
                        <td width="1%">&nbsp;</td>
                        <td width="89%">
							<input type="radio" name="showPoolTemp" value="0" <?php if(isset($extra['Pool_Temp']) && $extra['Pool_Temp'] == '0') { echo 'checked="checked";';}?> checked="checked" <?php if($sAccess == 1) { echo 'disabled="disabled"';} ?>>&nbsp;No
							&nbsp;&nbsp;
							
							<input type="radio" name="showPoolTemp" value="1" <?php if(isset($extra['Pool_Temp']) && $extra['Pool_Temp'] == '1') { echo 'checked="checked";';}?> <?php if($sAccess == 1) { echo 'disabled="disabled"';} ?>>&nbsp;Yes
							
							&nbsp;&nbsp;
							<img src="<?php echo HTTP_ASSETS_PATH.'/images/help.png';?>" alt="Help" class="top-right tipso_style_custom" data-tipso="SELECT WHETHER TO SHOW POOL TEMPERATURE ON HOME PAGE." style="width:32px;">
							
							<div style="height:10px;">&nbsp;</div>
							
							<div id="poolTempID" style="display:<?php if(isset($extra['Pool_Temp_Address']) && $extra['Pool_Temp_Address'] != '') { echo ''; } else {echo 'none';}?>">
							
							<strong>Select :</strong> 
							<select name="selPoolTemp" id="selPoolTemp" class="form-control inputBox" style="display:inline !important; width:136px !important;" <?php if($sAccess == 1) { echo 'disabled="disabled"';} ?>>
							<?php
									foreach($aTemprature as $key=>$temprature)
									{
										$strTemp	=	'';
										if($temprature != '')
										{
											$strTemp = '( '.$temprature.' )';
										}
										
										$strSelect	=	'';
										if(isset($extra['Pool_Temp_Address']) && $extra['Pool_Temp_Address'] != '')
										{
											if($extra['Pool_Temp_Address'] == $key)
											{
												$strSelect	=	'selected="selected"';
											}
										}
										
										echo '<option value="'.$key.'" '.$strSelect.'>'.$key.' '.$strTemp.'</option>';
									}

							?>
							</select>
							
							</div>
						</td>
                    </tr>
					
                    <tr><td colspan="3">&nbsp;</td></tr>
					<tr>
                        <td width="10%"><strong>Display Desired Spa Temp on home page:</strong></td>
                        <td width="1%">&nbsp;</td>
                        <td width="89%">
							<input type="radio" name="showSpaTemp" value="0" <?php if((isset($extra['Pool_Temp']) && $extra['Spa_Temp'] == '0')) { echo 'checked="checked";';}?> checked="checked" <?php if($sAccess == 1) { echo 'disabled="disabled"';} ?>>&nbsp;No
							&nbsp;&nbsp;
							<input type="radio" name="showSpaTemp" value="1" <?php if((isset($extra['Pool_Temp']) && $extra['Spa_Temp'] == '1')) { echo 'checked="checked";';}?> <?php if($sAccess == 1) { echo 'disabled="disabled"';} ?>>&nbsp;Yes
							&nbsp;&nbsp;
							<img src="<?php echo HTTP_ASSETS_PATH.'/images/help.png';?>" alt="Help" class="top-right tipso_style_custom" data-tipso="SELECT WHETHER TO SHOW SPA TEMPERATURE ON HOME PAGE." style="width:32px;">
							
							<div style="height:10px;">&nbsp;</div>
							<div id="spaTempID" style="display:<?php if(isset($extra['Spa_Temp_Address']) && $extra['Spa_Temp_Address'] != '') { echo ''; } else {echo 'none';}?>">
								<strong>Select :</strong> 
								<select name="selSpaTemp" id="selSpaTemp" class="form-control inputBox" style="display:inline !important; width:136px !important;" <?php if($sAccess == 1) { echo 'disabled="disabled"';} ?> >
									<?php
										foreach($aTemprature as $key=>$temprature)
										{
											$strTemp	=	'';
											if($temprature != '')
											{
												$strTemp = '( '.$temprature.' )';
											}
											
											$strSelect	=	'';
											if(isset($extra['Spa_Temp_Address']) && $extra['Spa_Temp_Address'] != '')
											{
												if($extra['Spa_Temp_Address'] == $key)
												{
													$strSelect	=	'selected="selected"';
												}
											}	
											
											echo '<option value="'.$key.'" '.$strSelect.'>'.$key.' '.$strTemp.'</option>';
										}
									?>
								</select>
							</div>
						</td>
                    </tr>
					
					<tr><td colspan="3">&nbsp;</td></tr>
					<tr>
                        <td width="10%"><strong>Maximum Manual Mode threshold expressed in minutes: </strong></td>
                        <td width="1%">&nbsp;</td>
                        <td width="89%">
							<input type="text" name="manualMinutes" id="manualMinutes" value="<?php echo $manualMinutes;?>" class="form-control inputBox" <?php if($sAccess == 1) { echo 'disabled="disabled"';} ?>>
							&nbsp;&nbsp;
							<img src="<?php echo HTTP_ASSETS_PATH.'/images/help.png';?>" alt="Help" class="top-right tipso_style_custom" data-tipso="THE SYSTEM WILL AUTOMATICALLY CHANGE FROM MANUAL MODE TO AUTO MODE AFTER THE THRESHOLD HAS BEEN EXCEEDED. e.g. 60" style="width:32px;">
						</td>
                    </tr>
					  
					<tr><td colspan="3">&nbsp;</td></tr>
					<tr>
                        <td width="10%"><strong>Enter Number of Pumps: </strong></td>
                        <td width="1%">&nbsp;</td>
                        <td width="89%">
							<input type="text" name="numPumps" id="numPumps" value="<?php echo $numPumps;?>" class="form-control inputBox" <?php if($sAccess == 1) { echo 'disabled="disabled"';} ?>>
							&nbsp;&nbsp;
							<img src="<?php echo HTTP_ASSETS_PATH.'/images/help.png';?>" alt="Help" class="top-right tipso_style_custom" data-tipso="ENTER NUMBER OF PUMPS USED WITH RLB BOARD. e.g. 2" style="width:32px;">
						</td>
                    </tr>
					  
					<tr><td colspan="3">&nbsp;</td></tr>
					<tr>
                        <td width="10%"><strong>Enter Number of Valves: </strong></td>
                        <td width="1%">&nbsp;</td>
                        <td width="89%">
							<input type="text" name="numValve" id="numValve" value="<?php echo $numValve;?>" class="form-control inputBox" <?php if($sAccess == 1) { echo 'disabled="disabled"';} ?>>
							&nbsp;&nbsp;
							<img src="<?php echo HTTP_ASSETS_PATH.'/images/help.png';?>" alt="Help" class="top-right tipso_style_custom" data-tipso="ENTER NUMBER OF VALVES USED WITH RLB BOARD. e.g. 2" style="width:32px;">
						</td>
                    </tr>
					  
					<tr><td colspan="3">&nbsp;</td></tr>
					<tr>
                        <td width="10%"><strong>Enter Number of Lights: </strong></td>
                        <td width="1%">&nbsp;</td>
                        <td width="89%">
							<input type="text" name="numLight" id="numLight" value="<?php echo $numLight;?>" class="form-control inputBox" <?php if($sAccess == 1) { echo 'disabled="disabled"';} ?>>
							&nbsp;&nbsp;
							<img src="<?php echo HTTP_ASSETS_PATH.'/images/help.png';?>" alt="Help" class="top-right tipso_style_custom" data-tipso="ENTER NUMBER OF LIGHTS USED WITH RLB BOARD. e.g. 2" style="width:32px;">
						</td>
                    </tr>
					  
					<tr><td colspan="3">&nbsp;</td></tr>
					<tr>
                        <td width="10%"><strong>Enter Number of Heater: </strong></td>
                        <td width="1%">&nbsp;</td>
                        <td width="89%">
							<input type="text" name="numHeater" id="numHeater" value="<?php echo $numHeater;?>" class="form-control inputBox"  <?php if($sAccess == 1) { echo 'disabled="disabled"';} ?>>
							&nbsp;&nbsp;
							<img src="<?php echo HTTP_ASSETS_PATH.'/images/help.png';?>" alt="Help" class="top-right tipso_style_custom" data-tipso="ENTER NUMBER OF HEATERS USED WITH RLB BOARD. e.g. 2" style="width:32px;">
						</td>
                    </tr>
					
					<tr><td colspan="3">&nbsp;</td></tr>
					<tr>
                        <td width="10%"><strong>Do you have a solar heater?: </strong></td>
                        <td width="1%">&nbsp;</td>
                        <td width="89%">
							<input type="radio" name="numSolarHeater" id="numSolarHeater_0" 
							value="0" <?php if($numSolarHeater == '0') { echo 'checked="checked"'; } ?> >&nbsp;No&nbsp;&nbsp;
							<input type="radio" name="numSolarHeater" id="numSolarHeater_1" 
							value="1" <?php if($numSolarHeater == '1') { echo 'checked="checked"'; } ?> >&nbsp;Yes
							&nbsp;&nbsp;
							<img src="<?php echo HTTP_ASSETS_PATH.'/images/help.png';?>" alt="Help" class="top-right tipso_style_custom" data-tipso="SELECT IF YOU HAVE SOLAR HEATER." style="width:32px;">
						</td>
                    </tr>
					  
					<tr><td colspan="3">&nbsp;</td></tr>
					<tr>
                        <td width="10%"><strong>Enter Number of Blower: </strong></td>
                        <td width="1%">&nbsp;</td>
                        <td width="89%">
							<input type="text" name="numBlower" id="numBlower" value="<?php echo $numBlower;?>" class="form-control inputBox" <?php if($sAccess == 1) { echo 'disabled="disabled"';} ?>>
							&nbsp;&nbsp;
							<img src="<?php echo HTTP_ASSETS_PATH.'/images/help.png';?>" alt="Help" class="top-right tipso_style_custom" data-tipso="ENTER NUMBER OF BLOWERS USED WITH RLB BOARD. e.g. 2" style="width:32px;">
						</td>
                    </tr>
					
					<tr><td colspan="3">&nbsp;</td></tr>
					<tr>
                        <td width="10%"><strong>Enter Number of Miscellanious Device: </strong></td>
                        <td width="1%">&nbsp;</td>
                        <td width="89%">
							<input type="text" name="numMisc" id="numMisc" value="<?php echo $numMisc;?>" class="form-control inputBox" <?php if($sAccess == 1) { echo 'disabled="disabled"';} ?>>
							&nbsp;&nbsp;
							<img src="<?php echo HTTP_ASSETS_PATH.'/images/help.png';?>" alt="Help" class="top-right tipso_style_custom" data-tipso="ENTER NUMBER OF MISCELLANIOUS DEVICE USED WITH RLB BOARD. e.g. 2" style="width:32px;">
						</td>
                    </tr>
					
					<tr><td colspan="3">&nbsp;</td></tr>
					<tr>
                        <td width="10%"><strong>Do you have a remote switch?: </strong></td>
                        <td width="1%">&nbsp;</td>
                        <td width="89%">
							<input type="radio" onclick="showHideDisplay(this.value);" name="showRemoteSpa" value="0" <?php if((isset($extra['Remote_Spa']) && $extra['Remote_Spa'] == '0')) { echo 'checked="checked";';}?> checked="checked" <?php if($sAccess == 1) { echo 'disabled="disabled"';} ?>>&nbsp;No
							&nbsp;&nbsp;
							<input type="radio" onclick="showHideDisplay(this.value);" name="showRemoteSpa" value="1" <?php if((isset($extra['Remote_Spa']) && $extra['Remote_Spa'] == '1')) { echo 'checked="checked";';}?> <?php if($sAccess == 1) { echo 'disabled="disabled"';} ?>>&nbsp;Yes
							&nbsp;&nbsp;
							<img src="<?php echo HTTP_ASSETS_PATH.'/images/help.png';?>" alt="Help" class="top-right tipso_style_custom" data-tipso="SELECT IF YOU HAVE REMOTE SWITCH WITH RLB BOARD." style="width:32px;">
						</td>
                    </tr>
					
					<tr id="displayRemoteBlank" <?php if($extra['Remote_Spa'] == '0' || $extra['Remote_Spa'] == ''){ echo 'style="display:none;"';}?>><td colspan="3">&nbsp;</td></tr>
					<tr id="displayRemote" <?php if($extra['Remote_Spa'] == '0' || $extra['Remote_Spa'] == ''){ echo 'style="display:none;"';}?>>
                        <td width="10%"><strong>Do you want to display on Home page?: </strong></td>
                        <td width="1%">&nbsp;</td>
                        <td width="89%">
							<input type="radio" id="showRemoteSpaDisplay_0" name="showRemoteSpaDisplay" value="0" <?php if((isset($extra['Remote_Spa_display']) && $extra['Remote_Spa_display'] == '0')) { echo 'checked="checked";';}?> checked="checked" <?php if($sAccess == 1) { echo 'disabled="disabled"';} ?>>&nbsp;No
							&nbsp;&nbsp;
							<input type="radio" id="showRemoteSpaDisplay_1" name="showRemoteSpaDisplay" value="1" <?php if((isset($extra['Remote_Spa_display']) && $extra['Remote_Spa_display'] == '1')) { echo 'checked="checked";';}?> <?php if($sAccess == 1) { echo 'disabled="disabled"';} ?>>&nbsp;Yes
							&nbsp;&nbsp;
							<img src="<?php echo HTTP_ASSETS_PATH.'/images/help.png';?>" alt="Help" class="top-right tipso_style_custom" data-tipso="SELECT WHETHER YOU WANT TO SHOW REMOTE SWITCH ON HOME PAGE." style="width:32px;">
						</td>
                    </tr>
					
					<tr><td colspan="3">&nbsp;</td></tr>
                    <tr>
						<td colspan="3"><!--<input type="<?php if($sAccess == 2) { echo 'submit';} else { echo 'button';} ?>" name="command" value="Save Setting" class="btn btn-success" onclick="return checkModeSelected();">-->
						  <a href="javascript:void(0);" <?php if($sAccess == 2) { ?> onclick="checkModeSelected();" <?php } ?> class="btn btn-green"><span>Save Setting</span></a>
						  &nbsp;&nbsp;
						  <a href="javascript:void(0);" <?php if($sAccess == 2) { ?> onclick="location.href='<?php echo base_url();?>';" <?php } ?> class="btn btn-gray"><span>Cancel</span></a>
						</td>
					</tr>
                </table>
                </form>
                </div>
              </div>
            </div>
          </div>
        </div><!-- /.row -->
      </div><!-- /#page-wrapper -->
<script type="text/javascript">
$(document).ready(function (){
	
	jQuery('.top-right').tipso({
				position: 'top-right',
				background: '#000000',
				useTitle: false
			});
	
	$("input[name='showPoolTemp']").click(function(){
		var checkedVal =	$(this).val();
		if(checkedVal == '1')
		{
			$("#poolTempID").show();
		}
		else
		{
			$("#poolTempID").hide();
		}
	});
	
	$("input[name='showSpaTemp']").click(function(){
		var checkedVal =	$(this).val();
		if(checkedVal == '1')
		{
			$("#spaTempID").show();
		}
		else
		{
			$("#spaTempID").hide();
		}
	});	
});
  function checkModeSelected()
  {
    var sRelayMode 		= 	$("#relay_mode").val();
	var manualMinutes	=	$("#manualMinutes").val();
	$("#command").val('');
    if(sRelayMode == '0')
    {
      $("#relay_mode").css('border','1px solid #B40404');
      alert('Please select Mode!');
      return false;
    }
    else
    {
      $("#relay_mode").css('border','');
    }
	
	if(manualMinutes != '')
	{
		if(isNaN(manualMinutes))
		{
			$("#manualMinutes").css('border','1px solid #B40404');
			alert("Please enter valid minutes!")
			return false;
		}
		else
		{
			$("#manualMinutes").css('border','');
			
		}
	}
	
	$("#command").val('Save Setting');
	document.settingForm.submit();
	//return true;
	

  }
  
  function showHideDisplay(val)
  {
	  if(val == '0')
	  {
			$('#showRemoteSpaDisplay_0').prop('checked',true);
			$("#displayRemote").hide();
			$("#displayRemoteBlank").hide();
	  }
	  else
	  {
			$("#displayRemote").show();
			$("#displayRemoteBlank").show();
	  }
  }
  
  
</script>
<?php

?>