<?php
	
	/**
	* @Programmer: Dhiraj S.
	* @Created: 13 July 2015
	* @Modified: 
	* @Description: View for Basic settings form.
	**/
	
	$sAccess 		=	'';
	$sModule	    =	12;

	//Get Permission Details
	$userID 		= $this->session->userdata('id');
	$aPermissions 	= json_decode(getPermissionOfModule($userID));

	$aModules 			= $aPermissions->sPermissionModule;	
	$aAllActiveModule 	= $aPermissions->sActiveModule;

	$sAccessKey		= 'access_'.$sModule;
			  
	if(!empty($aModules))
	{
		if(in_array($sModule,$aModules->ids))
		{
			$sAccess = $aModules->$sAccessKey;
		}
		else if(!in_array($sModule,$aModules->ids)) 
		{
			$sAccess = '0'; 
		}
	}

	if($sAccess == '')
		$sAccess = '2' ; 

	if($sAccess == '0') 
	{
		redirect(site_url('home/'));
	}


	$numPumps		=	0;
	$numValve		=	0;
	$numLight		=	0;
	$numHeater		=	0;
	$numBlower		=	0;
	$numSolarHeater =	0;
	
	$numPumps		=	isset($extra['PumpsNumber']) ? $extra['PumpsNumber'] : 0;
	$numValve		=	isset($extra['ValveNumber']) ? $extra['ValveNumber'] : 0;
	$numLight		=	isset($extra['LightNumber']) ? $extra['LightNumber'] : 0;
	$numHeater		=	isset($extra['HeaterNumber']) ? $extra['HeaterNumber'] : 0;
	$numSolarHeater	=	isset($extra['SolarHeaterNumber']) ? $extra['SolarHeaterNumber'] : 0;
	$numBlower		=	isset($extra['BlowerNumber']) ? $extra['BlowerNumber'] : 0;
	$numMisc		=	isset($extra['MiscNumber']) ? $extra['MiscNumber'] : 0;
	
	$numPumps2		=	isset($extra['PumpsNumber2']) ? $extra['PumpsNumber2'] : 0;
	$numValve2		=	isset($extra['ValveNumber2']) ? $extra['ValveNumber2'] : 0;
	$numLight2		=	isset($extra['LightNumber2']) ? $extra['LightNumber2'] : 0;
	$numHeater2		=	isset($extra['HeaterNumber2']) ? $extra['HeaterNumber2'] : 0;
	$numSolarHeater2	=	isset($extra['SolarHeaterNumber2']) ? $extra['SolarHeaterNumber2'] : 0;
	$numBlower2		=	isset($extra['BlowerNumber2']) ? $extra['BlowerNumber2'] : 0;
	$numMisc2		=	isset($extra['MiscNumber2']) ? $extra['MiscNumber2'] : 0;
	
	$secondIP		=	isset($extra['SecondIP']) ? $extra['SecondIP'] : 0;
	
	//Create IP and Board Name Variables.
	if(!empty($aIPDetails))
	{
		$i	=	1;
		foreach($aIPDetails as $aIP)
		{
			${"sIP". $i} = $aIP->ip;
			${"sBoardName". $i} = $aIP->name;
			${"sShh". $i} = $aIP->ssh_port;
			$i++;
		}
	}
	
?>
<style>
.inputBox
{
	width: 180px !important;
	display:inline-block;
}
.manualMsg
{
	float:left;
	margin-left:10px;
	width: 350px;
	line-height: 20px;
}
.tipso_style_custom 
{
    border-bottom: medium none !important;
	vertical-align:middle;
}
@media (max-width:480px)
{
	.inputBox
	{
		width: 130px !important;
		display:inline-block;
	}
	.manualMsg
	{
		margin-left:0px !important;
		width: 180px !important;
	}
}
</style>

<link rel="stylesheet" href="<?php echo HTTP_ASSETS_PATH.'/tipso-master/tipso.css';?>">
<script src="<?php echo HTTP_ASSETS_PATH.'/tipso-master/tipso.js';?>"></script>

    <div id="page-wrapper">
        <div class="row">
          <div class="col-lg-12">
            <ol class="breadcrumb">
			  <li><img src="<?php echo HTTP_IMAGES_PATH.'icons/home.png';?>" width="24" style="vertical-align: middle !important;">&nbsp;<a href="<?php echo site_url();?>">Home</a> </li>
			  <li class="active">Setting</li>
			</ol>
            <?php if($sucess == '1') { ?>
              <div class="alert alert-success alert-dismissable">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                Details saved successfully! 
              </div>
            <?php } ?>
            <?php if($err_sucess == '1') { ?>
              <div class="alert alert-success alert-dismissable" style="background-color: #FFC0CB;border: 1px solid #FFC0CB; color:red;">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                IP and Port details required! 
              </div>
            <?php } ?>
            
          </div>
        </div><!-- /.row -->
        <div class="row">
			<form action="<?php if($sAccess == 2) {echo site_url('home/setting');}?>" method="post" name="settingForm" id="settingForm">
			<!--<input type="hidden" id="command" name="command" value="">-->
			<div class="col-sm-12" id="IpDeviceTab">
				<table border="0" cellspacing="0" cellpadding="0" width="100%">
				<tr>
					<td width="35%" style="color:#FFF"><strong>PORT NO:</strong></td>
					<td width="1%">&nbsp;</td>
					<td width="89%">
						<input type="text" class="form-control inputBox" placeholder="Enter port no" name="relay_port_no" value="<?php echo $sPort;?>" id="relay_port_no" <?php if($sAccess == 1) { echo 'disabled="disabled"';} ?> style="height:35px !important;">
						&nbsp;&nbsp;
						<img src="<?php echo HTTP_ASSETS_PATH.'/images/help.png';?>" alt="Help" class="top-right tipso_style_custom" data-tipso="ENTER PORT NO. RLB BOARD. e.g.13330" style="width:32px;">
					</td>
				</tr>
				<tr><td colspan="3">&nbsp;</td></tr>
								
				<tr>
					<td width="35%" style="color:#FFF"><strong>MAXIMUM MANUAL MODE THRESHOLD EXPRESSED IN MINUTES: </strong></td>
					<td width="1%">&nbsp;</td>
					<td width="74%">
						<input type="text" name="manualMinutes" id="manualMinutes" value="<?php echo $manualMinutes;?>" class="form-control inputBox" <?php if($sAccess == 1) { echo 'disabled="disabled"';} ?> style="height:35px !important;">
						&nbsp;&nbsp;
						<img src="<?php echo HTTP_ASSETS_PATH.'/images/help.png';?>" alt="Help" class="top-right tipso_style_custom" data-tipso="THE SYSTEM WILL AUTOMATICALLY CHANGE FROM MANUAL MODE TO AUTO MODE AFTER THE THRESHOLD HAS BEEN EXCEEDED. e.g. 60" style="width:32px;">
					</td>
				</tr>
				<tr><td colspan="3">&nbsp;</td></tr>
				</table>
				
				<div class="tabs-framed tabs-small boxed green-line">
					<ul class="tabs clearfix">
						<li class="active"><a href="#IP1" data-toggle="tab">IP / Board 1 Settings</a></li>
						<li><a href="#IP2" data-toggle="tab">IP / Board 2 Settings</a></li>
					</ul>
					<div class="tab-content">
						<div class="tab-pane fade in active" id="IP1">
							<table border="0" cellspacing="0" cellpadding="0" width="100%" style="margin-left:20px; margin-top:20px; margin-bottom:20px;">
								<tr>
									<td width="24%"><strong>IP ADDRESS RLB BOARD 1:</strong></td>
									<td width="1%">&nbsp;</td>
									<td width="75%">
										<input type="text" class="form-control inputBox" placeholder="Enter ip address for RLB BOARD 1" name="relay_ip_address" value="<?php echo $sIP1;?>" id="relay_ip_address" <?php if($sAccess == 1) { echo 'disabled="disabled"';} ?>>
										&nbsp;&nbsp;
										<img src="<?php echo HTTP_ASSETS_PATH.'/images/help.png';?>" alt="Help" class="top-right tipso_style_custom" data-tipso="ENTER THE LOCAL IP ADDRESS WHERE YOUR RLB BOARD 1 IS LOCATED. e.g.192.168.1.50" style="width:32px;" required>
										<?php if(IS_LOCAL == '1') { ?>
											&nbsp;<input type="text" class="form-control inputBox" name="relay_ip_address_ssh1" value="<?php echo $sShh1;?>" id="relay_ip_address_ssh1" <?php if($sAccess == 1) { echo 'disabled="disabled"';} ?> style="width:60px !important;" required>&nbsp;&nbsp;
											<img src="<?php echo HTTP_ASSETS_PATH.'/images/help.png';?>" alt="Help" class="top-right tipso_style_custom" data-tipso="ENTER SSH PORT FOR IP. e.g.22" style="width:32px;">
										<?php } ?>
									</td>
								</tr>
								
								<tr><td colspan="3">&nbsp;</td></tr>
								
								 <tr>
									<td width="24%"><strong>NAME RLB BOARD 1:</strong></td>
									<td width="1%">&nbsp;</td>
									<td width="75%">
										<input type="text" class="form-control inputBox" placeholder="Enter name for RLB BOARD 1" name="relay_board_name1" value="<?php echo $sBoardName1;?>" id="relay_board_name1" <?php if($sAccess == 1) { echo 'disabled="disabled"';} ?>>
										&nbsp;&nbsp;
										<img src="<?php echo HTTP_ASSETS_PATH.'/images/help.png';?>" alt="Help" class="top-right tipso_style_custom" data-tipso="ENTER NAME FOR RLB BOARD 1(OPTIONAL). e.g.Relayboard1" style="width:32px;">
									</td>
								</tr>
								
								<tr><td colspan="3">&nbsp;</td></tr>
								<tr>
									<td width="10%"><strong>Enter Number of Pumps: </strong></td>
									<td width="1%">&nbsp;</td>
									<td width="89%">
										<input type="text" name="numPumps" id="numPumps" value="<?php echo $numPumps;?>" class="form-control inputBox" <?php if($sAccess == 1) { echo 'disabled="disabled"';} ?>>
										&nbsp;&nbsp;
										<img src="<?php echo HTTP_ASSETS_PATH.'/images/help.png';?>" alt="Help" class="top-right tipso_style_custom" data-tipso="ENTER NUMBER OF PUMPS USED WITH RLB BOARD. e.g. 2" style="width:32px;">
									</td>
								</tr>
								  
								<tr><td colspan="3">&nbsp;</td></tr>
								<tr>
									<td width="10%"><strong>Enter Number of Valves: </strong></td>
									<td width="1%">&nbsp;</td>
									<td width="89%">
										<input type="text" name="numValve" id="numValve" value="<?php echo $numValve;?>" class="form-control inputBox" <?php if($sAccess == 1) { echo 'disabled="disabled"';} ?>>
										&nbsp;&nbsp;
										<img src="<?php echo HTTP_ASSETS_PATH.'/images/help.png';?>" alt="Help" class="top-right tipso_style_custom" data-tipso="ENTER NUMBER OF VALVES USED WITH RLB BOARD. e.g. 2" style="width:32px;">
									</td>
								</tr>
								  
								<tr><td colspan="3">&nbsp;</td></tr>
								<tr>
									<td width="10%"><strong>Enter Number of Lights: </strong></td>
									<td width="1%">&nbsp;</td>
									<td width="89%">
										<input type="text" name="numLight" id="numLight" value="<?php echo $numLight;?>" class="form-control inputBox" <?php if($sAccess == 1) { echo 'disabled="disabled"';} ?>>
										&nbsp;&nbsp;
										<img src="<?php echo HTTP_ASSETS_PATH.'/images/help.png';?>" alt="Help" class="top-right tipso_style_custom" data-tipso="ENTER NUMBER OF LIGHTS USED WITH RLB BOARD. e.g. 2" style="width:32px;">
									</td>
								</tr>
								  
								<tr><td colspan="3">&nbsp;</td></tr>
								<tr>
									<td width="10%"><strong>Enter Number of Heater: </strong></td>
									<td width="1%">&nbsp;</td>
									<td width="89%">
										<input type="text" name="numHeater" id="numHeater" value="<?php echo $numHeater;?>" class="form-control inputBox"  <?php if($sAccess == 1) { echo 'disabled="disabled"';} ?>>
										&nbsp;&nbsp;
										<img src="<?php echo HTTP_ASSETS_PATH.'/images/help.png';?>" alt="Help" class="top-right tipso_style_custom" data-tipso="ENTER NUMBER OF HEATERS USED WITH RLB BOARD. e.g. 2" style="width:32px;">
									</td>
								</tr>
								
								<tr><td colspan="3">&nbsp;</td></tr>
								<tr>
									<td width="10%"><strong>Do you have a solar heater?: </strong></td>
									<td width="1%">&nbsp;</td>
									<td width="89%">
										<input type="radio" name="numSolarHeater" id="numSolarHeater_0" 
										value="0" <?php if($numSolarHeater == '0') { echo 'checked="checked"'; } ?> >&nbsp;No&nbsp;&nbsp;
										<input type="radio" name="numSolarHeater" id="numSolarHeater_1" 
										value="1" <?php if($numSolarHeater == '1') { echo 'checked="checked"'; } ?> >&nbsp;Yes
										&nbsp;&nbsp;
										<img src="<?php echo HTTP_ASSETS_PATH.'/images/help.png';?>" alt="Help" class="top-right tipso_style_custom" data-tipso="SELECT IF YOU HAVE SOLAR HEATER." style="width:32px;">
									</td>
								</tr>
								  
								<tr><td colspan="3">&nbsp;</td></tr>
								<tr>
									<td width="10%"><strong>Enter Number of Blower: </strong></td>
									<td width="1%">&nbsp;</td>
									<td width="89%">
										<input type="text" name="numBlower" id="numBlower" value="<?php echo $numBlower;?>" class="form-control inputBox" <?php if($sAccess == 1) { echo 'disabled="disabled"';} ?>>
										&nbsp;&nbsp;
										<img src="<?php echo HTTP_ASSETS_PATH.'/images/help.png';?>" alt="Help" class="top-right tipso_style_custom" data-tipso="ENTER NUMBER OF BLOWERS USED WITH RLB BOARD. e.g. 2" style="width:32px;">
									</td>
								</tr>
								
								<tr><td colspan="3">&nbsp;</td></tr>
								<tr>
									<td width="10%"><strong>Enter Number of Miscellanious Device: </strong></td>
									<td width="1%">&nbsp;</td>
									<td width="89%">
										<input type="text" name="numMisc" id="numMisc" value="<?php echo $numMisc;?>" class="form-control inputBox" <?php if($sAccess == 1) { echo 'disabled="disabled"';} ?>>
										&nbsp;&nbsp;
										<img src="<?php echo HTTP_ASSETS_PATH.'/images/help.png';?>" alt="Help" class="top-right tipso_style_custom" data-tipso="ENTER NUMBER OF MISCELLANIOUS DEVICE USED WITH RLB BOARD. e.g. 2" style="width:32px;">
									</td>
								</tr>
								
								<tr><td colspan="3">&nbsp;</td></tr>
								<tr>
									<td width="10%"><strong>Do you have a remote switch?: </strong></td>
									<td width="1%">&nbsp;</td>
									<td width="89%">
										<input type="radio" onclick="showHideDisplay(this.value);" name="showRemoteSpa" value="0" <?php if((isset($extra['Remote_Spa']) && $extra['Remote_Spa'] == '0')) { echo 'checked="checked";';}?> checked="checked" <?php if($sAccess == 1) { echo 'disabled="disabled"';} ?>>&nbsp;No
										&nbsp;&nbsp;
										<input type="radio" onclick="showHideDisplay(this.value);" name="showRemoteSpa" value="1" <?php if((isset($extra['Remote_Spa']) && $extra['Remote_Spa'] == '1')) { echo 'checked="checked";';}?> <?php if($sAccess == 1) { echo 'disabled="disabled"';} ?>>&nbsp;Yes
										&nbsp;&nbsp;
										<img src="<?php echo HTTP_ASSETS_PATH.'/images/help.png';?>" alt="Help" class="top-right tipso_style_custom" data-tipso="SELECT IF YOU HAVE REMOTE SWITCH WITH RLB BOARD." style="width:32px;">
									</td>
								</tr>
								
								<tr id="displayRemoteBlank" <?php if($extra['Remote_Spa'] == '0' || $extra['Remote_Spa'] == ''){ echo 'style="display:none;"';}?>><td colspan="3">&nbsp;</td></tr>
								<tr id="displayRemote" <?php if($extra['Remote_Spa'] == '0' || $extra['Remote_Spa'] == ''){ echo 'style="display:none;"';}?>>
									<td width="10%"><strong>Do you want to display on Home page?: </strong></td>
									<td width="1%">&nbsp;</td>
									<td width="89%">
										<input type="radio" id="showRemoteSpaDisplay_0" name="showRemoteSpaDisplay" value="0" <?php if((isset($extra['Remote_Spa_display']) && $extra['Remote_Spa_display'] == '0')) { echo 'checked="checked";';}?> checked="checked" <?php if($sAccess == 1) { echo 'disabled="disabled"';} ?>>&nbsp;No
										&nbsp;&nbsp;
										<input type="radio" id="showRemoteSpaDisplay_1" name="showRemoteSpaDisplay" value="1" <?php if((isset($extra['Remote_Spa_display']) && $extra['Remote_Spa_display'] == '1')) { echo 'checked="checked";';}?> <?php if($sAccess == 1) { echo 'disabled="disabled"';} ?>>&nbsp;Yes
										&nbsp;&nbsp;
										<img src="<?php echo HTTP_ASSETS_PATH.'/images/help.png';?>" alt="Help" class="top-right tipso_style_custom" data-tipso="SELECT WHETHER YOU WANT TO SHOW REMOTE SWITCH ON HOME PAGE." style="width:32px;">
									</td>
								</tr>
							</table>
						</div>
						<div class="tab-pane fade in" id="IP2">
							<table border="0" cellspacing="0" cellpadding="0" width="100%" style="margin-left:20px; margin-top:20px; margin-bottom:20px;">
							<tr>
									<td width="24%"><strong>Do you have 2nd IP / Board?:</strong></td>
									<td width="1%">&nbsp;</td>
									<td width="75%">
										<input type="radio" name="secondIP" id="secondIPYes" value="1" <?php if($secondIP == '1'){ echo 'checked="checked"';}?>>&nbsp;YES
										&nbsp;&nbsp;
										<input type="radio" name="secondIP" id="secondIPNo" value="0" <?php if($secondIP == '0'){ echo 'checked="checked"';}?>>&nbsp;No
										&nbsp;&nbsp;
										<img src="<?php echo HTTP_ASSETS_PATH.'/images/help.png';?>" alt="Help" class="top-right tipso_style_custom" data-tipso="SELECT WHETHER YOU HAVE 2nd IP OR NOT!" style="width:32px;">
									</td>
								</tr>
								<tr><td colspan="3">&nbsp;</td></tr>
								
								<tr>
									<td width="24%"><strong>IP ADDRESS RLB BOARD 2:</strong></td>
									<td width="1%">&nbsp;</td>
									<td width="75%">
										<input type="text" class="form-control inputBox" placeholder="Enter ip address for RLB BOARD 2" name="relay_ip_address2" value="<?php echo $sIP2;?>" id="relay_ip_address2" <?php if($sAccess == 1) { echo 'disabled="disabled"';} ?>>
										&nbsp;&nbsp;
										<img src="<?php echo HTTP_ASSETS_PATH.'/images/help.png';?>" alt="Help" class="top-right tipso_style_custom" data-tipso="ENTER THE LOCAL IP ADDRESS WHERE YOUR RLB BOARD 2 IS LOCATED.(OPTIONAL) e.g.192.168.1.50" style="width:32px;">
										<?php if(IS_LOCAL == '1') { ?>
											&nbsp;<input type="text" class="form-control inputBox" name="relay_ip_address_ssh2" value="<?php echo $sShh2;?>" id="relay_ip_address_ssh2" <?php if($sAccess == 1) { echo 'disabled="disabled"';} ?> style="width:60px !important;">&nbsp;&nbsp;
											<img src="<?php echo HTTP_ASSETS_PATH.'/images/help.png';?>" alt="Help" class="top-right tipso_style_custom" data-tipso="ENTER SSH PORT FOR IP. e.g.23" style="width:32px;">
										<?php } ?>
										
									</td>
								</tr>
								
								<tr><td colspan="3">&nbsp;</td></tr>
								
								<tr>
									<td width="24%"><strong>NAME RLB BOARD 2:</strong></td>
									<td width="1%">&nbsp;</td>
									<td width="75%">
										<input type="text" class="form-control inputBox" placeholder="Enter name for RLB BOARD 2" name="relay_board_name2" value="<?php echo $sBoardName2;?>" id="relay_board_name2" <?php if($sAccess == 1) { echo 'disabled="disabled"';} ?>>
										&nbsp;&nbsp;
										<img src="<?php echo HTTP_ASSETS_PATH.'/images/help.png';?>" alt="Help" class="top-right tipso_style_custom" data-tipso="ENTER NAME FOR RLB BOARD 2(OPTIONAL). e.g.Relayboard2" style="width:32px;">
									</td>
								</tr>
								  
								<tr><td colspan="3">&nbsp;</td></tr>
								<tr>
									<td width="10%"><strong>Enter Number of Pumps: </strong></td>
									<td width="1%">&nbsp;</td>
									<td width="89%">
										<input type="text" name="numPumps2" id="numPumps2" value="<?php echo $numPumps2;?>" class="form-control inputBox" <?php if($sAccess == 1) { echo 'disabled="disabled"';} ?>>
										&nbsp;&nbsp;
										<img src="<?php echo HTTP_ASSETS_PATH.'/images/help.png';?>" alt="Help" class="top-right tipso_style_custom" data-tipso="ENTER NUMBER OF PUMPS USED WITH RLB BOARD. e.g. 2" style="width:32px;">
									</td>
								</tr>
								  
								<tr><td colspan="3">&nbsp;</td></tr>
								<tr>
									<td width="10%"><strong>Enter Number of Valves: </strong></td>
									<td width="1%">&nbsp;</td>
									<td width="89%">
										<input type="text" name="numValve2" id="numValve2" value="<?php echo $numValve2;?>" class="form-control inputBox" <?php if($sAccess == 1) { echo 'disabled="disabled"';} ?>>
										&nbsp;&nbsp;
										<img src="<?php echo HTTP_ASSETS_PATH.'/images/help.png';?>" alt="Help" class="top-right tipso_style_custom" data-tipso="ENTER NUMBER OF VALVES USED WITH RLB BOARD. e.g. 2" style="width:32px;">
									</td>
								</tr>
								  
								<tr><td colspan="3">&nbsp;</td></tr>
								<tr>
									<td width="10%"><strong>Enter Number of Lights: </strong></td>
									<td width="1%">&nbsp;</td>
									<td width="89%">
										<input type="text" name="numLight2" id="numLight2" value="<?php echo $numLight2;?>" class="form-control inputBox" <?php if($sAccess == 1) { echo 'disabled="disabled"';} ?>>
										&nbsp;&nbsp;
										<img src="<?php echo HTTP_ASSETS_PATH.'/images/help.png';?>" alt="Help" class="top-right tipso_style_custom" data-tipso="ENTER NUMBER OF LIGHTS USED WITH RLB BOARD. e.g. 2" style="width:32px;">
									</td>
								</tr>
								  
								<tr><td colspan="3">&nbsp;</td></tr>
								<tr>
									<td width="10%"><strong>Enter Number of Heater: </strong></td>
									<td width="1%">&nbsp;</td>
									<td width="89%">
										<input type="text" name="numHeater2" id="numHeater2" value="<?php echo $numHeater2;?>" class="form-control inputBox"  <?php if($sAccess == 1) { echo 'disabled="disabled"';} ?>>
										&nbsp;&nbsp;
										<img src="<?php echo HTTP_ASSETS_PATH.'/images/help.png';?>" alt="Help" class="top-right tipso_style_custom" data-tipso="ENTER NUMBER OF HEATERS USED WITH RLB BOARD. e.g. 2" style="width:32px;">
									</td>
								</tr>
								
								<tr><td colspan="3">&nbsp;</td></tr>
								<tr>
									<td width="10%"><strong>Do you have a solar heater?: </strong></td>
									<td width="1%">&nbsp;</td>
									<td width="89%">
										<input type="radio" name="numSolarHeater2" id="numSolarHeater_0_2" 
										value="0" <?php if($numSolarHeater2 == '0') { echo 'checked="checked"'; } ?> >&nbsp;No&nbsp;&nbsp;
										<input type="radio" name="numSolarHeater2" id="numSolarHeater_1_2" 
										value="1" <?php if($numSolarHeater2 == '1') { echo 'checked="checked"'; } ?> >&nbsp;Yes
										&nbsp;&nbsp;
										<img src="<?php echo HTTP_ASSETS_PATH.'/images/help.png';?>" alt="Help" class="top-right tipso_style_custom" data-tipso="SELECT IF YOU HAVE SOLAR HEATER." style="width:32px;">
									</td>
								</tr>
								  
								<tr><td colspan="3">&nbsp;</td></tr>
								<tr>
									<td width="10%"><strong>Enter Number of Blower: </strong></td>
									<td width="1%">&nbsp;</td>
									<td width="89%">
										<input type="text" name="numBlower2" id="numBlower2" value="<?php echo $numBlower2;?>" class="form-control inputBox" <?php if($sAccess == 1) { echo 'disabled="disabled"';} ?>>
										&nbsp;&nbsp;
										<img src="<?php echo HTTP_ASSETS_PATH.'/images/help.png';?>" alt="Help" class="top-right tipso_style_custom" data-tipso="ENTER NUMBER OF BLOWERS USED WITH RLB BOARD. e.g. 2" style="width:32px;">
									</td>
								</tr>
								
								<tr><td colspan="3">&nbsp;</td></tr>
								<tr>
									<td width="10%"><strong>Enter Number of Miscellanious Device: </strong></td>
									<td width="1%">&nbsp;</td>
									<td width="89%">
										<input type="text" name="numMisc2" id="numMisc2" value="<?php echo $numMisc2;?>" class="form-control inputBox" <?php if($sAccess == 1) { echo 'disabled="disabled"';} ?>>
										&nbsp;&nbsp;
										<img src="<?php echo HTTP_ASSETS_PATH.'/images/help.png';?>" alt="Help" class="top-right tipso_style_custom" data-tipso="ENTER NUMBER OF MISCELLANIOUS DEVICE USED WITH RLB BOARD. e.g. 2" style="width:32px;">
									</td>
								</tr>
								
								<tr><td colspan="3">&nbsp;</td></tr>
								<tr>
									<td width="10%"><strong>Do you have a remote switch?: </strong></td>
									<td width="1%">&nbsp;</td>
									<td width="89%">
										<input type="radio" onclick="showHideDisplay2(this.value);" name="showRemoteSpa2" value="0" <?php if((isset($extra['Remote_Spa2']) && $extra['Remote_Spa2'] == '0')) { echo 'checked="checked";';}?> checked="checked" <?php if($sAccess == 1) { echo 'disabled="disabled"';} ?>>&nbsp;No
										&nbsp;&nbsp;
										<input type="radio" onclick="showHideDisplay2(this.value);" name="showRemoteSpa2" value="1" <?php if((isset($extra['Remote_Spa2']) && $extra['Remote_Spa2'] == '1')) { echo 'checked="checked";';}?> <?php if($sAccess == 1) { echo 'disabled="disabled"';} ?>>&nbsp;Yes
										&nbsp;&nbsp;
										<img src="<?php echo HTTP_ASSETS_PATH.'/images/help.png';?>" alt="Help" class="top-right tipso_style_custom" data-tipso="SELECT IF YOU HAVE REMOTE SWITCH WITH RLB BOARD." style="width:32px;">
									</td>
								</tr>
								
								<tr id="displayRemoteBlank2" <?php if($extra['Remote_Spa2'] == '0' || $extra['Remote_Spa2'] == ''){ echo 'style="display:none;"';}?>><td colspan="3">&nbsp;</td></tr>
								<tr id="displayRemote2" <?php if($extra['Remote_Spa2'] == '0' || $extra['Remote_Spa2'] == ''){ echo 'style="display:none;"';}?>>
									<td width="10%"><strong>Do you want to display on Home page?: </strong></td>
									<td width="1%">&nbsp;</td>
									<td width="89%">
										<input type="radio" id="showRemoteSpaDisplay_0_2" name="showRemoteSpaDisplay2" value="0" <?php if((isset($extra['Remote_Spa_display2']) && $extra['Remote_Spa_display2'] == '0')) { echo 'checked="checked";';}?> checked="checked" <?php if($sAccess == 1) { echo 'disabled="disabled"';} ?>>&nbsp;No
										&nbsp;&nbsp;
										<input type="radio" id="showRemoteSpaDisplay_1_2" name="showRemoteSpaDisplay2" value="1" <?php if((isset($extra['Remote_Spa_display2']) && $extra['Remote_Spa_display2'] == '1')) { echo 'checked="checked";';}?> <?php if($sAccess == 1) { echo 'disabled="disabled"';} ?>>&nbsp;Yes
										&nbsp;&nbsp;
										<img src="<?php echo HTTP_ASSETS_PATH.'/images/help.png';?>" alt="Help" class="top-right tipso_style_custom" data-tipso="SELECT WHETHER YOU WANT TO SHOW REMOTE SWITCH ON HOME PAGE." style="width:32px;">
									</td>
								</tr>
							</table>
						</div>
					</div>
					
					
					<div style="padding-left:20px; padding-bottom:20px;">
						  <!--<a href="javascript:void(0);" <?php if($sAccess == 2) { ?> onclick="checkModeSelected();" <?php } ?> class="btn btn-green"><span>Save Setting</span></a>-->
						  <?php if($sAccess == 2) { ?>
						  <span class="btn btn-green"><input type="submit" name="command" value="Save Setting" onclick="return checkModeSelected();" /></span>
						  &nbsp;&nbsp;
						  <?php } ?>
						  <a href="javascript:void(0);" onclick="location.href='<?php echo base_url();?>';" class="btn btn-gray"><span>Cancel</span></a>
					</div>
				</div>
            </div>
			</form>
        </div><!-- /.row -->  
	</div><!-- /#page-wrapper -->
<script type="text/javascript">
$(document).ready(function (){
	
	jQuery('.top-right').tipso({
				position: 'top-right',
				background: '#000000',
				useTitle: false
			});
	
	
});
  function checkModeSelected()
  {
    var manualMinutes	=	$("#manualMinutes").val();
	//$("#command").val('');
    
	if(manualMinutes != '')
	{
		if(isNaN(manualMinutes))
		{
			$("#manualMinutes").css('border','1px solid #B40404');
			alert("Please enter valid minutes!")
			return false;
		}
		else
		{
			$("#manualMinutes").css('border','');
			
		}
	}
	
	var relay_ip_address = $("#relay_ip_address").val();
	if(relay_ip_address == '')	 
	{
		alert("Please enter IP ADDRESS RLB BOARD 1!");
		$("#relay_ip_address").css('border','1px Solid #FF0000');
		return false;
	}
	else
	{
		$("#relay_ip_address").css('border','');
	}
	<?php if(IS_LOCAL == '1') { ?>
		var relay_ip_address_ssh1 = $("#relay_ip_address_ssh1").val();
		if(relay_ip_address_ssh1 == '')	 
		{
			alert("Please enter SSH PORT For IP ADDRESS RLB BOARD 1!");
			$("#relay_ip_address_ssh1").css('border','1px Solid #FF0000');
			return false;
		}
		else
		{
			$("#relay_ip_address_ssh1").css('border','');
		}
	<?php } ?>
	var relay_port_no = $("#relay_port_no").val();
	
	if(relay_port_no == '')	 
	{
		alert("Please enter PORT NO!");
		$("#relay_port_no").css('border','1px Solid #FF0000');
		return false;
	}
	else
	{
		$("#relay_port_no").css('border','');
	}
	
	//$("#command").val('Save Setting');
	//document.settingForm.submit();
	return true;
	

  }
  
  function showHideDisplay(val)
  {
	  if(val == '0')
	  {
			$('#showRemoteSpaDisplay_0').prop('checked',true);
			$("#displayRemote").hide();
			$("#displayRemoteBlank").hide();
	  }
	  else
	  {
			$("#displayRemote").show();
			$("#displayRemoteBlank").show();
	  }
  }
  
  function showHideDisplay2(val)
  {
	  if(val == '0')
	  {
			$('#showRemoteSpaDisplay_0_2').prop('checked',true);
			$("#displayRemote2").hide();
			$("#displayRemoteBlank2").hide();
	  }
	  else
	  {
			$("#displayRemote2").show();
			$("#displayRemoteBlank2").show();
	  }
  }
  
  
</script>
<?php

?>