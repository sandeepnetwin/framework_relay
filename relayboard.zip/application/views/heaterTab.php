<h3>Heater Setting</h3>
<section>
<div class="col-sm-12">
	<label for="automatic_heaters_question1">How many heaters do you have?<span class="requiredMark">*</span>&nbsp;<img src="<?php echo HTTP_ASSETS_PATH.'images/help.png';?>" width="24" class="tooltipster-icon" title="Please select number of Heater used in the mode?" /></label><a class="changeLink" id="changeLinkHeater" href="javascript:void(0);" onclick="javascript:$('#heaterForm').toggleClass('disableConfig');" style="float:right;" title="Click here to Enable/Disable Heater related settings!">Enable/Disable Heater Configuration</a>
	<select name="automatic_heaters_question1" id="automatic_heaters_question1" class="form-control required" onchange="showHeater();">
	<option <?php if(isset($arrHeater['heater']) &&  $arrHeater['heater'] == '0'){echo 'selected="selected"';}?> value="0">0 Heater</option>
		<option <?php if(isset($arrHeater['heater']) &&  $arrHeater['heater'] == '1'){echo 'selected="selected"';}?> value="1">1 Heater</option>
		<option <?php if(isset($arrHeater['heater']) &&  $arrHeater['heater'] == '2'){echo 'selected="selected"';}?> value="2">2 Heater</option>
		<option <?php if(isset($arrHeater['heater']) &&  $arrHeater['heater'] == '3'){echo 'selected="selected"';}?> value="3">3 Heater</option>
	</select>
</div>
<div style="height:10px">&nbsp;</div>
<div class="col-sm-6">
	<table width="100%">
	<tr id="trHeaterWork1" style="display:<?php if(isset($arrHeater['heater']) &&  $arrHeater['heater'] >= 1){echo '';}else{echo 'none';}?>;"><td>
	<label for="Heater1">Heater 1?<span class="requiredMark">*</span></label>
	<select name="Heater1" id="Heater1" class="form-control">
		<option <?php if(isset($arrHeater['Heater1']) &&  $arrHeater['Heater1'] == 'Pool spa Combo'){echo 'selected="selected"';}?> value="Pool spa Combo">Heat pool and spa</option>
		<option <?php if(isset($arrHeater['Heater1']) &&  $arrHeater['Heater1'] == 'Pool Only'){echo 'selected="selected"';}?> value="Pool Only">Heat pool</option>
		<option <?php if(isset($arrHeater['Heater1']) &&  $arrHeater['Heater1'] == 'Spa Only'){echo 'selected="selected"';}?> value="Spa Only">Heat spa</option>
		<option <?php if(isset($arrHeater['Heater1']) &&  $arrHeater['Heater1'] == 'Heat off'){echo 'selected="selected"';}?> value="Heat off">Heat off</option>
	</select>
	</td></tr>
	<tr id="trHeaterWork2" style="display:<?php if(isset($arrHeater['heater']) &&  $arrHeater['heater'] >= 2){echo '';}else{echo 'none';}?>;"><td>
	<div style="height:10px">&nbsp;</div>
	<label for="Heater2">Heater 2?<span class="requiredMark">*</span></label>
	<select name="Heater2" id="Heater2" class="form-control">
		<option <?php if(isset($arrHeater['Heater2']) &&  $arrHeater['Heater2'] == 'Pool spa Combo'){echo 'selected="selected"';}?> value="Pool spa Combo">Heat pool and spa</option>
		<option <?php if(isset($arrHeater['Heater2']) &&  $arrHeater['Heater2'] == 'Pool Only'){echo 'selected="selected"';}?> value="Pool Only">Heat pool</option>
		<option <?php if(isset($arrHeater['Heater2']) &&  $arrHeater['Heater2'] == 'Spa Only'){echo 'selected="selected"';}?> value="Spa Only">Heat spa</option>
		<option <?php if(isset($arrHeater['Heater2']) &&  $arrHeater['Heater2'] == 'Heat off'){echo 'selected="selected"';}?> value="Heat off">Heat off</option>
	</select>
	</td></tr>
	<tr id="trHeaterWork3" style="display:<?php if(isset($arrHeater['heater']) &&  $arrHeater['heater'] >= 3){echo '';}else{echo 'none';}?>;"><td>
	<div style="height:10px">&nbsp;</div>
	<label for="Heater3">Heater 3?<span class="requiredMark">*</span></label>
	<select name="Heater3" id="Heater3" class="form-control">
		<option <?php if(isset($arrHeater['Heater3']) &&  $arrHeater['Heater3'] == 'Pool spa Combo'){echo 'selected="selected"';}?> value="Pool spa Combo">Heat pool and spa</option>
		<option <?php if(isset($arrHeater['Heater3']) &&  $arrHeater['Heater3'] == 'Pool Only'){echo 'selected="selected"';}?> value="Pool Only">Heat pool</option>
		<option <?php if(isset($arrHeater['Heater3']) &&  $arrHeater['Heater3'] == 'Spa Only'){echo 'selected="selected"';}?> value="Spa Only">Heat spa</option>
		<option <?php if(isset($arrHeater['Heater3']) &&  $arrHeater['Heater3'] == 'Heat off'){echo 'selected="selected"';}?> value="Heat off">Heat off</option>
	</select>
	</td></tr>
	</table>
	</table>
	</div>
	<div class="col-sm-6">
	<table width="100%">
	<tr id="trHeaterPump1" style="display:<?php if(isset($arrHeater['heater']) &&  $arrHeater['heater'] >= 1){echo '';}else{echo 'none';}?>;"><td>
	<label for="HeaterPump1">Which Pump used in order to operate Heater 1?<span class="requiredMark">*</span></label>
	<select name="HeaterPump1" id="HeaterPump1" class="form-control">
		<option <?php if(isset($arrHeater['HeaterPump1']) &&  $arrHeater['HeaterPump1'] == '1'){echo 'selected="selected"';}?> value="1">Pump1</option>
		<?php if(isset($arrHeater['heater']) &&  $arrHeater['heater'] >= 2) {?>
		<option <?php if(isset($arrHeater['HeaterPump1']) &&  $arrHeater['HeaterPump1'] == '2'){echo 'selected="selected"';}?> value="2">Pump2</option>
		<?php } if(isset($arrHeater['heater']) &&  $arrHeater['heater'] >= 3) {?>
		<option <?php if(isset($arrHeater['HeaterPump1']) &&  $arrHeater['HeaterPump1'] == '3'){echo 'selected="selected"';}?> value="3">Pump3</option>
		<?php } ?>
	</select>
	</td></tr>
	<tr id="trHeaterPump2" style="display:<?php if(isset($arrHeater['heater']) &&  $arrHeater['heater'] >= 2){echo '';}else{echo 'none';}?>;"><td>
	<div style="height:10px">&nbsp;</div>
	<label for="HeaterPump2">Which Pump used in order to operate Heater 2?<span class="requiredMark">*</span></label>
	<select name="HeaterPump2" id="HeaterPump2" class="form-control">
		<option <?php if(isset($arrHeater['HeaterPump2']) &&  $arrHeater['HeaterPump2'] == '1'){echo 'selected="selected"';}?> value="1">Pump1</option>
		<?php if(isset($arrHeater['heater']) &&  $arrHeater['heater'] >= 2) {?>
		<option <?php if(isset($arrHeater['HeaterPump2']) &&  $arrHeater['HeaterPump2'] == '2'){echo 'selected="selected"';}?> value="2">Pump2</option>
		<?php } if(isset($arrHeater['heater']) &&  $arrHeater['heater'] >= 3) {?>
		<option <?php if(isset($arrHeater['HeaterPump2']) &&  $arrHeater['HeaterPump2'] == '3'){echo 'selected="selected"';}?> value="3">Pump3</option>
		<?php } ?>
	</select>
	</td></tr>
	<tr id="trHeaterPump3" style="display:<?php if(isset($arrHeater['heater']) &&  $arrHeater['heater'] >= 3){echo '';}else{echo 'none';}?>;"><td>
	<div style="height:10px">&nbsp;</div>
	<label for="HeaterPump3">Which Pump used in order to operate Heater 3?<span class="requiredMark">*</span></label>
	<select name="HeaterPump3" id="HeaterPump3" class="form-control">
		<option <?php if(isset($arrHeater['HeaterPump3']) &&  $arrHeater['HeaterPump3'] == '1'){echo 'selected="selected"';}?> value="1">Pump1</option>
		<?php if(isset($arrHeater['heater']) &&  $arrHeater['heater'] >= 2) {?>
		<option <?php if(isset($arrHeater['HeaterPump3']) &&  $arrHeater['HeaterPump3'] == '2'){echo 'selected="selected"';}?> value="2">Pump2</option>
		<?php } if(isset($arrHeater['heater']) &&  $arrHeater['heater'] >= 3) {?>
		<option <?php if(isset($arrHeater['HeaterPump3']) &&  $arrHeater['HeaterPump3'] == '3'){echo 'selected="selected"';}?> value="3">Pump3</option>
		<?php } ?>
	</select>
	</td></tr>
	</table>
	<div style="height:10px">&nbsp;</div>
	</div>
	
	<div class="col-sm-12">
			<div class="col-sm-4" style="padding-left:0px;">
				<div class="controls boxed green-line" style="min-height:210px;">
					<div class="inner">
						<h3 class="profile-title"><strong style="color:#C9376E;">Assign Heater</strong></h3>
						<div id="contentsHeater">
						</div>
					</div>
				</div>	
			</div>
			
			<div class="col-sm-8">
			<div id="heaterForm" class="disableConfig">	
		<div style="margin-bottom:10px;"><h3 class="confHeader">Heater Configuration</h3></div>
		<table class="table removeBorder" id="heaterTable" width="100%" cellspacing="0" cellpadding="0">
			<tbody>
				<tr>
					<td style="width:48%;">Enter Number of Heater to Use in system:</td>
					<td style="width:2%;">&nbsp;</td>
					<td style="width:50%;"><input type="text" name="heaterNumber" id="heaterNumber" onkeyup="showHeaterDetails();" value="<?php if(isset($extra['HeaterNumber']) && $extra['HeaterNumber'] != 0) { echo $extra['HeaterNumber'];}?>" class="form-control inputText"></td>
				</tr>
				<?php for($i=1;$i<9;$i++)
					  {
				?>
						<tr id="heaterDetails_<?php echo $i;?>" style="display:<?php if(isset($extra['HeaterNumber']) && $i <= $extra['HeaterNumber']) { echo ''; } else { echo 'none;';}?>">
							<td colspan="3">
								<table border="0" cellspacing="0" cellpadding="0" width="100%">
									<tr><td colspan="3"><strong>Heater <?php echo $i;?></strong></td></tr>
									<tr>
									<td width="48%">How do you turn on your Heater <?php echo $i;?>?</td>
									<td width="2%">&nbsp;</td>
									<td width="50%">
										<select onchange="showRelays(this.value,'<?php echo $i;?>');" class="form-control valid" id="heater<?php echo $i;?>_equiment" name="heater<?php echo $i;?>_equiment">
											<option value="24">24V AC Relays</option>
											<option value="12">12V DC Relays</option>
										</select>
									</td>
									</tr>
									<tr><td colspan="3">&nbsp;</td></tr>
									<tr id="trHeaterSub<?php echo $i;?>_24">
									<td width="48%"><label for="heater<?php echo $i;?>_sub_equiment_24">Select 24V Relay<span class="requiredMark">*</span></label></td>
									<td width="2%">&nbsp;</td>
									<td width="50%">
									<select name="heater<?php echo $i;?>_sub_equiment_24" id="heater<?php echo $i;?>_sub_equiment_24" class="form-control">
										<option value="">Select Relay</option>
										<?php foreach($sRelays as $relay) {
										?>
											<option value="<?php echo $relay;?>">Relay <?php echo $relay;?></option>
										<?php } ?>
									</select>
									</td>
									</tr>
				
									<tr id="trHeaterSub<?php echo $i;?>_12" style="display:none;">
									<td width="48%"><label for="heater<?php echo $i;?>_sub_equiment_12">Select 12V Relay<span class="requiredMark">*</span></label></td>
									<td width="2%">&nbsp;</td>
									<td width="50%">
										<select name="heater<?php echo $i;?>_sub_equiment_12" id="heater<?php echo $i;?>_sub_equiment_12" class="form-control">
											<option value="">Select Relay</option>
											<?php foreach($sPowercenter as $relay) { ?>
											<option value="<?php echo $relay;?>">Relay <?php echo $relay;?></option>
											<?php } ?>
										</select>
									</td></tr>
									
									<tr><td colspan="3"><hr style="border-color:#000;" /></td></tr>
								</table>
							</td>
						</tr>
				<?php 
					  }
				?>	
				<tr id="heaterSaveConf" style="display:<?php if($extra['HeaterNumber'] == 0){ echo 'none;';}?>"><td colspan="3"><a href="javascript:void(0);" onclick="checkAndSaveHeater();" class="btn btn-middle"><span>Save</span></a>&nbsp;&nbsp;<span id="loadingImgHeater" style="display:none; vertical-align: middle;"><img src="<?php echo site_url('assets/images/loading.gif');?>" alt="Loading...." width="32" height="32"></span></td></tr>
			</tbody>
		</table>
	</div>
			</div>
	</div>
</section>