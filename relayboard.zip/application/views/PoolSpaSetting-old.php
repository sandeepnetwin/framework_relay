<?php


$sAccess 		 = '';
$sModule	    = 2;

//Get Permission Details
$userID = $this->session->userdata('id');
$aPermissions = json_decode(getPermissionOfModule($userID));

$aModules 		= $aPermissions->sPermissionModule;	
$aAllActiveModule = $aPermissions->sActiveModule;

$sAccessKey	= 'access_'.$sModule;

if(!empty($aModules))
{
  if(in_array($sModule,$aModules->ids))
  {
	 $sAccess 		= $aModules->$sAccessKey;
  }
  else if(!in_array($sModule,$aModules->ids)) 
  {
	$sAccess 		= '0'; 
  }
}

if($sAccess == '')
$sAccess = '2' ;

$arrGeneral = '';
$arrDevice 	= '';
$arrHeater 	= '';
$arrMore	= '';

if(!empty($arrDetails))
{
	if(isset($arrDetails['General']))
		$arrGeneral = unserialize($arrDetails['General']);
	if(isset($arrDetails['Device']))
		$arrDevice = unserialize($arrDetails['Device']);
	if(isset($arrDetails['Heater']))
		$arrHeater = unserialize($arrDetails['Heater']);
	if(isset($arrDetails['More']))
		$arrMore = unserialize($arrDetails['More']);
}

?>
<style>
.requiredMark
{
	color: #ff0000;
}
.questionText
{
	line-height:15px;
}
.trClass
{
	vertical-align:top !important;
}
.inputText
{
	height:35px !important;
}
.content
{
	padding:0px !important;
	overflow-y: scroll;
}
</style>
<link rel="stylesheet" href="<?php echo HTTP_ASSETS_PATH.'steps/css/jquery.steps.css';?>">

<script src="<?php echo HTTP_ASSETS_PATH.'steps/lib/modernizr-2.6.2.min.js';?>"></script>
<script src="<?php echo HTTP_ASSETS_PATH.'steps/lib/jquery.cookie-1.3.1.js';?>"></script>
<script src="<?php echo HTTP_ASSETS_PATH.'steps/build/jquery.steps.js';?>"></script>
<script src="<?php echo HTTP_ASSETS_PATH.'steps/main.js';?>"></script>
<script type="text/javascript">
	$(function ()
	{
		
	});
	function valveChange()
	{
		var valveNumber	=	$('#strValve').val();
		
		for (i = 0; i <= valveNumber; i++) 
		{
			if(i == 0)
				$("#valve_actuated").html('<option value="">Select Valve Quantity</option><option value="'+i+'">Valve '+i+' is actuated</option>');
			else
				$("#valve_actuated").append('<option value="'+i+'">Valve '+i+' is actuated</option>');
		}
	}
	
	function pumpChange()
	{
		var pumpNumber	=	$('#automatic_pumps').val();
		
		for (i = 1; i <= pumpNumber; i++) 
		{
			$("#trPump"+i).show();
		}
		
		for (i = (parseInt(pumpNumber)+1); i <= 3; i++) 
		{
			$("#trPump"+i).hide();
		}
		//if(pumpNumber == 1 || pumpNumber == 2)
			//$(".content").css('height','auto');
		//if(pumpNumber == 3)
			//$(".content").css('height','530px');
	}
	
	function showHeater()
	{
		var heaterNumber	=	$('#automatic_heaters_question1').val();
		
		for (i = 1; i <= heaterNumber; i++) 
		{
			$("#trHeater"+i).show();
			$("#trHeaterWork"+i).show();
			$("#trHeaterPump"+i).show();
		}		
		
		for (i = (parseInt(heaterNumber)+1); i <= 3; i++) 
		{
			$("#trHeater"+i).hide();
			$("#trHeaterWork"+i).hide();
			$("#trHeaterPump"+i).hide();
		}
		
		for (i = 1; i <= heaterNumber; i++) 
		{
			for(j = 1; j <= heaterNumber; j++)
			{
				if(j == 1)
					$("#HeaterPump"+i).html('<option value="'+j+'">Pump '+j+'</option>');
				else 
					$("#HeaterPump"+i).append('<option value="'+j+'">Pump '+j+'</option>');	
			}
		}
	}
	
	function checkType(type)
	{
		if(type == '')
		{
			$("#pool_maximum_temperature").attr('readonly','readonly');
			$("#pool_temperature").attr('readonly','readonly');
			$("#pool_manual").attr('readonly','readonly');
			$("#display_pool_temp").attr('disabled','disabled');
			$("#display_spa_temp").attr('disabled','disabled');
			$("#spa_maximum_temperature").attr('readonly','readonly');
			$("#spa_temperature").attr('readonly','readonly');
			$("#spa_manual").attr('readonly','readonly');
		}
		else if(type == 'spa')
		{
			$("#spa_maximum_temperature").removeAttr('readonly').addClass('required');
			$("#spa_temperature").removeAttr('readonly').addClass('required');
			$("#spa_manual").removeAttr('readonly').addClass('required');
			$("#display_spa_temp").removeAttr('disabled').addClass('required');
			
			$("#pool_maximum_temperature").attr('readonly','readonly').removeClass('required');
			$("#pool_temperature").attr('readonly','readonly').removeClass('required');
			$("#pool_manual").attr('readonly','readonly').removeClass('required');
			$("#display_pool_temp").attr('disabled','disabled').removeClass('required');
		}
		else if(type == 'pool')
		{
			$("#pool_maximum_temperature").removeAttr('readonly').addClass('required');
			$("#pool_temperature").removeAttr('readonly').addClass('required');
			$("#pool_manual").removeAttr('readonly').addClass('required');
			$("#display_pool_temp").removeAttr('disabled').addClass('required');
			
			$("#spa_maximum_temperature").attr('readonly','readonly').removeClass('required');
			$("#spa_temperature").attr('readonly','readonly').removeClass('required');
			$("#spa_manual").attr('readonly','readonly').removeClass('required');
			$("#display_spa_temp").attr('disabled','disabled').removeClass('required');
		}
		else if(type == 'both')
		{
			$("#pool_maximum_temperature").removeAttr('readonly').addClass('required');
			$("#pool_temperature").removeAttr('readonly').addClass('required');
			$("#pool_manual").removeAttr('readonly').addClass('required');
			$("#display_pool_temp").removeAttr('disabled').addClass('required');
			$("#spa_maximum_temperature").removeAttr('readonly').addClass('required');
			$("#spa_temperature").removeAttr('readonly').addClass('required');
			$("#spa_manual").removeAttr('readonly').addClass('required');
			$("#display_spa_temp").removeAttr('disabled').addClass('required');
		}
		
	}

</script>
<div class="row">
	<div class="col-lg-12">
		<ol class="breadcrumb">
		  <li><img src="<?php echo HTTP_IMAGES_PATH.'icons/home.png';?>" width="24" style="vertical-align: middle !important;">&nbsp;<a href="<?php echo site_url();?>">Home</a> </li>
		  <li class="active">Pool & Spa Setting</li>
		</ol>
	</div>
</div>

<div class="row">
	<div class="col-lg-12">
		<div><span style="color:#FFF;"><strong>Edit Pool & Spa Automation Question To Set Up Their Equipment Properly<strong></span><span style="color:#FF0000; float:right;"><strong>* indicates required field</strong></span></div>
	</div>
</div>
<div class="row">
<div class="col-lg-12">&nbsp;</div>
</div>
<div class="row">
<div class="col-lg-12">
	<!-- Tabs -->
    <script type="text/javascript">

$(function ()
 {
    var form = $("#formPoolSpa");
     form.validate({
        errorPlacement: function errorPlacement(error, element) { element.before(error); },
        rules: {
            confirm: {
                equalTo: "#password"
            }
        }
    }); 
    form.children("div").steps({
        headerTag: "h3",
        bodyTag: "section",
        transitionEffect: "slideLeft",
        onStepChanging: function (event, currentIndex, newIndex)
        {
            form.validate().settings.ignore = ":disabled,:hidden";
            return form.valid();
        },
        onFinishing: function (event, currentIndex)
        {
            form.validate().settings.ignore = ":disabled";
            return form.valid();
        },
        onFinished: function (event, currentIndex)
        {
            //alert("Submitted!");
			//document.formPoolSpa.submit();
			$("#formPoolSpa").submit();
        }
    });
 });

</script>  
    <form id="formPoolSpa" name="formPoolSpa" action="<?php echo base_url('home/PoolSpaSetting/');?>" method="post">
	<input type="hidden" name="command" id="command" value="save">
        <div>
            <h3>General</h3>
			<section>
			<div class="col-sm-6">
                <label for="strType">Do you have a pool only, spa only and or a pool and spa?:<span class="requiredMark">*</span></label>
                <select name="strType" id="strType" class="form-control required" onchange="checkType(this.value)">
					<option <?php if(isset($arrGeneral['type']) && $arrGeneral['type'] == ''){ echo 'selected="selected"';} ?> value="">Select Type</option>
					<option <?php if(isset($arrGeneral['type']) && $arrGeneral['type'] == 'pool'){ echo 'selected="selected"';} ?> value="pool">Pool only</option>
					<option <?php if(isset($arrGeneral['type']) && $arrGeneral['type'] == 'spa'){ echo 'selected="selected"';} ?> value="spa">Spa only</option>
					<option <?php if(isset($arrGeneral['type']) && $arrGeneral['type'] == 'both'){ echo 'selected="selected"';} ?> value="both">Pool and Spa</option>
				</select>
				<div style="height:10px">&nbsp;</div>
                <label for="strEquipment">How do you control your equipment?<span class="requiredMark">*</span></label>
                <select name="strEquipment" id="strEquipment" class="form-control required">
					<option <?php if(isset($arrGeneral['equip']) && $arrGeneral['equip'] == ''){ echo 'selected="selected"';} ?> value="">Select Equipment</option>
					<option <?php if(isset($arrGeneral['equip']) && $arrGeneral['equip'] == '1'){ echo 'selected="selected"';} ?> value="1">RLB Board</option>
					<option <?php if(isset($arrGeneral['equip']) && $arrGeneral['equip'] == '2'){ echo 'selected="selected"';} ?> value="2">Other or Manually Operated</option>
					<option <?php if(isset($arrGeneral['equip']) && $arrGeneral['equip'] == '3'){ echo 'selected="selected"';} ?> value="3">Both</option>
				</select>
				<div style="height:10px">&nbsp;</div>
				<?php
					$strPoolRequired	=	'';
					$strSpaRequired		=	'';
					if(isset($arrGeneral['type']) && $arrGeneral['type'] == 'pool')
					{
						$strPoolRequired		=	'Yes';
					}
					if(isset($arrGeneral['type']) && $arrGeneral['type'] == 'spa')
					{
						$strSpaRequired			=	'Yes';
					}
					if(isset($arrGeneral['type']) && $arrGeneral['type'] == 'both')
					{
						$strPoolRequired		=	'Yes';
						$strSpaRequired			=	'Yes';
					}
				?>
                <label for="pool_maximum_temperature">What is the maximum temperature expressed in Fahrenheit that you would like to be able to set the pool temperature to ?<span class="requiredMark">*</span></label>
               <input type="text" name="pool_maximum_temperature" value="<?php if(isset($arrGeneral['pool_max_temp']) && $arrGeneral['pool_max_temp'] != '') { echo $arrGeneral['pool_max_temp'];}?>" id="pool_maximum_temperature" class="form-control inputText <?php if($strPoolRequired == 'Yes') { echo 'required';} ?>" <?php if($strPoolRequired == '') { echo 'readonly="readonly"';} ?>>
			   <div style="height:10px">&nbsp;</div>
                <label for="pool_temperature">Desire pool temperature when user is in Pool Mode?<span class="requiredMark">*</span></label>
               <input type="text" name="pool_temperature" value="<?php if(isset($arrGeneral['pool_temp']) && $arrGeneral['pool_temp'] != '') { echo $arrGeneral['pool_temp'];}?>" id="pool_temperature" class="form-control inputText <?php if($strPoolRequired == 'Yes') { echo 'required';} ?>" <?php if($strPoolRequired == '') { echo 'readonly="readonly"';} ?>>
			   <div style="height:10px">&nbsp;</div>
                <label for="pool_manual">The maximum allotted time for Pool Manual Mode expressed in minutes?<span class="requiredMark">*</span></label>
               <input type="text" name="pool_manual" value="<?php if(isset($arrGeneral['pool_manual']) && $arrGeneral['pool_manual'] != '') { echo $arrGeneral['pool_manual'];}?>" id="pool_manual" class="form-control inputText <?php if($strPoolRequired == 'Yes') { echo 'required';} ?>" <?php if($strPoolRequired == '') { echo 'readonly="readonly"';} ?>>
				
			</div>
			<div class="col-sm-6">
                <label for="display_pool_temp">Display Pool Temp on mode Page yes or no?<span class="requiredMark">*</span></label>
                <select name="display_pool_temp" id="display_pool_temp" class="form-control <?php if($strPoolRequired == 'Yes') { echo 'required';} ?>" <?php if($strPoolRequired == '') { echo 'disabled="disabled"';} ?>>
						<option <?php if(isset($arrGeneral['display_pool_temp']) && $arrGeneral['display_pool_temp'] == 'Yes'){ echo 'selected="selected"';} ?> value="Yes">Yes</option>
						<option <?php if(isset($arrGeneral['display_pool_temp']) && $arrGeneral['display_pool_temp'] == 'No'){ echo 'selected="selected"';} ?> value="No">No</option>
					</select>
				<div style="height:10px">&nbsp;</div>
                <label for="display_spa_temp">Display Spa Temp on mode Page yes or no?<span class="requiredMark">*</span></label>
                <select name="display_spa_temp" id="display_spa_temp" class="form-control <?php if($strSpaRequired == 'Yes') { echo 'required';} ?>" <?php if($strSpaRequired == '') { echo 'disabled="disabled"';} ?>>
						<option <?php if(isset($arrGeneral['display_spa_temp']) && $arrGeneral['display_spa_temp'] == 'Yes'){ echo 'selected="selected"';} ?> value="Yes">Yes</option>
						<option <?php if(isset($arrGeneral['display_spa_temp']) && $arrGeneral['display_spa_temp'] == 'No'){ echo 'selected="selected"';} ?> value="No">No</option>
				</select>
				<div style="height:10px">&nbsp;</div>
                <label for="pool_temperature">What is the maximum temperature expressed in Fahrenheit that you would like to be able to set the spa temperature to?<span class="requiredMark">*</span></label>
               <input type="text" name="spa_maximum_temperature" value="<?php if(isset($arrGeneral['spa_max_temp']) && $arrGeneral['spa_max_temp'] != '') { echo $arrGeneral['spa_max_temp'];}?>" id="spa_maximum_temperature" class="form-control inputText <?php if($strSpaRequired == 'Yes') { echo 'required';} ?>" <?php if($strSpaRequired == '') { echo 'readonly="readonly"';} ?>>
			   <div style="height:10px">&nbsp;</div>
                <label for="spa_temperature">Desire spa temperature when user is in Spa Mode?<span class="requiredMark">*</span></label>
               <input type="text" name="spa_temperature" value="<?php if(isset($arrGeneral['spa_temperature']) && $arrGeneral['spa_temperature'] != '') { echo $arrGeneral['spa_temperature'];}?>" id="spa_temperature" class="form-control inputText <?php if($strSpaRequired == 'Yes') { echo 'required';} ?>" <?php if($strSpaRequired == '') { echo 'readonly="readonly"';} ?>>
			   <div style="height:10px">&nbsp;</div>
                <label for="spa_manual">The maximum allotted time for Spa Mode expressed in minutes?<span class="requiredMark">*</span><br><br></label>
               <input type="text" name="spa_manual" value="<?php if(isset($arrGeneral['spa_manual']) && $arrGeneral['spa_manual'] != '') { echo $arrGeneral['spa_manual'];}?>" id="spa_manual" class="form-control inputText <?php if($strSpaRequired == 'Yes') { echo 'required';} ?>" <?php if($strSpaRequired == '') { echo 'readonly="readonly"';} ?>>
           
			</div>
			</section>
            <h3>Device</h3>
            <section>
			<div class="col-sm-6">
                <label for="strValve">How many AUTOMATIC valves do you have on your pool and or pool/spa system?<span class="requiredMark">*</span></label>
                <select name="strValve" id="strValve" class="form-control required" onchange="valveChange();">
					<option <?php if(isset($arrDevice['valve']) && $arrDevice['valve'] == ''){ echo 'selected="selected"';} ?> value="">Select valves</option>
					<option <?php if(isset($arrDevice['valve']) && $arrDevice['valve'] == '0'){ echo 'selected="selected"';} ?> value="0">0 Valves</option>
					<option <?php if(isset($arrDevice['valve']) && $arrDevice['valve'] == '1'){ echo 'selected="selected"';} ?> value="1">1 Valves</option>
					<option <?php if(isset($arrDevice['valve']) && $arrDevice['valve'] == '2'){ echo 'selected="selected"';} ?> value="2">2 Valves</option>
					<option <?php if(isset($arrDevice['valve']) && $arrDevice['valve'] == '3'){ echo 'selected="selected"';} ?> value="3">3 Valves</option>
					<option <?php if(isset($arrDevice['valve']) && $arrDevice['valve'] == '4'){ echo 'selected="selected"';} ?> value="4">4 Valves</option>
					<option <?php if(isset($arrDevice['valve']) && $arrDevice['valve'] == '5'){ echo 'selected="selected"';} ?> value="5">5 Valves</option>
					<option <?php if(isset($arrDevice['valve']) && $arrDevice['valve'] == '6'){ echo 'selected="selected"';} ?> value="6">6 Valves</option>
					<option <?php if(isset($arrDevice['valve']) && $arrDevice['valve'] == '7'){ echo 'selected="selected"';} ?> value="7">7 Valves</option>
					<option <?php if(isset($arrDevice['valve']) && $arrDevice['valve'] == '8'){ echo 'selected="selected"';} ?> value="8">8 Valves</option>
				</select>
				<div style="height:10px">&nbsp;</div>
				<label for="valve_actuated">If necessary, Which valve(s) is actuated when you switch from Pool to Spa Mode?<span class="requiredMark">*</span></label>
                <select name="valve_actuated[]" id="valve_actuated" class="form-control required" multiple="">
					<option <?php if(isset($arrDevice['valve_actuated']) && in_array('',$arrDevice['valve_actuated'])){ echo 'selected="selected"';} ?> value="">Select Valve Quantity</option>
					<option <?php if(isset($arrDevice['valve_actuated'])  && in_array('0',$arrDevice['valve_actuated'])){ echo 'selected="selected"';} ?> value="0">Valve 0 is actuated</option>
					<option <?php if(isset($arrDevice['valve_actuated'])  && in_array('1',$arrDevice['valve_actuated'])){ echo 'selected="selected"';} ?> value="1" selected="selected">Valve 1 is actuated</option>
					<option <?php if(isset($arrDevice['valve_actuated'])  && in_array('2',$arrDevice['valve_actuated'])){ echo 'selected="selected"';} ?> value="2" selected="selected">Valve 2 is actuated</option>
				</select>
				<div style="height:10px">&nbsp;</div>
				<label for="valveRunTime">Valve Run Time?<span class="requiredMark">*</span></label>
                <input type="text" name="valveRunTime" value="<?php if(isset($arrDevice['valveRunTime']) && $arrDevice['valveRunTime'] != '') { echo $arrDevice['valveRunTime'];}?>" id="valveRunTime" class="form-control inputText required">
				<div style="height:10px">&nbsp;</div>
				<label for="valveSequence">Valve sequence?<span class="requiredMark">*</span></label>
                <input type="text" name="valveSequence" value="<?php if(isset($arrDevice['valveSequence']) && $arrDevice['valveSequence'] != '') { echo $arrDevice['valveSequence'];}?>" id="valveSequence" class="form-control inputText required">
			</div>	
			<div class="col-sm-6">
			<label for="automatic_pumps">How many Pumps do you have?<span class="requiredMark">*</span><br><br></label>
                <select name="automatic_pumps" id="automatic_pumps" class="form-control required" onchange="pumpChange();">
					<option <?php if(isset($arrDevice['pump']) && $arrDevice['pump'] == '1'){ echo 'selected="selected"';} ?>  value="0">0 Pump</option>
					<option <?php if(isset($arrDevice['pump']) && $arrDevice['pump'] == '1'){ echo 'selected="selected"';} ?>  value="1">1 Pump</option>
					<option <?php if(isset($arrDevice['pump']) && $arrDevice['pump'] == '2'){ echo 'selected="selected"';} ?> value="2">2 Pump</option>
					<option <?php if(isset($arrDevice['pump']) && $arrDevice['pump'] == '3'){ echo 'selected="selected"';} ?> value="3">3 Pump</option>
				</select>
				
				<div style="height:10px">&nbsp;</div>
				<table width="100%;">
				<tr id="trPump1"><td>
				<label for="strValve">Pump1<span class="requiredMark">*</span></label>
                <select name="Pump1" id="Pump1" class="form-control required">
				<option <?php if(isset($arrDevice['pump1']) && $arrDevice['pump1'] == ''){ echo 'selected="selected"';} ?> value="">--Select pump function--</option>
				<option <?php if(isset($arrDevice['pump1']) && $arrDevice['pump1'] == 'Filtering Pool and Spa'){ echo 'selected="selected"';} ?> value="Filtering Pool and Spa">Filtering Pool and Spa</option>
				<option <?php if(isset($arrDevice['pump1']) && $arrDevice['pump1'] == 'Filtering Spa Only'){ echo 'selected="selected"';} ?> value="Filtering Spa Only">Filtering Spa Only</option>
				<option <?php if(isset($arrDevice['pump1']) && $arrDevice['pump1'] == 'Filtering Pool Only'){ echo 'selected="selected"';} ?> value="Filtering Pool Only">Filtering Pool Only</option>
				<option <?php if(isset($arrDevice['pump1']) && $arrDevice['pump1'] == 'Spa Jets Only'){ echo 'selected="selected"';} ?> value="Spa Jets Only">Spa Jets Only</option>
				<option <?php if(isset($arrDevice['pump1']) && $arrDevice['pump1'] == 'Spa Circulation and Heating'){ echo 'selected="selected"';} ?> value="Spa Circulation and Heating">Spa Circulation and Heating</option>
				<option <?php if(isset($arrDevice['pump1']) && $arrDevice['pump1'] == 'Pool Circulation and Heating'){ echo 'selected="selected"';} ?> value="Pool Circulation and Heating">Pool Circulation and Heating</option>
				<option <?php if(isset($arrDevice['pump1']) && $arrDevice['pump1'] == 'Pool and Spa Circulation and Heating'){ echo 'selected="selected"';} ?> value="Pool and Spa Circulation and Heating">Pool and Spa Circulation and Heating</option>
				<option <?php if(isset($arrDevice['pump1']) && $arrDevice['pump1'] == 'waterfall'){ echo 'selected="selected"';} ?> value="waterfall">waterfall</option>
				<option <?php if(isset($arrDevice['pump1']) && $arrDevice['pump1'] == 'solar heater'){ echo 'selected="selected"';} ?> value="solar heater">solar heater</option>
				<option <?php if(isset($arrDevice['pump1']) && $arrDevice['pump1'] == 'waterslide'){ echo 'selected="selected"';} ?> value="waterslide">waterslide</option>
				<option <?php if(isset($arrDevice['pump1']) && $arrDevice['pump1'] == 'water feature 1'){ echo 'selected="selected"';} ?> value="water feature 1">water feature 1</option>
				<option <?php if(isset($arrDevice['pump1']) && $arrDevice['pump1'] == 'water feature 2'){ echo 'selected="selected"';} ?> value="water feature 2">water feature 2</option>
				</select>
				</td></tr>
				<tr id="trPump2" style="display:<?php if(isset($arrDevice['pump']) && $arrDevice['pump'] >= 2){ echo '';} else {echo 'none;';} ?>"><td>
				<label for="strValve">Pump2<span class="requiredMark">*</span></label>
                <select name="Pump2" id="Pump2" class="form-control">
				<option <?php if(isset($arrDevice['pump2']) && $arrDevice['pump2'] == ''){ echo 'selected="selected"';} ?> value="">--Select pump function--</option>
				<option <?php if(isset($arrDevice['pump2']) && $arrDevice['pump2'] == 'Filtering Pool and Spa'){ echo 'selected="selected"';} ?> value="Filtering Pool and Spa">Filtering Pool and Spa</option>
				<option <?php if(isset($arrDevice['pump2']) && $arrDevice['pump2'] == 'Filtering Spa Only'){ echo 'selected="selected"';} ?> value="Filtering Spa Only">Filtering Spa Only</option>
				<option <?php if(isset($arrDevice['pump2']) && $arrDevice['pump2'] == 'Filtering Pool Only'){ echo 'selected="selected"';} ?> value="Filtering Pool Only">Filtering Pool Only</option>
				<option <?php if(isset($arrDevice['pump2']) && $arrDevice['pump2'] == 'Spa Jets Only'){ echo 'selected="selected"';} ?> value="Spa Jets Only">Spa Jets Only</option>
				<option <?php if(isset($arrDevice['pump2']) && $arrDevice['pump2'] == 'Spa Circulation and Heating'){ echo 'selected="selected"';} ?> value="Spa Circulation and Heating">Spa Circulation and Heating</option>
				<option <?php if(isset($arrDevice['pump2']) && $arrDevice['pump2'] == 'Pool Circulation and Heating'){ echo 'selected="selected"';} ?> value="Pool Circulation and Heating">Pool Circulation and Heating</option>
				<option <?php if(isset($arrDevice['pump2']) && $arrDevice['pump2'] == 'Pool and Spa Circulation and Heating'){ echo 'selected="selected"';} ?> value="Pool and Spa Circulation and Heating">Pool and Spa Circulation and Heating</option>
				<option <?php if(isset($arrDevice['pump2']) && $arrDevice['pump2'] == 'waterfall'){ echo 'selected="selected"';} ?> value="waterfall">waterfall</option>
				<option <?php if(isset($arrDevice['pump2']) && $arrDevice['pump2'] == 'solar heater'){ echo 'selected="selected"';} ?> value="solar heater">solar heater</option>
				<option <?php if(isset($arrDevice['pump2']) && $arrDevice['pump2'] == 'waterslide'){ echo 'selected="selected"';} ?> value="waterslide">waterslide</option>
				<option <?php if(isset($arrDevice['pump2']) && $arrDevice['pump2'] == 'water feature 1'){ echo 'selected="selected"';} ?> value="water feature 1">water feature 1</option>
				<option <?php if(isset($arrDevice['pump2']) && $arrDevice['pump2'] == 'water feature 2'){ echo 'selected="selected"';} ?> value="water feature 2">water feature 2</option>
				</select>
				</td></tr>
				<tr id="trPump3" style="display:<?php if(isset($arrDevice['pump']) && $arrDevice['pump'] == 3){ echo '';} else { echo 'none;';} ?>"><td>
				<label for="strValve">Pump3<span class="requiredMark">*</span></label>
                <select name="Pump3" id="Pump3" class="form-control">
				<option <?php if(isset($arrDevice['pump3']) && $arrDevice['pump3'] == ''){ echo 'selected="selected"';} ?> value="">--Select pump function--</option>
				<option <?php if(isset($arrDevice['pump3']) && $arrDevice['pump3'] == 'Filtering Pool and Spa'){ echo 'selected="selected"';} ?> value="Filtering Pool and Spa">Filtering Pool and Spa</option>
				<option <?php if(isset($arrDevice['pump3']) && $arrDevice['pump3'] == 'Filtering Spa Only'){ echo 'selected="selected"';} ?> value="Filtering Spa Only">Filtering Spa Only</option>
				<option <?php if(isset($arrDevice['pump3']) && $arrDevice['pump3'] == 'Filtering Pool Only'){ echo 'selected="selected"';} ?> value="Filtering Pool Only">Filtering Pool Only</option>
				<option <?php if(isset($arrDevice['pump3']) && $arrDevice['pump3'] == 'Spa Jets Only'){ echo 'selected="selected"';} ?> value="Spa Jets Only">Spa Jets Only</option>
				<option <?php if(isset($arrDevice['pump3']) && $arrDevice['pump3'] == 'Spa Circulation and Heating'){ echo 'selected="selected"';} ?> value="Spa Circulation and Heating">Spa Circulation and Heating</option>
				<option <?php if(isset($arrDevice['pump3']) && $arrDevice['pump3'] == 'Pool Circulation and Heating'){ echo 'selected="selected"';} ?> value="Pool Circulation and Heating">Pool Circulation and Heating</option>
				<option <?php if(isset($arrDevice['pump3']) && $arrDevice['pump3'] == 'Pool and Spa Circulation and Heating'){ echo 'selected="selected"';} ?> value="Pool and Spa Circulation and Heating">Pool and Spa Circulation and Heating</option>
				<option <?php if(isset($arrDevice['pump3']) && $arrDevice['pump3'] == 'waterfall'){ echo 'selected="selected"';} ?> value="waterfall">waterfall</option>
				<option <?php if(isset($arrDevice['pump3']) && $arrDevice['pump3'] == 'solar heater'){ echo 'selected="selected"';} ?> value="solar heater">solar heater</option>
				<option <?php if(isset($arrDevice['pump3']) && $arrDevice['pump3'] == 'waterslide'){ echo 'selected="selected"';} ?> value="waterslide">waterslide</option>
				<option <?php if(isset($arrDevice['pump3']) && $arrDevice['pump3'] == 'water feature 1'){ echo 'selected="selected"';} ?> value="water feature 1">water feature 1</option>
				<option <?php if(isset($arrDevice['pump3']) && $arrDevice['pump3'] == 'water feature 2'){ echo 'selected="selected"';} ?> value="water feature 2">water feature 2</option>
				</select>
				</td></tr>
				</table>
				<div style="height:10px">&nbsp;</div>
				<label for="pumpRunTime">Pump Run Time?<span class="requiredMark">*</span></label>
                <input type="text" name="pumpRunTime" value="<?php if(isset($arrDevice['pumpRunTime']) && $arrDevice['pumpRunTime'] != '') { echo $arrDevice['pumpRunTime'];}?>" id="pumpRunTime" class="form-control inputText required">
				<div style="height:10px">&nbsp;</div>
				<label for="pumpSequence">Pump sequence?<span class="requiredMark">*</span></label>
                <input type="text" name="pumpSequence" value="<?php if(isset($arrDevice['pumpSequence']) && $arrDevice['pumpSequence'] != '') { echo $arrDevice['pumpSequence'];}?>" id="pumpSequence" class="form-control inputText required">
			</div>
            </section>
            <h3>Heater</h3>
            <section>
                <div class="col-sm-6">
				<label for="automatic_heaters_question1">How many heaters do you have?<span class="requiredMark">*</span></label>
                <select name="automatic_heaters_question1" id="automatic_heaters_question1" class="form-control required" onchange="showHeater();">
				<option <?php if(isset($arrHeater['heater']) &&  $arrHeater['heater'] == '0'){echo 'selected="selected"';}?> value="0">0 Heater</option>
					<option <?php if(isset($arrHeater['heater']) &&  $arrHeater['heater'] == '1'){echo 'selected="selected"';}?> value="1">1 Heater</option>
					<option <?php if(isset($arrHeater['heater']) &&  $arrHeater['heater'] == '2'){echo 'selected="selected"';}?> value="2">2 Heater</option>
					<option <?php if(isset($arrHeater['heater']) &&  $arrHeater['heater'] == '3'){echo 'selected="selected"';}?> value="3">3 Heater</option>
				</select>
				<div style="height:10px">&nbsp;</div>
				<table width="100%">
				<tr id="trHeater1" style="display:<?php if(isset($arrHeater['heater']) &&  $arrHeater['heater'] >= 1){echo '';}else{echo 'none';}?>;"><td>
				<label for="heater1_equiment">How do you turn on your Heater 1?<span class="requiredMark">*</span></label>
                <select name="heater1_equiment" id="heater1_equiment" class="form-control">
					<option <?php if(isset($arrHeater['heater1_equip']) &&  $arrHeater['heater1_equip'] == ''){echo 'selected="selected"';}?> value="">Select Equipment</option>
					<option <?php if(isset($arrHeater['heater1_equip']) &&  $arrHeater['heater1_equip'] == '24'){echo 'selected="selected"';}?> value="24">24V AC</option>
					<option <?php if(isset($arrHeater['heater1_equip']) &&  $arrHeater['heater1_equip'] == '12'){echo 'selected="selected"';}?> value="12">12V DC</option>
				</select>
				</td></tr>
				
				<tr id="trHeater2" style="display:<?php if(isset($arrHeater['heater']) &&  $arrHeater['heater'] >= 2){echo '';}else{echo 'none';}?>;"><td>
				<div style="height:10px">&nbsp;</div>
				<label for="heater2_equiment">How do you turn on your Heater 2?<span class="requiredMark">*</span></label>
                <select name="heater2_equiment" id="heater2_equiment" class="form-control">
					<option <?php if(isset($arrHeater['heater2_equip']) &&  $arrHeater['heater2_equip'] == ''){echo 'selected="selected"';}?> value="">Select Equipment</option>
					<option <?php if(isset($arrHeater['heater2_equip']) &&  $arrHeater['heater2_equip'] == '24'){echo 'selected="selected"';}?> value="24">24V AC</option>
					<option <?php if(isset($arrHeater['heater2_equip']) &&  $arrHeater['heater2_equip'] == '12'){echo 'selected="selected"';}?> value="12">12V DC</option>
				</select>
				</td></tr>
				<tr id="trHeater3" style="display:<?php if(isset($arrHeater['heater']) &&  $arrHeater['heater'] >= 3){echo '';}else{echo 'none';}?>;"><td>
				<div style="height:10px">&nbsp;</div>
				<label for="heater3_equiment">How do you turn on your Heater 3?<span class="requiredMark">*</span></label>
                <select name="heater3_equiment" id="heater3_equiment" class="form-control">
					<option <?php if(isset($arrHeater['heater3_equip']) &&  $arrHeater['heater3_equip'] == ''){echo 'selected="selected"';}?> value="">Select Equipment</option>
					<option <?php if(isset($arrHeater['heater3_equip']) &&  $arrHeater['heater3_equip'] == '24'){echo 'selected="selected"';}?> value="24">24V AC</option>
					<option <?php if(isset($arrHeater['heater3_equip']) &&  $arrHeater['heater3_equip'] == '12'){echo 'selected="selected"';}?> value="12">12V DC</option>
				</select>
				</td></tr>
				</table>
				<div style="height:10px">&nbsp;</div>
				<label for="heaterSequence">Heater sequence?<span class="requiredMark">*</span></label>
                <input type="text" name="heaterSequence" value="<?php if(isset($arrHeater['heaterSequence']) && $arrHeater['heaterSequence'] != '') { echo $arrHeater['heaterSequence'];}?>" id="heaterSequence" class="form-control inputText required">
				</div>
				<div class="col-sm-6">
				
				<table width="100%">
				<tr id="trHeaterWork1" style="display:<?php if(isset($arrHeater['heater']) &&  $arrHeater['heater'] >= 1){echo '';}else{echo 'none';}?>;"><td>
				<label for="Heater1">Heater 1?<span class="requiredMark">*</span></label>
                <select name="Heater1" id="Heater1" class="form-control">
					<option <?php if(isset($arrHeater['Heater1']) &&  $arrHeater['Heater1'] == 'Pool spa Combo'){echo 'selected="selected"';}?> value="Pool spa Combo">Heat pool and spa</option>
					<option <?php if(isset($arrHeater['Heater1']) &&  $arrHeater['Heater1'] == 'Pool Only'){echo 'selected="selected"';}?> value="Pool Only">Heat pool</option>
					<option <?php if(isset($arrHeater['Heater1']) &&  $arrHeater['Heater1'] == 'Spa Only'){echo 'selected="selected"';}?> value="Spa Only">Heat spa</option>
					<option <?php if(isset($arrHeater['Heater1']) &&  $arrHeater['Heater1'] == 'Heat off'){echo 'selected="selected"';}?> value="Heat off">Heat off</option>
				</select>
				</td></tr>
				<tr id="trHeaterWork2" style="display:<?php if(isset($arrHeater['heater']) &&  $arrHeater['heater'] >= 2){echo '';}else{echo 'none';}?>;"><td>
				<div style="height:10px">&nbsp;</div>
				<label for="Heater2">Heater 2?<span class="requiredMark">*</span></label>
                <select name="Heater2" id="Heater2" class="form-control">
					<option <?php if(isset($arrHeater['Heater2']) &&  $arrHeater['Heater2'] == 'Pool spa Combo'){echo 'selected="selected"';}?> value="Pool spa Combo">Heat pool and spa</option>
					<option <?php if(isset($arrHeater['Heater2']) &&  $arrHeater['Heater2'] == 'Pool Only'){echo 'selected="selected"';}?> value="Pool Only">Heat pool</option>
					<option <?php if(isset($arrHeater['Heater2']) &&  $arrHeater['Heater2'] == 'Spa Only'){echo 'selected="selected"';}?> value="Spa Only">Heat spa</option>
					<option <?php if(isset($arrHeater['Heater2']) &&  $arrHeater['Heater2'] == 'Heat off'){echo 'selected="selected"';}?> value="Heat off">Heat off</option>
				</select>
				</td></tr>
				<tr id="trHeaterWork3" style="display:<?php if(isset($arrHeater['heater']) &&  $arrHeater['heater'] >= 3){echo '';}else{echo 'none';}?>;"><td>
				<div style="height:10px">&nbsp;</div>
				<label for="Heater3">Heater 3?<span class="requiredMark">*</span></label>
                <select name="Heater3" id="Heater3" class="form-control">
					<option <?php if(isset($arrHeater['Heater3']) &&  $arrHeater['Heater3'] == 'Pool spa Combo'){echo 'selected="selected"';}?> value="Pool spa Combo">Heat pool and spa</option>
					<option <?php if(isset($arrHeater['Heater3']) &&  $arrHeater['Heater3'] == 'Pool Only'){echo 'selected="selected"';}?> value="Pool Only">Heat pool</option>
					<option <?php if(isset($arrHeater['Heater3']) &&  $arrHeater['Heater3'] == 'Spa Only'){echo 'selected="selected"';}?> value="Spa Only">Heat spa</option>
					<option <?php if(isset($arrHeater['Heater3']) &&  $arrHeater['Heater3'] == 'Heat off'){echo 'selected="selected"';}?> value="Heat off">Heat off</option>
				</select>
				</td></tr>
				</table>
				<div style="height:10px">&nbsp;</div>
				<table width="100%">
				<tr id="trHeaterPump1" style="display:<?php if(isset($arrHeater['heater']) &&  $arrHeater['heater'] >= 1){echo '';}else{echo 'none';}?>;"><td>
				<label for="HeaterPump1">Which Pump has to be on in order to operate Heater 1?<span class="requiredMark">*</span></label>
                <select name="HeaterPump1" id="HeaterPump1" class="form-control">
					<option <?php if(isset($arrHeater['HeaterPump1']) &&  $arrHeater['HeaterPump1'] == '1'){echo 'selected="selected"';}?> value="1">Pump1</option>
					<?php if(isset($arrHeater['heater']) &&  $arrHeater['heater'] >= 2) {?>
					<option <?php if(isset($arrHeater['HeaterPump1']) &&  $arrHeater['HeaterPump1'] == '2'){echo 'selected="selected"';}?> value="2">Pump2</option>
					<?php } if(isset($arrHeater['heater']) &&  $arrHeater['heater'] >= 3) {?>
					<option <?php if(isset($arrHeater['HeaterPump1']) &&  $arrHeater['HeaterPump1'] == '3'){echo 'selected="selected"';}?> value="3">Pump3</option>
					<?php } ?>
				</select>
				</td></tr>
				<tr id="trHeaterPump2" style="display:<?php if(isset($arrHeater['heater']) &&  $arrHeater['heater'] >= 2){echo '';}else{echo 'none';}?>;"><td>
				<div style="height:10px">&nbsp;</div>
				<label for="HeaterPump2">Which Pump has to be on in order to operate Heater 2?<span class="requiredMark">*</span></label>
                <select name="HeaterPump2" id="HeaterPump2" class="form-control">
					<option <?php if(isset($arrHeater['HeaterPump2']) &&  $arrHeater['HeaterPump2'] == '1'){echo 'selected="selected"';}?> value="1">Pump1</option>
					<?php if(isset($arrHeater['heater']) &&  $arrHeater['heater'] >= 2) {?>
					<option <?php if(isset($arrHeater['HeaterPump2']) &&  $arrHeater['HeaterPump2'] == '2'){echo 'selected="selected"';}?> value="2">Pump2</option>
					<?php } if(isset($arrHeater['heater']) &&  $arrHeater['heater'] >= 3) {?>
					<option <?php if(isset($arrHeater['HeaterPump2']) &&  $arrHeater['HeaterPump2'] == '3'){echo 'selected="selected"';}?> value="3">Pump3</option>
					<?php } ?>
				</select>
				</td></tr>
				<tr id="trHeaterPump3" style="display:<?php if(isset($arrHeater['heater']) &&  $arrHeater['heater'] >= 3){echo '';}else{echo 'none';}?>;"><td>
				<div style="height:10px">&nbsp;</div>
				<label for="HeaterPump3">Which Pump has to be on in order to operate Heater 3?<span class="requiredMark">*</span></label>
                <select name="HeaterPump3" id="HeaterPump3" class="form-control">
					<option <?php if(isset($arrHeater['HeaterPump3']) &&  $arrHeater['HeaterPump3'] == '1'){echo 'selected="selected"';}?> value="1">Pump1</option>
					<?php if(isset($arrHeater['heater']) &&  $arrHeater['heater'] >= 2) {?>
					<option <?php if(isset($arrHeater['HeaterPump3']) &&  $arrHeater['HeaterPump3'] == '2'){echo 'selected="selected"';}?> value="2">Pump2</option>
					<?php } if(isset($arrHeater['heater']) &&  $arrHeater['heater'] >= 3) {?>
					<option <?php if(isset($arrHeater['HeaterPump3']) &&  $arrHeater['HeaterPump3'] == '3'){echo 'selected="selected"';}?> value="3">Pump3</option>
					<?php } ?>
				</select>
				</td></tr>
				</table>
				</div>
            </section>
			<h3>More Device</h3>
            <section>
			<div class="col-sm-6">
               <label for="no_light">How many Spa/Pool lights do you have?<span class="requiredMark">*</span></label>
                <select name="no_light" id="no_light" class="form-control">
						<option <?php if(isset($arrMore['light']) &&  $arrMore['light'] == ''){echo 'selected="selected"';}?> value="">Select number of lights</option>
						<option <?php if(isset($arrMore['light']) &&  $arrMore['light'] == '1'){echo 'selected="selected"';}?> value="1">1 Light</option>
						<option <?php if(isset($arrMore['light']) &&  $arrMore['light'] == '2'){echo 'selected="selected"';}?> value="2">2 Light</option>
						<option <?php if(isset($arrMore['light']) &&  $arrMore['light'] == '3'){echo 'selected="selected"';}?> value="3">3 Light</option>
						<option <?php if(isset($arrMore['light']) &&  $arrMore['light'] == '4'){echo 'selected="selected"';}?> value="4">4 Light</option>
				</select>
				<div style="height:10px">&nbsp;</div>
				<label for="lightRunTime">After how many minutes, would you like to automatically turn the pool/spa lights OFF?<span class="requiredMark">*</span></label>
                <input type="text" name="lightRunTime" value="<?php if(isset($arrMore['lightRunTime']) && $arrMore['lightRunTime'] != '') { echo $arrMore['lightRunTime'];}?>" id="lightRunTime" class="form-control inputText required">
				<div style="height:10px">&nbsp;</div>
				<label for="lightSequence">Light sequence?<span class="requiredMark">*</span></label>
                <input type="text" name="lightSequence" value="<?php if(isset($arrMore['lightSequence']) && $arrMore['lightSequence'] != '') { echo $arrMore['lightSequence'];}?>" id="lightSequence" class="form-control inputText required">
				<div style="height:10px">&nbsp;</div>
				<label for="temperature1">Temperature Sensor 1<span class="requiredMark">*</span></label>
                <select name="temperature1" id="temperature1" class="form-control">
					<option <?php if(isset($arrMore['temperature1']) &&  $arrMore['temperature1'] == '1'){echo 'selected="selected"';}?> value="1">TS1</option>
					<option <?php if(isset($arrMore['temperature1']) &&  $arrMore['temperature1'] == '2'){echo 'selected="selected"';}?> value="2">TS2</option>
					<option <?php if(isset($arrMore['temperature1']) &&  $arrMore['temperature1'] == '3'){echo 'selected="selected"';}?> value="3">TS3</option>
					<option <?php if(isset($arrMore['temperature1']) &&  $arrMore['temperature1'] == '4'){echo 'selected="selected"';}?> value="4">TS4</option>
					<option <?php if(isset($arrMore['temperature1']) &&  $arrMore['temperature1'] == '5'){echo 'selected="selected"';}?> value="5">TS5</option>
				</select>
				
				<div style="height:10px">&nbsp;</div>
				<label for="temperature3">Temperature Sensor 3<span class="requiredMark">*</span></label>
                <select name="temperature3" id="temperature3" class="form-control">
					<option <?php if(isset($arrMore['temperature3']) &&  $arrMore['temperature3'] == '1'){echo 'selected="selected"';}?> value="1">TS1</option>
					<option <?php if(isset($arrMore['temperature3']) &&  $arrMore['temperature3'] == '2'){echo 'selected="selected"';}?> value="2">TS2</option>
					<option <?php if(isset($arrMore['temperature3']) &&  $arrMore['temperature3'] == '3'){echo 'selected="selected"';}?> value="3">TS3</option>
					<option <?php if(isset($arrMore['temperature3']) &&  $arrMore['temperature3'] == '4'){echo 'selected="selected"';}?> value="4">TS4</option>
					<option <?php if(isset($arrMore['temperature3']) &&  $arrMore['temperature3'] == '5'){echo 'selected="selected"';}?> value="5">TS5</option>
				</select>
				
				<div style="height:10px">&nbsp;</div>
				<label for="temperature5">Temperature Sensor 5<span class="requiredMark">*</span></label>
                <select name="temperature5" id="temperature5" class="form-control">
					<option <?php if(isset($arrMore['temperature5']) &&  $arrMore['temperature5'] == '1'){echo 'selected="selected"';}?> value="1">TS1</option>
					<option <?php if(isset($arrMore['temperature5']) &&  $arrMore['temperature5'] == '2'){echo 'selected="selected"';}?> value="2">TS2</option>
					<option <?php if(isset($arrMore['temperature5']) &&  $arrMore['temperature5'] == '3'){echo 'selected="selected"';}?> value="3">TS3</option>
					<option <?php if(isset($arrMore['temperature5']) &&  $arrMore['temperature5'] == '4'){echo 'selected="selected"';}?> value="4">TS4</option>
					<option <?php if(isset($arrMore['temperature5']) &&  $arrMore['temperature5'] == '5'){echo 'selected="selected"';}?> value="5">TS5</option>
				</select>
				
			</div>
			<div class="col-sm-6">
			<label for="no_blower">How many Spa devices do you have?<span class="requiredMark">*</span></label>
                <select name="no_blower" id="no_blower" class="form-control">
						<option <?php if(isset($arrMore['blower']) &&  $arrMore['blower'] == ''){echo 'selected="selected"';}?> value="">Select number of blowers</option>
						<option <?php if(isset($arrMore['blower']) &&  $arrMore['blower'] == '0'){echo 'selected="selected"';}?> value="0">0 Blower</option>
						<option <?php if(isset($arrMore['blower']) &&  $arrMore['blower'] == '1'){echo 'selected="selected"';}?> value="1">1 Blower</option>
						<option <?php if(isset($arrMore['blower']) &&  $arrMore['blower'] == '2'){echo 'selected="selected"';}?> value="2">2 Blower</option>
						<option <?php if(isset($arrMore['blower']) &&  $arrMore['blower'] == '3'){echo 'selected="selected"';}?> value="3">3 Blower</option>
						<option <?php if(isset($arrMore['blower']) &&  $arrMore['blower'] == '4'){echo 'selected="selected"';}?> value="4">4 Blower</option>
					</select>
				<div style="height:10px">&nbsp;</div>
				<label for="blowerRunTime">After how many minutes, would you like to automatically turn the pool/spa blower OFF?<span class="requiredMark">*</span></label>
                <input type="text" name="blowerRunTime" value="<?php if(isset($arrMore['blowerRunTime']) && $arrMore['blowerRunTime'] != '') { echo $arrMore['blowerRunTime'];}?>" id="blowerRunTime" class="form-control inputText required">
				<div style="height:10px">&nbsp;</div>
				<label for="blowerSequence">Blower sequence?<span class="requiredMark">*</span></label>
                <input type="text" name="blowerSequence" value="<?php if(isset($arrMore['blowerSequence']) && $arrMore['blowerSequence'] != '') { echo $arrMore['blowerSequence'];}?>" id="blowerSequence" class="form-control inputText required">	

				<div style="height:10px">&nbsp;</div>
				<label for="temperature2">Temperature Sensor 2<span class="requiredMark">*</span></label>
                <select name="temperature2" id="temperature2" class="form-control">
					<option <?php if(isset($arrMore['temperature2']) &&  $arrMore['temperature2'] == '1'){echo 'selected="selected"';}?> value="1">TS1</option>
					<option <?php if(isset($arrMore['temperature2']) &&  $arrMore['temperature2'] == '2'){echo 'selected="selected"';}?> value="2">TS2</option>
					<option <?php if(isset($arrMore['temperature2']) &&  $arrMore['temperature2'] == '3'){echo 'selected="selected"';}?> value="3">TS3</option>
					<option <?php if(isset($arrMore['temperature2']) &&  $arrMore['temperature2'] == '4'){echo 'selected="selected"';}?> value="4">TS4</option>
					<option <?php if(isset($arrMore['temperature2']) &&  $arrMore['temperature2'] == '5'){echo 'selected="selected"';}?> value="5">TS5</option>
				</select>
				
				<div style="height:10px">&nbsp;</div>
				<label for="temperature4">Temperature Sensor 4<span class="requiredMark">*</span></label>
                <select name="temperature4" id="temperature4" class="form-control">
					<option <?php if(isset($arrMore['temperature4']) &&  $arrMore['temperature4'] == '1'){echo 'selected="selected"';}?> value="1">TS1</option>
					<option <?php if(isset($arrMore['temperature4']) &&  $arrMore['temperature4'] == '2'){echo 'selected="selected"';}?> value="2">TS2</option>
					<option <?php if(isset($arrMore['temperature4']) &&  $arrMore['temperature4'] == '3'){echo 'selected="selected"';}?> value="3">TS3</option>
					<option <?php if(isset($arrMore['temperature4']) &&  $arrMore['temperature4'] == '4'){echo 'selected="selected"';}?> value="4">TS4</option>
					<option <?php if(isset($arrMore['temperature4']) &&  $arrMore['temperature4'] == '5'){echo 'selected="selected"';}?> value="5">TS5</option>
				</select>	
			</div>
            </section>
		</div>
    </form>


</div>
</div>

	