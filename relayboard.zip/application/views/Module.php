<?php


$sModuleID			= '';
$sModuleName		= '';
$sModuleActive 		= '';

if(!empty($moduleDetails))
{
	foreach($moduleDetails as $Module)
	{
		$sModuleID		= $Module->id;
		$sModuleName	= $Module->module_name;
		$sModuleActive 	= $Module->module_active;
	}
}

$sButtonText	=	'';
if($sModuleID == '')
	$sButtonText = 'Save Module';
else if($sModuleID != '')
	$sButtonText = 'Update Module';

?>
<style>
.navbar-toggle {
		background-color: transparent !important;
		background-image: none !important;
		border: 1px solid transparent !important;
		border-radius: 4px !important;
		float: left !important;
		margin-bottom: 8px !important;
		margin-right: 15px !important;
		margin-top: 8px !important;
		padding: 9px 10px !important;
		position: relative !important;
	}
	
	.navbar-toggle .icon-bar {
		border-radius: 1px !important;
		display: block !important;
		height: 2px !important;
		width: 22px !important;
	}
</style>
    <div id="page-wrapper">
        <div class="row">
          <div class="col-lg-12">
             <ol class="breadcrumb">
				  <li><img src="<?php echo HTTP_IMAGES_PATH.'icons/home.png';?>" width="24" style="vertical-align: middle !important;">&nbsp;<a href="<?php echo site_url();?>">Home</a> </li>
				  <li><a href="<?php echo base_url('dashboard/module');?>">All Modules</a></li>
				  <li class="active">Add/Edit Module</li>
				</ol>
          </div>
        </div><!-- /.row -->
        <div class="row">
          <div class="col-lg-12">
            <div class="panel panel-primary">
              <div class="panel-heading" style="border-top-left-radius: 0px;border-top-right-radius: 0px;">
                <h3 class="panel-title" style="color:#FFF;">Add/Edit Page</h3>
              </div>
              <div class="panel-body">
                <div id="morris-chart-area">
                  <form action="<?php echo site_url('dashboard/moduleAddEdit');?>" method="post">
				  <input type="hidden" name="moduleID" value="<?php echo $sModuleID;?>">
                    <table border="0" cellspacing="0" cellpadding="0" width="100%">
					<tr>
                        <td colspan="3"><span style="color:#FF0000;">* indicates required field</span></td>
                    </tr>
					 <tr><td colspan="3">&nbsp;</td></tr>
                      <tr>
                        <td width="24%"><strong>Name: <span class="mandetory">*</span></strong></td>
                        <td width="1%">&nbsp;</td>
                        <td width="75%"><input type="text" class="form-control" placeholder="Enter Module Name" name="sModuleName" value="<?php echo $sModuleName;?>" id="sModuleName" required></td>
                      </tr>
                      <tr><td colspan="3">&nbsp;</td></tr>
                      <tr>
                        <td width="10%"><strong>Active:</strong></td>
                        <td width="1%">&nbsp;</td>
                        <td width="89%"><input type="radio" name="sModuleActive" value="0" <?php if($sModuleActive == '0'|| $sModuleActive == ''){echo 'checked="checked"';} ?> checked="checked">&nbsp;No&nbsp;&nbsp;&nbsp;&nbsp;<input type="radio" <?php if($sModuleActive == '1'){echo 'checked="checked"';} ?> name="sModuleActive" value="1">&nbsp;Yes</td>
                      </tr>
                      <tr><td colspan="3">&nbsp;</td></tr>
                      <tr><td colspan="3"><span class="btn btn-green"><input type="submit" name="command" value="<?php echo $sButtonText;?>" class="btn btn-success" onclick="return checkForm();"></span>&nbsp;&nbsp;<span class="btn btn-red"><input type="button" name="back" value="Back" class="btn btn-success" onclick="javascript:location.href='<?php echo base_url('dashboard/module');?>';"></span></td></tr>
                      
                    </table>
                  </form>
                </div>
              </div>
            </div>
          </div>
        </div><!-- /.row -->
      </div><!-- /#page-wrapper -->
<script type="text/javascript">
$(document).ready(function (){
	
});
  function checkForm()
  {
	return true;
  }
</script>

<?php

?>