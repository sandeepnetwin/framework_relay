<!-- START : Temperature Sensors -->
<div class="row">
	<?php
		if(!empty($aIPDetails))
		{
			foreach($aIPDetails as $aIP)
			{
	?>
	<div class="col-sm-12" id="onoffbuttons_<?php echo $aIP->id;?>" style="display:<?php if($aIP->id != $iFirstIPId){ echo 'none';} ?>">
	<input type="hidden" value="<?php echo $aIP->id;?>" id="hidIPIdButton">
		<!-- widget Tags-->
		<div class="widget-container widget-stats boxed green-line">
		<div class="widget-title">
			<a href="<?php echo base_url('home/setting/'.$sDevice.'/');?>" class="link-refresh" id="link-refresh-1"><span class="glyphicon glyphicon-refresh"></span></a>
			<h3>Temperature Sensor</h3>
		</div>
		<div class="stats-content clearfix">
		<div class="stats-content-right" style="width:100% !important; margin-left:5px; margin-right:5px; float:none;">
		
		<table class="table table-hover">
			<thead>
				<tr style="font-weight:bold;">
					<div class="row">
						<th class="header">
						Temperature sensor
						</th>
					</div>	
				</tr>
			</thead>
			<tbody>
			<?php
				//START : Temperature sensor
				for ($i=0;$i < ${"temprature_count".$aIP->id}; $i++)
				{
					$iTempratureVal = ${"sTemprature".$aIP->id}[$i];
					
					$sTempratureNameDb =  $this->home_model->getDeviceName($i,$sDevice,$aIP->id);
					if($sTempratureNameDb == '')
						$sTempratureNameDb = 'Add Name';
				  
					if($iTempratureVal == '')
						$iTempratureVal = '-';
					else
					{
						//If temperature is in Celcius convert it to Fahrenheit.
						if(preg_match('/C/',$iTempratureVal))
						{
							$iTempratureVal = str_replace('C','',$iTempratureVal);
							$iTempratureVal = celciustofahrenheit($iTempratureVal).'F';
						}
					}
					
					$strBusNumber	 =	'';
					$sTempratureShow =	'';
					$strGetBusNumber = "SELECT light_relay_number,show_dashboard FROM rlb_device WHERE device_type = 'T' AND device_number='".$i."' AND ip_id ='".$aIP->id."'";
					
					$query  =   $this->db->query($strGetBusNumber);
					
					if($query->num_rows() > 0)
					{
						foreach($query->result() as $rowResult)
						{
							$strBusNumber	 =	$rowResult->light_relay_number;
							//$sTempratureShow =	$rowResult->show_dashboard;
						}
					}
					
					/* //Get Port Number
					$sDevicePort	=	$this->home_model->getDevicePort($i,$sDevice);
					
					if($sDevicePort == '')
						$sDevicePort = 0;
					
					$strPortClass	=	'port_'.$sDevicePort; */
					
					//Get the status whether to show on Dashboard or not.
					$sTempratureShow =  $this->home_model->getDeviceShowOnDashboard($i,$sDevice,$aIP->id);
					
					//Get Temprature Offset.
					$sTempratureOffset =  $this->home_model->getTemperatureOffset($i,$aIP->id);
			?>
				<tr>
					<td>
						<div class="row">
							<div class="col-sm-4">Temperature sensor <?php echo $i;?>
							</div>
							<div class="col-sm-4">Temperature: <span id="temperature_<?php echo $i.'_'.$aIP->id;?>" ><?php echo $iTempratureVal;?></span>
							<hr />
							<strong>Show on Dashboard?: </strong>
							&nbsp;<input type="radio" onclick="saveShowOnHome('<?php echo $i;?>',this.value);" name="show_<?php echo $i;?>_<?php echo $aIP->id;?>" id="show_1_<?php echo $i;?>_<?php echo $aIP->id;?>" value="1" <?php if($sTempratureShow == '1') { echo 'checked="checked"';} ?>> Yes
							&nbsp;&nbsp;
							<input type="radio" name="show_<?php echo $i;?>_<?php echo $aIP->id;?>" onclick="saveShowOnHome('<?php echo $i;?>',this.value);" id="show_0_<?php echo $i;?>_<?php echo $aIP->id;?>" value="0" <?php if($sTempratureShow == '0' || $sTempratureShow == '') { echo 'checked="checked"';} ?>> No
							<hr />
							</div>
							<div class="col-sm-4">
							Name : <a href="<?php if($sAccess == 2){ echo site_url('home/deviceName/'.base64_encode($i).'/'.base64_encode($sDevice).'/'.base64_encode($aIP->id));} else { echo 'javascript:void(0);';}?>" ><?php echo $sTempratureNameDb;?></a><br>
							<?php
								$strConfigureLink	=	'';
								$strRemoveLink		=	'';
								
								$strConfigureLink = 'href="'.base_url('analog/tempConfig/'.base64_encode($i).'/'.base64_encode($aIP->id)).'"';
								
								$strRemoveLink	  = 'href="'.base_url('analog/tempConfig/'.base64_encode($i).'/remove'.'/'.base64_encode($aIP->id)).'"';
								
							?>
							<?php if($i != 0) { ?>
							<a style="padding:6px 0;" class="btn btn-small btn-caps" <?php echo $strConfigureLink;?>><span><?php if($strBusNumber == ''){ echo 'Configure';} else {echo 'Edit';}?></span></a>
							<?php if($i != 0 && $strBusNumber != '') { ?>&nbsp;&nbsp;<a style="padding:6px 0;" class="btn btn-small btn-caps" <?php echo $strRemoveLink;?> ><span>Remove Sensor</span>	</a><?php } ?>
							<?php } ?>
							<br /><a style="padding:6px 0;" href="javascript:void(0);" onclick="showHideOffset('<?php echo $i;?>','<?php echo $aIP->id;?>');" >Temperature Offset</a><br />
								<div id="temperature_offset_div_<?php echo $i.'_'.$aIP->id;?>" style="display:<?php if($sTempratureOffset == '' || $sTempratureOffset == '0') { echo 'none;';} else if($sTempratureOffset != ''){ echo '';}?>">
									<input type="text" class="form-control" name="temperature_offset_<?php echo $i;?>" id="temperature_offset_<?php echo $i.'_'.$aIP->id;?>" value = "<?php echo $sTempratureOffset;?>" style="width:120px; display:inline-block;">&nbsp;&nbsp;<a style="padding:6px 0;" class="btn btn-caps" href="javascript:void(0);" onclick="saveOffset('<?php echo $i;?>','<?php echo $aIP->id;?>')" ><span>Save</span>	</a> 
								</div>
							</div>
						</div>
					</td>	
				</tr>
			<?php } ?>
			</tbody>
		</table>
		</div>
		</div>
		<!-- Widget Tags -->
	</div>
</div>
<?php 	}
	}
?>	
</div>
<script type="text/javascript">
function saveShowOnHome(iTempSensor,bStatus)
{
	var sIpId = $("#IpId").val();
	$.ajax({
			type: "POST",
			url: "<?php echo site_url('home/saveTempShowOnDashboard/');?>", 
			data: {iTempSensor:iTempSensor,bStatus:bStatus,sIpId:sIpId},
			success: function(data) {
			}
	});
}
function showHideOffset(device,ipID)
{
	
	var display = $("#temperature_offset_div_"+device+"_"+ipID).css('display');
	if(display == 'none')
	{
		$("#temperature_offset_div_"+device+"_"+ipID).show();
	}
	else
	{
		$("#temperature_offset_div_"+device+"_"+ipID).hide();
	}
	
}
function saveOffset(device,ipID)
{
	var offset = $("#temperature_offset_"+device+"_"+ipID).val();
	if(offset == '')
	{
		alert("Please enter Offset for Temperature sensor "+device);
		return false;
	}
	else
	{
		$.ajax({
				type: "POST",
				url: "<?php echo site_url('home/saveTemperatureOffset/');?>", 
				data: {iTempSensor:device,offset:offset,sIpId:ipID},
				success: function(data) {
					alert("Temperature Offset added successfully!");
					location.reload();	
				}
		});
	}
}
</script>
<!-- END : Temperature Sensors -->