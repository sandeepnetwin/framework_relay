<!-- START : Temperature Sensors -->
<div class="row">
	<div class="col-sm-12">
		<!-- widget Tags-->
		<div class="widget-container widget-stats boxed green-line">
		<div class="widget-title">
			<a href="<?php echo base_url('home/setting/'.$sDevice.'/');?>" class="link-refresh" id="link-refresh-1"><span class="glyphicon glyphicon-refresh"></span></a>
			<h3>Temperature Sensor</h3>
		</div>
		<div class="stats-content clearfix">
		<div class="stats-content-right" style="width:100% !important; margin-left:5px; margin-right:5px; float:none;">
		
		<table class="table table-hover">
			<thead>
				<tr style="font-weight:bold;">
					<div class="row">
						<th class="header">
						Temperature sensor
						</th>
					</div>	
				</tr>
			</thead>
			<tbody>
			<?php
				//START : Temperature sensor
				for ($i=0;$i < $temprature_count; $i++)
				{
					$iTempratureVal = $sTemprature[$i];
					
					$sTempratureNameDb =  $this->home_model->getDeviceName($i,$sDevice);
					if($sTempratureNameDb == '')
						$sTempratureNameDb = 'Add Name';
				  
					if($iTempratureVal == '')
						$iTempratureVal = '-';
					
					$strBusNumber	 =	'';
					$strGetBusNumber = "SELECT light_relay_number FROM rlb_device WHERE device_type = 'T' AND device_number='".$i."'";
					
					$query  =   $this->db->query($strGetBusNumber);
					
					if($query->num_rows() > 0)
					{
						foreach($query->result() as $rowResult)
						{
							$strBusNumber	=	$rowResult->light_relay_number;
						}
					}
					
					//Get Port Number
					$sDevicePort	=	$this->home_model->getDevicePort($i,$sDevice);
					
					if($sDevicePort == '')
						$sDevicePort = 0;
					
					$strPortClass	=	'port_'.$sDevicePort;
					
					//Get the status whether to show on Dashboard or not.
					$sTempratureShow =  $this->home_model->getDeviceShowOnDashboard($i,$sDevice);
			?>
				<tr>
					<td>
						<div class="row">
							<div class="col-sm-4">Temperature sensor <?php echo $i;?>
							</div>
							<div class="col-sm-4">Temperature: <?php echo $iTempratureVal;?>
							<hr />
							<strong>Select Port: </strong><select name="selPort_V_<?php echo $i;?>" id="selPort_V_<?php echo $i;?>" onchange="saveDevicePort('<?php echo $i;?>','<?php echo $sDevice;?>',this.value)">
									<option value="" <?php if($sDevicePort == ''){ echo 'selected="selected"'; }?>>-- Port--</option>
									<option value="<?php echo $sPort;?>" <?php if($sDevicePort == $sPort){ echo 'selected="selected"'; }?>><?php echo $sPort;?></option>
									<option value="<?php echo $sPort2;?>" <?php if($sDevicePort == $sPort2){ echo 'selected="selected"'; }?>><?php echo $sPort2;?></option>
							</select>
							<hr />
							<strong>Show on Dashboard?: </strong>
							&nbsp;<input type="radio" onclick="saveShowOnHome('<?php echo $i;?>',this.value);" name="show_<?php echo $i;?>" id="show_1_<?php echo $i;?>" value="1" <?php if($sTempratureShow == '1') { echo 'checked="checked"';} ?>> Yes
							&nbsp;&nbsp;
							<input type="radio" name="show_<?php echo $i;?>" onclick="saveShowOnHome('<?php echo $i;?>',this.value);" id="show_0_<?php echo $i;?>" value="0" <?php if($sTempratureShow == '0' || $sTempratureShow == '') { echo 'checked="checked"';} ?>> No
							<hr />
							</div>
							<div class="col-sm-4">
							Name : <a href="<?php if($sAccess == 2){ echo site_url('home/deviceName/'.base64_encode($i).'/'.base64_encode($sDevice).'/');} else { echo 'javascript:void(0);';}?>" ><?php echo $sTempratureNameDb;?></a><br>
							<?php
								$strConfigureLink	=	'';
								$strRemoveLink		=	'';
								
								if($sDevicePort == '0')
								{
									$strConfigureLink = 'href="javascript:void(0);" onclick="alert(\'Please select Port first!\');"';
									$strRemoveLink	  = 'href="javascript:void(0);" onclick="alert(\'Please select Port first!\');"';
								}
								else
								{
									$strConfigureLink = 'href="'.base_url('analog/tempConfig/'.base64_encode($i)).'"';
									$strRemoveLink	  = 'href="'.base_url('analog/tempConfig/'.base64_encode($i).'/remove/').'"';
								}
							?>
							<?php if($i != 0) { ?>
							<a style="padding:6px 0;" class="btn btn-small btn-caps" <?php echo $strConfigureLink;?>><span><?php if($strBusNumber == ''){ echo 'Configure';} else {echo 'Edit';}?></span></a>
							<?php if($i != 0 && $strBusNumber != '') { ?>&nbsp;&nbsp;<a style="padding:6px 0;" class="btn btn-small btn-caps" <?php echo $strRemoveLink;?> ><span>Remove Sensor</span>	</a><?php } ?>
							<?php } ?>
							</div>
						</div>
					</td>	
				</tr>
			<?php } ?>
			</tbody>
		</table>
		</div>
		</div>
		<!-- Widget Tags -->
	</div>
</div>	
</div>
<script type="text/javascript">
function saveShowOnHome(iTempSensor,bStatus)
{
	$.ajax({
			type: "POST",
			url: "<?php echo site_url('home/saveTempShowOnDashboard/');?>", 
			data: {iTempSensor:iTempSensor,bStatus:bStatus},
			success: function(data) {
			}
	});
}
</script>
<!-- END : Temperature Sensors -->