<?php
/**
 *	Project : LVN 
 *	Program/Module Name : Valve Device
 *	Author : Dhiraj S. 
 *	Creation Date : 03/08/2016 
 *	Description : Save/Update the Valve default Position View.
 *	Modification History : 
 *	Change Date: 	Name: 
**/

$sAccess	=	"2";
$strBackUrl	=	base_url('home/setting/V').'/'.base64_encode($sIpID);

?>
<style>
	.form-control-custom
	{
		display:inline-block !important;	
	}
</style>

<script type="text/javascript" src="<?php echo HTTP_ASSETS_PATH.'fancybox/source/jquery.fancybox.js?v=2.1.5';?>"></script>
<link rel="stylesheet" type="text/css" href="<?php echo HTTP_ASSETS_PATH.'fancybox/source/jquery.fancybox.css?v=2.1.5';?>" media="screen" />

<script type="text/javascript">
$(document).ready(function() {
	$('.fancybox').fancybox();
});
</script>

<div id="page-wrapper">

	<div class="row">
	  <div class="col-lg-12">
		<ol class="breadcrumb">
					  <li><img src="<?php echo HTTP_IMAGES_PATH.'icons/home.png';?>" width="24" style="vertical-align: middle !important;">&nbsp;<a href="<?php echo site_url();?>">Home</a> </li>
					  <li><a href="<?php echo $strBackUrl;?>">Valve</a></li>
		</ol>
		<?php if($sucess == '1') { ?>
		  <div class="alert alert-success alert-dismissable">
			<button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
			Details saved successfully! 
		  </div>
		<?php } ?>
	  </div>
	</div>
	<!-- /.row -->
	<div class="row">
	  <div class="col-lg-12">
		<div class="panel panel-primary">
		  <div class="panel-heading" style="border-top-left-radius: 0px;border-top-right-radius: 0px;">
			<h3 class="panel-title" style="color:#FFF;">Save Default Position For Valve</h3>
		  </div>
		  <div class="panel-body">
			<div id="morris-chart-area">
			  <form action="<?php if($sAccess == 2) { echo site_url('valve/defaultPosition/'.base64_encode($sDeviceID).'/'.base64_encode($sIpID)); } else { echo '';}?>" method="post">
			  <input type="hidden" id="sDeviceID" name="sDeviceID" value="<?php echo base64_encode($sDeviceID);?>">
			  <input type="hidden" name="sIpID" value="<?php echo base64_encode($sIpID);?>">
			  
				<table border="0" cellspacing="0" cellpadding="0" width="100%">
				  <tr>
					<td width="10%"><strong>Select Default Position:</strong></td>
					<td width="1%">&nbsp;</td>
					<td width="89%">
						<select name="position" id="position" class="form-control form-control-custom" style="width:50%;height:50px;" required>
							<option value="">--Select Position--</option>
							<?php
								for($i=1;$i<=2;$i++)
								{
									$strSelect	=	'';
									
									if($i == $existPosition)
									{
										$strSelect	=	'selected="selected"';
									}
									
									$strPosition = $this->home_model->getPositionNameFromID(${"sPositionName".$i});
									
									echo '<option value="'.$i.'" '.$strSelect.'>'.$strPosition.'</option>';
								}
							?>	
						</select>
					</td>
				  </tr>
				  <tr><td colspan="3">&nbsp;</td></tr>
				  <tr>
					<td width="10%"><strong>Enter Default Position Time:</strong></td>
					<td width="1%">&nbsp;</td>
					<td width="89%">
						<input type="text" name="positiontime" id="positiontime" class="form-control form-control-custom" value="<?php echo $existPositionTime;?>" style="width:50%;height:50px;">
					</td>
				  </tr>
				  <tr><td colspan="3">&nbsp;</td></tr>
				  <tr><td colspan="3"><span class="btn btn-green"><input type="<?php if($sAccess == 2) {echo 'submit';} else { echo 'button';} ?>" name="command" value="Save" <?php if($sAccess == 2) {?> onclick="return checkForm();" <?php } ?> ></span>&nbsp;&nbsp;<a class="btn" href="<?php echo $strBackUrl;?>"><span>Back</span></a></td></tr>
				  
				</table>
			  </form>
			</div>
		  </div>
		</div>
	  </div>
	</div><!-- /.row -->
</div><!-- /#page-wrapper -->
<script type="text/javascript">
  $(document).ready(function() {
	  
  });
  function checkForm()
  {
		var position = $("#position").val();
		if(position == '')
		{
			alert("Please Select Default Position!");
			return false;
		}
		
		return true;
  }
</script>
