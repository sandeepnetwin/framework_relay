<!-- START : PUMPS -->
<?php $iPumpsNumber	=	$extra['PumpsNumber']; ?>
<div class="row">
	<div class="col-sm-6">
		<div class="widget-container widget-stats boxed green-line">
		<div class="widget-title">
			<a href="<?php echo base_url('home/setting/'.$sDevice.'/');?>" class="link-refresh" id="link-refresh-1"><span class="glyphicon glyphicon-refresh"></span></a>
			<h3>ON/OFF</h3>
		</div>
		<div class="stats-content clearfix">
			<div class="stats-content-right" style="width:96% !important; margin-left:5px; margin-right:5px; margin-top:10px; float:none;">
			<?php
				if( $iPumpsNumber == 0 || $iPumpsNumber == '' )
				{ 
			?>
					<div class="row">
						<div class="col-sm-12">
							<span style="color:red">Please add number of Pumps in the <a href="<?php echo base_url('home/setting/');?>">Settings</a> Page!</span>
						</div>
					</div>
						
			<?php 
				}
				else
				{
					$arrPump		=	array(0,1,2);
					$remainigCount	=	0;
					$chkPump		=	0;
					if(!empty($Pumps))
					{
						foreach($Pumps as $pump)
						{
							
						$i= $pump->pump_number;
						unset($arrPump[$i]);		
						$iPumpVal = $sPump[$i];
						$sPumpNameDb =  $this->home_model->getDeviceName($i,$sDevice);
						if($sPumpNameDb == '')
						  $sPumpNameDb = 'Add Name';
						
						$sStatus2Speed	=	'';
						
						$aPumpDetails = $this->home_model->getPumpDetails($i);
						$sPumpType		=	'';
						if(!empty($aPumpDetails))
						{
							foreach($aPumpDetails as $aResultEdit)
							{
								$sPumpType    = $aResultEdit->pump_type;//Pump Type
								$sPumpRelay   = $aResultEdit->relay_number;//Assigned Relay Number
								$sPumpRelay1   = $aResultEdit->relay_number_1;//Assigned Relay Number
								if($sPumpType == '12')
								{
									$iPumpVal = $sPowercenter[$sPumpRelay]; //Taken the status
								}
								else if($sPumpType == '24')
								{
									$iPumpVal = $sRelays[$sPumpRelay];//Taken the status
								}
								else if($sPumpType == '2Speed')
								{
									$sPumpSubType    = $aResultEdit->pump_sub_type;//Pump SUB Type
									$sStatus2Speed   = $aResultEdit->status;//Pump SUB Type
									
									if($sStatus2Speed == '0')
									{
										$iPumpVal        = $sStatus2Speed;
									}
									else if($sStatus2Speed == '1')											
									{
										if($sPumpSubType == '12')
										{
											$iPumpVal = $sPowercenter[$sPumpRelay]; //Taken the status
										}
										else if($sPumpSubType == '24')
										{
											$iPumpVal = $sRelays[$sPumpRelay];//Taken the status
										}
									}
									else if($sStatus2Speed == '2')											
									{
										if($sPumpSubType == '12')
										{
											$iPumpVal = $sPowercenter[$sPumpRelay1]; //Taken the status
										}
										else if($sPumpSubType == '24')
										{
											$iPumpVal = $sRelays[$sPumpRelay1];//Taken the status
										}
									}
								}
								else if(preg_match('/Emulator/',$sPumpType))
								{
									 $iPumpVal = $sPump[$i];
								}
							}
						}	//END : Getting assigned relay status from the Server.
						$sPumpVal = false;
						if($iPumpVal)
						  $sPumpVal = true;
						
						$strChecked	=	'';
						if($iPumpVal > 0)
							$strChecked	=	'class="checked"';
					  
						$sMainType	 = $this->home_model->getDeviceMainType($i,$sDevice);
						
						$strPumpName = 'Pump '.$i;
						if($sPumpNameDb != '' && $sPumpNameDb != 'Add Name')
							$strPumpName .= '<br>('.$sPumpNameDb.')';
						
						if($sStatus2Speed == '')
							$sStatus2Speed = '0';
						
						//Get Port Number
						$sDevicePort	=	$this->home_model->getDevicePort($i,$sDevice);
						
						if($sDevicePort == '')
							$sDevicePort = 0;
						
						$strPortClass	=	'port_'.$sDevicePort;
				?>
							<div class="row <?php echo $strPortClass;?>">
							<div class="col-sm-12">
							<?php if($sPumpType == '2Speed') { ?>
							<script>
							var iActiveMode = '<?php echo $iActiveMode;?>';
							var sAccess 	= '<?php echo $sAccess;?>';
							</script>
							<link href="<?php echo site_url('assets/switchy/switchy.css'); ?>" rel="stylesheet" />
							<script type="text/javascript" src="<?php echo site_url('assets/switchy/switchy.js'); ?>"></script>
							<script type="text/javascript" src="<?php echo site_url('assets/switchy/jquery.event.drag.js'); ?>"></script>
							<script type="text/javascript" src="<?php echo site_url('assets/switchy/jquery.animate-color.js'); ?>"></script>
							<div class="span1 pump-<?php echo $i?>" value="1" style="margin-top: 10px; width: auto; color: #428BCA;font-weight: bold; cursor: pointer; float: left;">Relay 1</div>
							<div class="span2" style="margin-left:5px; margin-right:5px; float: left;" >
							<select id='switch-me-<?php echo $i;?>'>
							<option value='1' <?php if($sStatus2Speed == '1') { echo 'selected="selected"';} ?>>Spa</option>
							<option value='0' <?php if($sStatus2Speed == '0' || $iPumpVal == '') { echo 'selected="selected"';} ?>></option>
							<option value='2' <?php if($sStatus2Speed == '2') { echo 'selected="selected"';} ?>>Pool</option>
							</select>
							<div class="pump-<?php echo $i?>" value="0" id="off-<?php echo $i;?>" style="color: red;font-weight: bold;width: 0; margin-left: 30px; cursor: pointer;">
								OFF
							</div>                              </div>
							<div class="span1 pump-<?php echo $i?>" value="2" style="margin-top: 10px; width: auto; color: #428BCA;font-weight: bold; cursor: pointer; float: left;">Relay 2</div>
							<div style="margin-top:10px; float:right; color:#C9376E;"><strong><?php echo $strPumpName;?></strong></div>
							
						  <script type="text/javascript">
						  
						  $(function()
						  {
							  var bgColor = '#E8E8E8';
								<?php if($iPumpVal == '1' || $iPumpVal == '2') { ?>
										bgColor = '#45A31F';
								<?php } else { ?>
										bgColor = '#E8E8E8';
								<?php } ?>
								
								$('#switch-me-<?php echo $i;?>').switchy();
								
								$('.pump-<?php echo $i?>').on('click', function(event){
									//event.preventDefault();
									//return false;
									
									var relayNumber = '<?php echo $i?>';
									var sPort	=	$("#selPort_PS_"+relayNumber).val();
									if(sPort == '')
									{
										alert("Please first select Port for Pump "+relayNumber+" !");
										$("#selPort_PS_"+relayNumber).css('border','2px red solid');
										
										$('#switch-me-<?php echo $i;?>').val(0);
									
										$('html, body').animate({
													scrollTop: $("#selPort_PS_"+relayNumber).parent().offset().top
												}, 1000);
										return false;
									}
									
									$('#switch-me-<?php echo $i;?>').val($(this).attr('value')).change();
								});
								
								$('#switch-me-<?php echo $i;?>').next('.switchy-container').find('.switchy-bar').animate({
										backgroundColor: bgColor
									});
								
								$('#switch-me-<?php echo $i;?>').on('change', function(event)
								{
									var relayNumber = '<?php echo $i?>';
									var sPort	=	$("#selPort_PS_"+relayNumber).val();
									if(sPort == '')
									{
										alert("Please first select Port for Pump "+relayNumber+" !");
										$("#selPort_PS_"+relayNumber).css('border','2px red solid');
										
										$('#switch-me-<?php echo $i;?>').val(0);
									
										$('html, body').animate({
													scrollTop: $("#selPort_PS_"+relayNumber).parent().offset().top
												}, 1000);
										return false;
									}
									
									if(sAccess == 2)
									{
										if(iActiveMode != 2)
										{
											var bConfirm	=	confirm('You will need to change to Manual mode to make this change.\nWould you like to activate manual mode?' );
											if(bConfirm)
											{
												$.ajax({
													type: "POST",
													url: "<?php echo site_url('analog/changeMode');?>", 
													data: {iMode:'2'},
													success: function(data) {
													}
												});
												//event.preventDefault();
												//return false;
												// Animate Switchy Bar background color
												var bgColor = '#E8E8E8';

												if ($(this).val() == '1' || $(this).val() == '2')
												{
													bgColor = '#45A31F';
												} 
												$('#switch-me-<?php echo $i;?>').next('.switchy-container').find('.switchy-bar').animate({
													backgroundColor: bgColor
												});
											
												
												//$("#loading_valve_<?php //echo $i;?>").css('visibility','visible');
												$.ajax({
													type: "POST",
													url: "<?php echo site_url('home/updateStatusOnOff');?>", 
													data: {sName:'<?php echo $i;?>',sStatus:$(this).val(),sDevice:'<?php echo $sDevice;?>'},
													success: function(data) {
													//$("#loading_valve_<?php //echo $i;?>").css('visibility','hidden');
													location.reload();
													}

												});
											}
										}
										else											
										{
											//event.preventDefault();
											//return false;
											// Animate Switchy Bar background color
											var bgColor = '#E8E8E8';

											if ($(this).val() == '1' || $(this).val() == '2')
											{
												bgColor = '#45A31F';
											} 
											$('#switch-me-<?php echo $i;?>').next('.switchy-container').find('.switchy-bar').animate({
												backgroundColor: bgColor
											});
										
											
											//$("#loading_valve_<?php //echo $i;?>").css('visibility','visible');
											$.ajax({
												type: "POST",
												url: "<?php echo site_url('home/updateStatusOnOff');?>", 
												data: {sName:'<?php echo $i;?>',sStatus:$(this).val(),sDevice:'<?php echo $sDevice;?>'},
												success: function(data) {
												//$("#loading_valve_<?php //echo $i;?>").css('visibility','hidden');
												}

											});
										}
									}
								});
							});
					   </script>
					   
							<?php } else if($sPumpType != '') { ?>
							
							<?php if(preg_match('/Emulator/',$sPumpType)) { ?>
							<script>
							  $(document).ready(function() {
								setInterval( function() {
									$.getJSON('<?php echo site_url('cron/pumpResponseLatest/');?>', {iPumpID: "<?php echo $i;?>"}, function(json) {
										
										if(json == '')
										{
											$("#lablePump-"+<?php echo $i;?>).removeClass('checked');
											$("#pumpRealResponse_"+<?php echo $i;?>).html('');
											$("#pumpProgrmaStatus_"+<?php echo $i;?>).html('');
										}
										else
										{
											$("#pumpRealResponse_"+<?php echo $i;?>).html(json);
											if($("#lablePump-"+<?php echo $i;?>).hasClass('checked'))
											{}
											else
											{
												$("#lablePump-"+<?php echo $i;?>).addClass('checked');
											}
										}
									});
									},30000);
									
									setInterval( function() {
									$.getJSON('<?php echo site_url('cron/getPumpProgramStatus/');?>', {iPumpID: "<?php echo $i;?>"}, function(json) {
										
										if(json == '')
										{
											$("#pumpProgrmaStatus_"+<?php echo $i;?>).html('');
										}
										else
										{
											$("#pumpProgrmaStatus_"+<?php echo $i;?>).html(json);
										}
									});
									},30000);
									
							  });
							</script>										  
							   <?php } ?>
							<div class="rowCheckbox switch">
								<div class="custom-checkbox"><input type="checkbox" value="<?php echo $i;?>" id="pumps-<?php echo $i?>" name="pumps-<?php echo $i?>" class="pumpsButton" hidefocus="true" style="outline: medium none;">
									<label style="margin-left: 10px;" <?php echo $strChecked;?>  id="lablePump-<?php echo $i?>" for="pumps-<?php echo $i?>"><span style="float:right; color:#C9376E;"><?php echo $strPumpName;?></span></label>
								</div>
							</div>
								<?php if(preg_match('/Emulator/',$sPumpType)) { ?>
								<div id="pumpRealResponse_<?php echo $i;?>" style="color: #164c87;font-weight: bold;"><?php if($iPumpVal > 0) { echo $strPumpsResponse		= $this->home_model->selectPumpsLatestResponse($i); }?></div>
								<div id="pumpProgrmaStatus_<?php echo $i;?>" style="color: #c9376e;font-weight: bold;"><?php if($iPumpVal > 0)
								{
									$aAllActiveProgram	=	$this->home_model->getAllActiveProgramsForPump($i);
									$strMessage		=	'';	
									if(!empty($aAllActiveProgram))
									{
										foreach($aAllActiveProgram as $aActiveProgram)
										{
											if($aActiveProgram->device_type == 'PS')
											{
												$aPumpDetails 	=	$this->home_model->getPumpDetails($aActiveProgram->device_number);
												
												if(is_array($aPumpDetails) && !empty($aPumpDetails))
												{
													foreach($aPumpDetails as $aResultEdit)
													{ 
														$sPumpNumber  = $aResultEdit->pump_number;
														$sPumpType    = $aResultEdit->pump_type;
														$sPumpSubType = $aResultEdit->pump_sub_type;
														$sPumpSpeed   = $aResultEdit->pump_speed;
													}
												}
												
												if($strMessage != '')
												{
													$strMessage .= ' <br /><strong>'.$aActiveProgram->program_name.'</strong> Program is Running for <strong>Pump '.$aActiveProgram->device_number.'</strong>';
													
													if($sPumpType	==	'Emulator' && $sPumpSubType == 'VS')
													{
														$strMessage .= ' With <strong>Speed '.$sPumpSpeed.' </strong>';
													}
													$strMessage .= '!';
												}
												else
												{
													$strMessage .= '<strong>'.$aActiveProgram->program_name.'</strong> Program is Running for <strong>Pump '.$aActiveProgram->device_number.'</strong>';
													
													if($sPumpType	==	'Emulator' && $sPumpSubType == 'VS')
													{
														$strMessage .= ' With <strong>Speed '.$sPumpSpeed.' </strong>';
													}
													$strMessage .= '!';
												}
											}
										}
									}	
									echo $strMessage;		
								}?></div>
								<?php } ?>
							<?php } ?>
							</div>
							</div>
							<div style="height:20px;">&nbsp;</div>
						<?php 
							$chkPump++;
						}
						?>
					<?php } ?>
					<?php 
						$remainigCount	=	$iPumpsNumber - $chkPump;
						//for ($i=0;$i < $valve_count; $i++)	
						//for ($i=0;$i < $remainigCount ; $i++)
						foreach($arrPump as $i)	
						{
							if($remainigCount == 0)	
								break;
							
							$remainigCount--;
									
						//for ($i=0;$i < $pump_count; $i++)
						//{
							$iPumpVal = $sPump[$i];
							/* $iPumpNewValSb = 1;
							if($iPumpVal == 1)
							{
							  $iPumpNewValSb = 0;
							}
							$sPumpVal = false;
							if($iPumpVal)
							  $sPumpVal = true; */
							//$sRelayNameDb = get_device_name(1, $i);
						
							$sPumpNameDb =  $this->home_model->getDeviceName($i,$sDevice);
							if($sPumpNameDb == '')
							  $sPumpNameDb = 'Add Name';
							
							//$iPower	 = $this->home_model->getDevicePower($i,$sDevice);
							
							//$sPowercenter = '01000000'		;
							//START : Getting assigned relay status from the Server.	
							//Details of Pump
							
							$sStatus2Speed	=	'';
							
							$aPumpDetails = $this->home_model->getPumpDetails($i);
							$sPumpType		=	'';
							if(!empty($aPumpDetails))
							{
								foreach($aPumpDetails as $aResultEdit)
								{
									$sPumpType    = $aResultEdit->pump_type;//Pump Type
									$sPumpRelay   = $aResultEdit->relay_number;//Assigned Relay Number
									$sPumpRelay1   = $aResultEdit->relay_number_1;//Assigned Relay Number
									if($sPumpType == '12')
									{
										$iPumpVal = $sPowercenter[$sPumpRelay]; //Taken the status
									}
									else if($sPumpType == '24')
									{
										$iPumpVal = $sRelays[$sPumpRelay];//Taken the status
									}
									else if($sPumpType == '2Speed')
									{
										$sPumpSubType    = $aResultEdit->pump_sub_type;//Pump SUB Type
										$sStatus2Speed   = $aResultEdit->status;//Pump SUB Type
										
										
										if($sStatus2Speed == '0')
										{
											$iPumpVal        = $sStatus2Speed;
										}
										else if($sStatus2Speed == '1')											
										{
											if($sPumpSubType == '12')
											{
												$iPumpVal = $sPowercenter[$sPumpRelay]; //Taken the status
											}
											else if($sPumpSubType == '24')
											{
												$iPumpVal = $sRelays[$sPumpRelay];//Taken the status
											}
										}
										else if($sStatus2Speed == '2')											
										{
											if($sPumpSubType == '12')
											{
												$iPumpVal = $sPowercenter[$sPumpRelay1]; //Taken the status
											}
											else if($sPumpSubType == '24')
											{
												$iPumpVal = $sRelays[$sPumpRelay1];//Taken the status
											}
										}
									}
									else if(preg_match('/Emulator/',$sPumpType))
									{
										 $iPumpVal = $sPump[$i];
									}
								}
							}	//END : Getting assigned relay status from the Server.
							$sPumpVal = false;
							if($iPumpVal)
							  $sPumpVal = true;
						  
							$sMainType	 = $this->home_model->getDeviceMainType($i,$sDevice);
							
							$strChecked	=	'';
							if($iPumpVal > '1')
								$strChecked	=	'class="checked"';
							
							$strPumpName = 'Pump '.$i;
							if($sPumpNameDb != '' && $sPumpNameDb != 'Add Name')
								$strPumpName .= '<br>('.$sPumpNameDb.')';
							
							if($sStatus2Speed == '')
								$sStatus2Speed = '0';
							
							//Get Port Number
							$sDevicePort	=	$this->home_model->getDevicePort($i,$sDevice);
							
							if($sDevicePort == '')
								$sDevicePort = 0;
							
							$strPortClass	=	'port_'.$sDevicePort;
					?>	
							<div class="row <?php echo $strPortClass;?>">
							<div class="col-sm-12">
							<?php if($sPumpType == '2Speed') { ?>
							<script>
								var iActiveMode = '<?php echo $iActiveMode;?>';
								var sAccess 	= '<?php echo $sAccess;?>';
							</script>
							<link href="<?php echo site_url('assets/switchy/switchy.css'); ?>" rel="stylesheet" />
							<script type="text/javascript" src="<?php echo site_url('assets/switchy/switchy.js'); ?>"></script>
							<script type="text/javascript" src="<?php echo site_url('assets/switchy/jquery.event.drag.js'); ?>"></script>
							<script type="text/javascript" src="<?php echo site_url('assets/switchy/jquery.animate-color.js'); ?>"></script>
							<div class="span1 pump-<?php echo $i?>" value="1" style="margin-top: 10px; width: auto; color: #428BCA;font-weight: bold; cursor: pointer; float: left;">Relay 1</div>
							<div class="span2" style="margin-left:5px; margin-right:5px; float: left;" >
							<select id='switch-me-<?php echo $i;?>'>
							<option value='1' <?php if($sStatus2Speed == '1') { echo 'selected="selected"';} ?>>Spa</option>
							<option value='0' <?php if($sStatus2Speed == '0' || $iPumpVal == '') { echo 'selected="selected"';} ?>></option>
							<option value='2' <?php if($sStatus2Speed == '2') { echo 'selected="selected"';} ?>>Pool</option>
							</select>
							<div class="pump-<?php echo $i?>" value="0" id="off-<?php echo $i;?>" style="color: red;font-weight: bold;width: 0; margin-left: 30px; cursor: pointer;">
								OFF
	</div>                              </div>
							<div class="span1 pump-<?php echo $i?>" value="2" style="margin-top: 10px; width: auto; color: #428BCA;font-weight: bold; cursor: pointer; float: left;">Relay 2</div>
							<div style="margin-top:10px; float:right; color:#C9376E;"><strong><?php echo $strPumpName;?></strong></div>
						  <script type="text/javascript">
						  
						  $(function()
						  {
							  var bgColor = '#E8E8E8';
								<?php if($iPumpVal == '1' || $iPumpVal == '2') { ?>
										bgColor = '#45A31F';
								<?php } else { ?>
										bgColor = '#E8E8E8';
								<?php } ?>
								
								$('#switch-me-<?php echo $i;?>').switchy();
								
								$('.pump-<?php echo $i?>').on('click', function(event){
									//event.preventDefault();
									//return false;
									
									var relayNumber = '<?php echo $i?>';
									var sPort	=	$("#selPort_PS_"+relayNumber).val();
									if(sPort == '')
									{
										alert("Please first select Port for Pump "+relayNumber+" !");
										$("#selPort_PS_"+relayNumber).css('border','2px red solid');
										
										$('#switch-me-<?php echo $i;?>').val(0);
									
										$('html, body').animate({
													scrollTop: $("#selPort_PS_"+relayNumber).parent().offset().top
												}, 1000);
										return false;
									}
									
									$('#switch-me-<?php echo $i;?>').val($(this).attr('value')).change();
								});
								
								$('#switch-me-<?php echo $i;?>').next('.switchy-container').find('.switchy-bar').animate({
										backgroundColor: bgColor
									});
								
								$('#switch-me-<?php echo $i;?>').on('change', function(event)
								{
									var relayNumber = '<?php echo $i?>';
									var sPort	=	$("#selPort_PS_"+relayNumber).val();
									if(sPort == '')
									{
										alert("Please first select Port for Pump "+relayNumber+" !");
										$("#selPort_PS_"+relayNumber).css('border','2px red solid');
										
										$('#switch-me-<?php echo $i;?>').val(0);
									
										$('html, body').animate({
													scrollTop: $("#selPort_PS_"+relayNumber).parent().offset().top
												}, 1000);
										return false;
									}
									
									if(sAccess == 2)
									{
										if(iActiveMode != 2)
										{
											var bConfirm	=	confirm('You will need to change to Manual mode to make this change.\nWould you like to activate manual mode?' );
											if(bConfirm)
											{
												$.ajax({
													type: "POST",
													url: "<?php echo site_url('analog/changeMode');?>", 
													data: {iMode:'2'},
													success: function(data) {
													}
												});
												//event.preventDefault();
												//return false;
												// Animate Switchy Bar background color
												var bgColor = '#E8E8E8';

												if ($(this).val() == '1' || $(this).val() == '2')
												{
													bgColor = '#45A31F';
												} 
												$('#switch-me-<?php echo $i;?>').next('.switchy-container').find('.switchy-bar').animate({
													backgroundColor: bgColor
												});
											
												
												//$("#loading_valve_<?php //echo $i;?>").css('visibility','visible');
												$.ajax({
													type: "POST",
													url: "<?php echo site_url('home/updateStatusOnOff');?>", 
													data: {sName:'<?php echo $i;?>',sStatus:$(this).val(),sDevice:'<?php echo $sDevice;?>'},
													success: function(data) {
													//$("#loading_valve_<?php //echo $i;?>").css('visibility','hidden');
													location.reload();
													}

												});
											}
										}
										else											
										{
											//event.preventDefault();
											//return false;
											// Animate Switchy Bar background color
											var bgColor = '#E8E8E8';

											if ($(this).val() == '1' || $(this).val() == '2')
											{
												bgColor = '#45A31F';
											} 
											$('#switch-me-<?php echo $i;?>').next('.switchy-container').find('.switchy-bar').animate({
												backgroundColor: bgColor
											});
										
											
											//$("#loading_valve_<?php //echo $i;?>").css('visibility','visible');
											$.ajax({
												type: "POST",
												url: "<?php echo site_url('home/updateStatusOnOff');?>", 
												data: {sName:'<?php echo $i;?>',sStatus:$(this).val(),sDevice:'<?php echo $sDevice;?>'},
												success: function(data) {
												//$("#loading_valve_<?php //echo $i;?>").css('visibility','hidden');
												}

											});
										}
									}
								});
							});
					   </script>
					   
							<?php } else if($sPumpType != '') { ?>
							 <div class="rowCheckbox switch">
								<div class="custom-checkbox"><input type="checkbox" value="<?php echo $i;?>" id="pumps-<?php echo $i?>" name="pumps-<?php echo $i?>" class="pumpsButton" hidefocus="true" style="outline: medium none;">
									<label style="margin-left: 10px;" <?php echo $strChecked;?>  id="lablePump-<?php echo $i?>" for="pumps-<?php echo $i?>"><span style="color:#C9376E;float:right;" ><?php echo $strPumpName;?></span></label>
								</div>
							</div>
							
							<?php } else if($sPumpType == '') { ?>
							<span style="color:#E94180;"><strong>Pump <?php echo $i; ?> not configured.</strong></span>
							<?php } ?>
							</div>
							</div>
							<div style="height:20px;">&nbsp;</div>
						<?php } ?>
				<?php } ?>
			</div>
		</div>
		</div>
	</div>
	  
	<div class="col-sm-6">
			<!-- Statistics -->
			<div class="widget-container widget-stats boxed green-line">
				<div class="widget-title">
					<a href="<?php echo base_url('home/setting/'.$sDevice.'/');?>" class="link-refresh" id="link-refresh-1"><span class="glyphicon glyphicon-refresh"></span></a>
					<h3>PUMP Settings</h3>
				</div>
				<div class="stats-content clearfix">
					<div class="stats-content-right" style="width:100% !important; margin-left:5px; margin-right:5px; float:none;">
				
				  <table class="table table-hover">
					<thead>
					  <tr>
						<th class="header">Pump</th>
					  </tr>
					</thead>
					<tbody>
					
					<?php
		
					if( $iPumpsNumber == 0 || $iPumpsNumber == '' )
					{ ?>
						
						<tr>
							<td>
								<div class="row">
									<div class="col-sm-12">
										<span style="color:red">Please add number of Pumps in the <a href="<?php echo base_url('home/setting/');?>">Settings</a> Page!</span>
									</div>	
								</div>
							</td>
						</tr>
						
					<?php 
					}
					else
					{
						$arrPump		=	array(0,1,2);
						$remainigCount	=	0;
						$chkPump		=	0;
						if(!empty($Pumps))
						{
							foreach($Pumps as $pump)
							{
								
							$i= $pump->pump_number;
							unset($arrPump[$i]);		
							//for ($i=0;$i < $pump_count; $i++)
							//{
							$iPumpVal = $sPump[$i];
							/* $iPumpNewValSb = 1;
							if($iPumpVal == 1)
							{
							  $iPumpNewValSb = 0;
							}
							$sPumpVal = false;
							if($iPumpVal)
							  $sPumpVal = true; */
							//$sRelayNameDb = get_device_name(1, $i);
						
							$sPumpNameDb =  $this->home_model->getDeviceName($i,$sDevice);
							if($sPumpNameDb == '')
							  $sPumpNameDb = 'Add Name';
							
							//$iPower	 = $this->home_model->getDevicePower($i,$sDevice);
							$sStatus2Speed	=	'';
							//$sPowercenter = '01000000'		;
							//START : Getting assigned relay status from the Server.	
							//Details of Pump
							$aPumpDetails = $this->home_model->getPumpDetails($i);
							$sPumpType		=	'';
							$sPumpSpeed		=	'';
							if(!empty($aPumpDetails))
							{
								foreach($aPumpDetails as $aResultEdit)
								{
									$sPumpType    = $aResultEdit->pump_type;//Pump Type
									$sPumpRelay   = $aResultEdit->relay_number;//Assigned Relay Number
									$sPumpRelay1   = $aResultEdit->relay_number_1;//Assigned Relay Number
									if($sPumpType == '12')
									{
										$iPumpVal = $sPowercenter[$sPumpRelay]; //Taken the status
									}
									else if($sPumpType == '24')
									{
										$iPumpVal = $sRelays[$sPumpRelay];//Taken the status
									}
									else if($sPumpType == '2Speed')
									{
										$sPumpSubType    = $aResultEdit->pump_sub_type;//Pump SUB Type
										$sStatus2Speed   = $aResultEdit->status;//Pump SUB Type
										
										
										if($sStatus2Speed == '0')
										{
											$iPumpVal        = $sStatus2Speed;
										}
										else if($sStatus2Speed == '1')											
										{
											if($sPumpSubType == '12')
											{
												$iPumpVal = $sPowercenter[$sPumpRelay]; //Taken the status
											}
											else if($sPumpSubType == '24')
											{
												$iPumpVal = $sRelays[$sPumpRelay];//Taken the status
											}
										}
										else if($sStatus2Speed == '2')											
										{
											if($sPumpSubType == '12')
											{
												$iPumpVal = $sPowercenter[$sPumpRelay1]; //Taken the status
											}
											else if($sPumpSubType == '24')
											{
												$iPumpVal = $sRelays[$sPumpRelay1];//Taken the status
											}
										}
									}
									else if(preg_match('/Emulator/',$sPumpType) || preg_match('/Intellicom/',$sPumpType))
									{
										 $iPumpVal 		= $sPump[$i];
										 $sPumpSpeed 	= $aResultEdit->pump_speed;	
									}
								}
							}	//END : Getting assigned relay status from the Server.
							$sPumpVal = false;
							if($iPumpVal)
							  $sPumpVal = true;
						  
							$strChecked	=	'';
							if($iPumpVal == '1')
								$strChecked	=	'class="checked"';
						  
							$sMainType	 = $this->home_model->getDeviceMainType($i,$sDevice);
							
							$strPumpName = 'Pump '.$i;
							if($sPumpNameDb != '' && $sPumpNameDb != 'Add Name')
								$strPumpName .= ' ('.$sPumpNameDb.')';
					?>
						<tr>
						<td>
						<div class="row">
							<div class="col-sm-3">
								Pump <?php echo $i;?><br />(<a href="<?php if($sAccess == 2) { echo site_url('home/deviceName/'.base64_encode($i).'/'.base64_encode($sDevice).'/'); } else { echo 'javascript:void(0);';}?>" ><?php echo $sPumpNameDb;?></a>)<!--<a href="javascript:void(0);" class="btn btn-red btn-small" style="padding:6px 0;"><span><?php //echo $sPumpType;?></span></a>-->
							</div>
							<div class="col-sm-3">
							<div class="rowRadio">
							<div class="custom-radio">
							<strong class="customType">Type</strong><br><br><input class="pumpRadio" type="radio" id="radio_other_<?php echo $i;?>" value="0" name="<?php echo $i;?>_MainType" <?php if($sMainType == '0' || $sMainType == ''){ echo 'checked="checked"';}?> <?php if($sAccess == '1') { echo 'disabled="disabled"';}?> hidefocus="true" style="outline: medium none;">
							<label id="relay_other_<?php echo $i;?>" for="radio_other_<?php echo $i;?>" class="<?php if($sMainType == '0' || $sMainType == ''){ echo 'checked';}?>" style="display:inline-block;">Other</label>
							
							<input class="pumpRadio" type="radio" id="radio_spa_<?php echo $i;?>" name="<?php echo $i;?>_MainType" value="1" <?php if($sMainType == '1'){ echo 'checked="checked"';}?> <?php if($sAccess == '1') { echo 'disabled="disabled"';}?> hidefocus="true" style="outline: medium none;">
							<label id="relay_spa_<?php echo $i;?>" for="radio_spa_<?php echo $i;?>" class="<?php if($sMainType == '1'){ echo 'checked';}?>" style="display:inline-block;">Spa</label>
							
							<input class="pumpRadio" type="radio" id="radio_pool_<?php echo $i;?>" name="<?php echo $i;?>_MainType" value="2" <?php if($sMainType == '2'){ echo 'checked="checked"';}?> <?php if($sAccess == '1') { echo 'disabled="disabled"';}?> hidefocus="true" style="outline: medium none;">
							<label id="relay_pool_<?php echo $i;?>" for="radio_pool_<?php echo $i;?>" class="<?php if($sMainType == '2'){ echo 'checked';}?>" style="display:inline-block;">Pool</label>
							
							</div></div>
							<hr />
							<strong>Select Port: </strong><select name="selPort_V_<?php echo $i;?>" id="selPort_V_<?php echo $i;?>" onchange="saveDevicePort('<?php echo $i;?>','<?php echo $sDevice;?>',this.value)">
									<option value="" <?php if($sDevicePort == ''){ echo 'selected="selected"'; }?>>-- Port--</option>
									<option value="<?php echo $sPort;?>" <?php if($sDevicePort == $sPort){ echo 'selected="selected"'; }?>><?php echo $sPort;?></option>
									<option value="<?php echo $sPort2;?>" <?php if($sDevicePort == $sPort2){ echo 'selected="selected"'; }?>><?php echo $sPort2;?></option>
							</select>
							<hr />
						</div>
						<div class="col-sm-6">
						<strong>Action</strong><br><br>
						<a class="btn btn-green btn-small" href="<?php if($sAccess == 2){echo site_url('home/pumpConfigure/'.base64_encode($i).'/');}else{echo 'javscript:void(0);';}?>" style="padding:6px 0;"><span>Configure</span></a>
						<a class="btn btn-small" href="<?php if($sAccess == 2){ echo site_url('home/setProgramsPump/'.base64_encode($i).'/');} else {echo 'javascript:void(0);';}?>" style="padding:6px 0;"><span>Programs</span></a>
						<?php 
							if(preg_match('/Emulator/',$sPumpType) || preg_match('/Intellicom/',$sPumpType)) {
						?>									
						<div style="padding-top: 10px; padding-bottom: 10px;">
						Change Speed: <br />	
						<input type="radio" class="pumpSpeedSet" name="pageSpeed_<?php echo $i;?>" id="pageSpeed0" <?php if($sPumpSpeed == 0) {echo 'checked="checked";';}?> value="0">&nbsp;0&nbsp;&nbsp;
						<input type="radio" class="pumpSpeedSet" name="pageSpeed_<?php echo $i;?>" id="pageSpeed1" value="1" <?php if($sPumpSpeed == 1) {echo 'checked="checked";';}?>>&nbsp;1&nbsp;&nbsp;
						<input type="radio" class="pumpSpeedSet" name="pageSpeed_<?php echo $i;?>" id="pageSpeed2" value="2" <?php if($sPumpSpeed == 2) {echo 'checked="checked";';}?>>&nbsp;2&nbsp;&nbsp;
						<input type="radio" class="pumpSpeedSet" name="pageSpeed_<?php echo $i;?>" id="pageSpeed3" value="3" <?php if($sPumpSpeed == 3) {echo 'checked="checked";';}?>>&nbsp;3&nbsp;&nbsp;
						<input type="radio" class="pumpSpeedSet" name="pageSpeed_<?php echo $i;?>" id="pageSpeed4" value="4" <?php if($sPumpSpeed == 4) {echo 'checked="checked";';}?>>&nbsp;4&nbsp;&nbsp;
						</div>
						<?php } ?>
						<div style="padding-top: 10px; padding-bottom: 10px;">
						<a style="padding:6px 0;" href="javascript:void(0);" onclick="removePump('<?php echo $i;?>')" class="btn btn-small"><span>Remove Pump</span>
						</a>&nbsp;&nbsp;<span id="loadingImgPumpRemove_<?php echo $i;?>" style="display:none;"><img src="<?php echo site_url('assets/images/loading.gif');?>" alt="Loading...." width="32" height="32"></span>
						</div>	
						</div>	
						</td>
						</tr>
						<?php 
								$chkPump++;
						} ?>
							
						<?php }
								
							$remainigCount	=	$iPumpsNumber - $chkPump;
							//for ($i=0;$i < $valve_count; $i++)	
							//for ($i=0;$i < $remainigCount ; $i++)
							foreach($arrPump as $i)	
							{
								if($remainigCount == 0)	
									break;
								
								$remainigCount--;
										
								$iPumpVal = $sPump[$i];
							
								$sPumpNameDb =  $this->home_model->getDeviceName($i,$sDevice);
								if($sPumpNameDb == '')
								  $sPumpNameDb = 'Add Name';
								
								$sStatus2Speed	=	'';
								
								//Details of Pump
								$aPumpDetails = $this->home_model->getPumpDetails($i);
								$sPumpType		=	'';
								$sPumpSpeed 	= 	'';	
								
								if(!empty($aPumpDetails))
								{
									foreach($aPumpDetails as $aResultEdit)
									{
										$sPumpType    = $aResultEdit->pump_type;//Pump Type
										$sPumpRelay   = $aResultEdit->relay_number;//Assigned Relay Number
										$sPumpRelay1   = $aResultEdit->relay_number_1;//Assigned Relay Number
										if($sPumpType == '12')
										{
											$iPumpVal = $sPowercenter[$sPumpRelay]; //Taken the status
										}
										else if($sPumpType == '24')
										{
											$iPumpVal = $sRelays[$sPumpRelay];//Taken the status
										}
										else if($sPumpType == '2Speed')
										{
											$sPumpSubType    = $aResultEdit->pump_sub_type;//Pump SUB Type
											$sStatus2Speed   = $aResultEdit->status;//Pump SUB Type
											
											
											if($sStatus2Speed == '0')
											{
												$iPumpVal        = $sStatus2Speed;
											}
											else if($sStatus2Speed == '1')											
											{
												if($sPumpSubType == '12')
												{
													$iPumpVal = $sPowercenter[$sPumpRelay]; //Taken the status
												}
												else if($sPumpSubType == '24')
												{
													$iPumpVal = $sRelays[$sPumpRelay];//Taken the status
												}
											}
											else if($sStatus2Speed == '2')											
											{
												if($sPumpSubType == '12')
												{
													$iPumpVal = $sPowercenter[$sPumpRelay1]; //Taken the status
												}
												else if($sPumpSubType == '24')
												{
													$iPumpVal = $sRelays[$sPumpRelay1];//Taken the status
												}
											}
										}
										else if(preg_match('/Emulator/',$sPumpType) || preg_match('/Intellicom/',$sPumpType))
										{
											 $iPumpVal 		= $sPump[$i];
											 $sPumpSpeed 	= $aResultEdit->pump_speed;	
										}
									}
								}	//END : Getting assigned relay status from the Server.
								
								$sPumpVal = false;
								if($iPumpVal)
								  $sPumpVal = true;
							  
								$sMainType	 = $this->home_model->getDeviceMainType($i,$sDevice);
								
								$strChecked	=	'';
								if($iPumpVal == '1')
									$strChecked	=	'class="checked"';
								
								$strPumpName = 'Pump '.$i;
								if($sPumpNameDb != '')
									$strPumpName .= ' ('.$sPumpNameDb.')';
									
								//Get Port Number
								$sDevicePort	=	$this->home_model->getDevicePort($i,$sDevice);
								
								if($sDevicePort == '')
									$sDevicePort = 0;
								
								$strPortClass	=	'port_'.$sDevicePort;
						?>	
						<tr class="<?php echo $strPortClass; ?>">
						<td>Pump <?php echo $i;?><br />(<a href="<?php if($sAccess == 2) { echo site_url('home/deviceName/'.base64_encode($i).'/'.base64_encode($sDevice).'/'); } else { echo 'javascript:void(0);';}?>" ><?php echo $sPumpNameDb;?></a>)</td>
						<td>
							<div class="rowRadio">
							<div class="custom-radio">
								<input class="pumpRadio" type="radio" id="radio_other_<?php echo $i;?>" value="0" name="<?php echo $i;?>_MainType" <?php if($sMainType == '0' || $sMainType == ''){ echo 'checked="checked"';}?> <?php if($sAccess == '1') { echo 'disabled="disabled"';}?> hidefocus="true" style="outline: medium none;">
								<label id="relay_other_<?php echo $i;?>" for="radio_other_<?php echo $i;?>" class="<?php if($sMainType == '0' || $sMainType == ''){ echo 'checked';}?>">Other</label>
								
								<input class="pumpRadio" type="radio" id="radio_spa_<?php echo $i;?>" name="<?php echo $i;?>_MainType" value="1" <?php if($sMainType == '1'){ echo 'checked="checked"';}?> <?php if($sAccess == '1') { echo 'disabled="disabled"';}?> hidefocus="true" style="outline: medium none;">
								<label id="relay_spa_<?php echo $i;?>" for="radio_spa_<?php echo $i;?>" class="<?php if($sMainType == '1'){ echo 'checked';}?>">Spa</label>
								
								<input class="pumpRadio" type="radio" id="radio_pool_<?php echo $i;?>" name="<?php echo $i;?>_MainType" value="2" <?php if($sMainType == '2'){ echo 'checked="checked"';}?> <?php if($sAccess == '1') { echo 'disabled="disabled"';}?> hidefocus="true" style="outline: medium none;">
								<label id="relay_pool_<?php echo $i;?>" for="radio_pool_<?php echo $i;?>" class="<?php if($sMainType == '2'){ echo 'checked';}?>">Pool</label>
							</div>
							</div>
							<hr />
							<strong>Select Port: </strong><select name="selPort_V_<?php echo $i;?>" id="selPort_V_<?php echo $i;?>" onchange="saveDevicePort('<?php echo $i;?>','<?php echo $sDevice;?>',this.value)">
									<option value="" <?php if($sDevicePort == ''){ echo 'selected="selected"'; }?>>-- Port--</option>
									<option value="<?php echo $sPort;?>" <?php if($sDevicePort == $sPort){ echo 'selected="selected"'; }?>><?php echo $sPort;?></option>
									<option value="<?php echo $sPort2;?>" <?php if($sDevicePort == $sPort2){ echo 'selected="selected"'; }?>><?php echo $sPort2;?></option>
							</select>
							<hr />
						</td>
						<td><a class="btn btn-green btn-small" href="<?php if($sAccess == 2){echo site_url('home/pumpConfigure/'.base64_encode($i).'/');}else{echo 'javscript:void(0);';}?>"><span>Configure</span></a>&nbsp;&nbsp;
							<a class="btn btn-small" href="<?php if($sAccess == 2){ echo site_url('home/setProgramsPump/'.base64_encode($i).'/');} else {echo 'javascript:void(0);';}?>"><span>Programs</span></a>
							<?php 
							if(preg_match('/Emulator/',$sPumpType) || preg_match('/Intellicom/',$sPumpType)) {
						?>									
						<div style="padding-top: 10px; padding-bottom: 10px;">
						Change Speed: <br />	
						<input type="radio" class="pumpSpeedSet" name="pageSpeed_<?php echo $i;?>" id="pageSpeed0" <?php if($sPumpSpeed == 0) {echo 'checked="checked";';}?> value="0">&nbsp;0&nbsp;&nbsp;
						<input type="radio" class="pumpSpeedSet" name="pageSpeed_<?php echo $i;?>" id="pageSpeed1" value="1" <?php if($sPumpSpeed == 1) {echo 'checked="checked";';}?>>&nbsp;1&nbsp;&nbsp;
						<input type="radio" class="pumpSpeedSet" name="pageSpeed_<?php echo $i;?>" id="pageSpeed2" value="2" <?php if($sPumpSpeed == 2) {echo 'checked="checked";';}?>>&nbsp;2&nbsp;&nbsp;
						<input type="radio" class="pumpSpeedSet" name="pageSpeed_<?php echo $i;?>" id="pageSpeed3" value="3" <?php if($sPumpSpeed == 3) {echo 'checked="checked";';}?>>&nbsp;3&nbsp;&nbsp;
						<input type="radio" class="pumpSpeedSet" name="pageSpeed_<?php echo $i;?>" id="pageSpeed4" value="4" <?php if($sPumpSpeed == 4) {echo 'checked="checked";';}?>>&nbsp;4&nbsp;&nbsp;
						</div>
							<?php } ?>	
						<div style="padding-top: 10px; padding-bottom: 10px;">
						<a href="javascript:void(0);" onclick="removePump('<?php echo $i;?>')" class="btn btn-small"><span>Remove Pump</span>
						</a>&nbsp;&nbsp;<span id="loadingImgPumpRemove_<?php echo $i;?>" style="display:none;"><img src="<?php echo site_url('assets/images/loading.gif');?>" alt="Loading...." width="32" height="32"></span>
						</div>			
						</td>
						</tr>
								<?php } ?>
						<?php } ?>		
					</tbody>
					</table>
					</div>
				</div>
			</div>
			<!--/ Statistics -->
		</div>
</div><!-- /.row -->
<!-- END : PUMPS -->