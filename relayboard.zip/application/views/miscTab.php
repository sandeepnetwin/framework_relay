<h3>Miscellaneous Setting</h3>
            <section>
			<div class="col-sm-12">
			<label for="no_blower">How many Spa/Pool Miscellaneous devices do you have?<span class="requiredMark">*</span>&nbsp;<img src="<?php echo HTTP_ASSETS_PATH.'images/help.png';?>" width="24" class="tooltipster-icon" title="Please select number of Miscellaneous devices used in the mode?" /></label><a class="changeLink" id="changeLinkLight" href="javascript:void(0);" onclick="javascript:$('#MiscForm').toggleClass('disableConfig');" style="float:right;" title="Click here to Enable/Disable Miscellaneous devices related settings!">Enable/Disable Miscellaneous Configuration</a>
			<select name="no_misc" id="no_misc" class="form-control" multiple>
				<option <?php if(isset($arrMore['misc']) &&  empty($arrMore['misc'])){echo 'selected="selected"';}?> value="">Select Devices</option>
				<?php
					for($i=0;$i<($extra['MiscNumber']+1);$i++)
					{
				?>		
						<option <?php if(isset($arrMore['misc']) &&  in_array($i,$arrMore['misc'])){echo 'selected="selected"';}?> value="<?php echo $i;?>"><?php echo $i;?> Device</option>
				<?php
					}
				?>	
			</select>
			<div style="height:10px">&nbsp;</div>
			</div>	
            </section>