<?php
$sDeviceFullName = '';
$sAccess 		 = '';
$sModule	     = '';
if($sDevice == 'R')
{
  $sDeviceFullName = 'Relay';
  $sModule	    = 2;
}
if($sDevice == 'P')
{
	$sDeviceFullName = 'Power Center';
	$sModule	     = 3;
}
if($sDevice == 'V')
{
	$sDeviceFullName = 'Valve';
	$sModule	     = 8;
}

//Get Permission Details
  $userID = $this->session->userdata('id');
  $aPermissions = json_decode(getPermissionOfModule($userID));
 
  $aModules 		= $aPermissions->sPermissionModule;	
  $aAllActiveModule = $aPermissions->sActiveModule;
  
  $sAccessKey	= 'access_'.$sModule;
  
  if(!empty($aModules))
  {
	  if(in_array($sModule,$aModules->ids))
	  {
		 $sAccess 		= $aModules->$sAccessKey;
	  }
	  else if(!in_array($sModule,$aModules->ids)) 
	  {
		$sAccess 		= '0'; 
	  }
  }
  
  if($sAccess == '')
	$sAccess = '2' ;



?>
        <div class="row">
          <div class="col-lg-12">
            <ol class="breadcrumb">
			  <li><img src="<?php echo HTTP_IMAGES_PATH.'icons/home.png';?>" width="24" style="vertical-align: middle !important;">&nbsp;<a href="<?php echo site_url();?>">Home</a> </li>
			  <li class="active"><?php echo $sDeviceFullName;?> Name Save</li>
			</ol>
	</div>
            <?php if($sucess == '1') { ?>
              <div class="alert alert-success alert-dismissable">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                Details saved successfully! 
              </div>
            <?php } ?>
          </div>
        
        <!-- /.row -->
        <div class="row">
          <div class="col-lg-12">
            <div class="panel panel-primary">
              <div class="panel-heading" style="border-top-left-radius: 0px;border-top-right-radius: 0px;">
                <h3 class="panel-title" style="color:#FFF;">Save Name</h3>
              </div>
              <div class="panel-body">
                <div id="morris-chart-area">
                  <form action="<?php if($sAccess == 2) { echo site_url('home/positionName/'.base64_encode($sDeviceID).'/'.base64_encode($sDevice).'/'); } else { echo '';}?>" method="post">
                  <input type="hidden" name="sDeviceID" value="<?php echo base64_encode($sDeviceID);?>">
                  <input type="hidden" name="sDevice" value="<?php echo base64_encode($sDevice);?>">
                    <table border="0" cellspacing="0" cellpadding="0" width="100%">
                      <tr>
                        <td width="10%"><strong>Enter Position 1:</strong></td>
                        <td width="1%">&nbsp;</td>
                        <td width="89%"><input type="text" class="form-control" placeholder="Enter Position 1 Name" name="sPositionName1" value="<?php echo $sPositionName1;?>" id="sDeviceName" required <?php if($sAccess == 1) { echo 'disabled="disabled"'; } ?> ></td>
                      </tr>
                      <tr><td colspan="3">&nbsp;</td></tr>
                      <tr>
                        <td width="10%"><strong>Enter Position 2:</strong></td>
                        <td width="1%">&nbsp;</td>
                        <td width="89%"><input type="text" class="form-control" placeholder="Enter Position 2 Name" name="sPositionName2" value="<?php echo $sPositionName2;?>" id="sDeviceName" required <?php if($sAccess == 1) { echo 'disabled="disabled"'; } ?>></td>
                      </tr>
                      <tr><td colspan="3">&nbsp;</td></tr>
                      <tr><td colspan="3"><span class="btn"><input type="<?php if($sAccess == 2) {echo 'submit';} else { echo 'button';} ?>" name="command" value="Save"></span>&nbsp;&nbsp;<a class="btn btn-red" href="<?php echo site_url('home/setting/'.$sDevice.'/');?>"><span>Back</span></a></td></tr>
                      
                    </table>
                  </form>
                </div>
              </div>
            </div>
          </div>
        </div><!-- /.row -->
      

<script type="text/javascript">
  
</script>
