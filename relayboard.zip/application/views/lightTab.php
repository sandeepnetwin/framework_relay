<?php
	$iLightCnt  = 0;
	if(!empty($aIPDetails))
	{
		foreach($aIPDetails as $aIP)
		{
			if($aIP->id <= 1)
				$iLightCnt += $extra['LightNumber'];
			else
				$iLightCnt += $extra['LightNumber2'];
			
			//First IP ID to show selected.
			if($iFirstIPId == '')
				$iFirstIPId = $aIP->id;
			
			$sDetails	=	$aIP->ip;
			if($aIP->name != '')
			{
				$sDetails .= ' ('.$aIP->name.')';
			}
			
			$sShow		=	'display:none';
			$sSelected	=	'';
			if($iFirstIPId == $aIP->id)
			{ 
				$sShow		=	'';
				$sSelected	=	'selected="selected"';
			} 
			
			$sIPOptions.='<option value="'.$aIP->id.'" '.$sSelected.'>'.$sDetails.'</option>';
		}
	}
?>
<script>
function checkLightAssign(light)
{
	<?php if($sAccess == '1') { ?>
		return false;
	<?php } else if($sAccess == '2') { ?>
	var numberOfLight	=	$("#no_light").val();
	if(numberOfLight == '' || numberOfLight == '0')
	{
		alert("Please select Light number first!");
		return false;
	}
	
	if(!$("#lableRelayLight-"+light).hasClass('checked'))
	{
		$("#lableRelayLight-"+light).addClass('checked');
	}
	else
	{
		$("#lableRelayLight-"+light).removeClass('checked');
	}
	
	var arrLightAssignNumber	= 	Array();
	
	$(".lightAssign").each(function(){
		var lightNumber = $(this).val();
		if($("#lableRelayLight-"+lightNumber).hasClass('checked'))
		{	
			arrLightAssignNumber.push(lightNumber);
		}
	});
	
	if(arrLightAssignNumber.length != numberOfLight && arrLightAssignNumber.length != 0)
	{
		if(arrLightAssignNumber.length > numberOfLight)
			$("#lableRelayLight-"+light).removeClass('checked');
		
		alert("Please assign "+numberOfLight+" Light!");
		return false;
	}
	<?php } ?>
}
</script>

<h3>Light Setting</h3>
<!-- Section -->
<section>
	<div class="col-sm-12">
		<!-- Light Numbers -->
	    <label for="no_light">
			How many Spa/Pool lights do you have?<span class="requiredMark">*</span>
			&nbsp;<img src="<?php echo HTTP_ASSETS_PATH.'images/help.png';?>" width="24" alt="Help" class="top-right tipso_style_custom" data-tipso="SELECT NUMBER OF LIGHT FROM TOTAL LIGHTS TO USE IN THE SELECTED MODE."  />
	    </label>
	   
	    <a class="changeLink" id="changeLinkLight" href="javascript:void(0);" <?php if($sAccess == '2') { ?> onclick="javascript:$('#LightForm').toggleClass('disableConfig');" <?php } ?> style="float:right;" title="Click here to Enable/Disable light related settings!">Enable/Disable Light Configuration</a>
	   
		<select name="no_light" id="no_light" class="form-control" onchange="showLight();" <?php if($sAccess == '1') { echo 'disabled="disabled"'; } ?>>
			<option <?php if(isset($arrMore['light']) &&  $arrMore['light'] == ''){echo 'selected="selected"';}?> value="">Select number of lights</option>
			<?php
			for($i=0;$i<($iLightCnt+1);$i++)
			{
			?>
			<option <?php if(isset($arrMore['light']) &&  $arrMore['light'] == $i){echo 'selected="selected"';}?> value="<?php echo $i;?>"><?php echo $i;?></option>
			<?php } ?>
		</select>
		<!-- Light Numbers -->
		
		<div style="height:10px">&nbsp;</div>
		
		<!-- Light Assign -->
		<div class="col-sm-4" style="padding-left:0px;">
			<div class="controls boxed green-line" style="min-height:210px;">
				<div class="inner">
					<h3 class="profile-title"><strong style="color:#C9376E;">Assign Light</strong></h3>
					<?php
					if(!empty($aIPDetails))
					{
						foreach($aIPDetails as $aIP)
						{
					?>
					<div id="contentsLight_<?php echo $aIP->id;?>">
					<?php
						for($i=0;$i<$iLightCnt;$i++)
						{
							$aLightDetails  =   $this->home_model->getLightDeviceDetails($i,$aIP->id);
							if(empty($aLightDetails))
								continue;
							$strLightName 		=	'Light '.($i+1);	
							$strLightNameTmp 	=	$this->home_model->getDeviceName($i,'L',$aIP->id);
							if($strLightNameTmp != '')
								$strLightName	.=	' ('.$strLightNameTmp.')';
							
							$checked 	=	'';
							$clsChecked	=	'';
							$lightAssign	=	unserialize($arrMore['lightAssign']);	
							if(in_array($i,$lightAssign))
							{
								$checked 	=	'checked="checked"';
								$clsChecked	=	'class="checked"';
							}
								
					?>
						<?php if($i != 0){ echo '<hr />'; }?>
						<div class="rowCheckbox switch">
							<div style="margin-bottom:10px;"><?php echo $strLightName;?></div>
							<div class="custom-checkbox"><input type="checkbox" value="<?php echo $i.'_'.$aIP->id;?>" id="relayLight-<?php echo $i.'_'.$aIP->id;?>" name="relayLight[]" hidefocus="true" style="outline: medium none;" onclick="checkLightAssign(this.value)" class="lightAssign" <?php echo $checked;?>>
							<label <?php echo $clsChecked;?> id="lableRelayLight-<?php echo $i.'_'.$aIP->id;?>" for="relayLight-<?php echo $i.'_'.$aIP->id;?>"><span style="color:#C9376E;">&nbsp;</span></label>
							</div>
						</div>
							
					<?php 	
						}
					?>
					</div>
					<?php }
					}
					?>
				</div>
			</div>
		</div>	
		<!-- Light Assign -->
		
		<!-- Light Assign -->
		<div class="col-sm-8" style="padding-right:0px;">
			<div id="LightForm" class="disableConfig">
				<div class="controls boxed green-line" style="min-height:210px;">
					<div class="inner">
					<div style="margin-bottom:10px;">
						<h3 class="confHeader">Light Configuration</h3>
					</div>
					<div style="margin-bottom:10px;">
						<span style="font-weight:bold;">Select Board : </span>
						<select name="selPort" id="selPort" onchange="showBoardDetails(this.value,'lightTable_')">
							<option value="">--IP(Name)--</option>
							<?php echo $sIPOptions;?>
						</select>
					</div>
					<?php
						if(!empty($aIPDetails))
						{
							foreach($aIPDetails as $aIP)
							{
								if($aIP->id == 1)
									$lightNumber	=	$extra['LightNumber'];
								else 
									$lightNumber	=	$extra['LightNumber2'];
					?>
						<table class="table removeBorder" id="lightTable_<?php echo $aIP->id;?>" style="display:<?php if($aIP->id != $iFirstIPId){ echo 'none';} ?>" width="100%" cellspacing="0" cellpadding="0">
							<tbody>
								<tr>
									<td style="width:48%;">Enter Number of Lights to Use in system:</td>
									<td style="width:2%;">&nbsp;</td>
									<td style="width:50%;">
										<input type="text" name="lightNumber" id="lightNumber_<?php echo $aIP->id;?>" onkeyup="showLightDetails('<?php echo $aIP->id;?>');" value="<?php if(isset($lightNumber) && $lightNumber != 0) { echo $lightNumber;}?>" class="form-control inputText" <?php if($sAccess == '1'){ echo 'readonly="readonly"';}?>>
									</td>
								</tr>
								<?php 
									  for($i=1;$i<9;$i++)
									  {
										$sRelayType     =   '';
										$sRelayNumber   =   '';
										
										$aLightDetails  =   $this->home_model->getLightDeviceDetails(($i-1),$aIP->id);
										
										if(!empty($aLightDetails))
										{
											foreach($aLightDetails as $aLight)
											$sRelayDetails  =   unserialize($aLight->light_relay_number);

											$sRelayType     =   $sRelayDetails['sRelayType'];
											$sRelayNumber   =   $sRelayDetails['sRelayNumber'];
										}
										
										$sRelayNameDb =  $this->home_model->getDeviceName(($i-1),'L',$aIP->id);
								?>		
										<tr id="lightDetails_<?php echo $i.'_'.$aIP->id;?>" style="display:<?php if(isset($lightNumber) && $i <= $lightNumber) { echo ''; } else { echo 'none;';}?>">
											<td colspan="3">
												<table border="0" cellspacing="0" cellpadding="0" width="100%">
													<tr><td colspan="3"><strong>Light <?php echo $i;?></strong></td></tr>

													<tr>
														<td width="48%">Enter Name for Light <?php echo $i;?>?</td>
														<td width="2%">&nbsp;</td>
														<td width="50%">
															<input type="text" id="lightName<?php echo $i.'_'.$aIP->id;?>" name="lightName<?php echo $i.'_'.$aIP->id;?>" class="form-control inputText" value="<?php echo $sRelayNameDb;?>" <?php if($sAccess == '1'){ echo 'readonly="readonly"';}?>>
														</td>
													</tr>
													
													<tr><td colspan="3">&nbsp;</td></tr>
													
													<tr>
														<td width="48%">How do you turn on your Light <?php echo $i;?>?</td>
														<td width="2%">&nbsp;</td>
														<td width="50%">
															<select onchange="showRelaysLight(this.value,'<?php echo $i.'_'.$aIP->id;?>');" class="form-control valid" id="light<?php echo $i.'_'.$aIP->id;?>_equiment" name="light<?php echo $i.'_'.$aIP->id;?>_equiment" <?php if($sAccess == '1'){ echo 'disabled="disabled"';}?>>
																<option value="24" <?php if($sRelayType == '24') { echo 'selected="selected"';} ?>>24V AC Relays</option>
																<option value="12" <?php if($sRelayType == '12') { echo 'selected="selected"';} ?>>12V DC Relays</option>
															</select>
														</td>
													</tr>
													
													<tr><td colspan="3">&nbsp;</td></tr>
													
													<tr id="trLightSub<?php echo $i.'_'.$aIP->id;?>_24" style="display:<?php if($sRelayType == '12') { echo 'none';} ?>">
														<td width="48%"><label for="light<?php echo $i.'_'.$aIP->id;?>_sub_equiment_24">Select 24V Relay<span class="requiredMark">*</span></label></td>
														<td width="2%">&nbsp;</td>
														<td width="50%">
															<select name="light<?php echo $i.'_'.$aIP->id;?>_sub_equiment_24" id="light<?php echo $i.'_'.$aIP->id;?>_sub_equiment_24" class="form-control" <?php if($sAccess == '1'){ echo 'disabled="disabled"';}?>>
																<option value="">Select Relay</option>
																<?php foreach(${"sRelays".$aIP->id} as $relay) {
																		$strSelect	=	'';
																		if($relay == $sRelayNumber)
																			$strSelect	=	'selected="selected"';
																?>
																<option value="<?php echo $relay;?>" <?php echo $strSelect;?>>Relay <?php echo $relay;?></option>
																
																<?php } ?>
															</select>
														</td>
													</tr>
								
													<tr id="trLightSub<?php echo $i.'_'.$aIP->id;?>_12" style="display:<?php if($sRelayType == '24' || $sRelayType == '') { echo 'none';} ?>">
														<td width="48%"><label for="light<?php echo $i.'_'.$aIP->id;?>_sub_equiment_12">Select 12V Relay<span class="requiredMark">*</span></label></td>
														<td width="2%">&nbsp;</td>
														<td width="50%">
															<select name="light<?php echo $i.'_'.$aIP->id;?>_sub_equiment_12" id="light<?php echo $i.'_'.$aIP->id;?>_sub_equiment_12" class="form-control" <?php if($sAccess == '1'){ echo 'disabled="disabled"';}?>>
																<option value="">Select PowerCenter</option>
																<?php foreach(${"sPowercenter".$aIP->id} as $relay) { 
																	$strSelect	=	'';
																	if($relay == $sRelayNumber)
																		$strSelect	=	'selected="selected"';
																?>
																<option value="<?php echo $relay;?>" <?php echo $strSelect;?>>PowerCenter <?php echo $relay;?></option>
																<?php } ?>
															</select>
														</td>
													</tr>
													
													<tr><td colspan="3"><hr style="border-color:#000;" /></td></tr>
												</table>
											</td>
										</tr>
								<?php 
									}
								?>	
								<?php if($sAccess == '2') { ?>
									<tr id="lightSaveConf_<?php echo $aIP->id;?>" style="display:<?php if($lightNumber == 0){ echo 'none;';}?>">
										<td colspan="3">
											<a href="javascript:void(0);" onclick="checkAndSaveLight('<?php echo $aIP->id;?>');" class="btn btn-small"><span>Save</span></a>
											&nbsp;&nbsp;
											<a href="javascript:void(0);" onclick="javascript:$('#LightForm').toggleClass('disableConfig');" class="btn btn-small btn-gray"><span>Cancel</span></a>
											&nbsp;&nbsp;
											<span id="loadingImgLight_<?php echo $aIP->id;?>" style="display:none; vertical-align: middle;">
												<img src="<?php echo site_url('assets/images/loading.gif');?>" alt="Loading...." width="32" height="32">
											</span>
										</td>
									</tr>
								<?php } ?>
							</tbody>
						</table>
						<?php
							}
						}
						?>
					</div>
				</div>
			</div>
		</div>    
	</div>
</section>
<!-- Section -->