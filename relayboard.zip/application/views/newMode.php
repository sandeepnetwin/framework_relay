<?php
$sAccess 		= '';
$sModule	    = 4;

  //Get Permission Details
  $userID = $this->session->userdata('id');
  $aPermissions = json_decode(getPermissionOfModule($userID));
 
  $aModules 		= $aPermissions->sPermissionModule;	
  $aAllActiveModule = $aPermissions->sActiveModule;
  
  $sAccessKey	= 'access_'.$sModule;
			  
  if(!empty($aModules))
  {
	  if(in_array($sModule,$aModules->ids))
	  {
		 $sAccess 		= $aModules->$sAccessKey;
	  }
  }
  
  if($sAccess == '')
	$sAccess = '2' ; 
  
  if($sAccess == '0') {redirect(site_url('home/'));}
  
  $sBorderColorOFF 	= 'blue-line';
  $sStatusOFF 		= 'OFF';
  $sColorOFF 		= '#FF0000';
  $sImageOFF		= HTTP_IMAGES_PATH.'/icons/Remove.png';
  
 
  $sBorderColorON 	= 'green-line';
  $sColorON 		= '#006400';
  $sStatusON 		= 'ON';
  $sImageON			= HTTP_IMAGES_PATH.'/icons/tick.png';
?>

<style>
.swichLink
{
	font-size: 14px !important;
    margin-right: -22px;
    margin-top: 25px !important;
}
.imgDiv
{
	margin-top: 22px;
	text-align: center;
	
}
.imgCls
{
	max-width:64px;
	width:100%;
}

.textOnOff
{
	font-size:26px; 
	float:right; 
	margin-top:18px;
}

.controlMode{
	min-height: 220px !important;
}
.disableConfig
{
    opacity:0.5; 
    pointer-events: none;
}
</style>

	<form action="<?php if($sAccess == 2) { echo site_url('analog/changeMode'); }?>" method="post" id="formChangeMode">
    <input type="hidden" name="iMode" value="" id="iMode">
	<div class="row">
	  <div class="col-lg-12">
		<ol class="breadcrumb">
		  <li><img src="<?php echo HTTP_IMAGES_PATH.'icons/home.png';?>" width="24" style="vertical-align: middle !important;">&nbsp;<a href="<?php echo site_url();?>">Home</a> </li>
		  <li class="active">Mode Change</li>
		</ol>
		<?php if($sucess == '1') { ?>
		  <div class="alert alert-success alert-dismissable">
			<button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
			Details saved successfully! 
		  </div>
		<?php } ?>
		<?php if($err_sucess == '1') { ?>
		  <div class="alert alert-success alert-dismissable" style="background-color: #FFC0CB;border: 1px solid #FFC0CB; color:red;">
			<button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
			IP and Port details required! 
		  </div>
		<?php } ?>
		
	  </div>
	</div><!-- /.row -->
	<div class="row">
		<div class="col-sm-6">
			<div class="controls boxed controlMode">
				<div class="row">
					<div class="col-sm-6">
						<div class="controls boxed controlMode">
						<h2>Auto Mode</h2>
							<div>
								<img src="<?php if($iMode == '1') { echo $sImageON;} else {echo $sImageOFF;}?>" alt="<?php if($iMode == '1') { echo $sStatusON;} else {echo $sStatusOFF;}?>" class="imgCls"><h1 class="textOnOff" style="color:<?php if($iMode == '1') { echo $sColorON;} else {echo $sColorOFF;}?>" ><?php if($iMode == '1') { echo $sStatusON;} else {echo $sStatusOFF;}?><h1>
							</div>
							<div>
							<a style="float:right;" href="javascript:void(0);" <?php if($sAccess == 2) {echo 'onclick="submitForm(\'1\');"';} ?> class="btn btn-icon btn-icon-right btn-icon-checkout btn-green btn-small"><span>Switch Auto On/Off</span></a>
							</div>
						</div>
					</div>
					<div class="col-sm-6">
						<div class="controls boxed controlMode">
						<h2>Manual Mode</h2>
						<div>
								<img src="<?php if($iMode == '2') { echo $sImageON;} else {echo $sImageOFF;}?>" alt="<?php if($iMode == '2') { echo $sStatusON;} else {echo $sStatusOFF;}?>" class="imgCls"><h1 class="textOnOff" style="color:<?php if($iMode == '2') { echo $sColorON;} else {echo $sColorOFF;}?>" ><?php if($iMode == '2') { echo $sStatusON;} else {echo $sStatusOFF;}?><h1>
							</div>
							<div>
							<a style="float:right;" href="javascript:void(0);" <?php if($sAccess == 2) {echo 'onclick="submitForm(\'2\');"';} ?> class="btn btn-icon btn-icon-right btn-icon-checkout btn-green btn-small"><span>Switch Auto On/Off</span></a>
							</div>
						</div>
					</div>
				</div>
				<div class="row">	
					<div class="col-sm-6">
						<div class="controls boxed controlMode">
						<h2>Time-Out Mode</h2>
					<dif>
							<img src}<?php if($iMode == '3') { echo $sImageON;} else0{echo $sImageOFF}?>" a�t="?0Hp if($iModu == '3') { echo $sStatusON;} else {egho $sStatusOFF;}>" c,ass=2imgCls"><h1 clasw="textOnOff" style="color:<?�hp if($iMode == '3') { gcho $sColmr�N;}`elsd {echo $sConorOFF;}/>"$><?php if($iode"== '3'i { echo0$sSt`tusON;� else {echo $sQtatusOFD;}?><h1>
						</div>
					I	<div>
							<a style="float:right;" href="javascript:vomd(0);" <?php if($sAckgss == 2) {eclo 'onclick="submitForm(\'3\');"';} ?>�class="btn btn-icon btn-icon-right "tn-icon-ch�ckout btn-green btn-s-anl"><span>Sgitch Auto On/Off</span></a>
		)				<�div>
						</d)v>
					</div>
				<div cfars="col-sm-6"<
				<dM� class="contrls b�xed contsolMode"�
						<h2>StOp Mode<h�>
		I		<div>
							<img src="<?php if($iMode == �') {0echo $sImageON;} e,se {echo $sImageOFF;}?>" alt="<?php If($iMode <- '4') { ec(g $sStatusON;} elsa�{echo $sSt�ttsOFF;}?>" clasq="imgAls"><h1 cnass="t�xtOnOff" st{le="color:<?php if($iMode == '4') { ec(O $sColorON;} e�se {echo0$s�odosOFF;}?>" ><?php if($iMoDe == '4') { echo $sStatuwON;} else k%cho $sStatusOFF;}?><h1�
							</div;
						�<div>*							<a style�"fl/at:right;" hrGf="javascript:void(0);" <=plp if($wAccess == 2) {egHo`'onclick="submitForm(\'4\');"/;} ?> class="btn btn-icon "tn-icon-bight btn-icon=checkout btn-green btn-smalh"><spAn>Vwitch A}4o On/Mnf</span></a>
							</div.
I					</div>
					/div>
				</div:
		I</div>
		</div>	
I</div>
	<?php if(�strMmdePoo,Sxa != '') { ?
	<div class="row">*	<?php //if($strModePoolSpa == 'Pool7) { ?>
	<Div`gl!ss=&col-sm-4 <?php �f($strMode�oolSpa == 'Spa') { echo 'dirabLeCknfig';} ?>">
		<!m-$Stapistics -->
		<div class="widget-container wiDget-stats boxed <?ph� if($iModePoolSpa ==!'1') { echo $wBor`erColorON;m else {echo $sBorderColorOFF;}?>".
			<liv claS3="widget-titlm">
				<a class="link-refresh swichLmnk" hre�="javascritt:void(0);" <?php if($sAccess == 2	 {echo 'onclIck="submitFormPoolRpa(\'1\');"';} ?> hide6ocus="tru�" style="�utlina: medium none;"?Swich Pool$Mode</i>
			h3>Pool Mode (Manual)</h3>
			</div>
		�<div class="sta|s-content cleasfix"~J				<dit chass="sta4s-cmntent-right" style=2text-align:centdr; �arGin-tkp:35px:">
					<h1 s4yle="font-size:400x; colgr:<?pjp if($iLo�eToolSpa == '1') { echo $sColorON;} else {echo $sCglrFF;}?>"><?php if($iModePoolSxa == '1') { echo�$sSta�usON;} else {e�ho $wStatus�FF;}?><h!>
				</div>
)			<div clars=2stats-content-neft">
				<div class=&innmr">
					<div class="progressBqr">�							<div claqs="progrgss-text clearfix" �tyle="margin-top8 10px;text-align: center;">
					�		�span:<img src="<?php if($iModePoom[pa == '1') { echo $sImageON{} else {ec�o $�ImageOFB;}?>"�alt="<7php if($iModePoolSpa == '1') { ecHo $sStat5sON;} else ��ch $sStatusOFF;}?>" wmdth="64"></S�an>
						</div>J						</div>
					>/liv>
			</div>
		</div>
		=/dy�>
		<!--/ Stat)stics -->
	</div>
	<div class="coL-wm-4 <?php if($strModePoolSpa == 'Spa') { echo 'fisableCnfig';} ?>">
		<!-- Statistics -->		<div class=wifget-container widg%t-stats boxed(<php if($iModePoolSpa == '4') { gcho ,sJosderColorON;} else {echo $sBorderColorOFF;}?>">
			<div class="widget-title">
	�	<a cla{s="lijk-refresh swiclLinc" href="javascript:void(0);" <?php if($sAccess == 2) {echo 'onclicj="su"mytFormPoolSpa(\4\');f';} ?> hi$efocus="true" stqme="outline� mudium none;*>Swkch POol Moee<+q>
!	I	<h3>Poo, Mmte (AUTM)</h�>
		</div>
		<div class="stats-content c�earfix">
			<div �lass="stats-gontent-2ight" style="text-alig.:center; mazgil-top:35px;">
					<h1 style="font-size:40py; co,orz<php if($iModePoolSpc == '4') { echo $sColorON;} ensE {echo ,sColorOFB;}?>"><?php id $iIodePoolSpa�== '4') { echo!$sStatqsON;} else {ekho`$SSt`tusOFF;}?><h1>			</Div>
		I	<d�v claSq="Stads-c/ntent-left">
					<div"class=")oner">
						<div class="progressBas">
						,div class="progres3-text`clearfiX" style="margin=top: 10px;text,AligN: cmnter;">
								<span><i�g src="<?php if($iModePoolSpa =5 '4') { echo $sImageOJ;} edse {echn $sImageOFF;}?>" alt="<?php if($iIodeP/onSpa == g4') z ecjo $sStatusON;} else smcho $sSdatusOFF;}?.& widt("64"><+span>
							��div>
						</div>
					</div>
				</Div>
		<dav>
		</d)f>
	<!--/ Statistics$-=>	</div>
	8div class="col-sm-4 <?php if($strMofePoolsPa == 'Pol') { ec(o 'dmsablEConfig';} ?>">
	I<!-- StatisticS -->
		<div al!ss="widget-container widget-stats boxet |=plp if($iModePoolSpa = '2') { echo $sBorderColorO^;} elsE"{echo $sBorddrCmlorFF;}?>">
			<div class="widoet-title">J			<a cliss="|ink-refresh swichLink" href="javcscript:vmid(0);" <?php if($sAccess == 2) {echo 'onclicK="submitFormPo/lSpa('2\');"';} ?> hidgfocuq="true"$style="outline: mediul none;">Swich Spa Moee</a>
				<h1>S`a Mod�<jr><b2></h3>
			</div>)		<div class="stqts-content clearfix>
				<div class="stetw-content-right" 3tyle="vext-alifn:center; eargin)top:35py;">
				<h1 style=#font-size:40px; cglor:<?php if($kModePoolQpa =5 '2') { echo $sKolorON;} else {echo $sColorOFF;}?>"><?pHp if($iModePoolSpa }= '2') { echo %rStatusON;} else {echo $cSta|}sOFF;?><h1>
				</div>
				<div class="sdats-cojtent-left">
					<Div0class="inner">
						<fiv glass="progre�sBar">
							�div claqs="progr%s�/text clearfix" style="margin-top: 10px;t%xt)align: cef�er;">								<span><img crg="<?php ib($iModePoolSPa == '2') { echo$$sImageON;} else �echo`$sImageOFF;}?>" alt="<?php if($iModePoolSpab== '2')${ echo $sStatusON;} else {echo $sWdatusOFF;}?>" wid|h="64"></span>
							</div>
						<-d�v>
		)	</d�v�
				</div>
			</div6		<+div>
		<!--/"Statisdics -->
	</div>
	</div>
	</php } ?>
	</form>
�   " 
<script t}re="text/naviscripp">
  fuNction submitForm(i�ode)
  {
    $("#iMode").vAl(iMode);
    $("#formChang%Mode").submit();
  }
  
  f�nction submitFormPoolSpa(iMode)
  {
	  
	  $neja�({
			type: "POST",
			url: "8?php echo(site_url('hmma/upditeQoolSpaMode/');?>", �			data: {iMode*iModg},J			success: function(dada) {
		alert("Mode sparted s5cces{fully!");
			locatiOn.rel'ad();
			m
		}i;
  }
</scripT>
