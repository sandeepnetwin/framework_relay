<?php echo 'ssss'.$option;?>
<form action="<?php echo base_url('importexport/index');?>" method="post" name="ImportExport" id="ImportExport" enctype="multipart/form-data">
<div class="row">
	
	<div class="col-sm-12" id="onoffbuttons_<?php echo $aIP->id;?>" style="display:<?php if($aIP->id != $iFirstIPId){ echo 'none';} ?>">
	<input type="hidden" value="<?php echo $aIP->id;?>" id="hidIPIdButton">
		<!-- widget Tags-->
		<div class="widget-container widget-stats boxed green-line">
		<div class="widget-title">
			<a href="<?php echo base_url('importexport/index');?>" class="link-refresh" id="link-refresh-1"><span class="glyphicon glyphicon-refresh"></span></a>
			<h3>Import/Export</h3>
		</div>
		<div class="stats-content clearfix">
		<div class="stats-content-right" style="width:100% !important; margin-left:5px; margin-right:5px; float:none;">
		
		<table class="table table-hover">
			<thead>
				<tr style="font-weight:bold;">
					<div class="row">
						<th class="header">
						Import/Export Details
						</th>
					</div>	
				</tr>
			</thead>
			<tbody>
			<?php if($error != '') {?>
				<tr id="errorDiv">
					<td>
						<div class="row">
							<div class="col-sm-12">
								<span style="color:red;"><li><?php echo $error;?></li></span>
							</div>								
						</div>
					</td>		
				</tr>
			<?php } ?>	
			<?php if($success != '') {?>
				<tr id="errorDiv">
					<td>
						<div class="row">
							<div class="col-sm-12">
								<span style="color:green;"><li><?php echo $success;?></li></span>
							</div>								
						</div>
					</td>		
				</tr>
			<?php } ?>			
				<tr>
					<td>
						<div class="row">
							<div class="col-sm-12"><strong>Select Option:</strong> Import&nbsp;<input type="radio" name="ImportExport" value="1" id="Import" class="mainOption" <?php if($option == '1') { echo 'checked="checked"';} ?>>&nbsp;&nbsp;
							Export&nbsp;<input type="radio" name="ImportExport" value="2" id="Export" <?php if($option == '2' || $option == '') { echo 'checked="checked"';} ?> class="mainOption">
							</div>
						</div>
						<div class="row"><div class="col-sm-12">&nbsp;</div></div>
						<div class="row">
							<div class="col-sm-12">	
							  
								<div id="ImportDiv" style="display:<?php if($option == '1') { echo '';} else{ echo 'none;';} ?>;">
									<div class="row">
										<div class="col-sm-12"><strong>Select Import File:</strong> <input type="file" name="importFile"></div>
									</div>
									<div class="row"><div class="col-sm-12">&nbsp;</div></div>
									<div class="row">
										<div class="col-sm-12">
										<span class="btn btn-small btn-green"><input type="submit" value="Import" name="command" hidefocus="true" style="outline: medium none;"></span>
										</div>
									</div>
								</div>

								<div id="ExportDiv" style="display:<?php if($option == '2') { echo '';} else{ echo 'none;';} ?>">
									<strong>Select For Export:</strong> Select All <input type="checkbox" name="selectAll" id="selectAllExport" value="1">
									<div class="row"><div class="col-sm-12">&nbsp;</div></div>
									<div class="row">
										<div class="col-sm-3">Basic Setting <input type="checkbox" name="basic" id="basic" value="1" class="selcheckboxExport"></div>
										<div class="col-sm-3">Programs & Custom Programs <input type="checkbox" name="program" id="program" value="1" class="selcheckboxExport"></div>
										<div class="col-sm-3">Device Settings <input type="checkbox" name="device" id="device" value="1" class="selcheckboxExport"></div>
										<div class="col-sm-3">Exclude Devices <input type="checkbox" name="exclude" id="exclude" value="1" class="selcheckboxExport"></div>
										<div class="col-sm-3">Advanced Settings <input type="checkbox" name="advance" id="advance" value="1" class="selcheckboxExport"></div>
										
									</div>
									<div class="row"><div class="col-sm-12">&nbsp;</div></div>
									<div class="row">
										<div class="col-sm-12">
										<span class="btn btn-green"><input type="submit" value="Export Selected" name="command" hidefocus="true" style="outline: medium none;" onclick="return checkRequired();"></span> or <span class="btn btn-green"><input type="submit" value="Export Complete Database" name="command" hidefocus="true" style="outline: medium none;"></span>
										</div>
									</div>
									</div>
								</div>
							</div>
						</div>
						
						
							
					</td>	
				</tr>
			
			</tbody>
		</table>
		</div>
		</div>
		<!-- Widget Tags -->
	</div>
</div>
</form>	

<script type="text/javascript">

$("#selectAllExport").click(function() {
	var isChecked = $(this).prop('checked');
	if(isChecked)
	{
		$(".selcheckboxExport").each(function() {
			$(this).prop('checked',true);
		});
	}
	else
	{
		$(".selcheckboxExport").each(function() {
			$(this).prop('checked',false);
		});
	}
});

$(".selcheckboxExport").click(function() 
{
	var isChecked = $(this).prop('checked');
	if(!isChecked)
	{
		$("#selectAllExport").prop('checked',false);
	}
	if(isChecked)
	{
		var checkedCount = $(".selcheckboxExport:checked").length;
		if(checkedCount == 4)
		{
			$("#selectAllExport").prop('checked',true);
		}
	}
});

$(".mainOption").click(function() {
	
	var checkedValue = $(this).val();
	
	if(checkedValue == '1')
	{
		$("#ExportDiv").slideUp('slow',function(){
			$("#ImportDiv").slideDown('slow');
		});
		
	}
	else if(checkedValue == '2')
	{
		$("#errorDiv").hide();
		$("#ImportDiv").slideUp('slow',function(){
			$("#ExportDiv").slideDown('slow');
		});
	}
});

function checkRequired()
{
	var checkedCount = $(".selcheckboxExport:checked").length;
	if(checkedCount == 0)
	{
		alert("Please select atleast One checkbox for Exportin Details!");
		return false;
	}
	return true;
}

</script>
<!-- END : Temperature Sensors -->