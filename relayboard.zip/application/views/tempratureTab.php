<h3>Temperature Settings</h3>
<!-- Section -->
<section>
	<div class="col-sm-12">
	
	<!-- Temperature Sensor1 -->
	<label for="temperature1">
		Temperature Sensor 1<span class="requiredMark">*</span>
		&nbsp;<img src="<?php echo HTTP_ASSETS_PATH.'images/help.png';?>" width="24" alt="Help" class="top-right tipso_style_custom" data-tipso="SELECT TEMPERATURE SENSOR FROM SENSORS." />
	</label>
	
	<select name="temperature1" id="temperature1" class="form-control" <?php if($sAccess == '1') { echo 'disabled="disabled"';} ?>>
		<option <?php if(isset($arrGeneral['temperature1']) &&  $arrGeneral['temperature1'] == '1'){echo 'selected="selected"';}?> value="1">TS1</option>
		<option <?php if(isset($arrGeneral['temperature1']) &&  $arrGeneral['temperature1'] == '2'){echo 'selected="selected"';}?> value="2">TS2</option>
		<option <?php if(isset($arrGeneral['temperature1']) &&  $arrGeneral['temperature1'] == '3'){echo 'selected="selected"';}?> value="3">TS3</option>
		<option <?php if(isset($arrGeneral['temperature1']) &&  $arrGeneral['temperature1'] == '4'){echo 'selected="selected"';}?> value="4">TS4</option>
		<option <?php if(isset($arrGeneral['temperature1']) &&  $arrGeneral['temperature1'] == '5'){echo 'selected="selected"';}?> value="5">TS5</option>
	</select>
	<!-- Temperature Sensor1 -->
	
	<div style="height:10px">&nbsp;</div>
	
	<!-- Temperature Sensor2 -->
	<label for="temperature2">
		Temperature Sensor 2<span class="requiredMark">*</span>
		&nbsp;<img src="<?php echo HTTP_ASSETS_PATH.'images/help.png';?>" width="24" alt="Help" class="top-right tipso_style_custom" data-tipso="SELECT TEMPERATURE SENSOR FROM SENSORS." />
	</label>
	
	<select name="temperature2" id="temperature2" class="form-control" <?php if($sAccess == '1') { echo 'disabled="disabled"';} ?>>
		<option <?php if(isset($arrGeneral['temperature2']) &&  $arrGeneral['temperature2'] == '1'){echo 'selected="selected"';}?> value="1">TS1</option>
		<option <?php if(isset($arrGeneral['temperature2']) &&  $arrGeneral['temperature2'] == '2'){echo 'selected="selected"';}?> value="2">TS2</option>
		<option <?php if(isset($arrGeneral['temperature2']) &&  $arrGeneral['temperature2'] == '3'){echo 'selected="selected"';}?> value="3">TS3</option>
		<option <?php if(isset($arrGeneral['temperature2']) &&  $arrGeneral['temperature2'] == '4'){echo 'selected="selected"';}?> value="4">TS4</option>
		<option <?php if(isset($arrGeneral['temperature2']) &&  $arrGeneral['temperature2'] == '5'){echo 'selected="selected"';}?> value="5">TS5</option>
	</select>
	<!-- Temperature Sensor2 -->
	
	<div style="height:10px">&nbsp;</div>
	
	<!-- Display Pool Temperature -->
	<label for="display_pool_temp">
		Display Pool Temp on mode Page yes or no?<span class="requiredMark">*</span>
		&nbsp;<img src="<?php echo HTTP_ASSETS_PATH.'images/help.png';?>" width="24" alt="Help" class="top-right tipso_style_custom" data-tipso="SELECT WHETHER TO SHOW POOL TEMPERATURE." />
	</label>
	
	<select name="display_pool_temp" id="display_pool_temp" class="form-control <?php if($strPoolRequired == 'Yes') { echo '';} ?>" <?php if($arrGeneral['type'] == 'spa' || $sAccess == '1') { echo 'disabled="disabled"';} ?>>
		<option <?php if(isset($arrGeneral['display_pool_temp']) && $arrGeneral['display_pool_temp'] == 'Yes'){ echo 'selected="selected"';} ?> value="Yes">Yes</option>
		<option <?php if(isset($arrGeneral['display_pool_temp']) && $arrGeneral['display_pool_temp'] == 'No'){ echo 'selected="selected"';} ?> value="No">No</option>
	</select>
	<!-- Display Spa Temperature -->
	
	<div style="height:10px">&nbsp;</div>
	
	<!-- Display Spa Temperature -->
	<label for="display_spa_temp">
		Display Spa Temp on mode Page yes or no?<span class="requiredMark">*</span>
		&nbsp;<img src="<?php echo HTTP_ASSETS_PATH.'images/help.png';?>" width="24" alt="Help" class="top-right tipso_style_custom" data-tipso="SELECT WHETHER TO SHOW SPA TEMPERATURE." />
	</label>
	
	<select name="display_spa_temp" id="display_spa_temp" class="form-control <?php if($strSpaRequired == 'Yes') { echo '';} ?>" <?php if($arrGeneral['type'] == 'pool' || $sAccess == '1') { echo 'disabled="disabled"';} ?>>
		<option <?php if(isset($arrGeneral['display_spa_temp']) && $arrGeneral['display_spa_temp'] == 'Yes'){ echo 'selected="selected"';} ?> value="Yes">Yes</option>
		<option <?php if(isset($arrGeneral['display_spa_temp']) && $arrGeneral['display_spa_temp'] == 'No'){ echo 'selected="selected"';} ?> value="No">No</option>
	</select>
	<!-- Display Spa Temperature -->
	
	<div style="height:10px">&nbsp;</div>
	</div>
</section>
<!-- Section -->