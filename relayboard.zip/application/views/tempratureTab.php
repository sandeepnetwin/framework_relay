<h3>Temperature Settings</h3>
			<section>
			<div class="col-sm-12">
			<label for="temperature1">Temperature Sensor 1<span class="requiredMark">*</span>&nbsp;<img src="<?php echo HTTP_ASSETS_PATH.'images/help.png';?>" width="24" class="tooltipster-icon" title="Select Temprature Sensor from list!" /></label>
			<select name="temperature1" id="temperature1" class="form-control">
				<option <?php if(isset($arrMore['temperature1']) &&  $arrMore['temperature1'] == '1'){echo 'selected="selected"';}?> value="1">TS1</option>
				<option <?php if(isset($arrMore['temperature1']) &&  $arrMore['temperature1'] == '2'){echo 'selected="selected"';}?> value="2">TS2</option>
				<option <?php if(isset($arrMore['temperature1']) &&  $arrMore['temperature1'] == '3'){echo 'selected="selected"';}?> value="3">TS3</option>
				<option <?php if(isset($arrMore['temperature1']) &&  $arrMore['temperature1'] == '4'){echo 'selected="selected"';}?> value="4">TS4</option>
				<option <?php if(isset($arrMore['temperature1']) &&  $arrMore['temperature1'] == '5'){echo 'selected="selected"';}?> value="5">TS5</option>
			</select>
			<div style="height:10px">&nbsp;</div>
			<label for="temperature2">Temperature Sensor 2<span class="requiredMark">*</span>&nbsp;<img src="<?php echo HTTP_ASSETS_PATH.'images/help.png';?>" width="24" class="tooltipster-icon" title="Select Temperature Sensor From List!" /></label>
			<select name="temperature2" id="temperature2" class="form-control">
				<option <?php if(isset($arrMore['temperature2']) &&  $arrMore['temperature2'] == '1'){echo 'selected="selected"';}?> value="1">TS1</option>
				<option <?php if(isset($arrMore['temperature2']) &&  $arrMore['temperature2'] == '2'){echo 'selected="selected"';}?> value="2">TS2</option>
				<option <?php if(isset($arrMore['temperature2']) &&  $arrMore['temperature2'] == '3'){echo 'selected="selected"';}?> value="3">TS3</option>
				<option <?php if(isset($arrMore['temperature2']) &&  $arrMore['temperature2'] == '4'){echo 'selected="selected"';}?> value="4">TS4</option>
				<option <?php if(isset($arrMore['temperature2']) &&  $arrMore['temperature2'] == '5'){echo 'selected="selected"';}?> value="5">TS5</option>
			</select>
			<div style="height:10px">&nbsp;</div>
			<label for="display_pool_temp">Display Pool Temp on mode Page yes or no?<span class="requiredMark">*</span>&nbsp;<img src="<?php echo HTTP_ASSETS_PATH.'images/help.png';?>" width="24" class="tooltipster-icon" title="Whether to display pool temperature on the page?" /></label>
			<select name="display_pool_temp" id="display_pool_temp" class="form-control <?php if($strPoolRequired == 'Yes') { echo '';} ?>" <?php if($strPoolRequired == '') { echo 'disabled="disabled"';} ?>>
					<option <?php if(isset($arrGeneral['display_pool_temp']) && $arrGeneral['display_pool_temp'] == 'Yes'){ echo 'selected="selected"';} ?> value="Yes">Yes</option>
					<option <?php if(isset($arrGeneral['display_pool_temp']) && $arrGeneral['display_pool_temp'] == 'No'){ echo 'selected="selected"';} ?> value="No">No</option>
				</select>
			<div style="height:10px">&nbsp;</div>
			<label for="display_spa_temp">Display Spa Temp on mode Page yes or no?<span class="requiredMark">*</span>&nbsp;<img src="<?php echo HTTP_ASSETS_PATH.'images/help.png';?>" width="24" class="tooltipster-icon" title="Whether to display spa temperature on the page?" /></label>
			<select name="display_spa_temp" id="display_spa_temp" class="form-control <?php if($strSpaRequired == 'Yes') { echo '';} ?>" <?php if($strSpaRequired == '') { echo 'disabled="disabled"';} ?>>
					<option <?php if(isset($arrGeneral['display_spa_temp']) && $arrGeneral['display_spa_temp'] == 'Yes'){ echo 'selected="selected"';} ?> value="Yes">Yes</option>
					<option <?php if(isset($arrGeneral['display_spa_temp']) && $arrGeneral['display_spa_temp'] == 'No'){ echo 'selected="selected"';} ?> value="No">No</option>
			</select>
			<div style="height:10px">&nbsp;</div>
			</div>
			</section>