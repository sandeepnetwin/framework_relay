<?php
	/**
	 *	Project : LVN 
	 *	Program/Module Name : ShutdownReboot View
	 *	Author : Dhiraj S. 
	 *	Creation Date : 28/06/2016 
	 *	Description : Shutdown and Reboot buttons view Page.
	 *	Modification History : 
	 *	Change Date: 	Name: 
	**/

?>

<style>
</style>

	<form action="<?php echo site_url('device/systemOperation'); ?>" method="post" id="formSystemOperations">
    <input type="hidden" name="iMode" value="" id="iMode">
	<div class="row">
	  <div class="col-lg-12">
		<ol class="breadcrumb">
		  <li><img src="<?php echo HTTP_IMAGES_PATH.'icons/home.png';?>" width="24" style="vertical-align: middle !important;">&nbsp;<a href="<?php echo site_url();?>">Home</a> </li>
		  <li class="active">System Operations</li>
		</ol>
		</div>
	</div><!-- /.row -->
	<div class="row">
		<div class="col-sm-12">
			<div class="controls boxed controlMode" style="min-height: auto;">
				<div class="row">
					<div class="col-sm-6" style="text-align: center;">
						<a href="javascript:void(0);" onclick="submitForm('1');"><img src="<?php echo HTTP_IMAGES_PATH.'/Reboot.png'; ?>"><br /><h2>REBOOT</h2></a>
					</div>
					<div class="col-sm-6" style="text-align: center;">
						<a href="javascript:void(0);" onclick="submitForm('2');"><img src="<?php echo HTTP_IMAGES_PATH.'/Shutdown.png'; ?>"><br /><h2>SHUTDOWN</h2></a>
					</div>
				</div>
			</div>
        </div>
		
	</div>
	</form>
      
<script type="text/javascript">
  function submitForm(iMode)
  {
    $("#iMode").val(iMode);
    $("#formSystemOperations").submit();
  }
</script>
