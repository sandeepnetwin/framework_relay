<h3>Home</h3>
<!-- Section -->
<section>
	<!-- Left Block of Section -->
	<div class="col-sm-6">
		<!-- Select Type Pool/Spa/Both -->
		<label for="strType">
			Do you have a pool only, spa only and or a pool and spa?:<span class="requiredMark">*</span>
			&nbsp;<img src="<?php echo HTTP_ASSETS_PATH.'images/help.png';?>" width="24" alt="Help" class="top-right tipso_style_custom" data-tipso="SELECT WHETHER YOU HAVE POOL,SPA OR BOTH."  />
		</label>
		
		<select name="strType" id="strType" class="form-control required" onchange="checkType(this.value)" <?php if($sAccess == '1') { echo 'disabled="disabled"';} ?>>
			<option <?php if(isset($arrGeneral['type']) && $arrGeneral['type'] == ''){ echo 'selected="selected"';} ?> value="">Select Type</option>
			<option <?php if(isset($arrGeneral['type']) && $arrGeneral['type'] == 'pool'){ echo 'selected="selected"';} ?> value="pool">Pool only</option>
			<option <?php if(isset($arrGeneral['type']) && $arrGeneral['type'] == 'spa'){ echo 'selected="selected"';} ?> value="spa">Spa only</option>
			<option <?php if(isset($arrGeneral['type']) && $arrGeneral['type'] == 'both'){ echo 'selected="selected"';} ?> value="both">Pool and Spa</option>
		</select>
		<!-- Select Type Pool/Spa/Both -->
		
		<div style="height:10px">&nbsp;</div>
		
		<!-- Pool Maximum Temperature -->
		<label for="pool_maximum_temperature">
			What is the maximum temperature expressed in Fahrenheit that you would like to be able to set the pool temperature to ?<span class="requiredMark">*</span>
			&nbsp;
			<img src="<?php echo HTTP_ASSETS_PATH.'images/help.png';?>" width="24" alt="Help" class="top-right tipso_style_custom" data-tipso="ENTER MAXIMUM POOL TEMPERATURE. e.g. 50" />
		</label>
		
		<input type="text" name="pool_maximum_temperature" value="<?php if(isset($arrGeneral['pool_max_temp']) && $arrGeneral['pool_max_temp'] != '') { echo $arrGeneral['pool_max_temp'];}?>" id="pool_maximum_temperature" class="form-control inputText <?php if($arrGeneral['type'] == 'pool' || $arrGeneral['type'] == 'both') { echo 'required';} ?>" <?php if($arrGeneral['type'] == 'spa' || $sAccess == '1') { echo 'readonly="readonly"';} ?>>
		<!-- Pool Maximum Temperature -->
	   
		<div style="height:10px">&nbsp;</div>
		
		<!-- Pool Desire Temperature -->
		<label for="pool_temperature">
		Desire pool temperature when user is in Pool Mode?<span class="requiredMark">*</span>
		&nbsp;
		<img src="<?php echo HTTP_ASSETS_PATH.'images/help.png';?>" width="24" alt="Help" class="top-right tipso_style_custom" data-tipso="ENTER DESIRE POOL TEMPERATURE WHEN USER IN POOL. e.g. 50" />
		</label>
		
		<input type="text" name="pool_temperature" value="<?php if(isset($arrGeneral['pool_temp']) && $arrGeneral['pool_temp'] != '') { echo $arrGeneral['pool_temp'];}?>" id="pool_temperature" class="form-control inputText <?php if($arrGeneral['type'] == 'pool' || $arrGeneral['type'] == 'both') { echo 'required';} ?>" <?php if($arrGeneral['type'] == 'spa' || $sAccess == '1' ) { echo 'readonly="readonly"';} ?>>
		<!-- Pool Desire Temperature -->
		
		<div style="height:10px">&nbsp;</div>
		
		<!-- Pool Manual Time -->
		<label for="pool_manual">
			The maximum allotted time for Pool Manual Mode expressed in minutes?<span class="requiredMark">*</span>
			&nbsp;<img src="<?php echo HTTP_ASSETS_PATH.'images/help.png';?>" width="24" alt="Help" class="top-right tipso_style_custom" data-tipso="ENTER TIME TILL POOL MODE IS ACTIVE IN MANUAL MODE. e.g. 60" />
		</label>
		
		<input type="text" name="pool_manual" value="<?php if(isset($arrGeneral['pool_manual']) && $arrGeneral['pool_manual'] != '') { echo $arrGeneral['pool_manual'];}?>" id="pool_manual" class="form-control inputText <?php if($arrGeneral['type'] == 'pool' || $arrGeneral['type'] == 'both') { echo 'required';} ?>" <?php if($arrGeneral['type'] == 'spa' || $sAccess == '1') { echo 'readonly="readonly"';} ?>>
		<!-- Pool Manual Time -->
		
		<div style="height:10px">&nbsp;</div>
	</div>
	<!-- Left Block of Section -->

	<!-- Right Block of Section -->
	<div class="col-sm-6">
	   <?php
			$strPoolRequired	=	'';
			$strSpaRequired		=	'';
			if(isset($arrGeneral['type']) && $arrGeneral['type'] == 'pool')
			{
				$strPoolRequired		=	'Yes';
			}
			if(isset($arrGeneral['type']) && $arrGeneral['type'] == 'spa')
			{
				$strSpaRequired			=	'Yes';
			}
			if(isset($arrGeneral['type']) && $arrGeneral['type'] == 'both')
			{
				$strPoolRequired		=	'Yes';
				$strSpaRequired			=	'Yes';
			}
		?>
		
		<!-- Spa Maximum Time -->
		<label for="pool_temperature">
			What is the maximum temperature expressed in Fahrenheit that you would like to be able to set the spa temperature to?<span class="requiredMark">*</span>
			&nbsp;<img src="<?php echo HTTP_ASSETS_PATH.'images/help.png';?>" width="24" alt="Help" class="top-right tipso_style_custom" data-tipso="ENTER MAXIMUM SPA TEMPERATURE. e.g. 50" />
		</label>
		
	    <input type="text" name="spa_maximum_temperature" value="<?php if(isset($arrGeneral['spa_max_temp']) && $arrGeneral['spa_max_temp'] != '') { echo $arrGeneral['spa_max_temp'];}?>" id="spa_maximum_temperature" class="form-control inputText <?php if($arrGeneral['type'] == 'spa' || $arrGeneral['type'] == 'both') { echo 'required';} ?>" <?php if($arrGeneral['type'] == 'pool' || $sAccess == '1') { echo 'readonly="readonly"';} ?>>
		<!-- Spa Maximum Time -->
		
	    <div style="height:10px">&nbsp;</div>
		
		<!-- Spa Desire Time -->
		<label for="spa_temperature">
			Desire spa temperature when user is in Spa Mode?<span class="requiredMark">*</span>
			&nbsp;<img src="<?php echo HTTP_ASSETS_PATH.'images/help.png';?>" width="24" alt="Help" class="top-right tipso_style_custom" data-tipso="ENTER DESIRE SPA TEMPERATURE WHEN USER IN SPA. e.g. 50" />
		</label>
		
	    <input type="text" name="spa_temperature" value="<?php if(isset($arrGeneral['spa_temperature']) && $arrGeneral['spa_temperature'] != '') { echo $arrGeneral['spa_temperature'];}?>" id="spa_temperature" class="form-control inputText <?php if($arrGeneral['type'] == 'spa' || $arrGeneral['type'] == 'both') { echo 'required';} ?>" <?php if($arrGeneral['type'] == 'pool' || $sAccess == '1') { echo 'readonly="readonly"';} ?>>
		<!-- Spa Desire Time -->
		
	    <div style="height:10px">&nbsp;</div>
		
		<!-- Spa Manual Time -->
		<label for="spa_manual">
			The maximum allotted time for Spa Mode expressed in minutes?<span class="requiredMark">*</span>
			&nbsp;<img src="<?php echo HTTP_ASSETS_PATH.'images/help.png';?>" width="24" alt="Help" class="top-right tipso_style_custom" data-tipso="ENTER TIME TILL SPA MODE IS ACTIVE IN MANUAL MODE. e.g. 60" />
		</label>
		
	    <input type="text" name="spa_manual" value="<?php if(isset($arrGeneral['spa_manual']) && $arrGeneral['spa_manual'] != '') { echo $arrGeneral['spa_manual'];}?>" id="spa_manual" class="form-control inputText <?php if($arrGeneral['type'] == 'spa' || $arrGeneral['type'] == 'both') { echo 'required';} ?>" <?php if($arrGeneral['type'] == 'pool' || $sAccess == '1') { echo 'readonly="readonly"';} ?>>
		<!-- Spa Manual Time -->
		
	    <div style="height:10px">&nbsp;</div>
	</div>
	<!-- Right Block of Section -->
</section>
<!-- Section -->