<?php
	
	/**
	* @Programmer: Dhiraj S.
	* @Created: 29 July 2015
	* @Modified: 
	* @Description: Showing Log details for selected Dates.
	**/
	
	$sAccess 		= '';
	$sModule	    = 15;

	//Get Permission Details
	$userID = $this->session->userdata('id');
	$aPermissions = json_decode(getPermissionOfModule($userID));
 
	$aModules 		= $aPermissions->sPermissionModule;	
	$aAllActiveModule = $aPermissions->sActiveModule;
  
    $sAccessKey	= 'access_'.$sModule;
			  
	if(!empty($aModules))
	{
		if(in_array($sModule,$aModules->ids))
		{
			$sAccess 		= $aModules->$sAccessKey;
		}
		else if(!in_array($sModule,$aModules->ids)) 
		{
			$sAccess 		= '0'; 
		}
	}
  
	if($sAccess == '')
	$sAccess = '2' ; 
  
	if($sAccess == '0') {redirect(site_url('home/'));}
  
	$iTotalIP	=	count($aIPDetails);
	  
	$sIPOptions	=	'';
	$iFirstIPId	=	'';	
	
	if($sBoard != '')
		$iFirstIPId		=	$sBoard;
	
	if(!empty($aIPDetails))
	{
		foreach($aIPDetails as $aIP)
		{
			//First IP ID to show selected.
			if($iFirstIPId == '')
				$iFirstIPId = $aIP->id;
							
			$sDetails	=	$aIP->ip;
			if($aIP->name != '')
			{
				$sDetails .= ' ('.$aIP->name.')';
			}
			
			$sShow		=	'display:none';
			$sSelected	=	'';
			if($iFirstIPId == $aIP->id)
			{ 
				$sShow		=	'';
				$sSelected	=	'selected="selected"';
			} 
			
			$sIPOptions.='<option value="'.$aIP->id.'" '.$sSelected.'>'.$sDetails.'</option>';
		}
	}
?>
<style>
.ui-datepicker-month
{
	color : #000 !important;
}

.fancybox-inner 
{
	height:40px !important;
}

.highlight {
    background-color: #fff34d;
    -moz-border-radius: 5px; /* FF1+ */
    -webkit-border-radius: 5px; /* Saf3-4 */
    border-radius: 5px; /* Opera 10.5, IE 9, Saf5, Chrome */
    -moz-box-shadow: 0 1px 4px rgba(0, 0, 0, 0.7); /* FF3.5+ */
    -webkit-box-shadow: 0 1px 4px rgba(0, 0, 0, 0.7); /* Saf3.0+, Chrome */
    box-shadow: 0 1px 4px rgba(0, 0, 0, 0.7); /* Opera 10.5+, IE 9.0 */
}

.highlight {
    padding:1px 4px;
    margin:0 -4px;
}
</style>

<style>	
	.navbar-toggle {
		background-color: transparent !important;
		background-image: none !important;
		border: 1px solid transparent !important;
		border-radius: 4px !important;
		float: left !important;
		margin-bottom: 8px !important;
		margin-right: 15px !important;
		margin-top: 8px !important;
		padding: 9px 10px !important;
		position: relative !important;
	}
	
	.navbar-toggle .icon-bar {
		border-radius: 1px !important;
		display: block !important;
		height: 2px !important;
		width: 22px !important;
	}
</style>

<script type="text/javascript" src="<?php echo HTTP_ASSETS_PATH.'fancybox/source/jquery.fancybox.js?v=2.1.5';?>"></script>
<link rel="stylesheet" type="text/css" href="<?php echo HTTP_ASSETS_PATH.'fancybox/source/jquery.fancybox.css?v=2.1.5';?>" media="screen" />
<script type="text/javascript">
//var $a = $.noConflict();
$(document).ready(function() {
	$('.fancybox').fancybox({'closeBtn' : false,'helpers': {'overlay' : {'closeClick': false}}
	});
});
</script>	
<link rel="stylesheet" href="<?php echo site_url('/assets/jquery-ui/jquery-ui.css');?>">
  <script src="<?php echo site_url('/assets/jquery-ui/jquery-ui.js');?>"></script>
    <script>
  $(function() {
	  setInterval( function() 
		{
			var IPID = $("#IpId").val();
			$.ajax({
				type: "POST",
				url: "<?php echo site_url('home/getRealLog/');?>", 
				data: {sIdIP:IPID,sFromDate:sFromDate,sToDate:sToDate},
				success: function(data) {
					var Obj = $.parseJSON(data);
					$("[id^='logdetails_']").hide();
					
					$("#showdetails_"+IPID).html(Obj.description);
					$("#logdetails_"+IPID).show();
				}
			});
			
		},30000);
    $( "#sFromDate" ).datepicker({
      defaultDate: "+1w",
      changeMonth: true,
      numberOfMonths: 1,
	  dateFormat: 'y-mm-dd',
      onClose: function( selectedDate ) {
        $( "#sToDate" ).datepicker( "option", "minDate", selectedDate );
      }
    });
    $( "#sToDate" ).datepicker({
      defaultDate: "+1w",
      changeMonth: true,
      numberOfMonths: 1,
	  dateFormat: 'y-mm-dd',
      onClose: function( selectedDate ) {
        $( "#sFromDate" ).datepicker( "option", "maxDate", selectedDate );
      }
    });
	
	$("#link-refresh").click(function(){
		var sFromDate = $("#sFromDate").val();
		var sToDate   = $("#sToDate").val();
		if(sFromDate == '')
		{
			alert("Please select From Date!");
			return false;
		}
		if(sToDate == '')
		{
			alert("Please select To Date!");
			return false;
		}
		$("#checkLink").trigger('click');
		var IPID = $("#IpId").val();
		$.ajax({
			type: "POST",
			url: "<?php echo site_url('home/getRealLog/');?>", 
			data: {sIdIP:IPID,sFromDate:sFromDate,sToDate:sToDate},
			success: function(data) {
				var Obj = $.parseJSON(data);
				$("[id^='logdetails_']").hide();
				
				$("#showdetails_"+IPID).html(Obj.description);
				$("#logdetails_"+IPID).show();
				parent.$.fancybox.close();
			}
		});
	});
  });
  
  function showBoardDetails(board)
	{
		
		if(board == '')
		{
			alert("Please select IP first!");
			return false;
		}
		else
		{
			$("#IpId").val(board);
			$("#checkLink").trigger('click');
			
			var IpId = $("#IpId").val();
			location.href='<?php echo base_url('home/getLogDetails');?>'+'/'+Base64.encode(IpId);
			var sFromDate = $("#sFromDate").val();
			var sToDate   = $("#sToDate").val();
		}
	}
  </script>
    <div id="page-wrapper">
		<div class="row">
          <div class="col-lg-12">
            <ol class="breadcrumb">
				<li><img src="<?php echo HTTP_IMAGES_PATH.'icons/home.png';?>" width="24" style="vertical-align: middle !important;">&nbsp;<a href="<?php echo site_url();?>">Home</a> </li>
				<li class="active">Log</li>
			</ol>
          </div>
        </div><!-- /.row -->
		
		<div class="row">
			<div class="col-sm-12">
			<span style="color:#FFF; font-weight:bold;">Select Board : </span>
			<select name="selPort" id="selPort" onchange="showBoardDetails(this.value)">
				<option value="">--IP(Name)--</option>
				<?php echo $sIPOptions;?>
			</select>	
			</div>
		</div>
		<div class="row">
			<div class="col-sm-12">
			&nbsp;
			</div>
		</div>
		
		<!--<div class="row">
			<div class="col-sm-12">
			Search: <input type="text" id="text-search" />
			</div>
		</div>-->
		
		<div class="row">
          <div class="col-sm-4">
            <div class="widget-container widget-stats boxed green-line">
			<div class="widget-title">
				
				<h3>Search</h3>
			</div>
			<div class="stats-content clearfix">
				<div class="stats-content-right" style="width:96% !important; margin-left:5px; margin-right:5px; margin-top:10px; float:none;">
				 <div id="morris-chart-area">
                <p style="word-wrap: break-word;">
				<form name="searchLog" action="<?php echo site_url('/home/getLogDetails/');?>" method="post">
				<label for="from">From</label>
				<input type="text" id="sFromDate" <?php if($sAccess != 2){echo 'disabled="disabled"';} ?> name="sFromDate" value="<?php echo $sStartDate;?>">
				<label for="to">to</label>
				<input type="text" id="sToDate" <?php if($sAccess != 2){echo 'disabled="disabled"';} ?> name="sToDate" value="<?php echo $sEndDate;?>">
				<br /><br />
				<p><span class="btn"><input <?php if($sAccess != 2){echo 'type="button"';} else { echo 'type="submit"';} ?>  name="searchLog" value="Search"></span></p>
				</form>
				</p>
                </div> 
				</div>
			</div>
		</div>
          </div>
		  <?php if(!empty($aIPDetails)) 
				{ 
					foreach($aIPDetails as $aIP)
					{
						
					
		  ?>
		   <div class="col-sm-8" id="logdetails_<?php echo $aIP->id;?>" style="display:<?php if($aIP->id != $iFirstIPId){ echo 'none';} ?>">
		    <div class="panel panel-primary">
              <div class="panel-heading" style="border-top-left-radius: 0px;border-top-right-radius: 0px;">
                <h3 class="panel-title" style="color:#FFF;">Log Details : <?php echo $sDate; ?><a href="javascript:void(0);" class="link-refresh" id="link-refresh" style="float:right"><span class="glyphicon glyphicon-refresh"></span></a></h3>
              </div>
              <div class="panel-body">
                <div id="morris-chart-area">
                <div id="showdetails_<?php echo $aIP->id;?>"><?php echo ${"Log".$aIP->id}; ?>
                </div>            
              </div>
            </div>
          </div>
		 	
        </div>
		 <?php   }
				}
			?>
	</div><!-- /#page-wrapper -->
	<input type="hidden" id="IpId" value="<?php echo $iFirstIPId;?>">
	<a class="fancybox" id="checkLink" href="#inline1" style="display:none;">&nbsp;</a>
<div id="inline1" style="text-align:center !important; display:none;"><img src="<?php echo HTTP_ASSETS_PATH.'images/loading.gif';?>" width="32" alt="loading..."></div>
<script type="text/javascript" src="<?php echo HTTP_JS_PATH; ?>highlight.js"></script>
<script type="text/javascript">
$(function() {
    $('#text-search').bind('keyup change', function(ev) {
        // pull in the new value
        var searchTerm = $(this).val();

        // remove any old highlighted terms
        $('[id^="logdetails_"]').removeHighlight();

        // disable highlighting if empty
        if ( searchTerm ) {
            // highlight the new term
            $('[id^="logdetails_"]').highlight( searchTerm );
        }
    });
});
</script>
