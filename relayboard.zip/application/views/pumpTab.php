<?php
	$iPumpCnt  = 0;
	if(!empty($aIPDetails))
	{
		foreach($aIPDetails as $aIP)
		{
			if($aIP->id <= 1)
				$iPumpCnt += $extra['PumpsNumber'];
			else
				$iPumpCnt += $extra['PumpsNumber2'];
			
			//First IP ID to show selected.
			if($iFirstIPId == '')
				$iFirstIPId = $aIP->id;
			
			$sDetails	=	$aIP->ip;
			if($aIP->name != '')
			{
				$sDetails .= ' ('.$aIP->name.')';
			}
			
			$sShow		=	'display:none';
			$sSelected	=	'';
			if($iFirstIPId == $aIP->id)
			{ 
				$sShow		=	'';
				$sSelected	=	'selected="selected"';
			} 
			
			$sIPOptions.='<option value="'.$aIP->id.'" '.$sSelected.'>'.$sDetails.'</option>';
		}
	}
?>
<script>
function checkPumpAssign(pump)
{
	<?php if($sAccess == '1') { ?>
		return false;
	<?php } else if($sAccess == '2') { ?>
	var numberOfPump	=	$("#automatic_pumps").val();
	if(numberOfPump == '' || numberOfPump == '0')
	{
		alert("Please select Pump number first!");
		return false;
	}
	
	if(!$("#lableRelayPump-"+pump).hasClass('checked'))
	{
		$("#lableRelayPump-"+pump).addClass('checked');
	}
	else
	{
		$("#lableRelayPump-"+pump).removeClass('checked');
	}
	
	var arrPumpAssignNumber	= 	Array();
	
	$(".pumpAssign").each(function(){
		var pumpNumber = $(this).val();
		if($("#lableRelayPump-"+pumpNumber).hasClass('checked'))
		{	
			arrPumpAssignNumber.push(pumpNumber);
		}
	});
	
	if(arrPumpAssignNumber.length != numberOfPump && arrPumpAssignNumber.length != 0)
	{
		if(arrPumpAssignNumber.length > numberOfPump)
			$("#lableRelayPump-"+pump).removeClass('checked');
		
		alert("Please assign "+numberOfPump+" Pump!");
		return false;
	}
	<?php } ?>
}
</script>

<h3>Pump Setting</h3>
<!-- Section -->
<section style="float: none;padding: 2.5%;position: relative;">
	<div class="col-sm-12">
	<!-- Pump Numbers -->
	<label for="automatic_pumps">
		How many Pumps do you have on your pool and or pool/spa system?<span class="requiredMark">*</span>
		&nbsp;<img src="<?php echo HTTP_ASSETS_PATH.'images/help.png';?>" width="24" alt="Help" class="top-right tipso_style_custom" data-tipso="SELECT NUMBER OF PUMP FROM TOTAL PUMPS TO USE IN THE SELECTED MODE." />
	</label>
	
	<!-- Pump configuration Link -->
	<a class="changeLink" id="changeLinkPump" href="javascript:void(0);" <?php if($sAccess == '2') { ?> onclick="javascript:$('#pumpForm').toggleClass('disableConfig');" <?php } ?> style="float:right;" title="Click here to Enable/Disable pump related settings!">Enable/Disable Pump Configuration</a>
	<!-- Pump configuration Link -->
	
	<select name="automatic_pumps" id="automatic_pumps" class="form-control required" onchange="pumpChange();" <?php if($sAccess == '1') { echo 'disabled="disabled"'; }?>>
		<option <?php if(isset($arrDevice['pump']) && $arrDevice['pump'] == ''){ echo 'selected="selected"';} ?>  value="">Select Number of Pump</option>
		<option <?php if(isset($arrDevice['pump']) && $arrDevice['pump'] == '0'){ echo 'selected="selected"';} ?>  value="0">0</option>
		<?php for($i=1;$i<=$iPumpCnt;$i++){?>
			<option <?php if(isset($arrDevice['pump']) && $arrDevice['pump'] == $i){ echo 'selected="selected"';} ?>  value="<?php echo $i;?>"><?php echo $i;?></option>
		<?php } ?>
	</select>
	<!-- Pump Numbers -->
	
	<div style="height:10px">&nbsp;</div>
	
	<!-- Pump Functioning -->
	<table width="100%;">
	<?php for($i=1;$i<=$iPumpCnt;$i++){?>
	<tr id="trPump<?php echo $i;?>" style="display:<?php if(isset($arrDevice['pump']) && $arrDevice['pump'] >= $i){ echo '';} else {echo 'none;';} ?>">
		<td>
			<label for="strValve">
				Pump<?php echo $i;?><span class="requiredMark">*</span>
				&nbsp;<img src="<?php echo HTTP_ASSETS_PATH.'images/help.png';?>" width="24" alt="Help" class="top-right tipso_style_custom" data-tipso="SELECT PUMP FUNCTIONING FROM LIST." />
			</label>
			<select name="Pump<?php echo $i;?>" id="Pump<?php echo $i;?>" class="form-control required" <?php if($sAccess == '1') { echo 'disabled="disabled"'; }?>>
				<option <?php if(isset($arrDevice['pump'.$i]) && $arrDevice['pump'.$i] == ''){ echo 'selected="selected"';} ?> value="">--Select pump function--</option>
				<option <?php if(isset($arrDevice['pump'.$i]) && $arrDevice['pump'.$i] == 'Filtering Pool and Spa'){ echo 'selected="selected"';} ?> value="Filtering Pool and Spa">Filtering Pool and Spa</option>
				<option <?php if(isset($arrDevice['pump'.$i]) && $arrDevice['pump'.$i] == 'Filtering Spa Only'){ echo 'selected="selected"';} ?> value="Filtering Spa Only">Filtering Spa Only</option>
				<option <?php if(isset($arrDevice['pump'.$i]) && $arrDevice['pump'.$i] == 'Filtering Pool Only'){ echo 'selected="selected"';} ?> value="Filtering Pool Only">Filtering Pool Only</option>
				<option <?php if(isset($arrDevice['pump'.$i]) && $arrDevice['pump'.$i] == 'Spa Jets Only'){ echo 'selected="selected"';} ?> value="Spa Jets Only">Spa Jets Only</option>
				<option <?php if(isset($arrDevice['pump'.$i]) && $arrDevice['pump'.$i] == 'Spa Circulation and Heating'){ echo 'selected="selected"';} ?> value="Spa Circulation and Heating">Spa Circulation and Heating</option>
				<option <?php if(isset($arrDevice['pump'.$i]) && $arrDevice['pump'.$i] == 'Pool Circulation and Heating'){ echo 'selected="selected"';} ?> value="Pool Circulation and Heating">Pool Circulation and Heating</option>
				<option <?php if(isset($arrDevice['pump'.$i]) && $arrDevice['pump'.$i] == 'Pool and Spa Circulation and Heating'){ echo 'selected="selected"';} ?> value="Pool and Spa Circulation and Heating">Pool and Spa Circulation and Heating</option>
				<option <?php if(isset($arrDevice['pump'.$i]) && $arrDevice['pump'.$i] == 'waterfall'){ echo 'selected="selected"';} ?> value="waterfall">waterfall</option>
				<option <?php if(isset($arrDevice['pump'.$i]) && $arrDevice['pump'.$i] == 'solar heater'){ echo 'selected="selected"';} ?> value="solar heater">solar heater</option>
				<option <?php if(isset($arrDevice['pump'.$i]) && $arrDevice['pump'.$i] == 'waterslide'){ echo 'selected="selected"';} ?> value="waterslide">waterslide</option>
				<option <?php if(isset($arrDevice['pump'.$i]) && $arrDevice['pump'.$i] == 'water feature 1'){ echo 'selected="selected"';} ?> value="water feature 1">water feature 1</option>
				<option <?php if(isset($arrDevice['pump'.$i]) && $arrDevice['pump'.$i] == 'water feature 2'){ echo 'selected="selected"';} ?> value="water feature 2">water feature 2</option>
			</select>
		</td>
	</tr>
	<?php } ?>
	</table>
	<!-- Pump Functioning -->

	<div style="height:10px">&nbsp;</div>

	<!-- Pump Assign -->
	<div class="col-sm-4" style="padding-left:0px;">
		<div class="controls boxed green-line" style="min-height:210px;">
			<div class="inner">
				<h3 class="profile-title"><strong style="color:#C9376E;">Assign Pump</strong></h3>
				<?php
					if(!empty($aIPDetails))
					{
						foreach($aIPDetails as $aIP)
						{
				?>
				<div id="contentsPump_<?php echo $aIP->id;?>">
				<?php
					echo '<h6>'.$aIP->ip.'('.$aIP->name.') Pumps</h6>';
					echo '<br>';	
					if(!empty(${"sPump".$aIP->id}))
					{
						foreach(${"sPump".$aIP->id} as $key => $Pump)
						{
							$i=$key;
							$sPumpDetails = $this->home_model->getPumpDetails($i,$aIP->id);
							if(empty($sPumpDetails))
							{
								continue;
							}
							$strPumpName 		=	'Pump '.($i+1);	
							$strPumpNameTmp 	=	$this->home_model->getDeviceName($i,'PS',$aIP->id);
							if($strPumpNameTmp != '')
								$strPumpName	.=	' ('.$strPumpNameTmp.')';
							
							$checked 	=	'';
							$clsChecked	=	'';
							$pumpAssign	=	unserialize($arrDevice['pumpAssign']);	
							if(in_array($i.'_'.$aIP->id,$pumpAssign))
							{
								$checked 	=	'checked="checked"';
								$clsChecked	=	'class="checked"';
							}						
				?>
					<?php if($i != 0){ echo '<hr />'; }?>
					<div class="rowCheckbox switch">
						<div style="margin-bottom:10px;"><?php echo $strPumpName;?></div>
						<div class="custom-checkbox">
							<input type="checkbox" value="<?php echo $i.'_'.$aIP->id;?>" id="relayPump-<?php echo $i.'_'.$aIP->id?>" name="relayPumpchk[]" hidefocus="true" style="outline: medium none;" onclick="checkPumpAssign(this.value)" class="pumpAssign" <?php echo $checked;?>>
							<label <?php echo $clsChecked;?> id="lableRelayPump-<?php echo $i.'_'.$aIP->id?>" for="relayPump-<?php echo $i.'_'.$aIP->id?>"><span style="color:#C9376E;">&nbsp;</span></label>
						</div>
					</div>
						
				<?php 	
						}
					}
				?>
				</div>
				<?php
						}
					}
				?>
			</div>
		</div>
	</div>
	<!-- Pump Assign -->
	
	<!-- Pump Configuration -->
	<div class="col-sm-8" style="padding-right:0px;">
		<div id="pumpForm" class="disableConfig">	
			<div style="margin-bottom:10px;">
				<h3 class="confHeader">Pump Configuration</h3>
			</div>
			<div style="margin-bottom:10px;">
				<span style="font-weight:bold;">Select Board : </span>
				<select name="selPort" id="selPort" onchange="showBoardDetails(this.value,'pumpTable_')">
					<option value="">--IP(Name)--</option>
					<?php echo $sIPOptions;?>
				</select>
			</div>
			<?php
				if(!empty($aIPDetails))
				{
					foreach($aIPDetails as $aIP)
					{
						if($aIP->id == 1)
							$pumpNumber	=	$extra['PumpsNumber'];
						else 
							$pumpNumber	=	$extra['PumpsNumber2'];
			?>	
			<table class="table removeBorder" id="pumpTable_<?php echo $aIP->id;?>" style="display:<?php if($aIP->id != $iFirstIPId){ echo 'none';} ?>" width="100%" cellspacing="0" cellpadding="0">
				<tbody>
					<tr>
						<td style="width:48%;">Enter Number of Pumps to Use in system:</td>
						<td style="width:2%;">&nbsp;</td>
						<td style="width:50%;">
							<input type="text" name="pumpNumber" id="pumpNumber_<?php echo $aIP->id;?>" onkeyup="showPumpDetails('<?php echo $aIP->id;?>');" value="<?php if(isset($pumpNumber) && $pumpNumber != 0) { echo $pumpNumber;}?>" class="form-control inputText" <?php if($sAccess == '1') { echo 'readonly="readonly"'; } ?>>
						</td>
					</tr>
					<?php for($i=0;$i<8;$i++)
					{
						$sPumpDetails = $this->home_model->getPumpDetails($i,$aIP->id);
						//Variable Initialization to blank.
						$sPumpNumber  	= '';
						$sPumpType  	= '';
						$sPumpSubType  	= '';
						$sPumpSpeed  	= '';
						$sPumpFlow 		= '';
						$sPumpClosure   = '';
						$sRelayNumber  	= '';
						$sPumpAddress	= '';
						$sRelayNumber1	= '';
						if(is_array($sPumpDetails) && !empty($sPumpDetails))
						{
						  foreach($sPumpDetails as $aResultEdit)
						  { 
							$sPumpNumber  = $aResultEdit->pump_number;
							$sPumpType    = $aResultEdit->pump_type;
							$sPumpSubType = $aResultEdit->pump_sub_type;
							$sPumpSpeed   = $aResultEdit->pump_speed;
							$sPumpFlow    = $aResultEdit->pump_flow;
							$sPumpClosure = $aResultEdit->pump_closure;
							$sRelayNumber = $aResultEdit->relay_number;
							$sPumpAddress = $aResultEdit->pump_address;
							$sRelayNumber1= $aResultEdit->relay_number_1;		
						  }
						}
					?>
					<tr id="trPumpDetails<?php echo $i.'_'.$aIP->id;?>" style="display:<?php if(isset($pumpNumber) && $i < $pumpNumber) { echo ''; } else { echo 'none;';}?>">
					<td colspan="3">
					  <table border="0" cellspacing="0" cellpadding="0" width="100%">
						  <tr id="trVSClosure">
							<td width="10%"><strong>Pump Closure:</strong></td>
							<td width="1%">&nbsp;</td>
							<td width="89%">
								<div class="rowCustom">
								<div class="colCustom" style="padding-left:0;">
								  <input type="radio" name="sPumpClosure_<?php echo $i.'_'.$aIP->id;?>" id="sPumpClosure0_<?php echo $i.'_'.$aIP->id;?>" value="0" <?php if($sPumpClosure == '0') { echo 'checked="checked"'; } ?> required <?php if($sAccess == 1){ echo 'readonly="readonly";';} ?> style="display: inline;" />
								  
								  <label style="margin-left: 5px;">No contact closure</label>
								  
								  <input type="radio" name="sPumpClosure_<?php echo $i.'_'.$aIP->id;?>" id="sPumpClosure1_<?php echo $i.'_'.$aIP->id;?>" value="1" <?php if($sPumpClosure == '1') { echo 'checked="checked"'; } ?> required <?php if($sAccess == 1){ echo 'readonly="readonly";';}?> style="display: inline;" />
								  
								  <label style="margin-left: 5px;">Contact closure 1</label>
							   </div>
								</div>
							</td>
						  </tr>
						  <tr><td colspan="3">&nbsp;</td></tr>
						  <tr>
							<td width="10%"><strong>Pump Number:</strong></td>
							<td width="1%">&nbsp;</td>
							<td width="89%">
								<input type="text" placeholder="Enter Pump Number" name="sPumpNumber_<?php echo $i.'_'.$aIP->id;?>" class="inputText" value="<?php echo $i;?>" id="sPumpNumber_<?php echo $i.'_'.$aIP->id;?>" required <?php if($sAccess == 1){ echo 'readonly="readonly";';}?>>
							</td>
						  </tr>
						  <tr><td colspan="3">&nbsp;</td></tr>

						  <tr>
							<td width="10%"><strong>Pump Type:</strong></td>
							<td width="1%">&nbsp;</td>
							<td width="89%">
							<select name="sPumpType_<?php echo $i.'_'.$aIP->id;?>" id="sPumpType_<?php echo $i.'_'.$aIP->id;?>" <?php if($sAccess == 1){ echo 'disabled="disabled";';}?> onchange="showDetailsPump(this.value,'<?php echo $i;?>','<?php echo $aIP->id;?>');" class="form-control" style="width:50%">
								<option value="12" <?php if($sPumpType == '12'){echo 'selected="selected";';}?> >12V DC</option>
								<option value="24" <?php if($sPumpType == '24'){echo 'selected="selected";';}?>>24V AC</option>
								<option value="2Speed" <?php if($sPumpType == '2Speed'){echo 'selected="selected";';}?>>2 Speed</option>
								<option value="Intellicom" <?php if($sPumpType == 'Intellicom'){echo 'selected="selected";';}?>>Intellicom for a Pentair VS or VF Pump</option>
								<option value="Intellicom12" <?php if($sPumpType == 'Intellicom12'){echo 'selected="selected";';}?>>Intellicom for a Pentair VS or VF Pump 12V DC</option>
								<option value="Intellicom24" <?php if($sPumpType == 'Intellicom24'){echo 'selected="selected";';}?>>Intellicom for a Pentair VS or VF Pump 24V AC</option>
								<option value="Emulator" <?php if($sPumpType == 'Emulator'){echo 'selected="selected";';}?>>Emulator Pentair VS or VF Pump</option>
								<option value="Emulator12" <?php if($sPumpType == 'Emulator12'){echo 'selected="selected";';}?>>Emulator Pentair VS or VF Pump 12V DC</option>
								<option value="Emulator24" <?php if($sPumpType == 'Emulator24'){echo 'selected="selected";';}?>>Emulator Pentair VS or VF Pump 24V AC</option>
							</select>
							</td>
						  </tr>
						  
						  <tr id="pumpSubType2SpeedTrBlk_<?php echo $i.'_'.$aIP->id;?>" style="display:<?php if($sPumpType == '2Speed'){echo '';}else{echo 'none;';} ?>"><td colspan="3">&nbsp;</td></tr>
						  <tr id="pumpSubType2SpeedTr_<?php echo $i.'_'.$aIP->id;?>" style="display:<?php if($sPumpType == '2Speed'){echo '';}else{echo 'none;';} ?>">
							<td width="10%"><strong>Select Relay:</strong></td>
							<td width="1%">&nbsp;</td>
							<td width="89%">
								<select name="sPumpSubType1_<?php echo $i.'_'.$aIP->id;?>" id="sPumpSubType1_<?php echo $i.'_'.$aIP->id;?>" <?php if($sAccess == 1){ echo 'disabled="disabled";';}?> class="form-control" style="width:50%">
								<option value="12" <?php if($sPumpSubType == '12'){echo 'selected="selected";';}?>>12V DC</option>
								<option value="24" <?php if($sPumpSubType == '24'){echo 'selected="selected";';}?>>24V AC</option>
								</select>
							</td>
						  </tr>
						  
						  <tr id="pumpSubTypeTrBlk_<?php echo $i.'_'.$aIP->id;?>" style="display:<?php if(preg_match('/Emulator/',$sPumpType)){echo '';}else{echo 'none;';} ?>"><td colspan="3">&nbsp;</td></tr>
						  <tr id="pumpSubTypeTr_<?php echo $i.'_'.$aIP->id;?>" style="display:<?php if(preg_match('/Emulator/',$sPumpType)){echo '';}else{ echo'none;';} ?>;">
							<td width="10%"><strong>Pump Sub Type:</strong></td>
							<td width="1%">&nbsp;</td>
							<td width="89%">
								<select name="sPumpSubType_<?php echo $i.'_'.$aIP->id;?>" id="sPumpSubType_<?php echo $i.'_'.$aIP->id;?>" <?php if($sAccess == 1){ echo 'disabled="disabled";';}?> class="form-control" style="width:50%" onchange="subTypeDetails(this.value,'<?php  echo $i;?>','<?php echo $aIP->id;?>')">
									<option value="VS" <?php if($sPumpSubType == 'VS'){echo 'selected="selected";';}?>>VS Pump (Variable Speed)</option>
									<option value="VF" <?php if($sPumpSubType == 'VF'){echo 'selected="selected";';}?>>VF Pump (Variable Flow)</option>
								</select>
							</td>
						  </tr>
						  
						  <tr id="trVSSpaceIntellicom_<?php echo $i.'_'.$aIP->id;?>" style="display:<?php if(preg_match('/Intellicom/',$sPumpType)) { echo ''; } else { echo 'none';} ?>;"><td colspan="3">&nbsp;</td></tr>
						  <tr id="trVSIntellicom_<?php echo $i.'_'.$aIP->id;?>" style="display:<?php if(preg_match('/Intellicom/',$sPumpType)) { echo ''; } else { echo 'none';} ?>;">
							<td width="10%"><strong>Pump Speed:</strong></td>
							<td width="1%">&nbsp;</td>
							<td width="89%">
								<div class="rowCustom">
								  <input type="radio" name="sPumpSpeedIn_<?php echo $i.'_'.$aIP->id;?>" id="sPumpSpeedIn0_<?php echo $i.'_'.$aIP->id;?>" value="0" <?php if($sPumpSpeed == '0') { echo 'checked=""checked';} ?> <?php if($sAccess == 1){ echo 'disabled="disabled";';}?> style="display: inline;">
								  <label style="margin-left: 5px;">0</label>
								  
								  <input type="radio" name="sPumpSpeedIn_<?php echo $i.'_'.$aIP->id;?>" id="sPumpSpeedIn1_<?php echo $i.'_'.$aIP->id;?>" value="1" <?php if($sPumpSpeed == '1') { echo 'checked=""checked';} ?> <?php if($sAccess == 1){ echo 'disabled="disabled";';}?> style="display: inline;">
								  <label style="margin-left: 5px;">1</label>
								  
								  <input type="radio" name="sPumpSpeedIn_<?php echo $i.'_'.$aIP->id;?>" id="sPumpSpeedIn2_<?php echo $i.'_'.$aIP->id;?>" value="2" <?php if($sPumpSpeed == '2') { echo 'checked=""checked';} ?> <?php if($sAccess == 1){ echo 'disabled="disabled";';}?> style="display: inline;">
								  <label style="margin-left: 5px;">2</label>
								  
								  <input type="radio" name="sPumpSpeedIn_<?php echo $i.'_'.$aIP->id;?>" id="sPumpSpeedIn3_<?php echo $i.'_'.$aIP->id;?>" value="3" <?php if($sPumpSpeed == '3') { echo 'checked=""checked';} ?> <?php if($sAccess == 1){ echo 'disabled="disabled";';}?> style="display: inline;">
								  <label style="margin-left: 5px;">3</label>
								  
								  <input type="radio" name="sPumpSpeedIn_<?php echo $i.'_'.$aIP->id;?>" id="sPumpSpeedIn4_<?php echo $i.'_'.$aIP->id;?>" value="4" <?php if($sPumpSpeed == '4') { echo 'checked=""checked';} ?> <?php if($sAccess == 1){ echo 'disabled="disabled";';}?> style="display: inline;">
								  <label style="margin-left: 5px;">4</label>
								  
							   </div>
							</td>
						  </tr>
						  
						  <tr id="trVSSpace_<?php echo $i.'_'.$aIP->id;?>" style="display:<?php if($sPumpSubType =='VS' && preg_match('/Emulator/',$sPumpType)) { echo ''; } else { echo 'none';} ?>;"><td colspan="3">&nbsp;</td></tr>
						  <tr id="trVS_<?php echo $i.'_'.$aIP->id;?>" style="display:<?php if($sPumpSubType =='VS' && preg_match('/Emulator/',$sPumpType)) { echo ''; } else { echo 'none';} ?>;">
							<td width="10%"><strong>Pump Speed:</strong></td>
							<td width="1%">&nbsp;</td>
							<td width="89%">
								<div class="rowCustom">
								<div class="colCustom" style="padding-left:0;">
								  <input type="radio" name="sPumpSpeed_<?php echo $i.'_'.$aIP->id;?>" id="sPumpSpeed0_<?php echo $i.'_'.$aIP->id;?>" value="0" <?php if($sPumpSpeed == '0') { echo 'checked=""checked';} ?> <?php if($sAccess == 1){ echo 'disabled="disabled";';}?> style="display: inline;">
								  <label style="margin-left: 5px;">0</label>
								  
								  <input type="radio" name="sPumpSpeed_<?php echo $i.'_'.$aIP->id;?>" id="sPumpSpeed1_<?php echo $i.'_'.$aIP->id;?>" value="1" <?php if($sPumpSpeed == '1') { echo 'checked=""checked';} ?> <?php if($sAccess == 1){ echo 'disabled="disabled";';}?> style="display: inline;">
								  <label style="margin-left: 5px;">1</label>
								  
								  <input type="radio" name="sPumpSpeed_<?php echo $i.'_'.$aIP->id;?>" id="sPumpSpeed2_<?php echo $i.'_'.$aIP->id;?>" value="2" <?php if($sPumpSpeed == '2') { echo 'checked=""checked';} ?> <?php if($sAccess == 1){ echo 'disabled="disabled";';}?> style="display: inline;">
								  <label style="margin-left: 5px;">2</label>
								  
								  <input type="radio" name="sPumpSpeed_<?php echo $i.'_'.$aIP->id;?>" id="sPumpSpeed3_<?php echo $i.'_'.$aIP->id;?>" value="3" <?php if($sPumpSpeed == '3') { echo 'checked=""checked';} ?> <?php if($sAccess == 1){ echo 'disabled="disabled";';}?> style="display: inline;">
								  <label style="margin-left: 5px;">3</label>
								  
								  <input type="radio" name="sPumpSpeed_<?php echo $i.'_'.$aIP->id;?>" id="sPumpSpeed4_<?php echo $i.'_'.$aIP->id;?>" value="4" <?php if($sPumpSpeed == '4') { echo 'checked=""checked';} ?> <?php if($sAccess == 1){ echo 'disabled="disabled";';}?> style="display: inline;">
								  <label style="margin-left: 5px;">4</label>
							   </div>
							 </div>
							</td>
						  </tr>
						  
						  <tr id="trVFSpace_<?php echo $i.'_'.$aIP->id;?>" style="display:<?php if($sPumpSubType =='VF' && $sPumpType == 'Emulator') { echo ''; } else { echo 'none';} ?>;"><td colspan="3">&nbsp;</td></tr>
						  <tr id="trVF_<?php echo $i.'_'.$aIP->id;?>" style="display:<?php if($sPumpSubType =='VF' && $sPumpType == 'Emulator') { echo ''; } else { echo 'none';} ?>;">
							<td width="10%"><strong>Pump Flow:</strong></td>
							<td width="1%">&nbsp;</td>
							<td width="89%">
								<input type="text" name="sPumpFlow_<?php echo $i.'_'.$aIP->id;?>" id="sPumpFlow_<?php echo $i.'_'.$aIP->id;?>" value="<?php echo $sPumpFlow;?>" class="inputText" <?php if($sAccess == 1){ echo 'readonly="readonly";';}?>>
							</td>
						  </tr>
						  
						  <tr id="trRelayNumberSpace_<?php echo $i.'_'.$aIP->id;?>" <?php if($sPumpType == 'Intellicom' || $sPumpType == 'Emulator') { echo 'style="display:none;"';} ?>><td colspan="3">&nbsp;</td></tr>
						  
						  <tr id="trRelayNumber_<?php echo $i.'_'.$aIP->id;?>" <?php if($sPumpType == 'Intellicom' || $sPumpType == 'Emulator') { echo 'style="display:none;"';} ?>>
							<td width="10%"><strong>Relay Number:</strong></td>
							<td width="1%">&nbsp;</td>
							<td width="89%">
								<input type="text" class="inputText" name="sRelayNumber_<?php echo $i.'_'.$aIP->id;?>" id="sRelayNumber_<?php echo $i.'_'.$aIP->id;?>" value="<?php echo $sRelayNumber;?>" <?php if($sPumpType != 'Intellicom' && $sPumpType != 'Emulator'  ) { echo 'required';} ?> <?php if($sAccess == 1){ echo 'readonly="readonly";';}?>>
							</td>
						  </tr>
						  
						  <tr id="trRelayNumber1Space_<?php echo $i.'_'.$aIP->id;?>" <?php if($sPumpType == '2Speed') { echo '';} else { echo 'style="display:none;"';}?>><td colspan="3">&nbsp;</td></tr>
						  
						  <tr id="trRelayNumber1_<?php echo $i.'_'.$aIP->id;?>" <?php if($sPumpType == '2Speed') { echo '';} else { echo 'style="display:none;"';}?>>
							<td width="10%"><strong>Relay Number 2:</strong></td>
							<td width="1%">&nbsp;</td>
							<td width="89%">
								<input type="text" class="inputText" name="sRelayNumber1_<?php echo $i.'_'.$aIP->id;?>" id="sRelayNumber1_<?php echo $i.'_'.$aIP->id;?>" value="<?php echo $sRelayNumber1;?>" <?php if($sPumpType == '2Speed') { echo 'required';} ?> <?php if($sAccess == 1){ echo 'readonly="readonly";';}?>>
							</td>
						  </tr>
						  
						  <tr id="trAddressNumberSpace_<?php echo $i.'_'.$aIP->id;?>" <?php if($sPumpType == '12' || $sPumpType == '24' || $sPumpType == '2Speed' || $sPumpType == '') { echo 'style="display:none;"';} ?>><td colspan="3">&nbsp;</td></tr>
						  
						  <tr id="trAddressNumber_<?php echo $i.'_'.$aIP->id;?>" <?php if($sPumpType == '12' || $sPumpType == '24' || $sPumpType == '2Speed' || $sPumpType == '') { echo 'style="display:none;"';} ?>>
							<td width="10%"><strong>Pump Address:</strong></td>
							<td width="1%">&nbsp;</td>
							<td width="89%">
								<input type="text" class="inputText" name="sPumpAddress_<?php echo $i.'_'.$aIP->id;?>" id="sPumpAddress_<?php echo $i.'_'.$aIP->id;?>" value="<?php echo $sPumpAddress;?>" <?php if($sPumpType != '12' && $sPumpType != '24' && $sPumpType != '2Speed') { echo 'required';} ?> <?php if($sAccess == 1){ echo 'readonly="readonly";';}?>>
							</td>
						  </tr>
						  <tr><td colspan="3"><hr style="border-color:#000;" /></td></tr>
						 </table>
						</td>
					</tr>
					
				<?php } ?>
				<?php if($sAccess == '2') { ?>
					<tr id="pumpSaveConf_<?php echo $aIP->id;?>" style="display:<?php if($extra['PumpsNumber'] == 0){ echo 'none;';}?>">
						<td colspan="3">
							<a href="javascript:void(0);" onclick="checkAndSavePumps('<?php echo $aIP->id;?>');" class="btn btn-middle"><span>Save</span></a>
							&nbsp;&nbsp;
							<a href="javascript:void(0);" onclick="javascript:$('#pumpForm').toggleClass('disableConfig');" class="btn btn-middle btn-gray"><span>Cancel</span></a>
							&nbsp;&nbsp;
							<span id="loadingImgPump_<?php echo $aIP->id;?>" style="display:none; vertical-align: middle;">
								<img src="<?php echo site_url('assets/images/loading.gif');?>" alt="Loading...." width="32" height="32">
							</span>
						</td>
					</tr>
				<?php } ?>	
				</tbody>
			</table>
			<?php
					}
				}
			?>	
		</div>
			
	</div>
	<!-- Pump Configuration -->
	</div>
</section>
<!-- Section -->