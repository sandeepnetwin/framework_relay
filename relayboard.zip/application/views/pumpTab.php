<h3>Pump Setting</h3>
            <section style="float: none;padding: 2.5%;position: relative;">
			<div class="col-sm-12">
			<label for="automatic_pumps">How many Pumps do you have?<span class="requiredMark">*</span></label>&nbsp;&nbsp;<a class="fancyboxPump changeLink" id="changeLinkPump" href="#pumpForm">Change</a>
                <select name="automatic_pumps" id="automatic_pumps" class="form-control required" onchange="pumpChange();">
					<option <?php if(isset($arrDevice['pump']) && $arrDevice['pump'] == '0'){ echo 'selected="selected"';} ?>  value="0">0 Pump</option>
					<?php for($i=1;$i<=$iPumpCnt;$i++){?>
					<option <?php if(isset($arrDevice['pump']) && $arrDevice['pump'] == $i){ echo 'selected="selected"';} ?>  value="<?php echo $i;?>"><?php echo $i;?> Pump</option>
					<?php } ?>
					
				</select>
				
				<div style="height:10px">&nbsp;</div>
				<table width="100%;">
				<?php for($i=1;$i<=$iPumpCnt;$i++){?>
				<tr id="trPump<?php echo $i;?>" style="display:<?php if(isset($arrDevice['pump']) && $arrDevice['pump'] >= $i){ echo '';} else {echo 'none;';} ?>">
					<td>
						<label for="strValve">Pump<?php echo $i;?><span class="requiredMark">*</span></label>
						<select name="Pump<?php echo $i;?>" id="Pump<?php echo $i;?>" class="form-control required">
						<option <?php if(isset($arrDevice['pump'.$i]) && $arrDevice['pump'.$i] == ''){ echo 'selected="selected"';} ?> value="">--Select pump function--</option>
						<option <?php if(isset($arrDevice['pump'.$i]) && $arrDevice['pump'.$i] == 'Filtering Pool and Spa'){ echo 'selected="selected"';} ?> value="Filtering Pool and Spa">Filtering Pool and Spa</option>
						<option <?php if(isset($arrDevice['pump'.$i]) && $arrDevice['pump'.$i] == 'Filtering Spa Only'){ echo 'selected="selected"';} ?> value="Filtering Spa Only">Filtering Spa Only</option>
						<option <?php if(isset($arrDevice['pump'.$i]) && $arrDevice['pump'.$i] == 'Filtering Pool Only'){ echo 'selected="selected"';} ?> value="Filtering Pool Only">Filtering Pool Only</option>
						<option <?php if(isset($arrDevice['pump'.$i]) && $arrDevice['pump'.$i] == 'Spa Jets Only'){ echo 'selected="selected"';} ?> value="Spa Jets Only">Spa Jets Only</option>
						<option <?php if(isset($arrDevice['pump'.$i]) && $arrDevice['pump'.$i] == 'Spa Circulation and Heating'){ echo 'selected="selected"';} ?> value="Spa Circulation and Heating">Spa Circulation and Heating</option>
						<option <?php if(isset($arrDevice['pump'.$i]) && $arrDevice['pump'.$i] == 'Pool Circulation and Heating'){ echo 'selected="selected"';} ?> value="Pool Circulation and Heating">Pool Circulation and Heating</option>
						<option <?php if(isset($arrDevice['pump'.$i]) && $arrDevice['pump'.$i] == 'Pool and Spa Circulation and Heating'){ echo 'selected="selected"';} ?> value="Pool and Spa Circulation and Heating">Pool and Spa Circulation and Heating</option>
						<option <?php if(isset($arrDevice['pump'.$i]) && $arrDevice['pump'.$i] == 'waterfall'){ echo 'selected="selected"';} ?> value="waterfall">waterfall</option>
						<option <?php if(isset($arrDevice['pump'.$i]) && $arrDevice['pump'.$i] == 'solar heater'){ echo 'selected="selected"';} ?> value="solar heater">solar heater</option>
						<option <?php if(isset($arrDevice['pump'.$i]) && $arrDevice['pump'.$i] == 'waterslide'){ echo 'selected="selected"';} ?> value="waterslide">waterslide</option>
						<option <?php if(isset($arrDevice['pump'.$i]) && $arrDevice['pump'.$i] == 'water feature 1'){ echo 'selected="selected"';} ?> value="water feature 1">water feature 1</option>
						<option <?php if(isset($arrDevice['pump'.$i]) && $arrDevice['pump'.$i] == 'water feature 2'){ echo 'selected="selected"';} ?> value="water feature 2">water feature 2</option>
						</select>
					</td>
				</tr>
				<tr style="height:10px;"><td>&nbsp;</td></tr>
				<tr class="trPumpShow" id="trPumpShow<?php echo $i;?>" style="display:<?php if(isset($arrDevice['pump']) && $arrDevice['pump'] >= $i){ echo '';} else {echo 'none;';} ?>">
					<td>
					<label for="strValve">Assign Pump<?php echo $i;?><span class="requiredMark">*</span></label>
					<select name="PumpAssign<?php echo $i;?>" id="PumpAssign<?php echo $i;?>" class="form-control">
					<option value="">--Select Pump--</option>
					<?php foreach($Pumps as $pump) { ?>
					<option value="<?php echo $pump->pump_number;?>">Pump <?php echo $pump->pump_number;?></option>
					<?php } ?>
					</select>	
					</td>
				</tr>
				<?php } ?>
				</table>
			</div>
            </section>