<?php
$this->load->model('home_model');
$sAccess 		= '';
$sModule	    = '';
$sDeviceFullName = '';

$iTotalIP	=	count($aIPDetails);
	  
	$sIPOptions	=	'';
	$iFirstIPId	=	'';	
	
	if($BackToIP != '')
		$iFirstIPId	= $BackToIP;
	
	if(!empty($aIPDetails))
	{
		foreach($aIPDetails as $aIP)
		{
			//First IP ID to show selected.
			if($iFirstIPId == '')
				$iFirstIPId = $aIP->id;
							
			$sDetails	=	$aIP->ip;
			if($aIP->name != '')
			{
				$sDetails .= ' ('.$aIP->name.')';
			}
			
			$sShow		=	'display:none';
			$sSelected	=	'';
			if($iFirstIPId == $aIP->id)
			{ 
				$sShow		=	'';
				$sSelected	=	'selected="selected"';
			} 
			
			$sIPOptions.='<option value="'.$aIP->id.'" '.$sSelected.'>'.$sDetails.'</option>';
		}
	}

?>
<style>
	.deviceTitle
	{
		color: #44b0e7;
		font-weight: bold;
		line-height: 40px;
		margin-left: 40px;
	}
</style>
<script type="text/javascript" src="<?php echo HTTP_ASSETS_PATH.'fancybox/source/jquery.fancybox.js?v=2.1.5';?>"></script>
<link rel="stylesheet" type="text/css" href="<?php echo HTTP_ASSETS_PATH.'fancybox/source/jquery.fancybox.css?v=2.1.5';?>" media="screen" />
<?php if($sDevice != 'V') { ?>
<script type="text/javascript">
var $a = $.noConflict();
$a(document).ready(function() {
	$a('.fancybox').fancybox({'closeBtn' : false,'helpers': {'overlay' : {'closeClick': false}}
	});
});
</script>
<?php } ?>	
<link href="<?php echo HTTP_ASSETS_PATH.'progressbar/css/static.css';?>" rel="stylesheet"/>
<script src="<?php echo HTTP_ASSETS_PATH.'progressbar/js/static.min.js';?>"></script>
<script src="<?php echo HTTP_ASSETS_PATH.'progressbar/dist/js/jquery.progresstimer.js';?>"></script>


<script type="text/javascript">
jQuery(document).ready(function($) {
	
	setInterval( function() {
		var sDevice	= '<?php echo $sDevice;?>';
		var sIdIP	=	 $("#IpId").val();
		$.ajax({
				type: "POST",
				url: "<?php echo site_url('home/getStatusAll/');?>", 
				data: {sDevice:sDevice,sIdIP:sIdIP},
				success: function(data) {
					var deviceStatus = jQuery.parseJSON(data);
					var lableText   = '';
					
					
					$.each( deviceStatus, function( key, value ) 
					{
						if(key == 'R')
						{
							lableText = 'lableRelay-';
						}
						else if(key == 'P')
						{
							lableText = 'lablePower-';
						}
						else if(key == 'L')
						{
							lableText = 'lableRelayLight-';
						}
						
						$.each( value, function( iDevice, sStatus ) 
						{
							if(key != 'V')
							{
								if(sStatus == '1')
								{
									if($("#"+lableText+iDevice+"-"+sIdIP).length)
									{
										if(!$("#"+lableText+iDevice+"-"+sIdIP).hasClass('checked'))
										{
											$("#"+lableText+iDevice+"-"+sIdIP).addClass('checked');
										}
										else
										{
											$("#"+lableText+iDevice+"-"+sIdIP).addClass('checked'); 
										}
									}
								}
								else if(sStatus == '0')
								{
									if($("#"+lableText+iDevice+"-"+sIdIP).length)
									{
										if($("#"+lableText+iDevice+"-"+sIdIP).hasClass('checked'))
										{
											$("#"+lableText+iDevice+"-"+sIdIP).removeClass('checked');
										}
									}
								}
							}
							else if(key == 'V')
							{
								if($("#switch-me-"+iDevice+"-"+sIdIP).length)
								{
									$('#switch-me-'+iDevice+"-"+sIdIP).val(sStatus).change();
								}
							} 
						}); 
					});
					
				}
		});
	},30000);
	
	$(".relayButton").click(function()
	{
		var sIdIP	=	 $("#IpId").val();
		//$a('.fancybox').fancybox();
		<?php if($iActiveMode == '2') { ?>
		$(".loading-progress").show();
		var progress = $(".loading-progress").progressTimer({
			timeLimit: 10,
			onFinish: function () {
			  //$(".loading-progress").hide();
			  parent.$a.fancybox.close();
			}
		});
		
		$a("#checkLink").trigger('click');
		
		
		//$a('.fancybox-inner').height(450);
		//$a.fancybox.reposition();
		
		var relayNumber = $(this).val();
		var status		= '';
		if($("#lableRelay-"+relayNumber+"-"+sIdIP).hasClass('checked'))
		{	
			status	=	0;
		}
		else
		{
			status = 1;
		}
		
		
		 $.ajax({
			type: "POST",
			url: "<?php echo site_url('home/updateStatusOnOff/');?>", 
			data: {sName:relayNumber,sStatus:status,sDevice:'R',sIdIP:sIdIP},
			success: function(data) {
				if($("#lableRelay-"+relayNumber+"-"+sIdIP).hasClass('checked'))
				{	
					$("#lableRelay-"+relayNumber+"-"+sIdIP).removeClass('checked');
				}
				else
				{
					$("#lableRelay-"+relayNumber+"-"+sIdIP).addClass('checked');
				}
				
			}
		}).error(function(){
        progress.progressTimer('error', {
            errorText:'ERROR!',
            onFinish:function(){
                alert('There was an error processing your information!');
            }
        });
		}).done(function(){
			progress.progressTimer('complete');
		});
		 <?php } else {  ?>
		  alert('You can perform this operation in manual mode only.');
		 <?php } ?> 
	});
	
	$(".powerButton").click(function()
	{
		var sIdIP	=	 $("#IpId").val();
		
		<?php if($iActiveMode == '2') { ?>
		 $(".loading-progress").show();
		var progress = $(".loading-progress").progressTimer({
			timeLimit: 10,
			onFinish: function () {
			  //$(".loading-progress").hide();
			  parent.$a.fancybox.close();
			}
		});
		
		$a("#checkLink").trigger('click');
		
		
		var relayNumber = $(this).val();
		var status		= '';
		if($("#lablePower-"+relayNumber+"-"+sIdIP).hasClass('checked'))
		{	
			status	=	0;
		}
		else
		{
			status = 1;
		}
		
		
		 $.ajax({
			type: "POST",
			url: "<?php echo site_url('home/updateStatusOnOff/');?>", 
			data: {sName:relayNumber,sStatus:status,sDevice:'P',sIdIP:sIdIP},
			success: function(data) {
				if($("#lablePower-"+relayNumber+"-"+sIdIP).hasClass('checked'))
				{	
					$("#lablePower-"+relayNumber+"-"+sIdIP).removeClass('checked');
				}
				else
				{
					$("#lablePower-"+relayNumber+"-"+sIdIP).addClass('checked');
				}
				
			}
		}).error(function(){
        progress.progressTimer('error', {
            errorText:'ERROR!',
            onFinish:function(){
                alert('There was an error processing your information!');
            }
        });
		}).done(function(){
			progress.progressTimer('complete');
		});
		 <?php } else {  ?>
		  alert('You can perform this operation in manual mode only.');
		 <?php } ?> 
	});
	
	$(".pumpsButton").click(function()
	{
		var sIdIP	=	 $("#IpId").val();
		
		<?php if($iActiveMode == '2') { ?>
		$(".loading-progress").show();
		var progress = $(".loading-progress").progressTimer({
			timeLimit: 10,
			onFinish: function () {
			  //$(".loading-progress").hide();
				setTimeout(function(){location.reload();parent.$a.fancybox.close();},1000);
				
			}
		});
		
		$a("#checkLink").trigger('click');
		
		var relayNumber = $(this).val();
		var status		= '';
		if($("#lablePump-"+relayNumber+"-"+sIdIP).hasClass('checked'))
		{	
			status	=	0;
		}
		else
		{
			status = 1;
		}
		
		<?php //if($iActiveMode == '2') { ?>
		 $.ajax({
			type: "POST",
			url: "<?php echo site_url('home/updateStatusOnOff/');?>", 
			data: {sName:relayNumber,sStatus:status,sDevice:'PS',sIdIP:sIdIP},
			success: function(data) {
				
				if($("#lablePump-"+relayNumber+"-"+sIdIP).hasClass('checked'))
				{	
					$("#lablePump-"+relayNumber+"-"+sIdIP).removeClass('checked');
				}
				else
				{
					$("#lablePump-"+relayNumber+"-"+sIdIP).addClass('checked');
				}
				
				
				
			}
		}).error(function(){
        progress.progressTimer('error', {
            errorText:'ERROR!',
            onFinish:function(){
                alert('There was an error processing your information!');
            }
        });
		}).done(function(){
			progress.progressTimer('complete');
		});
		 <?php } else {  ?>
		  alert('You can perform this operation in manual mode only.');
		  
		 <?php } ?> 
	});
	
	$(".lightButton").click(function()
	{
		var sIdIP	=	 $("#IpId").val();
		
        var chkVal      = $(this).val();
        var arrDetails	= chkVal.split("|||");	
        
        var lightNumber = arrDetails[0];
        var relayNumber = arrDetails[2];
        var sDevice     = '';
        
        if(arrDetails[1] == '24')
            sDevice     =   'R';    
        else if(arrDetails[1] == '12')
            sDevice     =   'P';
        
        <?php if($iActiveMode == '2') { ?>
        $(".loading-progress").show();
        var progress = $(".loading-progress").progressTimer({
                timeLimit: 10,
                onFinish: function () {
                    //$(".loading-progress").hide();
                    parent.$a.fancybox.close();
                }
        });
        
        
        $a("#checkLink").trigger('click');

        var status		= '';
        if($("#lableRelayLight-"+lightNumber+"-"+sIdIP).hasClass('checked'))
        {	
                status	=	0;
        }
        else
        {
                status = 1;
        }


            $.ajax({
                type: "POST",
                url: "<?php echo site_url('home/updateStatusOnOff/');?>", 
                data: {sName:relayNumber,sStatus:status,sDevice:sDevice,sIdIP:sIdIP},
                success: function(data) {
					if($("#lableRelayLight-"+lightNumber+"-"+sIdIP).hasClass('checked'))
					{	
						$("#lableRelayLight-"+lightNumber+"-"+sIdIP).removeClass('checked');
					}
					else
					{
						$("#lableRelayLight-"+lightNumber+"-"+sIdIP).addClass('checked');
					}

                }
        }).error(function(){
            progress.progressTimer('error', {
                errorText:'ERROR!',
                onFinish:function(){
                    alert('There was an error processing your information!');
                }
            });
        }).done(function(){
                progress.progressTimer('complete');
        });
            <?php } else {  ?>
            alert('You can perform this operation in manual mode only.');
            <?php } ?> 
    });
});

function showBoardDetails(board)
{
	if(board == '')
	{
		alert("Please select IP first!");
		return false;
	}
	$("[id^='onoffbuttons_']").hide();
	
	$("#onoffbuttons_"+board).show();
	
	$("#IpId").val(board);
}
</script>

    <div id="page-wrapper">
	
        <div class="row">
          <div class="col-lg-12">
            <ol class="breadcrumb" style="float:left;">
                <li><img src="<?php echo HTTP_IMAGES_PATH.'icons/home.png';?>" width="24" style="vertical-align: middle !important;">&nbsp;<a href="<?php echo site_url();?>">Home</a> </li>
                <li class="active">Spa Device</li>
            </ol>
		  </div>
        </div>
		
		<div class="row">
			<div class="col-sm-12">
			<span style="color:#FFF; font-weight:bold;">Select Board : </span>
			<select name="selPort" id="selPort" onchange="showBoardDetails(this.value)">
				<option value="">--IP(Name)--</option>
				<?php echo $sIPOptions;?>
			</select>	
			</div>
		</div>
		<div class="row">
			<div class="col-sm-12">&nbsp;</div>
		</div>
		
        <!-- /.row -->
        <div class="row">
		<?php
			if(!empty($aIPDetails))
			{
				foreach($aIPDetails as $aIP)
				{
					$currentID = $aIP->id;
		?>
		<div class="col-sm-12" id="onoffbuttons_<?php echo $currentID;?>" style="display:<?php if($currentID != $iFirstIPId){ echo 'none';} ?>" >
		<div class="widget-container widget-stats boxed green-line">
		<div class="widget-title">
			<a href="<?php echo base_url('home/SpaDevice');?>" class="link-refresh" id="link-refresh-1"><span class="glyphicon glyphicon-refresh"></span></a>
			<h3>Spa Devices ON/OFF</h3>
		</div>
		<div class="stats-content clearfix">
        <?php //if($sDevice == 'R') 
			$sDevice                = 'R' ;
			$sDeviceFullName 	= '24V AC Relay';
			$sModule	    	= 2;
			
			$sAccessKey	= 'access_'.$sModule;
				  
			  if(!empty($aModules))
			  {
				  if(in_array($sModule,$aModules->ids))
				  {
					 $sAccess 		= $aModules->$sAccessKey;
				  }
			  }
		  
			if($sAccess == '')
				$sAccess = '2' ; 
		  
			if($sAccess == '0') {redirect(site_url('home/'));}?>
		
		<?php if(($sAccess == '1' || $sAccess == '2') && ${"relay_count".$currentID} > 0) { ?> 
        <div class="stats-content-right" style="width:96% !important; margin-left:5px; margin-right:5px; margin-top:10px; float:none;">
		<div class="deviceTitle">24V Relays</div>
		<?php
				$spaRelayDeviceCnt = 0;
				for ($i=0;$i < ${"relay_count".$currentID}; $i++)
				{
					$iRelayVal = ${"sRelays".$currentID}[$i];
					
					if($iRelayVal != '' && $iRelayVal !='.') 
					{
						$strChecked	=	'';
						if($iRelayVal == '1')
								$strChecked	=	'class="checked"';

						$sRelayNameDb =  $this->home_model->getDeviceName($i,$sDevice,$currentID);
						$strRelayName = 'Relay '.$i;
						if($sRelayNameDb != '')
								$strRelayName .= ' ('.$sRelayNameDb.')';
						
						$sMainType =	$this->home_model->getDeviceMainType($i,$sDevice,$currentID);
						if($sMainType == '1')
						{
							$spaRelayDeviceCnt++;
			?>      
							<div class="rowCheckbox switch">
								<div class="custom-checkbox">
									<input type="checkbox" value="<?php echo $i.'_'.$currentID;?>" id="relay_<?php echo $i?>_<?php echo $currentID;?>" name="relay-<?php echo $i?>-<?php echo $currentID;?>" class="relayButton" hidefocus="true" style="outline: medium none;">
									<label style="margin-left:60px;" <?php echo $strChecked;?>  id="lableRelay-<?php echo $i?>-<?php echo $currentID;?>" for="relay_<?php echo $i?>_<?php echo $currentID;?>"><span style="color:#C9376E; float:right;"><?php echo $strRelayName;?></span></label>
								</div>
							</div>
		<?php           
						}
					}		
				}
			?> 
			<hr />
		</div>
		
        <?php } ?>
        
		<?php //if($sDevice == 'P') 
		$sDevice            = 'P' 	;
		$sDeviceFullName = '12V DC Power Center Relay';
		$sModule	       = 3;
		
		$sAccessKey	= 'access_'.$sModule;
			  
		  if(!empty($aModules))
		  {
			  if(in_array($sModule,$aModules->ids))
			  {
				 $sAccess 		= $aModules->$sAccessKey;
			  }
		  }
	  
		if($sAccess == '')
			$sAccess = '2' ; 
	  
		if($sAccess == '0') {redirect(site_url('home/'));}	
	
		?>
		<?php if(($sAccess == '1' || $sAccess == '2') && ${"power_count".$currentID} >0) 
			  { 
		?>
			<div class="stats-content-right" style="width:96% !important; margin-left:5px; margin-right:5px; margin-top:10px; float:none;">
			<div class="deviceTitle">12V DC Relays</div>
			<?php
							$spaPowerDeviceCnt  =   0;
							for ($i=0;$i < ${"power_count".$currentID}; $i++)
							{
									$iRelayVal = ${"sPowercenter".$currentID}[$i];

									if($iRelayVal != '' && $iRelayVal !='.') 
									{
										$strChecked	=	'';
										if($iRelayVal == '1')
												$strChecked	=	'class="checked"';

										$sRelayNameDb =  $this->home_model->getDeviceName($i,$sDevice,$currentID);
										$strRelayName = 'PowerCenter '.$i;
										if($sRelayNameDb != '')
												$strRelayName .= ' ('.$sRelayNameDb.')';
										
										$sMainType =	$this->home_model->getDeviceMainType($i,$sDevice,$currentID);
										if($sMainType == '1')
										{
											$spaPowerDeviceCnt++;
				?>
											
											<div class="rowCheckbox switch">
											<div class="custom-checkbox"><input type="checkbox" value="<?php echo $i.'_'.$currentID;?>" id="power_<?php echo $i?>_<?php echo $currentID;?>" name="power-<?php echo $i?>-<?php echo $currentID;?>" class="powerButton" hidefocus="true" style="outline: medium none;">
											<label <?php echo $strChecked;?> style="margin-left:60px;"  id="lablePower-<?php echo $i?>-<?php echo $currentID;?>" for="power_<?php echo $i?>_<?php echo $currentID;?>"><span style="color:#C9376E; float:right;"><?php echo $strRelayName;?></span></label>
											</div>
											</div>
					<?php           
										}
									}		
								}
								
					?> 
					<hr />
			</div>
			
        <?php } ?>
        <?php //if($sDevice == 'PS') 
		
		$sDevice            = 'PS' 	;
		$sDeviceFullName 	= 'Pump Sequencer';
		$sModule	        = 9;
		if($currentID == 1)
		$iPumpsNumber	=	$extra['PumpsNumber'];
		else
		$iPumpsNumber	=	$extra['PumpsNumber2'];
	
		$sAccessKey	= 'access_'.$sModule;
			  
		  if(!empty($aModules))
		  {
			  if(in_array($sModule,$aModules->ids))
			  {
				 $sAccess 		= $aModules->$sAccessKey;
			  }
		  }
	  
		if($sAccess == '')
			$sAccess = '2' ; 
	  
		if($sAccess == '0') {redirect(site_url('home/'));}
		
		{  // START : Pump Device?>
		<?php if(($sAccess == 1 || $sAccess == 2) && $iPumpsNumber > 0) { ?>
			
			<div class="stats-content-right" style="width:96% !important; margin-left:5px; margin-right:5px; margin-top:10px; float:none;">
			<div class="deviceTitle">Pumps</div>
			<?php
		
					if( $iPumpsNumber == 0 || $iPumpsNumber == '' )
					{ ?>
					<?php 
					}
					else
					{
						$spaPumpDeviceCnt	=	0;
						$arrPump		=	array(0,1,2);
						$remainigCount	=	0;
						$chkPump		=	0;
						if(!empty(${"Pumps".$currentID}))
						{
							foreach(${"Pumps".$currentID} as $pump)
							{
								
							$i= $pump->pump_number;
							unset($arrPump[$i]);		
							$iPumpVal = $sPump[$i];
							$sPumpNameDb =  $this->home_model->getDeviceName($i,$sDevice,$currentID);
							if($sPumpNameDb == '')
							  $sPumpNameDb = 'Add Name';
							
							$sStatus2Speed	=	'';
							
							$aPumpDetails = $this->home_model->getPumpDetails($i,$currentID);
							$sPumpType		=	'';
							if(!empty($aPumpDetails))
							{
								foreach($aPumpDetails as $aResultEdit)
								{
									$sPumpType    = $aResultEdit->pump_type;//Pump Type
									$sPumpRelay   = $aResultEdit->relay_number;//Assigned Relay Number
									$sPumpRelay1   = $aResultEdit->relay_number_1;//Assigned Relay Number
									if($sPumpType == '12')
									{
										$iPumpVal = ${"sPowercenter".$currentID}[$sPumpRelay]; //Taken the status
									}
									else if($sPumpType == '24')
									{
										$iPumpVal = ${"sRelays".$currentID}[$sPumpRelay];//Taken the status
									}
									else if($sPumpType == '2Speed')
									{
										$sPumpSubType    = $aResultEdit->pump_sub_type;//Pump SUB Type
										$sStatus2Speed   = $aResultEdit->status;//Pump SUB Type
										
										if($sStatus2Speed == '0')
										{
											$iPumpVal        = $sStatus2Speed;
										}
										else if($sStatus2Speed == '1')											
										{
											if($sPumpSubType == '12')
											{
												$iPumpVal = ${"sPowercenter".$currentID}[$sPumpRelay]; //Taken the status
											}
											else if($sPumpSubType == '24')
											{
												$iPumpVal = ${"sRelays".$currentID}[$sPumpRelay];//Taken the status
											}
										}
										else if($sStatus2Speed == '2')											
										{
											if($sPumpSubType == '12')
											{
												$iPumpVal = ${"sPowercenter".$currentID}[$sPumpRelay1]; //Taken the status
											}
											else if($sPumpSubType == '24')
											{
												$iPumpVal = ${"sRelays".$currentID}[$sPumpRelay1];//Taken the status
											}
										}
									}
									else if(preg_match('/Emulator/',$sPumpType))
									{
										 $iPumpVal = ${"sPump".$currentID}[$i];
									}
								}
							}	//END : Getting assigned relay status from the Server.
							$sPumpVal = false;
							if($iPumpVal)
							  $sPumpVal = true;
							
							$strChecked	=	'';
							if($iPumpVal > 0)
								$strChecked	=	'class="checked"';
						  
							$sMainType	 = $this->home_model->getDeviceMainType($i,$sDevice,$currentID);
							
							$strPumpName = 'Pump '.$i;
							if($sPumpNameDb != '' && $sPumpNameDb != 'Add Name')
								$strPumpName .= '('.$sPumpNameDb.')';
							
							if($sStatus2Speed == '')
								$sStatus2Speed = '0';
							
							if($sMainType == '1')
							{
								$spaPumpDeviceCnt++;
					?>
							<?php if($sPumpType == '2Speed') { ?>
								<script>
								var iActiveMode = '<?php echo $iActiveMode;?>';
								var sAccess 	= '<?php echo $sAccess;?>';
								</script>
								<link href="<?php echo site_url('assets/switchy/switchy.css'); ?>" rel="stylesheet" />
								<script type="text/javascript" src="<?php echo site_url('assets/switchy/switchy.js'); ?>"></script>
								<script type="text/javascript" src="<?php echo site_url('assets/switchy/jquery.event.drag.js'); ?>"></script>
								<script type="text/javascript" src="<?php echo site_url('assets/switchy/jquery.animate-color.js'); ?>"></script>
							
							<div class="span1 pump-<?php echo $i?>-<?php echo $currentID;?>" value="1" style="margin-top: 10px; width: auto; color: #428BCA;font-weight: bold; cursor: pointer; float: left;">Relay 1</div>
							
							<div class="span2" style="margin-left:5px; margin-right:5px; float: left;" >
								<select id='switch-me-<?php echo $i;?>-<?php echo $currentID;?>'>
								<option value='1' <?php if($sStatus2Speed == '1') { echo 'selected="selected"';} ?>>Spa</option>
								<option value='0' <?php if($sStatus2Speed == '0' || $iPumpVal == '') { echo 'selected="selected"';} ?>></option>
								<option value='2' <?php if($sStatus2Speed == '2') { echo 'selected="selected"';} ?>>Pool</option>
								</select>
								
								<div class="pump-<?php echo $i?>-<?php echo $currentID;?>" value="0" id="off-<?php echo $i;?>-<?php echo $currentID;?>" style="color: red;font-weight: bold;width: 0; margin-left: 30px; cursor: pointer;">
									OFF
								</div>
							</div>
							
							<div class="span1 pump-<?php echo $i?>-<?php echo $currentID;?>" value="2" style="margin-top: 10px; width: auto; color: #428BCA;font-weight: bold; cursor: pointer; float: left;">Relay 2</div>
							
							<div style="margin-top:10px; float:right; color:#C9376E;"><strong><?php echo $strPumpName;?></strong></div>
							
						  <script type="text/javascript">
						  
						  $(function()
						  {
							  var bgColor = '#E8E8E8';
								<?php if($iPumpVal == '1' || $iPumpVal == '2') { ?>
										bgColor = '#45A31F';
								<?php } else { ?>
										bgColor = '#E8E8E8';
								<?php } ?>
								
								$('#switch-me-<?php echo $i;?>-<?php echo $currentID;?>').switchy();
								
								$('.pump-<?php echo $i?>-<?php echo $currentID;?>').on('click', function(event){
									//event.preventDefault();
									//return false;
									$('#switch-me-<?php echo $i;?>-<?php echo $currentID;?>').val($(this).attr('value')).change();
								});
								
								$('#switch-me-<?php echo $i;?>-<?php echo $currentID;?>').next('.switchy-container').find('.switchy-bar').animate({
										backgroundColor: bgColor
									});
								
								$('#switch-me-<?php echo $i;?>-<?php echo $currentID;?>').on('change', function(event)
								{
									if(sAccess == 2)
									{
										if(iActiveMode != 2)
										{
											var bConfirm	=	confirm('You will need to change to Manual mode to make this change.\nWould you like to activate manual mode?' );
											if(bConfirm)
											{
												$.ajax({
													type: "POST",
													url: "<?php echo site_url('analog/changeMode');?>", 
													data: {iMode:'2'},
													success: function(data) {
													}
												});
												//event.preventDefault();
												//return false;
												// Animate Switchy Bar background color
												var bgColor = '#E8E8E8';

												if ($(this).val() == '1' || $(this).val() == '2')
												{
													bgColor = '#45A31F';
												} 
												$('#switch-me-<?php echo $i;?>-<?php echo $currentID;?>').next('.switchy-container').find('.switchy-bar').animate({
													backgroundColor: bgColor
												});
											
												
												//$("#loading_valve_<?php //echo $i;?>").css('visibility','visible');
												$.ajax({
													type: "POST",
													url: "<?php echo site_url('home/updateStatusOnOff');?>", 
													data: {sName:'<?php echo $i;?>',sStatus:$(this).val(),sDevice:'<?php echo $sDevice;?>',sIdIP:'<?php echo $currentID;?>'},
													success: function(data) {
													//$("#loading_valve_<?php //echo $i;?>").css('visibility','hidden');
													location.reload();
													}

												});
											}
										}
										else											
										{
											//event.preventDefault();
											//return false;
											// Animate Switchy Bar background color
											var bgColor = '#E8E8E8';

											if ($(this).val() == '1' || $(this).val() == '2')
											{
												bgColor = '#45A31F';
											} 
											$('#switch-me-<?php echo $i;?>-<?php echo $currentID;?>').next('.switchy-container').find('.switchy-bar').animate({
												backgroundColor: bgColor
											});
										
											
											//$("#loading_valve_<?php //echo $i;?>").css('visibility','visible');
											$.ajax({
												type: "POST",
												url: "<?php echo site_url('home/updateStatusOnOff');?>", 
												data: {sName:'<?php echo $i;?>',sStatus:$(this).val(),sDevice:'<?php echo $sDevice;?>',sIdIP:'<?php echo $currentID;?>'},
												success: function(data) {
												//$("#loading_valve_<?php //echo $i;?>").css('visibility','hidden');
												}

											});
										}
									}
								});
							});
					   </script>
					   
							<?php } else if($sPumpType != '') { ?>
							
							<?php if(preg_match('/Emulator/',$sPumpType)) { ?>
							<script>
							  $(document).ready(function() {
								setInterval( function() {
									$.getJSON('<?php echo site_url('cron/pumpResponseLatest/');?>', {iPumpID: "<?php echo $i;?>",sIpId:'<?php echo $currentID;?>'}, function(json) {
										
										if(json == '')
										{
											$("#lablePump-"+<?php echo $i;?>+"-"+<?php echo $currentID;?>).removeClass('checked');
											$("#pumpRealResponse_"+<?php echo $i;?>+"_"+<?php echo $currentID;?>).html('');
										}
										else
										{
											$("#pumpRealResponse_"+<?php echo $i;?>+"_"+<?php echo $currentID;?>).html(json);
											if($("#lablePump-"+<?php echo $i;?>+"-"+<?php echo $currentID;?>).hasClass('checked'))
											{}
											else
											{
												$("#lablePump-"+<?php echo $i;?>+"-"+<?php echo $currentID;?>).addClass('checked');
											}
										}
									});
									},30000);
							  });
							</script>										  
							   <?php } ?>
							<div class="rowCheckbox switch">
								<div class="custom-checkbox">
									<input type="checkbox" value="<?php echo $i."_".$currentID;?>" id="pumps_<?php echo $i?>_<?php echo $currentID;?>" name="pumps-<?php echo $i?>-<?php echo $currentID;?>" class="pumpsButton" hidefocus="true" style="outline: medium none;">
									<label style="margin-left: 60px;" <?php echo $strChecked;?>  id="lablePump-<?php echo $i?>-<?php echo $currentID;?>" for="pumps-<?php echo $i?>"><span style="float:right; color:#C9376E;"><?php echo $strPumpName;?></span></label>
								</div>
							</div>
								<?php if(preg_match('/Emulator/',$sPumpType)) { ?>
								<div id="pumpRealResponse_<?php echo $i;?>_<?php echo $currentID;?>" style="color: #164c87;font-weight: bold;"><?php if($iPumpVal > 0) { echo $strPumpsResponse		= $this->home_model->selectPumpsLatestResponse($i); }?></div>
								<?php } ?>
							<?php } ?>
							
							<div style="height:20px;">&nbsp;</div>
							<?php } ?>
						<?php 
							$chkPump++;
						}
						?>
					<?php } ?>
					<?php 
						$remainigCount	=	$iPumpsNumber - $chkPump;
						//for ($i=0;$i < $valve_count; $i++)	
						//for ($i=0;$i < $remainigCount ; $i++)
						foreach($arrPump as $i)	
						{
							if($remainigCount == 0)	
								break;
							
							$remainigCount--;
									
						//for ($i=0;$i < $pump_count; $i++)
						//{
							$iPumpVal = ${"sPump".$currentID}[$i];
							/* $iPumpNewValSb = 1;
							if($iPumpVal == 1)
							{
							  $iPumpNewValSb = 0;
							}
							$sPumpVal = false;
							if($iPumpVal)
							  $sPumpVal = true; */
							//$sRelayNameDb = get_device_name(1, $i);
						
							$sPumpNameDb =  $this->home_model->getDeviceName($i,$sDevice,$currentID);
							if($sPumpNameDb == '')
							  $sPumpNameDb = 'Add Name';
							
							//$iPower	 = $this->home_model->getDevicePower($i,$sDevice);
							
							//$sPowercenter = '01000000'		;
							//START : Getting assigned relay status from the Server.	
							//Details of Pump
							
							$sStatus2Speed	=	'';
							
							$aPumpDetails = $this->home_model->getPumpDetails($i,$currentID);
							$sPumpType		=	'';
							if(!empty($aPumpDetails))
							{
								foreach($aPumpDetails as $aResultEdit)
								{
									$sPumpType    = $aResultEdit->pump_type;//Pump Type
									$sPumpRelay   = $aResultEdit->relay_number;//Assigned Relay Number
									$sPumpRelay1   = $aResultEdit->relay_number_1;//Assigned Relay Number
									if($sPumpType == '12')
									{
										$iPumpVal = ${"sPowercenter".$currentID}[$sPumpRelay]; //Taken the status
									}
									else if($sPumpType == '24')
									{
										$iPumpVal = ${"sRelays".$currentID}[$sPumpRelay];//Taken the status
									}
									else if($sPumpType == '2Speed')
									{
										$sPumpSubType    = $aResultEdit->pump_sub_type;//Pump SUB Type
										$sStatus2Speed   = $aResultEdit->status;//Pump SUB Type
										
										
										if($sStatus2Speed == '0')
										{
											$iPumpVal        = $sStatus2Speed;
										}
										else if($sStatus2Speed == '1')											
										{
											if($sPumpSubType == '12')
											{
												$iPumpVal = ${"sPowercenter".$currentID}[$sPumpRelay]; //Taken the status
											}
											else if($sPumpSubType == '24')
											{
												$iPumpVal = ${"sRelays".$currentID}[$sPumpRelay];//Taken the status
											}
										}
										else if($sStatus2Speed == '2')											
										{
											if($sPumpSubType == '12')
											{
												$iPumpVal = ${"sPowercenter".$currentID}[$sPumpRelay1]; //Taken the status
											}
											else if($sPumpSubType == '24')
											{
												$iPumpVal = ${"sRelays".$currentID}[$sPumpRelay1];//Taken the status
											}
										}
									}
									else if(preg_match('/Emulator/',$sPumpType))
									{
										 $iPumpVal = ${"sPump".$currentID}[$i];
									}
								}
							}	//END : Getting assigned relay status from the Server.
							$sPumpVal = false;
							if($iPumpVal)
							  $sPumpVal = true;
						  
							$sMainType	 = $this->home_model->getDeviceMainType($i,$sDevice,$currentID);
							
							$strChecked	=	'';
							if($iPumpVal > '1')
								$strChecked	=	'class="checked"';
							
							$strPumpName = 'Pump '.$i;
							if($sPumpNameDb != '' && $sPumpNameDb != 'Add Name')
								$strPumpName .= ' ('.$sPumpNameDb.')';
							
							if($sStatus2Speed == '')
								$sStatus2Speed = '0';
							
							if($sMainType == '1')
							{
								$spaPumpDeviceCnt++;
					?>	
							
							<?php if($sPumpType == '2Speed') { ?>
							<script>
							var iActiveMode = '<?php echo $iActiveMode;?>';
							var sAccess 	= '<?php echo $sAccess;?>';
							</script>
							<link href="<?php echo site_url('assets/switchy/switchy.css'); ?>" rel="stylesheet" />
							<script type="text/javascript" src="<?php echo site_url('assets/switchy/switchy.js'); ?>"></script>
							<script type="text/javascript" src="<?php echo site_url('assets/switchy/jquery.event.drag.js'); ?>"></script>
							<script type="text/javascript" src="<?php echo site_url('assets/switchy/jquery.animate-color.js'); ?>"></script>
							
							<div class="span1 pump-<?php echo $i?>-<?php echo $currentID;?>" value="1" style="margin-top: 10px; width: auto; color: #428BCA;font-weight: bold; cursor: pointer; float: left;">Relay 1</div>
							<div class="span2" style="margin-left:5px; margin-right:5px; float: left;" >
							<select id='switch-me-<?php echo $i;?>-<?php echo $currentID;?>'>
							<option value='1' <?php if($sStatus2Speed == '1') { echo 'selected="selected"';} ?>>Spa</option>
							<option value='0' <?php if($sStatus2Speed == '0' || $iPumpVal == '') { echo 'selected="selected"';} ?>></option>
							<option value='2' <?php if($sStatus2Speed == '2') { echo 'selected="selected"';} ?>>Pool</option>
							</select>
							<div class="pump-<?php echo $i?>-<?php echo $currentID;?>" value="0" id="off-<?php echo $i;?>-<?php echo $currentID;?>" style="color: red;font-weight: bold;width: 0; margin-left: 30px; cursor: pointer;">
								OFF
	</div>                              </div>
							<div class="span1 pump-<?php echo $i?>-<?php echo $currentID;?>" value="2" style="margin-top: 10px; width: auto; color: #428BCA;font-weight: bold; cursor: pointer; float: left;">Relay 2</div>
							<div style="margin-top:10px; float:right; color:#C9376E;"><strong><?php echo $strPumpName;?></strong></div>
						  <script type="text/javascript">
						  
						  $(function()
						  {
							  var bgColor = '#E8E8E8';
								<?php if($iPumpVal == '1' || $iPumpVal == '2') { ?>
										bgColor = '#45A31F';
								<?php } else { ?>
										bgColor = '#E8E8E8';
								<?php } ?>
								
								$('#switch-me-<?php echo $i;?>-<?php echo $currentID;?>').switchy();
								
								$('.pump-<?php echo $i?>-<?php echo $currentID;?>').on('click', function(event){
									//event.preventDefault();
									//return false;
									$('#switch-me-<?php echo $i;?>-<?php echo $currentID;?>').val($(this).attr('value')).change();
								});
								
								$('#switch-me-<?php echo $i;?>-<?php echo $currentID;?>').next('.switchy-container').find('.switchy-bar').animate({
										backgroundColor: bgColor
									});
								
								$('#switch-me-<?php echo $i;?>-<?php echo $currentID;?>').on('change', function(event)
								{
									if(sAccess == 2)
									{
										if(iActiveMode != 2)
										{
											var bConfirm	=	confirm('You will need to change to Manual mode to make this change.\nWould you like to activate manual mode?' );
											if(bConfirm)
											{
												$.ajax({
													type: "POST",
													url: "<?php echo site_url('analog/changeMode');?>", 
													data: {iMode:'2'},
													success: function(data) {
													}
												});
												//event.preventDefault();
												//return false;
												// Animate Switchy Bar background color
												var bgColor = '#E8E8E8';

												if ($(this).val() == '1' || $(this).val() == '2')
												{
													bgColor = '#45A31F';
												} 
												$('#switch-me-<?php echo $i;?>-<?php echo $currentID;?>').next('.switchy-container').find('.switchy-bar').animate({
													backgroundColor: bgColor
												});
											
												
												//$("#loading_valve_<?php //echo $i;?>").css('visibility','visible');
												$.ajax({
													type: "POST",
													url: "<?php echo site_url('home/updateStatusOnOff');?>", 
													data: {sName:'<?php echo $i;?>',sStatus:$(this).val(),sDevice:'<?php echo $sDevice;?>',sIdIP:'<?php echo $currentID;?>'},
													success: function(data) {
													//$("#loading_valve_<?php //echo $i;?>").css('visibility','hidden');
													location.reload();
													}

												});
											}
										}
										else											
										{
											//event.preventDefault();
											//return false;
											// Animate Switchy Bar background color
											var bgColor = '#E8E8E8';

											if ($(this).val() == '1' || $(this).val() == '2')
											{
												bgColor = '#45A31F';
											} 
											$('#switch-me-<?php echo $i;?>-<?php echo $currentID;?>').next('.switchy-container').find('.switchy-bar').animate({
												backgroundColor: bgColor
											});
										
											
											//$("#loading_valve_<?php //echo $i;?>").css('visibility','visible');
											$.ajax({
												type: "POST",
												url: "<?php echo site_url('home/updateStatusOnOff');?>", 
												data: {sName:'<?php echo $i;?>',sStatus:$(this).val(),sDevice:'<?php echo $sDevice;?>',sIdIP:'<?php echo $currentID;?>'},
												success: function(data) {
												//$("#loading_valve_<?php //echo $i;?>").css('visibility','hidden');
												}

											});
										}
									}
								});
							});
					   </script>
					   
							<?php } else if($sPumpType != '') { ?>
							 <div class="rowCheckbox switch">
								<div class="custom-checkbox">
								<input type="checkbox" value="<?php echo $i."_".$currentID;?>" id="pumps_<?php echo $i?>_<?php echo $currentID;?>" name="pumps-<?php echo $i?>-<?php echo $currentID;?>" class="pumpsButton" hidefocus="true" style="outline: medium none;">
									<label style="margin-left: 60px;" <?php echo $strChecked;?>  id="lablePump-<?php echo $i?>-<?php echo $currentID;?>" for="pumps_<?php echo $i?>_<?php echo $currentID;?>"><span style="color:#C9376E;float:right;" ><?php echo $strPumpName;?></span></label>
								</div>
							</div>
							
							<?php } else if($sPumpType == '') { ?>
							<span style="color:#E94180;"><strong>Pump <?php echo $i; ?> not configured.</strong></span>
							<?php } ?>
							
							<div style="height:20px;">&nbsp;</div>
							<?php } ?>
						<?php } ?>
				<?php } ?>
			<hr />	
			</div>
			
		<?php }
			} ?> <!-- END : Pump Device -->
			
			<?php
			
				$sDevice            = 'L' 	;
				$sDeviceFullName 	= 'Light';
				if($currentID == 1)
				$numLight			= $extra['LightNumber'];
				else
				$numLight			= $extra['LightNumber2'];
				
				$sModule	        = 16;
				$sAccessKey	= 'access_'.$sModule;
					  
				if(!empty($aModules))
				{
					if(in_array($sModule,$aModules->ids))
					{
					 $sAccess 		= $aModules->$sAccessKey;
					}
					else if(!in_array($sModule,$aModules->ids)) 
					{
						$sAccess 		= '0'; 
					}
				}
			  
				if($sAccess == '')
					$sAccess = '2' ; 
			  
				if($sAccess == '0') {redirect(site_url('home/'));} 
			
			?>
				<?php if(($sAccess == 1 || $sAccess == 2) && $numLight > 0) { ?>
				<div class="stats-content-right" style="width:96% !important; margin-left:5px; margin-right:5px; float:none; margin-top:10px;">
				<div class="deviceTitle">Lights</div>
				<?php
					$spaLightDeviceCnt	=	0;
					for ($i=0;$i<$numLight; $i++)
					{	
						$strLightName	=   'Light '.$i;
															
							$sRelayType     =   '';
							$sRelayNumber   =   '';
							$strLight	=   'light_off.png';
							
							$aLightDetails  =   $this->home_model->getLightDeviceDetails($i,$currentID);
							if(!empty($aLightDetails))
							{
								foreach($aLightDetails as $aLight)
								{
									$sLightStatus	=	'';
									$sRelayDetails  =   unserialize($aLight->light_relay_number);
									
									$sRelayType     =   $sRelayDetails['sRelayType'];
									$sRelayNumber   =   $sRelayDetails['sRelayNumber'];
									
									if($sRelayType == '24')
									{
										$sLightStatus   =   ${"sRelays".$currentID}[$sRelayNumber];
									}
									if($sRelayType == '12')
									{
										$sLightStatus   =   ${"sPowercenter".$currentID}[$sRelayNumber];
									}
									
									
								}
							}
							
							$sMainType	 = $this->home_model->getDeviceMainType($i,$sDevice,$currentID);
							
							$strCheckedLight	=	'';
							if($sLightStatus)
								$strCheckedLight	=	'class="checked"';
							
							if($sMainType == '1')
							{
								$spaLightDeviceCnt++;
							if($sRelayNumber != '')
							{
								
				?>
				<div class="rowCheckbox switch">
					<div class="custom-checkbox" style="margin-right:10px; margin-top:20px;">
					<input type="checkbox" value="<?php echo $i.'|||'.$sRelayType.'|||'.$sRelayNumber.'|||'.$currentID;?>" id="relayLight_<?php echo $i?>_<?php echo $currentID;?>" name="relayLight-<?php echo $i?>-<?php echo $currentID; ?>" class="lightButton" hidefocus="true" style="outline: medium none;">
						<label style="margin-left:60px;" <?php echo $strCheckedLight;?>  id="lableRelayLight-<?php echo $i?>-<?php echo $currentID;?>" for="relayLight_<?php echo $i?>_<?php echo $currentID;?>"><span style="color:#C9376E; float:right;"><?php echo $strLightName;?></span></label>
					</div>
				</div>
				<?php } ?>
				<?php echo '<div style="height:30px;">&nbsp;</div>';} ?>
				<?php 			
					 }
				?> 
					</div>
				<?php } ?>	
				</div>
			</div>
		</div>
		<?php }
			}
		?>		
	</div>  
<p><a class="fancybox" id="checkLink" href="#inline1" style="display:none;">&nbsp;</a>
<div id="inline1" style="width:250px;height:40px; display:none;"><div class="loading-progress"></div></div></p>

<input type="hidden" id="IpId" value="<?php echo $iFirstIPId;?>">