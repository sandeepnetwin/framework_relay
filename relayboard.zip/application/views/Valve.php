<!-- START : VALVES -->
<?php //$iValveNumber = $extra['ValveNumber'];?> 	
<link href="<?php echo site_url('assets/switchy/switchy.css'); ?>" rel="stylesheet" />
<script type="text/javascript" src="<?php echo site_url('assets/switchy/switchy.js'); ?>"></script>
<script type="text/javascript" src="<?php echo site_url('assets/switchy/jquery.event.drag.js'); ?>"></script>
<script type="text/javascript" src="<?php echo site_url('assets/switchy/jquery.animate-color.js'); ?>"></script>

<script>
	var iActiveMode = '<?php echo $iActiveMode;?>';
	var sAccess 	= '<?php echo $sAccess;?>';
</script>

<div class="row">
	<?php
		if(!empty($aIPDetails))
		{
			foreach($aIPDetails as $aIP)
			{
				if($aIP->id <= 1)
					$iValveNumber = $extra['ValveNumber'];
			    else if($aIP->id > 1)
					$iValveNumber = $extra['ValveNumber2'];
				
	?>
	<div class="col-sm-4" id="onoffbuttons_<?php echo $aIP->id;?>" style="display:<?php if($aIP->id != $iFirstIPId){ echo 'none';} ?>">
		<div class="widget-container widget-stats boxed green-line">
		<div class="widget-title">
			<a href="<?php echo base_url('home/setting/'.$sDevice.'/');?>" class="link-refresh" id="link-refresh-1"><span class="glyphicon glyphicon-refresh"></span></a>
			<h3>ON/OFF</h3>
		</div>
		<div class="stats-content clearfix">
			<div class="stats-content-right" style="width:96% !important; margin-left:5px; margin-right:5px; margin-top:10px; float:none;">
			<?php
				if( $iValveNumber == 0 || $iValveNumber == '' )
				{ ?>
					<tr>
						<td>
							<span style="color:red">Please add number of Vavles in the <a href="<?php echo base_url('home/setting/');?>">Settings</a> Page!</span>
						</td>
					</tr>
				<?php 
				}
				else
				{
					//START : Valve Device 
					$arrValve	=	array(0,1,2,3,4,5,6,7);
					$j=0;
					$remainigCount	=	0;
					$chkValve		=	0;
					
					if(!empty(${"ValveRelays".$aIP->id}))
					{
						foreach(${"ValveRelays".$aIP->id} as $valve)
						{
							$i = $valve->device_number;
							$j = $i *2;
							
							unset($arrValve[$i]);
							
							$iValvesVal = ${"sValves".$aIP->id}[$i];
							$iValvesNewValSb1 = 1;
							$iValvesNewValSb2 = 2 ;
							if($iValvesVal == 1)
							{
							  $iValvesNewValSb1 = 0;
							}
							if($iValvesVal == 2)
							{
							  $iValvesNewValSb2 = 1;
							}
							$sValvesVal1 = false;
							$sValvesVal2 = false;
							if($iValvesVal == 1)
							  $sValvesVal1 = true;
							if($iValvesVal == 2)
							  $sValvesVal2 = true;
							//$sValvesNameDb = get_device_name(3, $i);

							$sValvesNameDb =  $this->home_model->getDeviceName($i,$sDevice,$aIP->id);
							if($sValvesNameDb == '')
							  $sValvesNameDb = 'Add Name';
							
							//START : Get Valve Position Details.
							$aPositionName   =  $this->home_model->getPositionName($i,$sDevice,$aIP->id);
							
							$strPosition1 = '';
							$strPosition2 = '';
							
							if($aPositionName[0] != '')
							$strPosition1	 =	$this->home_model->getPositionNameFromID($aPositionName[0]);
							if($aPositionName[1] != '')
							$strPosition2	 =	$this->home_model->getPositionNameFromID($aPositionName[1]);
							//END : Get Valve Position Details.
							
							$aRelayNumber    =  json_decode($this->home_model->getValveRelayNumber($i,$sDevice,$aIP->id));
							$sMainType	     =  $this->home_model->getDeviceMainType($i,$sDevice,$aIP->id);
							
							//echo 'iValvesVal : '.$iValvesVal;
							
							if($iValvesVal == '.' || $iValvesVal == '')
								continue;
							
							if($iValvesVal != '' && $iValvesVal != '.' && !empty($aRelayNumber)) 
							{
						?>
							<div class="row">
							<div class="col-sm-12">
							<div class="span1 valve-<?php echo $i?>-<?php echo $aIP->id;?>" value="1" style="margin-top: 10px; width: auto; color: #428BCA;font-weight: bold; cursor: pointer; float: left;"><?php echo $strPosition1; ?></div>
							<div class="span2" style="margin-left:5px; margin-right:5px; float: left;" >
							<select id='switch-me-<?php echo $i;?>-<?php echo $aIP->id;?>'>
							<option value='1' <?php if($iValvesVal == '1') { echo 'selected="selected"';} ?>>Spa</option>
							<option value='0' <?php if($iValvesVal == '0' || $iValvesVal == '') { echo 'selected="selected"';} ?>></option>
							<option value='2' <?php if($iValvesVal == '2') { echo 'selected="selected"';} ?>>Pool</option>
							</select>
							<div class="valve-<?php echo $i?>-<?php echo $aIP->id;?>" value="0" id="off-<?php echo $i;?>-<?php echo $aIP->id;?>" style="color: red;font-weight: bold;width: 0; margin-left: 30px; cursor: pointer;">
								OFF
							</div></div>
							<div class="span1 valve-<?php echo $i?>-<?php echo $aIP->id;?>" value="2" style="margin-top: 10px; width: auto; color: #428BCA;font-weight: bold; cursor: pointer; float: left;"><?php echo $strPosition2; ?></div>
							<div style="float: right;margin-right: 10px;margin-top: 10px;"><strong><span style="color:#C9376E;"><?php echo 'Valve '.$i; ?></span></strong></div>
							<script type="text/javascript">
							  $(function()
							  {
									var bgColor = '#E8E8E8';
									<?php if($iValvesVal == '1' || $iValvesVal == '2') { ?>
											bgColor = '#45A31F';
									<?php } else { ?>
											bgColor = '#E8E8E8';
									<?php } ?>
									
									$('#switch-me-<?php echo $i;?>-<?php echo $aIP->id;?>').switchy();
									
									$('.valve-<?php echo $i?>-<?php echo $aIP->id;?>').on('click', function(event){
										
										$('#switch-me-<?php echo $i;?>-<?php echo $aIP->id;?>').val($(this).attr('value')).change();
									});
									
									$('#switch-me-<?php echo $i;?>-<?php echo $aIP->id;?>').next('.switchy-container').find('.switchy-bar').animate({
											backgroundColor: bgColor
										});
									
									$('#switch-me-<?php echo $i;?>-<?php echo $aIP->id;?>').on('change', function(event)
									{
										if(sAccess == 2)
										{
											if(iActiveMode != 2)
											{
												var bConfirm	=	confirm('You will need to change to Manual mode to make this change.\nWould you like to activate manual mode?' );
												if(bConfirm)
												{
													$.ajax({
														type: "POST",
														url: "<?php echo site_url('analog/changeMode');?>", 
														data: {iMode:'2'},
														success: function(data) {
														}
													});
													//event.preventDefault();
													//return false;
													// Animate Switchy Bar background color
													var bgColor = '#E8E8E8';

													if ($(this).val() == '1' || $(this).val() == '2')
													{
														bgColor = '#45A31F';
													} 
													$('#switch-me-<?php echo $i;?>-<?php echo $aIP->id;?>').next('.switchy-container').find('.switchy-bar').animate({
														backgroundColor: bgColor
													});
												
													
													//$("#loading_valve_<?php //echo $i;?>").css('visibility','visible');
													$.ajax({
														type: "POST",
														url: "<?php echo site_url('home/updateStatusOnOff');?>", 
														data: {sName:'<?php echo $i;?>',sStatus:$(this).val(),sDevice:'<?php echo $sDevice;?>',sIdIP:'<?php echo $aIP->id;?>'},
														success: function(data) {
														//$("#loading_valve_<?php //echo $i;?>").css('visibility','hidden');
														location.reload();
														}

													});
												}
											}
											else
											{
												//event.preventDefault();
												//return false;
												// Animate Switchy Bar background color
												var bgColor = '#E8E8E8';

												if ($(this).val() == '1' || $(this).val() == '2')
												{
													bgColor = '#45A31F';
												} 
												$('#switch-me-<?php echo $i;?>-<?php echo $aIP->id;?>').next('.switchy-container').find('.switchy-bar').animate({
													backgroundColor: bgColor
												});
											
												
												//$("#loading_valve_<?php //echo $i;?>").css('visibility','visible');
												$.ajax({
													type: "POST",
													url: "<?php echo site_url('home/updateStatusOnOff');?>", 
													data: {sName:'<?php echo $i;?>',sStatus:$(this).val(),sDevice:'<?php echo $sDevice;?>',sIdIP:'<?php echo $aIP->id;?>'},
													success: function(data) {
													//$("#loading_valve_<?php //echo $i;?>").css('visibility','hidden');
													}

												});
											}
										}
									});
								});
						   </script>
						  </div>
						</div>
						<div style="height:10px;">&nbsp;</div>
				<?php 	}
						else
						{
							echo '<div class="row"><div class="col-sm-12"><div class="tagcloud clearfix"><span style="color:#FF0000;">Relay Not Assigned</span><div style="float: right;margin-right: 10px;color:#C9376E"><strong>Valve '.$i.'</strong></div></div></div></div><div style="height:10px;">&nbsp;</div>';
						}
						
							$chkValve++;
						}		
					}
					$remainigCount	=	$iValveNumber - $chkValve;
					//for ($i=0;$i < $valve_count; $i++)	
					//for ($i=0;$i < $remainigCount ; $i++)
					foreach($arrValve as $i)	
					{
						if($remainigCount == 0)	
							break;
						
						$remainigCount--;
						
						$j = $i * 2;
						
						$iValvesVal = ${"sValves".$aIP->id}[$i];
						$iValvesNewValSb1 = 1;
						$iValvesNewValSb2 = 2 ;
						if($iValvesVal == 1)
						{
						  $iValvesNewValSb1 = 0;
						}
						if($iValvesVal == 2)
						{
						  $iValvesNewValSb2 = 1;
						}
						$sValvesVal1 = false;
						$sValvesVal2 = false;
						if($iValvesVal == 1)
						  $sValvesVal1 = true;
						if($iValvesVal == 2)
						  $sValvesVal2 = true;
						//$sValvesNameDb = get_device_name(3, $i);

						$sValvesNameDb =  $this->home_model->getDeviceName($i,$sDevice,$aIP->id);
						
						//START : Get Valve Position Details.
						$aPositionName   =  $this->home_model->getPositionName($i,$sDevice,$aIP->id);
						
						$strPosition1 = '';
						$strPosition2 = '';
						
						if($aPositionName[0] != '')
						$strPosition1	 =	$this->home_model->getPositionNameFromID($aPositionName[0]);
						if($aPositionName[1] != '')
						$strPosition2	 =	$this->home_model->getPositionNameFromID($aPositionName[1]);
						//END : Get Valve Position Details.
					
						
						$aRelayNumber    =  json_decode($this->home_model->getValveRelayNumber($i,$sDevice,$aIP->id));
						$iPower	 	     =  $this->home_model->getDevicePower($i,$sDevice);
						$sMainType	     =  $this->home_model->getDeviceMainType($i,$sDevice,$aIP->id);
						
						//echo 'iValvesVal : '.$iValvesVal;
						
					if($iValvesVal != '' && $iValvesVal != '.' && !empty($aRelayNumber)) 
					{
					?>
						<div class="row">
						<div class="col-sm-12">
						
						<div class="span1 valve-<?php echo $i?>-<?php echo $aIP->id;?>" value="1" style="margin-top: 10px; width: auto; color: #428BCA;font-weight: bold; cursor: pointer; float: left;"><?php  echo $strPosition1; ?></div>
						
						<div class="span2" style="margin-left:5px; margin-right:5px; float: left;" >
							<select id='switch-me-<?php echo $i;?>-<?php echo $aIP->id;?>'>
							<option value='1' <?php if($iValvesVal == '1') { echo 'selected="selected"';} ?>>Spa</option>
							<option value='0' <?php if($iValvesVal == '0' || $iValvesVal == '') { echo 'selected="selected"';} ?>></option>
							<option value='2' <?php if($iValvesVal == '2') { echo 'selected="selected"';} ?>>Pool</option>
							</select>
							<div class="valve-<?php echo $i?>-<?php echo $aIP->id;?>" value="0" id="off-<?php echo $i;?>-<?php echo $aIP->id;?>" style="color: red;font-weight: bold;width: 0; margin-left: 30px; cursor: pointer;">
								OFF
							</div>
						</div>
						<div class="span1 valve-<?php echo $i?>-<?php echo $aIP->id;?>" value="2" style="margin-top: 10px; width: auto; color: #428BCA;font-weight: bold; cursor: pointer; float: left;"><?php  echo $strPosition2; ?></div>
						<div style="float: right;margin-right: 10px;margin-top: 10px;"><strong><span style="color:#C9376E;"><?php echo 'Valve '.$i; ?></span></strong></div>
						<script type="text/javascript">
						  $(function()
						  {
								var bgColor = '#E8E8E8';
								<?php if($iValvesVal == '1' || $iValvesVal == '2') { ?>
										bgColor = '#45A31F';
								<?php } else { ?>
										bgColor = '#E8E8E8';
								<?php } ?>
								
								$('#switch-me-<?php echo $i;?>-<?php echo $aIP->id;?>').switchy();
								
								$('.valve-<?php echo $i?>-<?php echo $aIP->id;?>').on('click', function(event){
									
									$('#switch-me-<?php echo $i;?>-<?php echo $aIP->id;?>').val($(this).attr('value')).change();
								});
								
								$('#switch-me-<?php echo $i;?>-<?php echo $aIP->id;?>').next('.switchy-container').find('.switchy-bar').animate({
										backgroundColor: bgColor
									});
								
								$('#switch-me-<?php echo $i;?>-<?php echo $aIP->id;?>').on('change', function(event)
								{
									if(sAccess == 2)
									{
										if(iActiveMode != 2)
										{
											var bConfirm	=	confirm('You will need to change to Manual mode to make this change.\nWould you like to activate manual mode?' );
											if(bConfirm)
											{
												$.ajax({
													type: "POST",
													url: "<?php echo site_url('analog/changeMode');?>", 
													data: {iMode:'2'},
													success: function(data) {
													}
												});
												//event.preventDefault();
												//return false;
												// Animate Switchy Bar background color
												var bgColor = '#E8E8E8';

												if ($(this).val() == '1' || $(this).val() == '2')
												{
													bgColor = '#45A31F';
												} 
												$('#switch-me-<?php echo $i;?>-<?php echo $aIP->id;?>').next('.switchy-container').find('.switchy-bar').animate({
													backgroundColor: bgColor
												});
											
												
												//$("#loading_valve_<?php //echo $i;?>").css('visibility','visible');
												$.ajax({
													type: "POST",
													url: "<?php echo site_url('home/updateStatusOnOff');?>", 
													data: {sName:'<?php echo $i;?>',sStatus:$(this).val(),sDevice:'<?php echo $sDevice;?>',sIdIP:'<?php echo $aIP->id;?>'},
													success: function(data) {
													//$("#loading_valve_<?php //echo $i;?>").css('visibility','hidden');
													location.reload();
													}

												});
											}
										}
										else
										{
											//event.preventDefault();
											//return false;
											// Animate Switchy Bar background color
											var bgColor = '#E8E8E8';

											if ($(this).val() == '1' || $(this).val() == '2')
											{
												bgColor = '#45A31F';
											} 
											$('#switch-me-<?php echo $i;?>-<?php echo $aIP->id;?>').next('.switchy-container').find('.switchy-bar').animate({
												backgroundColor: bgColor
											});
										
											
											//$("#loading_valve_<?php //echo $i;?>").css('visibility','visible');
											$.ajax({
												type: "POST",
												url: "<?php echo site_url('home/updateStatusOnOff');?>", 
												data: {sName:'<?php echo $i;?>',sStatus:$(this).val(),sDevice:'<?php echo $sDevice;?>',sIdIP:'<?php echo $aIP->id;?>'},
												success: function(data) {
												//$("#loading_valve_<?php //echo $i;?>").css('visibility','hidden');
												}

											});
										}
									}
								});
							});
						</script> 
					</div>
					</div>
					<div style="height:10px;">&nbsp;</div>
				<?php }	
						else
						{
							echo '<div class="row"><div class="col-sm-12"><div class="tagcloud clearfix"><span style="color:#FF0000;">Relay Not Assigned.</span><div style="float: right;margin-right: 10px; color:#C9376E"><strong>Valve '.$i.'</strong></div></div></div></div><div style="height:10px;">&nbsp;</div>';
						}
					}
				}
				?>
			</div>
		</div>
		</div>
	</div>
	<div class="col-sm-8" id="relayConfigure_<?php echo $aIP->id;?>" style="display:<?php if($aIP->id != $iFirstIPId){ echo 'none';} ?>">
	<div class="widget-container widget-stats boxed green-line">
		<div class="widget-title">
			<a href="<?php echo base_url('home/setting/'.$sDevice.'/');?>" class="link-refresh" id="link-refresh-1"><span class="glyphicon glyphicon-refresh"></span></a>
			<h3>Valve Settings</h3>
		</div>
	<?php
		if( $iValveNumber == 0 || $iValveNumber == '' )
				{ ?>
					<div class="stats-content clearfix">
					<div class="stats-content-right" style="width:100% !important; margin-left:5px; margin-right:5px; float:none;">
							<span style="color:red">Please add number of Vavles in the <a href="<?php echo base_url('home/setting/');?>">Settings</a> Page!</span>
					</div>
					</div>
					
				<?php 
				}
				else
				{
				?>
				
					<div class="stats-content clearfix">
					<div class="stats-content-right" style="width:100% !important; margin-left:5px; margin-right:5px; float:none;">
				
				  <table class="table table-hover">
					<thead>
					  <tr>
						<th class="header" style="width:25%">Valve</th>
						<th class="header"  style="width:25%">Type</th>
						<th class="header"  style="width:50%">Action</th>
					  </tr>
					</thead>
					<tbody>
					<?php			
					$arrValve	=	array(0,1,2,3,4,5,6,7);
					$j=0;
					$remainigCount	=	0;
					$chkValve		=	0;
					
					if(!empty(${"ValveRelays".$aIP->id}))
					{
						foreach(${"ValveRelays".$aIP->id} as $valve)
						{
							$i = $valve->device_number;
							$j = $i *2;
							
							unset($arrValve[$i]);
							
							$iValvesVal = ${"sValves".$aIP->id}[$i];
							$iValvesNewValSb1 = 1;
							$iValvesNewValSb2 = 2 ;
							if($iValvesVal == 1)
							{
							  $iValvesNewValSb1 = 0;
							}
							if($iValvesVal == 2)
							{
							  $iValvesNewValSb2 = 1;
							}
							$sValvesVal1 = false;
							$sValvesVal2 = false;
							if($iValvesVal == 1)
							  $sValvesVal1 = true;
							if($iValvesVal == 2)
							  $sValvesVal2 = true;
							//$sValvesNameDb = get_device_name(3, $i);

							$sValvesNameDb =  $this->home_model->getDeviceName($i,$sDevice,$aIP->id);
							if($sValvesNameDb == '')
							  $sValvesNameDb = 'Add Name';
						  
							$aPositionName   =  $this->home_model->getPositionName($i,$sDevice,$aIP->id);
							$aRelayNumber    =  json_decode($this->home_model->getValveRelayNumber($i,$sDevice,$aIP->id));
							$sMainType	     =  $this->home_model->getDeviceMainType($i,$sDevice,$aIP->id);
							
						?>
							<tr class="">
							<td>Valve <?php echo $i;?><br />(<a href="<?php if($sAccess == 2) { echo site_url('home/deviceName/'.base64_encode($i).'/'.base64_encode($sDevice).'/'.base64_encode($aIP->id)); } else { echo 'javascript:void(0);';}?>" ><?php echo $sValvesNameDb;?></a>)</td>
							<td>
								<div class="rowRadio">
									<div class="custom-radio">
										
										<input class="valveRadio" type="radio" id="radio-other-<?php echo $i;?>-<?php echo $aIP->id;?>" value="0" name="<?php echo $i;?>_MainType" <?php if($sMainType == '0' || $sMainType == ''){ echo 'checked="checked"';}?> <?php if($sAccess == '1') { echo 'disabled="disabled"';}?> hidefocus="true" style="outline: medium none;">
										<label id="relay_other_<?php echo $i;?>_<?php echo $aIP->id;?>" for="radio-other-<?php echo $i;?>-<?php echo $aIP->id;?>" class="<?php if($sMainType == '0' || $sMainType == ''){ echo 'checked';}?>">Other</label>
								
										<input class="valveRadio" type="radio" id="radio-spa-<?php echo $i;?>-<?php echo $aIP->id;?>" name="<?php echo $i;?>_MainType" value="1" <?php if($sMainType == '1'){ echo 'checked="checked"';}?> <?php if($sAccess == '1') { echo 'disabled="disabled"';}?> hidefocus="true" style="outline: medium none;">
										<label id="relay_spa_<?php echo $i;?>_<?php echo $aIP->id;?>" for="radio-spa-<?php echo $i;?>-<?php echo $aIP->id;?>" class="<?php if($sMainType == '1'){ echo 'checked';}?>">Spa</label>
								
										<input class="valveRadio" type="radio" id="radio-pool-<?php echo $i;?>-<?php echo $aIP->id;?>" name="<?php echo $i;?>_MainType" value="2" <?php if($sMainType == '2'){ echo 'checked="checked"';}?> <?php if($sAccess == '1') { echo 'disabled="disabled"';}?> hidefocus="true" style="outline: medium none;">
										
										<label id="relay_pool_<?php echo $i;?>_<?php echo $aIP->id;?>" for="radio-pool-<?php echo $i;?>-<?php echo $aIP->id;?>" class="<?php if($sMainType == '2'){ echo 'checked';}?>">Pool</label>
									</div>
								</div>
							</td>
							<td>

							<a class="btn btn-green btn-small" style="width:120px" href="<?php if($sAccess == '2') { echo base_url('home/valveRelays/'.base64_encode($i).'/'.base64_encode($sDevice).'/'.base64_encode($aIP->id));} else { echo 'javascript:void(0);';}?>"><?php if(!empty($aRelayNumber)) { ?><span>Edit Relays</span><?php } else { ?><span>Assign Relays</span><?php } ?></a>
							
							<?php if(!empty($aRelayNumber)) { ?>
							<a class="btn btn-small" style="width:120px" href="javascript:void(0);" <?php if($sAccess == '2') { echo 'onclick="return RemoveValveRelays(\''.$i.'\',\''.$aIP->id.'\')"';} ?>><span>Remove Relays</span></a>
							<?php } ?>
							
							<!-- Position Button-->
							
							<!--<a class="btn btn-small" style="width:120px" href="<?php //if($sAccess == 2) { echo site_url('home/positionName/'.base64_encode($i).'/'.base64_encode($sDevice).'/'); } else { echo 'javascript:void(0);';}?>"><span>Edit Position</span></a>-->
							
							<!-- Position Button-->
							
							<!--<a class="btn btn-small btn-red" style="width:120px" href="<?php //if($sAccess == 2) { echo site_url('home/removeValve/'.base64_encode($i).'/'.base64_encode($sDevice).'/'); } else { echo 'javascript:void(0);';}?>"><span>Remove Valve</span></a>-->
							</td>
							</tr>
					<?php
							$chkValve++;
						} ?>
					<?php  } ?>	
				
				<?php
					$remainigCount	=	$iValveNumber - $chkValve;
					//for ($i=0;$i < $valve_count; $i++)	
					//for ($i=0;$i < $remainigCount ; $i++)
					foreach($arrValve as $i)	
					{
						if($remainigCount == 0)	
							break;
						
						$remainigCount--;
						
						$j = $i * 2;
						
						$iValvesVal = ${"sValves".$aIP->id}[$i];
						$iValvesNewValSb1 = 1;
						$iValvesNewValSb2 = 2 ;
						if($iValvesVal == 1)
						{
						  $iValvesNewValSb1 = 0;
						}
						if($iValvesVal == 2)
						{
						  $iValvesNewValSb2 = 1;
						}
						$sValvesVal1 = false;
						$sValvesVal2 = false;
						if($iValvesVal == 1)
						  $sValvesVal1 = true;
						if($iValvesVal == 2)
						  $sValvesVal2 = true;
						//$sValvesNameDb = get_device_name(3, $i);

						$sValvesNameDb =  $this->home_model->getDeviceName($i,$sDevice,$aIP->id);
						if($sValvesNameDb == '')
						  $sValvesNameDb = 'Add Name';
					  
						$aPositionName   =  $this->home_model->getPositionName($i,$sDevice,$aIP->id);
						$aRelayNumber    =  json_decode($this->home_model->getValveRelayNumber($i,$sDevice,$aIP->id));
						$iPower	 	     =  $this->home_model->getDevicePower($i,$sDevice);
						$sMainType	     =  $this->home_model->getDeviceMainType($i,$sDevice,$aIP->id);
				?>
						<tr class="">
							<td>Valve <?php echo $i;?><br />(<a href="<?php if($sAccess == 2) { echo site_url('home/deviceName/'.base64_encode($i).'/'.base64_encode($sDevice).'/'.base64_encode($aIP->id)); } else { echo 'javascript:void(0);';}?>" ><?php echo $sValvesNameDb;?></a>)</td>
							<td>
								<div class="rowRadio">
									<div class="custom-radio">
										
										<input class="valveRadio" type="radio" id="radio-other-<?php echo $i;?>-<?php echo $aIP->id;?>" value="0" name="<?php echo $i;?>_MainType" <?php if($sMainType == '0' || $sMainType == ''){ echo 'checked="checked"';}?> <?php if($sAccess == '1') { echo 'disabled="disabled"';}?> hidefocus="true" style="outline: medium none;">
										<label id="relay_other_<?php echo $i;?>_<?php echo $aIP->id;?>" for="radio-other-<?php echo $i;?>-<?php echo $aIP->id;?>" class="<?php if($sMainType == '0' || $sMainType == ''){ echo 'checked';}?>">Other</label>
										
										<input class="valveRadio" type="radio" id="radio-spa-<?php echo $i;?>-<?php echo $aIP->id;?>" name="<?php echo $i;?>_MainType" value="1" <?php if($sMainType == '1'){ echo 'checked="checked"';}?> <?php if($sAccess == '1') { echo 'disabled="disabled"';}?> hidefocus="true" style="outline: medium none;">
										<label id="relay_spa_<?php echo $i;?>_<?php echo $aIP->id;?>" for="radio-spa-<?php echo $i;?>-<?php echo $aIP->id;?>" class="<?php if($sMainType == '1'){ echo 'checked';}?>">Spa</label>
										
										<input class="valveRadio" type="radio" id="radio-pool-<?php echo $i;?>-<?php echo $aIP->id;?>" name="<?php echo $i;?>_MainType" value="2" <?php if($sMainType == '2'){ echo 'checked="checked"';}?> <?php if($sAccess == '1') { echo 'disabled="disabled"';}?> hidefocus="true" style="outline: medium none;">
										<label id="relay_pool_<?php echo $i;?>_<?php echo $aIP->id;?>" for="radio-pool-<?php echo $i;?>-<?php echo $aIP->id;?>" class="<?php if($sMainType == '2'){ echo 'checked';}?>">Pool</label>
									</div>
								</div>
							</td>
							<td>
							<a class="btn btn-green btn-small" style="width:120px" href="<?php if($sAccess == '2') { echo base_url('home/valveRelays/'.base64_encode($i).'/'.base64_encode($sDevice).'/'.base64_encode($aIP->id));} else { echo 'javascript:void(0);';}?>"><?php if(!empty($aRelayNumber)) { ?><span>Edit Relays</span><?php } else { ?><span>Assign Relays</span><?php } ?></a>
							<?php if(!empty($aRelayNumber)) { ?>
							&nbsp;&nbsp;<a class="btn btn-small" style="width:120px" href="javascript:void(0);" <?php if($sAccess == '2') { echo ' onclick="return RemoveValveRelays(\''.$i.'\',\''.$aIP->id.'\');"';}?>><span>Remove Relays</span></a>
							<?php } ?>
							<!-- Position Button-->
							
							<!-- <a class="btn btn-small" style="width:120px" href="<?php //if($sAccess == 2) { echo site_url('home/positionName/'.base64_encode($i).'/'.base64_encode($sDevice).'/'); } else { echo 'javascript:void(0);';}?>"><span>Edit Position</span></a> -->
							
							<!-- Position Button-->
							
							<a class="btn btn-small" style="width:120px" href="javascript:void(0);" <?php if($sAccess == '2') { echo ' onclick="removeValve(\''.$aIP->id.'\');"';}?> ><span>Remove Valve</span></a>
							</td>
							</tr>
					<?php	} ?>
						<tr><td colspan="3">
						<div class="buttons">
						<a class="btn btn-icon btn-icon-right btn-icon-go addMoreValve" id="addMoreValve-<?php echo $aIP->id;?>" href="javascript:void(0);" hidefocus="true" style="outline: medium none; padding:0px !important;"><span>Add More Valve</span></a>
						</div>
						<div id="moreValve-<?php echo $aIP->id;?>" style="display:none;">
							<input type="text" value="" id="moreValveCnt-<?php echo $aIP->id;?>" name="moreValveCnt-<?php echo $aIP->id;?>" hidefocus="true" style="outline: medium none; width: 45%; margin-top:1px; margin-right:10px;" placeholder="Add Number"><a class="btn btn-icon btn-green btn-icon-right btn-icon-checkout" href="javascript:void(0);" style="padding:0px !important;" hidefocus="true" onclick="saveValveCount('<?php echo $aIP->id;?>')"><span>Save</span></a>
						</div>
						</td></tr>
					</tbody>
					</table>
					</div>
				</div>
			</div>							
					
				<?php	
				}
				
				?>
	</div>
	<?php } 
		}
	?>	
</div>		
<!-- END : VALVE DEVICES-->