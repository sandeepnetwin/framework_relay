<?php
	//@session_start();
	if (!$this->session->userdata('is_admin_login')) //START : Check if user login or not.
	{
		redirect('dashboard/login/');
		die;
	}  //END : Check if user login or not. 
	
	//Get Permission Details
	if($this->userID == '')
	$this->userID = $this->session->userdata('id');

	if($this->aPermissions == '')
	{
		$this->aPermissions 	= json_decode(getPermissionOfModule($this->userID));
		$this->aModules 		= $this->aPermissions->sPermissionModule;	
		$this->aAllActiveModule     = $this->aPermissions->sActiveModule;
	}
	
	$strTitle = isset($Title) && $Title != '' ?  $Title :'Dashboard'  ; 

	$strSettingUrl	=	'href="'.base_url('home/setting/').'"';
	$strStatusUrl	=	'href="'.base_url('home/systemStatus/').'"';
	$strLogUrl		=	'href="'.base_url('home/getLogDetails/').'"';
	$strPoolSpaUrl	=	'href="'.base_url('home/PoolSpaSetting/').'"';
	$strModeUrl		=	'href="'.base_url('analog/changeMode/').'"';
	
	$strExcludeUrl	=	base_url('device/index');
	$strCustomProgramUrl	=	base_url('device/customProgram');
	
	$this->load->model('home_model');
	$iActiveMode	= $this->home_model->getActiveMode();
	$strActiveMode	=	'';
	if($iActiveMode == '1')
		$strActiveMode	=	'Pool Mode Auto';
	if($iActiveMode == '2')
		$strActiveMode	=	'Pool Mode Manual';
	if($iActiveMode == '3')
		$strActiveMode	=	'Time-Out Mode';
	
	if(!empty($aModules))
	{
		if(!in_array(12,$aModules->ids)) 
		{
			$strSettingUrl = 'href="javascript:void(0);" onClick="showRestrict();"'; 
		}
		if(!in_array(13,$aModules->ids)) 
		{
			$strStatusUrl = 'href="javascript:void(0);" onClick="showRestrict();"'; 
		}
		if(!in_array(15,$aModules->ids)) 
		{
			$strLogUrl = 'href="javascript:void(0);" onClick="showRestrict();"'; 
		}  
		if(!in_array(18,$aModules->ids)) 
		{
			$strPoolSpaUrl = 'href="javascript:void(0);" onClick="showRestrict();"'; 
		}
		if(!in_array(4,$aModules->ids)) 
		{
			$strModeUrl = 'href="javascript:void(0);" onClick="showRestrict();"'; 
		}						
	}

	$strRelayUrl	=	'href="'.base_url('home/setting/R/').'"';
	$strPowerUrl	=	'href="'.base_url('home/setting/P/').'"';
	$strValveUrl	=	'href="'.base_url('home/setting/V/').'"';
	$strPumpUrl		=	'href="'.base_url('home/setting/PS/').'"';
	$strTempUrl		=	'href="'.base_url('home/setting/T/').'"';

	if(!empty($aModules))
	{
		if(!in_array(3,$aModules->ids)) 
		{
			$strRelayUrl = 'href="javascript:void(0);" onClick="showRestrict();"'; 
		}
		if(!in_array(3,$aModules->ids)) 
		{
			$strPowerUrl = 'href="javascript:void(0);" onClick="showRestrict();"'; 
		}
		if(!in_array(8,$aModules->ids)) 
		{
			$strValveUrl = 'href="javascript:void(0);" onClick="showRestrict();"'; 
		}  
		if(!in_array(9,$aModules->ids)) 
		{
			$strPumpUrl = 'href="javascript:void(0);" onClick="showRestrict();"'; 
		}
		if(!in_array(10,$aModules->ids)) 
		{
			$strTempUrl = 'href="javascript:void(0);" onClick="showRestrict();"'; 
		}
		
	}

	$strLightUrl			=	'href="'.base_url('analog/showLight/').'"';
	$strHeaterUrl			=	'href="'.base_url('analog/showHeater/').'"';
	$strBlowerUrl			=	'href="'.base_url('analog/showBlower/').'"';
	$strMiscUrl			=	'href="'.base_url('analog/showMisc/').'"';


	if(!empty($aModules))
	{
		if(!in_array(16,$aModules->ids)) 
		{
			$strRelayUrl = 'href="javascript:void(0);" onClick="showRestrict();"'; 
		}
		if(!in_array(17,$aModules->ids)) 
		{
			$strPowerUrl = 'href="javascript:void(0);" onClick="showRestrict();"'; 
		}
		if(!in_array(19,$aModules->ids)) 
		{
			$strValveUrl = 'href="javascript:void(0);" onClick="showRestrict();"'; 
		}  
		if(!in_array(19,$aModules->ids)) 
		{
			$strMiscUrl = 'href="javascript:void(0);" onClick="showRestrict();"'; 
		}
	}

	$this->load->model('custom_model');
	$this->load->model('home_model');
	//Get All On Program and Details.
	$aAllOnPrograms = $this->home_model->getOnCustomProgram();	

?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">
	<!--<meta HTTP-EQUIV="CACHE-CONTROL" CONTENT="NO-CACHE, NO-STORE, must-revalidate">
	<meta HTTP-EQUIV="PRAGMA" CONTENT="NO-CACHE">
	<meta HTTP-EQUIV="EXPIRES" CONTENT=0>-->
	
	
	<link rel="shortcut icon" href="<?php echo HTTP_CSS_PATH; ?>favicon.png">
    <title>Relay Board <?php echo '- '.$strTitle;?></title>
   <!-- main JS libs -->
	<script src="<?php echo HTTP_JS_PATH; ?>libs/jquery-1.10.2.min.js"></script>
	<script src="<?php echo HTTP_JS_PATH; ?>libs/jquery-ui.min.js"></script>
	<script src="<?php echo HTTP_JS_PATH; ?>libs/bootstrap.min.js"></script>

	<!-- Style CSS -->
	<link href="<?php echo HTTP_CSS_PATH; ?>bootstrap.css" media="screen" rel="stylesheet">
	<link href="<?php echo HTTP_ASSETS_PATH; ?>style.css" media="screen" rel="stylesheet">

	<!-- General Scripts -->
	<script src="<?php echo HTTP_JS_PATH; ?>general.js"></script>
	<script src="<?php echo HTTP_JS_PATH; ?>common.js"></script>
	
	<!-- custom input -->
	<script src="<?php echo HTTP_JS_PATH; ?>jquery.customInput.js"></script>
  
	<link rel="stylesheet" href="<?php echo HTTP_CSS_PATH; ?>chosen.css">
	<script src="<?php echo HTTP_JS_PATH; ?>chosen.jquery.min.js" type="text/javascript"></script>
	<script type="text/javascript" src="<?php echo HTTP_JS_PATH; ?>jquery.powerful-placeholder.min.js"></script>
	
	<script>
		jQuery(document).ready(function($) {
			if($("[placeholder]").size() > 0) {
				$.Placeholder.init();
			}
			
			var pull 		= $('#pull');
				menu 		= $('nav ul');
				menuHeight	= menu.height();

			$(pull).on('click', function(e) {
				e.preventDefault();
				menu.slideToggle();
			});

			$(window).resize(function(){
        		var w = $(window).width();
        		if(w > 320 && menu.is(':hidden')) {
        			menu.removeAttr('style');
        		}
    		});
		});
		
		function showRestrict()
		{
			alert("You don't have access to this section!");
			//$("#checkLinkNew").trigger('click');
			return false;
		}
		
	</script>
	
	<link rel="stylesheet" type="text/css" href="<?php echo HTTP_ASSETS_PATH.'horizontalmenu/css/font-awesome.css'; ?>">
	<link rel="stylesheet" type="text/css" href="<?php echo HTTP_ASSETS_PATH.'horizontalmenu/css/menu.css'; ?>">
    <script type="text/javascript" src="<?php echo HTTP_ASSETS_PATH.'horizontalmenu/js/function.js'; ?>"></script>
	
	<link rel="stylesheet" type="text/css" href="<?php echo HTTP_ASSETS_PATH.'css/style_menu.css'; ?>">
	<link rel="stylesheet" type="text/css" href="<?php echo HTTP_ASSETS_PATH.'css/jquery.sidr.dark.css'; ?>">
	<script type="text/javascript" src="<?php echo HTTP_JS_PATH; ?>jquery.sidr.min.js"></script>
	
	<link href="<?php echo HTTP_ASSETS_PATH.'notification/notification.css';?>" media="screen" rel="stylesheet">
	<link href="<?php echo HTTP_ASSETS_PATH.'notification/jquery.countdownTimer.css';?>" media="screen" rel="stylesheet">
	<style>
	/* Remote Switch */
	
	@media (max-width:700px)
	{
		#notificationDiv
		{
			position: absolute !important; z-index: 999 !important; left: 60px !important; top: 4px !important;
		}
	}
	@media screen and (min-width:701px) and (max-width:766px)
	{
		#notificationDiv
		{
			position: absolute !important; z-index: 999 !important; left: 5px !important; top: 160px !important;
		}
	}
	@media screen and (min-width:767px) and (max-width:990px)
	{
		#notificationDiv
		{
			position: absolute !important; z-index: 999 !important; left: 5px !important; top: 2px !important;
		}
	}
	
	.bi-label::after
	{
		content:" Completed - ";
	}
	.bi-titleSpan
	{
		float:right !important;
	}
	
	.miniNoty {
	  position: fixed;
	  right: 0;
	  bottom: 0; 
	  /* top:5px;
	  left:10px; */
	  max-width: 50%;
	  min-width: 150px;
	  z-index: 101;
	  -webkit-transition: all 0.5s;
	  -moz-transition: all 0.5s;
	  -o-transition: all 0.5s;
	  transition: all 0.5s; }
	  .miniNoty_message {
		  font-size:16px;
		position: relative;
		right: 10px;
		opacity: 0;
		color: #fff;
		cursor: pointer;
		float: right;
		clear: both;
		padding: 0 10px;
		margin: 0;
		max-height: 0;
		border-radius: 5px;
		overflow: hidden;
		-ms-box-sizing: border-box;
		-moz-box-sizing: border-box;
		-webkit-box-sizing: border-box;
		box-sizing: border-box;
		-webkit-transform: scale(1, 0);
		-moz-transform: scale(1, 0);
		-o-transform: scale(1, 0);
		-ms-transform: scale(1, 0);
		transform: scale(1, 0);
		-webkit-transition: all 0.5s;
		-moz-transition: all 0.5s;
		-o-transition: all 0.5s;
		transition: all 0.5s; }
	  .miniNoty_message-show {
		  height:70px;
		margin: 0 0 10px;
		padding: 25px 10px;
		max-height: 500px;
		opacity: 1;
		-webkit-transform: scale(1, 1);
		-moz-transform: scale(1, 1);
		-o-transform: scale(1, 1);
		-ms-transform: scale(1, 1);
		transform: scale(1, 1); }
	  .miniNoty_message-remove {
		padding: 0;
		margin: 0;
		overflow: hidden; }
	  .miniNoty_message-success {
		background: mediumseagreen;
		box-shadow: 0 2px 5px mediumseagreen; }
	  .miniNoty_message-error {
		background: indianred;
		box-shadow: 0 2px 5px indianred; }
	  .miniNoty_message-normal {
		background: #fafafa;
		box-shadow: 0 2px 5px lightgrey;
		color: #000; }
		.miniNoty_message-normal .miniNoty_btn {
		  color: #000; }
	  .miniNoty_message-warning {
		background: goldenrod;
		box-shadow: 0 2px 5px goldenrod; }
	  .miniNoty_btn {
		display: inline-block;
		padding: 5px 7px;
		border-radius: 4px;
		color: #fff;
		margin: 5px 5px 0 0;
		text-decoration: none;
		border: 1px solid #eee;
		background: rgba(255, 255, 255, 0.3); }
		.miniNoty_btn:hover {
		  background: rgba(255, 255, 255, 0.5); }

	@media screen and (max-width: 480px) {
	  .miniNoty {
		max-width: 100%;
		width: 100%; }
		.miniNoty_message {
		  margin: 0 0 5px;
		  border-radius: 0;
		  text-align: center;
		  padding: 5px;
		  right: 0;
		  float: none; }
		  .miniNoty_message:last-child {
			margin: 0; }
		  .miniNoty_message-show {
			bottom: 5px; } }

	/*# sourceMappingURL=style.css.map */

	</style>
	<script src="<?php echo HTTP_JS_PATH; ?>jquery.countdown.js"></script>
	<script>
	jQuery(document).ready(function($) 
	{
		var today = new Date();
		
		$(window).load(function(){
		  $("#testNotification").trigger('click');
		});
		<?php //if($_SERVER['REMOTE_ADDR'] != '14.142.41.62') {?>
		 setInterval( function() {
			$.ajax({
					type: "POST",
					url: "<?php echo site_url('home/getCustomProgramProgress/');?>", 
					data: {},
					success: function(data) {
						var obj = jQuery.parseJSON( data );
						if (obj == undefined || obj == null || obj.length == 0)	
						{
							var items = Array();
							var template =
							'<div class="notifications js-notifications">' +
							'<h3>Notifications</h3>' +
							'<div class="row">' +
							'<div class="col-sm-12">' +
							'<ul class="notifications-list">' +
							'<li class="item no-data">You don\'t have notifications</li>' +
							'<li class="item js-item" data-id="'+i+'">' +
							'<div class="details" style="width:95%">' +
							'<span class="title">You don\'t have notifications</span>' +
							'<span class="date"><?php echo date('Y-m-d H:i:s'); ?></span>' +
							'</div>' +
							'</li>' +
							'</ul>' +
							'</div>' +
							'</div>' +
							'</div>';
							refreshNotifications(items, today, template);
							//$(".#notification_button").addClass('active');
							$("#notification_button").show();
							$(".js-notifications").toggle();
						}
						else
						{
							var template =
							'<div class="notifications js-notifications">' +
							'<h3>Notifications</h3>' +
							'<div class="row">' +
							'<div class="col-sm-12">' +
							'<ul class="notifications-list">' +
							'<li class="item no-data">You don\'t have notifications</li>';
							var items = Array();
							var i =1;
							$.each(obj, function(index,value){
								var objTemp = {};
								objTemp['id'] = i;
								objTemp['title'] = value.Name;
								objTemp['description'] = value.description;
								objTemp['date'] = '<?php echo date('Y-m-d H:i:s'); ?>';
								items.push(objTemp);
								
								var TimerText = '';
								var ProgramStatusText = '';
								
								if(value.After == 1)
								{
									ProgramStatusText = ' <span style="color: red;">( Turning OFF )</span>';
								}
								else if(value.After == 0)
								{
									TimerText = '<div style="height: 30px; border: 1px solid rgb(60, 179, 113); background-color: rgb(60, 179, 113); color: rgb(255, 255, 255); padding-left: 5px; line-height: 25px;">End Time: <span id="program_timer_'+i+'" class="countdown simple">'+value.Time+'</span><span id="timer_'+i+'" style="display:none;">'+value.Time+'</span></div>';
									ProgramStatusText = ' <span style="color: red;">( Running )</span>';
								}
								
								template +='<li class="item js-item" data-id="'+i+'">' +
								'<div class="details" style="width:95%">' +
								'<span class="title">'+value.Name+ProgramStatusText+TimerText+'</span>' +
								'<span class="title" style="color:#9CD70E;">Current On Devices</span>';
								var tableDetails = '<table class="table table-hover">'+
									'<thead>'+
									'<tr>'+
										'<th class="header">Device</th>'+
										'<th class="header">Start Time</th>'+
										'<th class="header">End Time</th>'+
									'</tr>'+
									'</thead>' +								
									'<tbody>';
									
								$.each(value.description, function(index1,value1){
									var arrDescription = value1.split('|||');
									
									tableDetails += '<tr><td>'+arrDescription[0]+'</td>'+
										'<td>'+arrDescription[1]+'</td>'+
										'<td>'+arrDescription[2]+'</td></tr>';
								});
								tableDetails += '</tbody></table>';
								template +='<span class="description">'+tableDetails+'</span>';
								if(value.After == 0)
								{
									template +='<span class="title" style="color:#9CD70E;">Next Sequence Devices</span>';
									
									var tableDetails = '<table class="table table-hover">'+
										'<thead>'+
										'<tr>'+
											'<th class="header">Device</th>'+
										'</tr>'+
										'</thead>' +								
										'<tbody>';
										
									$.each(value.nextdescription, function(index1,value1){
										tableDetails += '<tr><td>'+value1+'</td></tr>';
									});
									tableDetails += '</tbody></table>';
									template +='<span class="description">'+tableDetails+'</span>';
								}
								
								template +='<span class="date"><?php echo date('Y-m-d H:i:s'); ?></span>' +
								'</div>' +
								'</li>';
								i++;
								
							});
							template +='</ul>' +
							'</div>' +
							'</div>' +
							'</div>';
							
							refreshNotifications(items, today, template);
							
							//$(".#notification_button").addClass('active');
							$("#notification_button").show();
							$(".js-notifications").toggle();
							$.each(obj, function(index,value){
								 $('.countdown.simple').countdown({ date: value.Time });
							});
							/* for(var j=1; j<i; j++)
							{
								if($('#program_timer_'+j).length)
								{
									var arrTime = $("#timer_"+j).html().split(":");
									$('#program_timer_'+j).countdowntimer({
                                        hours : arrTime[0],
                                        minutes :arrTime[1],
                                        seconds : arrTime[2],
                                        size : "sm",
										borderColor : "#164C87"
									});
								}
							} */
						}
					}
			});
		
		},10000);
		<?php //} ?>		
		
		$("#testNotification").click(function() {
			$.ajax({
					type: "POST",
					url: "<?php echo site_url('home/getCustomProgramProgress/');?>", 
					data: {},
					success: function(data) {
						var obj = jQuery.parseJSON( data );
						if (obj == undefined || obj == null || obj.length == 0)	
						{
							var items = Array();
							var template =
							'<div class="notifications js-notifications">' +
							'<h3>Notifications</h3>' +
							'<div class="row">' +
							'<div class="col-sm-12">' +
							'<ul class="notifications-list">' +
							'<li class="item no-data">You don\'t have notifications</li>' +
							'<li class="item js-item" data-id="'+i+'">' +
							'<div class="details" style="width:95%">' +
							'<span class="title">You don\'t have notifications</span>' +
							'<span class="date"><?php echo date('Y-m-d H:i:s'); ?></span>' +
							'</div>' +
							'</li>' +
							'</ul>' +
							'</div>' +
							'</div>' +
							'</div>';
							refreshNotifications(items, today, template);
							//$(".#notification_button").addClass('active');
							$("#notification_button").show();
							$(".js-notifications").toggle();
						}
						else
						{
							var template =
							'<div class="notifications js-notifications">' +
							'<h3>Notifications</h3>' +
							'<div class="row">' +
							'<div class="col-sm-12">' +
							'<ul class="notifications-list">' +
							'<li class="item no-data">You don\'t have notifications</li>';
							var items = Array();
							var i =1;
							$.each(obj, function(index,value){
								var objTemp = {};
								objTemp['id'] = i;
								objTemp['title'] = value.Name;
								objTemp['description'] = value.description;
								objTemp['date'] = '<?php echo date('Y-m-d H:i:s'); ?>';
								items.push(objTemp);
								
								var TimerText = '';
								var ProgramStatusText = '';
								
								if(value.After == 1)
								{
									ProgramStatusText = ' <span style="color: red;">( Turning OFF )</span>';
								}
								else if(value.After == 0)
								{
									TimerText = '<div style="height: 30px; border: 1px solid rgb(60, 179, 113); background-color: rgb(60, 179, 113); color: rgb(255, 255, 255); padding-left: 5px; line-height: 25px;">End Time: <span id="program_timer_'+i+'" class="countdown simple">'+value.Time+'</span><span id="timer_'+i+'" style="display:none;">'+value.Time+'</span></div>';
									ProgramStatusText = ' <span style="color: red;">( Running )</span>';
								}
									
								
								
								template +='<li class="item js-item" data-id="'+i+'">' +
								'<div class="details" style="width:95%">' +
								'<span class="title">'+value.Name+ProgramStatusText+TimerText+'</span>' +
								'<span class="title" style="color:#9CD70E;">Current On Devices</span>';
								var tableDetails = '<table class="table table-hover">'+
									'<thead>'+
									'<tr>'+
										'<th class="header">Device</th>'+
										'<th class="header">Start Time</th>'+
										'<th class="header">End Time</th>'+
									'</tr>'+
									'</thead>' +								
									'<tbody>';
									
								$.each(value.description, function(index1,value1){
									var arrDescription = value1.split('|||');
									
									tableDetails += '<tr><td>'+arrDescription[0]+'</td>'+
										'<td>'+arrDescription[1]+'</td>'+
										'<td>'+arrDescription[2]+'</td></tr>';
								});
								tableDetails += '</tbody></table>';
								template +='<span class="description">'+tableDetails+'</span>';
								if(value.After == 0)
								{
									template +='<span class="title" style="color:#9CD70E;">Next Sequence Devices</span>';
									
									
									var tableDetails = '<table class="table table-hover">'+
										'<thead>'+
										'<tr>'+
											'<th class="header">Device</th>'+
										'</tr>'+
										'</thead>' +								
										'<tbody>';
									if(value.nextdescription)	
									{
										$.each(value.nextdescription, function(index1,value1){
											tableDetails += '<tr><td>'+value1+'</td></tr>';
										});
									}
									else
									{
										tableDetails += '<tr><td>No Next device available!</td></tr>';
									}
									
									tableDetails += '</tbody></table>';
									template +='<span class="description">'+tableDetails+'</span>';
								}
								
								template +='<span class="date"><?php echo date('Y-m-d H:i:s'); ?></span>' +
								'</div>' +
								'</li>';
								i++;
								
							});
							template +='</ul>' +
							'</div>' +
							'</div>' +
							'</div>';
							
							refreshNotifications(items, today, template);
							//$(".#notification_button").addClass('active');
							$("#notification_button").show();
							$(".js-notifications").toggle();
							
							$.each(obj, function(index,value){
								 $('.countdown.simple').countdown({ date: value.Time });
							});
							
							/* for(var j=1; j<i; j++)
							{
								
								if($('#program_timer_'+j).length)
								{
									console.log($("#timer_"+j).html());
									var arrTime = $("#timer_"+j).html().split(":");
									$('#program_timer_'+j).countdowntimer({
                                        hours : arrTime[0],
                                        minutes :arrTime[1],
                                        seconds : arrTime[2],
                                        size : "sm",
										borderColor : "#164C87"
									});
								}
							} */
						}
					}
			});
		});
		
		$("#notification_button").click(function() {
			if($('.js-notifications').length)
			{
				if(!$("#notification_button").hasClass('active'))
				{
					$(".js-show-notifications").addClass('active');	
				}
				$('.js-notifications').toggle();
			}
		}); 
		
		$('#existing-content-menu').sidr({
            name: 'main-menu-test',
            source: '#mod_menu',
	  //renaming :false,
	  onOpen :function() {
		  setTimeout(function(){ 
		  	$('[data-toggle="collapse"]').click(function(){
					hash = $(this).attr('href');
					$(hash).collapse('toggle');
				  
				  });
		  }, 3000);
	  }
	});
	
	if($(window).width() > 700)	{
		$.sidr('close', 'main-menu-test');
		$('.top_menu').hide();
		
	}
	if($(window).width() <= 700)	{
		$('.top_menu').show();
		$('.icon-reorder').hide();
	}
	
	$(window).resize(function(){
		if($(window).width() > 700)	{
			$.sidr('close', 'main-menu-test');
			$('.top_menu').hide();
			
		}
		if($(window).width() <= 700)	{
			$('.top_menu').show();
			$('.icon-reorder').hide();
		}
	});
	
	$('.sidr-class-nav .sidr-class-dropdown a').on('click', function(){
		//$(this).closest('li').toggleClass('open');
		if($(this).next('ul').length)
		{
			$(this).next('ul').slideToggle('fast');
			return false;
			
		}
	});
	});
	</script>
	
  </head>
<body>
<div class="miniNoty"><div class="miniNoty_message miniNoty_message-success miniNoty_message-show"><div class="miniNoty_text"><a style="color:#FFF;" <?php echo $strModeUrl;?>>Current Active Mode is <strong><span class="activeModeMini"><?php echo $strActiveMode;?></span></strong></a></div></div></div>

<div id="notificationDiv" style="position: fixed; z-index: 999; top: 70px; left: 5px;">
	<a href="javascript:void(0)" id="testNotification" style="display:none;">&nbsp;</a>
	<button type="button" id="notification_button" class="button-default show-notifications active js-show-notifications" >
		<img src="<?php echo HTTP_ASSETS_PATH.'notification/notification.png';?>" alt="notifications">
		<div class="notifications-count js-count"></div>
	</button>

	<script type="text/javascript" src="<?php echo HTTP_ASSETS_PATH.'notification/mustache.js';?>"></script>	
	<script type="text/javascript" src="<?php echo HTTP_ASSETS_PATH.'notification/notification.js';?>"></script>
	<script type="text/javascript" src="<?php echo HTTP_ASSETS_PATH.'notification/jquery.countdownTimer.js';?>"></script>
	</div>
    <?php
    $pg = isset($page) && $page != '' ?  $page :'home'  ;    
    ?>
	<a class="fancyboxNew" id="checkLinkNew" href="#inline1New" style="display:none;">&nbsp;</a>
		<div id="inline1New" style="width:250px;height:40px; display:none;"><div >You Don't have access to this section!</div></div>
	
    <div class="body-wrap">
	<div class="navbar top_menu" style="display:none;">  
		<div class="navbar-header">
			<button aria-controls="navbar" aria-expanded="false" class="navbar-toggle collapsed" type="button" id="existing-content-menu">
				<span class="sr-only">Toggle navigation</span>
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>
			</button>
		</div>
					 
		<div class="container" id="mod_menu">
			<div id="menu_bar">   
				<div class="container" style="color:#fff;">
					<div class="row">                        
						<div class="navbar-right">
							<ul class="nav navbar-nav">
								<li><a href="<?php echo base_url();?>">Home</a> 
								</li>
								<li class="dropdown"><a href="javascript:void(0);">Devices</a> 
									<ul>
										<li><a <?php echo $strRelayUrl;?>>24V AC Relays<i class="fa-angle-right"></i></a> </li>
										<li><a <?php echo $strPowerUrl;?>>12V DC Relays<i class="fa-angle-right"></i></a> </li>
										<li><a <?php echo $strTempUrl;?>>Temperature<i class="fa-angle-right"></i></a> </li>
										<li><a <?php echo $strValveUrl;?>>Valves</a> </li>
										<li><a <?php echo $strPumpUrl;?>>Pumps</a> </li>
										<li><a <?php echo $strBlowerUrl;?>>Blowers</a> </li>
										<li><a <?php echo $strHeaterUrl;?>>Heaters</a> </li>
										<li><a <?php echo $strLightUrl;?>>Lights</a> </li>
										<li><a <?php echo $strMiscUrl;?>>Miscelleneous</a> </li>
										<?php if($this->session->userdata('user_type') == 'SA') { ?>
										<li><a href="<?php echo $strExcludeUrl;?>">Exclude Device</a></li>
										<li><a href="<?php echo $strCustomProgramUrl;?>">Custom Programs</a></li>
										<?php } ?>
									</ul>
								</li>
								<li class="dropdown"><a href="javascript:void(0);">System</a> 
									<ul>
										<li><a <?php echo $strSettingUrl;?>><i class="glyphicon glyphicon-cog"></i>Basic Setting</a> </li>
										<li><a href="<?php echo base_url('home/PoolSpaSetting/');?>"><i class="glyphicon glyphicon-cog"></i>Advance Setting</a></li>
										<li><a <?php echo $strModeUrl;?>><i class="glyphicon glyphicon-sort"></i>Mode</a></li>
										<li><a <?php echo $strStatusUrl;?>><i class="glyphicon glyphicon-ok"></i>Status</a></li>
										<li><a <?php echo $strLogUrl;?>><i class="glyphicon glyphicon-folder-open"></i>Log</a></li>
										<?php if($this->session->userdata('user_type') == 'SA') { ?>
										<li><a href="<?php echo base_url('dashboard/position/');?>"><i class="glyphicon glyphicon-th"></i>Valve Positions</a></li>
										<li><a href="<?php echo base_url('importexport/index/');?>"><i class="glyphicon glyphicon-export"></i>Import/Export</a></li>
										<li><a href="<?php echo base_url('device/systemOperation');?>"><i class="glyphicon glyphicon-off"></i>System Operation</a></li>
										</li>
										<?php } ?>
									</ul>
								</li>
								<li class="dropdown"><a href="javascript:void(0);">User</a>
									<ul>
										<li><a href="<?php echo base_url('dashboard/logout'); ?>"><i class="glyphicon glyphicon-lock"></i>Logout</a></li>
										<?php if($this->session->userdata('user_type') == 'SA') { ?>
										<li><a href="<?php echo base_url('dashboard/users/');?>"><i class="glyphicon glyphicon-user"></i>Sub Users</a></li>
										<li><a href="<?php echo base_url('dashboard/module/');?>"><i class="glyphicon glyphicon-th-list"></i>Pages</a></li>
									<?php } ?>
									</ul>
								</li>
							</ul>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
    <div class="content">
	
        <!--container-->
        <div class="container">
			<?php 
								
				  $strSettingUrl	=	'href="'.base_url('home/setting/').'"';
				  $strStatusUrl		=	'href="'.base_url('home/systemStatus/').'"';
				  $strLogUrl		=	'href="'.base_url('home/getLogDetails/').'"';
				  $strPoolSpaUrl	=	'href="'.base_url('home/PoolSpaSetting/').'"';
				  $strModeUrl		=	'href="'.base_url('analog/changeMode/').'"';
				  
				  if(!empty($aModules))
				  {
						if(!in_array(12,$aModules->ids)) 
						{
							$strSettingUrl = 'href="javascript:void(0);" onClick="showRestrict();"'; 
						}
						if(!in_array(13,$aModules->ids)) 
						{
							$strStatusUrl = 'href="javascript:void(0);" onClick="showRestrict();"'; 
						}
						if(!in_array(15,$aModules->ids)) 
						{
							$strLogUrl = 'href="javascript:void(0);" onClick="showRestrict();"'; 
						}  
						if(!in_array(18,$aModules->ids)) 
						{
							$strPoolSpaUrl = 'href="javascript:void(0);" onClick="showRestrict();"'; 
						}
						if(!in_array(4,$aModules->ids)) 
						{
							$strModeUrl = 'href="javascript:void(0);" onClick="showRestrict();"'; 
						}						
				  }
				  
				  $strRelayUrl			=	'href="'.base_url('home/setting/R/').'"';
				  $strPowerUrl			=	'href="'.base_url('home/setting/P/').'"';
				  $strValveUrl			=	'href="'.base_url('home/setting/V/').'"';
				  $strPumpUrl			=	'href="'.base_url('home/setting/PS/').'"';
				  $strTempUrl			=	'href="'.base_url('home/setting/T/').'"';
				  
				  if(!empty($aModules))
				  {
						if(!in_array(3,$aModules->ids)) 
						{
							$strRelayUrl = 'href="javascript:void(0);" onClick="showRestrict();"'; 
						}
						if(!in_array(3,$aModules->ids)) 
						{
							$strPowerUrl = 'href="javascript:void(0);" onClick="showRestrict();"'; 
						}
						if(!in_array(8,$aModules->ids)) 
						{
							$strValveUrl = 'href="javascript:void(0);" onClick="showRestrict();"'; 
						}  
						if(!in_array(9,$aModules->ids)) 
						{
							$strPumpUrl = 'href="javascript:void(0);" onClick="showRestrict();"'; 
						}
						if(!in_array(10,$aModules->ids)) 
						{
							$strTempUrl = 'href="javascript:void(0);" onClick="showRestrict();"'; 
						}
						
				  }
				  
				  $strLightUrl			=	'href="'.base_url('analog/showLight/').'"';
				  $strHeaterUrl			=	'href="'.base_url('analog/showHeater/').'"';
				  $strBlowerUrl			=	'href="'.base_url('analog/showBlower/').'"';
				  $strMiscUrl			=	'href="'.base_url('analog/showMisc/').'"';
				  
				  
				  if(!empty($aModules))
				  {
						if(!in_array(16,$aModules->ids)) 
						{
							$strRelayUrl = 'href="javascript:void(0);" onClick="showRestrict();"'; 
						}
						if(!in_array(17,$aModules->ids)) 
						{
							$strPowerUrl = 'href="javascript:void(0);" onClick="showRestrict();"'; 
						}
						if(!in_array(19,$aModules->ids)) 
						{
							$strValveUrl = 'href="javascript:void(0);" onClick="showRestrict();"'; 
						}  
						if(!in_array(19,$aModules->ids)) 
						{
							$strMiscUrl = 'href="javascript:void(0);" onClick="showRestrict();"'; 
						}
				  }
				  
			?>
			<?php if(!isset($iframe) && $iframe != '1') {  ?>
			<div id="wrap">
				<header>
					<div class="innerMenu relative">
						<a style="color:#ffffff !important; text-decoration:none;" href="<?php echo base_url();?>" class="logo">
						<span style="font: italic bold 33px/40px Times New Roman">Crystal Properties</span>
						</a>
						<a id="menu-toggle" class="button dark" href="#"><i class="icon-reorder"></i></a>
						<nav id="navigation">
							<ul id="main-menu">
								<li <?php if($pg == 'home') {echo 'class="current-menu-item"';}?>><a href="<?php echo base_url();?>">Home</a></li>
								<!--<li class="parent">
									<a href="javascript:void(0);">Switches</a>
									<ul class="sub-menu">
										<li><a <?php echo $strRelayUrl;?>><i class="glyphicon glyphicon-flash"></i>24V AC Relays</a></li>
										<li><a <?php echo $strPowerUrl;?>><i class="glyphicon glyphicon-flash"></i>12V DC Relays</a></li>
										<li><a <?php echo $strTempUrl;?>><i class="glyphicon glyphicon-flash"></i>Temperature</a></li>
									</ul>
								</li>-->
								<li class="parent">
									<a href="javascript:void(0);">Devices</a>
									<ul class="sub-menu">
										<li class="parent">
											<a href="javascript:void(0);">Switches</a>
											<ul class="sub-menu">
												<li><a <?php echo $strRelayUrl;?>>24V AC Relays</a></li>
												<li><a <?php echo $strPowerUrl;?>>12V DC Relays</a></li>
											</ul>
										</li>
										<li><a <?php echo $strTempUrl;?>>Temperature</a></li>
										<li><a <?php echo $strValveUrl;?>>Valves</a></li>
										<li><a <?php echo $strPumpUrl;?>>Pumps</a></li>
										<li><a <?php echo $strBlowerUrl;?>>Blower</a></li>
										<li><a <?php echo $strHeaterUrl;?>>Heater</a></li>
										<li><a <?php echo $strLightUrl;?>>Lights</a></li>
										<li><a <?php echo $strMiscUrl;?>>Miscelleneous Device</a></li>
										<?php if($this->session->userdata('user_type') == 'SA') { ?>
										<li><a href="<?php echo $strExcludeUrl;?>">Exclude Device</a></li>
										<li><a href="<?php echo $strCustomProgramUrl;?>">Custom Programs</a></li>
										<?php } ?>
									</ul>
								</li>
								<!--<li <?php if($pg == 'device') {echo 'class="current-menu-item"';}?>><a href="<?php echo base_url('home/PoolSpaSetting/');?>">Pool & Spa</a></li>-->
								<li class="parent">
									<a <?php if($pg == 'setting' || $pg == 'status' || $pg == 'log') {echo 'class="current-menu-item"';}?> href="javascript:void(0);">System</a>
									<ul class="sub-menu">
										<li class="parent"><a href="javascript:void(0);" >Settings</a>
											<ul class="sub-menu">
												<li><a <?php echo $strSettingUrl;?>><i class="glyphicon glyphicon-cog"></i>Basic Setting</a></li>
												<li><a href="<?php echo base_url('home/PoolSpaSetting/');?>"><i class="glyphicon glyphicon-cog"></i>Advance Setting</a></li>
											</ul>
										</li>
										<li><a <?php echo $strModeUrl;?>><i class="glyphicon glyphicon-sort"></i>Mode</a></li>
										<li><a <?php echo $strStatusUrl;?>><i class="glyphicon glyphicon-ok"></i>Status</a></li>
										<li><a <?php echo $strLogUrl;?>><i class="glyphicon glyphicon-folder-open"></i>Log</a></li>
										<?php if($this->session->userdata('user_type') == 'SA') { ?>
										<li><a href="<?php echo base_url('dashboard/position/');?>"><i class="glyphicon glyphicon-th"></i>Valve Positions</a></li>
										<li><a href="<?php echo base_url('importexport/index/');?>"><i class="glyphicon glyphicon-export"></i>Import/Export</a></li>
										<li><a href="<?php echo base_url('device/systemOperation');?>"><i class="glyphicon glyphicon-off"></i>System Operation</a></li>
										</li>
										<?php } ?>
									</ul>
								</li>
								<li class="parent"><a href="javascript:void(0);">User</a>
								<ul class="sub-menu">
									<li><a href="<?php echo base_url('dashboard/logout'); ?>"><i class="glyphicon glyphicon-lock"></i>Logout</a></li>
									<?php if($this->session->userdata('user_type') == 'SA') { ?>
									<li><a href="<?php echo base_url('dashboard/users/');?>"><i class="glyphicon glyphicon-user"></i>Sub Users</a></li>
									<li><a href="<?php echo base_url('dashboard/module/');?>"><i class="glyphicon glyphicon-th-list"></i>Pages</a></li>
									<?php } ?>
								</ul>
								</li>
							</ul>
						</nav>
						<div class="clear"></div>
					</div>
				</header>	
			</div>
			<div class="row">&nbsp;</div>
			<?php 
				if(!empty($aAllOnPrograms))
				{
			?>
				<div class="row">
						<div class="col-sm-12">
							<div class="customProgramProgress" style="background-color:#FFF;padding-bottom:20px;padding-top:20px;padding-left:10px;padding-right:10px;">
							<h1>Custom Programs Progress:</h1>
							<?php
									foreach($aAllOnPrograms as $customProgram)
									{
										$unique_id	=	$customProgram->unique_id;
										$programID	=	$customProgram->id;
										
										$aProgramDetails =	json_decode($customProgram->program_details);
										
										$maxRunTime		 =	$aProgramDetails->g_custom_max_time;
										$programStart	 =	$customProgram->program_start;	
										$programEnd		 =	$customProgram->program_end;
										$programName	 =  trim(str_replace("_"," ",$aProgramDetails->g_custom_mode_name));
										
										$arrProgramDetails[$programID]['Name'] = $programName;
										
										$time1     = new DateTime($programStart);
										$time2     = new DateTime(date('Y-m-d H:i:s'));
										$interval  = $time2->diff($time1);
										$sTotalTime = $interval->format('%I');
										
										$minutes = $interval->days * 24 * 60;
										$minutes += $interval->h * 60;
										$minutes += $interval->i;
										
										if(isset($aProgramDetails->g_rlb_pump_list) && $aProgramDetails->g_rlb_pump_list != '')
										{
											//Pump Device Details.
											$pumpDevice		=	explode(",",$aProgramDetails->g_rlb_pump_list);
											$pumpSequence	=	explode(",",$aProgramDetails->g_pump_sq);
											$pumpTime		=	explode(",",$aProgramDetails->g_pump_time);
										}
										
										if(isset($aProgramDetails->g_rlb_valve_list) && $aProgramDetails->g_rlb_valve_list != '')
										{
											//Valve Device Details
											$valveDevice	=	explode(",",$aProgramDetails->g_rlb_valve_list);	
											$valveSequence	=	explode(",",$aProgramDetails->g_valve_sq);	
											$valveTime		=	explode(",",$aProgramDetails->g_valve_time);
										}

										if(isset($aProgramDetails->g_rlb_relay_list) && $aProgramDetails->g_rlb_relay_list != '')
										{
											//Relay Device Details
											$relayDevice	=	explode(",",$aProgramDetails->g_rlb_relay_list);	
											$relaySequence	=	explode(",",$aProgramDetails->g_relay_sq);	
											$relayTime		=	explode(",",$aProgramDetails->g_relay_time);				
										}
										
										if(isset($aProgramDetails->g_rlb_powercenter_list) && $aProgramDetails->g_rlb_powercenter_list != '')
										{
											//Relay Device Details
											$powerCenterDevice	=	explode(",",$aProgramDetails->g_rlb_powercenter_list);	
											$powerCenterSequence	=	explode(",",$aProgramDetails->g_powercenter_sq);	
											$powerCenterTime		=	explode(",",$aProgramDetails->g_powercenter_time);				
										}
														
										if(!empty($pumpSequence))
										{
											foreach($pumpSequence as $seq => $key)
											{
												if($key != '')
												{
													if(!array_key_exists($key,$arrSequnceDevice))
													$arrSequnceDevice[$key] = array();
													
													array_push($arrSequnceDevice[$key],$pumpDevice[$seq].'|||'.$pumpTime[$seq].'|||PS');
												}
											}
										}
										
										//$valveSequence	=	array_flip($valveSequence);
										
										$arrAfterProgramDevice = array();
										$arrValveKeepOn		   = array();
										
										if(!empty($valveSequence))
										{
											
											$k = 1;
											foreach($valveSequence as $seq => $key)
											{
												if($key != '')
												{
													if(!array_key_exists($key,$arrSequnceDevice))
													$arrSequnceDevice[$key] = array();
												
													array_push($arrSequnceDevice[$key],$valveDevice[$seq].'|||'.$valveTime[$seq].'|||V');
												
												}
											}
										}
										
										if(!empty($relaySequence))
										{
											foreach($relaySequence as $seq => $key)
											{
												if($key != '')
												{
													if(!array_key_exists($key,$arrSequnceDevice))
													$arrSequnceDevice[$key] = array();
													
													array_push($arrSequnceDevice[$key],$relayDevice[$seq].'|||'.$relayTime[$seq].'|||R');
												}
											}
										}
										
										if(!empty($powerCenterSequence))
										{
											foreach($powerCenterSequence as $seq => $key)
											{
												if($key != '')
												{
													if(!array_key_exists($key,$arrSequnceDevice))
													$arrSequnceDevice[$key] = array();
													
													array_push($arrSequnceDevice[$key],$powerCenterDevice[$seq].'|||'.$powerCenterTime[$seq].'|||P');
												}
											}
										}
										
										ksort($arrSequnceDevice);
										
										$sTotalCustomProgramRunTime	= 0;
										
										foreach($arrSequnceDevice as $device)
										{
											
											foreach($device as $deviceDetails)
											{
												$arrDeviceDetails = explode('|||',$deviceDetails);
												$sTotalCustomProgramRunTime += $arrDeviceDetails[1];
												break;
											}
										}
										
										//$minutes = 11;
										
										$completePercentage = ($minutes/$sTotalCustomProgramRunTime)*100;
										
										$minuteIncrease = (1/$sTotalCustomProgramRunTime)*100;
										
										//echo $sTotalCustomProgramRunTime;
										
							?>
								<input type="hidden" class="currentProgressPercent" name="currentProgressPercent_<?php echo $programID;?>" id="currentProgressPercent_<?php echo $programID;?>" value="<?php echo $completePercentage;?>">
								
								<input type="hidden" name="currentProgressPercent_<?php echo $programID;?>_total" id="currentProgressPercent_<?php echo $programID;?>_total" value="<?php echo $sTotalCustomProgramRunTime;?>">
								
								<input type="hidden" name="currentProgressPercent_<?php echo $programID;?>_minute" id="currentProgressPercent_<?php echo $programID;?>_minute" value="<?php echo number_format($minuteIncrease,2);?>">
								
								<span id="customProgram_<?php echo $programID;?>" class="testBar"><?php echo $completePercentage;?></span>
							<?php } 
								 ?>	
							</div>
						</div>
					</div>
					<a href="javascript:void(0)" id="showHideProgress" style="color:#ffffff;">Show/Hide Custom Program Progress</a>
					<div class="row"><div class="col-sm-12">&nbsp;</div></div>
				<?php } ?>	
			<?php } ?>
			