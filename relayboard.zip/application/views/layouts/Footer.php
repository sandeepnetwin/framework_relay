	<script type="text/javascript">
	var bar;
	var site_url = '<?php echo site_url();?>';
	</script>
	<link href="<?php echo HTTP_ASSETS_PATH.'barIndicator/css/bi-style.css';?>" rel="stylesheet" />
	<script src="<?php echo HTTP_ASSETS_PATH.'barIndicator/jquery.easing.1.3.js';?>"></script>
	<script src="<?php echo HTTP_ASSETS_PATH.'barIndicator/jquery-barIndicator.js';?>"></script>
	<script src="<?php echo HTTP_ASSETS_PATH.'barIndicator/scripts.js';?>"></script>	
	<?php if(!isset($iframe) && $iframe != '1') { ?>
		<hr />
		<footer>
		<p style="text-align:center; color:#FFF;">&nbsp; &copy; <?php echo date('Y') ?> Crystal Properties & Investments, Inc. All rights reserved. </p>
		</footer>
    <?php } ?> 
    <!-- Placed at the end of the document so the pages load faster -->
    </div><!-- /#container -->
     </div><!-- /.content -->
    </div><!-- /.body-wrap --> 
	
	
  </body>
</html>