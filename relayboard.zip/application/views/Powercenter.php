<!-- START : 12V DC RELAY -->
			
<div class="row">
	<div class="col-sm-4">
		<div class="widget-container widget-stats boxed green-line">
			<div class="widget-title">
				<a href="<?php echo base_url('home/setting/'.$sDevice.'/');?>" class="link-refresh" id="link-refresh-1"><span class="glyphicon glyphicon-refresh"></span></a>
				<h3>ON/OFF</h3>
			</div>
			<div class="stats-content clearfix">
				<div class="stats-content-right" style="width:96% !important; margin-left:5px; margin-right:5px; margin-top:10px; float:none;">
				<?php
						for ($i=0;$i < $power_count; $i++)
						{
							$iRelayVal = $sPowercenter[$i];
							
							if($iRelayVal != '' && $iRelayVal !='.') 
							{
								$strChecked	=	'';
								if($iRelayVal == '1')
									$strChecked	=	'class="checked"';
								
								$sRelayNameDb =  $this->home_model->getDeviceName($i,$sDevice);
								$strRelayName = 'PowerCenter '.$i;
								if($sRelayNameDb != '')
									$strRelayName .= '<br>('.$sRelayNameDb.')';
								
								//Get Port Number
								$sDevicePort	=	$this->home_model->getDevicePort($i,$sDevice);
								
								if($sDevicePort == '')
									$sDevicePort = 0;
								
								$strPortClass	=	'port_'.$sDevicePort;
				?>
								<div class="rowCheckbox switch <?php echo $strPortClass;?>">
									<div class="custom-checkbox" style="<?php if($sRelayNameDb != '') { echo 'height:60px;'; }?>">
										
										<input type="checkbox" value="<?php echo $i;?>" id="power-<?php echo $i?>" name="power-<?php echo $i?>" class="powerButton" hidefocus="true" style="outline: medium none;">
										
										<label <?php echo $strChecked;?>  id="lablePower-<?php echo $i?>" for="power-<?php echo $i?>"><span style="color:#C9376E; float:right;"><?php echo $strRelayName;?></span></label>
										
									</div>
								</div>
				<?php		}		
						}
				?> 
				</div>
			</div>
		</div>
	</div>
	<div class="col-sm-8">
		<!-- Statistics -->
		<div class="widget-container widget-stats boxed green-line">
			<div class="widget-title">
				<a href="<?php echo base_url('home/setting/'.$sDevice.'/');?>" class="link-refresh" id="link-refresh-1"><span class="glyphicon glyphicon-refresh"></span></a>
				<h3>12V DC Relay Settings</h3>
			</div>
			<div class="stats-content clearfix">
				<div class="stats-content-right" style="width:100% !important; margin-left:5px; margin-right:5px; float:none;">
			
					<table class="table table-hover">
					<thead>
					  <tr>
						<th class="header" style="width:50%">Relay</th>
						<th class="header"  style="width:50%">Action</th>
					  </tr>
					</thead>
					<tbody>
					<?php			
					for ($i=0;$i < $power_count; $i++)
					{
						$iRelayVal = $sPowercenter[$i];
						if($iRelayVal != '' && $iRelayVal !='.') 
						{
							$iRelayNewValSb = 1;
							if($iRelayVal == 1)
							{
							  $iRelayNewValSb = 0;
							}
							$sRelayVal = false;
							if($iRelayVal)
							  $sRelayVal = true;
							
							$sPowerCenterNameDb =  $this->home_model->getDeviceName($i,$sDevice);
							if($sPowerCenterNameDb == '')
							  $sPowerCenterNameDb = 'Add Name';
							
							$sMainType =	$this->home_model->getDeviceMainType($i,$sDevice);
							
							//Get Port Number
							$sDevicePort	=	$this->home_model->getDevicePort($i,$sDevice);
							
							if($sDevicePort == '')
								$sDevicePort = 0;
							
							$strPortClass	=	'port_'.$sDevicePort;
						?>
							<tr class="<?php echo $strPortClass;?>">
								<td>PowerCenter <?php echo $i;?><br><br><a href="<?php if($sAccess == '1'){echo 'javascript:void(0);';} else if($sAccess == '2') { echo site_url('home/deviceName/'.base64_encode($i).'/'.base64_encode($sDevice).'/');}?>" ><?php echo $sPowerCenterNameDb;?></a></td>
								<td>
									<div class="rowRadio">
										<div class="custom-radio">
											<input class="powerRadio" type="radio" id="radio_other_<?php echo $i;?>" value="0" name="<?php echo $i;?>_MainType" <?php if($sMainType == '0' || $sMainType == ''){ echo 'checked="checked"';}?> <?php if($sAccess == '1') { echo 'disabled="disabled"';}?> hidefocus="true" style="outline: medium none;">
											<label id="relay_other_<?php echo $i;?>" for="radio_other_<?php echo $i;?>" class="<?php if($sMainType == '0' || $sMainType == ''){ echo 'checked';}?>">Other</label>
											
											<input class="powerRadio" type="radio" id="radio_spa_<?php echo $i;?>" name="<?php echo $i;?>_MainType" value="1" <?php if($sMainType == '1'){ echo 'checked="checked"';}?> <?php if($sAccess == '1') { echo 'disabled="disabled"';}?> hidefocus="true" style="outline: medium none;">
											<label id="relay_spa_<?php echo $i;?>" for="radio_spa_<?php echo $i;?>" class="<?php if($sMainType == '1'){ echo 'checked';}?>">Spa</label>
											
											<input class="powerRadio" type="radio" id="radio_pool_<?php echo $i;?>" name="<?php echo $i;?>_MainType" value="2" <?php if($sMainType == '2'){ echo 'checked="checked"';}?> <?php if($sAccess == '1') { echo 'disabled="disabled"';}?> hidefocus="true" style="outline: medium none;">
											<label id="relay_pool_<?php echo $i;?>" for="radio_pool_<?php echo $i;?>" class="<?php if($sMainType == '2'){ echo 'checked';}?>">Pool</label>
										
										</div>
									</div>
									<hr />
									<strong>Select Board: </strong>
									<select name="selPort_P_<?php echo $i;?>" id="selPort_P_<?php echo $i;?>" onchange="saveDevicePort('<?php echo $i;?>','<?php echo $sDevice;?>',this.value)">
											<option value="" <?php if($sDevicePort == ''){ echo 'selected="selected"'; }?>>-- IP(Name)--</option>
											<?php
												if(!empty($aIPDetails))
												{
													foreach($aIPDetails as $aIP)
													{
														$sDetails	=	$aIP->ip;
														if($aIP->name != '')
														{
															$sDetails .= ' ('.$aIP->name.')';
														}
											?>		
														<option value="<?php echo $aIP->id;?>" <?php if($sDevicePort == $aIP->id){ echo 'selected="selected"'; }?>><?php echo $sDetails;?></option>
											<?php 	}
												}
											?>
									</select>
									<hr />
								</td>
							</tr>
				<?php  	} ?>
			<?php	} ?>	
					</tbody>
					</table>
				</div>
			</div>
		</div>
	</div>
</div>	
<!-- END : 12V DC RELAY -->