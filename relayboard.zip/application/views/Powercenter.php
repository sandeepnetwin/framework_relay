<!-- START : 12V DC RELAY -->
			
<div class="row">
	<?php
		if(!empty($aIPDetails))
		{
			foreach($aIPDetails as $aIP)
			{
	?>
	<div class="col-sm-4" id="onoffbuttons_<?php echo $aIP->id;?>" style="display:<?php if($aIP->id != $iFirstIPId){ echo 'none';} ?>">
	<input type="hidden" value="<?php echo $aIP->id;?>" id="hidIPIdButton">
		<div class="widget-container widget-stats boxed green-line">
			<div class="widget-title">
				<a href="<?php echo base_url('home/setting/'.$sDevice.'/');?>" class="link-refresh" id="link-refresh-1"><span class="glyphicon glyphicon-refresh"></span></a>
				<h3>ON/OFF</h3>
			</div>
			<div class="stats-content clearfix">
				<div class="stats-content-right" style="width:96% !important; margin-left:5px; margin-right:5px; margin-top:10px; float:none;">
				<?php
						for ($i=0;$i < ${"power_count".$aIP->id}; $i++)
						{
							$iRelayVal = ${"sPowercenter".$aIP->id}[$i];
							
							if($iRelayVal != '' && $iRelayVal !='.') 
							{
								$strChecked	=	'';
								if($iRelayVal == '1')
									$strChecked	=	'class="checked"';
								
								$sRelayNameDb =  $this->home_model->getDeviceName($i,$sDevice,$aIP->id);
								$strRelayName = 'PowerCenter '.$i;
								if($sRelayNameDb != '')
									$strRelayName .= '<br>('.$sRelayNameDb.')';
								
								/* //Get Port Number
								$sDevicePort	=	$this->home_model->getDevicePort($i,$sDevice);
								
								if($sDevicePort == '')
									$sDevicePort = 0;
								
								$strPortClass	=	'port_'.$sDevicePort; */
				?>
								<div class="rowCheckbox switch">
									<div class="custom-checkbox" style="<?php if($sRelayNameDb != '') { echo 'height:60px;'; }?>">
										
										<input type="checkbox" value="<?php echo $i;?>" id="power-<?php echo $i?>" name="power-<?php echo $i?>" class="powerButton" hidefocus="true" style="outline: medium none;">
										
										<label <?php echo $strChecked;?>  id="lablePower-<?php echo $i?>-<?php echo $aIP->id;?>" for="power-<?php echo $i?>"><span style="color:#C9376E; float:right;"><?php echo $strRelayName;?></span></label>
										
									</div>
								</div>
				<?php		}		
						}
				?> 
				</div>
			</div>
		</div>
	</div>
	<div class="col-sm-8" id="relayConfigure_<?php echo $aIP->id;?>" style="display:<?php if($aIP->id != $iFirstIPId){ echo 'none';} ?>">
		<!-- Statistics -->
		<div class="widget-container widget-stats boxed green-line">
			<div class="widget-title">
				<a href="<?php echo base_url('home/setting/'.$sDevice.'/');?>" class="link-refresh" id="link-refresh-1"><span class="glyphicon glyphicon-refresh"></span></a>
				<h3>12V DC Relay Settings</h3>
			</div>
			<div class="stats-content clearfix">
				<div class="stats-content-right" style="width:100% !important; margin-left:5px; margin-right:5px; float:none;">
			
					<table class="table table-hover">
					<thead>
					  <tr>
						<th class="header" style="width:50%">Relay</th>
						<th class="header"  style="width:50%">Action</th>
					  </tr>
					</thead>
					<tbody>
					<?php			
					for ($i=0;$i < ${"power_count".$aIP->id}; $i++)
					{
						$iRelayVal = ${"sPowercenter".$aIP->id}[$i];
						if($iRelayVal != '' && $iRelayVal !='.') 
						{
							$iRelayNewValSb = 1;
							if($iRelayVal == 1)
							{
							  $iRelayNewValSb = 0;
							}
							$sRelayVal = false;
							if($iRelayVal)
							  $sRelayVal = true;
							
							$sPowerCenterNameDb =  $this->home_model->getDeviceName($i,$sDevice,$aIP->id);
							if($sPowerCenterNameDb == '')
							  $sPowerCenterNameDb = 'Add Name';
							
							$sMainType =	$this->home_model->getDeviceMainType($i,$sDevice,$aIP->id);
							
							/* //Get Port Number
							$sDevicePort	=	$this->home_model->getDevicePort($i,$sDevice);
							
							if($sDevicePort == '')
								$sDevicePort = 0;
							
							$strPortClass	=	'port_'.$sDevicePort; */
						?>
							<tr>
								<td>PowerCenter <?php echo $i;?><br><br><a href="<?php if($sAccess == '1'){echo 'javascript:void(0);';} else if($sAccess == '2') { echo site_url('home/deviceName/'.base64_encode($i).'/'.base64_encode($sDevice).'/'.base64_encode($aIP->id));}?>" ><?php echo $sPowerCenterNameDb;?></a></td>
								<td>
									<div class="rowRadio">
										<div class="custom-radio">
											<input class="powerRadio" type="radio" id="radio-other-<?php echo $i;?>-<?php echo $aIP->id;?>" value="0" name="<?php echo $i;?>_MainType" <?php if($sMainType == '0' || $sMainType == ''){ echo 'checked="checked"';}?> <?php if($sAccess == '1') { echo 'disabled="disabled"';}?> hidefocus="true" style="outline: medium none;">
											
											<label id="relay_other_<?php echo $i;?>-<?php echo $aIP->id;?>" for="radio-other-<?php echo $i;?>-<?php echo $aIP->id;?>" class="<?php if($sMainType == '0' || $sMainType == ''){ echo 'checked';}?>">Other</label>
											
											<input class="powerRadio" type="radio" id="radio-spa-<?php echo $i;?>-<?php echo $aIP->id;?>" name="<?php echo $i;?>_MainType" value="1" <?php if($sMainType == '1'){ echo 'checked="checked"';}?> <?php if($sAccess == '1') { echo 'disabled="disabled"';}?> hidefocus="true" style="outline: medium none;">
											
											<label id="relay_spa_<?php echo $i;?>-<?php echo $aIP->id;?>" for="radio-spa-<?php echo $i;?>-<?php echo $aIP->id;?>" class="<?php if($sMainType == '1'){ echo 'checked';}?>">Spa</label>
											
											<input class="powerRadio" type="radio" id="radio-pool-<?php echo $i;?>-<?php echo $aIP->id;?>" name="<?php echo $i;?>_MainType" value="2" <?php if($sMainType == '2'){ echo 'checked="checked"';}?> <?php if($sAccess == '1') { echo 'disabled="disabled"';}?> hidefocus="true" style="outline: medium none;">
											
											<label id="relay_pool_<?php echo $i;?>-<?php echo $aIP->id;?>" for="radio-pool-<?php echo $i;?>-<?php echo $aIP->id;?>" class="<?php if($sMainType == '2'){ echo 'checked';}?>">Pool</label>
										
										</div>
									</div>
								</td>
							</tr>
				<?php  	} ?>
			<?php	} ?>	
					</tbody>
					</table>
				</div>
			</div>
		</div>
	</div>
	<?php 	}
		}
	?>
</div>	
<!-- END : 12V DC RELAY -->