<!-- List Of All Devices From multiple Boards-->
<div class="row">
	<div class="col-sm-12">
		<form action="<?php echo base_url('device/index');?>" method="post">
		<div class="widget-container widget-stats boxed green-line">
			<div class="widget-title">
				<h3>Select Device To Exclude For Modes</h3>
			</div>
			<div class="tabs-framed tabs-small boxed green-line">
			<ul class="tabs clearfix">
				<li class="active"><a href="#24VAC" data-toggle="tab">24V AC Relays</a></li>
				<li><a href="#12VDC" data-toggle="tab">12V DC Relays</a></li>
				<li><a href="#Valve" data-toggle="tab">Valves</a></li>
				<li><a href="#Pump" data-toggle="tab">Pumps</a></li>
				<li><a href="#Heater" data-toggle="tab">Heater</a></li>
				<li><a href="#Blower" data-toggle="tab">Blower</a></li>
				<li><a href="#Light" data-toggle="tab">Lights</a></li>
				<li><a href="#Miscellenious" data-toggle="tab">Miscellenious</a></li>
			</ul>
			<div class="tab-content">
				
				<!-- START : 24V AC Relays -->
				<div class="tab-pane fade in active" id="24VAC">
					
					<table class="table table-hover">
					<thead>
					<tr>
						<th class="header" style="width:50%"><strong>Device Name</strong></th>
						<th class="header" style="width:50%"><strong>Exclude</strong></th>
					</tr>
					</thead>
					<tbody>
						<?php
							if(!empty($aIPDetails))
							{
								foreach($aIPDetails as $aIP)
								{
									
									//START : Relay Devices
									$sDevice = 'R';
									for ($i=0;$i < ${"relay_count".$aIP->id}; $i++)
									{
										
										$iRelayVal = ${"sRelays".$aIP->id}[$i];
										if($iRelayVal != '' && $iRelayVal !='.') 
										{
											//Name added to Relay
											$sDeviceNameDb =  $this->home_model->getDeviceName($i,$sDevice,$aIP->id);
											
											$sDeviceNameDb .= ' - Relay '.$i.' ('.$aIP->ip.')';
						?>
						<tr>
							<td><?php echo $sDeviceNameDb;?></td>
							<td>
								<?php
									$strSelect = '';
									if(in_array($i.'_'.$aIP->id,$excludeDevices['R']))
										$strSelect = 'checked="checked"';
									
								?>
								<input name="24VRelays[]" type="checkbox" id="24VRelays_<?php echo $i.'_'.$aIP->id;?>" <?php echo $strSelect;?> value="<?php echo $i.'_'.$aIP->id;?>">
							</td>
						</tr>	
												
						<?php			}
									}
								}
							}
						?>
						</tbody>
					</table>
				</div>
				<!-- END : 24V AC Relays -->
				
				<!-- START : 12V DC Relays -->
				<div class="tab-pane fade in" id="12VDC">
					<table class="table table-hover">
					<thead>
					<tr>
						<th class="header" style="width:50%"><strong>Device Name</strong></th>
						<th class="header" style="width:50%"><strong>Exclude</strong></th>
					</tr>
					</thead>
					<tbody>
						<?php
							if(!empty($aIPDetails))
							{
								foreach($aIPDetails as $aIP)
								{
									//START : Relay Devices
									$sDevice = 'P';
									for ($i=0;$i < ${"power_count".$aIP->id}; $i++)
									{
										$iRelayVal = ${"sPowercenter".$aIP->id}[$i];
										
										//Name added to Relay
										$sDeviceNameDb =  $this->home_model->getDeviceName($i,$sDevice,$aIP->id);
											
										$sDeviceNameDb .= ' - PowerCenter '.$i.' ('.$aIP->ip.')';
						?>
						<tr>
							<td><?php echo $sDeviceNameDb;?></td>
							<td>
								<?php
									$strSelect = '';
									if(in_array($i.'_'.$aIP->id,$excludeDevices['P']))
										$strSelect = 'checked="checked"';
								?>
									<input name="12VRelays[]" type="checkbox" id="12VRelays_<?php echo $i.'_'.$aIP->id;?>" <?php echo $strSelect;?> value="<?php echo $i.'_'.$aIP->id;?>">
							</td>
						</tr>	
												
						<?php		}
								}
							}
						?>
						</tbody>
					</table>
				</div>
				<!-- END : 12V DC Relays -->
				
				<!-- START : Valve -->
				<div class="tab-pane fade in" id="Valve">
					<table class="table table-hover">
					<thead>
					<tr>
						<th class="header" style="width:50%"><strong>Device Name</strong></th>
						<th class="header" style="width:50%"><strong>Exclude</strong></th>
					</tr>
					</thead>
					<tbody>
						<?php
							if(!empty($aIPDetails))
							{
								foreach($aIPDetails as $aIP)
								{
									//START : Relay Devices
									$sDevice = 'V';
									if(!empty(${"ValveRelays".$aIP->id}))
									{
										foreach(${"ValveRelays".$aIP->id} as $valve)
										{
											$i = $valve->device_number;
											$iRelayVal = ${"sValves".$aIP->id}[$i];
											//Name added to Relay
											$sDeviceNameDb =  $this->home_model->getDeviceName($i,$sDevice,$aIP->id);
												
											$sDeviceNameDb .= ' - Valve '.$i.' ('.$aIP->ip.')';
						?>
						<tr>
							<td><?php echo $sDeviceNameDb;?></td>
							<td>
								<?php
									$strSelect = '';
									if(in_array($i.'_'.$aIP->id,$excludeDevices['V']))
										$strSelect = 'checked="checked"';
								?>
								<input name="Valves[]" type="checkbox" id="Valves_<?php echo $i.'_'.$aIP->id;?>" <?php echo $strSelect;?> value="<?php echo $i.'_'.$aIP->id;?>">
							</td>
						</tr>	
												
						<?php			}
									}
								}
							}
						?>
						</tbody>
					</table>
				</div>
				<!-- END : Valve -->
				
				<!-- START : Pump -->
				<div class="tab-pane fade in" id="Pump">
					<table class="table table-hover">
					<thead>
					<tr>
						<th class="header" style="width:50%"><strong>Device Name</strong></th>
						<th class="header" style="width:50%"><strong>Exclude</strong></th>
					</tr>
					</thead>
					<tbody>
						<?php
							if(!empty($aIPDetails))
							{
								foreach($aIPDetails as $aIP)
								{
									//START : Relay Devices
									$sDevice = 'PS';
									if(!empty(${"Pumps".$aIP->id}))
									{
										foreach(${"Pumps".$aIP->id} as $pump)
										{
											
											$i= $pump->pump_number;
											$iRelayVal = ${"Pumps".$aIP->id}[$i];
											//Name added to Relay
											$sDeviceNameDb =  $this->home_model->getDeviceName($i,$sDevice,$aIP->id);
												
											$sDeviceNameDb .= ' - Pump '.$i.' ('.$aIP->ip.')';
						?>
						<tr>
							<td><?php echo $sDeviceNameDb;?></td>
							<td>
								<?php
									$strSelect = '';
									if(in_array($i.'_'.$aIP->id,$excludeDevices['PS']))
										$strSelect = 'checked="checked"';
								?>
								<input name="Pumps[]" type="checkbox" id="Pumps_<?php echo $i.'_'.$aIP->id;?>" <?php echo $strSelect;?> value="<?php echo $i.'_'.$aIP->id;?>">
							</td>
						</tr>	
												
						<?php			}
									}
								}
							}
						?>
						</tbody>
					</table>
				</div>
				<!-- END : Pump -->
				
				<!-- START : Heater -->
				<div class="tab-pane fade in" id="Heater">
					<table class="table table-hover">
					<thead>
					<tr>
						<th class="header" style="width:50%"><strong>Device Name</strong></th>
						<th class="header" style="width:50%"><strong>Exclude</strong></th>
					</tr>
					</thead>
					<tbody>
						<?php
							if(!empty($aIPDetails))
							{
								foreach($aIPDetails as $aIP)
								{
									$tempIPID	=	($aIP->id == '1') ? '' : $aIP->id;
									${'numHeater'.$aIP->id}     =	$extra['HeaterNumber'.$tempIPID];
									$sDevice = 'H';
										for ($i=0;$i < ${'numHeater'.$aIP->id}; $i++)
										{
											//Name added to Relay
											$sDeviceNameDb =  $this->home_model->getDeviceName($i,$sDevice,$aIP->id);
												
											$sDeviceNameDb .= ' - Heater '.$i.' ('.$aIP->ip.')';
						?>
						<tr>
							<td><?php echo $sDeviceNameDb;?></td>
							<td>
								<?php
									$strSelect = '';
									if(in_array($i.'_'.$aIP->id,$excludeDevices['H']))
										$strSelect = 'checked="checked"';
								?>
								<input name="Heaters[]" type="checkbox" id="Heaters_<?php echo $i.'_'.$aIP->id;?>" <?php echo $strSelect;?> value="<?php echo $i.'_'.$aIP->id;?>">
							</td>
						</tr>	
												
						<?php			
									}
								}
							}
						?>
						</tbody>
					</table>
				</div>
				<!-- END : Heater -->
				
				<!-- START : Blower -->
				<div class="tab-pane fade in" id="Blower">
					<table class="table table-hover">
					<thead>
					<tr>
						<th class="header" style="width:50%"><strong>Device Name</strong></th>
						<th class="header" style="width:50%"><strong>Exclude</strong></th>
					</tr>
					</thead>
					<tbody>
						<?php
							if(!empty($aIPDetails))
							{
								foreach($aIPDetails as $aIP)
								{
									$tempIPID	=	($aIP->id == '1') ? '' : $aIP->id;
									${'numBlower'.$aIP->id}     =	$extra['BlowerNumber'.$tempIPID];
									$sDevice = 'B';
										for ($i=1;$i <= ${'numBlower'.$aIP->id}; $i++)
										{
											//Name added to Relay
											$sDeviceNameDb =  $this->home_model->getDeviceName($i,$sDevice,$aIP->id);
												
											$sDeviceNameDb .= ' - Blower '.$i.' ('.$aIP->ip.')';
						?>
						<tr>
							<td><?php echo $sDeviceNameDb;?></td>
							<td>
								<?php
									$strSelect = '';
									if(in_array($i.'_'.$aIP->id,$excludeDevices['B']))
										$strSelect = 'checked="checked"';
								?>
								<input name="Blowers[]" type="checkbox" id="Blowers_<?php echo $i.'_'.$aIP->id;?>" <?php echo $strSelect;?> value="<?php echo $i.'_'.$aIP->id;?>">
							</td>
						</tr>	
												
						<?php			
									}
								}
							}
						?>
						</tbody>
					</table>
				</div>
				<!-- END : Blower -->
				
				<!-- START : Light -->
				<div class="tab-pane fade in" id="Light">
					<table class="table table-hover">
					<thead>
					<tr>
						<th class="header" style="width:50%"><strong>Device Name</strong></th>
						<th class="header" style="width:50%"><strong>Exclude</strong></th>
					</tr>
					</thead>
					<tbody>
						<?php
							if(!empty($aIPDetails))
							{
								foreach($aIPDetails as $aIP)
								{
									$tempIPID	=	($aIP->id == '1') ? '' : $aIP->id;
									${'numLight'.$aIP->id}     =	$extra['LightNumber'.$tempIPID];
									$sDevice = 'L';
										for ($i=0;$i < ${'numLight'.$aIP->id}; $i++)
										{
											//Name added to Relay
											$sDeviceNameDb =  $this->home_model->getDeviceName($i,$sDevice,$aIP->id);
												
											$sDeviceNameDb .= ' - Light '.($i+1).' ('.$aIP->ip.')';
						?>
						<tr>
							<td><?php echo $sDeviceNameDb;?></td>
							<td>
								<?php
									$strSelect = '';
									if(in_array($i.'_'.$aIP->id,$excludeDevices['L']))
										$strSelect = 'checked="checked"';
								?>
								<input name="Lights[]" type="checkbox" id="Lights_<?php echo $i.'_'.$aIP->id;?>" <?php echo $strSelect;?> value="<?php echo $i.'_'.$aIP->id;?>">
							</td>
						</tr>	
												
						<?php			
									}
								}
							}
						?>
						</tbody>
					</table>
				</div>
				<!-- END : Light -->
				
				<!-- START : Miscellenious -->
				<div class="tab-pane fade in" id="Miscellenious">
					<table class="table table-hover">
					<thead>
					<tr>
						<th class="header" style="width:50%"><strong>Device Name</strong></th>
						<th class="header" style="width:50%"><strong>Exclude</strong></th>
					</tr>
					</thead>
					<tbody>
						<?php
							if(!empty($aIPDetails))
							{
								foreach($aIPDetails as $aIP)
								{
									$tempIPID	=	($aIP->id == '1') ? '' : $aIP->id;
									${'numMisc'.$aIP->id}     =	$extra['MiscNumber'.$tempIPID];
									$sDevice = 'M';
										for ($i=0;$i < ${'numMisc'.$aIP->id}; $i++)
										{
											//Name added to Relay
											$sDeviceNameDb =  $this->home_model->getDeviceName($i,$sDevice,$aIP->id);
												
											$sDeviceNameDb .= ' - Miscellenious '.($i+1).' ('.$aIP->ip.')';
						?>
						<tr>
							<td><?php echo $sDeviceNameDb;?></td>
							<td>
								<?php
									$strSelect = '';
									if(in_array($i.'_'.$aIP->id,$excludeDevices['M']))
										$strSelect = 'checked="checked"';
								?>
								<input name="Miscs[]" type="checkbox" id="Miscs_<?php echo $i.'_'.$aIP->id;?>" <?php echo $strSelect;?> value="<?php echo $i.'_'.$aIP->id;?>">
							</td>
						</tr>	
												
						<?php			
									}
								}
							}
						?>
						</tbody>
					</table>
				</div>
				<!-- END : Miscellenious -->
				
				
				
			</div>	
		</div>
			<div style="text-align:center;padding-bottom:30px;"><span class="btn btn-green"><input type="submit" name="save" value="Save Details"></span></div>
	</div>
	</form>
</div>
<!-- List Of All Devices From multiple Boards-->