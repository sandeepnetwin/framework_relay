<?php

$sDeviceFullName = '';
$sAccess 		 = '';
$sModule	     = '';
if($sDevice == 'R')
{
  $sDeviceFullName = 'Relay';
  $sModule	    = 2;
}
if($sDevice == 'P')
{
	$sDeviceFullName = 'Power Center';
	$sModule	     = 3;
}
if($sDevice == 'V')
{
	$sDeviceFullName = 'Valve';
	$sModule	     = 8;
}

//Get Permission Details
  $userID = $this->session->userdata('id');
  $aPermissions = json_decode(getPermissionOfModule($userID));
 
  $aModules 		= $aPermissions->sPermissionModule;	
  $aAllActiveModule = $aPermissions->sActiveModule;
  
  $sAccessKey	= 'access_'.$sModule;
  
  if(!empty($aModules))
  {
	  if(in_array($sModule,$aModules->ids))
	  {
		 $sAccess 		= $aModules->$sAccessKey;
	  }
	  else if(!in_array($sModule,$aModules->ids)) 
	  {
		$sAccess 		= '0'; 
	  }
  }
  
  if($sAccess == '')
	$sAccess = '2' ;


$sRelay1	=	$aRelayNumber->Relay1;
$sRelay2	=	$aRelayNumber->Relay2;

?>
<style>
	.form-control-custom
	{
		display:inline-block !important;	
	}
</style>

<script type="text/javascript" src="<?php echo HTTP_ASSETS_PATH.'fancybox/source/jquery.fancybox.js?v=2.1.5';?>"></script>
<link rel="stylesheet" type="text/css" href="<?php echo HTTP_ASSETS_PATH.'fancybox/source/jquery.fancybox.css?v=2.1.5';?>" media="screen" />

<script type="text/javascript">
$(document).ready(function() {
	$('.fancybox').fancybox();
});
</script>

<div id="page-wrapper">

	<div class="row">
	  <div class="col-lg-12">
		<ol class="breadcrumb">
					  <li><img src="<?php echo HTTP_IMAGES_PATH.'icons/home.png';?>" width="24" style="vertical-align: middle !important;">&nbsp;<a href="<?php echo site_url();?>">Home</a> </li>
					  <li><a href="<?php echo base_url('home/setting/V/'.base64_encode($sIpID));?>">Valve</a></li>
					  <li class="active"><?php echo $sDeviceFullName;?> Relays</li>
		</ol>
		<?php if($sucess == '1') { ?>
		  <div class="alert alert-success alert-dismissable">
			<button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
			Details saved successfully! 
		  </div>
		<?php } ?>
	  </div>
	</div>
	<!-- /.row -->
	<div class="row">
	  <div class="col-lg-12">
		<div class="panel panel-primary">
		  <div class="panel-heading" style="border-top-left-radius: 0px;border-top-right-radius: 0px;">
			<h3 class="panel-title" style="color:#FFF;">Save Relays For Valve</h3>
		  </div>
		  <div class="panel-body">
			<div id="morris-chart-area">
			  <form action="<?php if($sAccess == 2) { echo site_url('home/valveRelays/'.base64_encode($sDeviceID).'/'.base64_encode($sDevice).'/'.base64_encode($sIpID)); } else { echo '';}?>" method="post">
			  <input type="hidden" id="sDeviceID" name="sDeviceID" value="<?php echo base64_encode($sDeviceID);?>">
			  <input type="hidden" name="sDevice" value="<?php echo base64_encode($sDevice);?>">
			  <input type="hidden" name="sIpID" value="<?php echo base64_encode($sIpID);?>">
			  
			   <input type="hidden" name="sDeviceIDHID" id="sDeviceIDHID" value="">
				<table border="0" cellspacing="0" cellpadding="0" width="100%">
				  <tr>
					<td width="10%"><strong>Enter Relay 1:</strong></td>
					<td width="1%">&nbsp;</td>
					<td width="89%">
					<input type="text" class="form-control form-control-custom" placeholder="Enter Relay 1" name="sRelay1" value="<?php echo $sRelay1;?>" id="sRelay1" required <?php if($sAccess == 1) { echo 'disabled="disabled"'; } ?> style="width:30%; float:left; margin-right:5%;">
						<select name="positionRelay1" id="positionRelay1" class="form-control form-control-custom" style="width:30%;height:50px;">
						<?php
								foreach($aAllPositions as $Position)
								{
									$strSelect	=	'';
									
									if($Position->id == $sPositionName1)
									{
										$strSelect	=	'selected="selected"';
									}
									
									echo '<option value="'.$Position->id.'" '.$strSelect.'>'.$Position->position_name.'</option>';
								}
						?>	
						</select>
						<span  style="float:right;width:10%;margin-right:10px;">
							<a class="fancybox" id="checkLink" href="#inline1">Add Position</a>
						</span>
					</td>
				  </tr>
				  <tr>
					<td width="10%">&nbsp;</td>
					<td width="1%">&nbsp;</td>
					<td width="89%">
					<span style="width:30%; float:left; margin-right:5%;">(Enter relays)</span><span style="width:30%; float:left;">(Select Position)</span>
					</td>
				  </tr>
				  <tr><td colspan="3">&nbsp;</td></tr>
				  <tr>
					<td width="10%"><strong>Enter Relay 2:</strong></td>
					<td width="1%">&nbsp;</td>
					<td width="89%">
					<input type="text" class="form-control form-control-custom" placeholder="Enter Relay 2" name="sRelay2" value="<?php echo $sRelay2;?>" id="sRelay2" required <?php if($sAccess == 1) { echo 'disabled="disabled"'; } ?> style="width:30%; float:left; margin-right:5%;">
					<select name="positionRelay2" id="positionRelay2" class="form-control form-control-custom" style="width:30%;height:50px;">
					<?php
							foreach($aAllPositions as $Position)
							{
								$strSelect	=	'';
								
								if($Position->id == $sPositionName2)
								{
									$strSelect	=	'selected="selected"';
								}
								
								echo '<option value="'.$Position->id.'" '.$strSelect.'>'.$Position->position_name.'</option>';
							}
					?>	
					</select>
					</td>
				  </tr>
				  <tr>
					<td width="10%">&nbsp;</td>
					<td width="1%">&nbsp;</td>
					<td width="89%">
					<span style="width:30%; float:left; margin-right:5%;">(Enter relays)</span><span style="width:30%;float:left;">(Select Position)</span>
					</td>
				  </tr>
				  <tr><td colspan="3">&nbsp;</td></tr>
				  <tr><td colspan="3"><span class="btn btn-green"><input type="<?php if($sAccess == 2) {echo 'submit';} else { echo 'button';} ?>" name="command" value="Save" <?php if($sAccess == 2) {?> onclick="return checkRelayNumber();" <?php } ?> ></span>&nbsp;&nbsp;<a class="btn" href="<?php echo site_url('home/setting/'.$sDevice.'/'.base64_encode($sIpID));?>"><span>Back</span></a></td></tr>
				  
				</table>
			  </form>
			</div>
		  </div>
		</div>
	  </div>
	</div><!-- /.row -->
</div><!-- /#page-wrapper -->


<div id="inline1" style="width:250px;height:auto; display:none;">
	<table border="0" cellspacing="0" cellpadding="0" width="100%">
		<tr>
			<td colspan="3"><span style="font-weight:bold;">New Position Details :</span></td>
		</tr>
		<tr>
			<td colspan="3">&nbsp;</td>
		</tr>
		<tr>
			<td colspan="3"><span style="color:#FF0000;">* indicates required field</span></td>
		</tr>
		 <tr><td colspan="3">&nbsp;</td></tr>
		  <tr>
			<td width="24%"><strong>Name: <span class="mandetory">*</span></strong></td>
			<td width="1%">&nbsp;</td>
			<td width="75%"><input type="text" class="form-control" placeholder="Enter Position Name" name="sPositionName" value="" id="sPositionName" required></td>
		  </tr>
		  <tr><td colspan="3">&nbsp;</td></tr>
		  <tr>
			<td width="10%"><strong>Active:</strong></td>
			<td width="1%">&nbsp;</td>
			<td width="89%"><input type="radio" name="sPositionActive" value="0">&nbsp;No&nbsp;&nbsp;&nbsp;&nbsp;<input type="radio" name="sPositionActive" checked="checked" value="1">&nbsp;Yes</td>
		  </tr>
		  <tr><td colspan="3">&nbsp;</td></tr>
		  <tr><td colspan="3"><span class="btn btn-green"><input type="button" name="command" value="Save" class="btn btn-success" onclick="return checkForm();"></span>&nbsp;&nbsp;<span class="btn"><input type="button" name="back" value="Back" class="btn btn-success" onclick="javascript:parent.$.fancybox.close();"></span>&nbsp;&nbsp;
		  <span id="loadingImg" style="display:none;"><img src="<?php echo site_url('assets/images/loading.gif');?>" alt="Loading...." width="32" height="32"></span></td></tr>
		  
		</table>
</div>

<script type="text/javascript">
  $(document).ready(function() {
	  
  });
  function checkRelayNumber()
  {
	var relay1 = $("#sRelay1").val();
	var relay2 = $("#sRelay2").val();
	
	var arrRelayStart =['0','2','4','6','8','10','12','14'];
	var arrRelayEnd   = ['1','3','5','7','9','11','13','15'];
	
	var relay1Position = arrRelayStart.indexOf(relay1);
	var relay2Position = arrRelayEnd.indexOf(relay2);
	
	if(relay1Position != -1) 
	{}
	else
	{
		$("#sRelay1").css('border','1px solid red');
		alert("Please select valid relay number for relay 1");
		return false;
	}
	
	if(relay2Position != -1) 
	{}
	else
	{
		$("#sRelay2").css('border','1px solid red');
		alert("Please select valid relay number for relay 2");
		return false;
	}
		
	if(arrRelayEnd[relay1Position] != relay2)
	{
		$("#sRelay2").css('border','1px solid red');
		alert("Relay Number must be in sequence!");
		return false;
	}
	
	$("#sDeviceIDHID").val(relay1Position);
	
	var positionRelay1	=	$("#positionRelay1").val();
	var positionRelay2	=	$("#positionRelay2").val();
	
	if(positionRelay1 == positionRelay2)
	{
		$("#positionRelay1").css('border','1px solid red');
		$("#positionRelay2").css('border','1px solid red');
		alert("Position should be different!");
		return false;
	}
	else
	{
		$("#positionRelay1").css('border','');
		$("#positionRelay2").css('border','');
	}
	
	return true;
  }
  function checkForm()
  {
	var sPositionName 	= $("#sPositionName").val();
	var sPositionActive = $("input[name='sPositionActive']:checked").val();
	
	if(sPositionName == '')
	{
		alert("Please enter Position Name!");
		return false;
	}
	$("#loadingImg").show();
	
	
	$.ajax({
			type: "POST",
			async:false,
			url: "<?php echo site_url('home/savePositionAjax/');?>", 
			data: {sPositionName:sPositionName,sPositionActive:sPositionActive},
			success: function(data) 
			{
				$("#positionRelay1").append('<option value="'+data+'">'+sPositionName+'</option>');
				$("#positionRelay2").append('<option value="'+data+'">'+sPositionName+'</option>');
				alert("New Position details added successfully!");
				$("#loadingImg").hide();
				parent.$.fancybox.close();
				
			}
		})
	
  }
</script>
