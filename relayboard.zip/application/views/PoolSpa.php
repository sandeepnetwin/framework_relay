<?php
$sAccess 		= '';
$sModule	    = 4;

  //Get Permission Details
  $userID = $this->session->userdata('id');
  $aPermissions = json_decode(getPermissionOfModule($userID));
 
  $aModules 		= $aPermissions->sPermissionModule;	
  $aAllActiveModule = $aPermissions->sActiveModule;
  
  $sAccessKey	= 'access_'.$sModule;
			  
  if(!empty($aModules))
  {
	  if(in_array($sModule,$aModules->ids))
	  {
		 $sAccess 		= $aModules->$sAccessKey;
	  }
  }
  
  if($sAccess == '')
	$sAccess = '2' ; 
  
  if($sAccess == '0') {redirect(site_url('home/'));}
  
  /* echo '<pre>'	;
  print_r($arrDeviceOnPage);
  echo '</pre>'; */
  
  $strMode = $arrGeneral['type'];
  
  $strValveDisabled			=	false;
  $strPumpDisabled			=	false;
  $strLightDisabled			=	false;
  $strBlowerDisabled		=	false;
  $strTemperatureDisabled	=	false;
  
?>
<style>
.tempDetails
{
	font-size:20px;
	margin-top:10px;
}
</style>
<script type="text/javascript">
$(document).ready(function(){
	
	//$(".valveSetting").trigger('click');
	
	$(".valveSetting").click(function(){
		$("#"+$(this).attr('class')+"Link").trigger('click');
	});
	
});
</script>

	<div class="row">
		<div class="col-lg-12">
			<ol class="breadcrumb" style="float:left;">
				  <li><img src="<?php echo HTTP_IMAGES_PATH.'icons/home.png';?>" width="24" style="vertical-align: middle !important;">&nbsp;<a href="<?php echo site_url();?>">Home</a> </li>
				  <li class="active"><?php echo ucfirst($strMode);?> Mode</li>
			</ol>
			<div class="alert alert-success alert-dismissable" style="background-color:#ffb6c1;border-color: #f08080;color: #800000; float: right; height: 100px;width: 100%; font-weight:bold;" >
				Temperature Details: <br />
				<p class="tempDetails">Required Temperature : 50&deg;</p>
				<p class="tempDetails">Current Temperature : 40&deg;</p>
			</div>
		</div>
	</div><!-- /.row -->
	<div class="row">
	<?php if(isset($arrDevice['valve']) && $arrDevice['valve'] == 0)
		  {
			$strValveDisabled = true;
		  }		
	?>
		<div class="col-sm-4" <?php if($strValveDisabled) { echo 'style="opacity:0.5; pointer-events: none;"';}?>>
			<div class="controls boxed controlMode">
				<h2>Valve <?php if($strValveDisabled){ echo '<span style="color:red; float:right;">Not available in this Mode!</span>';}?></h2>
				<?php
					$iValveCnt	=	$arrDevice['valve'];
											
					for($i=0; $i<$iValveCnt; $i++)
					{
				?>
						<div class="rowCheckbox switch">
							<img src="<?php echo HTTP_IMAGES_PATH;?>temp/valve.jpg" width="25%" style="vertical-align:middle;">
							<div class="custom-checkbox" style="float:right; margin-top:20px;"><input type="checkbox" value="<?php echo $i;?>" onclick="checkValveAssign(this.value)" id="relayValve-<?php echo $i?>" name="relayValve[]" hidefocus="true" style="outline: medium none;">
							<label id="lableRelayValve-<?php echo $i?>" for="relayValve-<?php echo $i?>"><span style="color:#C9376E;">Valve <?php echo ($i+1);?></span></label>
							</div>
						</div>
						<div style="height:20px;">&nbsp;</div>
					<?php	
					}
					
					//echo '<div>&nbsp;</div><span style="color:#006400; font-size:12px;">Last Result Pool Mode(Auto) Activated 10/11/2015 20:51 PM</span>';
					
				?>
			</div>
		</div>
	<?php if(isset($arrHeater['heater']) && $arrHeater['heater'] == 0)
		  {
			$strPumpDisabled = true;
		  }		
	?>
		<div class="col-sm-8" <?php if($strPumpDisabled) { echo 'style="opacity:0.5; pointer-events: none;"';}?>>
			<div class="controls boxed controlMode">
			<h2>Heater And Pump <?php if($strPumpDisabled){ echo '<span style="color:red; float:right;">Not available in this Mode!</span>';}?></h2>
			<?php
				if(isset($arrHeater['heater']) && $arrHeater['heater'] != 0)
				{
					
					$iHeaterCnt	=	$arrHeater['heater'];
					for($i=0;$i<$iHeaterCnt;$i++)
					{
			?>
					<!--<div style="margin-bottom:10px;">
						<img src="<?php echo HTTP_IMAGES_PATH;?>icons/water-heater.png" width="80" style="vertical-align:middle;">
						<span style="margin-right:30px;">Heater <?php echo ($i+1);?>&nbsp;&nbsp;<span style="font-weight:bold;color:#FF0000;">Temperature:50F</span></span>
						<img src="<?php echo HTTP_IMAGES_PATH;?>temp/pump.jpg" width="80" style="vertical-align:middle;">
					</div>-->
					
					<div class="rowCheckbox switch">
						<img src="<?php echo HTTP_IMAGES_PATH;?>temp/pump.jpg" width="15%" style="vertical-align:middle;">
						<div class="custom-checkbox" style="float:right; margin-top:20px;"><input type="checkbox" value="<?php echo $i;?>" onclick="checkValveAssign(this.value)" id="relayValve-<?php echo $i?>" name="relayValve[]" hidefocus="true" style="outline: medium none;">
						<label id="lableRelayValve-<?php echo $i?>" for="relayValve-<?php echo $i?>"><span style="color:#C9376E;">Pump <?php echo ($i+1);?></span></label>
						</div>
					</div>
					<div class="rowCheckbox switch">
						<img src="<?php echo HTTP_IMAGES_PATH;?>icons/water-heater.png" width="15%" style="vertical-align:middle;">
						<div class="custom-checkbox" style="float:right; margin-top:20px;"><input type="checkbox" value="<?php echo $i;?>" onclick="checkValveAssign(this.value)" id="relayValve-<?php echo $i?>" name="relayValve[]" hidefocus="true" style="outline: medium none;">
						<label id="lableRelayValve-<?php echo $i?>" for="relayValve-<?php echo $i?>"><span style="color:#C9376E;">Heater <?php echo ($i+1);?></span></label>
						</div>
					</div>
					<div style="height:20px;"><hr /></div>
					
			<?php   }
				}
			?>
			</div>
		</div>
		
		<?php
			/* echo '<pre>';
			print_r($arrMore);
			echo '</pre>'; */
		?>
		<div class="col-sm-4">
			<div class="controls boxed controlMode">
			<h2>Light</h2>
			<?php for($i=0;$i<$arrMore['light'];$i++){ ?>
				<div class="rowCheckbox switch">
					<img src="<?php echo HTTP_IMAGES_PATH;?>icons/light_off.png" width="25%" style="vertical-align:middle;">
					<div class="custom-checkbox" style="float:right; margin-top:20px;"><input type="checkbox" value="<?php echo $i;?>" onclick="checkValveAssign(this.value)" id="relayValve-<?php echo $i?>" name="relayValve[]" hidefocus="true" style="outline: medium none;">
					<label id="lableRelayValve-<?php echo $i?>" for="relayValve-<?php echo $i?>"><span style="color:#C9376E;">Light <?php echo ($i+1);?></span></label>
					</div>
				</div>
				<div style="height:20px;">&nbsp;</div>	
			<?php } ?>
			</div>
		</div>
		
		<div class="col-sm-4">
			<div class="controls boxed controlMode">
			<h2>Blower</h2>
			<?php for($i=0;$i<$arrMore['blower'];$i++){ ?>
				<div class="rowCheckbox switch">
					<img src="<?php echo HTTP_IMAGES_PATH;?>icons/blower.png" width="25%" style="vertical-align:middle;">
					<div class="custom-checkbox" style="float:right; margin-top:20px;"><input type="checkbox" value="<?php echo $i;?>" onclick="checkValveAssign(this.value)" id="relayValve-<?php echo $i?>" name="relayValve[]" hidefocus="true" style="outline: medium none;">
					<label id="lableRelayValve-<?php echo $i?>" for="relayValve-<?php echo $i?>"><span style="color:#C9376E;">Blower <?php echo ($i+1);?></span></label>
					</div>
				</div>
				<div style="height:20px;">&nbsp;</div>
			<?php } ?>
			</div>
		</div>
		
		<div class="col-sm-4">
			<div class="controls boxed controlMode">
			<h2>Miscellenious Device</h2>
			<?php for($i=0;$i<$arrMore['misc'];$i++){ ?>
				<div class="rowCheckbox switch">
					<img src="<?php echo HTTP_IMAGES_PATH;?>icons/misc.png" width="25%" style="vertical-align:middle;">
					<div class="custom-checkbox" style="float:right; margin-top:20px;"><input type="checkbox" value="<?php echo $i;?>" onclick="checkValveAssign(this.value)" id="relayValve-<?php echo $i?>" name="relayValve[]" hidefocus="true" style="outline: medium none;">
					<label id="lableRelayValve-<?php echo $i?>" for="relayValve-<?php echo $i?>"><span style="color:#C9376E;">Misc Device <?php echo ($i+1);?></span></label>
					</div>
				</div>
				<div style="height:20px;">&nbsp;</div>
			<?php } ?>
			</div>
		</div>
	</div>


