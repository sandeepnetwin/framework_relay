<?php

  $sAccess 		= '';
  $sModule	    = 4;

  //Get Permission Details
  $userID = $this->session->userdata('id');
  $aPermissions = json_decode(getPermissionOfModule($userID));
 
  $aModules 		= $aPermissions->sPermissionModule;	
  $aAllActiveModule = $aPermissions->sActiveModule;
  
  $sAccessKey	= 'access_'.$sModule;
			  
  if(!empty($aModules))
  {
	  if(in_array($sModule,$aModules->ids))
	  {
		 $sAccess 		= $aModules->$sAccessKey;
	  }
  }
  
  if($sAccess == '')
	$sAccess = '2' ; 
  
  if($sAccess == '0') {redirect(site_url('home/'));}
  
  $strMode = $arrGeneral['type'];
  
  $strValveDisabled			=	false;
  $strPumpDisabled			=	false;
  $strLightDisabled			=	false;
  $strBlowerDisabled		=	false;
  $strTemperatureDisabled	=	false;
  
  /* echo '<pre>';
  print_r($arrGeneral);
  echo '</pre>'; */
  
  $modeType			=	$arrGeneral['type'];
  $modeManualTime	=	'';
  $temprature		=	'';
  if($modeType == 'pool')
  {
	$modeManualTime	=	$arrGeneral['pool_manual'];
	$temprature		=	$arrGeneral['pool_temp'];
  }
  else if($modeType == 'spa')
  {
	$modeManualTime	=	$arrGeneral['spa_manual']; 	  
	$temprature		=	$arrGeneral['spa_temperature']; 	  
  }
  else
  {
	if($arrGeneral['pool_manual'] >= $arrGeneral['spa_manual'])
		$modeManualTime	=	$arrGeneral['pool_manual'];
    else	
		$modeManualTime	=	$arrGeneral['spa_manual'];

	if($arrGeneral['pool_temp'] >= $arrGeneral['spa_temperature'])
	  $temprature		=	$arrGeneral['pool_temp'];
    else
	  $temprature		=	$arrGeneral['spa_temperature'];
  }
  
  
  
?>
<style>
.tempDetails
{
	font-size:120%;
	margin-top:10px;
}
a#quickSettingLink:hover
{
	color:#006400 !important;
}
.inputText
{
    height:35px !important;
}
@media (max-width:480px)
{
	.customTempBox
	{
		width:100% !important;
	}
	.customHeater
	{
		margin-top:0px !important;
	}
}

</style>
<script type="text/javascript" src="<?php echo HTTP_ASSETS_PATH.'fancybox/source/jquery.fancybox.js?v=2.1.5';?>"></script>
<link rel="stylesheet" type="text/css" href="<?php echo HTTP_ASSETS_PATH.'fancybox/source/jquery.fancybox.css?v=2.1.5';?>" media="screen" />
<script type="text/javascript">
var $a = $.noConflict();
$a(document).ready(function() {
    $a('.fancyboxLoading').fancybox({
								width:250,
								height:25,
								autoSize : false,
								fitToView: false, // set the specific size without scaling to the 
								minWidth : 200, // or whatever, default is 100
								minHeight: 20, // default 100
								'closeBtn' : false,
								'helpers': {'overlay' : {'closeClick': false, overlay : null}}
							});
	$a('.fancyboxSetting').fancybox({'width':650,
                         'height':450,
                         'autoSize' : false,
						 beforeShow: function(){
							<?php //if($modeType == 'pool') { ?>
								//$a(".spa").hide();
							<?php //} ?>
							
							<?php //if($modeType == 'spa') { ?>
								//$a(".pool").hide();
							<?php //} ?>
						 }
						 });						 
							 
});

</script>	
<link href="<?php echo HTTP_ASSETS_PATH.'progressbar/css/static.css';?>" rel="stylesheet"/>
<script src="<?php echo HTTP_ASSETS_PATH.'progressbar/js/static.min.js';?>"></script>
<script src="<?php echo HTTP_ASSETS_PATH.'progressbar/dist/js/jquery.progresstimer.js';?>"></script>

<script type="text/javascript">
$(document).ready(function(){
	
	/* setInterval( function() {
		$.ajax({
				type: "POST",
				url: "<?php echo site_url('analog/checkTempAndTime/');?>", 
				data: {mode:'<?php echo $iActiveMode;?>',modeType:'<?php echo $modeType;?>',modeManualTime:'<?php echo $modeManualTime;?>',temprature:'<?php echo $temprature;?>'},
				success: function(data) {
					
					//console.log(data);
					$('#currentTemprature').html(data);
				}
		});
	},30000); */
	
	
	setInterval( function() {
		$.ajax({
				type: "POST",
				url: "<?php echo site_url('analog/getDeviceStatusUpdate/');?>", 
				data: {},
				success: function(data) {
					
					var deviceStatus = jQuery.parseJSON( data );
					var valveDevice	 = deviceStatus.valve;
					var pumpDevice	 = deviceStatus.pump;
					var heaterDevice = deviceStatus.heater;
					var lightDevice	 = deviceStatus.light;
					var blowerDevice = deviceStatus.blower;
					var miscDevice	 = deviceStatus.misc;
					
					/* $.each( lightDevice, function( key, value ) 
					{
						if(value == '1')
						{
							if(!$("#lableRelayLight-"+key).hasClass('checked'))
							{
								$("#lableRelayLight-"+key).addClass('checked');
								$("#lightImage_"+key).attr('src','<?php echo HTTP_IMAGES_PATH."icons/light_on.png";?>');
							}
						}
						else if(value == '0')
						{
							if($("#lableRelayLight-"+key).hasClass('checked'))
							{
								$("#lableRelayLight-"+key).removeClass('checked');
								$("#lightImage_"+key).attr('src','<?php echo HTTP_IMAGES_PATH."icons/light_off.png";?>');
							}
						}
						
					}); */
					
					$.each( deviceStatus, function( key, value ) 
					{
						if(key != 'valve')
						{
							var lableText	=	'';
							if(key == 'light')
							{
								lableText	=	'lableRelayLight-';
							}
							if(key == 'blower')
							{
								lableText	=	'lableRelayBlower-';
							}
							if(key == 'misc')
							{
								lableText	=	'lableRelayMisc-';
							}
							if(key == 'heater')
							{
								lableText	=	'lableRelayHeater-';
							}
							if(key == 'pump')
							{
								lableText	=	'lablePump-';
							}
							
							$.each( value, function( iDevice, sStatus ) 
							{
								if(sStatus == '1')
								{
									if(!$("#"+lableText+iDevice).hasClass('checked'))
									{
										$("#"+lableText+iDevice).addClass('checked');
										if(key == 'light')
										$("#lightImage_"+iDevice).attr('src','<?php echo HTTP_IMAGES_PATH."icons/light_on.png";?>');
									}
								}
								else if(sStatus == '0')
								{
									if($("#"+lableText+iDevice).hasClass('checked'))
									{
										$("#"+lableText+iDevice).removeClass('checked');
										if(key == 'light')
										$("#lightImage_"+iDevice).attr('src','<?php echo HTTP_IMAGES_PATH."icons/light_off.png";?>');
									}
								}
							});
							
						}
						
					});
					
					
					//$('#currentTemprature').html(data);
				}
		});
	},30000);
	
	$(".valveSetting").click(function(){
		$("#"+$(this).attr('class')+"Link").trigger('click');
	});
	
	
	$(".pumpsButton").click(function()
	{
		var relayNumber = $(this).val();
		var id			= $(this).attr('id').split("_");
		var ipID		= id[1];
		var status		= '';
		if($("#lablePump-"+relayNumber+"-"+ipID).hasClass('checked'))
		{	
			status	=	0;
		}
		else
		{
			status = 1;
		}
		if(status	==	1)
		{
			$(".loading-progress").show();
			var progress = $(".loading-progress").progressTimer({
					timeLimit: 10,
					onFinish: function () {
						//$(".loading-progress").hide();
						parent.$a.fancybox.close();
					}
			});
			
			
			$a("#checkLink").trigger('click');
		
			$.ajax({
				type: "POST",
				url: "<?php echo site_url('home/updateStatusOnOff/');?>", 
				data: {sName:relayNumber,sStatus:status,sDevice:'PS',sIdIP:ipID},
				success: function(data) {
					
					if($("#lablePump-"+relayNumber+"-"+ipID).hasClass('checked'))
					{	
						$("#lablePump-"+relayNumber+"-"+ipID).removeClass('checked');
					}
					else
					{
						$("#lablePump-"+relayNumber+"-"+ipID).addClass('checked');
					}
				}
			}).error(function(){
				progress.progressTimer('error', {
					errorText:'ERROR!',
					onFinish:function(){
						alert('There was an error processing your information!');
					}
				});
			}).done(function(){
					progress.progressTimer('complete');
			});
		}
	});
	
	$(".heaterButton").click(function()
	{
        var chkVal      = $(this).val();
        var arrDetails	= chkVal.split("|||");	
        
        var lightNumber = arrDetails[0];
        var relayNumber = arrDetails[2];
		var relatedPump = arrDetails[3];
		var ipID		= arrDetails[4];		
        var sDevice     = '';
        
        if(arrDetails[1] == '24')
            sDevice     =   'R';    
        else if(arrDetails[1] == '12')
            sDevice     =   'P';
        
        var status		= '';
        if($("#lableRelayHeater-"+lightNumber+"-"+ipID).hasClass('checked'))
        {	
                status	=	0;
        }
        else
        {
                status = 1;
        }
		
		if(!$("#lablePump-"+relatedPump+"-"+ipID).hasClass('checked'))
		{
			alert("Please first make the PUMP ON before making Heater ON.");
			return false;
		}
		
		if(status	==	1)
		{
			$(".loading-progress").show();
			var progress = $(".loading-progress").progressTimer({
					timeLimit: 10,
					onFinish: function () {
						//$(".loading-progress").hide();
						parent.$a.fancybox.close();
					}
			});
			
			
			$a("#checkLink").trigger('click');

			$.ajax({
				type: "POST",
				async:false,
				url: "<?php echo site_url('home/updateStatusOnOff/');?>", 
				data: {sName:relayNumber,sStatus:status,sDevice:sDevice,sIdIP:ipID},
				success: function(data) {
						if($("#lableRelayHeater-"+lightNumber+"-"+ipID).hasClass('checked'))
						{	
								$("#lableRelayHeater-"+lightNumber+"-"+ipID).removeClass('checked');
						}
						else
						{
								$("#lableRelayHeater-"+lightNumber+"-"+ipID).addClass('checked');
						}
						
				}
			}).error(function(){
				progress.progressTimer('error', {
					errorText:'ERROR!',
					onFinish:function(){
						alert('There was an error processing your information!');
					}
				});
			}).done(function(){
					progress.progressTimer('complete');
			});
		}
    });
	
	$(".lightButton").click(function()
	{
        var chkVal      = $(this).val();
        var arrDetails	= chkVal.split("|||");	
        
        var lightNumber = arrDetails[0];
        var relayNumber = arrDetails[2];
        var ipID		= arrDetails[3];
		
        var sDevice     = '';
        
        if(arrDetails[1] == '24')
            sDevice     =   'R';    
        else if(arrDetails[1] == '12')
            sDevice     =   'P';
        
        $(".loading-progress").show();
        var progress = $(".loading-progress").progressTimer({
                timeLimit: 10,
                onFinish: function () {
                    //$(".loading-progress").hide();
                    parent.$a.fancybox.close();
                }
        });
        
        
        $a("#checkLink").trigger('click');

        var status		= '';
        if($("#lableRelayLight-"+lightNumber+"-"+ipID).hasClass('checked'))
        {	
                status	=	0;
        }
        else
        {
                status = 1;
        }

		$.ajax({
			type: "POST",
			url: "<?php echo site_url('home/updateStatusOnOff/');?>", 
			data: {sName:relayNumber,sStatus:status,sDevice:sDevice,sIdIP:ipID},
			success: function(data) {
					if($("#lableRelayLight-"+lightNumber+"-"+ipID).hasClass('checked'))
					{	
							$("#lableRelayLight-"+lightNumber+"-"+ipID).removeClass('checked');
							$("#lightImage_"+lightNumber+"_"+ipID).attr('src','<?php echo HTTP_IMAGES_PATH."icons/light_off.png";?>');
							
					}
					else
					{
							$("#lableRelayLight-"+lightNumber+"-"+ipID).addClass('checked');
							$("#lightImage_"+lightNumber+"_"+ipID).attr('src','<?php echo HTTP_IMAGES_PATH."icons/light_on.png";?>');
					}

			}
        }).error(function(){
            progress.progressTimer('error', {
                errorText:'ERROR!',
                onFinish:function(){
                    alert('There was an error processing your information!');
                }
            });
        }).done(function(){
                progress.progressTimer('complete');
        });
    });
	
	$(".blowerButton").click(function()
	{
        var chkVal      = $(this).val();
        var arrDetails	= chkVal.split("|||");	
        
        var lightNumber = arrDetails[0];
        var relayNumber = arrDetails[2];
		var ipID		= arrDetails[3];
        var sDevice     = '';
        
        if(arrDetails[1] == '24')
            sDevice     =   'R';    
        else if(arrDetails[1] == '12')
            sDevice     =   'P';
        
        $(".loading-progress").show();
        var progress = $(".loading-progress").progressTimer({
                timeLimit: 10,
                onFinish: function () {
                    //$(".loading-progress").hide();
                    parent.$a.fancybox.close();
                }
        });
        
        
        $a("#checkLink").trigger('click');

        var status		= '';
        if($("#lableRelayBlower-"+lightNumber+"-"+ipID).hasClass('checked'))
        {	
                status	=	0;
        }
        else
        {
                status = 1;
        }


		$.ajax({
			type: "POST",
			url: "<?php echo site_url('home/updateStatusOnOff/');?>", 
			data: {sName:relayNumber,sStatus:status,sDevice:sDevice,sIdIP:ipID},
			success: function(data) {
					if($("#lableRelayBlower-"+lightNumber+"-"+ipID).hasClass('checked'))
					{	
							$("#lableRelayBlower-"+lightNumber+"-"+ipID).removeClass('checked');
					}
					else
					{
							$("#lableRelayBlower-"+lightNumber+"-"+ipID).addClass('checked');
					}

			}
        }).error(function(){
            progress.progressTimer('error', {
                errorText:'ERROR!',
                onFinish:function(){
                    alert('There was an error processing your information!');
                }
            });
        }).done(function(){
                progress.progressTimer('complete');
        });
    });
	
	$(".miscButton").click(function()
	{
        var chkVal      = $(this).val();
        var arrDetails	= chkVal.split("|||");	
        
        var miscNumber = arrDetails[0];
        var relayNumber = arrDetails[2];
		var ipID		= arrDetails[3];
        var sDevice     = '';
        
        if(arrDetails[1] == '24')
            sDevice     =   'R';    
        else if(arrDetails[1] == '12')
            sDevice     =   'P';
        
        $(".loading-progress").show();
        var progress = $(".loading-progress").progressTimer({
                timeLimit: 10,
                onFinish: function () {
                    //$(".loading-progress").hide();
                    parent.$a.fancybox.close();
                }
        });
        
        
        $a("#checkLink").trigger('click');

        var status		= '';
        if($("#lableRelayMisc-"+miscNumber+"-"+ipID).hasClass('checked'))
        {	
                status	=	0;
        }
        else
        {
                status = 1;
        }


		$.ajax({
			type: "POST",
			url: "<?php echo site_url('home/updateStatusOnOff/');?>", 
			data: {sName:relayNumber,sStatus:status,sDevice:sDevice,sIdIP:ipID},
			success: function(data) {
					if($("#lableRelayMisc-"+miscNumber+"-"+ipID).hasClass('checked'))
					{	
							$("#lableRelayMisc-"+miscNumber+"-"+ipID).removeClass('checked');
					}
					else
					{
							$("#lableRelayMisc-"+miscNumber+"-"+ipID).addClass('checked');
					}

			}
        }).error(function(){
            progress.progressTimer('error', {
                errorText:'ERROR!',
                onFinish:function(){
                    alert('There was an error processing your information!');
                }
            });
        }).done(function(){
                progress.progressTimer('complete');
        });
    });
	
});

function showSelected(mode)
{
	if(mode != '')
	{
		$("[id^=sel_]").css('border','');
		$("#sel_"+mode).css('border','2px solid #000');
		$("#mode_type").val(mode);
		
		if(mode == 'pool')
		{
			$("#spa_maximum_temperature").attr('disabled','disabled');
			$("#spa_desire_temperature").attr('disabled','disabled');
			$("#spa_time").attr('disabled','disabled');
			$("#pool_maximum_temperature").removeAttr('disabled');
			$("#pool_desire_temperature").removeAttr('disabled');
			$("#pool_time").removeAttr('disabled');
		}
		else if(mode == 'spa')
		{
			$("#pool_maximum_temperature").attr('disabled','disabled');
			$("#pool_desire_temperature").attr('disabled','disabled');
			$("#pool_time").attr('disabled','disabled');
			$("#spa_maximum_temperature").removeAttr('disabled');
			$("#spa_desire_temperature").removeAttr('disabled');
			$("#spa_time").removeAttr('disabled');
		}
		else if(mode == 'both')
		{
			$("#pool_maximum_temperature").removeAttr('disabled');
			$("#pool_desire_temperature").removeAttr('disabled');
			$("#pool_time").removeAttr('disabled');
			$("#spa_maximum_temperature").removeAttr('disabled');
			$("#spa_desire_temperature").removeAttr('disabled');
			$("#spa_time").removeAttr('disabled');
		}
	}
}

function saveQuickSetting()
{
	var type 			= $("#mode_type").val();
	var pool_max 		= $("#pool_maximum_temperature").val();
	var pool_des 		= $("#pool_desire_temperature").val();
	var pool_man 		= $("#pool_time").val();
	var spa_max 		= $("#spa_maximum_temperature").val();
	var spa_des 		= $("#spa_desire_temperature").val();
	var spa_man 		= $("#spa_time").val();
	var temperature1	= $("#temperature1").val();
	var temperature2	= $("#temperature1").val();
	
	var err = '';
	if(type == '')
	{
		err += 'Please select Mode!\n';
	}
	if(temperature1 == '')
	{
		err += 'Please select Temperature Sensor1!\n';
	}
	if(temperature2 == '')
	{
		err += 'Please select Temperature Sensor2!\n';
	}
	
	if(type != '' && (type == 'pool' || type == 'both'))
	{
		if(pool_max == '')
		{
			err += 'Please enter Pool Maximum Temperature!\n';
		}
		if(pool_des == '')
		{
			err += 'Please enter Pool Desire Temperature!\n';
		}
		if(pool_man == '')
		{
			err += 'Please enter Pool Manual Time!\n';
		}
	}
	
	if(type != '' && (type == 'spa' || type == 'both'))
	{
		if(spa_max == '')
		{
			err += 'Please enter Spa Maximum Temperature!\n';
		}
		if(spa_des == '')
		{
			err += 'Please enter Spa Desire Temperature!\n';
		}
		if(spa_man == '')
		{
			err += 'Please enter Spa Manual Time!\n';
		}
	}
	
	if(err != '')
	{
		alert('Please check below errors : \n\n'+err);
		return false;
	}
	else
	{
		arrQuickSetting		=	{'type': type, 'pool_max' : pool_max, 'pool_des':pool_des,'pool_man':pool_man,'spa_max':spa_max,'spa_des':spa_des,'spa_man':spa_man,'temperature1':temperature1,'temperature2':temperature2};
		
		$.ajax({
		type: "POST",
		url: "<?php echo site_url('analog/saveQuickSetting/');?>", 
		data: {general:JSON.stringify(arrQuickSetting)},
		success: function(data) {
				alert('Details saved successfully!');
				location.reload();
			}
		});
		
	}
}
function refreshDeviceStatus(sDevice)
	{
		if(sDevice == '')
		{
			alert("Not Valid Device Type!");
			return false;
		}
		else
		{
			var IpId	= $("#IpId").val();	
			$("#refreshLoading_"+sDevice).css('display','flex').show();
			
			setTimeout( function(){
			$.ajax({
						type: "POST",
						url: "<?php echo site_url('home/refreshDeviceStatus/');?>", 
						data: {sDevice:sDevice,IpId:IpId},
						success: function(data) 
						{
							var deviceStatus = jQuery.parseJSON(data);
							var lableText   = '';
							
							if(sDevice == 'R')
							{
								lableText = 'lableRelay-';
							}
							else if(sDevice == 'P')
							{
								lableText = 'lablePower-';
							}
							else if(sDevice == 'PS')
							{
								lableText = 'lablePump-';
							}
							
							$.each( deviceStatus, function( iDevice, sStatus ) 
							{
								if(sDevice != 'V' && sDevice != 'PS')
								{
									if(sStatus >= '1')
									{
										if(!$("#"+lableText+iDevice+"-"+IpId).hasClass('checked'))
										{
											$("#"+lableText+iDevice+"-"+IpId).addClass('checked');
										}
									}
									else if(sStatus == '0')
									{
										if($("#"+lableText+iDevice+"-"+IpId).hasClass('checked'))
										{
											$("#"+lableText+iDevice+"-"+IpId).removeClass('checked');
										}
									}
								}
								else if(sDevice == 'V')
								{
									var current = $('#switch-me-'+iDevice+'-'+IpId).val();
									if(current != sStatus.status)
									{
										$('#switch-me-'+iDevice+'-'+IpId).val(sStatus.status).change();
										$('#switch-me-'+iDevice+'-'+IpId+'-all').val(sStatus.status).change();
									}
									
									$('#lastRun_'+iDevice+'_'+IpId).html(sStatus.lastPosition+" !");
									$('#lastRun_'+iDevice+'_'+IpId+'_all').html(sStatus.lastPosition+" !");
								}
								else if(sDevice == 'PS')
								{
									if(sStatus >= '1')
									{
										if(!$("#"+lableText+iDevice+"-"+IpId).hasClass('checked'))
										{
											$("#"+lableText+iDevice+"-"+IpId).addClass('checked');
										}
										
										//START : Get Latest Response.
										$.getJSON('<?php echo site_url('cron/pumpResponseLatest/');?>', {iPumpID: iDevice,sIpId : IpId}, function(json) {
										
											if(json == '')
											{
												$("#pumpRealResponse_"+iDevice+"_"+IpId).html('');
												$("#pumpProgrmaStatus_"+iDevice+"_"+IpId).html('');
											}
											else
											{
												$("#pumpRealResponse_"+iDevice+"_"+IpId).html(json);
												if($("#lablePump-"+iDevice+"-"+IpId).hasClass('checked'))
												{}
												else
												{
													$("#lablePump-"+iDevice+"-"+IpId).addClass('checked');
												}
											}
										});
										//END : Get Latest Response.
										
										//START:Pump Program Information.
											$.getJSON('<?php echo site_url('cron/getPumpProgramStatus/');?>', {iPumpID: iDevice,sIpId : IpId}, function(json) {
											
												if(json == '')
												{
													$("#pumpProgrmaStatus_"+iDevice+"_"+IpId).html('');
												}
												else
												{
													$("#pumpProgrmaStatus_"+iDevice+"_"+IpId).html(json);
												}
											});
										//START:Pump Program Information.	
									}
									else if(sStatus == '0')
									{
										if($("#"+lableText+iDevice+"-"+IpId).hasClass('checked'))
										{
											$("#"+lableText+iDevice+"-"+IpId).removeClass('checked');
										}
									}
								}
								
							});
							
							$("#refreshLoading_"+sDevice).css('display','none');
						}
					});
			},500);
		}
		
	}
</script>

	<div class="row">
		<div class="col-lg-12">
			<ol class="breadcrumb" style="float:left;">
				  <li><img src="<?php echo HTTP_IMAGES_PATH.'icons/home.png';?>" width="24" style="vertical-align: middle !important;">&nbsp;<a href="<?php echo site_url();?>">Home</a> </li>
				  <li class="active"><?php echo ucfirst($strMode);?> Mode</li>
			</ol>
			<div class="alert alert-success alert-dismissable customTempBox" style="border:2px solid #006400;color: #006400; float: right; font-weight:bold;" >
				Temperature Details: <a style="color:#006400;" title="Quick Setting" class="fancyboxSetting" id="quickSettingLink" href="#quickSettingForm"><span style="float: right;margin-right: -40px;margin-top: -10px;"><i class="glyphicon glyphicon-cog"></i></span></a><br />
				<p class="tempDetails">Required Temperature : <?php echo $temprature;?>F</p>
				<p class="tempDetails">Current Temperature : <span id="currentTemprature">-</span>F</p>

			</div>
		</div>
	</div><!-- /.row -->
	
	<div class="row">
	<?php if(isset($arrDevice['valve']) && $arrDevice['valve'] == 0)
		  {
			$strValveDisabled = true;
		  }		
	?>
		<div class="col-sm-4" <?php if($strValveDisabled) { echo 'style="opacity:0.5; pointer-events: none;"';}?>>
			<div class="controls boxed controlMode">
			<div class="refreshLoading" id="refreshLoading_V" style="width:80%;height:40px;position:relative;"><img src="<?php echo base_url("assets/images/loading.gif");?>" alt="loading">&nbsp;Refreshing Devices....</div>
			<div class="widget-title" style="float:right;">
				<a href="javascript:void(0);" class="link-refresh" id="link-refresh-1" onclick="refreshDeviceStatus('V');"><span class="glyphicon glyphicon-refresh"></span></a>
			</div>
				<h2>Valve <?php if($strValveDisabled){ echo '<span style="color:red; float:right;">Not available in this Mode!</span>';}?></h2>
				<link href="<?php echo site_url('assets/switchy/switchy.css'); ?>" rel="stylesheet" />
				<script type="text/javascript" src="<?php echo site_url('assets/switchy/switchy.js'); ?>"></script>
				<script type="text/javascript" src="<?php echo site_url('assets/switchy/jquery.event.drag.js'); ?>"></script>
				<script type="text/javascript" src="<?php echo site_url('assets/switchy/jquery.animate-color.js'); ?>"></script>
				<script>
				var iActiveMode = '<?php echo $iActiveMode;?>';
				var sAccess 	= '<?php echo $sAccess;?>';
				</script>
				<table class="table table-hover">
				<?php
					$iValveCnt		=	$arrDevice['valve'];
					$aValveAssign	=	unserialize($arrDevice['valveAssign']);
					$iValveCnt		=	count($aValveAssign);
											
					//for($i=0; $i<$iValveCnt; $i++)
					foreach($aValveAssign as $Valve)	
					{
						$arrTempValve	=	explode("_",$Valve);
						$i				=	$arrTempValve[0];
						$ipID			=	$arrTempValve[1];
						
						$iValvesVal = ${"sValves".$ipID}[$i];
						
						$iValvesNewValSb1 = 1;
						$iValvesNewValSb2 = 2 ;
						if($iValvesVal == 1)
						{
						  $iValvesNewValSb1 = 0;
						}
						if($iValvesVal == 2)
						{
						  $iValvesNewValSb2 = 1;
						}
						$sValvesVal1 = false;
						$sValvesVal2 = false;
						if($iValvesVal == 1)
						  $sValvesVal1 = true;
						if($iValvesVal == 2)
						  $sValvesVal2 = true;
						
						$sValvesNameDb =  $this->home_model->getDeviceName($i,'V',$ipID);
						if($sValvesNameDb == '')
						  $sValvesNameDb = 'Valve '.$i;
						
						//START : Get Valve Position Details.
						$aPositionName   =  $this->home_model->getPositionName($i,'V',$ipID);
						
						$strPosition1 = '';
						$strPosition2 = '';
						
						if($aPositionName[0] != '')
						$strPosition1	 =	$this->home_model->getPositionNameFromID($aPositionName[0]);
						if($aPositionName[1] != '')
						$strPosition2	 =	$this->home_model->getPositionNameFromID($aPositionName[1]);
						//END : Get Valve Position Details.
						
						$aRelayNumber    =  json_decode($this->home_model->getValveRelayNumber($i,'V',$ipID));
						
						if($iValvesVal == '.' || $iValvesVal == '')
							continue;
						
				?>		
						<tr>
							<td colspan="3" style="border-top:none;">
								<div style="margin-top: 10px;margin-bottom: 10px;"><strong><span style="color:#C9376E;"><?php echo $sValvesNameDb; ?></span></strong></div>
							</td>
						</tr>
						<!--<div class="row">
						<div class="col-sm-12">-->
						<tr style="border-bottom: 1px solid #ccc;">
							<td width="33%" style="border-top:none;">						
								<div class="span1 valve-<?php echo $i?>-<?php echo $ipID;?>" value="1" style="margin-top: 10px; width: auto; color: #428BCA;font-weight: bold; cursor: pointer; float: left;"><?php echo $strPosition1; ?></div>
							</td>
							<td width="34%" style="border-top:none;">						
							<div class="span2" style="margin-left:5px; margin-right:5px; float: left;" >
								<select id='switch-me-<?php echo $i;?>-<?php echo $ipID;?>'>
								<option value='1' <?php if($iValvesVal == '1') { echo 'selected="selected"';} ?>>Spa</option>
								<option value='0' <?php if($iValvesVal == '0' || $iValvesVal == '') { echo 'selected="selected"';} ?>></option>
								<option value='2' <?php if($iValvesVal == '2') { echo 'selected="selected"';} ?>>Pool</option>
								</select>
								<div class="valve-<?php echo $i?>-<?php echo $ipID;?>" value="0" id="off-<?php echo $i;?>-<?php echo $ipID;?>" style="color: red;font-weight: bold;width: 0; margin-left: 30px; cursor: pointer;">
								OFF
								</div>
							</div>
							</td>
							<td width="33%" style="border-top:none;">
								<div class="span1 valve-<?php echo $i?>-<?php echo $ipID;?>" value="2" style="margin-top: 10px; width: auto; color: #428BCA;font-weight: bold; cursor: pointer; float: right;text-align:right;"><?php echo $strPosition2; ?></div>
							</td>
						</tr>						
						
						<!--</div>
						</div>-->
						<script type="text/javascript">
						  $(function()
						  {
								var bgColor = '#E8E8E8';
								<?php if($iValvesVal == '1' || $iValvesVal == '2') { ?>
										bgColor = '#45A31F';
								<?php } else { ?>
										bgColor = '#E8E8E8';
								<?php } ?>
								
								$('#switch-me-<?php echo $i;?>-<?php echo $ipID;?>').switchy();
								
								$('.valve-<?php echo $i?>-<?php echo $ipID;?>').on('click', function(event){
									//event.preventDefault();
									//return false;
									$('#switch-me-<?php echo $i;?>-<?php echo $ipID;?>').val($(this).attr('value')).change();
								});
								
								$('#switch-me-<?php echo $i;?>-<?php echo $ipID;?>').next('.switchy-container').find('.switchy-bar').animate({
										backgroundColor: bgColor
									});
								
								$('#switch-me-<?php echo $i;?>-<?php echo $ipID;?>').on('change', function(event)
								{
									if(sAccess == 2)
									{
										if(iActiveMode != 2)
										{
											var bConfirm	=	confirm('You will need to change to Manual mode to make this change.\nWould you like to activate manual mode?' );
											if(bConfirm)
											{
												$.ajax({
													type: "POST",
													url: "<?php echo site_url('analog/changeMode');?>", 
													data: {iMode:'2'},
													success: function(data) {
													}
												});
												//event.preventDefault();
												//return false;
												// Animate Switchy Bar background color
												var bgColor = '#E8E8E8';

												if ($(this).val() == '1' || $(this).val() == '2')
												{
													bgColor = '#45A31F';
												} 
												$('#switch-me-<?php echo $i;?>-<?php echo $ipID;?>').next('.switchy-container').find('.switchy-bar').animate({
													backgroundColor: bgColor
												});
											
												
												//$("#loading_valve_<?php //echo $i;?>").css('visibility','visible');
												$.ajax({
													type: "POST",
													url: "<?php echo site_url('home/updateStatusOnOff');?>", 
													data: {sName:'<?php echo $i;?>',sStatus:$(this).val(),sDevice:'<?php echo 'V';?>',sIdIP:'<?php echo $ipID;?>'},
													success: function(data) {
													//$("#loading_valve_<?php //echo $i;?>").css('visibility','hidden');
													location.reload();
													}

												});
											}
										}
										else											
										{
											//event.preventDefault();
											//return false;
											// Animate Switchy Bar background color
											var bgColor = '#E8E8E8';

											if ($(this).val() == '1' || $(this).val() == '2')
											{
												bgColor = '#45A31F';
											} 
											$('#switch-me-<?php echo $i;?>-<?php echo $ipID;?>').next('.switchy-container').find('.switchy-bar').animate({
												backgroundColor: bgColor
											});
										
											
											//$("#loading_valve_<?php //echo $i;?>").css('visibility','visible');
											$.ajax({
												type: "POST",
												url: "<?php echo site_url('home/updateStatusOnOff');?>", 
												data: {sName:'<?php echo $i;?>',sStatus:$(this).val(),sDevice:'V',sIdIP:'<?php echo $ipID;?>'},
												success: function(data) {
												//$("#loading_valve_<?php //echo $i;?>").css('visibility','hidden');
												}

											});
										}
									}
								});
							});
						</script>
					<?php	
					}
					
					//echo '<div>&nbsp;</div><span style="color:#006400; font-size:12px;">Last Result Pool Mode(Auto) Activated 10/11/2015 20:51 PM</span>';
					
				?>
				</table>
			</div>
		</div>
	<?php if(isset($arrHeater['heater']) && $arrHeater['heater'] == 0)
		  {
			$strPumpDisabled = true;
		  }	
			//echo '<pre>';print_r($arrHeater);echo '</pre>';
			//die('STOP');
	?>
		<div class="col-sm-8" <?php if($strPumpDisabled) { echo 'style="opacity:0.5; pointer-events: none;"';}?>>
			<div class="controls boxed controlMode">
			<div class="refreshLoading" id="refreshLoading_PS" style="width:80%;height:40px;position:relative;"><img src="<?php echo base_url("assets/images/loading.gif");?>" alt="loading">&nbsp;Refreshing Devices....</div>
			<div class="widget-title" style="float:right;">
				<a href="javascript:void(0);" class="link-refresh" id="link-refresh-1" onclick="refreshDeviceStatus('PS');"><span class="glyphicon glyphicon-refresh"></span></a>
			</div>
			<h2>Heater And Pump <?php if($strPumpDisabled){ echo '<span style="color:red; float:right;">Not available in this Mode!</span>';}?></h2>
			<?php
				//echo '<pre>';print_r($arrHeater); echo '</pre>';
				if(isset($arrHeater['heater']) && $arrHeater['heater'] != 0)
				{
					$iHeaterCnt		=	$arrHeater['heater'];

					//for($i=0;$i<$iHeaterCnt;$i++)
					$aHeaterAssign	=	unserialize($arrHeater['heaterAssign']);
					foreach($aHeaterAssign as $Heater)	
					{
						$arrTempHeater	=	explode("_",$Heater);
						$i				=	$arrTempHeater[0];
						$ipID			=	$arrTempHeater[1];
						
						$j	=	$arrHeater['HeaterPump'.($i+1)];
						
						$aHeaterDetails  =   $this->home_model->getHeaterDeviceDetails($i,$ipID);
						if(!empty($aHeaterDetails))
						{
							foreach($aHeaterDetails as $aHeater)
							$sRelayDetails  =   unserialize($aHeater->light_relay_number);
							
							$sRelayType     =   $sRelayDetails['sRelayType'];
							$sRelayNumber   =   $sRelayDetails['sRelayNumber'];
							
							if($sRelayType == '24')
							{
								$sLightStatus   =   ${"sRelays".$ipID}[$sRelayNumber];
							}
							if($sRelayType == '12')
							{
								$sLightStatus   =   ${"sPowercenter".$ipID}[$sRelayNumber];
							}
						}
						
						if($sRelayNumber != '')
						{
							
							$strChecked	=	'';
							if($sLightStatus)
							{
								$strChecked	=	'class="checked"';
							}
							
							$iPumpVal = $sPump[$j];
							
							$aPumpDetails = $this->home_model->getPumpDetails($j,$ipID);
							$sPumpType		=	'';
							if(!empty($aPumpDetails))
							{
								foreach($aPumpDetails as $aResultEdit)
								{
									$sPumpType    = $aResultEdit->pump_type;//Pump Type
									$sPumpRelay   = $aResultEdit->relay_number;//Assigned Relay Number
									$sPumpRelay1   = $aResultEdit->relay_number_1;//Assigned Relay Number
									if($sPumpType == '12')
									{
										$iPumpVal = ${"sPowercenter".$ipID}[$sPumpRelay]; //Taken the status
									}
									else if($sPumpType == '24')
									{
										$iPumpVal = ${"sRelays".$ipID}[$sPumpRelay];//Taken the status
									}
									else if($sPumpType == '2Speed')
									{
										$sPumpSubType    = $aResultEdit->pump_sub_type;//Pump SUB Type
										$sStatus2Speed   = $aResultEdit->status;//Pump SUB Type
										
										if($sStatus2Speed == '0')
										{
											$iPumpVal        = $sStatus2Speed;
										}
										else if($sStatus2Speed == '1')											
										{
											if($sPumpSubType == '12')
											{
												$iPumpVal = ${"sPowercenter".$ipID}[$sPumpRelay]; //Taken the status
											}
											else if($sPumpSubType == '24')
											{
												$iPumpVal = ${"sRelays".$ipID}[$sPumpRelay];//Taken the status
											}
										}
										else if($sStatus2Speed == '2')											
										{
											if($sPumpSubType == '12')
											{
												$iPumpVal = ${"sPowercenter".$ipID}[$sPumpRelay1]; //Taken the status
											}
											else if($sPumpSubType == '24')
											{
												$iPumpVal = ${"sRelays".$ipID}[$sPumpRelay1];//Taken the status
											}
										}
									}
									else if(preg_match('/Emulator/',$sPumpType))
									{
										 $iPumpVal = ${"sPump".$ipID}[$j];
									}
								}
							}	//END : Getting assigned relay status from the Server.
							$sPumpVal = false;
							if($iPumpVal)
							  $sPumpVal = true;
							
							$strCheckedP	=	'';
							if($iPumpVal > 0)
								$strCheckedP	=	'class="checked"';
			?>		
						<div class="rowCheckbox switch">
							<img src="<?php echo HTTP_IMAGES_PATH;?>icons/motor_image.png" width="25%" style="vertical-align:middle;">
							<div class="custom-checkbox customHeater" style="float:right; margin-top:20px;">
								<input type="checkbox" value="<?php echo $j;?>" id="pumps_<?php echo $j?>_<?php echo $ipID;?>" name="pumps-<?php echo $j;?>-<?php echo $ipID;?>" hidefocus="true" style="outline: medium none;" class="pumpsButton">
							<label <?php echo $strCheckedP;?> id="lablePump-<?php echo $j?>-<?php echo $ipID;?>" for="pumps_<?php echo $j?>_<?php echo $ipID;?>"><span style="color:#C9376E;">Pump <?php echo ($j+1);?></span></label>
							</div>
						</div>
						<div class="rowCheckbox switch">
							<img src="<?php echo HTTP_IMAGES_PATH;?>icons/rsz_water-heater.png" width="25%" style="vertical-align:middle;">
							<div class="custom-checkbox" style="float:right; margin-top:20px;"><input type="checkbox" value="<?php echo $i.'|||'.$sRelayType.'|||'.$sRelayNumber.'|||'.$j.'|||'.$ipID;?>" id="relayHeater-<?php echo $i?>-<?php echo $ipID;?>" name="relayHeater-<?php echo $i?>-<?php echo $ipID;?>" hidefocus="true" style="outline: medium none;" class="heaterButton">
							<label <?php echo $strChecked;?> id="lableRelayHeater-<?php echo $i?>-<?php echo $ipID;?>" for="relayHeater-<?php echo $i?>-<?php echo $ipID;?>"><span style="color:#C9376E;">Heater <?php echo ($i+1);?></span></label>
							</div>
						</div>
						<div style="height:20px;"><hr /></div>
			<?php   	}	
					}
				}
			?>
			</div>
		</div>
		<?php //echo '<pre>';print_r($arrMore);echo '</pre>';?>
		<div class="col-sm-4">
			<div class="controls boxed controlMode">
			<div class="refreshLoading" id="refreshLoading_L" style="width:80%;height:40px;position:relative;"><img src="<?php echo base_url("assets/images/loading.gif");?>" alt="loading">&nbsp;Refreshing Devices....</div>
			<div class="widget-title" style="float:right;">
				<a href="javascript:void(0);" class="link-refresh" id="link-refresh-1" onclick="refreshDeviceStatus('L');"><span class="glyphicon glyphicon-refresh"></span></a>
			</div>
			<h2>Light</h2>
			<?php 
				$aLightAssign	= unserialize($arrMore['lightAssign']);
				//for($i=0;$i<$arrMore['light'];$i++)
				foreach($aLightAssign as $Light)	
				{
					$arrTempLight	=	explode("_",$Light);
					$i				=	$arrTempLight[0];
					$ipID			=	$arrTempLight[1];
					
					//$i	=	$Light;	
					$sLightStatus	=	0;
					$strLight		=	'light_off.png';				
					$aLightDetails  =   $this->home_model->getLightDeviceDetails($i,$ipID);
					if(!empty($aLightDetails))
					{
						foreach($aLightDetails as $aLight)
						$sRelayDetails  =   unserialize($aLight->light_relay_number);
						
						$sRelayType     =   $sRelayDetails['sRelayType'];
						$sRelayNumber   =   $sRelayDetails['sRelayNumber'];
						
						if($sRelayType == '24')
						{
							$sLightStatus   =   ${"sRelays".$ipID}[$sRelayNumber];
							if($sLightStatus)
								$strLight   =   'light_on.png';
						}
						if($sRelayType == '12')
						{
							
							$sLightStatus   =   ${"sPowercenter".$ipID}[$sRelayNumber];
							if($sLightStatus)
								$strLight   =   'light_on.png';
						}
					}
					$strChecked	=	'';
					if($sLightStatus)
					{
						$strChecked	=	'class="checked"';
					}
			?>
				<div class="rowCheckbox switch">
					<img id="lightImage_<?php echo $i.'_'.$ipID;?>" src="<?php echo HTTP_IMAGES_PATH;?>icons/<?php echo $strLight;?>" width="25%" style="vertical-align:middle;">
					<div class="custom-checkbox" style="float:right; margin-top:20px;"><input type="checkbox" value="<?php echo $i.'|||'.$sRelayType.'|||'.$sRelayNumber.'|||'.$ipID;?>" id="relayLight-<?php echo $i?>-<?php echo $ipID;?>" name="relayLight-<?php echo $i?>-<?php echo $ipID;?>" hidefocus="true" style="outline: medium none;" class="lightButton">
					<label <?php echo $strChecked;?> id="lableRelayLight-<?php echo $i?>-<?php echo $ipID;?>" for="relayLight-<?php echo $i?>-<?php echo $ipID;?>"><span style="color:#C9376E;">Light <?php echo ($i+1);?></span></label>
					</div>
				</div>
				<div style="height:20px;">&nbsp;</div>	
			<?php } ?>
			</div>
		</div>
		
		<div class="col-sm-4">
			<div class="controls boxed controlMode">
			<div class="refreshLoading" id="refreshLoading_B" style="width:80%;height:40px;position:relative;"><img src="<?php echo base_url("assets/images/loading.gif");?>" alt="loading">&nbsp;Refreshing Devices....</div>
			<div class="widget-title" style="float:right;">
				<a href="javascript:void(0);" class="link-refresh" id="link-refresh-1" onclick="refreshDeviceStatus('B');"><span class="glyphicon glyphicon-refresh"></span></a>
			</div>
			<h2>Blower</h2>
			<?php 
				$aBlowerAssign	= unserialize($arrMore['blowerAssign']);
				//for($i=0;$i<$arrMore['blower'];$i++)
				foreach($aBlowerAssign as $Blower)	
				{
					$arrTempBlower	=	explode("_",$Blower);
					$i				=	$arrTempBlower[0];
					$ipID			=	$arrTempBlower[1];
					
					//$i	=	$Blower;
					$aBlowerDetails  =   $this->home_model->getBlowerDeviceDetails($i,$ipID);
					if(!empty($aBlowerDetails))
					{
						foreach($aBlowerDetails as $aBlower)
						$sRelayDetails  =   unserialize($aBlower->light_relay_number);
						
						$sRelayType     =   $sRelayDetails['sRelayType'];
						$sRelayNumber   =   $sRelayDetails['sRelayNumber'];
						
						if($sRelayType == '24')
						{
							$sLightStatus   =   ${"sRelays".$ipID}[$sRelayNumber];
						}
						if($sRelayType == '12')
						{
							$sLightStatus   =   ${"sPowercenter".$ipID}[$sRelayNumber];
						}
					}
					
					$strChecked	=	'';
					if($sLightStatus)
					{
						$strChecked	=	'class="checked"';
					}	
			?>
				<div class="rowCheckbox switch">
					<img src="<?php echo HTTP_IMAGES_PATH;?>icons/blower.png" width="25%" style="vertical-align:middle;">
					<div class="custom-checkbox" style="float:right; margin-top:20px;"><input type="checkbox" value="<?php echo $i.'|||'.$sRelayType.'|||'.$sRelayNumber.'|||'.$ipID;?>" id="relayBlower-<?php echo $i?>-<?php echo $ipID;?>" name="relayBlower-<?php echo $i?>-<?php echo $ipID;?>" hidefocus="true" style="outline: medium none;" class="blowerButton">
					<label <?php echo $strChecked;?> id="lableRelayBlower-<?php echo $i?>-<?php echo $ipID;?>" for="relayBlower-<?php echo $i?>-<?php echo $ipID;?>"><span style="color:#C9376E;">Blower <?php echo ($i+1);?></span></label>
					</div>
				</div>
				<div style="height:20px;">&nbsp;</div>
			<?php } ?>
			</div>
		</div>
		
		<div class="col-sm-4">
			<div class="controls boxed controlMode">
			<div class="refreshLoading" id="refreshLoading_M" style="width:80%;height:40px;position:relative;"><img src="<?php echo base_url("assets/images/loading.gif");?>" alt="loading">&nbsp;Refreshing Devices....</div>
			<div class="widget-title" style="float:right;">
				<a href="javascript:void(0);" class="link-refresh" id="link-refresh-1" onclick="refreshDeviceStatus('M');"><span class="glyphicon glyphicon-refresh"></span></a>
			</div>
			<h2>Miscellenious</h2>
			<?php 
				$aMiscAssign	= unserialize($arrMore['miscAssign']);
				//for($i=0;$i<$arrMore['misc'];$i++)
				foreach($aMiscAssign as $Misc)	
				{ 
					//$i	=	$Misc;
					$arrTempMisc	=	explode("_",$Misc);
					$i				=	$arrTempMisc[0];
					$ipID			=	$arrTempMisc[1];
					
					$aMiscDetails  =   $this->home_model->getMiscDeviceDetails($i,$ipID);
					if(!empty($aMiscDetails))
					{
						foreach($aMiscDetails as $aMisc)
						{
							$sMiscStatus	=	'';
							$sRelayDetails  =   unserialize($aMisc->light_relay_number);
							
							$sRelayType     =   $sRelayDetails['sRelayType'];
							$sRelayNumber   =   $sRelayDetails['sRelayNumber'];
							
							if($sRelayType == '24')
							{
								$sMiscStatus   =   ${"sRelays".$ipID}[$sRelayNumber];
							}
							if($sRelayType == '12')
							{
								$sMiscStatus   =   ${"sPowercenter".$ipID}[$sRelayNumber];
							}
						}
					}
					
					$strChecked	=	'';
					if($sMiscStatus)
					{
						$strChecked	=	'class="checked"';
					}
					
					
					
			?>
				<div class="rowCheckbox switch">
					<img src="<?php echo HTTP_IMAGES_PATH;?>icons/misc.png" width="25%" style="vertical-align:middle;">
					<div class="custom-checkbox" style="float:right; margin-top:20px;"><input type="checkbox" value="<?php echo $i.'|||'.$sRelayType.'|||'.$sRelayNumber.'|||'.$ipID;?>" id="relayMisc-<?php echo $i?>-<?php echo $ipID;?>" name="relayMisc-<?php echo $i?>-<?php echo $ipID;?>" hidefocus="true" style="outline: medium none;" class="miscButton">
					<label <?php echo $strChecked;?> id="lableRelayMisc-<?php echo $i?>-<?php echo $ipID;?>" for="relayMisc-<?php echo $i?>-<?php echo $ipID;?>"><span style="color:#C9376E;">Misc Device <?php echo ($i+1);?></span></label>
					</div>
				</div>
				<div style="height:20px;">&nbsp;</div>
			<?php } ?>
			</div>
		</div>
	</div>

<p>
		<a class="fancyboxLoading" id="checkLink" href="#loadingDiv" style="display:none;">&nbsp;</a>
		<div id="loadingDiv" style="display:none;"><div class="loading-progress"></div></div>
</p>
		
		<div id="quickSettingForm" style="display:none;">
		<?php
			
			$sType		=	$arrGeneral['type'];
			$sPoolMax	=	$arrGeneral['pool_max_temp'];
			$sPool		=	$arrGeneral['pool_temp'];
			$sPoolMan	=	$arrGeneral['pool_manual'];
			$sSpaMax	=	$arrGeneral['spa_max_temp'];
			$sSpa		=	$arrGeneral['spa_temperature'];
			$sSpaMan	=	$arrGeneral['spa_manual'];
			$sTemp1		=	$arrGeneral['temperature1'];
			$sTemp2		=	$arrGeneral['temperature2'];
			
			
		?>
		<table>
			<tr><td colspan="3" style="color: #4fc4fe;font-style: italic;font-weight: 400;margin: 0;"><h3>Details</h3></td></tr>
			<tr><td style="width:50%">Change Mode<input type="hidden" name="mode_type" id="mode_type" value="<?php echo $sType;?>"></td>
			<td style="width:1%">&nbsp;</td>
			<td>
			<a href="javascript:void(0);" id="sel_pool" onclick="showSelected('pool');" class="btn btn-middle"  style="<?php if($sType == 'pool'){ echo 'border:2px solid #000;';} ?>"><span>Pool</span></a>
			<a href="javascript:void(0);" onclick="showSelected('spa');" id="sel_spa" class="btn btn-middle btn-green" style="<?php if($sType == 'spa'){ echo 'border:2px solid #000;';} ?>"><span>Spa</span></a>
			<a href="javascript:void(0);" onclick="showSelected('both');" id="sel_both" class="btn btn-middle btn-red" style="<?php if($sType == 'both'){ echo 'border:2px solid #000;';} ?>"><span>Both</span></a></td></tr>
			<tr><td colspan="3">&nbsp;</td></tr>
			<tr class="pool">
				<td style="width:50%">
					Maximum temperature expressed in Fahrenheit set the pool temperature to?
				</td>
				<td style="width:1%">&nbsp;</td>
				<td><input type="text" name="pool_maximum_temperature" id="pool_maximum_temperature" class="form-control inputText" value="<?php echo $sPoolMax;?>"></td>
			</tr>
			<tr class="pool"><td colspan="3">&nbsp;</td></tr>
			<tr class="pool">
				<td style="width:50%">
					Desire pool temperature when user is in Pool Mode?
				</td>
				<td style="width:1%">&nbsp;</td>
				<td><input type="text" name="pool_desire_temperature" id="pool_desire_temperature" class="form-control inputText" value="<?php echo $sPool;?>"></td>
			</tr>
			<tr class="pool"><td colspan="3">&nbsp;</td></tr>
			<tr class="pool">
				<td style="width:50%">
					The maximum allotted time for Pool Manual Mode expressed in minutes?
				</td>
				<td style="width:1%">&nbsp;</td>
				<td><input type="text" name="pool_time" id="pool_time" class="form-control inputText" value="<?php echo $sPoolMan;?>"></td>
			</tr>
			<tr class="spa"><td colspan="3">&nbsp;</td></tr>
			<tr class="spa">
				<td style="width:50%">
					Maximum temperature expressed in Fahrenheit set the spa temperature to?
				</td>
				<td style="width:1%">&nbsp;</td>
				<td><input type="text" name="spa_maximum_temperature" id="spa_maximum_temperature" class="form-control inputText" value="<?php echo $sSpaMax;?>"></td>
			</tr>
			<tr class="spa"><td colspan="3">&nbsp;</td></tr>
			<tr class="spa">
				<td style="width:50%">
					Desire spa temperature when user is in Spa Mode?
				</td>
				<td style="width:1%">&nbsp;</td>
				<td><input type="text" name="spa_desire_temperature" id="spa_desire_temperature" class="form-control inputText" value="<?php echo $sSpa;?>" ></td>
			</tr>
			<tr class="spa"><td colspan="3">&nbsp;</td></tr>
			<tr class="spa">
				<td style="width:50%">
					The maximum allotted time for Spa Manual Mode expressed in minutes?
				</td>
				<td style="width:1%">&nbsp;</td>
				<td><input type="text" name="spa_time" id="spa_time" class="form-control inputText" value="<?php echo $sSpaMan;?>"></td>
			</tr>
			<tr><td colspan="3">&nbsp;</td></tr>
			<tr>
				<td style="width:50%">
					Temperature Sensor 1?
				</td>
				<td style="width:1%">&nbsp;</td>
				<td><select name="temperature1" id="temperature1" class="form-control">
				<option <?php if(isset($sTemp1) &&  $sTemp1 == '1'){echo 'selected="selected"';}?> value="1">TS1</option>
				<option <?php if(isset($sTemp1) &&  $sTemp1 == '2'){echo 'selected="selected"';}?> value="2">TS2</option>
				<option <?php if(isset($sTemp1) &&  $sTemp1 == '3'){echo 'selected="selected"';}?> value="3">TS3</option>
				<option <?php if(isset($sTemp1) &&  $sTemp1 == '4'){echo 'selected="selected"';}?> value="4">TS4</option>
				<option <?php if(isset($sTemp1) &&  $sTemp1 == '5'){echo 'selected="selected"';}?> value="5">TS5</option>
			</select></td>
			</tr>
			<tr><td colspan="3">&nbsp;</td></tr>
			<tr>
				<td style="width:50%">
					Temperature Sensor 2?
				</td>
				<td style="width:1%">&nbsp;</td>
				<td><select name="temperature1" id="temperature1" class="form-control">
				<option <?php if(isset($sTemp2) &&  $sTemp2 == '1'){echo 'selected="selected"';}?> value="1">TS1</option>
				<option <?php if(isset($sTemp2) &&  $sTemp2 == '2'){echo 'selected="selected"';}?> value="2">TS2</option>
				<option <?php if(isset($sTemp2) &&  $sTemp2 == '3'){echo 'selected="selected"';}?> value="3">TS3</option>
				<option <?php if(isset($sTemp2) &&  $sTemp2 == '4'){echo 'selected="selected"';}?> value="4">TS4</option>
				<option <?php if(isset($sTemp2) &&  $sTemp2 == '5'){echo 'selected="selected"';}?> value="5">TS5</option>
			</select></td>
			</tr>
			<tr><td colspan="3">&nbsp;</td></tr>
			<tr>
				<td colspan="3">
					<a href="javascript:void(0);" onclick="saveQuickSetting();" class="btn btn-green"><span>Save</span></a>
					<a href="javascript:void(0);" onclick="parent.$a.fancybox.close();" class="btn btn-red"><span>Cancel</span></a>
				</td>
			</tr>
		</table>
		</div>
