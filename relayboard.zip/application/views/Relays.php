<?php
	//Create IP and Board Name Variables.
	if(!empty($aIPDetails))
	{
		$i	=	1;
		foreach($aIPDetails as $aIP)
		{
			${"sIP". $i} = $aIP->ip;
			${"sBoardName". $i} = $aIP->name;
			$i++;
		}
	}
?>
<!-- START : 24V AC RELAY -->
<div class="row">
	<?php
		if(!empty($aIPDetails))
		{
			foreach($aIPDetails as $aIP)
			{
	?>	
	<div class="col-sm-4" id="onoffbuttons_<?php echo $aIP->id;?>" style="display:<?php if($aIP->id != $iFirstIPId){ echo 'none';} ?>">
	<input type="hidden" value="<?php echo $aIP->id;?>" id="hidIPIdButton">
		<div class="widget-container widget-stats boxed green-line">
			<div class="widget-title">
				<a href="<?php echo base_url('home/setting/'.$sDevice.'/');?>" class="link-refresh" id="link-refresh-1"><span class="glyphicon glyphicon-refresh"></span></a>
				<h3>ON/OFF</h3>
			</div>
				
						<div class="stats-content clearfix" >
							<div class="stats-content-right" style="width:96% !important; margin-left:5px; margin-right:5px; margin-top:10px; float:none;">
							<?php
								for ($i=0;$i < ${"relay_count".$aIP->id}; $i++)
								{
									$iRelayVal = ${"sRelays".$aIP->id}[$i];
									if($iRelayVal != '' && $iRelayVal !='.') 
									{
										$strChecked	=	'';
										if($iRelayVal == '1')
											$strChecked	=	'class="checked"';
										
										//Name added to Relay
										$sRelayNameDb =  $this->home_model->getDeviceName($i,$sDevice,$aIP->id);
										$strRelayName = 'Relay '.$i;
										if($sRelayNameDb != '')
											$strRelayName .= ' ('.$sRelayNameDb.')';
										
										//Get Port Number
										$sDevicePort	=	$this->home_model->getDevicePort($i,$sDevice);
										
										if($sDevicePort == '')
											$sDevicePort = 0;
										
										$strPortClass	=	'port_'.$sDevicePort;
							?>
										<div class="rowCheckbox switch <?php echo $strPortClass;?>">
											<div class="custom-checkbox" style="<?php if($sRelayNameDb != ''){ echo 'height:60px;';}?>">
												<input type="checkbox" value="<?php echo $i;?>" id="relay-<?php echo $i?>" name="relay-<?php echo $i?>" class="relayButton" hidefocus="true" style="outline: medium none;">
												<label <?php echo $strChecked;?>  id="lableRelay-<?php echo $i?>" for="relay-<?php echo $i?>"><span style="color:#C9376E; float:right;"><?php echo $strRelayName;?></span></label>
											</div>
										</div>
							<?php 	}		
								}
							?> 
							</div>
						</div>
		</div>
	</div>
	
	<div class="col-sm-8" id="relayConfigure_<?php echo $aIP->id;?>" style="display:<?php if($aIP->id != $iFirstIPId){ echo 'none';} ?>">
		<!-- Statistics -->
		<div class="widget-container widget-stats boxed green-line">
			<div class="widget-title">
				<a href="<?php echo base_url('home/setting/'.$sDevice.'/');?>" class="link-refresh" id="link-refresh-1"><span class="glyphicon glyphicon-refresh"></span></a>
				<h3>24V AC Relay Settings</h3>
			</div>
			<div class="stats-content clearfix">
				<div class="stats-content-right" style="width:100% !important; margin-left:5px; margin-right:5px; float:none;">
		
					<table class="table table-hover">
					<thead>
					<tr>
						<th class="header" style="width:25%">Relay Details</th>
					</tr>
					</thead>
					<tbody>
					<?php			
						//START : Relay Device 
						$j=0;
						//START : First Show all Relays assigned to Valves.
						for ($i=0;$i < ${"relay_count".$aIP->id}; $i++)
						{
							$iRelayVal = ${"sRelays".$aIP->id}[$i];
							if($iRelayVal == '' || $iRelayVal =='.') 
							{
								$sRelayNameDb =  $this->home_model->getDeviceName($i,$sDevice,$aIP->id);
								if($sRelayNameDb == '')
								  $sRelayNameDb = 'Add Name';
					?>
						
								<tr <?php if($j>=1){ echo 'class="displayMore"';}?>>
									<td>
										<div class="row">
										<div class="col-sm-4">
										Relay <?php echo $i;?><br />(<a href="<?php if($sAccess == '2') { echo site_url('home/deviceName/'.base64_encode($i).'/'.base64_encode($sDevice).'/'.base64_encode($aIP->id)); } else { echo 'javascript:void(0);';} ?>"><?php echo $sRelayNameDb;?></a>)
										</div>
										<div class="col-sm-4"> - </div>
										<div class="col-sm-4"><strong style="color:#FF0000">Output is Assigned to Valve.</strong></div>
										</div>
									</td>
								</tr>	
						<?php 
								$j++;
							}
						}
						if($j > 0)
						{
							echo '<tr>
									<th class="header more" style="text-align: center; color:#428BCA; cursor:pointer;">More +</th>
								 </tr>';
						}
						//END : First Show all Relays assigned to Valves.
						
						for ($i=0;$i < ${"relay_count".$aIP->id}; $i++)
						{
							$iRelayVal = ${"sRelays".$aIP->id}[$i];
							
							if($iRelayVal != '' && $iRelayVal !='.') 
							{
								$iRelayNewValSb = 1;
								if($iRelayVal == 1)
								{
								  $iRelayNewValSb = 0;
								}
								$sRelayVal = false;
								if($iRelayVal)
								  $sRelayVal = true;
								//$sRelayNameDb = get_device_name(1, $i);

								$sRelayNameDb =  $this->home_model->getDeviceName($i,$sDevice,$aIP->id);
								if($sRelayNameDb == '')
								  $sRelayNameDb = 'Add Name';
								
								$sDeviceTime =  $this->home_model->getDeviceTime($i,$sDevice);
								if($sDeviceTime == '')
								  $sDeviceTime = 'Add Time';
								else
								  $sDeviceTime .= ' Minute';
							  
								//Get Device Program Count
								$iRelayProgramCount = $this->home_model->getProgramCount($i,$sDevice);
								
								$iPower	 = $this->home_model->getDevicePower($i,$sDevice);
								
								//Get Device Type
								$sMainType =	$this->home_model->getDeviceMainType($i,$sDevice);
								
					?>
								<tr>
									<td>
										<div class="row" >
											<div class="col-sm-4">
												Relay <?php echo $i;?><br />(<a href="<?php if($sAccess == '2') { echo site_url('home/deviceName/'.base64_encode($i).'/'.base64_encode($sDevice).'/'.base64_encode($aIP->id)); } else { echo 'javascript:void(0);';} ?>"><?php echo $sRelayNameDb;?></a>)
											</div>
										
											<div class="col-sm-4">
												<div class="rowRadio">
													<div class="custom-radio">
														<strong class="customType">Type</strong><br><br>
														<input class="relayRadio" type="radio" id="radio_other_<?php echo $i;?>" value="0" name="<?php echo $i;?>_MainType" <?php if($sMainType == '0' || $sMainType == ''){ echo 'checked="checked"';}?> <?php if($sAccess == '1') { echo 'disabled="disabled"';}?> hidefocus="true" style="outline: medium none;">
														
														<label id="relay_other_<?php echo $i;?>" for="radio_other_<?php echo $i;?>" class="<?php if($sMainType == '0' || $sMainType == ''){ echo 'checked';}?>" style="display:inline-block;">Other</label>
														
														<input class="relayRadio" type="radio" id="radio_spa_<?php echo $i;?>" name="<?php echo $i;?>_MainType" value="1" <?php if($sMainType == '1'){ echo 'checked="checked"';}?> <?php if($sAccess == '1') { echo 'disabled="disabled"';}?> hidefocus="true" style="outline: medium none;">
														
														<label id="relay_spa_<?php echo $i;?>" for="radio_spa_<?php echo $i;?>" class="<?php if($sMainType == '1'){ echo 'checked';}?>" style="display:inline-block;">Spa</label>
														
														<input class="relayRadio" type="radio" id="radio_pool_<?php echo $i;?>" name="<?php echo $i;?>_MainType" value="2" <?php if($sMainType == '2'){ echo 'checked="checked"';}?> <?php if($sAccess == '1') { echo 'disabled="disabled"';}?> hidefocus="true" style="outline: medium none;">
														
														<label id="relay_pool_<?php echo $i;?>" for="radio_pool_<?php echo $i;?>" class="<?php if($sMainType == '2'){ echo 'checked';}?>" style="display:inline-block;">Pool</label>
													</div>
												</div>
											</div>
											<div class="col-sm-4">
												<strong>Action</strong><br><br>
												<a class="btn btn-small" href="<?php if($sAccess == '2') { echo site_url('home/setPrograms/'.base64_encode($i).'/'.base64_encode('ip='.$aIP->id));} else { echo 'javascript:void(0);';}?>"><span>Programs</span></a>
												
												<a class="btn btn-small" href="<?php if($sAccess == '2') { echo site_url('home/setPrograms/'.base64_encode($i).'/'.base64_encode('ip='.$aIP->id));} else { echo 'javascript:void(0);';}?>"><span><?php echo $iRelayProgramCount;?><?php if($iRelayProgramCount == 1 || $iRelayProgramCount == 0){ echo ' Program';}else{ echo ' Programs';}?></span></a>
												
												<a class="btn btn-green btn-small" href="<?php if($sAccess == '2') {echo site_url('home/addTime/'.base64_encode($i).'/'.  base64_encode($sDevice));} else { echo 'javascript:void(0);';}?>"><span><?php echo $sDeviceTime;?></span></a>
											</div>
										</div>	
									</td>
								</tr>
					<?php	} ?>
				<?php	} ?>	
					</tbody>
					</table>
				</div>
			</div>
			<!--/ Statistics -->
		</div>
	</div>
	<?php 	}
		}
	?>
</div><!-- /.row -->
<!-- END : 24V AC RELAY -->