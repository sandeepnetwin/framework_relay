<?php
	/**
	 *	Project : LVN 
	 *	Program/Module Name :Custom Program 
	 *	Author : Dhiraj S. 
	 *	Creation Date : 27/06/2016 
	 *	Description : Manage Custom Program Related Operations.
	 *	Modification History : 
	 *	Change Date: Name: 
	**/
?>
<style>
.navbar-toggle {
		background-color: transparent !important;
		background-image: none !important;
		border: 1px solid transparent !important;
		border-radius: 4px !important;
		float: left !important;
		margin-bottom: 8px !important;
		margin-right: 15px !important;
		margin-top: 8px !important;
		padding: 9px 10px !important;
		position: relative !important;
	}
	
	.navbar-toggle .icon-bar {
		border-radius: 1px !important;
		display: block !important;
		height: 2px !important;
		width: 22px !important;
	}
	
	.btn.sc-btn{
    padding:10px 15px;
    height:auto;
    line-height:1;
    color: #ffffff;
    background-color: #5bc0de;
    border-color: #46b8da;
}


.btn.sc-btn:hover,
.btn.sc-btn:focus,
.btn.sc-btn:active{
    color: #ffffff;
    background-color: #39b3d7;
    border-color: #269abc;
}

.btn.sc-btn.btn-danger{
    padding:10px 15px;
    height:auto;
    line-height:1;
    color: #ffffff;
    background-color: #d9534f;
    border-color: #d43f3a;
}

.btn.sc-btn.btn-danger:hover,
.btn.sc-btn.btn-danger:focus,
.btn.sc-btn.btn-danger:active{
    color: #ffffff;
    background-color: #d2322d;
    border-color: #ac2925;
}

.btn > .countdown
{
	background: #d9534f !important;
	border: none;
	display: inline;
	line-height: inherit;
	padding: 0;
}

.sc-btn:hover span
{
	background-color: #d2322d !important;
}

	
</style>
<link rel="stylesheet" type="text/css" href="<?php echo HTTP_ASSETS_PATH.'craftpip-jquery-confirm/jquery-confirm.css';?>" />
<script type="text/javascript" src="<?php echo HTTP_ASSETS_PATH.'craftpip-jquery-confirm/jquery-confirm.js';?>"></script>
<script type="text/javascript">
$(document).ready(function ()
{
});
</script>	

      <div id="page-wrapper">

        <div class="row">
          <div class="col-lg-12">
           <ol class="breadcrumb">
				  <li><img src="<?php echo HTTP_IMAGES_PATH.'icons/home.png';?>" width="24" style="vertical-align: middle !important;">&nbsp;<a href="<?php echo site_url();?>">Home</a> </li>
				  <li class="active">Custom Programs</li>
				  <div style="float:right;"><a class="btn btn-green btn-small" onclick="javascript:location.href='<?php echo base_url('device/addeditCustomProgram/'); ?>';"><span>Add New Custom Program</span></a><?php if($_SERVER['REMOTE_ADDR'] == '14.142.41.62') {?>&nbsp; <a class="btn btn-small" href="<?php echo base_url('device/customProgramLog/') ;?>"><span>Show Log</span></a><?php } ?></div>
			</ol>
		
			<?php if($msg != '') { ?>
              <div class="alert alert-success alert-dismissable">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                <?php echo $msg;?>
              </div>
            <?php } ?>
            <?php if($errmsg != '') { ?>
              <div class="alert alert-danger alert-dismissable">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                <?php echo $errmsg;?>
              </div>
            <?php } ?>
		  </div>
        </div><!-- /.row -->
            <div class="table-responsive" style="color:#FFF;">
              <table class="table tablesorter">
                <thead>
                  <tr style="font-weight:bold;">
                    <th class="header">Program Name <i class="fa fa-sort"></i></th>
                    <th class="header">Display </th>
					<th class="header">Run Status </th>
                   <th class="header">Action</th>
                  </tr>
                </thead>
                <tbody>
				<?php if(!empty($allCustomPrograms))
					  { 
						foreach($allCustomPrograms as $CustomProgram) 
						{
							$CustomProgramDetails = json_decode($CustomProgram->program_details);	
							$CustomProgramName    = $CustomProgramDetails->g_custom_mode_name;
							$CustomProgramID	  = $CustomProgram->id;
							$CustomProgramOn	  = $CustomProgram->is_on;
							
							/* if($_SERVER['REMOTE_ADDR'] == '14.142.41.62')
							{
								echo '<pre>';print_r($CustomProgram);echo '</pre>';
							} */
							
							
				?>	
                  <tr>
                    <td><?php echo str_replace("_"," ",$CustomProgramName);?><input type="hidden" name="customProgramID" id="customProgramID" value=""></td>
                    <td>
						<a href="javascript:void(0);" onclick="changeStatus('<?php echo $CustomProgramID;?>')" id="displayAccess_<?php echo $CustomProgramID;?>"><input type="hidden" name="currentStatus" id="currentStatus_<?php echo $CustomProgramID;?>" value="<?php echo $CustomProgram->display_access;?>"><?php if($CustomProgram->display_access) {?> <i class="glyphicon glyphicon-ok" style="color:#AEEC16;"></i><?php } else {?><i class="glyphicon glyphicon-remove" style="color:#c9376e;"></i><?php } ?></a>
						<span id="loadingImg_<?php echo $CustomProgramID;?>" style="display:none;">
							<img width="32" height="32" alt="Loading...." src="<?php echo HTTP_IMAGES_PATH.'loading.gif';?>">
						</span>
					</td>
					<td>
						<?php if($CustomProgramOn == '1') {?> <i class="glyphicon glyphicon-ok" style="color:#AEEC16;"></i><?php } else {?><i class="glyphicon glyphicon-remove" style="color:#c9376e;"></i><?php } ?></a>
					</td>
                   <td>
				   <?php if($CustomProgramOn == '0') { ?><a class="btn btn-small" href="<?php echo site_url('device/runCustomProgram/'.base64_encode($CustomProgramID).'/');?>"><span>Run</span></a><?php } else if($CustomProgramOn == '1') {?> <a class="btn btn-small btn-red" href="javascript:void(0);" onclick="offCustomProgram('<?php echo $CustomProgramID;?>');"><span>Stop</span></a><?php } ?> &nbsp; <a class="btn btn-small btn-green" href="<?php echo site_url('device/addeditCustomProgram/'.base64_encode($CustomProgramID).'/');?>"><span>Edit</span></a> &nbsp; <a class="btn btn-small btn-red" href="<?php echo site_url('device/deleteCustomProgram/'.base64_encode($CustomProgramID).'/');?>"><span>Delete</span></a>
				    
				   </td>
                  </tr>
				<?php 	}
					  } 
					  else 
					  { 
				  ?>  
                  <tr>
					<td colspan="5"><span style="color:red; font-weight:bold;">No Custom Programs Available!</span></td>
                   </tr>
				<?php } ?>
                </tbody>
              </table>
            </div>
      </div><!-- /#page-wrapper -->
<script type="text/javascript">
  function changeStatus(customProgramID)
  {
	  $("#loadingImg_"+customProgramID).show();
	  var currentStatus = $("#currentStatus_"+customProgramID).val();
	  
	  var status;
	  
	  if(currentStatus == '1')
		  status = '0';
	  else if(currentStatus == '0')
		  status = '1';
	  
	  
	  
	  $.ajax({
				type: "POST",
				url: "<?php echo site_url('device/changeCustomProgramDisplay/');?>", 
				data: {customProgramID:customProgramID,status:status},
				success: function(data) 
				{
					$("#currentStatus_"+customProgramID).val(data);
					if(data == '0')
						$("#displayAccess_"+customProgramID).html('<input type="hidden" name="currentStatus" id="currentStatus_'+customProgramID+'" value="'+data+'"><i class="glyphicon glyphicon-remove" style="color:#c9376e;"></i>');
					if(data == '1')
						$("#displayAccess_"+customProgramID).html('<input type="hidden" name="currentStatus" id="currentStatus_'+customProgramID+'" value="'+data+'"><i class="glyphicon glyphicon-ok" style="color:#AEEC16;"></i>');
					
					$("#loadingImg_"+customProgramID).hide();
				}
	  });
  }
  
  function offCustomProgram(customProgramID)
  {
	  $("#loadingImg_"+customProgramID).show();
	   $.ajax({
				type: "POST",
				url: "<?php echo site_url('device/offCustomProgram/');?>", 
				data: {customProgramID:customProgramID},
				async:false,
				success: function(data) 
				{
					if(data.indexOf("|||"))
					{						
						var arrData = data.split('|||');
						alert(arrData[0]);
						$("#customProgramID").val(customProgramID);
						
						if(arrData[1] == '1')
						{
							$(".content-pane > .content").css({"padding" : '0px', "line-height":'20px'});
							$.confirm({
								title: 'Confirm!',
								content: 'Do you want to resume Pool mode manual or Pool Mode Auto? If you select Pool Mode manual then previous valve positions are set.',
								confirmButton: 'POOL MODE MANUAL',
								cancelButton: 'POOL MODE AUTO',
								autoClose: 'cancel|60000',
								confirmButtonClass: 'btn-info sc-btn',
								cancelButtonClass: 'btn-danger sc-btn',
								columnClass: 'col-md-6 col-md-offset-3',
								confirm: function(){
									var customProgramID	 = $("#customProgramID").val();
									$.ajax({
											type: "POST",
											url: "<?php echo site_url('device/setDevicePreviousPosition/');?>", 
											data: {customProgramID:customProgramID},
											async:false,
											success: function(previousData) {
													$("#customProgramID").val('');
														location.reload();
													}
											
									 });
								},
								cancel: function(){
									 var customProgramID	 = $("#customProgramID").val();
									 $.ajax({
											type: "POST",
											url: "<?php echo site_url('device/setDeviceDefaultPosition/');?>", 
											data: {customProgramID:customProgramID},
											async:false,
											success: function(defaultData) {
												$("#customProgramID").val('');
												location.reload();
												}
									 });
								}
							});
						}
						else
						{
							location.reload();
						}
					}
					else
					{
						alert(data);
					}
					$("#loadingImg_"+customProgramID).hide();
				}
	  });
  }
</script>
<?php

?>