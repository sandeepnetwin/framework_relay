<h3>Valve Setting</h3>
            <section>
			<div class="col-sm-12">
				<label for="strValve">How many AUTOMATIC valves do you have on your pool and or pool/spa system?<span class="requiredMark">*</span>&nbsp;&nbsp;<a class="fancybox changeLink" id="changeLinkValve" href="#valveForm">Change</a></label>
				<?php //if(isset($arrDevice['valve_actuated'])  && in_array(2,$arrDevice['valve_actuated'])){ echo 'selected="selected"';}?>
                <select name="strValve" id="strValve" class="form-control required" onchange="valveChange();">
				<option <?php if(isset($arrDevice['valve']) && $arrDevice['valve'] == ''){ echo 'selected="selected"';} ?> value="">Select valves</option>
				<option <?php if(isset($arrDevice['valve']) && $arrDevice['valve'] == '0'){ echo 'selected="selected"';} ?> value="0">0 Valves</option>
					<?php
						for($i=0;$i<$iValveCnt;$i++)
						{
					?>
						<option <?php if(isset($arrDevice['valve']) && $arrDevice['valve'] == ($i+1)){ echo 'selected="selected"';} ?> value="<?php echo ($i+1);?>"><?php echo ($i+1);?> Valves</option>
					<?php } ?>
				</select>
				<?php for($i=0;$i<8;$i++){?>
				<div class="valveShow" id="valveShow<?php echo ($i+1);?>" style="display:<?php if($iValveCnt >= ($i+1)) { echo '';} else { echo 'none';}?>" >
					<div style="height:10px">&nbsp;</div>
					<label for="valve_assign<?php echo ($i+1);?>">Assign Valve<?php echo ($i+1);?>?<span class="requiredMark">*</span></label>
					<select name="valve_assign<?php echo ($i+1);?>" id="valve_assign<?php echo ($i+1);?>" class="form-control">
					<option value="">Select Valve to Assign</option>
					<?php foreach($ValveRelays as $valve)
						  {
							  echo '<option value="'.$valve->device_number.'">Valve '.$valve->device_number.'</option>';
						  }
					?>	  
					</select>
				</div>	
				<?php } ?>
				
				<div style="height:10px">&nbsp;</div>
				<label for="valve_actuated">If necessary, Which valve(s) is actuated when you switch from Pool to Spa Mode?<span class="requiredMark">*</span></label>
                <select name="valve_actuated[]" id="valve_actuated" class="form-control required" multiple="" onchange="showReason(this.value);">
					<option <?php if(isset($arrDevice['valve_actuated']) && in_array('',$arrDevice['valve_actuated'])){ echo 'selected="selected"';} ?> value="">Select Valve Quantity</option>
					<option <?php if(isset($arrDevice['valve_actuated'])  && in_array(0,$arrDevice['valve_actuated'])){ echo 'selected="selected"';} ?> value="0">Valve 0 is actuated</option>
					<?php
						for($i=0;$i<$iValveCnt;$i++)
						{
					?>
					<option <?php if(isset($arrDevice['valve_actuated'])  && in_array(1,$arrDevice['valve_actuated'])){ echo 'selected="selected"';} ?> value="<?php echo ($i+1);?>">Valve <?php echo ($i+1);?> is actuated</option>
					<?php } ?>
				</select>
				<div style="height:10px; display:none;" id="reasonValveBlk">&nbsp;</div>
				<label id="reasonValvelbl" for="reasonValve" style="display:none;">Reason for No valves are actuated?<span class="requiredMark">*</span></label>
                <input type="text" name="reasonValve" value="<?php if(isset($arrDevice['reasonValve']) && $arrDevice['reasonValve'] != '') { echo $arrDevice['reasonValve'];}?>" id="reasonValve" class="form-control inputText" style="display:none;">
				
				<div style="height:10px">&nbsp;</div>
				<label for="valveRunTime">Valve Run Time expressed in minutes?<span class="requiredMark">*</span></label>
                <input type="text" name="valveRunTime" value="<?php if(isset($arrDevice['valveRunTime']) && $arrDevice['valveRunTime'] != '') { echo $arrDevice['valveRunTime'];}?>" id="valveRunTime" class="form-control inputText required">
				
				<div style="height:10px">&nbsp;</div>
				
			</div>	
			</section>