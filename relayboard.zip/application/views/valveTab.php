<?php
		//Get all Positions
		$this->load->model('user_model');
		$aAllPositions 	= $this->user_model->getAllPositions();	
?>
<script>
function checkValveAssign(valve)
{
	var numberOfValve	=	$("#strValve").val();
	if(numberOfValve == '' || numberOfValve == '0')
	{
		alert("Please select Valve number first!");
		return false;
	}
	
	if(!$("#lableRelayValve-"+valve).hasClass('checked'))
	{
		$("#lableRelayValve-"+valve).addClass('checked');
	}
	else
	{
		$("#lableRelayValve-"+valve).removeClass('checked');
	}
	
	var arrValveAssignNumber	= 	Array();
	
	$(".valveAssign").each(function(){
		var valveNumber = $(this).val();
		if($("#lableRelayValve-"+valveNumber).hasClass('checked'))
		{	
			arrValveAssignNumber.push(valveNumber);
		}
	});
	
	if(arrValveAssignNumber.length != numberOfValve && arrValveAssignNumber.length != 0)
	{
		if(arrValveAssignNumber.length > numberOfValve)
			$("#lableRelayValve-"+valve).removeClass('checked');
		
		alert("Please assign "+numberOfValve+" Valve!");
		return false;
	}
}
</script>
<h3>Valve Setting</h3>
	<section>
		<div class="col-sm-12">
			
			<label for="strValve">How many AUTOMATIC valves do you have on<br /> your pool and or pool/spa system?<span class="requiredMark">*</span>&nbsp;<img src="<?php echo HTTP_ASSETS_PATH.'images/help.png';?>" width="24" class="tooltipster-icon" title="Please select number of valve used in the mode?" /></label>
			<a class="changeLink" id="changeLinkValve" href="javascript:void(0);" onclick="javascript:$('#valveForm').toggleClass('disableConfig');" style="float:right;" title="Click here to Enable/Disable valve related settings!">Enable/Disable Valve Configuration</a>
			
			<select name="strValve" id="strValve" class="form-control required" onchange="valveChange();">
			<option <?php if(isset($arrDevice['valve']) && $arrDevice['valve'] == ''){ echo 'selected="selected"';} ?> value="">Select number of valves</option>
			<option <?php if(isset($arrDevice['valve']) && $arrDevice['valve'] == '0'){ echo 'selected="selected"';} ?> value="0">0</option>
			<?php
					for($i=0;$i<$iValveCnt;$i++)
					{
			?>
					<option <?php if(isset($arrDevice['valve']) && $arrDevice['valve'] == ($i+1)){ echo 'selected="selected"';} ?> value="<?php echo ($i+1);?>"><?php echo ($i+1);?></option>
				
			<?php 	} ?>
			</select>
			
			<div style="height:10px">&nbsp;</div>
			
			<label for="valve_actuated">If necessary, Which valve(s) is actuated when you switch from Pool to Spa Mode?<span class="requiredMark">*</span></label>
			
			<select name="valve_actuated[]" id="valve_actuated" class="form-control required" multiple="" onchange="showReason(this.value);">
				<option <?php if(isset($arrDevice['valve_actuated']) && in_array('',$arrDevice['valve_actuated'])){ echo 'selected="selected"';} ?> value="">Select Valve Quantity</option>
				<option <?php if(isset($arrDevice['valve_actuated'])  && in_array(0,$arrDevice['valve_actuated'])){ echo 'selected="selected"';} ?> value="0">Valve 0 is actuated</option>
				<?php
					for($i=0;$i<$iValveCnt;$i++)
					{
				?>
						<option <?php if(isset($arrDevice['valve_actuated'])  && in_array(($i+1),$arrDevice['valve_actuated'])){ echo 'selected="selected"';} ?> value="<?php echo ($i+1);?>">Valve <?php echo ($i+1);?> is actuated</option>
				<?php } ?>
			</select>
			
			<div style="height:10px; display:none;" id="reasonValveBlk">&nbsp;</div>
			<label id="reasonValvelbl" for="reasonValve" style="display:none;">Reason for No valves are actuated?<span class="requiredMark">*</span></label>
			
			<input type="text" name="reasonValve" value="<?php if(isset($arrDevice['reasonValve']) && $arrDevice['reasonValve'] != '') { echo $arrDevice['reasonValve'];}?>" id="reasonValve" class="form-control inputText" style="display:none;">
			
			<div style="height:10px">&nbsp;</div>
			<label for="valveRunTime">Valve Run Time expressed in minutes?<span class="requiredMark">*</span></label>
			<input type="text" name="valveRunTime" value="<?php if(isset($arrDevice['valveRunTime']) && $arrDevice['valveRunTime'] != '') { echo $arrDevice['valveRunTime'];}?>" id="valveRunTime" class="form-control inputText required">
			
			<div style="height:10px">&nbsp;</div>
			<!-- Assign Div -->
			<div class="col-sm-4" style="padding-left:0px;">
				<div class="controls boxed green-line" style="min-height:210px;">
					<div class="inner">
						<h3 class="profile-title"><strong style="color:#C9376E;">Assign Valve</strong></h3>
						<div id="contentsValve">
						<?php
							//for($i=0;$i<$iValveCnt;$i++)
							if(!empty($ValveRelays))
							{
								foreach($ValveRelays as $valve)
								{
									$i	=	$valve->device_number;
									$strValveName 		=	'Valve '.($i);	
									$strValveNameTmp 	=	$this->home_model->getDeviceName($i,'V');
									if($strValveNameTmp != '')
										$strValveName	.=	' ('.$strValveNameTmp.')';
									
									$checked 	=	'';
									$clsChecked	=	'';
									$valveAssign	=	unserialize($arrDevice['valveAssign']);	
									if(in_array($i,$valveAssign))
									{
										$checked 	=	'checked="checked"';
										$clsChecked	=	'class="checked"';
									}
							?>
							<?php if($i != 0){ echo '<hr />'; }?>
								<div class="rowCheckbox switch">
									<div style="margin-bottom:10px;"><?php echo $strValveName;?></div>
									<div class="custom-checkbox"><input type="checkbox" value="<?php echo $i;?>" onclick="checkValveAssign(this.value)" id="relayValve-<?php echo $i?>" name="relayValve[]" hidefocus="true" style="outline: medium none;" class="valveAssign" <?php echo $checked;?>>
									<label <?php echo $clsChecked;?> id="lableRelayValve-<?php echo $i?>" for="relayValve-<?php echo $i?>"><span style="color:#C9376E;">&nbsp;</span></label>
									</div>
								</div>
									
						<?php 	
								}
							}
						?>
						</div>
					</div>
				</div>
			</div>
			<!-- Assign Div -->
			
			<!-- Configuration Div -->
			<div class="col-sm-8" style="padding-right:0px;">
				<div id="valveForm" class="disableConfig" >	
					<div style="margin-bottom:10px;"><h3 class="confHeader">Valve Configuration</h3></div>
					<table class="table removeBorder" id="valveTable" width="100%" cellspacing="0" cellpadding="0">
					<tbody>
						<tr>
							<td style="width:48%;">Enter Number of Valves to Use in system:</td>
							<td style="width:2%;">&nbsp;</td>
							<td style="width:50%;"><input type="text" name="valveNumber" id="valveNumber" onkeyup="showValveDetails();" value="<?php if(isset($extra['ValveNumber']) && $extra['ValveNumber'] != 0) { echo $extra['ValveNumber'];}?>" class="form-control inputText"></td>
						</tr>
						<?php
							$i	= 0;
							$arrValve	=	array(0,1,2,3,4,5,6,7);
							if(!empty($ValveRelays))
							{
								foreach($ValveRelays as $valve)
								{
									$valve_relay_number	=	unserialize($valve->valve_relay_number);
									
									//START : Get Valve Position Details.
									$aPositionName   =  $this->home_model->getPositionName($valve->device_number,'V');
									
									$strPosition1 = '';
									$strPosition2 = '';
									
									if($aPositionName[0] != '')
									$strPosition1	 =	$this->home_model->getPositionNameFromID($aPositionName[0]);
									if($aPositionName[1] != '')
									$strPosition2	 =	$this->home_model->getPositionNameFromID($aPositionName[1]);
									//END : Get Valve Position Details.
									
									unset($arrValve[$valve->device_number])
						?>
									<tr id="trValveDetails<?php echo $valve->device_number;?>">
									<td>
										<strong>Valve <?php echo $valve->device_number;?></strong>&nbsp;<span class="relayText">(Enter relays in sequence)</span>
									</td>
									
									<td>&nbsp;</td>
									<td>
									
										<input type="text" style="width:50px; display:inline;" class="inputText" id="sRelay<?php echo $valve->device_number;?>_1" value="<?php echo $valve_relay_number['Relay1'];?>">
										&nbsp;&nbsp;
										<select class="form-control" style="width:100px !important; display:inline;" name="valveDirection_<?php echo $valve->device_number;?>_1" id="valveDirection_<?php echo $valve->device_number;?>_1">
										<?php
										foreach($aAllPositions as $Position)
										{
											$strSelect	=	'';
											
											if($Position->id == $aPositionName[0])
											{
												$strSelect	=	'selected="selected"';
											}
											
											echo '<option value="'.$Position->id.'" '.$strSelect.'>'.$Position->position_name.'</option>';
										}
										?>
										</select>
										
										<div style="height: 5px;"> </div>
										
										<input type="text" style="width:50px; display:inline;" class=" inputText" id="sRelay<?php echo $valve->device_number;?>_2" value="<?php echo $valve_relay_number['Relay2'];?>">
										&nbsp;&nbsp;
										<select class="form-control" style="width:100px !important; display:inline;" id="valveDirection_<?php echo $valve->device_number;?>_2" name="valveDirection_<?php echo $valve->device_number;?>_2">
										<?php
										foreach($aAllPositions as $Position)
										{
											$strSelect	=	'';
											
											if($Position->id == $aPositionName[1])
											{
												$strSelect	=	'selected="selected"';
											}
											
											echo '<option value="'.$Position->id.'" '.$strSelect.'>'.$Position->position_name.'</option>';
										}
										?>
										</select>
										
										<!--&nbsp;<a class="changeLink" href="javascript:void(0);" onclick="removeRow('valveTable')">Remove</a>-->
									</td>
								</tr>
						<?php 
								$i++;
								
								}	 		
							}
							?>
						<?php 
							  $remainingValve	=	$extra['ValveNumber'] - $i;	
							  $j=0;
							  foreach($arrValve as $i)	
							  {
								  
								$sDevice	=	'V';
								//$valve_relay_number	=	unserialize($valve->valve_relay_number);
								
								//START : Get Valve Position Details.
								$aPositionName   =  $this->home_model->getPositionName($i,$sDevice);
								
								$strPosition1 = '';
								$strPosition2 = '';
								
								if($aPositionName[0] != '')
								$strPosition1	 =	$this->home_model->getPositionNameFromID($aPositionName[0]);
								if($aPositionName[1] != '')
								$strPosition2	 =	$this->home_model->getPositionNameFromID($aPositionName[1]);
								//END : Get Valve Position Details.
								
								$aRelayNumber    =  json_decode($this->home_model->getValveRelayNumber($i,$sDevice));
								
							?>
								<tr id="trValveDetails<?php echo $i;?>" style="display:<?php if(isset($remainingValve) && $j < $remainingValve) { echo ''; } else { echo 'none;';}?>" >
									<td>
										<strong>Valve <?php echo $i;?></strong>&nbsp;<span class="relayText">(Enter relays in sequence)</span>
									</td>
									
									<td>&nbsp;</td>
									<td>
									
										<input type="text" style="width:50px; display:inline;" class="inputText" id="sRelay<?php echo $i;?>_1" value="<?php echo $aRelayNumber->Relay1;?>">
										&nbsp;&nbsp;
										<select class="form-control" style="width:100px !important; display:inline;" name="valveDirection_<?php echo $i;?>_1" id="valveDirection_<?php echo $i;?>_1">
										<?php
										foreach($aAllPositions as $Position)
										{
											$strSelect	=	'';
											
											if($Position->id == $aPositionName[0])
											{
												$strSelect	=	'selected="selected"';
											}
											
											echo '<option value="'.$Position->id.'" '.$strSelect.'>'.$Position->position_name.'</option>';
										}
										?>
										</select>
										
										<div style="height: 5px;"> </div>
										
										<input type="text" style="width:50px; display:inline;" class=" inputText" id="sRelay<?php echo $i;?>_2" value="<?php echo $aRelayNumber->Relay2;?>">
										&nbsp;&nbsp;
										<select class="form-control" style="width:100px !important; display:inline;" name="valveDirection_<?php echo $i;?>_2" id="valveDirection_<?php echo $i;?>_2">
										<?php
										foreach($aAllPositions as $Position)
										{
											$strSelect	=	'';
											
											if($Position->id == $aPositionName[1])
											{
												$strSelect	=	'selected="selected"';
											}
											
											echo '<option value="'.$Position->id.'" '.$strSelect.'>'.$Position->position_name.'</option>';
										}
										?>
										</select>
										
										<!--&nbsp;<a class="changeLink" href="javascript:void(0);" onclick="removeRow('valveTable')">Remove</a>-->
									
									</td>
								</tr>
							<?php
									$j++;
								}
								
								echo '<tr id="valveSaveConf">
										<td colspan="3">
											<a href="javascript:void(0);" onclick="checkAndSaveRelays();" class="btn btn-middle"><span>Save</span></a>&nbsp;&nbsp;<a href="javascript:void(0);" onclick="javascript:$(\'#valveForm\').toggleClass(\'disableConfig\');" class="btn btn-middle btn-red"><span>Cancel</span></a>&nbsp;&nbsp;<span id="loadingImg" style="display:none; vertical-align: middle;"><img src="'.site_url('assets/images/loading.gif').'" alt="Loading...." width="32" height="32"></span>
										</td>
									</tr>';
							  
						?>
					</tbody>		
					</table>
				</div>
			</div>
			<!-- Configuration Div -->
		</div>	
	</section>