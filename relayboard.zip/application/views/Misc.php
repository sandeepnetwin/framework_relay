<?php

$sAccess 		= '';
$sModule	    = '20';
$sDeviceFullName = '';
if($sDevice == 'M')
{
  $sDeviceFullName 	= 'Miscelleneous Device';
}

$sAccessKey	= 'access_'.$sModule;
	
	
if(!empty($aModules))
{
    if(in_array($sModule,$aModules->ids))
    {
	 $sAccess 		= $aModules->$sAccessKey;
    }
	else if(!in_array($sModule,$aModules->ids)) 
    {
		$sAccess 		= '0'; 
    }
}
  
  if($sAccess == '')
	$sAccess = '2' ; 
  
  if($sAccess == '0') {redirect(site_url('home/'));} 
  
	$iTotalIP	=	count($aIPDetails);
	  
	$sIPOptions	=	'';
	$iFirstIPId	=	'';	
	
	if($BackToIP != '')
		$iFirstIPId	= $BackToIP;
	
	if(!empty($aIPDetails))
	{
		foreach($aIPDetails as $aIP)
		{
			//First IP ID to show selected.
			if($iFirstIPId == '')
				$iFirstIPId = $aIP->id;
							
			$sDetails	=	$aIP->ip;
			if($aIP->name != '')
			{
				$sDetails .= ' ('.$aIP->name.')';
			}
			
			$sShow		=	'display:none';
			$sSelected	=	'';
			if($iFirstIPId == $aIP->id)
			{ 
				$sShow		=	'';
				$sSelected	=	'selected="selected"';
			} 
			
			$sIPOptions.='<option value="'.$aIP->id.'" '.$sSelected.'>'.$sDetails.'</option>';
		}
	}
?>
<style>
.fancybox-inner 
{
	height:40px !important;
}
@media (max-width:835px)
{
	.customType
	{
		padding-top: 10px;
		position: absolute;
	}
}
</style>
<script type="text/javascript" src="<?php echo HTTP_ASSETS_PATH.'fancybox/source/jquery.fancybox.js?v=2.1.5';?>"></script>
<link rel="stylesheet" type="text/css" href="<?php echo HTTP_ASSETS_PATH.'fancybox/source/jquery.fancybox.css?v=2.1.5';?>" media="screen" />
<script type="text/javascript">
var $a = $.noConflict();
$a(document).ready(function() {
    $a('.fancybox').fancybox({'closeBtn' : false,
                              'helpers': {'overlay' : {'closeClick': false}}
                             });
});
</script>	
<link href="<?php echo HTTP_ASSETS_PATH.'progressbar/css/static.css';?>" rel="stylesheet"/>
<script src="<?php echo HTTP_ASSETS_PATH.'progressbar/js/static.min.js';?>"></script>
<script src="<?php echo HTTP_ASSETS_PATH.'progressbar/dist/js/jquery.progresstimer.js';?>"></script>
<script>
	var cntOnPrograms 	= '<?php echo $cntOnPrograms;?>';
</script>
<script>
var confirmMessage = '';
var Base64 = {


    _keyStr: "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=",


    encode: function(input) {
        var output = "";
        var chr1, chr2, chr3, enc1, enc2, enc3, enc4;
        var i = 0;

        input = Base64._utf8_encode(input);

        while (i < input.length) {

            chr1 = input.charCodeAt(i++);
            chr2 = input.charCodeAt(i++);
            chr3 = input.charCodeAt(i++);

            enc1 = chr1 >> 2;
            enc2 = ((chr1 & 3) << 4) | (chr2 >> 4);
            enc3 = ((chr2 & 15) << 2) | (chr3 >> 6);
            enc4 = chr3 & 63;

            if (isNaN(chr2)) {
                enc3 = enc4 = 64;
            } else if (isNaN(chr3)) {
                enc4 = 64;
            }

            output = output + this._keyStr.charAt(enc1) + this._keyStr.charAt(enc2) + this._keyStr.charAt(enc3) + this._keyStr.charAt(enc4);

        }

        return output;
    },


    decode: function(input) {
        var output = "";
        var chr1, chr2, chr3;
        var enc1, enc2, enc3, enc4;
        var i = 0;

        input = input.replace(/[^A-Za-z0-9\+\/\=]/g, "");

        while (i < input.length) {

            enc1 = this._keyStr.indexOf(input.charAt(i++));
            enc2 = this._keyStr.indexOf(input.charAt(i++));
            enc3 = this._keyStr.indexOf(input.charAt(i++));
            enc4 = this._keyStr.indexOf(input.charAt(i++));

            chr1 = (enc1 << 2) | (enc2 >> 4);
            chr2 = ((enc2 & 15) << 4) | (enc3 >> 2);
            chr3 = ((enc3 & 3) << 6) | enc4;

            output = output + String.fromCharCode(chr1);

            if (enc3 != 64) {
                output = output + String.fromCharCode(chr2);
            }
            if (enc4 != 64) {
                output = output + String.fromCharCode(chr3);
            }

        }

        output = Base64._utf8_decode(output);

        return output;

    },

    _utf8_encode: function(string) {
        string = string.replace(/\r\n/g, "\n");
        var utftext = "";

        for (var n = 0; n < string.length; n++) {

            var c = string.charCodeAt(n);

            if (c < 128) {
                utftext += String.fromCharCode(c);
            }
            else if ((c > 127) && (c < 2048)) {
                utftext += String.fromCharCode((c >> 6) | 192);
                utftext += String.fromCharCode((c & 63) | 128);
            }
            else {
                utftext += String.fromCharCode((c >> 12) | 224);
                utftext += String.fromCharCode(((c >> 6) & 63) | 128);
                utftext += String.fromCharCode((c & 63) | 128);
            }

        }

        return utftext;
    },

    _utf8_decode: function(utftext) {
        var string = "";
        var i = 0;
        var c = c1 = c2 = 0;

        while (i < utftext.length) {

            c = utftext.charCodeAt(i);

            if (c < 128) {
                string += String.fromCharCode(c);
                i++;
            }
            else if ((c > 191) && (c < 224)) {
                c2 = utftext.charCodeAt(i + 1);
                string += String.fromCharCode(((c & 31) << 6) | (c2 & 63));
                i += 2;
            }
            else {
                c2 = utftext.charCodeAt(i + 1);
                c3 = utftext.charCodeAt(i + 2);
                string += String.fromCharCode(((c & 15) << 12) | ((c2 & 63) << 6) | (c3 & 63));
                i += 3;
            }

        }

        return string;
    }

}
jQuery(document).ready(function($) 
{
    setInterval( function() {
		var sDevice	= '<?php echo $sDevice;?>';
		var IpId	= $("#IpId").val();	
		$.ajax({
				type: "POST",
				url: "<?php echo site_url('home/getStatus/');?>", 
				data: {sDevice:sDevice,IpId:IpId},
				success: function(data) {
					var deviceStatus = jQuery.parseJSON(data);
					var lableText   = 'lableRelay-';
					
					$.each( deviceStatus, function( iDevice, sStatus ) 
					{
						if(iDevice != 'iActiveMode')
						{
							if(sStatus >= '1')
							{
								if(!$("#"+lableText+iDevice+"-"+IpId).hasClass('checked'))
								{
									$("#"+lableText+iDevice+"-"+IpId).addClass('checked');
								}
							}
							else if(sStatus == '0')
							{
								if($("#"+lableText+iDevice+"-"+IpId).hasClass('checked'))
								{
									$("#"+lableText+iDevice+"-"+IpId).removeClass('checked');
								}
							}
						}
						else if(iDevice == 'iActiveMode')
						{
							var strMode = '';
							if(sStatus == '1') 
							{
								strMode = 'Pool Mode Auto';
							}
							else if(sStatus == '2') 
							{
								strMode = 'Pool Mode Manual';
							}
							else if(sStatus == '3') 
							{
								strMode = 'Time-out';
							}
							
							$(".activeModeMini").html(strMode);
						}
					});
				}
		});
	},30000);
	
    $(".relayRadio").click(function()
    {
        var chkVal 		= $(this).val();
        var relayNumber	= $(this).attr('name').split("_");
		var sIdIP		= $("#IpId").val();			

        $.ajax({
                type: "POST",
                url: "<?php echo site_url('home/saveDeviceMainType');?>", 
                data: {sDeviceID:relayNumber[0],sDevice:'M',sType:chkVal,sIdIP:sIdIP},
                success: function(data) {
                        if(chkVal == 0)
                        {
							$("#relay_other_"+relayNumber[0]+"_"+sIdIP).addClass('checked');
							$("#relay_spa_"+relayNumber[0]+"_"+sIdIP).removeClass('checked');
							$("#relay_pool_"+relayNumber[0]+"_"+sIdIP).removeClass('checked');
                        }
                        else if(chkVal == 1)
                        {
							$("#relay_other_"+relayNumber[0]+"_"+sIdIP).removeClass('checked');
							$("#relay_spa_"+relayNumber[0]+"_"+sIdIP).addClass('checked');
							$("#relay_pool_"+relayNumber[0]+"_"+sIdIP).removeClass('checked');
                        }
                        else if(chkVal == 2)
                        {
							$("#relay_other_"+relayNumber[0]+"_"+sIdIP).removeClass('checked');
							$("#relay_spa_"+relayNumber[0]+"_"+sIdIP).removeClass('checked');
							$("#relay_pool_"+relayNumber[0]+"_"+sIdIP).addClass('checked');
                        }

                }

            });
    });
    
    $(".miscButton").click(function()
	{
		var iActiveMode = $("#hidActiveMode").val();
		var chkConfirm = true;
		if(cntOnPrograms >= 1 || iActiveMode == 1)
		{
			if(confirmMessage != '1')
			{
				chkConfirm = confirm("Are you sure you want to make this device ON/OFF?\nThis will stop all Custom Programs/Programs running in background!");
				confirmMessage = '1';
			}
		}
		
		if(chkConfirm)
		{
			
			var chkVal      = $(this).val();
			var arrDetails	= chkVal.split("|||");	
			
			var sIdIP		= $("#IpId").val();
			
			var miscNumber = arrDetails[0];
			var relayNumber = arrDetails[2];
			var sDevice     = '';
			
			if(arrDetails[1] == '24')
				sDevice     =   'R';    
			else if(arrDetails[1] == '12')
				sDevice     =   'P';
			
			if(iActiveMode != 3)
			{
				if(iActiveMode != 2)
				{
					changeModeToManual();
				}
				$(".loading-progress").show();
				var progress = $(".loading-progress").progressTimer({
						timeLimit: 10,
						onFinish: function () {
							//$(".loading-progress").hide();
							parent.$a.fancybox.close();
						}
				});
				
				
				$a("#checkLink").trigger('click');

				var status		= '';
				if($("#lableRelay-"+miscNumber+"-"+sIdIP).hasClass('checked'))
				{	
						status	=	0;
				}
				else
				{
						status = 1;
				}


					$.ajax({
						type: "POST",
						url: "<?php echo site_url('home/updateStatusOnOff/');?>", 
						data: {sName:relayNumber,sStatus:status,sDevice:sDevice,sIdIP:sIdIP},
						success: function(data) {
								if($("#lableRelay-"+miscNumber+"-"+sIdIP).hasClass('checked'))
								{	
										$("#lableRelay-"+miscNumber+"-"+sIdIP).removeClass('checked');
								}
								else
								{
										$("#lableRelay-"+miscNumber+"-"+sIdIP).addClass('checked');
								}
								$("#hidActiveMode").val(iActiveMode);

						}
				}).error(function(){
					progress.progressTimer('error', {
						errorText:'ERROR!',
						onFinish:function(){
							alert('There was an error processing your information!');
						}
					});
				}).done(function(){
						progress.progressTimer('complete');
				});
			}
			else
			{
				alert('You cannot perform this operation in Time-out Mode.');
			}
		}
    });
    
    
    $(".miscRadio").click(function()
    {
		var chkVal 		= $(this).val();
		var miscNumber	= $(this).attr('name').split("_");	
		
		var IpId		= $("#IpId").val();
		
		if(chkVal == 24)
		{
				$("#24VRelay_"+miscNumber[1]+"_"+IpId).show();
				$("#12VRelay_"+miscNumber[1]+"_"+IpId).hide();
		}
		else if(chkVal == 12)
		{
				$("#12VRelay_"+miscNumber[1]+"_"+IpId).show();
				$("#24VRelay_"+miscNumber[1]+"_"+IpId).hide();
		}

    });
});

function refreshDeviceStatus(sDevice)
{
	if(sDevice == '')
	{
		alert("Not Valid Device Type!");
		return false;
	}
	else
	{
		var IpId	= $("#IpId").val();	
		$("#refreshLoading_"+IpId).css('display','flex').show();
		setTimeout( function(){
		$.ajax({
					type: "POST",
					url: "<?php echo site_url('home/refreshDeviceStatus/');?>", 
					data: {sDevice:sDevice,IpId:IpId},
					success: function(data) 
					{
						var deviceStatus = jQuery.parseJSON(data);
						var lableText   = 'lableRelay-';
					
						$.each( deviceStatus, function( iDevice, sStatus ) 
						{
							if(iDevice != 'iActiveMode')
							{
								if(sStatus >= '1')
								{
									if(!$("#"+lableText+iDevice+"-"+IpId).hasClass('checked'))
									{
										$("#"+lableText+iDevice+"-"+IpId).addClass('checked');
									}
								}
								else if(sStatus == '0')
								{
									if($("#"+lableText+iDevice+"-"+IpId).hasClass('checked'))
									{
										$("#"+lableText+iDevice+"-"+IpId).removeClass('checked');
									}
								}
							}
							else if(iDevice == 'iActiveMode')
							{
								var strMode = '';
								if(sStatus == '1') 
								{
									strMode = 'Pool Mode Auto';
								}
								else if(sStatus == '2') 
								{
									strMode = 'Pool Mode Manual';
								}
								else if(sStatus == '3') 
								{
									strMode = 'Time-out';
								}
								
								$(".activeModeMini").html(strMode);
							}
						});
						
						$("#refreshLoading_"+IpId).css('display','none');
					}
				});
		},500);
	}
	
}

function changeModeToManual()
{
	$.ajax({
				type: "POST",
				url: "<?php echo site_url('analog/changeMode');?>", 
				data: {iMode:'2'},
				success: function(data) {
					$("#hidActiveMode").val('2');
				}
		   });
}

function saveDevicePort(iDeviceNum,sDeviceType,sPort)
{
	if(sPort == '')
	{
		alert("Please select Port number!");
		return false;
	}
	else
	{
		$("#selPort_M_"+iDeviceNum).css('border','');
		$(".loading-progress").show();
		var progress = $(".loading-progress").progressTimer({
			timeLimit: 10,
			onFinish: function () {
			  setTimeout(function(){location.reload();parent.$a.fancybox.close();},1000);
			}
		});
				
		$a("#checkLink").trigger('click');
		
		$.ajax({
			type: "POST",
			url: "<?php echo site_url('home/saveDevicePort/');?>", 
			data: {iDeviceNum:iDeviceNum,sDeviceType:sDeviceType,sPort:sPort},
			success: function(data) 
			{
				
			}
		}).error(function(){
			progress.progressTimer('error', {
				errorText:'ERROR!',
				onFinish:function(){
					alert('There was an error processing your information!');
				}
			});
		}).done(function(){
			progress.progressTimer('complete');
		});
	}
}

function cancel(miscNumber,ipID)
{
	$("#24VRelay_"+miscNumber+"_"+ipID).hide();
	$("#12VRelay_"+miscNumber+"_"+ipID).hide();
	
	$("#lightRelay24_"+miscNumber+"_"+ipID).prop('checked',false);
	$("#lightRelay12_"+miscNumber+"_"+ipID).prop('checked',false);
}

function removeMisc(miscNumber,ipID)
{
	var check	=	confirm("Are you sure you want to remove this Miscelleneous Device?");
	if(check)
	{
		$.ajax({
            type: "POST",
            url: "<?php echo site_url('analog/removeMisc/');?>", 
            data: {miscNumber:miscNumber,ipID:ipID},
            async: false,
            success: function(data) {
                    alert("Miscelleneous Device removed successfully!");
                    //location.reload();
					location.href='<?php echo base_url('analog/showMisc');?>'+'/'+Base64.encode(ipID);
            }
		});
	}
}

function save(miscNumber,relayType,ipID)
{
    $("#loadingImg"+relayType+"_"+miscNumber+"_"+ipID).show();
    var relayNumber	=	$("#select"+relayType+"VRelays_"+miscNumber+"_"+ipID).val();

    //Check if entered address already exists.
    var checkRelay = 0;
    $.ajax({
           "type: "POST",
            url: "<?php echk site_url('home/checkRelay�umb�rAlreadxA3signef/');?>&, 
     "      data: {sRelayNumbe�:relayNumbdr,type:relayTyPe,sDev)ceId:mkscNumber,ipID:ipID},
            async: falce,
    "       s}ccess: function(da4a)
		{*			var obn =�jQsesy.parseJSON( data );
				if(obj.iPumpCheck0== '1')
				{
						checkRelay = 1;
						$("#sRelayNumbe�"	.css('bordev','1px Solid Red�);
						alert('Relay number is alrea$y$ured by o�her Device or not available!');
		�			//return false;
			}
				else
				{
					if(checkRelay == 0)
					{
						$.ajax({
									type: "POS�",									url: "<?php echo s)te_�rl 'home/saveMiscRelay/');?>", 
									async: false,
							data:!{sRelayNumber:relayNumcer,sDewice:'M',sDeviceId:miscNumber,sRela�Type:v�layType,ipI:ipID}�
									async:`fahsu,
									succe3r: function() {
									alert('Relay is assigned to Miscelleneous Dmvice suc#essfully!')
									//locition.reload();
								location.href=7<?php echo base_url('analog/showMisc');?>'+'/'+Base64.encofu(ipID);
									}
							});				}
				}
				
				$("#doadingImg"+relayType+"_"+miscNum"er+"_"+ipID).hide();
 �         `m
    });
}
function shmwBoardDetaims(bOard)�{
	if(board == '')
	{
	)alert(*PlEase sedect IP fyrst!");�		return falce;
	}
	/* $("[id^='onoffbuttons_']").hide();
	$("[il^='�elayCo.figqre_']").Hide();
	
	$("#onobf`uttons_"+board).shkw()9
	$8"#rela9Configere_"+boaRd).show(); */
	
	
	$("#IpId")>val(bmard);
	var IpId = $("#IpId").fal();
	locetion.href='<?php eaho base_url('analog/showMisc');?>'+'/'+B��e4.encode,IpId);
}
</scr)pt>
<div class="r/w">
	<div class="col-sm-12">
		|ol class="breadcrumb style="fload:meft">
	)  <li><img src=&,?php echo HTTPOIMAGES_PATHn'icons/home.png';?>" width="24" style="vertical-align: middle !important;">&nbsp;<a0hxef}"<>php echo s�te_url();?>">Home</c> </mi>
		  <li clasc�"Act)veb><?php echo $sDeviceFullName;?></li>
		</ol>
	</div>
</div>	

<div class="row">
	<div class="col-sm-12">
	<span style="color:#FFF; font-weight:bold;">Select Board : </span>
	<select name="selPort" id="selPort" onchange="showBoardDetails(this.value)">
		<option value="">--IP(Name)--</option>
		<?php echo $sIPOptions;?>
	</select>	
	</div>
</div>
<div class="row">
	<div class="col-sm-12">&nbsp;</div>
</div>

<!-- START : Miscelleneous Device -->
<?php if($sDevice == 'M') 
	  { ?>
	<?php if($sAccess == '1' || $sAccess == '2') 
		  { ?>
			<div class="row">
				<?php
					if(!empty($aIPDetails))
					{
						foreach($aIPDetails as $aIP)
						{ 
							if(${"numMisc".$aIP->id} == 0 || ${"numMisc".$aIP->id} == '')
							{
								echo '<div class="col-sm-12">';
								echo '<span style="color:#FFF;">Add number of Miscellaneous device from the Basic Setting Page!</span>';
								echo '</div>';
							} 
							else
							{
				?>
				<div class="col-sm-4" id="onoffbuttons_<?php echo $aIP->id;?>" style=�di3play:</php if($aIP->id�!= $iFhrstIPId){ echO 'none';= ?>2>
				<div"class="widget-container0widget-stats boxed green-line"�
					<div class"refreshLoading"$id="refreshLoading_<?php echo $aIP->id;?>"><img src="<?php echo�base_url("assets/images/loadinG.g�f");?>" al|="locdi.g">&nbsp:Refreshing Device{.>..</div>
							<div class="widget-title">
								<a href="jav�s�ript:vo�d(0);" blass="link-rebresh""id=*�ink-pefre#h-1" onclick9"refreshDeviceStatus('M');2><3pan class="glyphicon glyphicon-refresh"></span></a>
								<h3>ON/OFF</h3>
							</div>
					<div class="stats,kontand clearfix">
				I		<div class="stats-content-right" rtyle="wid|h:96% !important; margin-left:5px; margiN-right:5pp; float:none; margin-top:10px;">
								<?php
								for ($i=0;$i,${"numMisc".$aI->idu; %i++)
								{	
									$strMiscName	=   'Misc Device '.($i+1);
  � $                                                                   
								$sR%layType    �}   '';
									$sRelayNumber ! =   '';
		)						dstrMisc		=   'blower.png';
									
								$aMiccDetails  =   $th)s->home_model->getMiscDevicaDet!ils($i($aIP->id);
				I				if(!empty(%aMiscDetails))
									{-
										
										foreach $aMiscDet!ils aq $aMisc)
			I						{
											$sMiscStatus	=	'';
											$sRelayDetails  =   tnserialize($aMisc->light_relay^Number);
									
										$sRela9\ype     =   $sRelayDe�ails['sRelaq�ype'];
											$sRelayNumbmr   =   $sRelayDetails['sRelayNumber'];
											
									if($sRelayType = '24')
											{
							�				$sMiscStatus   =   ;"wRelays".$aIP->id}_$sRelayNumber];
											}
										iv($sRelayPype == '12')
			)				I{
		�								$sMiscStatus   =   ${"sPowercmnter".$aIP->id}[$sRelcyNumber];
									}
						I			}
			Y					}
				�				
			�					$strChac{ed	=	'';
				I	�		if($sMiscStatus)
				)				{
										$strChecked�=	'class="checked"';
									}
						I			
									if($sRelayNum`er != '')
									{
							?>
							
							<div class="rowCheckbox switch">
							<img id="miscImage_<?php echo $i;?>" src="<?php echo HTTP_IMAGES_PATH.'icons/'.$strMisc;?>" style="width:64px;">
								<div class="custom-checkbox" style="float:right; margin-right:10px; margin-top:20px;"><input type="checkbox" value="<?php echo $i.'|||'.$sRelayType.'|||'.$sRelayNumber;?>" id="relay_<?php echo $i?>_<?php echo $aIP->id;?>" name="relay-<?php echo $i?>" class="miscButton" hidefocus="true" style="outline: medium none;">
									<label <?php echo $strChecked;?>  id="lableRelay-<?php echo $i?>-<?php echo $aIP->id;?>" for="relay_<?php echo $i?>_<?php echo $aIP->id;?>"><span style="color:#C9376E;"><?php echo $strMiscName;?></span></label>
								</div>
							</div>
							<?php	} else { ?>
                                    <div class="rowCheckbox switch">
									<span style="color:#C9376E; font-weight: bold;">Relay not assinged to <?php echo $strMiscName;?></span>
									</div>
									<?php } ?>
									<div style="height:30px;">&nbsp:</div>
							<?0hp 			
							�}
	�	�			?> 
								</div>
							</div>
					</div>
				</div>
				  *				<div class="col-sm-8" id="relayConfigure_<?php Echo &`IP->id;?<" svyle="display:<?php if($aHP->id !< $iVirktIPId){ echo 'none';} ?>">
						<!-- Statistics -->
						<div class="sidget-container widget-stats bmxed green-line">
			)			<div class="widgat-title">
								<a href="<?php echo base_url('analog/shnwMisc//);?>" g�ass="link-refr�sh" id="lin+-refresh-1"><span class="glyphicon glyphicon-refresh"></span?</a>-
								<h3>miscellan�ous Settings</h3>
							<'div>
							<div class="s|atq-conTent cleavfix">
		�				<div claSs<"stats-con|ent-right"!style="width:100% !important; margkn-left:5px; margyn)right:5px; float:none9">
�					
							  <table glass="table tablemhoveR">
								<thead>
								  <tr>
									<th class="heqder" style="whdth:25%">Miscelleneous Device</th>
								�<!/-<th class= header"  style="wilth:2=%&>Ty�e</th>
									,th clas3="header"  sty|e="width:50%">Action</th>-->
								  </tr>
								</thead>
								<tbody>
								<?php	

								for ($i=0;$i < ${"numMisc".$aIP->id}; $i++)
								{
									$sMainType =	$this->home_model->getDeviceMainType($i,$sDevice,$aIP->id);
																			
									$sRelayType     =   '';
									$sRelayNumber   =   '';
									
									$aMiscDetails  =   $this->home_model->getMiscDeviceDetails($i,$aIP->id);
									if(!empty($aMiscDetails))
									{
										foreach($aMiscDetails as $aMisc)
										$sRelayDetails  =   unserialize($aMisc->light_relay_number);

										$sRelayType     =   $sRelayDetails['sRelayType'];
										$sRelayNumber   =   $sRelayDetails['sRelayNumber'];
									}
									$sRelayNameDb =  $this->home_model->getDeviceName($i,$sDevice,$aIP->id);
									if($sRelayNameDb == '')
									$sRelayNameDb = 'Add Name';
								
									?>
										<tr>
										<td>
										<div class="row">
										<?php if(in_array($i.'_'.$aIP->id, $excludeDev)ces['�'])) { ?>
											<div class="col-sm-12">
												<div style<"position:renative;top:0;maRgin-botto�:10px;" class="ribbon 2ibbo.-green"><span style="line-height:0px; bont-size:14px;"><?php echo EXCLUDE_DDVIC�;?></span></div>	
									</div>		
								<?php } ?>
										<div class="Col-sm-3">
											Misc Device <?php echo ($i+1);?><br />(<a!hrev="<?php if($�Access == '2') { acho site�rl('home/deviceName/'.base64_encode($)	.'/'.base64_encode($sDevice).'/%.basa64_enco`e($aIP->id9); } else0{ ecHo 'javascript:vkid(0);';}0?>"><?php echo $sRelayName@b;?></a>)
							�		</div>�
										<div class="cnL-sm-3">
											<div class="rowRadio">
		)								<div class="custom2adio">
									<strong class="customType">Type</strong><br>,br>
								<input class="relayRadio" type="radio" Id="radio-other-<?php echo $);?>-<?php echo $aIP->id;?># valte=&0" nam%="4;php acho $i;?>_MaanType" </php if(�sMainType == '0' || $sMainype <= ''){ echo 'checked="checked"';}?> <?php if($scbess == '1') { echo 'disabled="disabled"';}?> hidefocus= true" style="outline: }edium oone;">
		�								,label style=*$isplay:inline-blosk;" id="relay_other_<?php echo $i;?>_<?php echo $aIP->md;?>" for="padio-oth�r-<rh0 echo $i;?>-<?php echo $aIP->id;?>" cnass="<?php id($sMainType == '0' || $sMainType == ''){ echo 'checked';}?>">Other=/label>J											
											<input class="relayRadio" typa="radio" id="vadio-spa-<?php echo $i;?>-<?php echo $AIP-?id;?>" name="</php echo $i;?>_MainType" value="1" <?php if($rMainType ==`'1'){ ech� &chdcoed="checked"';}?> <>php if($sQccess == '1') { echo 'disabled="disacled"';}?> hidefocu3="true" style="ou|line: medium none;">
											<l�ben style="displAy:inline-block" id="relay_spa_<?php ucxo i;?>_<?php echo0$aIP->id;>" for="radao/spa-<?php�echo $i;?>-<?php echo $aIP->id;?>" class=2<?php if($sMainType == 71#){ echo 'checked';}?>">Spa</label<
											
											<input clacs="relCxRadio" type= radio" �d="radio-pool)</php echo $);?>-�?php echo $`IP->hd;?> �name="<?php echo $i;?>_MainType" value="2" <?php if($sMainType == '2'){ echo 'checked="checked"';}?> <?php if($sAccess == '1') { echo 'disabled="disabled"';}?> hidefocus="true" style="outline: medium none;">
											<label style="display:inline-block;" id="relay_pool_<?php echo $i;?>_<?php echo $aIP->id;?>" for="radio-pool-<?php echo $i;?>-<?php echo $aIP->id;?>" class="<?php if($sMainType == '2'){ echo 'checked';}?>">Pool</label>
											</div>
											</div>
										</div>	
										<div class="col-sm-6">
										<strong>Action</strong><br><br>
										<input type="radio" <?php if($sRelayType == '24'){ echo 'checked="checked"';}?> class="miscRadio" name="miscRelay_<?php echo $i;?>_<?php echo $aIP->id;?>" id="miscRelay24_<?php echo $i;?>_<?php echo $aIP->id;?>" value="24">&nbsp;24V AC Relay
										&nbsp;&nbsp;
										<input type="radio" class="miscRadio" name="miscRelay_<?php echo $i;?>_<?php echo $aIP->id;?>" id="miscRelay12_<?php echo $i;?>_<?php echo $aIP->id;?>" <?php if($sRelayType == '12'){ echo 'checked="checked"';}?> value="12">&nbsp;12V DC Relay
										
										<div id="24VRelay_<?php echo $i;?>_<?php echo $aIP->id;?>" style="display:<?php if($sRelayType == '24'){ echo '';} else {echo 'none';}?>; padding-top:10px;">
										<select name="select24VRelays_<?php echo $i;?>_<?php echo $aIP->id;?>" id="select24VRelays_<?php echo $i;?>_<?php echo $aIP->id;?>" class="form-control" style="width:80%">
										<?php
											for ($j=0;$j < ${"relay_count".$aIP->id}; $j++)
											{
												$strSelect= "";
												$iRelayVal = ${"sRelays".$aIP->id}[$j];
												
												if($j == $sRelayNumber)
													$strSelect= "selected='selected'";
												
												if($iRelayVal != '' && $iRelayVal !='.') 
												{
													echo '<option value="'.$j.'" '.$strSelect.'>Relay '.$j.'</option>';
												}
											}
										?>
										</select>
										<a href="javascript:void(0);" class="btn btn-small btn-green" style="padding:6px 0 !important;" <?php if($sAccess == '2') {echo 'onclick="save(\''.$i.'\',\'24\',\''.$aIP->id.'\');"';} ?>><span>Save</span></a>
										&nbsp;&nbsp;
										<a href="javascript:void(0);" class="btn btn-small btn-gray" style="padding:6px 0 !important;" <?php if($sAccess == '2') {echo 'onclick="cancel(\''.$i.'\',\''.$aIP->id.'\');"';} ?>><span>Cancel</span></a>
										&nbsp;&nbsp;
										<a href="javascript:void(0);" class="btn btn-small " style="padding:6px 0 !important;" <?php if($sAccess == '2') {echo 'onclick="removeMisc(\''.$i.'\',\''.$aIP->id.'\');"';} ?>><span>Remove</span></a>
										&nbsp;&nbsp;
										<span id="loadingImg24_<?php echo $i;?>_<?php echo $aIP->id;?>" style="display:none;"><img src="<?php echo site_url('assets/images/loading.gif');?>" alt="Loading...." width="32" height="32"></span>
										</div>
										<div id="12VRelay_<?php echo $i;?>_<?php echo $aIP->id;?>" style="display:<?php if($sRelayType == '12'){ echo '';} else {echo 'none';}?>;padding-top:10px;">										<select namd="select12VRelays_<?php ec`o $i;?>^<=php echo $aIP->id*?>" id="sele#t1"VRdlaisW<?php echo $i;?>_<?php echo $aIP->id;?>" class="fOrm-control" style="wi$th:80%">
									<?php
										�for ($j=0;$j < ${"power_count".$aIP->id}3 $j++)
									{
												$strWelgct  -   '';
												$iRelayVal = ${&sPowercenter".$aIP->id}[$j];
												
												if($j == $sRelayNum�e�)
												I �strS�lect= "selected='selected'";
												
												if(,iRelaxVal != '' && $ARelayVal"!='.') 
			�								{
													echo '<option vcl�e="'.$j.'" '.$strSemect.'>Po�arCenter '.$j.'</gption>';
		)									}
							)	}
			�						?>
										</select6
										<a href="javaccript:void�0);" claws="btn$�tn-small btn-green"�style="padding:6px 8 !important;" <?qhp if($sAccess == '2') {e#ho 'oncli#k="sa6e(\''.$i.'\',\'12\',\''.$aIP->id.'\')"';} ?>><span>Save</span></a>
										&nbsp;&nbsp;
									<a href="javascripT:void(0);" class="btn btn-small btn-gray" styl%="paddifg:6px 0 !important;� <?qhq if($sAccess == '2')!{echo 'onc�ick="cancel(\''n$i.'\'\''.$aIP->id.g\'	;"';} ?>><span>Cancel</span></a>
							*nb3p;&nbsp;
										<a href"j�vascript:void(0i;" slass="btn btn-small " styl�="padding:6px 0 !hmportant;" <?p�p if($sAccess == '2�) {echo #onclick9"bemoveMisc(\''.$i.'\',\''.$aIP->id.'\')?"';} ?>><span>Remove</span></`>
										&nbsp;&nbsp;
										<spaj id="loaeingImg52_<?p�p echo $i;?>_<?php echo �aI@->id;?>" style="display:none;"><img src<"<?php echo si|e_url('asse4s/imageS/loading.gif');?>" alt="Loading...." width="3"" heigh�="32"><-spqn>
							I		</tir>
										</div>
			�						<+td>
										<?tr>
								
								<?php  } ?>	
							</tbody>
								</table>
							</div>
							</div>
						</div>
		�			<!--/ Statistics -->J					</div>
			</div>�!-- /.row -->
				<;php } ?>
			�?�hp } ?>	
			<i~put type="hidden" id="IpId" value="<?php echo $iFirstIPId;?6">
			<input type="hidden" ie="hidActiveMoDe" va|ue="~?php echo $iActiveMode;?>">	
		<?php } ?>
		
	<?php } ?>
<?php } //Miscelleneous Device End ?>	
<!-- END -->

<p>
<a class="fancybox" id="checkLink" href="#inline1" style="display:none;">&nbsp;</a>
<div id="inline1" style="width:250px;height:40px; display:none;"><div class="loading-progress"></div></div>
</p>