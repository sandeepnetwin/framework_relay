<?php
$sAccess 		= '';
$sModule	    = 4;

  //Get Permission Details
  $userID = $this->session->userdata('id');
  $aPermissions = json_decode(getPermissionOfModule($userID));
 
  $aModules 		= $aPermissions->sPermissionModule;	
  $aAllActiveModule = $aPermissions->sActiveModule;
  
  $sAccessKey	= 'access_'.$sModule;
			  
  if(!empty($aModules))
  {
	  if(in_array($sModule,$aModules->ids))
	  {
		 $sAccess 		= $aModules->$sAccessKey;
	  }
  }
  
  if($sAccess == '')
	$sAccess = '2' ; 
  
  if($sAccess == '0') {redirect(site_url('home/'));}
  
  $sBorderColorOFF 	= 'blue-line';
  $sStatusOFF 		= 'OFF';
  $sColorOFF 		= '#FF0000';
  $sImageOFF		= HTTP_IMAGES_PATH.'/icons/Remove.png';
  
 
  $sBorderColorON 	= 'green-line';
  $sColorON 		= '#006400';
  $sStatusON 		= 'ON';
  $sImageON			= HTTP_IMAGES_PATH.'/icons/tick.png';
?>

<style>
.swichLink
{
	font-size: 14px !important;
    margin-right: -22px;
    margin-top: 25px !important;
}
.imgDiv
{
	margin-top: 22px;
	text-align: center;
	
}
.imgCls
{
	max-width:64px;
	width:100%;
}

.textOnOff
{
	font-size:26px; 
	float:right; 
	margin-top:18px;
}

.controlMode{
	min-height: 220px !important;
}
.disableConfig
{
    opacity:0.5; 
    pointer-events: none;
}
.navbar-toggle {
		background-color: transparent !important;
		background-image: none !important;
		border: 1px solid transparent !important;
		border-radius: 4px !important;
		float: left !important;
		margin-bottom: 8px !important;
		margin-right: 15px !important;
		margin-top: 8px !important;
		padding: 9px 10px !important;
		position: relative !important;
	}
	
	.navbar-toggle .icon-bar {
		border-radius: 1px !important;
		display: block !important;
		height: 2px !important;
		width: 22px !important;
	}
</style>

	<form action="<?php if($sAccess == 2) { echo site_url('analog/changeMode'); }?>" method="post" id="formChangeMode">
    <input type="hidden" name="iMode" value="" id="iMode">
	<div class="row">
	  <div class="col-lg-12">
		<ol class="breadcrumb">
		  <li><img src="<?php echo HTTP_IMAGES_PATH.'icons/home.png';?>" width="24" style="vertical-align: middle !important;">&nbsp;<a href="<?php echo site_url();?>">Home</a> </li>
		  <li class="active">Mode Change</li>
		</ol>
		<?php if($sucess == '1') { ?>
		  <div class="alert alert-success alert-dismissable">
			<button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
			Details saved successfully! 
		  </div>
		<?php } ?>
		<?php if($sucess == '2') { ?>
		  <div class="alert alert-success alert-dismissable" style="background-color: #FFC0CB;border: 1px solid #FFC0CB; color:red;">
			<button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
			Custom program is running, so not able to switch mode! 
		  </div>
		<?php } ?>
		<?php if($err_sucess == '1') { ?>
		  <div class="alert alert-success alert-dismissable" style="background-color: #FFC0CB;border: 1px solid #FFC0CB; color:red;">
			<button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
			IP and Port details required! 
		  </div>
		<?php } ?>
		
	  </div>
	</div><!-- /.row -->
	<div class="row">
		<div class="col-sm-4">
			<div class="controls boxed controlMode" style="height: 250px;">
			<h2>Pool Mode Auto</h2>
				<div>
					<img src="<?php if($iMode == '1') { echo $sImageON;} else {echo $sImageOFF;}?>" alt="<?php if($iMode == '1') { echo $sStatusON;} else {echo $sStatusOFF;}?>" class="imgCls"><h1 class="textOnOff" style="color:<?php if($iMode == '1') { echo $sColorON;} else {echo $sColorOFF;}?>" ><?php if($iMode == '1') { echo $sStatusON;} else {echo $sStatusOFF;}?><h1>
				</div>
				<div>
				<a style="float:right;" href="javascript:void(0);" <?php if($sAccess == 2) {echo 'onclick="submitForm(\'1\');"';} ?> class="btn btn-icon btn-icon-right btn-icon-checkout btn-green btn-middle"><span>Enable Mode</span></a>
				</div>
			</div>
        </div>
		<div class="col-sm-4">
			<div class="controls boxed controlMode" style="height: 250px;">
			<h2>Pool Mode Manual</h2>
			<div>
					<img src="<?php if($iMode == '2') { echo $sImageON;} else {echo $sImageOFF;}?>" alt="<?php if($iMode == '2') { echo $sStatusON;} else {echo $sStatusOFF;}?>" class="imgCls"><h1 class="textOnOff" style="color:<?php if($iMode == '2') { echo $sColorON;} else {echo $sColorOFF;}?>" ><?php if($iMode == '2') { echo $sStatusON;} else {echo $sStatusOFF;}?><h1>
				</div>
				<div>
				<a style="float:right;" href="javascript:void(0);" <?php if($sAccess == 2) {echo 'onclick="submitForm(\'2\');"';} ?> class="btn btn-icon btn-icon-right btn-icon-checkout btn-green btn-middle"><span>Enable Mode</span></a>
				</div>
			</div>
        </div>
		<div class="col-sm-4">
			<div class="controls boxed controlMode" style="height: 250px;">
			<h2>Time-Out</h2>
			<div>
					<img src="<?php if($iMode == '3') { echo $sImageON;} else {echo $sImageOFF;}?>" alt="<?php if($iMode == '3') { echo $sStatusON;} else {echo $sStatusOFF;}?>" class="imgCls"><h1 class="textOnOff" style="color:<?php if($iMode == '3') { echo $sColorON;} else {echo $sColorOFF;}?>" ><?php if($iMode == '3') { echo $sStatusON;} else {echo $sStatusOFF;}?><h1>
				</div>
				<div>
				<a style="float:right;" href="javascript:void(0);" <?php if($sAccess == 2) {echo 'onclick="submitForm(\'3\');"';} ?> class="btn btn-icon btn-icon-right btn-icon-checkout btn-green btn-middle"><span>Enable Mode</span></a>
				</div>
			</div>
        </div>
	</div>
</form>
      
<script type="text/javascript">
  function submitForm(iMode)
  {
    $("#iMode").val(iMode);
    $("#formChangeMode").submit();
  }
  
  function submitFormPoolSpa(iMode)
  {
	  
	  $.ajax({
			type: "POST",
			url: "<?php echo site_url('home/updatePoolSpaMode/');?>", 
			data: {iMode:iMode},
			success: function(data) {
				alert("Mode started successfully!");
				location.reload();
			}
		});
  }
</script>
