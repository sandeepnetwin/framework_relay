<?php
$sAccess 		= '';
$sModule	    = 4;

  //Get Permission Details
  $userID = $this->session->userdata('id');
  $aPermissions = json_decode(getPermissionOfModule($userID));
 
  $aModules 		= $aPermissions->sPermissionModule;	
  $aAllActiveModule = $aPermissions->sActiveModule;
  
  $sAccessKey	= 'access_'.$sModule;
			  
  if(!empty($aModules))
  {
	  if(in_array($sModule,$aModules->ids))
	  {
		 $sAccess 		= $aModules->$sAccessKey;
	  }
  }
  
  if($sAccess == '')
	$sAccess = '2' ; 
  
  if($sAccess == '0') {redirect(site_url('home/'));}
  
  $sBorderColorOFF 	= 'blue-line';
  $sStatusOFF 		= 'OFF';
  $sColorOFF 		= '#FF0000';
  $sImageOFF		= HTTP_IMAGES_PATH.'/icons/Remove.png';
  
 
  $sBorderColorON 	= 'green-line';
  $sColorON 		= '#006400';
  $sStatusON 		= 'ON';
  $sImageON			= HTTP_IMAGES_PATH.'/icons/tick.png';
?>

<link rel="stylesheet" type="text/css" href="<?php echo HTTP_ASSETS_PATH.'craftpip-jquery-confirm/jquery-confirm.css';?>" />
<script type="text/javascript" src="<?php echo HTTP_ASSETS_PATH.'craftpip-jquery-confirm/jquery-confirm.js';?>"></script>
<script type="text/javascript">
$(document).ready(function (){
});
</script>	

<style>
.swichLink
{
	font-size: 14px !important;
    margin-right: -22px;
    margin-top: 25px !important;
}
.imgDiv
{
	margin-top: 22px;
	text-align: center;
	
}
.imgCls
{
	max-width:64px;
	width:100%;
}

.textOnOff
{
	font-size:26px; 
	float:right; 
	margin-top:18px;
}

.controlMode{
	min-height: 220px !important;
}
.disableConfig
{
    opacity:0.5; 
    pointer-events: none;
}
.navbar-toggle {
		background-color: transparent !important;
		background-image: none !important;
		border: 1px solid transparent !important;
		border-radius: 4px !important;
		float: left !important;
		margin-bottom: 8px !important;
		margin-right: 15px !important;
		margin-top: 8px !important;
		padding: 9px 10px !important;
		position: relative !important;
	}
	
	.navbar-toggle .icon-bar {
		border-radius: 1px !important;
		display: block !important;
		height: 2px !important;
		width: 22px !important;
	}
	
	.btn.sc-btn{
    padding:10px 15px;
    height:auto;
    line-height:1;
    color: #ffffff;
    background-color: #5bc0de;
    border-color: #46b8da;
}


.btn.sc-btn:hover,
.btn.sc-btn:focus,
.btn.sc-btn:active{
    color: #ffffff;
    background-color: #39b3d7;
    border-color: #269abc;
}

.btn.sc-btn.btn-danger{
    padding:10px 15px;
    height:auto;
    line-height:1;
    color: #ffffff;
    background-color: #d9534f;
    border-color: #d43f3a;
}

.btn.sc-btn.btn-danger:hover,
.btn.sc-btn.btn-danger:focus,
.btn.sc-btn.btn-danger:active{
    color: #ffffff;
    background-color: #d2322d;
    border-color: #ac2925;
}

.btn > .countdown
{
	background: #d9534f !important;
	border: none;
	display: inline;
	line-height: inherit;
	padding: 0;
}

.sc-btn:hover span
{
	background-color: #d2322d !important;
}

.AutoModeDefaultPosition
{
    background-color: #9cd70e;
    border: 1px solid #9cd70e;
    color: #ffffff;
    float: right;
    font-weight: bold;
    line-height: 15px;
    margin-top: 10px;
    outline: medium none;
    padding: 5px;
}
.AutoModeDefaultPosition:hover
{
    color: #ffffff !important;
    border: 1px solid #9cd70e !important;
}

</style>
<form action="<?php if($sAccess == 2) { echo site_url('analog/changeMode'); }?>" method="post" id="formChangeMode">
  <input type="hidden" name="iMode" value="" id="iMode">
	<input type="hidden" name="ValveDefaultPosition" value="" id="ValveDefaultPosition">
	<input type="hidden" name="ValveNumber" value="" id="ValveNumber">
	<div class="row">
	  <div class="col-lg-12">
		<ol class="breadcrumb">
		  <li><img src="<?php echo HTTP_IMAGES_PATH.'icons/home.png';?>" width="24" style="vertical-align: middle !important;">&nbsp;<a href="<?php echo site_url();?>">Home</a> </li>
		  <li class="active">Mode Change</li>
		</ol>
		<?php if($sucess == '1') { ?>
		  <div class="alert alert-success alert-dismissable">
			<button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
			Details saved successfully! 
		  </div>
		<?php } ?>
		<?php if($sucess == '2') { ?>
		  <div class="alert alert-success alert-dismissable" style="background-color: #FFC0CB;border: 1px solid #FFC0CB; color:red;">
			<button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
			Custom program is running, so not able to switch mode! 
		  </div>
		<?php } ?>
		<?php if($err_sucess == '1') { ?>
		  <div class="alert alert-success alert-dismissable" style="background-color: #FFC0CB;border: 1px solid #FFC0CB; color:red;">
			<button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
			IP and Port details required! 
		  </div>
		<?php } ?>
		
	  </div>
	</div><!-- /.row -->
	<div class="row">
		<div class="col-sm-4">
			<div class="controls boxed controlMode" style="height: 250px;">
			<h2>Pool Mode Auto</h2>
				<div>
					<img src="<?php if($iMode == '1') { echo $sImageON;} else {echo $sImageOFF;}?>" alt="<?php if($iMode == '1') { echo $sStatusON;} else {echo $sStatusOFF;}?>" class="imgCls"><h1 class="textOnOff" style="color:<?php if($iMode == '1') { echo $sColorON;} else {echo $sColorOFF;}?>" ><?php if($iMode == '1') { echo $sStatusON;} else {echo $sStatusOFF;}?></h1>
				</div>
				<div style="margin-top: 15px;">
				<a style="float:right;" <?php if($iMode == '1') { echo 'disabled="disabled"';} ?> href="javascript:void(0);" <?php if($sAccess == 2) {echo 'onclick="submitForm(\'1\');"';} ?> class="btn btn-icon btn-icon-right btn-icon-checkout btn-green btn-middle"><span>Enable Mode</span></a>
				</div>
				<div>
				<a class="AutoModeDefaultPosition" href="javascript:void(0);" <?php if($iMode != '1') { ?> onclick="GetDefaultValveNumbers();" <?php } ?>>Enable Pool Mode Auto &amp; Resume default valve positions</a>
				<!---->
				
				</div>
				
			</div>
        </div>
		<div class="col-sm-4">
			<div class="controls boxed controlMode" style="height: 250px;">
			<h2>Pool Mode Manual</h2>
			<div>
					<img src="<?php if($iMode == '2') { echo $sImageON;} else {echo $sImageOFF;}?>" alt="<?php if($iMode == '2') { echo $sStatusON;} else {echo $sStatusOFF;}?>" class="imgCls"><h1 class="textOnOff" style="color:<?php if($iMode == '2') { echo $sColorON;} else {echo $sColorOFF;}?>" ><?php if($iMode == '2') { echo $sStatusON;} else {echo $sStatusOFF;}?></h1>
				</div>
				<div style="margin-top: 15px;">
				<a style="float:right;" <?php if($iMode == '2') { echo 'disabled="disabled"';} ?> href="javascript:void(0);" <?php if($sAccess == 2) {echo 'onclick="submitForm(\'2\');"';} ?> class="btn btn-icon btn-icon-right btn-icon-checkout btn-green btn-middle"><span>Enable Mode</span></a>
				</div>
			</div>
        </div>
		<div class="col-sm-4">
			<div class="controls boxed controlMode" style="height: 250px;">
			<h2>Time-Out</h2>
			<div>
					<img src="<?php if($iMode == '3') { echo $sImageON;} else {echo $sImageOFF;}?>" alt="<?php if($iMode == '3') { echo $sStatusON;} else {echo $sStatusOFF;}?>" class="imgCls"><h1 class="textOnOff" style="color:<?php if($iMode == '3') { echo $sColorON;} else {echo $sColorOFF;}?>" ><?php if($iMode == '3') { echo $sStatusON;} else {echo $sStatusOFF;}?></h1>
				</div>
				<div style="margin-top: 15px;">
				<a style="float:right;" <?php if($iMode == '3') { echo 'disabled="disabled"';} ?> href="javascript:void(0);" <?php if($sAccess == 2) {echo 'onclick="submitForm(\'3\');"';} ?> class="btn btn-icon btn-icon-right btn-icon-checkout btn-green btn-middle"><span>Enable Mode</span></a>
				</div>
			</div>
        </div>
	</div>
</form>
      
<script type="text/javascript">
  function submitForm(iMode)
  {
		if(iMode == 5)
		{
			$("#iMode").val('1');
			$("#ValveDefaultPosition").val('1');
		}
		else
		{
			$("#iMode").val(iMode);
			$("#ValveDefaultPosition").val('0');	
		}
		
		<?php if($_SERVER['REMOTE_ADDR'] != '14.142.41.62') { ?>
		$("#formChangeMode").submit();	
		<?php } else { ?>
		if($("#iMode").val() == '1')
		{
			$.ajax({
				type: "POST",
				url: "<?php echo site_url('device/GetRunningValveCount/');?>", 
				data: {},
				success: function(ValveCount) 
				{
					if(ValveCount > 0)
					{
						$.confirm({
							title: 'Turn Valve OFF',
							content: 'Do you want to turn valves off prior to resuming auto mode?',
							confirmButton: 'No',
							cancelButton: 'Yes',
							autoClose: 'cancel|60000',
							confirmButtonClass: 'btn-info sc-btn',
							cancelButtonClass: 'btn-danger sc-btn',
							columnClass: 'col-md-6 col-md-offset-3',
							confirm: function(){
								$("#formChangeMode").submit();
							},
							cancel: function(){
							}
						});
					}
					else
					{
						$("#formChangeMode").submit();
					}
				}
			});	
		}
		else
		{
			$("#formChangeMode").submit();	
		}
		<?php } ?>
		
  }
  
  function submitFormPoolSpa(iMode)
  {
	  
	  $.ajax({
			type: "POST",
			url: "<?php echo site_url('home/updatePoolSpaMode/');?>", 
			data: {iMode:iMode},
			success: function(data) {
				alert("Mode started successfully!");
				location.reload();
			}
		});
  }
  function GetDefaultValveNumbers()
  {
		var number = prompt("Enter Number of Valves Run At a Time","");


		if(number == '')
		{
			alert("Please Enter a Number!");
			GetDefaultValveNumbers();
		}
		else if (isNaN(number))
		{
			alert("Please Enter a Valid Number!");
			GetDefaultValveNumbers();
		}
		else
		{
			if(number != null)
			{
				$("#ValveNumber").val(number);
				submitForm(5);
			}
		}
  }
</script>
