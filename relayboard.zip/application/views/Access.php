<?php


?>
    <div id="page-wrapper">
        <div class="row">
          <div class="col-lg-12">
            <ol class="breadcrumb">
				  <li><img src="<?php echo HTTP_IMAGES_PATH.'icons/home.png';?>" width="24" style="vertical-align: middle !important;">&nbsp;<a href="<?php echo site_url();?>">Home</a> </li>
				   <li><a href="<?php echo base_url('dashboard/users');?>">All Users</a></li>
				  <li class="active">Permissions</li>
				  <span style="float:right;"><a class="btn btn-green btn-small" onclick="javascript:document.permissionForm.submit();"><span>Update Permissions</span></a>&nbsp;&nbsp;<a class="btn btn-red btn-small" onclick="javascript:location.href='<?php echo base_url('dashboard/users');?>';"><span>Back</span></a></span>
			</ol>
          </div>
        </div><!-- /.row -->
        <div class="row">
          <div class="col-lg-12">
            <div class="panel panel-primary">
              <div class="panel-heading" style="border-top-left-radius: 0px;border-top-right-radius: 0px;">
                <h3 class="panel-title" style="color:#FFF;">Manage Permissions For <?php echo $userName;?></h3>
              </div>
              <div class="panel-body">
                <div id="morris-chart-area">
                  <form name="permissionForm" id="permissionForm" action="<?php echo site_url('dashboard/accessAddEdit/'.base64_encode($userID));?>" method="post">
				    <input type="hidden" name="userID" value="<?php echo $userID; ?>">
				    <table class="table table-bordered table-striped tablesorter">
					<thead>
					  <tr>
						<th class="header">Module Name&nbsp;<i class="fa fa-sort"></i></th>
						<th class="header">Block</th>
						<th class="header">View</th>
						<th class="header">View & Change</th>
						
					  </tr>
					</thead>
					<tbody>
					<?php if(!empty($allActiveModules))
						  {
							  foreach($allActiveModules as $Module)
							  {
								  $sPermission	=	$this->access_model->getPermissionForModule($userID,$Module->id)
					?>			 <tr>
									<td><?php echo $Module->module_name;?></td>
									<td><input type="radio" name="radioAccess_<?php echo $Module->id;?>" value="0" checked="checked" <?php if($sPermission == '0') {echo 'checked="checked"';} ?>>
									</td>
									<td><input type="radio" name="radioAccess_<?php echo $Module->id;?>" value="1" <?php if($sPermission == '1') {echo 'checked="checked"';} ?>></td>
									<td><input type="radio" name="radioAccess_<?php echo $Module->id;?>" value="2" <?php if($sPermission == '2') {echo 'checked="checked"';} ?>></td>
									
								 </tr>
					<?php	  }
						  }
					?>	  
					
					</tbody>
					</table>
                  </form>
                </div>
              </div>
            </div>
          </div>
        </div><!-- /.row -->
		<div class="row">
          <div class="col-lg-12">
            <ol class="breadcrumb">
			<span style="float:right;"><a class="btn btn-green btn-small" onclick="javascript:document.permissionForm.submit();"><span>Update Permissions</span></a>&nbsp;&nbsp;<a class="btn btn-red btn-small" onclick="javascript:location.href='<?php echo base_url('dashboard/users');?>';"><span>Back</span></a></span>
              <div style="clear: both;"></div>
            </ol>
          </div>
        </div><!-- /.row -->
      </div><!-- /#page-wrapper -->
<script type="text/javascript">
$(document).ready(function (){
	
});
  function checkForm()
  {
	return true;
  }
</script>

<?php

?>