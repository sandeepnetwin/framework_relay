<?php
	
	if (!defined('BASEPATH')) exit('No direct script access allowed');

	class Myclass
    {
		private $CI;
		
		function __construct()
		{
			session_start();
			$this->CI = &get_instance();
		}
		function check()
		{
			/* $methodName	=	$this->CI->router->fetch_method();
			//print_r($this->CI->session->all_userdata());
			if ($this->CI->session->userdata('is_admin_login') == "" )  // If no session found redirect to login page.
			{
				if($methodName != 'login' && $methodName != 'do_login')
				{
					redirect(site_url("dashboard/login"));
					die;
				}
			} */
			
			//if($_SERVER['REMOTE_ADDR'] == '14.142.41.62')
			//echo "current : ".date('Y-m-d H:i:s');
		}
		
	}
?>