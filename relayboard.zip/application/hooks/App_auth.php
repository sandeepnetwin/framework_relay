<?php
	class App_auth
    {
		private $CI;

		function __construct()
		{
			$this->CI = &get_instance();
		}

		function index()
		{
			echo 'HERE';
			if ($this->CI->session->userdata('is_admin_login') == "" )  // If no session found redirect to login page.
			{
				redirect(site_url("dashboard/login"));
			}
		}
	}
?>