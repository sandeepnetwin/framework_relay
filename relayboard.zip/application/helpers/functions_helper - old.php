<?php
/**
* @Programmer: DHIRAJ S.
* @Created: 17 DEC 2015
* @Modified: 
* @Description: Functions to execute the commands on the relayboard.
**/

	function execute_command($sCommand)
	{
		$response = shell_exec($sCommand);
		
		if(stripos($response, '?') !== FALSE)
		{
			die('Invalid response: '.$response.' \n Please try again after some Time! \n');
		}
		
		return $response;
	}
	
	function send_command_udp_new($IP,$PORT,$aPumps)
	{
		$aPumpNumber	=	json_decode($aPumps);
		$sServer 		= 	$IP;
		$iPort 			=	$PORT;
		
		$cntPump		=	count($aPumpNumber);
		
		$server = $sServer;
		$port = 13330;
		
		if(!($sSock = socket_create(AF_INET, SOCK_DGRAM, 0)))
		{
			$iErrorcode = socket_last_error();
			$sErrormsg = socket_strerror($iErrorcode);
			 
			die("Couldn't create socket: [$iErrorcode] $sErrormsg \n");
		} 
		
		socket_connect ( $sSock , $server , $port );
		//$line = socket_read ($sSock, 1024) or die("Could not read server response\n");
		//var_dump($line);
		$package = "\x07\x00";
		socket_send($sSock, $package, strLen($package), 0);
		$line1 = socket_read($sSock, 255);
		$strPumpResponse	= '';
		
		$package = "\x06\x00";
		socket_send($sSock, $package, strLen($package), 0);
		//echo $cntPump;
		
		for($i=0;$i<$cntPump; $i++)
		{
			$strResponse = socket_read($sSock, 255);
			while(preg_match('/^S/',$strResponse))
			{
                $strResponse = socket_read($sSock, 255);
			}
			if($strPumpResponse == '')
			{
				$strPumpResponse = $strResponse;
			}
			else
			{
				$strPumpResponse .= '|||'.$strResponse;
			}				
		}
		
		$package ="\x7f\x00";
		socket_send($sSock, $package, strLen($package), 0);
		
		//$line3 = socket_read($sSock, 255);
		//var_dump($line3); 
		
		socket_close($sSock);
		//die('STOP');
		return $strPumpResponse;
	}
	
	function response_input_switch($IP,$PORT)
	{
		$aPumpNumber	=	json_decode($aPumps);
		$sServer 		= 	$IP;
		$iPort 			=	$PORT;
		
		$cntPump		=	count($aPumpNumber);
		
		$server = $sServer;
		$port = 13330;
		
		if(!($sSock = socket_create(AF_INET, SOCK_DGRAM, 0)))
		{
			$iErrorcode = socket_last_error();
			$sErrormsg = socket_strerror($iErrorcode);
			 
			die("Couldn't create socket: [$iErrorcode] $sErrormsg \n");
		} 
		
		socket_connect ( $sSock , $server , $port );
		$package = "\x07\x00";
		socket_send($sSock, $package, strLen($package), 0);
		$line1 = socket_read($sSock, 255);
		//var_dump($line1);
		$strPumpResponse	= '';
		
		$package = "\x06\x00";
		socket_send($sSock, $package, strLen($package), 0);
		
		$strResponse = socket_read($sSock, 255);
		while(!preg_match('/^S/',$strResponse))
		{
			$strResponse = socket_read($sSock, 255);
		}			
		
		$package ="\x7f\x00";
		socket_send($sSock, $package, strLen($package), 0);
		socket_close($sSock);
		
		return $strResponse;
	}
	
	function get_rlb_status()
	{
		$aReturn = array();
		$sUrl = 'rlb s';
		$sResponse = execute_command($sUrl);
		
		$aResponse = explode(',',$sResponse);
		
		$aReturn['response'] = $sResponse;
		//$aReturn['day'] = $aResponse['3'];
		$aReturn['day'] = (isset($aResponse['3'])) ? $aResponse['3'] : '';
		$aReturn['time'] = (isset($aResponse['4'])) ? $aResponse['4'] : '';
		$aReturn['valves'] = (isset($aResponse['7'])) ? $aResponse['7'] : '';
		$aReturn['relay'] = (isset($aResponse['8'])) ? $aResponse['8'] : '';
		$aReturn['powercenter'] = (isset($aResponse['9'])) ? $aResponse['9'] : '';
		
		$aReturn['TS0'] = (isset($aResponse['15'])) ? $aResponse['15'] : '';
		$aReturn['TS1'] = (isset($aResponse['16'])) ? $aResponse['16'] : '';
		$aReturn['TS2'] = (isset($aResponse['17'])) ? $aResponse['17'] : '';
		$aReturn['TS3'] = (isset($aResponse['18'])) ? $aResponse['18'] : '';
		$aReturn['TS4'] = (isset($aResponse['19'])) ? $aResponse['19'] : '';
		$aReturn['TS5'] = (isset($aResponse['20'])) ? $aResponse['20'] : '';

		$aReturn['AP0'] = (isset($aResponse['10'])) ? $aResponse['10'] : '';
		$aReturn['AP1'] = (isset($aResponse['11'])) ? $aResponse['11'] : '';
		$aReturn['AP2'] = (isset($aResponse['12'])) ? $aResponse['12'] : '';
		$aReturn['AP3'] = (isset($aResponse['13'])) ? $aResponse['13'] : '';		
				
		$aReturn['push'] = (isset($aResponse['22'])) ? $aResponse['22'] : '';
		$aReturn['level_sensor_instant'] = (isset($aResponse['21'])) ? $aResponse['21'] : '';
		$aReturn['remote_spa_ctrl_st'] = (isset($aResponse['22'])) ? $aResponse['22'] : '';
		$aReturn['level_sensor_avg'] = (isset($aResponse['23'])) ? $aResponse['23'] : '';
		$aReturn['pump_seq_0_st'] = (isset($aResponse['24'])) ? $aResponse['24'] : '';
		$aReturn['pump_seq_1_st'] = (isset($aResponse['25'])) ? $aResponse['25'] : '';
		$aReturn['pump_seq_2_st'] = isset($aResponse['26']) ? $aResponse['26'] : '';
		
		return $aReturn;
	}
	
	function replace_return($sStr, $sReplace, $iReplace){
		$iStrCount = strlen($sStr);
		$sReturn = '';
		for($iStr = 0; $iStr < $iStrCount; $iStr++){
			if($iStr == $iReplace){
				$sReturn .= $sReplace;
			}else{
				$sReturn .= $sStr[$iStr];
			}
		}
		return $sReturn;
	}
	
	function onoff_rlb_relay($sRelayStatus){
		$sUrl = 'rlb R,'.$sRelayStatus;
		$sResponse = execute_command($sUrl);	
		if ($sResponse === false) 
		{
			return 0;
		}	
		return 1;
	}

	function onoff_rlb_powercenter($sPowercenterStatus){
		$sUrl = 'rlb B,'.$sPowercenterStatus;
		$sResponse = execute_command($sUrl);	
		if ($sResponse === false) 
		{
			return 0;
		}	
		return 1;
	}
	
	function onoff_rlb_valve($sRelayStatus){
		$sUrl = 'rlb V,'.$sRelayStatus;
		$sResponse = execute_command($sUrl);	
		if ($sResponse === false) 
		{
			return 0;
		}	
		return 1;
	}

	function onoff_rlb_pump($sRelayStatus){
		$sUrl = 'rlb m '.$sRelayStatus;
		$sResponse = execute_command($sUrl);	
		if ($sResponse === false) 
		{
			return 0;
		}	
		return 1;
	}
	
	function getAddressToPump($sDeviceNumber){
		$sUrl = 'rlb p pm'.$sDeviceNumber;
		$sResponse = execute_command($sUrl);	
		if ($sResponse === false) 
		{
			return 0;
		}	
		return 1;
	}
	
	function assignAddressToPump($sDeviceNumber,$sAddress){
		$sUrl = 'rlb p pm'.$sDeviceNumber.' '.$sAddress;
		$sResponse = execute_command($sUrl);	
		if ($sResponse === false) 
		{
			return 0;
		}	
		return 1;
	}
	
	function assignValvesToRelay($sHexNumber){
		$sUrl = 'rlb p vlm '.$sHexNumber;
		$sResponse = execute_command($sUrl);	
		if ($sResponse === false) 
		{
			return 0;
		}	
		return 1;
	}
	
	function getTempratureBus($sHexNumber){
		$sUrl = 'rlb t';
		$sResponse = execute_command($sUrl);	
		if ($sResponse === false) 
		{
			return 0;
		}	
		return 1;
	}
	
	function configureTempratureBus($TS,$BUS)
	{
		$sUrl = 'rlb p '.$TS.' '.$BUS;
		
		$sResponse = execute_command($sUrl);	
		if ($sResponse === false) 
		{
			return 0;
		}	
		return 1;
	}
	
	function removePumpAddress($Pump)
	{
		$sUrl = 'rlb p '.$Pump.' 0';
		$sResponse = execute_command($sUrl);	
		if ($sResponse === false) 
		{
			return 0;
		}	
		return 1;
	}

	function switch_arrays($aOrig, $aNew){
		$aReturn = array();
		foreach($aNew as $vNew){
			$aReturn[] = $aOrig[$vNew];
		}
		return $aReturn;
	}

	function update_prog_status($iProgId, $iStatus){
		if($iProgId){
			$sSqlUpdate = "UPDATE rlb_relay_prog SET relay_prog_active='".$iStatus."' WHERE relay_prog_id='".$iProgId."'";
			$rResult = mysql_query($sSqlUpdate) or die('ERR: @sSqlUpdate=> '.mysql_error());
		}
	}
	
	function get_current_mode(){
		//get list of relay modes.
		$iMode = '';
		$sSql = "SELECT * FROM rlb_modes WHERE mode_status='1' ";
		$rResult = mysql_query($sSql) or die('ERR: @sSql=> '.mysql_error());
		$iCnt = mysql_num_rows($rResult);
		if($iCnt){
			$aRow = mysql_fetch_assoc($rResult);
			$iMode = $aRow['mode_id'];
		}
		return $iMode;
	}
	
	/*function to return device name
	* @iDeviceType => 1-Relay, 2-Valve, 3-Powercenter
	* @iDeviceNum => As per availabel device type start from 0 - n
	*/
	function get_device_name($iDeviceType, $iDeviceNum){
		$aDeviceType = array(1, 2, 3);
		$aDeviceTypeName = array( '1' => 'Relay', '2' => 'Valve' , '3' => 'Powercenter');
		$aTbl = array('1' => 'rlb_relays', '2' => 'rlb_valves', '3' => 'rlb_powercenters');
		$aFldWhere = array('1' => 'relay_number', '2' => 'valve_number', '3' => 'powercenter_number');
		$aFldSel = array('1' => 'relay_name', '2' => 'valve_name', '3' => 'powercenter_name');
		$sDeviceNameAE = $aDeviceTypeName[$iDeviceType].' '.$iDeviceNum;
		
		if(is_numeric($iDeviceNum) && in_array($iDeviceType, $aDeviceType)){
			$sSqlEdit = "SELECT * FROM ". $aTbl[$iDeviceType] ." WHERE ". $aFldWhere[$iDeviceType] ." ='".$iDeviceNum."'";
			$rResultEdit = mysql_query($sSqlEdit) or die('ERR: @sSqlEdit=> '.mysql_error());
			$iCnt = mysql_num_rows($rResultEdit);
			if($iCnt){
				$aRowEdit = mysql_fetch_assoc($rResultEdit);
				$sDeviceNameAE = stripslashes($aRowEdit[$aFldSel[$iDeviceType]]);
			}
		}
		return $sDeviceNameAE;
	}
	
	
	function getPermissionOfModule($userID)
	{
		$CI = get_instance();
		$CI->load->model('access_model');
		$aPermissions = $CI->access_model->getPermission($userID);
		$aModules	= array();
		$aReturn	= array();
		
		//var_dump($aPermissions);
		if(!empty($aPermissions))
		{
		  foreach($aPermissions as $sPermission)
		  {
			$aModules['ids'][] = $sPermission->module_id;
			$aModules['access_'.$sPermission->module_id] = $sPermission->access;
		  }
		}  
		
		$CI->load->model('user_model');
	    $aAllMActiveModule	=	$CI->user_model->getAllModulesActive();
		
		$aReturn['sPermissionModule']	=	$aModules;
		$aReturn['sActiveModule']		=	$aAllMActiveModule;
		
		return json_encode($aReturn);
	}
	
	function getModuleAccess($sModule)
	{
		$CI = get_instance();
		$CI->load->model('access_model');
	    $aPermissions = $CI->access_model->getPermission($userID);
	}
	
?>