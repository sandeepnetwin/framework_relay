<?php
	/**
    * @Programmer: Dhiraj S.
    * @Created: 11 Feb 2016
    * @Modified: 
    * @Description: Custom Model for the functions related to the Custom Program.
    **/
	
if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Custom_model extends CI_Model 
{

    public function __construct() 
    {
        parent::__construct();
    }
    
	/**
	  * Function to Get the current Running Device for Program.
	  * @param programID
	  * @return Current Running Device Details Or Blank
	**/
	public function getCustomProgrmaCurrentDevice($programID)
	{
	   $sSql   =   "SELECT id,current_on_device,device_type,device_number,current_on_time,current_off_time,current_sequence,ip_id FROM rlb_custom_program_current WHERE program_id = '".$programID."' AND current_device_complete = '0'";
	   $query  =   $this->db->query($sSql);

	   if ($query->num_rows() > 0)
	   {
			return $query->result();
	   }

	   return '';
	}
	
	/**
	  * Function to Save Current Running Device For Program.
	  * @param arrDetails : current Device details
	  * @return Blank
	**/
	public function saveCustomCurrentRunningDevice($arrDetails)
	{
	   $sProgramDeviceStart =   date("H:i:s", time());
	   $aStartTime       		=   explode(":",$sProgramDeviceStart);
	   $sProgramDeviceEnd   =   mktime(($aStartTime[0]),($aStartTime[1]+(int)$arrDetails['current_on_time']),($aStartTime[2]),date('m'),date('d'),date('Y'));
	   
	   $arrDetails['current_on_time'] 	=	date('Y-m-d').' '.$sProgramDeviceStart;
	   $arrDetails['current_off_time']	=	date("Y-m-d H:i:s", $sProgramDeviceEnd);
	   
	   $this->db->insert('rlb_custom_program_current',$arrDetails);
	}

	/**
	  * Function to Save Source and Start Time of the Custom Program.
	  * @param programID, Start From, Start Time
	  * @return Blank
	**/
	public function saveCustomStartSourceDetails($ProgramID,$StartFrom,$StartDate)
	{
			$InsertData = array('CustomProgramId'=>$ProgramID,'StartedFrom'=>$StartFrom,'StartDate'=>$StartDate);
			$this->db->insert('rlb_custom_program_run_details',$InsertData);
	}

	/**
	  * Function to Save Source and Start Time of the Custom Program.
	  * @param programID, Stop From, Stop Time, Is Completed
	  * @return Blank
	**/
	public function saveCustomStopSourceDetails($ProgramID,$StopFrom,$EndDate,$IsCompleted)
	{
		  $this->db->select('id');
			$this->db->where('CustomProgramId',$ProgramID);
			$this->db->order_by('id','desc');
			$this->db->limit(1);
			$Query = $this->db->get('rlb_custom_program_run_details');

			if($Query->num_rows() > 0)
			{
					foreach($Query->result() as $Result)
					{
							$UpdateData = array('StoppedFrom'=>$StopFrom,'IsCompleted'=>$IsCompleted,'EndDate'=>$EndDate);
							$this->db->where('id',$Result->id);
							$this->db->update('rlb_custom_program_run_details',$UpdateData);
					}
			}
	}
	
	/**
	  * Function to Save Current Device Details IN Log table After Complete Run.
	  * @param programID, deviceType
	  * @return Blank
	**/
	public function saveCustomEntryInLog($programID,$deviceType)
	{
	   $sSql   =   "SELECT * FROM rlb_custom_program_current WHERE program_id = '".$programID."' AND device_type = '".$deviceType."'";
	   $query  =   $this->db->query($sSql);

	   if ($query->num_rows() > 0)
	   {
			foreach($query->result() as $rowResult)
			{
				$strInsertInLog = "INSERT INTO rlb_custom_program_log(	program_id,device,device_type,device_number,device_start,device_stop,device_complete_run,current_sequence,ip_id,unique_id) VALUES('".$programID."','".$rowResult->current_on_device."','".$rowResult->device_type."','".$rowResult->device_number."','".$rowResult->current_on_time."','".$rowResult->current_off_time."','1','".$rowResult->current_sequence."','".$rowResult->ip_id."','".$rowResult->unique_id."')";
				
				$this->db->query($strInsertInLog);
				//if($_SERVER['REMOTE_ADDR'] == '14.142.41.62')
				//$this->db->last_query();
			}
	   }
	}
	
	/**
	  * Function to Delete Current Device Details From Current Table.
	  * @param programID
	  * @return Blank
	**/
	public function deleteCustomEntryFromCurrent($programID,$deviceType='',$deviceNumber='')
	{
		if($deviceType != '' && $deviceNumber != '')
		{
			$extra = "AND device_number='".$deviceNumber."' AND device_type = '".$deviceType."'";
		}
		$sSql   =   "DELETE FROM rlb_custom_program_current WHERE program_id = '".$programID."' ".$extra;
		$query  =   $this->db->query($sSql);
	}
	
	/**
	  * Function to Turn OFF the Custom Program.
	  * @param programID, sStatus
	  * @return Blank
	**/
	public function offCustomProgram($programID,$sStatus)
	{
		$aData = array('is_on'=>$sStatus,'unique_id'=>'');
		$this->db->where('id',$programID);
		$this->db->update('rlb_custom_program',$aData);
	}
	
	
	/**
	  * Function to Get the After Running Device for Program.
	  * @param programID
	  * @return Current Running Device Details Or Blank
	**/
	public function getCustomProgrmaAfterDevice($programID)
	{
	   $sSql   =   "SELECT id,current_on_device,device_type,device_number,current_on_time,current_off_time,current_sequence,ip_id FROM rlb_custom_program_after WHERE program_id = '".$programID."' AND current_device_complete = '0'";
	   $query  =   $this->db->query($sSql);

	   if ($query->num_rows() > 0)
	   {
			return $query->result();
	   }

	   return '';
	}
	
	/**
	  * Function to Save After Running Device For Program.
	  * @param arrDetails : current Device details
	  * @return Blank
	**/
	public function saveCustomAfterRunningDevice($arrDetails)
	{
	   $sProgramDeviceStart =   date("H:i:s", time());
	   $aStartTime       	=   explode(":",$sProgramDeviceStart);
	   $sProgramDeviceEnd   =   mktime(($aStartTime[0]),($aStartTime[1]+(int)$arrDetails['current_on_time']),($aStartTime[2]),date('m'),date('d'),date('Y'));
	   
	   $arrDetails['current_on_time'] 	=	date('Y-m-d').' '.$sProgramDeviceStart;
	   $arrDetails['current_off_time']	=	date("Y-m-d H:i:s", $sProgramDeviceEnd);
	   
	   $this->db->insert('rlb_custom_program_after',$arrDetails);
	}
	
	/**
	  * Function to Save Current Device of after program Details IN Log table After Complete Run.
	  * @param programID, deviceType
	  * @return Blank
	**/
	public function saveCustomAfterEntryInLog($programID,$deviceType)
	{
	   $sSql   =   "SELECT * FROM rlb_custom_program_after WHERE program_id = '".$programID."' AND device_type = '".$deviceType."'";
	   $query  =   $this->db->query($sSql);

	   if ($query->num_rows() > 0)
	   {
			foreach($query->result() as $rowResult)
			{
				$strInsertInLog = "INSERT INTO rlb_custom_program_log(	program_id,device,device_type,device_number,device_start,device_stop,device_complete_run,current_sequence,ip_id,unique_id,afterDevice) VALUES('".$programID."','".$rowResult->current_on_device."','".$rowResult->device_type."','".$rowResult->device_number."','".$rowResult->current_on_time."','".$rowResult->current_off_time."','1','".$rowResult->current_sequence."','".$rowResult->ip_id."','".$rowResult->unique_id."','1')";
				
				$this->db->query($strInsertInLog);
			}
	   }
	}
	
	/**
	  * Function to Delete After Device Details From Current Table.
	  * @param programID
	  * @return Blank
	**/
	public function deleteCustomEntryFromAfter($programID,$deviceType='',$deviceNumber='')
	{
		if($deviceType != '' && $deviceNumber != '')
		{
			$extra = "AND device_number='".$deviceNumber."' AND device_type = '".$deviceType."'";
		}
		$sSql   =   "DELETE FROM rlb_custom_program_after WHERE program_id = '".$programID."' ".$extra;
		$query  =   $this->db->query($sSql);
	}
	
	/**
	  * Function to Delete ALL records FROM Current and after Table.
	  * @param 
	  * @return Blank
	**/
	public function deleteAllEntryFromCurrentAfter()
	{
		$sSqlCurrent   =   "DELETE FROM rlb_custom_program_current";
		$queryCurrent  =   $this->db->query($sSqlCurrent);
		
		$sSqlAfter   =   "DELETE FROM rlb_custom_program_after";
		$queryAfter  =   $this->db->query($sSqlAfter);
		
	}
	
	/**
	* Function to Get all Active Custom Programs.
	* 
	* @return
	*/
	public function GetAllActiveCustomPrograms()
	{
		$ArrResponse = array();
		$this->db->select("id,program_details");
		$this->db->where("isremoved","0");
		
		$QueryGetCustomProgram = $this->db->get('rlb_custom_program');
		
		if($QueryGetCustomProgram->num_rows() > 0)
		{
			foreach($QueryGetCustomProgram->result() as $Result)
			{
				$ArrTemp	 = json_decode($Result->program_details);
				
				$ProgramName = str_replace("_"," ",$ArrTemp->g_custom_mode_name);
				$ArrResponse[$Result->id] = $ProgramName;	
			}
		}
		
		$QueryGetCustomProgram->free_result();
		
		return $ArrResponse;
		
	}
}
?>
