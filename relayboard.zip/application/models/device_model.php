<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Device_model extends CI_Model 
{
    public function __construct() 
    {
        parent::__construct();
    }
	
	/**
	* Function to Get All Custom Program Details.
	* @param
	* @return Custom Program Details
	**/
	public function getAllCustomPrograms()
	{
		$query = $this->db->select('id,program_details,display_access,is_on')->where('isremoved','0')->get('rlb_custom_program');
		if($query->num_rows() > 0)
		{
			return $query->result();
		}
		return '';
	}
	
	/**
	* Function to Change the Display Access of Custom Program.
	* @param
	* @return
	**/
	public function changeCustomProgramDisplay($customProgramID,$status)
	{
		$data = array('display_access'=>$status);
		$this->db->where('id',$customProgramID);
		$this->db->update('rlb_custom_program',$data);
	}
	
	/**
	* Function to Save Custom Program Details.
	* @param
	* @return
	**/
	public function saveCustomProgram($programDetails,$isSchedule,$customProgramStart,$customProgramEnd,$sProgramType,$sProgramDays)
	{
		$data = array('g_id'=>'1',
					  'program_details'=>$programDetails,
					  'is_schedule'=>$isSchedule,
					  'program_schedule_start'=>$customProgramStart,
					  'program_schedule_end'=>$customProgramEnd,
					  'program_type'=>$sProgramType,
					  'program_days'=>$sProgramDays
					  );
		$this->db->insert('rlb_custom_program',$data);
	}
	
	/**
	* Function to Get Custom Program Details.
	* @param
	* @return
	**/
	public function getCustomProgramDetails($customProgramID)
	{
		$query = $this->db->select("program_details,display_access")->where('id',$customProgramID)->get('rlb_custom_program');
		if($query->num_rows() > 0)
		{
			return $query->result();
		}
		
		return '';
	}
	
	
	/**
	* Function to Update Custom Program Details.
	* @param
	* @return
	**/
	public function updateCustomProgram($customProgramID,$programDetails,$isSchedule,$customProgramStart,$customProgramEnd)
	{
		$data = array('g_id'=>'1',
					  'program_details'=>$programDetails,
					  'is_schedule'=>$isSchedule,
					  'program_schedule_start'=>$customProgramStart,
					  'program_schedule_end'=>$customProgramEnd
					  );
		$this->db->where('id',$customProgramID);
		$this->db->update('rlb_custom_program',$data);
	}
	
	/**
	* Function to Delete Custom Program Details.
	* @param
	* @return
	**/
	public function deleteCustomProgram($customProgramID)
	{
		$data = array('isremoved'=>'1');
		$this->db->where('id',$customProgramID);
		$this->db->update('rlb_custom_program',$data);
		
	}
	
	/**
	* Function to Get All schedule Custom Program Details.
	* @param
	* @return
	**/
	public function getScheduleProgram()
	{
		$query = $this->db->select("id,program_details,display_access,is_on,afterProgram,previousState,program_schedule_start,program_schedule_end")->where(array('is_schedule'=>'1','schedule_run'=>'0'))->get('rlb_custom_program');
		if($query->num_rows() > 0)
		{
			return $query->result();
		}
		
		return '';
	}
	
	
    /**
	* Function to Get All Heaters those are running.
	* @param
	* @return List of Running Heaters
	**/
	public function getAllRunningHeaters()
	{
		$query = $this->db->select("id,heaterNumber,ip_id,heaterStart,heaterEnd")->where('heaterRun','1')->get('rlb_heater_run');
		if($query->num_rows() > 0)
		{
			return $query->result();
		}
		
		return '';
	}
	
	/**
	* Function to Get All Heaters those are running.
	* @param
	* @return List of Running Heaters
	**/
	public function getAllAfterRunningProgramID()
	{
		$arrProgramID = array();
		//Get the program ID from the Valve default position run table.
		$query = $this->db->select("DISTINCT(program_id)")->from("rlb_valve_default_position_run")->get();
		if($query->num_rows() > 0)
		{
			foreach($query->result() as $result)
			{
				if(!in_array($result->program_id,$arrProgramID))
				{
					$arrProgramID[] = $result->program_id;
				}
			}
		}
		
		//Get the program ID from the Pump run after heater table.
		$query = $this->db->select("DISTINCT(program_id)")->from("rlb_run_after_heater")->where('runComplete','0')->get();
		if($query->num_rows() > 0)
		{
			foreach($query->result() as $result)
			{
				if($result->program_id != 0)
				{
					if(!in_array($result->program_id,$arrProgramID))
					{
						$arrProgramID[] = $result->program_id;
					}
				}
			}
		}
		
		return $arrProgramID;
	}
	
	/**
	* Function to Get All Heaters those are running.
	* @param
	* @return List of Running Heaters
	**/
	public function selectRunningDeviceDetails($ProgramID)
	{
		$arrDeviceDetails = array();
		//Get all running valves those are running after program completion.
		$query = $this->db->select('valve,ip_id,start_time,end_time')->from('rlb_valve_default_position_run')->where('program_id',$ProgramID)->get();
		if($query->num_rows() > 0)
		{
			foreach($query->result() as $result)
			{
				$Device = $result->valve.'_'.$result->ip_id;
				if(!in_array($Device,$arrDeviceDetails))
				{
					$arrDeviceDetails[$Device]['start_time'] 	= $result->start_time;
					$arrDeviceDetails[$Device]['end_time'] 		= $result->end_time;
					$arrDeviceDetails[$Device]['device_type'] 	= 'V';
				}
			}
		}
		
		//Get all running pumps those are running after program/heater completion.
		
		$query = $this->db->select('pumpNumber,ip_id,heaterStopTime,PumpStopTime')->from('rlb_run_after_heater')->where('program_id',$ProgramID)->get();
		if($query->num_rows() > 0)
		{
			foreach($query->result() as $result)
			{
				$Device = $result->pumpNumber.'_'.$result->ip_id;
				if(!in_array($Device,$arrDeviceDetails))
				{
					$arrDeviceDetails[$Device]['start_time'] 	= $result->heaterStopTime;
					$arrDeviceDetails[$Device]['end_time'] 		= $result->PumpStopTime;
					$arrDeviceDetails[$Device]['device_type'] 	= 'P';
				}
			}
		}
		
		return $arrDeviceDetails;
	}
	
	
}

/* End of file device_model.php */
/* Location: ./application/models/device_model.php */