<?php
/**
 *	Project : Relayboard 
 *	Program/Module Name : Device Model
 *	Author : Dhiraj S. 
 *	Creation Date : 16/11/2016 
 *	Description : 
 *	Modification History : 
 *	Change Date: mm/dd/yyyy	Name: 
**/


if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Device_model extends CI_Model 
{
    public function __construct() 
    {
        parent::__construct();
    }
	
	/**
	* Function to Get All Custom Program Details.
	* @param
	* @return Custom Program Details
	**/
	public function getAllCustomPrograms()
	{
		$query = $this->db->select('id,program_details,display_access,is_on')->where('isremoved','0')->get('rlb_custom_program');
		if($query->num_rows() > 0)
		{
			return $query->result();
		}
		return '';
	}
	
	/**
	* Function to Change the Display Access of Custom Program.
	* @param
	* @return
	**/
	public function changeCustomProgramDisplay($customProgramID,$status)
	{
		$data = array('display_access'=>$status);
		$this->db->where('id',$customProgramID);
		$this->db->update('rlb_custom_program',$data);
	}
	
	/**
	* Function to Save Custom Program Details.
	* @param
	* @return
	**/
	public function saveCustomProgram($programDetails,$isSchedule,$customProgramStart,$customProgramEnd,$sProgramType,$sProgramDays,$ProgramTypeStart,$ProgramTypeEnd)
	{
		$data = array('g_id'=>'1',
					  'program_details'=>$programDetails,
					  'is_schedule'=>$isSchedule,
					  'program_type'=>$sProgramType,
					  'program_days'=>$sProgramDays,
					  'program_type_start'=>$ProgramTypeStart,
					  'program_type_end'=>$ProgramTypeEnd
					  );
		$this->db->insert('rlb_custom_program',$data);
	}
	
	/**
	* Function to Get Custom Program Details.
	* @param
	* @return
	**/
	public function getCustomProgramDetails($customProgramID)
	{
		$query = $this->db->select("program_details,display_access,is_schedule,program_type,program_days,program_type_start,program_type_end")->where('id',$customProgramID)->get('rlb_custom_program');
		if($query->num_rows() > 0)
		{
			return $query->result();
		}
		
		return '';
	}
	
	
	/**
	* Function to Update Custom Program Details.
	* @param
	* @return
	**/
	public function updateCustomProgram($customProgramID,$programDetails,$isSchedule,$customProgramStart,$customProgramEnd,$sProgramType,$sProgramDays,$ProgramTypeStart,$ProgramTypeEnd)
	{
		$data = array('g_id'=>'1',
					  'program_details'=>$programDetails,
					  'is_schedule'=>$isSchedule,
					  'program_type'=>$sProgramType,
					  'program_days'=>$sProgramDays,
					  'program_type_start'=>$ProgramTypeStart,
					  'program_type_end'=>$ProgramTypeEnd
					  );
		$this->db->where('id',$customProgramID);
		$this->db->update('rlb_custom_program',$data);

		echo $this->db->last_query();
		exit;
	}
	
	/**
	* Function to Delete Custom Program Details.
	* @param
	* @return
	**/
	public function deleteCustomProgram($customProgramID)
	{
		$data = array('isremoved'=>'1');
		$this->db->where('id',$customProgramID);
		$this->db->update('rlb_custom_program',$data);
		
	}
	
	/**
	* Function to Get All schedule Custom Program Details.
	* @param
	* @return
	**/
	public function getScheduleProgram()
	{
		$query = $this->db->select("id,program_details,display_access,is_on,afterProgram,previousState,program_schedule_start,program_schedule_end")->where(array('is_schedule'=>'1','schedule_run'=>'0'))->get('rlb_custom_program');
		if($query->num_rows() > 0)
		{
			return $query->result();
		}
		
		return '';
	}
	
	
    /**
	* Function to Get All Heaters those are running.
	* @param
	* @return List of Running Heaters
	**/
	public function getAllRunningHeaters()
	{
		$query = $this->db->select("id,heaterNumber,ip_id,heaterStart,heaterEnd")->where('heaterRun','1')->get('rlb_heater_run');
		if($query->num_rows() > 0)
		{
			return $query->result();
		}
		
		return '';
	}
	
	/**
	* Function to Get All Heaters those are running.
	* @param
	* @return List of Running Heaters
	**/
	public function getAllAfterRunningProgramID()
	{
		$arrProgramID = array();
		//Get the program ID from the Valve default position run table.
		$query = $this->db->select("DISTINCT(program_id)")->from("rlb_valve_default_position_run")->get();
		if($query->num_rows() > 0)
		{
			foreach($query->result() as $result)
			{
				if(!in_array($result->program_id,$arrProgramID))
				{
					$arrProgramID[] = $result->program_id;
				}
			}
		}
		
		//Get the program ID from the Pump run after heater table.
		$query = $this->db->select("DISTINCT(program_id)")->from("rlb_run_after_heater")->where('runComplete','0')->get();
		if($query->num_rows() > 0)
		{
			foreach($query->result() as $result)
			{
				if($result->program_id != 0)
				{
					if(!in_array($result->program_id,$arrProgramID))
					{
						$arrProgramID[] = $result->program_id;
					}
				}
			}
		}
		
		return $arrProgramID;
	}
	
	/**
	* Function to Get All Heaters those are running.
	* @param
	* @return List of Running Heaters
	**/
	public function selectRunningDeviceDetails($ProgramID)
	{
		$arrDeviceDetails = array();
		//Get all running valves those are running after program completion.
		$query = $this->db->select('valve,ip_id,start_time,end_time')->from('rlb_valve_default_position_run')->where('program_id',$ProgramID)->get();
		if($query->num_rows() > 0)
		{
			foreach($query->result() as $result)
			{
				$Device = $result->valve.'_'.$result->ip_id.'_V';
				if(!in_array($Device,$arrDeviceDetails))
				{
					$arrDeviceDetails[$Device]['start_time'] 	= $result->start_time;
					$arrDeviceDetails[$Device]['end_time'] 		= $result->end_time;
					$arrDeviceDetails[$Device]['device_type'] 	= 'V';
				}
			}
		}
		
		//Get all running pumps those are running after program/heater completion.
		
		$query = $this->db->select('pumpNumber,ip_id,heaterStopTime,PumpStopTime')->from('rlb_run_after_heater')->where('program_id',$ProgramID)->get();
		if($query->num_rows() > 0)
		{
			foreach($query->result() as $result)
			{
				$Device = $result->pumpNumber.'_'.$result->ip_id.'_PS';
				if(!in_array($Device,$arrDeviceDetails))
				{
					$arrDeviceDetails[$Device]['start_time'] 	= $result->heaterStopTime;
					$arrDeviceDetails[$Device]['end_time'] 		= $result->PumpStopTime;
					$arrDeviceDetails[$Device]['device_type'] 	= 'P';
				}
			}
		}
		
		return $arrDeviceDetails;
	}
	
	/**
	* Function to Check if the relay is assigned to the Heater device.
	* @param
	* @return 
	**/
	public function checkRelayAssignedToHeater($IpID, $Device, $Type)
	{
		$PumpNumber = '';
		$this->db->select('light_relay_number,device_number,ip_id');
		$this->db->where("light_relay_number like '%s:10:\"sRelayType\";s:2:\"".$Type."\";s:12:\"sRelayNumber\";s:".strlen($Device).":\"".$Device."\"%'");
		$this->db->where('ip_id',$IpID);
		$this->db->where('device_type','H');
		
		$Query = $this->db->get("rlb_device");
		//echo $this->db->last_query();
		
		if($Query->num_rows() > 0)
		{
			foreach($Query->result() as $row)
			{
				$Details = unserialize($row->light_relay_number);
				$PumpNumber = $Details['Pump'];
			}
		}

		if($PumpNumber == '')
			$PumpNumber = '0';
			
		return $PumpNumber;	
		
	}
	/**
	* Function to remove all existing entries.
	* 
	* @return
	*/
	public function EmptyCurrentValveDefaultRun()
	{
		$this->db->empty_table('rlb_valve_default_position_current');	
	}
	
	/**
	* Function to save the Valve default position run when Auto mode is Enabled.
	* @param $uniqueID
	* 
	* @return record inserted id
	*/
	public function SaveValveDefaultModeRunDetails($uniqueID,$TotalTime,$ValveNumber)
	{
		$TempStart 		 =   date("H:i:s", time());
		$aStartTime      =   explode(":",$TempStart);
		$TempEnd   		 =   mktime(($aStartTime[0]),($aStartTime[1]+(int)$TotalTime),($aStartTime[2]),date('m'),date('d'),date('Y'));

		$StartTime  =	date('Y-m-d').' '.$TempStart;
		$StopTime   =	date("Y-m-d H:i:s", $TempEnd);
		
		$ArrInsert = array('UniqueID'=>$uniqueID,
						   'StartDateTime' => $StartTime,
						   'EndDateTime' => $StopTime,
						   'DeviceNumberToRun' => $ValveNumber,
						   'StartedFrom'   => '1',
						   'IsRunning' => '1');
		$this->db->insert('rlb_valve_default_position_mode_run',$ArrInsert);	
		
		return $this->db->insert_id();			   
	}
	
	/**
	* Function to Save the Current running Device details for Valve Default Position run when Auto mode is Enabled.
	* @param $ArrInsert
	* 
	* @return
	*/
	public function SaveValveDefaultPositionRunCurrent($ArrInsert)
	{
		$this->db->insert('rlb_valve_default_position_current',$ArrInsert);	
	}
	
	/**
	* Function to Save the Device details which is OFF for Valve Default Position run when Auto mode is Enabled.
	* @param $ArrInsert
	* 
	* @return
	*/
	public function SaveValveDefaultPositionRunLog($ArrInsert)
	{
		$this->db->insert('rlb_valve_default_position_log',$ArrInsert);	
	}
	
	/**
	* Function to Get the current Valve Default Position run mode details.
	* 
	* @return array with details
	*/
	public function GetValveDefaultPositionModeRunDetails()
	{
		$this->db->select('id,UniqueID,DeviceNumberToRun,StartDateTime,EndDateTime,IsCompleted');
		$this->db->where('IsRunning','1');
		$Query = $this->db->get('rlb_valve_default_position_mode_run');
		
		if($Query->num_rows() > 0)
		{
			return $Query->result();	
		}
		
		return '';
	}
	
	/**
	* Function to Get the current running device information for Valve Default Position run when auto mode is enabled.
	* 
	* @return array with details
	*/
	public function GetValveDefaultPositionModeCurrentDevice($UniqueID,$ID)
	{
		$this->db->select('id,current_on_device,current_on_device_type,current_on_device_number,current_on_device_start,current_on_device_stop,current_sequence,ip_id,unique_id');
		$this->db->where('unique_id',$UniqueID);
		$this->db->where('run_id',$ID);
		$Query = $this->db->get('rlb_valve_default_position_current');
		
		if($Query->num_rows() > 0)
		{
			return $Query->result();	
		}
		
		return '';
	}
	
	/**
	* Function to Stop the Valve default Run Position functionality.
	* @param undefined $ID
	* 
	* @return
	*/
	public function StopValveDefaultPositionRun($ID,$Source)
	{
		//$ArrUpdate = array('IsRunning'=>'0');
		$this->db->where('id',$ID);
		$this->db->update('rlb_valve_default_position_mode_run',array('IsRunning'=>'0','StoppedFrom'=>$Source));
	}
	
	/**
	* Function to Remove the current running Valve default Run Position details.
	* @param undefined $ID
	* 
	* @return
	*/
	public function RemoveCurrentValveDefaultRun($ID)
	{
		$this->db->where('id',$ID);
		$this->db->delete('rlb_valve_default_position_current');
	}
	
	
	
	
}

/* End of file device_model.php */
/* Location: ./application/models/device_model.php */