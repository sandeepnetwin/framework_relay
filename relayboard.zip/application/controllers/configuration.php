<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Configuration extends CI_Controller {

    public function __construct() 
	{
		parent::__construct();
		$this->load->helper('common_functions');
		$this->load->model('configuration_model','Configuration');
		$this->load->model('home_model','HomeModel');
	}
	
	public function index()
	{	
		$this->load->view('Configuration');
    }
	/**
	* Function to save the board configuration first.
	* 
	* @return
	*/
	public function SaveConfiguration()
	{
		$Configuration = $this->input->post('Configuration');
		$Configuration = "DefaultConfiguration";
		$FileName	   = "";
		
		if($Configuration == "PropertyConfiguration")
		{
			$FileName = 'assets/configure/Property.txt';
			#$this->Configuration->SaveLocalIPProperty($this->input->post());
			
		}
		if($Configuration == "DefaultConfiguration")
		{
			$FileName = 'assets/configure/Default.txt';
			
			//Save the Local IP in the database.
			$StrCommandForIP="/sbin/ifconfig eth0 | grep 'inet addr:' | cut -d: -f2 | awk '{ print $1}'";
			exec ($StrCommandForIP,$LocalIP);
			if(empty($LocalIP))
			{
				$LocalIP[] = '192.168.0.50';
			}
			
			echo $LocalIP[0];
			#$this->Configuration->SaveLocalIP($LocalIP[0]);
		}
		##START : Configure the Devices on the Board if not configured.
			
		$aIPDetails = $this->HomeModel->getBoardIP();
		
		foreach($aIPDetails as $IP)
		{
			//Get saved IP and PORT 
			list($sIP,$sPort,$extra) = $this->home_model->getSettings();
			
			$shhPort	=	'';
			if(IS_LOCAL == '1')
			{
				//Get SSH port of the RLB board using IP.
				$shhPort = $this->home_model->getSSHPortFromID($sIpID);
			}
			
			for($i = 1; $i <= 2; $i++)
			{
				if($i == 1)
				{
					//Get position values from POST
            		$Relay1 = 0;
            		$Relay2 = 1;
				}
				else
				{
					$Relay1 = 2;
            		$Relay2 = 3;
				}
				
				$positionRelay1	= 'Position1';
				$positionRelay2	= 'Position2';
				
				$this->Configuration->SaveRelayForValve($i,$Relay1,$Relay2,$IP->id);
				$this->HomeModel->savePositionName($sDeviceID,$sDevice,$positionRelay1,$positionRelay2,$sIpID);
			}
			
			$arrValves	=	$this->HomeModel->getAllValvesHavingRelays($IP->id);
			$strValves	=	'00000000';
			if(!empty($arrValves))
			{
				foreach($arrValves as $aValve)
				{
					$device_number = $aValve->device_number;
					$strValves[$device_number] = '1';
				}
			}
			$hexNumber 	= dechex(bindec(strrev($strValves)));
			$response	=	assignValvesToRelay($hexNumber,$IP->ip,$sPort,$shhPort)	;
			
			$totalValveCnt	=	count($arrValves);
			$this->HomeModel->updateValveCnt($totalValveCnt,$sIpID);	
		}
		
		/*foreach($aIPDetails as $IP)
		{
			//Get saved IP and PORT 
			list($sIP,$sPort,$extra) = $this->home_model->getSettings();
			
			$shhPort	=	'';
			if(IS_LOCAL == '1')
			{
				//Get SSH port of the RLB board using IP.
				$shhPort = $this->home_model->getSSHPortFromID($sIpID);
			}
			
			//START : Valve Configuration.
			$arrValves	=	$this->home_model->getAllValvesHavingRelays($IP->id);
				
			$strValves	=	'00000000';
			if(!empty($arrValves))
			{
				foreach($arrValves as $aValve)
				{
					$device_number = $aValve->device_number;
					$strValves[$device_number] = '1';
				}
			}
			$strValves;
			$hexNumber = dechex(bindec(strrev($strValves)));
			
			$response	=	assignValvesToRelay($hexNumber,$IP->ip,$sPort,$shhPort)	;
			
			$totalValveCnt	=	count($arrValves);
			$this->home_model->updateValveCnt($totalValveCnt,$IP->id);
			//END : Valve Configuration.
			
			//Get all Pump and Temperature sensor Devices.
			$PumpAndTempeDevices = $this->Configuration->AllDevicesForConfiguration($IP->id);
			
			//START : Get the Temeprature sensor Bus.
			$arrBusDetails = array();
			$sResponse = getTempratureBus($IP->ip,$sPort,$shhPort);
			if(!empty($sResponse))
			{
				$arrResponse	=	explode(",",$sResponse);
				if(count($arrResponse) > 3)
				{
					foreach($arrResponse as $strRes)
					{
						if(preg_match('/TS28/',$strRes))
						{
							$arrBusDetails[] = $strRes;
						}
					}
				}
			}
			//START : Get the Temeprature sensor Bus.
			
			foreach($PumpAndTempeDevices as $Device)
			{
				//START : Temperature Configuration
					if($Device->device_type == "T")
					{
						if(!empty($arrBusDetails))
						{
							configureTempratureBus('ts'.$Device->device_number,$arrBusDetails[$Device->device_number],$IP->ip,$sPort,$shhPort);
						}
					}
				//END : Temperature Configuration
				
				$i = 0;
				//START : PUPM Configuration
				//if($Device->device_type == "PS")
				//{
				//	$Address = array(60,61,62);
				//	$sAddress = $Address[$i];
				//	assignAddressToPump($Device->device_number,$sAddress,$IP->ip,$sPort,$shhPort);
				//	$i++;
				//}
				//END : PUPM Configuration
			}
			
		}	
			
		##END : Configure the Devices on the Board if not configured.
		echo json_encode(array("response"=>"Configuration of devices are done Successfully!"));
		exit;*/
	}

	public function SaveDetailsInDB($FileName)
	{
		$Queries = '';
		$templine = '';
		$lines = file($FileName);
		$arrDetails = array();
		$i =0;
		foreach ($lines as $key => $line)
		{
			if (substr($line, 0, 2) == '--' || $line == '')
			{
				continue;
			}
			$templine .= $line;

			
			if (substr(trim($line), -1, 1) == ';')
			{
				$arrDetails[] = $templine;
				if(!preg_match("/\b(delete|alter)\b/i", $templine))
				{
					$this->Configuration->RunQuery($templine);
				}
				$templine = '';
			}
		}
	}


}

/* End of file configuration.php */
/* Location: ./application/controllers/configuration.php */