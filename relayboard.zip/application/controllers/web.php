<?php
    /**
    * @Programmer: Dhiraj S.
    * @Created: 21 July 2015
    * @Modified: 
    * @Description: Webservice to on/off Devices and Get status of Devices.
    **/
    
    if (!defined('BASEPATH'))
        exit('No direct script access allowed');
    
    class Web extends CI_Controller
    {
        protected $isHTTPSRequired          = FALSE; // Define whether an HTTPS connection is required
        protected $isAuthenticationRequired = FALSE; // Define whether user authentication is required
        
        // Define API response codes and their related HTTP response
        public $aApiResponseCode = array(
                                            0 => array('HTTP Response' => 400, 'Message' => 'Unknown Error'),
                                            1 => array('HTTP Response' => 200, 'Message' => 'Success'),
                                            2 => array('HTTP Response' => 403, 'Message' => 'HTTPS Required'),
                                            3 => array('HTTP Response' => 401, 'Message' => 'Authentication Required'),
                                            4 => array('HTTP Response' => 401, 'Message' => 'Authentication Failed'),
                                            5 => array('HTTP Response' => 404, 'Message' => 'Invalid Request'),
                                            6 => array('HTTP Response' => 400, 'Message' => 'Invalid Response Format')
                                        );
        
        public function __construct() 
        {
            parent::__construct(); // Parent Contructor Call
            $this->load->helper('common_functions'); // Loaded helper : To get all functions accessible from common_functions file.
            
        } // END : function __construct()
        
		public function webResponse($sformat, $aApiResponse)
        {
           // Define HTTP responses
            $http_response_code = array(
                                        200 => 'OK',
                                        400 => 'Bad Request',
                                        401 => 'Unauthorized',
                                        403 => 'Forbidden',
                                        404 => 'Not Found'
                                       );

            // Set HTTP Response
            //header('HTTP/1.1 '.$aApiResponse['status'].' '.$http_response_code[ $aApiResponse['status'] ]);

            // Process different content types
            if( strcasecmp($sformat,'json') == 0 )
            {
                // Set HTTP Response Content Type
                header('Content-Type: application/json; charset=utf-8');

                // Format data into a JSON response
                $json_response = json_encode($aApiResponse);

                // Deliver formatted data
                echo $json_response;

            }
            elseif( strcasecmp($sformat,'xml') == 0 )
            {
                // Set HTTP Response Content Type
                header('Content-Type: application/xml; charset=utf-8');

                // Format data into an XML response (This is only good at handling string data, not arrays)
                $xml_response = '<?xml version="1.0" encoding="UTF-8"?>'."\n".
                    '<response>'."\n".
                    "\t".'<code>'.$aApiResponse['code'].'</code>'."\n".
                    "\t".'<data>'.$aApiResponse['data'].'</data>'."\n".
                    '</response>';

                // Deliver formatted data
                echo $xml_response;
            }
            else
            {
                // Set HTTP Response Content Type (This is only good at handling string data, not arrays)
                header('Content-Type: text/html; charset=utf-8');

                // Deliver formatted data
                echo $aApiResponse['data'];
            }

            // End script process
            exit;
        }
		
		public function webAuthorisation($sUsername,$sPassword,$sFormat)
        {
			$aResponse             =   array();

			if( $sPassword == '' )
			{
				$aResponse['code'] = 3;
				$aResponse['status'] = $this->aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
				$aResponse['data'] = $this->aApiResponseCode[ $aResponse['code'] ]['Message'];

				// Return Response to browser
				$this->webResponse($sFormat, $aResponse);
			}
			if( $sPassword != 'bar' )
			{
				$aResponse['code'] = 4;
				$aResponse['status'] = $this->aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
				$aResponse['data'] = $this->aApiResponseCode[ $aResponse['code'] ]['Message'];

				// Return Response to browser
				$this->webResponse($sFormat, $aResponse);
			}
             
        }
		
		/**
		* Function to Change the Device Status.
		* @param 
		* @return : Validation message or Success Message.
		**/
        public function changeDeviceStatus()
        {
            // Set default HTTP response of 'ok'
            $aResponse              =   array();
            $aResponse['code']      =   0;
            $aResponse['status']    =   404;
            $aResponse['data']      =   NULL;
            $sformat                =   isset($_GET['format']) ? $_GET['format'] : '' ; // Get response Format (json,xml,html etc.)
            $sAuth                  =   isset($_GET['auth']) ? $_GET['auth'] : '' ;// Check if Authentication is required.
            $this->isAuthenticationRequired =   $sAuth;
                
            // Optionally require connections to be made via HTTPS
            if( $this->isHTTPSRequired && $_SERVER['HTTPS'] != 'on' )
            {
                $aResponse['code']      = 2;
                $aResponse['status']    = $aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
                $aResponse['data']      = $aApiResponseCode[ $aResponse['code'] ]['Message'];

                // Return Response to browser. This will exit the script.
                $this->webResponse($sformat, $aResponse);
            }
            
            if($this->isAuthenticationRequired)
            {
                //START : Authorisation
                $sUsername       = isset($_GET['username']) ? $_GET['username'] : '' ;   // Get the username of webservice 
                $sPassword       = isset($_GET['password']) ? $_GET['password'] : '' ;   // Get the password of webservice 
                $this->webAuthorisation($sUsername, $sPassword,$sformat); // Check if username and password is valid.
                // END : Authorisation
            }
            
            #INPUTS
			$ipID			 = isset($_GET['ip']) ? $_GET['ip'] : '' ; // IP ID
            $sDevice         = isset($_GET['dvc']) ? $_GET['dvc'] : '' ; // Get the Device(ie. R=Relay,V=Valve,PC=Power Center)
            $sDeviceNo       = isset($_GET['dn'])  ? $_GET['dn'] : '' ;  // Get the Device No.
            $iDeviceStatus   = isset($_GET['ds']) ? $_GET['ds'] : '' ;   // Get the status to which Device will be changed         
            
			if($ipID == '')
			{
				$aResponse['code']      = 5;
                $aResponse['status']    = $this->aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
                $aResponse['data']      = 'Please Enter Valid IP.';

                // Return Response to browser. This will exit the script.
                $this->webResponse($sformat, $aResponse);
            }
			
            $aResult            = array();
            $aResult['msg']     = "";
            $aResult['response']  = 0;
            $aDeviceStatus      = array('0', '1', '2'); //respective values of status.
                     
            $this->load->model('home_model');
            $iActiveMode =  $this->home_model->getActiveMode();
			
			//GET IP of Device
			$sDeviceIP		= 	$this->home_model->getBoardIPFromID($ipID);
			
			//Get SSH port when working on LOCAL.
			$shhPort	=	'';
			if(IS_LOCAL == '1')
			{
				//Get SSH port of the RLB board using IP.
				$shhPort = $this->home_model->getSSHPortFromID($ipID);
			}
			
			//Get the number of Devices(Blower,Light and Heater) from the settings.
			list($sIP,$sPort,$sExtra) = $this->home_model->getSettings();
                        
            //if($iActiveMode == 2) // START : If Mode is Manual.
            {
                if($sDeviceNo != '' && in_array($iDeviceStatus, $aDeviceStatus) && $sDevice != '') 
                {
                    $sResponse      =   get_rlb_status($sDeviceIP,$sPort,$shhPort); // Get the relay borad response from server.
                    $sValves        =   $sResponse['valves']; // Valve Devices.
                    $sRelays        =   $sResponse['relay'];  // Relay Devices.
                    $sPowercenter   =   $sResponse['powercenter']; // Power Center Devices.
                    $sRelayNewResp  =   '';
                    
                    if($sDevice == 'R') // START : If Device is Relay.
                    {
                        if($sRelays != '') // START : Check if Relay devices are available.
                        {
                            $iRelayCount    = strlen($sRelays); // Count of Relay Devices.
                            if( $sDeviceNo > ($iRelayCount-1) || $sDeviceNo < 0)
                            {
                                $aResponse['code']      = 5;
                                $aResponse['status']    = $this->aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
                                $aResponse['data']      = 'Invalid relay number.';

                                // Return Response to browser. This will exit the script.
                                $this->webResponse($sformat, $aResponse);
                            } // END : if( $sDeviceNo > ($iRelayCount-1) || $sDeviceNo < 0)
                            else
                            {
                                $sRelayNewResp = replace_return($sRelays, $iDeviceStatus, $sDeviceNo ); // Change the status with the sent status for the device no.
                                onoff_rlb_relay($sRelayNewResp,$sDeviceIP,$sPort,$shhPort); // Send the request to change the status on server.		
                                
                                $aResponse['code']      = 1;
                                $aResponse['status']    = $this->aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
                                $aResponse['data']      = 'Relay status changed successfully.';

                                // Return Response to browser. This will exit the script.
                                $this->webResponse($sformat, $aResponse);
                            } // END : else of if( $sDeviceNo > ($iRelayCount-1) || $sDeviceNo < 0)
                        }
                        else
                        {
                            $aResponse['code']      = 5;
                            $aResponse['status']    = $this->aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
                            $aResponse['data']      = 'Relay devices not available.';

                            // Return Response to browser. This will exit the script.
                            $this->webResponse($sformat, $aResponse);
                        }
                    } // END : if($sDevice == 'R')
                                        
                    if($sDevice == 'PC') // START : If Device is Power Center.
                    {
                        if($sPowercenter != '') // START : Check if Power Center devices are available.
                        {
                            $iPowerCenterCount    = strlen($sPowercenter); // Count of Power Center Devices.
                            if( $sDeviceNo > ($iPowerCenterCount-1) || $sDeviceNo < 0)
                            {
                                $aResponse['code']      = 5;
                                $aResponse['status']    = $this->aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
                                $aResponse['data']      = 'Invalid Power Center number.';

                                // Return Response to browser. This will exit the script.
                                $this->webResponse($sformat, $aResponse);
                            } // END : if( $sDeviceNo > ($iPowerCenterCount-1) || $sDeviceNo < 0)
                            else
                            {
                                $sRelayNewResp = replace_return($sPowercenter, $iDeviceStatus, $sDeviceNo ); // Change the status with the sent status for the device no.
                                onoff_rlb_powercenter($sRelayNewResp,$sDeviceIP,$sPort,$shhPort); // Send the request to change the status on server.		
                                
                                $aResponse['code']      = 1;
                                $aResponse['status']    = $this->aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
                                $aResponse['data']      = 'Power Center status changed successfully.';

                                // Return Response to browser. This will exit the script.
                                $this->webResponse($sformat, $aResponse);
                            } // END : else of if( $sDeviceNo > ($iPowerCenterCount-1) || $sDeviceNo < 0)
                        }
                        else
                        {
                            $aResponse['code']      = 5;
                            $aResponse['status']    = $this->aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
                            $aResponse['data']      = 'Power Center devices not available.';

                            // Return Response to browser. This will exit the script.
                            $this->webResponse($sformat, $aResponse);
                        }
                    } // END : if($sDevice == 'PC')
                                        
                    if($sDevice == 'V') // START : If Device is Power Center.
                    {
						if($sValves != '') // START : Check if Valve devices are available.
                        {
                            $iValveCount    = strlen($sValves); // Count of Power Center Devices.
                            if( $sDeviceNo > ($iValveCount-1) || $sDeviceNo < 0)
                            {
                                $aResponse['code']      = 5;
                                $aResponse['status']    = $this->aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
                                $aResponse['data']      = 'Invalid Valve number.';

                                // Return Response to browser. This will exit the script.
                                $this->webResponse($sformat, $aResponse);
                            } // END : if( $sDeviceNo > ($iValveCount-1) || $sDeviceNo < 0)
                            else
                            {
								//First Get the Current Status.
								$currentOnPosition = $sValves[$sDeviceNo];
								
								if($currentOnPosition  != 0)
								{
									$this->home_model->saveLastRun($sDeviceNo,'V',$currentOnPosition,$sIdIP);
								}
			
                                $sRelayNewResp = replace_return($sValves, $iDeviceStatus, $sDeviceNo ); // Change the status with the sent status for the device no.
                                onoff_rlb_valve($sRelayNewResp,$sDeviceIP,$sPort,$shhPort); // Send the request to change the status on server.		
                                
								$aResponse['code']      = 1;
                                $aResponse['status']    = $this->aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
                                $aResponse['data']      = 'Valve status changed successfully.';

                                // Return Response to browser. This will exit the script.
                                $this->webResponse($sformat, $aResponse);
                            } // END : else of if( $sDeviceNo > ($iValveCount-1) || $sDeviceNo < 0)
                        }
                        else
                        {
                            //$aResult['msg'] = "Valve devices not available."; 
                            $aResponse['code']      = 5;
                            $aResponse['status']    = $this->aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
                            $aResponse['data']      = 'Valve devices not available.';

                            // Return Response to browser. This will exit the script.
                            $this->webResponse($sformat, $aResponse);
                        }
                    } // END : if($sDevice == 'V')
					
					if($sDevice == 'PS')
					{
						$sPump	=	'';
						if(isset($sResponse['pump_seq_'.$sDeviceNo.'_st']))
							$sPump = $sResponse['pump_seq_'.$sDeviceNo.'_st'];
						
						if($sPump != '')
						{		
							$aPumpDetails = $this->home_model->getPumpDetails($sDeviceNo,$ipID);
							//Variable Initialization to blank.
							$sPumpNumber  	= '';
							$sPumpType  	= '';
							$sPumpSubType  	= '';
							$sPumpSpeed  	= '';
							$sPumpFlow 		= '';
							$sPumpClosure   = '';
							$sRelayNumber  	= '';

							if(is_array($aPumpDetails) && !empty($aPumpDetails))
							{
							  foreach($aPumpDetails as $aResultEdit)
							  { 
								$sPumpNumber  = $aResultEdit->pump_number;
								$sPumpType    = $aResultEdit->pump_type;
								$sPumpSubType = $aResultEdit->pump_sub_type;
								$sPumpSpeed   = $aResultEdit->pump_speed;
								$sPumpFlow    = $aResultEdit->pump_flow;
								$sPumpClosure = $aResultEdit->pump_closure;
								$sRelayNumber = $aResultEdit->relay_number;
							  }
							}
							else
							{
								$aResponse['code']      = 5;
								$aResponse['status']    = $this->aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
								$aResponse['data']      = 'Pump devices not configured properly.';

								// Return Response to browser. This will exit the script.
								$this->webResponse($sformat, $aResponse);
							}
							
							if($sPumpType != '')
							{
								if($sPumpType == '12' || $sPumpType == '24')
								{
									if($sPumpType == '24')
									{
										$sNewResp = replace_return($sRelays, $iDeviceStatus, $sRelayNumber );
										onoff_rlb_relay($sNewResp,$sDeviceIP,$sPort,$shhPort);
										$this->home_model->updateDeviceRunTime($sDeviceNo,$sDevice,$iDeviceStatus,$ipID);
									}
									else if($sPumpType == '12')
									{
										$sNewResp = replace_return($sPowercenter, $iDeviceStatus, $sRelayNumber );
										onoff_rlb_powercenter($sNewResp,$sDeviceIP,$sPort,$shhPort);
									}
									
									$aResponse['code']      = 1;
									$aResponse['status']    = $this->aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
									$aResponse['data']      = 'Pump status changed successfully.';
								}
								else
								{
									if(preg_match('/Emulator/',$sPumpType))
									{
										$sNewResp = '';

										if($iDeviceStatus == '0')
											$sNewResp =  $sDeviceNo.' '.$iDeviceStatus;
										else if($iDeviceStatus == '1')
										{
											$sType          =   '';
											if($sPumpSubType == 'VS')
												$sType  =   '2'.' '.$sPumpSpeed;
											elseif ($sPumpSubType == 'VF')
												$sType  =   '3'.' '.$sPumpFlow;

											$sNewResp =  $sDeviceNo.' '.$sType;    
										}
										
										onoff_rlb_pump($sNewResp,$sDeviceIP,$sPort,$shhPort);
										
										if($sPumpType == 'Emulator12')
										{
											$sNewResp12 = replace_return($sPowercenter, $iDeviceStatus, $sRelayNumber );
											onoff_rlb_powercenter($sNewResp12,$sDeviceIP,$sPort,$shhPort);
										}
										if($sPumpType == 'Emulator24')
										{
											$sNewResp24 = replace_return($sRelays, $iDeviceStatus, $sRelayNumber );
											onoff_rlb_relay($sNewResp24,$sDeviceIP,$sPort,$shhPort);
											$this->home_model->updateDeviceRunTime($sRelayNumber,'R',$iDeviceStatus,$ipID);
										}
										$aResponse['code']      = 1;
										$aResponse['status']    = $this->aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
										$aResponse['data']      = 'Pump status changed successfully.';
									}
									else if(preg_match('/Intellicom/',$sPumpType))
									{
										$sNewResp = '';

										if($iDeviceStatus == '0')
											$sNewResp =  $sDeviceNo.' '.$iDeviceStatus;
										else if($iDeviceStatus == '1')
										{
											$sType  =   '2'.' '.$sPumpSpeed;
											$sNewResp =  $sDeviceNo.' '.$sType;    
										}
										
										onoff_rlb_pump($sNewResp,$sDeviceIP,$sPort,$shhPort);
										
										if($sPumpType == 'Intellicom12')
										{
											$sNewResp12 = replace_return($sPowercenter, $iDeviceStatus, $sRelayNumber );
											onoff_rlb_powercenter($sNewResp12,$sDeviceIP,$sPort,$shhPort);
										}
										if($sPumpType == 'Intellicom24')
										{
											$sNewResp24 = replace_return($sRelays, $iDeviceStatus, $sRelayNumber );
											onoff_rlb_relay($sNewResp24,$sDeviceIP,$sPort,$shhPort);
											$this->home_model->updateDeviceRunTime($sRelayNumber,'R',$iDeviceStatus,$ipID);
										}
										$aResponse['code']      = 1;
										$aResponse['status']    = $this->aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
										$aResponse['data']      = 'Pump status changed successfully.';
									}
								}
							}
							else
							{
								$aResponse['code']      = 5;
								$aResponse['status']    = $this->aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
								$aResponse['data']      = 'Pump devices not configured properly or Closure is set to 0.';

								// Return Response to browser. This will exit the script.
								$this->webResponse($sformat, $aResponse);
							}
							
						}
						else
                        {
                            $aResponse['code']      = 5;
                            $aResponse['status']    = $this->aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
                            $aResponse['data']      = 'Pump devices not available.';

                            // Return Response to browser. This will exit the script.
                            $this->webResponse($sformat, $aResponse);
                        }
					}
					else if($sDevice == 'B') // START : If Device is Blower.
					{
						//Number of blower set on the setting Page.
						if($ipID == 1)
							$iNumBlower	=	$sExtra['BlowerNumber'];
						else
							$iNumBlower	=	$sExtra['BlowerNumber2'];
						
						//If Blower is not set or count is 0.
						if($iNumBlower == 0 || $iNumBlower == '')
						{
							$aResponse['code']      = 5;
							$aResponse['status']    = $this->aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
							$aResponse['data']      = 'Blower Devices are not available!';
							
							$this->webResponse($sformat, $aResponse);
							exit;
						}//If Blower is not set or count is 0.
						
						$aBlowerDetails  =   $this->home_model->getBlowerDeviceDetails($sDeviceNo,$ipID);
						if(!empty($aBlowerDetails))
						{
							foreach($aBlowerDetails as $aBlower)
							{
								$sBlowerStatus	=	'';
								$sRelayDetails  =   unserialize($aBlower->light_relay_number);
								
								//Blower Operated Type and Relay
								$sRelayType     =   $sRelayDetails['sRelayType'];
								$sRelayNumber   =   $sRelayDetails['sRelayNumber'];
								
								if($sRelayType == '24')
								{
									$sNewResp = replace_return($sRelays, $iDeviceStatus, $sRelayNumber );
									onoff_rlb_relay($sNewResp,$sDeviceIP,$sPort,$shhPort);
									$this->home_model->updateDeviceRunTime($sRelayNumber,$sDevice,$iDeviceStatus,$ipID);
								}
								if($sRelayType == '12')
								{
									$sNewResp = replace_return($sPowercenter, $iDeviceStatus, $sRelayNumber );
									onoff_rlb_powercenter($sNewResp,$sDeviceIP,$sPort,$shhPort);
								}
								
								$aResponse['code']      = 1;
								$aResponse['status']    = $this->aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
								$aResponse['data']      = 'Blower status changed successfully.';
								
								$this->webResponse($sformat, $aResponse);
							}
						}
						else
						{
							$aResponse['code']      = 5;
                            $aResponse['status']    = $this->aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
                            $aResponse['data']      = 'Blower devices not available.';

                            $this->webResponse($sformat, $aResponse);
						}
					}// END : If Device is Blower.
					else if($sDevice == 'L') // START : If Device is Light.
					{
						//Number of blower set on the setting Page.
						if($ipID == 1)
						$iNumLight	=	$sExtra['LightNumber'];
						else
						$iNumLight	=	$sExtra['LightNumber2'];
						
						//If Light is not set or count is 0.
						if($iNumLight == 0 || $iNumLight == '')
						{
							$aResponse['code']      = 5;
							$aResponse['status']    = $this->aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
							$aResponse['data']      = 'Light Devices are not available!';
							
							$this->webResponse($sformat, $aResponse);
							exit;
						}//If Light is not set or count is 0.
						
						$aLightDetails  =   $this->home_model->getLightDeviceDetails($sDeviceNo,$ipID);
						
						if(!empty($aLightDetails))
						{
							foreach($aLightDetails as $aLight)
							{
								$sLightStatus	=	'';
								$sRelayDetails  =   unserialize($aLight->light_relay_number);
								
								//Light Operated Type and Relay
								$sRelayType     =   $sRelayDetails['sRelayType'];
								$sRelayNumber   =   $sRelayDetails['sRelayNumber'];
								
								if($sRelayType == '24')
								{
									$sNewResp = replace_return($sRelays, $iDeviceStatus, $sRelayNumber );
									onoff_rlb_relay($sNewResp,$sDeviceIP,$sPort,$shhPort);
									$this->home_model->updateDeviceRunTime($sRelayNumber,$sDevice,$iDeviceStatus,$ipID);
								}
								if($sRelayType == '12')
								{
									$sNewResp = replace_return($sPowercenter, $iDeviceStatus, $sRelayNumber );
									onoff_rlb_powercenter($sNewResp,$sDeviceIP,$sPort,$shhPort);
								}
								
								$aResponse['code']      = 1;
								$aResponse['status']    = $this->aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
								$aResponse['data']      = 'Light status changed successfully.';
								
								$this->webResponse($sformat, $aResponse);
								
							}
						}
						else
						{
							$aResponse['code']      = 5;
                            $aResponse['status']    = $this->aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
                            $aResponse['data']      = 'Light devices not available.';

                            $this->webResponse($sformat, $aResponse);
						}
					}// END : If Device is Light.
					else if($sDevice == 'H') // START : If Device is Heater.
					{
						//Number of Heater set on the setting Page.
						if($ipID == 1)
						$iNumHeater	=	$sExtra['HeaterNumber'];
						else
						$iNumHeater	=	$sExtra['HeaterNumber2'];
						
						//If Heater is not set or count is 0.
						if($iNumHeater == 0 || $iNumHeater == '')
						{
							$aResponse['code']      = 5;
							$aResponse['status']    = $this->aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
							$aResponse['data']      = 'Heater Devices are not available!';
							
							$this->webResponse($sformat, $aResponse);
							exit;
						}//If Heater is not set or count is 0.
						
						//Heater Details
						$aHeaterDetails  =   $this->home_model->getHeaterDeviceDetails($sDeviceNo,$ipID);
						if(!empty($aHeaterDetails))
						{
							foreach($aHeaterDetails as $aHeater)
							{
								$sHeaterStatus	=	'';
								$sRelayDetails  =   unserialize($aHeater->light_relay_number);
								
								//Heater Operated Type and Relay
								$sRelayType     =   $sRelayDetails['sRelayType'];
								$sRelayNumber   =   $sRelayDetails['sRelayNumber'];
								
								if($sRelayType == '24')
								{
									$sNewResp = replace_return($sRelays, $iDeviceStatus, $sRelayNumber );
									onoff_rlb_relay($sNewResp,$sDeviceIP,$sPort,$shhPort);
									$this->home_model->updateDeviceRunTime($sRelayNumber,$sDevice,$iDeviceStatus,$ipID);
								}
								if($sRelayType == '12')
								{
									$sNewResp = replace_return($sPowercenter, $iDeviceStatus, $sRelayNumber );
									onoff_rlb_powercenter($sNewResp,$sDeviceIP,$sPort,$shhPort);
								}
								$aResponse['code']      = 1;
								$aResponse['status']    = $this->aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
								$aResponse['data']      = 'Heater status changed successfully.';
								
								$this->webResponse($sformat, $aResponse);
							}
						}
						
					}// END : If Device is Heater.
					else if($sDevice == 'M') // START : If Device is Misc Devices.
					{
						//Number of Heater set on the setting Page.
						if($ipID == 1)
							$iNumMisc	=	$sExtra['MiscNumber'];
						else 
							$iNumMisc	=	$sExtra['MiscNumber2'];
						
						//If Misc is not set or count is 0.
						if($iNumMisc == 0 || $iNumMisc == '')
						{
							$aResponse['code']      = 5;
							$aResponse['status']    = $this->aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
							$aResponse['data']      = 'Misc Devices are not available!';
							
							$this->webResponse($sformat, $aResponse);
							exit;
						}//If Misc is not set or count is 0.
						
						//Misc Details
						$aMiscDetails  =   $this->home_model->getMiscDeviceDetails($sDeviceNo,$ipID);
						if(!empty($aMiscDetails))
						{
							foreach($aMiscDetails as $aMisc)
							{
								$sHeaterStatus	=	'';
								$sRelayDetails  =   unserialize($aMisc->light_relay_number);
								
								//Heater Operated Type and Relay
								$sRelayType     =   $sRelayDetails['sRelayType'];
								$sRelayNumber   =   $sRelayDetails['sRelayNumber'];
								
								if($sRelayType == '24')
								{
									$sNewResp = replace_return($sRelays, $iDeviceStatus, $sRelayNumber );
									onoff_rlb_relay($sNewResp,$sDeviceIP,$sPort,$shhPort);
									$this->home_model->updateDeviceRunTime($sRelayNumber,$sDevice,$iDeviceStatus,$ipID);
								}
								if($sRelayType == '12')
								{
									$sNewResp = replace_return($sPowercenter, $iDeviceStatus, $sRelayNumber );
									onoff_rlb_powercenter($sNewResp,$sDeviceIP,$sPort,$shhPort);
								}
								$aResponse['code']      = 1;
								$aResponse['status']    = $this->aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
								$aResponse['data']      = 'Misc Device status changed successfully.';
								
								$this->webResponse($sformat, $aResponse);
							}
						}
						
					}// END : If Device is Misc Device.
					
                } // END : if($sDeviceNo != '' && in_array($iDeviceStatus, $aDeviceStatus) && $sDevice != '')
                else
                {
                    $aResponse['code']      = 5;
                    $aResponse['status']    = $this->aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
                    $aResponse['data']      = 'Invalid Device number Or Device status OR Device Type.';

                    // Return Response to browser. This will exit the script.
                    $this->webResponse($sformat, $aResponse);
                }
            } // END : if($iActiveMode == 2)
        } //END : function changeDeviceStatus()
        
		/**
		* Function to Get the Status of Particular Device Type.
		* @param 
		* @return : Validation message or Status of All Devices of the given type.
		**/
        public function getDeviceStatus()
        {
            // Set default HTTP response of 'ok'
            $aResponse              =   array();
            $aResponse['code']      =   0;
            $aResponse['status']    =   404;
            $aResponse['data']      =   NULL;
            $sformat                =   isset($_GET['format']) ? $_GET['format'] : '' ; // Get response Format (json,xml,html etc.)
            $sAuth                  =   isset($_GET['auth']) ? $_GET['auth'] : '' ;// Check if Authentication is required.
            $this->isAuthenticationRequired =   $sAuth;
            
            // Optionally require connections to be made via HTTPS
            if( $this->isHTTPSRequired && $_SERVER['HTTPS'] != 'on' )
            {
                $aResponse['code']      = 2;
                $aResponse['status']    = $aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
                $aResponse['data']      = $aApiResponseCode[ $aResponse['code'] ]['Message'];

                // Return Response to browser. This will exit the script.
                $this->webResponse($sformat, $aResponse);
            }
            
            if($this->isAuthenticationRequired)
            {
                //START : Authorisation
                $sUsername       = isset($_GET['username']) ? $_GET['username'] : '' ;   // Get the username of webservice 
                $sPassword       = isset($_GET['password']) ? $_GET['password'] : '' ;   // Get the password of webservice 
                $this->webAuthorisation($sUsername, $sPassword,$sformat); // Check if username and password is valid.
                // END : Authorisation
            }
             
            #INPUTS
            $sDevice         = isset($_GET['dvc']) ? $_GET['dvc'] : '' ;
            
            $aResult            = array();
            $aResult['msg']     = "";
            $aResult['response']= 0;
            $aResult['status']  = 0;
            
            $sValves            = ""; // Valve Devices Initialization.
            $sRelays            = "";  // Relay Devices Initialization.
            $sPowercenter       = ""; // Power Center Devices Initialization.
            $iCntValves         = "0"; // Valve Devices Count Initialization.
            $iCntRelays         = "0";  // Relay Devices Count Initialization.
            $iCntPowercenter    = "0"; // Power Center Devices Initialization.
            
            $this->load->model('home_model');
			
			$ipID			 = isset($_GET['ip']) ? $_GET['ip'] : '' ; // IP ID
			if($ipID == '')
			{
				$aResponse['code']      = 5;
                $aResponse['status']    = $this->aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
                $aResponse['data']      = 'Please Enter Valid IP.';

                // Return Response to browser. This will exit the script.
                $this->webResponse($sformat, $aResponse);
            }
			//GET IP of Device
			$sDeviceIP		= 	$this->home_model->getBoardIPFromID($ipID);
			
			//Get SSH port when working on LOCAL.
			$shhPort	=	'';
			if(IS_LOCAL == '1')
			{
				//Get SSH port of the RLB board using IP.
				$shhPort = $this->home_model->getSSHPortFromID($ipID);
			}
			
            $iActiveMode =  $this->home_model->getActiveMode();
			
			//Get the number of Devices(Blower,Light and Heater) from the settings.
			list($sIP,$sPort,$sExtra) = $this->home_model->getSettings();
            
            //if($iActiveMode == 2) // START : If Mode is Manual.
            {
                if($sDevice != '') // START : If device type is not empty
                {
                    $sResponse      =   get_rlb_status($sDeviceIP,$sPort,$shhPort); // Get the relay borad response from server.
                    if($sDevice == "V") // START : If Device is Valve
                    {
                        if($sResponse['valves'] != '') // START : Checked if Valve Devices are available
                        {
                            $sValves        =   $sResponse['valves']; // Valve Devices.
                            $iCntValves     =   strlen($sValves); // Count of Valve Devices.
                            
                            $aResponse['code']      = 1;
                            $aResponse['status']    = $this->aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
                            $aResponse['data']      = $sValves;

                            // Return Response to browser. This will exit the script.
                            $this->webResponse($sformat, $aResponse);
                        } // END : Checked if Valve Devices are available
                        else
                        {
                            $aResponse['code']      = 5;
                            $aResponse['status']    = $this->aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
                            $aResponse['data']      = 'Valve devices not available.';

                            // Return Response to browser. This will exit the script.
                            $this->webResponse($sformat, $aResponse);
                        }
                    } // if($sDevice == "V") END : If Device is Valve
                    else if($sDevice == "R") // START : If Device is Relay.
                    {
                        if($sResponse['relay'] != '')
                        {
                            $sRelays        =   $sResponse['relay'];  // Relay Devices.
                            $iCntRelays     =   strlen($sRelays); // Count of Relay Devices.
                            
                            $aResponse['code']      = 1;
                            $aResponse['status']    = $this->aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
                            $aResponse['data']      = $sRelays;
                            
                            $this->webResponse($sformat, $aResponse);
                        }
                        else
                        {
                            $aResponse['code']      = 5;
                            $aResponse['status']    = $this->aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
                            $aResponse['data']      = 'Relay devices not available.';

                            // Return Response to browser. This will exit the script.
                            $this->webResponse($sformat, $aResponse);
                        }
                    } // END : If Device is Relay.
                    else if($sDevice == "PC") // START : If Device is Power Center.
                    {
                        if($sResponse['powercenter'] != '')
                        {
                            $sPowercenter   =   $sResponse['powercenter']; // Power Center Devices.
                            $iCntPowercenter=   strlen($sPowercenter); // Count of Power Center Devices.
                            
                            $aResponse['code']      = 1;
                            $aResponse['status']    = $this->aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
                            $aResponse['data']      = $sPowercenter;
                            
                            $this->webResponse($sformat, $aResponse);
                        }
                        else
                        {    
                            $aResponse['code']      = 5;
                            $aResponse['status']    = $this->aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
                            $aResponse['data']      = 'Power Center devices not available.';

                            // Return Response to browser. This will exit the script.
                            $this->webResponse($sformat, $aResponse);
                        }
                    } // END : If Device is Power Center.
					else if($sDevice == "PS")// START : If Device is PUMPS.
					{
						$sPumps 		= '';
						for($i=0;$i<3;$i++)
						{
							$aPumpDetails = $this->home_model->getPumpDetails($i,$ipID);
							//Variable Initialization to blank.
							$sPumpNumber  	= '';
							$sPumpType  	= '';
							$relay_number   = '';
							
							if(is_array($aPumpDetails) && !empty($aPumpDetails))
							{
							  foreach($aPumpDetails as $aResultEdit)
							  { 
								$sPumpNumber  = $aResultEdit->pump_number;
								$sPumpType    = $aResultEdit->pump_type;
								$relay_number = $aResultEdit->relay_number;
								$sPumpClosure = $aResultEdit->pump_closure;
								
								if($sPumpType != '')
								{
									if($sPumpType == '12' || $sPumpType == '24')
									{
										if($sPumpType == '24')
										{
											if($sResponse['relay'] != '')
											{
												$sRelays        =   $sResponse['relay'];  // Relay Devices.
												if(isset($sRelays[$relay_number]) && $sRelays[$relay_number] != '')
												{    
													$sPumps      .= $sRelays[$relay_number];
												}
												else
												{
													$aResponse['code']      = 5;
													$aResponse['status']    = $this->aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
													$aResponse['data']      = 'Device Number is not Valid';

													$this->webResponse($sformat, $aResponse);
												}
											}
											else
											{
												$aResponse['code']      = 5;
												$aResponse['status']    = $this->aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
												$aResponse['data']      = 'Devices not available.';

												$this->webResponse($sformat, $aResponse);
											}
										}
										else if($sPumpType == '12')
										{
											
											if($sResponse['powercenter'] != '')
											{
												$sPowercenter   =   $sResponse['powercenter']; // Power Center Devices.
												if(isset($sPowercenter[$relay_number]) && $sPowercenter[$relay_number] != '')
												{    
													$sPumps      .= $sPowercenter[$relay_number];
												}
												else
												{
													$aResponse['code']      = 5;
													$aResponse['status']    = $this->aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
													$aResponse['data']      = 'Device Number is not Valid';

													$this->webResponse($sformat, $aResponse);
												}
											}
											else
											{
												$aResponse['code']      = 5;
												$aResponse['status']    = $this->aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
												$aResponse['data']      = 'Device not available.';

												$this->webResponse($sformat, $aResponse);
											}
										}
									}
									else
									{
										if(preg_match('/Emulator/',$sPumpType) || preg_match('/Intellicom/',$sPumpType))
										{
											if($sResponse['pump_seq_'.$sPumpNumber.'_st'] > 0)
												$sPumps .= 1;
											else 
												$sPumps .= 0;
										}
									}
								}
								else
								{
									$aResponse['code']      = 5;
									$aResponse['status']    = $this->aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
									$aResponse['data']      = 'Pump devices not configured properly or Closure is set to 0.';

									// Return Response to browser. This will exit the script.
									$this->webResponse($sformat, $aResponse);
								}
							  }
							}
							else
							{
								if(isset($sResponse['pump_seq_'.$i.'_st']))
								{
									$sPumps .= '.';
								}
							}
						}
						$aResponse['code']      = 1;
						$aResponse['status']    = $this->aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
						$aResponse['data']      = $sPumps;
					
						$this->webResponse($sformat, $aResponse);
						
					}// END : If Device is PUMPS.
					else if($sDevice == "T")// START : If Device is Temperature Sensor.
					{
						$sTemprature	= 	array();
						/* $sTemprature[0] = $sResponse['TS0'];
						$sTemprature[1] = $sResponse['TS1'];
						$sTemprature[2] = $sResponse['TS2'];
						$sTemprature[3] = $sResponse['TS3'];
						$sTemprature[4] = $sResponse['TS4'];
						$sTemprature[5] = $sResponse['TS5']; */
						
						for($i=0; $i<=5; $i++)
						{
							$sTemprature[$i]['temp'] = $sResponse['TS'.$i];	
							$sTemprature[$i]['name'] = $this->home_model->getDeviceName($i,'T',$ipID);
						}
						
						$aResponse['code']      = 1;
						$aResponse['status']    = $this->aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
						$aResponse['data']      = json_encode($sTemprature);
						
						$this->webResponse($sformat, $aResponse);
						
					}// END : If Device is Temperature Sensor.
					else if($sDevice == "B")// START : If Device is Blower.
					{
						$sBlower	= 	array();
						
						//Number of blower set on the setting Page.
						if($ipID == 1)
						$iNumBlower	=	$sExtra['BlowerNumber'];
						else
						$iNumBlower	=	$sExtra['BlowerNumber2'];
						
						//If Blower is not set or count is 0.
						if($iNumBlower == 0 || $iNumBlower == '')
						{
							$aResponse['code']      = 5;
							$aResponse['status']    = $this->aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
							$aResponse['data']      = 'Blower Devices are not available!';
							
							$this->webResponse($sformat, $aResponse);
							exit;
						}//If Blower is not set or count is 0.
						
						for($i=0; $i<$iNumBlower; $i++)		
						{
							//Blower Details
							$aBlowerDetails  =   $this->home_model->getBlowerDeviceDetails($i,$ipID);
							if(!empty($aBlowerDetails))
							{
								$sRelays        =   $sResponse['relay'];
								$sPowercenter   =   $sResponse['powercenter'];
								
								foreach($aBlowerDetails as $aBlower)
								{
									$sBlowerStatus	=	'';
									$sRelayDetails  =   unserialize($aBlower->light_relay_number);
									
									//Blower Operated Type and Relay
									$sRelayType     =   $sRelayDetails['sRelayType'];
									$sRelayNumber   =   $sRelayDetails['sRelayNumber'];
									
									if($sRelayType == '24')
									{
										$sBlowerStatus   =   $sRelays[$sRelayNumber];
									}
									if($sRelayType == '12')
									{
										$sBlowerStatus   =   $sPowercenter[$sRelayNumber];
									}
								
									$sBlower[$i] = $sBlowerStatus;
								}
							}
						}
						
						$aResponse['code']      = 1;
						$aResponse['status']    = $this->aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
						$aResponse['data']      = json_encode($sBlower);
						
						$this->webResponse($sformat, $aResponse);
						
					}// END : If Device is Blower.
					else if($sDevice == "L")// START : If Device is Light.
					{
						$sLight	= 	array();
						
						//Number of blower set on the setting Page.
						if($ipID == 1)
						$iNumLight	=	$sExtra['LightNumber'];
						else
						$iNumLight	=	$sExtra['LightNumber2'];
						
						//If Blower is not set or count is 0.
						if($iNumLight == 0 || $iNumLight == '')
						{
							$aResponse['code']      = 5;
							$aResponse['status']    = $this->aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
							$aResponse['data']      = 'Light Devices are not available!';
							
							$this->webResponse($sformat, $aResponse);
							exit;
						}//If Blower is not set or count is 0.
						
						for($i=0; $i<$iNumLight; $i++)		
						{
							//Light Details
							$aLightDetails  =   $this->home_model->getLightDeviceDetails($i,$ipID);
							if(!empty($aLightDetails))
							{
								$sRelays        =   $sResponse['relay'];
								$sPowercenter   =   $sResponse['powercenter'];
								
								foreach($aLightDetails as $aLight)
								{
									$sLightStatus	=	'';
									$sRelayDetails  =   unserialize($aLight->light_relay_number);
									
									//Light Operated Type and Relay
									$sRelayType     =   $sRelayDetails['sRelayType'];
									$sRelayNumber   =   $sRelayDetails['sRelayNumber'];
									
									if($sRelayType == '24')
									{
										$sLightStatus   =   $sRelays[$sRelayNumber];
									}
									if($sRelayType == '12')
									{
										$sLightStatus   =   $sPowercenter[$sRelayNumber];
									}
								
									$sLight[$i] = $sLightStatus;
								}
							}
						}
						
						$aResponse['code']      = 1;
						$aResponse['status']    = $this->aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
						$aResponse['data']      = json_encode($sLight);
						
						$this->webResponse($sformat, $aResponse);
						
					}// END : If Device is Heater.
					else if($sDevice == "H")// START : If Device is Heater.
					{
						$sHeater	= 	array();
						
						//Number of blower set on the setting Page.
						if($ipID == 1)
						$iNumHeater	=	$sExtra['HeaterNumber'];
						else
						$iNumHeater	=	$sExtra['HeaterNumber2'];
						
						//If Blower is not set or count is 0.
						if($iNumHeater == 0 || $iNumHeater == '')
						{
							$aResponse['code']      = 5;
							$aResponse['status']    = $this->aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
							$aResponse['data']      = 'Heater Devices are not available!';
							
							$this->webResponse($sformat, $aResponse);
							exit;
						}//If Blower is not set or count is 0.
						
						for($i=0; $i<$iNumHeater; $i++)		
						{
							//Heater Details
							$aHeaterDetails  =   $this->home_model->getHeaterDeviceDetails($i,$ipID);
							if(!empty($aHeaterDetails))
							{
								$sRelays        =   $sResponse['relay'];
								$sPowercenter   =   $sResponse['powercenter'];
								
								foreach($aHeaterDetails as $aHeater)
								{
									$sHeaterStatus	=	'';
									$sRelayDetails  =   unserialize($aHeater->light_relay_number);
									
									//Heater Operated Type and Relay
									$sRelayType     =   $sRelayDetails['sRelayType'];
									$sRelayNumber   =   $sRelayDetails['sRelayNumber'];
									
									if($sRelayType == '24')
									{
										$sHeaterStatus   =   $sRelays[$sRelayNumber];
									}
									if($sRelayType == '12')
									{
										$sHeaterStatus   =   $sPowercenter[$sRelayNumber];
									}
								
									$sHeater[$i] = $sHeaterStatus;
								}
							}
						}
						
						$aResponse['code']      = 1;
						$aResponse['status']    = $this->aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
						$aResponse['data']      = json_encode($sHeater);
						
						$this->webResponse($sformat, $aResponse);
						
					}// END : If Device is Heater.
					else if($sDevice == "M")// START : If Device is Misc.
					{
						$sMisc	= 	array();
						
						//Number of blower set on the setting Page.
						if($ipID == 1)
						$iNumMisc	=	$sExtra['MiscNumber'];
						else
						$iNumMisc	=	$sExtra['MiscNumber2'];
						
						//If Blower is not set or count is 0.
						if($iNumMisc == 0 || $iNumMisc == '')
						{
							$aResponse['code']      = 5;
							$aResponse['status']    = $this->aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
							$aResponse['data']      = 'Misc Devices are not available!';
							
							$this->webResponse($sformat, $aResponse);
							exit;
						}//If Blower is not set or count is 0.
						
						for($i=0; $i<$iNumHeater; $i++)		
						{
							//Heater Details
							$aMiscDetails  =   $this->home_model->getMiscDeviceDetails($i,$ipID);
							if(!empty($aMiscDetails))
							{
								$sRelays        =   $sResponse['relay'];
								$sPowercenter   =   $sResponse['powercenter'];
								
								foreach($aMiscDetails as $aMisc)
								{
									$sMiscStatus	=	'';
									$sRelayDetails  =   unserialize($aMisc->light_relay_number);
									
									//Heater Operated Type and Relay
									$sRelayType     =   $sRelayDetails['sRelayType'];
									$sRelayNumber   =   $sRelayDetails['sRelayNumber'];
									
									if($sRelayType == '24')
									{
										$sMiscStatus   =   $sRelays[$sRelayNumber];
									}
									if($sRelayType == '12')
									{
										$sMiscStatus   =   $sPowercenter[$sRelayNumber];
									}
								
									$sMisc[$i] = $sMiscStatus;
								}
							}
						}
						
						$aResponse['code']      = 1;
						$aResponse['status']    = $this->aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
						$aResponse['data']      = json_encode($sMisc);
						
						$this->webResponse($sformat, $aResponse);
						
					}// END : If Device is Misc.
					
                } // END : If device type is not empty. if($sDevice != '')
                else
                {
                    $aResponse['code']      = 5;
                    $aResponse['status']    = $this->aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
                    $aResponse['data']      = 'Invalid Device Type.';

                    // Return Response to browser. This will exit the script.
                    $this->webResponse($sformat, $aResponse);
                }
            } // END : If Mode is Manual.
            /*else
            {
                $aResponse['code']      = 5;
                $aResponse['status']    = $this->aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
                $aResponse['data']      = 'Invalid mode to perform this operation.';

                // Return Response to browser. This will exit the script.
                $this->webResponse($sformat, $aResponse);
            }*/
            
         } // END : getDeviceStatus()
        
		/**
		* Function to Get the Status of Particular Device.
		* @param
		* @return : Validation message or Status of the Device Number.
		**/
        public function getDeviceNumberStatus()
        {
             // Set default HTTP response of 'ok'
            $aResponse              =   array();
            $aResponse['code']      =   0;
            $aResponse['status']    =   404;
            $aResponse['data']      =   NULL;
            $sformat                =   isset($_GET['format']) ? $_GET['format'] : '' ; // Get response Format (json,xml,html etc.)
            $sAuth                  =   isset($_GET['auth']) ? $_GET['auth'] : '' ;// Check if Authentication is required.
            $this->isAuthenticationRequired =   $sAuth;
            
            // Optionally require connections to be made via HTTPS
            if( $this->isHTTPSRequired && $_SERVER['HTTPS'] != 'on' )
            {
                $aResponse['code']      = 2;
                $aResponse['status']    = $aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
                $aResponse['data']      = $aApiResponseCode[ $aResponse['code'] ]['Message'];

                // Return Response to browser. This will exit the script.
                $this->webResponse($sformat, $aResponse);
            }
            
            if($this->isAuthenticationRequired)
            {
                //START : Authorisation
                $sUsername       = isset($_GET['username']) ? $_GET['username'] : '' ;   // Get the username of webservice 
                $sPassword       = isset($_GET['password']) ? $_GET['password'] : '' ;   // Get the password of webservice 
                $this->webAuthorisation($sUsername, $sPassword,$sformat); // Check if username and password is valid.
                // END : Authorisation
            }
            
            #INPUTS
            $sDevice         = isset($_GET['dvc']) ? $_GET['dvc'] : '' ;  // Get the Device(ie. R=Relay,V=Valve,PC=Power Center)
            $sDeviceNo       = isset($_GET['dn'])  ? $_GET['dn'] : '' ;  // Get the Device No.
            
            $aResult            = array();
            $aResult['msg']     = "";
            $aResult['status']  = 0;
            $aResult['response']="0";
            $sValves            = ""; // Valve Devices Initialization.
            $sRelays            = "";  // Relay Devices Initialization.
            $sPowercenter       = ""; // Power Center Devices Initialization.
            
            $this->load->model('home_model');
			
			$ipID			 = isset($_GET['ip']) ? $_GET['ip'] : '' ; // IP ID
			if($ipID == '')
			{
				$aResponse['code']      = 5;
                $aResponse['status']    = $this->aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
                $aResponse['data']      = 'Please Enter Valid IP.';

                // Return Response to browser. This will exit the script.
                $this->webResponse($sformat, $aResponse);
            }
			//GET IP of Device
			$sDeviceIP		= 	$this->home_model->getBoardIPFromID($ipID);
			
			//Get SSH port when working on LOCAL.
			$shhPort	=	'';
			if(IS_LOCAL == '1')
			{
				//Get SSH port of the RLB board using IP.
				$shhPort = $this->home_model->getSSHPortFromID($ipID);
			}
			
            $iActiveMode =  $this->home_model->getActiveMode();
			
			//Get the number of Devices(Blower,Light and Heater) from the settings.
			list($sIP,$sPort,$sExtra) = $this->home_model->getSettings();
            
            //if($iActiveMode == 2) // START : If Mode is Manual.
            {
                if($sDevice != '' && $sDeviceNo != '') // START : If device type is not empty and Valid Device number is there.
                {
                    $sResponse      =   get_rlb_status($sDeviceIP,$sPort,$shhPort); // Get the relay borad response from server.
                    if($sDevice == "V") // START : If Device is Valve
                    {
                        if($sResponse['valves'] != '') // START : Checked if Valve Devices are available
                        {
                            $sValves        =   $sResponse['valves']; // Valve Devices.
                            if(isset($sValves[$sDeviceNo]) && $sValves[$sDeviceNo] != '')
                            {    
                                $aResponse['code']      = 1;
                                $aResponse['status']    = $this->aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
                                $aResponse['data']      = $sValves[$sDeviceNo];
                                
                                $this->webResponse($sformat, $aResponse);
                            }
                            else
                            {
                                $aResponse['code']      = 5;
                                $aResponse['status']    = $this->aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
                                $aResponse['data']      = 'Device Number is not Valid';
                                
                                $this->webResponse($sformat, $aResponse);
                            }
                        } // END : Checked if Valve Devices are available
                        else
                        {
                            $aResponse['code']      = 5;
                            $aResponse['status']    = $this->aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
                            $aResponse['data']      = 'Valve devices not available.';

                            $this->webResponse($sformat, $aResponse);
                        }
                    } // if($sDevice == "V") END : If Device is Valve
                    else if($sDevice == "R") // START : If Device is Relay.
                    {
                        if($sResponse['relay'] != '')
                        {
                            $sRelays        =   $sResponse['relay'];  // Relay Devices.
                            if(isset($sRelays[$sDeviceNo]) && $sRelays[$sDeviceNo] != '')
                            {    
                                $aResponse['code']      = 1;
                                $aResponse['status']    = $this->aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
                                $aResponse['data']      = $sRelays[$sDeviceNo];

                                $this->webResponse($sformat, $aResponse);
                            }
                            else
                            {
                                $aResponse['code']      = 5;
                                $aResponse['status']    = $this->aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
                                $aResponse['data']      = 'Device Number is not Valid';

                                $this->webResponse($sformat, $aResponse);
                            }
                        }
                        else
                        {
                            $aResponse['code']      = 5;
                            $aResponse['status']    = $this->aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
                            $aResponse['data']      = 'Relay devices not available.';

                            $this->webResponse($sformat, $aResponse);
                        }
                    } // END : If Device is Relay.
                    else if($sDevice == "PC") // START : If Device is Power Center.
                    {
                        if($sResponse['powercenter'] != '')
                        {
                            $sPowercenter   =   $sResponse['powercenter']; // Power Center Devices.
                            if(isset($sPowercenter[$sDeviceNo]) && $sPowercenter[$sDeviceNo] != '')
                            {    
                                $aResponse['code']      = 1;
                                $aResponse['status']    = $this->aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
                                $aResponse['data']      = $sPowercenter[$sDeviceNo];

                                $this->webResponse($sformat, $aResponse);
                            }
                            else
                            {
                                $aResponse['code']      = 5;
                                $aResponse['status']    = $this->aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
                                $aResponse['data']      = 'Device Number is not Valid';

                                $this->webResponse($sformat, $aResponse);
                            }
                        }
                        else
                        {
                            $aResponse['code']      = 5;
                            $aResponse['status']    = $this->aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
                            $aResponse['data']      = 'Power Center devices not available.';

                            $this->webResponse($sformat, $aResponse);
                        }
                    } // END : If Device is Power Center.
					else if($sDevice == "PS")// START : If Device is PUMPS.
					{
						$sPumps = '';
						$aPumpDetails = $this->home_model->getPumpDetails($sDeviceNo,$ipID);
						//Variable Initialization to blank.
						$sPumpNumber  	= '';
						$sPumpType  	= '';
						$relay_number   = '';
						
						if(is_array($aPumpDetails) && !empty($aPumpDetails))
						{
						  foreach($aPumpDetails as $aResultEdit)
						  { 
							$sPumpNumber  = $aResultEdit->pump_number;
							$sPumpType    = $aResultEdit->pump_type;
							$relay_number = $aResultEdit->relay_number;
							$sPumpClosure = $aResultEdit->pump_closure;
							
							if($sPumpType != '')
							{
								if($sPumpType == '12' || $sPumpType == '24')
								{
									if($sPumpType == '24')
									{
										if($sResponse['relay'] != '')
										{
											$sRelays        =   $sResponse['relay'];  // Relay Devices.
											if(isset($sRelays[$relay_number]) && $sRelays[$relay_number] != '')
											{    
												$sPumps      = $sRelays[$relay_number];
											}
											else
											{
												$aResponse['code']      = 5;
												$aResponse['status']    = $this->aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
												$aResponse['data']      = 'Device Number is not Valid';

												$this->webResponse($sformat, $aResponse);
											}
										}
										else
										{
											$aResponse['code']      = 5;
											$aResponse['status']    = $this->aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
											$aResponse['data']      = 'Devices not available.';

											$this->webResponse($sformat, $aResponse);
										}
									}
									else if($sPumpType == '12')
									{
										
										if($sResponse['powercenter'] != '')
										{
											$sPowercenter   =   $sResponse['powercenter']; // Power Center Devices.
											if(isset($sPowercenter[$relay_number]) && $sPowercenter[$relay_number] != '')
											{    
												$sPumps      = $sPowercenter[$relay_number];
											}
											else
											{
												$aResponse['code']      = 5;
												$aResponse['status']    = $this->aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
												$aResponse['data']      = 'Device Number is not Valid';

												$this->webResponse($sformat, $aResponse);
											}
										}
										else
										{
											$aResponse['code']      = 5;
											$aResponse['status']    = $this->aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
											$aResponse['data']      = 'Device not available.';

											$this->webResponse($sformat, $aResponse);
										}
									}
								}
								else
								{
									$sResponse['pump_seq_'.$sPumpNumber.'_st'];
									if($sResponse['pump_seq_'.$sPumpNumber.'_st'] > 0)
										$sPumps = 1;
									else if($sResponse['pump_seq_'.$sPumpNumber.'_st'] == 0)
										$sPumps = 0;
									
								}
							}
							else
							{
								$aResponse['code']      = 5;
								$aResponse['status']    = $this->aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
								$aResponse['data']      = 'Pump devices not configured properly or Closure is set to 0.';

								// Return Response to browser. This will exit the script.
								$this->webResponse($sformat, $aResponse);
							}
						  }
						}
						else
						{
							if(isset($sResponse['pump_seq_'.$sDeviceNo.'_st']))
							{
								$sPumps = '.';
							}
						}
						
						if($sPumps != '' || $sPumps == 0)
						{
							$aResponse['code']      = 1;
							$aResponse['status']    = $this->aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
							$aResponse['data']      = $sPumps;
							
							$this->webResponse($sformat, $aResponse);
						}
						else
						{
							$aResponse['code']      = 5;
                            $aResponse['status']    = $this->aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
                            $aResponse['data']      = 'Pump devices not available.';

                            $this->webResponse($sformat, $aResponse);
						}
					}// END : If Device is PUMPS.
					else if($sDevice == "T")// START : If Device is Temperature.
					{
						$sTemprature = '';
						if(isset($sResponse['TS'.$sDeviceNo]))
						{
							$sTemprature	= 	$sResponse['TS'.$sDeviceNo];
						}
						
						if($sTemprature != '')
						{
							$aResponse['code']      = 1;
							$aResponse['status']    = $this->aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
							$aResponse['data']      = $sTemprature;
							
							$this->webResponse($sformat, $aResponse);
						}
						else
						{
							$aResponse['code']      = 5;
                            $aResponse['status']    = $this->aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
                            $aResponse['data']      = 'Temperature devices not available.';

                            $this->webResponse($sformat, $aResponse);
						}
					}// END : If Device is Temperature.
					else if($sDevice == 'B') // START : If Device is Blower.
					{
						//Number of blower set on the setting Page.
						if($ipID == 1)
						$iNumBlower	=	$sExtra['BlowerNumber'];
					    else
						$iNumBlower	=	$sExtra['BlowerNumber2'];
					
						//If Blower is not set or count is 0.
						if($iNumBlower == 0 || $iNumBlower == '')
						{
							$aResponse['code']      = 5;
							$aResponse['status']    = $this->aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
							$aResponse['data']      = 'Blower Devices are not available!';
							
							$this->webResponse($sformat, $aResponse);
							exit;
						}//If Blower is not set or count is 0.
						
						//Blower Details
						$aBlowerDetails  =   $this->home_model->getBlowerDeviceDetails($sDeviceNo,$ipID);
						if(!empty($aBlowerDetails))
						{
							$sRelays        =   $sResponse['relay']; // 24V AC Relays
                            $sPowercenter   =   $sResponse['powercenter']; // Power Center Devices.
							foreach($aBlowerDetails as $aBlower)
							{
								$sBlowerStatus	=	'';
								$sRelayDetails  =   unserialize($aBlower->light_relay_number);
								
								//Blower Operated Type and Relay
								$sRelayType     =   $sRelayDetails['sRelayType'];
								$sRelayNumber   =   $sRelayDetails['sRelayNumber'];
								
								if($sRelayType == '24')
								{
									$sBlowerStatus   =   $sRelays[$sRelayNumber];
								}
								if($sRelayType == '12')
								{
									$sBlowerStatus   =   $sPowercenter[$sRelayNumber];
								}
							
								$aResponse['code']      = 1;
								$aResponse['status']    = $this->aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
								$aResponse['data']      = $sBlowerStatus;
								
								$this->webResponse($sformat, $aResponse);
							}
						}
						else
						{
							$aResponse['code']      = 5;
                            $aResponse['status']    = $this->aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
                            $aResponse['data']      = 'Blower devices not available.';

                            $this->webResponse($sformat, $aResponse);
						}
					}// END : If Device is Blower.
					else if($sDevice == 'L') // START : If Device is Light.
					{
						//Number of Light set on the setting Page.
						if($ipID == 1)
						$iNumLight	=	$sExtra['LightNumber'];
						else
						$iNumLight	=	$sExtra['LightNumber2'];	
						
						//If Light is not set or count is 0.
						if($iNumLight == 0 || $iNumLight == '')
						{
							$aResponse['code']      = 5;
							$aResponse['status']    = $this->aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
							$aResponse['data']      = 'Light Devices are not available!';
							
							$this->webResponse($sformat, $aResponse);
							exit;
						}//If Light is not set or count is 0.
												
						//Light Details
						$aLightDetails  =   $this->home_model->getLightDeviceDetails($sDeviceNo,$ipID);
						if(!empty($aLightDetails))
						{
							$sRelays        =   $sResponse['relay']; // 24V AC Relays
                            $sPowercenter   =   $sResponse['powercenter']; // Power Center Devices.
							foreach($aLightDetails as $aLight)
							{
								$sLightStatus	=	'';
								$sRelayDetails  =   unserialize($aLight->light_relay_number);
								
								//Light Operated Type and Relay
								$sRelayType     =   $sRelayDetails['sRelayType'];
								$sRelayNumber   =   $sRelayDetails['sRelayNumber'];
								
								if($sRelayType == '24')
								{
									$sLightStatus   =   $sRelays[$sRelayNumber];
								}
								if($sRelayType == '12')
								{
									$sLightStatus   =   $sPowercenter[$sRelayNumber];
								}
							
								$aResponse['code']      = 1;
								$aResponse['status']    = $this->aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
								$aResponse['data']      = $sLightStatus;
								
								$this->webResponse($sformat, $aResponse);
							}
						}
						else
						{
							$aResponse['code']      = 5;
							$aResponse['status']    = $this->aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
							$aResponse['data']      = 'Light Device is not available!';
							
							$this->webResponse($sformat, $aResponse);
							exit;
						}
					}// END : If Device is Light
					else if($sDevice == 'H')// START : If Device is Heater
					{
						//Number of Heater set on the setting Page.
						if($ipID == 1)
						$iNumHeater	=	$sExtra['HeaterNumber'];
						else
						$iNumHeater	=	$sExtra['HeaterNumber2'];	
						
						//If Heater is not set or count is 0.
						if($iNumHeater == 0 || $iNumHeater == '')
						{
							$aResponse['code']      = 5;
							$aResponse['status']    = $this->aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
							$aResponse['data']      = 'Heater Devices are not available!';
							
							$this->webResponse($sformat, $aResponse);
							exit;
						}//If Heater is not set or count is 0.
						
						//Heater Details
						$aHeaterDetails  =   $this->home_model->getHeaterDeviceDetails($sDeviceNo,$ipID);
						if(!empty($aHeaterDetails))
						{
							$sRelays        =   $sResponse['relay']; // 24V AC Relays
                            $sPowercenter   =   $sResponse['powercenter']; // Power Center Devices.
							foreach($aHeaterDetails as $aHeater)
							{
								$sHeaterStatus	=	'';
								$sRelayDetails  =   unserialize($aHeater->light_relay_number);
								
								//Heater Operated Type and Relay
								$sRelayType     =   $sRelayDetails['sRelayType'];
								$sRelayNumber   =   $sRelayDetails['sRelayNumber'];
								
								if($sRelayType == '24')
								{
									$sHeaterStatus   =   $sRelays[$sRelayNumber];
								}
								if($sRelayType == '12')
								{
									$sHeaterStatus   =   $sPowercenter[$sRelayNumber];
								}
							
								$aResponse['code']      = 1;
								$aResponse['status']    = $this->aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
								$aResponse['data']      = $sHeaterStatus;
								
								$this->webResponse($sformat, $aResponse);
							}
						}
						else
						{
							$aResponse['code']      = 5;
							$aResponse['status']    = $this->aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
							$aResponse['data']      = 'Heater Device is not available!';
							
							$this->webResponse($sformat, $aResponse);
							exit;
						}
					}// END : If Device is Heater
					else if($sDevice == 'M')// START : If Device is Misc.
					{
						//Number of Heater set on the setting Page.
						if($ipID == 1)
						$iNumMisc	=	$sExtra['MiscNumber'];
						else
						$iNumMisc	=	$sExtra['MiscNumber2'];	
						
						//If Misc Device is not set or count is 0.
						if($iNumMisc == 0 || $iNumMisc == '')
						{
							$aResponse['code']      = 5;
							$aResponse['status']    = $this->aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
							$aResponse['data']      = 'Misc Devices are not available!';
							
							$this->webResponse($sformat, $aResponse);
							exit;
						}//If Misc Device is not set or count is 0.
						
						//Misc Device Details
						$aMiscDetails  =   $this->home_model->getMiscDeviceDetails($sDeviceNo,$ipID);
						if(!empty($aMiscDetails))
						{
							$sRelays        =   $sResponse['relay']; // 24V AC Relays
                            $sPowercenter   =   $sResponse['powercenter']; // Power Center Devices.
							foreach($aMiscDetails as $aMisc)
							{
								$sMiscStatus	=	'';
								$sRelayDetails  =   unserialize($aMisc->light_relay_number);
								
								//Heater Operated Type and Relay
								$sRelayType     =   $sRelayDetails['sRelayType'];
								$sRelayNumber   =   $sRelayDetails['sRelayNumber'];
								
								if($sRelayType == '24')
								{
									$sMiscStatus   =   $sRelays[$sRelayNumber];
								}
								if($sRelayType == '12')
								{
									$sMiscStatus   =   $sPowercenter[$sRelayNumber];
								}
							
								$aResponse['code']      = 1;
								$aResponse['status']    = $this->aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
								$aResponse['data']      = $sMiscStatus;
								
								$this->webResponse($sformat, $aResponse);
							}
						}
						else
						{
							$aResponse['code']      = 5;
							$aResponse['status']    = $this->aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
							$aResponse['data']      = 'Misc Device is not available!';
							
							$this->webResponse($sformat, $aResponse);
							exit;
						}
					}// END : If Device is Misc
                } // if($sDevice != '')  END : If device type is not empty and Valid Device number is there. 
                else
                {
                    $aResponse['code']      = 5;
                    $aResponse['status']    = $this->aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
                    $aResponse['data']      = 'Invalid Device Type or Device Number.';

                    $this->webResponse($sformat, $aResponse);
                    
                }
            } // END : If Mode is Manual.
            /*else
            {
                $aResponse['code']      = 5;
                $aResponse['status']    = $this->aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
                $aResponse['data']      = 'Invalid mode to perform this operation.';

                $this->webResponse($sformat, $aResponse);
            }*/
            
         } // END : function getDeviceNumberStatus()
         
         
        /**
		* Function to Get the Active Mode.
		* @param
		* @return : Validation message or Active Mode ID.
		**/ 
        public function getActiveMode() //START : Function to get the active mode for web service.
        {
            // Set default HTTP response of 'ok'
            $aResponse              =   array();
            $aResponse['code']      =   0;
            $aResponse['status']    =   404;
            $aResponse['data']      =   NULL;
            $sformat                =   isset($_GET['format']) ? $_GET['format'] : '' ; // Get response Format (json,xml,html etc.)
            $sAuth                  =   isset($_GET['auth']) ? $_GET['auth'] : '' ;// Check if Authentication is required.
            $this->isAuthenticationRequired =   $sAuth;
            
            // Optionally require connections to be made via HTTPS
            if( $this->isHTTPSRequired && $_SERVER['HTTPS'] != 'on' )
            {
                $aResponse['code']      = 2;
                $aResponse['status']    = $aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
                $aResponse['data']      = $aApiResponseCode[ $aResponse['code'] ]['Message'];

                // Return Response to browser. This will exit the script.
                $this->webResponse($sformat, $aResponse);
            }
            
            if($this->isAuthenticationRequired)
            {
                //START : Authorisation
                $sUsername       = isset($_GET['username']) ? $_GET['username'] : '' ;   // Get the username of webservice 
                $sPassword       = isset($_GET['password']) ? $_GET['password'] : '' ;   // Get the password of webservice 
                $this->webAuthorisation($sUsername, $sPassword,$sformat); // Check if username and password is valid.
                // END : Authorisation
            }
             
            $aResult            = array();
            $aResult['msg']     = "";
            $aResult['response']= 0;
            $aResult['status']  = 0;
            
            
            $this->load->model('home_model');
            //Get the mode from Database.
            $iActiveMode =  $this->home_model->getActiveMode();
            
            if($iActiveMode != '')
            {
                $aResponse['code']      = 1;
                $aResponse['status']    = $this->aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
                $aResponse['data']      = $iActiveMode;
                // Return Response to browser. This will exit the script.
                $this->webResponse($sformat, $aResponse);
            }
            else
            {
                $aResponse['code']      = 5;
                $aResponse['status']    = $this->aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
                $aResponse['data']      = 'Invalid mode.';
                // Return Response to browser. This will exit the script.
                $this->webResponse($sformat, $aResponse);
            }
         } //END : Function to get the active mode for web service.
		
		/**
		* Function to Change the Active Mode and depending on Mode change the device status.
		* @param
		* @return : Validation message or Active Mode ID.
		**/ 
		
		public function changeActiveMode() //START : Function to change the active mode for web service.
        {
			// Set default HTTP response of 'ok'
            $aResponse              =   array();
            $aResponse['code']      =   0;
            $aResponse['status']    =   404;
            $aResponse['data']      =   NULL;
            $sformat                =   isset($_GET['format']) ? $_GET['format'] : '' ; // Get response Format (json,xml,html etc.)
            $sAuth                  =   isset($_GET['auth']) ? $_GET['auth'] : '' ;// Check if Authentication is required.
            $this->isAuthenticationRequired =   $sAuth;
			
			//INPUTS
			$iMode	=	trim($_GET['md']);
			$iTime	=	trim($_GET['mt']); //Manual Time in Minute
            
            // Optionally require connections to be made via HTTPS
            if( $this->isHTTPSRequired && $_SERVER['HTTPS'] != 'on' )
            {
                $aResponse['code']      = 2;
                $aResponse['status']    = $aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
                $aResponse['data']      = $aApiResponseCode[ $aResponse['code'] ]['Message'];

                // Return Response to browser. This will exit the script.
                $this->webResponse($sformat, $aResponse);
            }
            
            if($this->isAuthenticationRequired)
            {
                //START : Authorisation
                $sUsername       = isset($_GET['username']) ? $_GET['username'] : '' ;   // Get the username of webservice 
                $sPassword       = isset($_GET['password']) ? $_GET['password'] : '' ;   // Get the password of webservice 
                $this->webAuthorisation($sUsername, $sPassword,$sformat); // Check if username and password is valid.
                // END : Authorisation
            }
             
            $aResult            = array();
            $aResult['msg']     = "";
            $aResult['response']= 0;
            $aResult['status']  = 0;
                        
            $this->load->model('home_model');
            //Get the mode from Database.
            $iActiveMode =  $this->home_model->getActiveMode();
            
            if($iMode != '')
            {
				if($iMode != $iActiveMode)
				{
					$this->home_model->updateMode($iMode);

					//If mode is manual then add the manual start time and end time calculated using the manual time(in minute) added on settings page.
					if($iMode == 2)
					{
						if($iTime == '')
							$sManualTime	=	$this->home_model->getManualModeTime();
					    else
							$sManualTime	=	$iTime;
						
						if($sManualTime != '')
						{
							if($iMode == 2)
							{
								$sProgramAbsStart =   date("H:i:s", time());
								$aStartTime       =   explode(":",$sProgramAbsStart);
								$sProgramAbsEnd   =   mktime(($aStartTime[0]),($aStartTime[1]+$sManualTime),($aStartTime[2]),date('m'),date('d'),date('Y'));
								$sAbsoluteEnd     =   date("Y-m-d H:i:s", $sProgramAbsEnd);
								$this->home_model->updateManualModeTimer($sProgramAbsStart,$sAbsoluteEnd);
								
								//Save Manual Mode Time.
								$this->home_model->updateManualModeTime($sManualTime);
							}
							else
							{
								$this->home_model->updateManualModeTimer('','');
							}	
						}
					}
						
					if($iMode == 3 || $iMode == 1)
					{
						$excludeDevices = unserialize($this->home_model->getExcludeDevices());
					
						list($sIP,$sPort,$extra) = $this->home_model->getSettings();
						$aViewParameter['aIPDetails'] = $this->home_model->getBoardIP();
						
						foreach($aViewParameter['aIPDetails'] as $IP)
						{
							$shhPort	=	'';
							if(IS_LOCAL == '1')
							{
								//Get SSH port of the RLB board using IP.
								$shhPort = $this->home_model->getSSHPortFromID($IP->id);
							}
							$sResponse		=	array();
							$sValves        =   ''; 
							$sRelays        =   '';  
							$sPowercenter   =   ''; 
							$sTime          =   '';
							$sPump			=	'';	
							$sTemprature	=	'';
							
							//Get the status response of devices from relay board.
							$sResponse      =   get_rlb_status($IP->ip,$sPort,$shhPort);
						
							$sValves        =   $sResponse['valves']; // Valve Device Status
							$sRelays        =   $sResponse['relay'];  // Relay Device Status
							$sPowercenter   =   $sResponse['powercenter']; // Power Center Device Status
							$sTime          =   $sResponse['time']; // Server Time from Response
							
							$relay_count   	=   strlen($sRelays);
							$valve_count    =   strlen($sValves);
							$power_count    =   strlen($sPowercenter);
							
							//off all relays
							if($sRelays != '')
							{
								//$sRelayNewResp = str_replace('1','0',$sRelays);
								//onoff_rlb_relay($sRelayNewResp,$IP->ip,$sPort,$shhPort);
								for($i=0; $i<$relay_count; $i++)	
								{
									if($sRelays[$i] != '.')
									{
										if(!in_array($i.'_'.$IP->id,$excludeDevices['R']))
										{
											$sNewResp = replace_return($sRelays, 0, $i);
											onoff_rlb_relay($sNewResp,$IP->ip,$sPort,$shhPort);
										}
										
										//Start : Check if relay is assigned to Heater.
										$HeaterNumber = $this->home_model->chkHeater($i,'24',$IP->id);
										if($HeaterNumber != '')
										{
											$this->heaterDetailsUpdateAfter($HeaterNumber,$IP->id,0);
										}
									}		
									//$sRelayNewResp = str_replace('1','0',$sRelays);
									//onoff_rlb_relay($sRelayNewResp,$IP->ip,$sPort,$shhPort);
								}
							}
							
							//off all valves
							if($sValves != '')
							{
								//$sValveNewResp = str_replace(array('1','2'), '0', $sValves);
								//onoff_rlb_valve($sValveNewResp,$IP->ip,$sPort,$shhPort);  
								for($i=0; $i<$valve_count; $i++)	
								{
									if($sValves[$i] != '.')
									{
										if(!in_array($i.'_'.$IP->id,$excludeDevices['V']))
										{
											$sNewResp = replace_return($sValves, 0, $i);
											onoff_rlb_valve($sNewResp,$IP->ip,$sPort,$shhPort);
										}
									}
								}
							}
							
							//off all power center
							if($sPowercenter != '')
							{
								for($i=0; $i<$power_count; $i++)	
								{
									if(!in_array($i.'_'.$IP->id,$excludeDevices['P']))
									{
										$sNewResp = replace_return($sPowercenter, 0, $i);
										onoff_rlb_powercenter($sNewResp,$IP->ip,$sPort,$shhPort);
									}
									
									//Start : Check if relay is assigned to Heater.
									$HeaterNumber = $this->home_model->chkHeater($i,'12',$IP->id);
									if($HeaterNumber != '')
									{
										$this->heaterDetailsUpdateAfter($HeaterNumber,$IP->id,0);
									}
								}
								//$sPowerNewResp = str_replace('1','0',$sPowercenter);  
								//onoff_rlb_powercenter($sPowerNewResp,$IP->ip,$sPort,$shhPort); 
							}
							
							//GET all Pump Devices.
							$aPumpDetails	=	$this->home_model->getAllPumpDetails($IP->id);
							if(!empty($aPumpDetails))
							{
								foreach($aPumpDetails as $aPump)	
								{
									$sStatus	  = 0;
									$sPumpNumber  = $aPump->pump_number;
									$sPumpType    = $aPump->pump_type;
									$sPumpSubType = $aPump->pump_sub_type;
									$sRelayNumber = $aPump->relay_number;
									$sRelayNumber1 = $aPump->relay_number_1;
									
									if(!in_array($sPumpNumber.'_'.$IP->id,$excludeDevices['PS']))
									{
										if($sPumpType == '12' || $sPumpType == '24' || $sPumpType == '2Speed')
										{
											
											if($sPumpType == '24')
											{
												$sNewResp = replace_return($sRelays, $sStatus, $sRelayNumber );
												onoff_rlb_relay($sNewResp,$IP->ip,$sPort,$shhPort);
												
												$this->home_model->updateDeviceRunTime($sRelayNumber,'R',$sStatus,$IP->id);
												$this->home_model->updateDeviceStauts($sRelayNumber,'R',$sStatus,$IP->id);
												
											}
											else if($sPumpType == '12')
											{
												$sNewResp = replace_return($sPowercenter, $sStatus, $sRelayNumber );
												onoff_rlb_powercenter($sNewResp,$IP->ip,$sPort,$shhPort);
												
												$this->home_model->updateDeviceStauts($sRelayNumber,'P',$sStatus,$IP->id);
												
											}
											if($sPumpType == '2Speed')
											{
												if($sPumpSubType == '24')
												{
													$sNewResp = replace_return($sRelays, 0, $sRelayNumber );
													onoff_rlb_relay($sNewResp,$IP->ip,$sPort,$shhPort);
													$this->home_model->updateDeviceRunTime($sRelayNumber,'R',0,$IP->id);
													$this->home_model->updateDeviceStauts($sRelayNumber,'R',0,$IP->id);
													
													$sNewResp = replace_return($sNewResp, '0', $sRelayNumber1 );
													onoff_rlb_relay($sNewResp,$IP->ip,$sPort,$shhPort);
													$this->home_model->updateDeviceRunTime($sRelayNumber1,'R',0,$IP->id);
													$this->home_model->updateDeviceStauts($sRelayNumber1,'R',0,$IP->id);
													
												}
												else if($sPumpSubType == '12')
												{
													$sNewResp = replace_return($sPowercenter, '0', $sRelayNumber );
													onoff_rlb_powercenter($sNewResp,$IP->ip,$sPort,$shhPort);
													$sNewResp = replace_return($sNewResp, '0', $sRelayNumber1 );
													onoff_rlb_powercenter($sNewResp,$IP->ip,$sPort,$shhPort);
													$this->home_model->updateDeviceStauts($sRelayNumber,'P',0,$IP->id);
													$this->home_model->updateDeviceStauts($sRelayNumber1,'P',0,$IP->id);
												}
											}
										}
										else
										{
											if(preg_match('/Emulator/',$sPumpType))
											{
												$sNewResp =  $sPumpNumber.' '.$sStatus;
												onoff_rlb_pump($sNewResp,$IP->ip,$sPort,$shhPort);
												
												if($sPumpType == 'Emulator12')
												{
													$sNewResp12 = replace_return($sPowercenter, $sStatus, $sRelayNumber );
													onoff_rlb_powercenter($sNewResp12,$IP->ip,$sPort,$shhPort);
												}
												if($sPumpType == 'Emulator24')
												{
													$sNewResp24 = replace_return($sRelays, $sStatus, $sRelayNumber );
													onoff_rlb_relay($sNewResp24,$IP->ip,$sPort,$shhPort);
													$this->home_model->updateDeviceRunTime($sRelayNumber,'R',$sStatus,$IP->id);
												}
												$this->home_model->updateDeviceStauts($sPumpNumber,'PS',$sStatus,$IP->id);
											}
											else if(preg_match('/Intellicom/',$sPumpType))
											{
												$sNewResp =  $sPumpNumber.' '.$sStatus;
												onoff_rlb_pump($sNewResp,$IP->ip,$sPort,$shhPort);
												
												if($sPumpType == 'Intellicom12')
												{
													$sNewResp12 = replace_return($sPowercenter, $sStatus, $sRelayNumber );
													onoff_rlb_powercenter($sNewResp12,$IP->ip,$sPort,$shhPort);
												}
												if($sPumpType == 'Intellicom24')
												{
													$sNewResp24 = replace_return($sRelays, $sStatus, $sRelayNumber );
													onoff_rlb_relay($sNewResp24,$IP->ip,$sPort,$shhPort);
													$this->home_model->updateDeviceRunTime($sRelayNumber,'R',$sStatus,$IP->id);
												}
												$this->home_model->updateDeviceStauts($sPumpNumber,'PS',$sStatus,$IP->id);
											}
										}
									}
								}
							}
						}
					}
					
					$aResponse['code']      = 1;
					$aResponse['status']    = $this->aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
					$aResponse['data']      = $iMode;
					
					// Return Response to browser. This will exit the script.
					$this->webResponse($sformat, $aResponse);
				}
				else
				{
					//If mode is manual then add the manual start time and end time calculated using the manual time(in minute) added on settings page.
					if($iMode == 2)
					{
						$sManualTime	=	$this->home_model->getManualModeTime();
						
						if($iTime != '')
						{
							if($sManualTime != $iTime)
							{
								$sProgramAbsStart =   date("H:i:s", time());
								$aStartTime       =   explode(":",$sProgramAbsStart);
								$sProgramAbsEnd   =   mktime(($aStartTime[0]),($aStartTime[1]+$iTime),($aStartTime[2]),date('m'),date('d'),date('Y'));
								$sAbsoluteEnd     =   date("Y-m-d H:i:s", $sProgramAbsEnd);
								$this->home_model->updateManualModeTimer($sProgramAbsStart,$sAbsoluteEnd);
								
								//Update the new time in database.
								$this->home_model->updateManualModeTime($iTime);
								
								$aResponse['code']      = 1;
								$aResponse['status']    = $this->aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
								$aResponse['data']      = $iMode;
								
								// Return Response to browser. This will exit the script.
								$this->webResponse($sformat, $aResponse);
							}
							else							
							{
								$aResponse['code']      = 1;
								$aResponse['status']    = $this->aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
								$aResponse['data']      = 'Mode already activated!';
								
								// Return Response to browser. This will exit the script.
								$this->webResponse($sformat, $aResponse);
							}
						}
					}
					else
					{
						$aResponse['code']      = 1;
						$aResponse['status']    = $this->aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
						$aResponse['data']      = 'Mode already activated!';
												
						// Return Response to browser. This will exit the script.
						$this->webResponse($sformat, $aResponse);
					}
				}
            }
            else
            {
                $aResponse['code']      = 5;
                $aResponse['status']    = $this->aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
                $aResponse['data']      = 'Please enter Valid mode.';
				
				// Return Response to browser. This will exit the script.
                $this->webResponse($sformat, $aResponse);
            }
         } //END : Function to get the active mode for web service.
        
		public function heaterDetailsUpdateAfter($heaterNumber,$sIdIP,$sStatus)
		{
			$this->load->model('home_model');
			//GET IP of Device
			$sDeviceIP		= 	$this->home_model->getBoardIPFromID($sIdIP);
			
			//Get saved IP and PORT 
			list($sIP,$sPort,$extra) = $this->home_model->getSettings();
			
			$shhPort	=	'';
			if(IS_LOCAL == '1')
			{
				//Get SSH port of the RLB board using IP.
				$shhPort = $this->home_model->getSSHPortFromID($sIdIP);
			}
			$this->home_model->updateHeaterRunDetails($heaterNumber,$sIdIP);
			$aHeaterDetails  =   $this->home_model->getHeaterDeviceDetails($heaterNumber,$sIdIP);
			if(!empty($aHeaterDetails))
			{
				foreach($aHeaterDetails as $aHeater)
				$sHeaterDetails  =   unserialize($aHeater->light_relay_number);
				
				$PumpNumber   		=   $sHeaterDetails['Pump'];
				
			}
			
			$allOnPumps = $this->home_model->getOnPumpOfHeaters();
			if(!empty($allOnPumps))
			{
				foreach($allOnPumps as $pumpDetails)
				{
					$id			  = $pumpDetails->id;
					$this->home_model->updateRunCompletePump($id,'1');
				}
			}
		}
				
		
		public function changeActiveModeBackup() //START : Function to change the active mode for web service.
        {
            // Set default HTTP response of 'ok'
            $aResponse              =   array();
            $aResponse['code']      =   0;
            $aResponse['status']    =   404;
            $aResponse['data']      =   NULL;
            $sformat                =   isset($_GET['format']) ? $_GET['format'] : '' ; // Get response Format (json,xml,html etc.)
            $sAuth                  =   isset($_GET['auth']) ? $_GET['auth'] : '' ;// Check if Authentication is required.
            $this->isAuthenticationRequired =   $sAuth;
			
			//INPUTS
			$iMode	=	trim($_GET['md']);
			$iTime	=	trim($_GET['mt']); //Manual Time in Minute
            
            // Optionally require connections to be made via HTTPS
            if( $this->isHTTPSRequired && $_SERVER['HTTPS'] != 'on' )
            {
                $aResponse['code']      = 2;
                $aResponse['status']    = $aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
                $aResponse['data']      = $aApiResponseCode[ $aResponse['code'] ]['Message'];

                // Return Response to browser. This will exit the script.
                $this->webResponse($sformat, $aResponse);
            }
            
            if($this->isAuthenticationRequired)
            {
                //START : Authorisation
                $sUsername       = isset($_GET['username']) ? $_GET['username'] : '' ;   // Get the username of webservice 
                $sPassword       = isset($_GET['password']) ? $_GET['password'] : '' ;   // Get the password of webservice 
                $this->webAuthorisation($sUsername, $sPassword,$sformat); // Check if username and password is valid.
                // END : Authorisation
            }
             
            $aResult            = array();
            $aResult['msg']     = "";
            $aResult['response']= 0;
            $aResult['status']  = 0;
            
            
            $this->load->model('home_model');
            //Get the mode from Database.
            $iActiveMode =  $this->home_model->getActiveMode();
            
            if($iMode != '')
            {
				if($iMode != $iActiveMode)
				{
					$this->home_model->updateMode($iMode);

					//If mode is manual then add the manual start time and end time calculated using the manual time(in minute) added on settings page.
					if($iMode == 2)
					{
						if($iTime == '')
							$sManualTime	=	$this->home_model->getManualModeTime();
					    else
							$sManualTime	=	$iTime;
						
						if($sManualTime != '')
						{
							if($iMode == 2)
							{
								$sProgramAbsStart =   date("H:i:s", time());
								$aStartTime       =   explode(":",$sProgramAbsStart);
								$sProgramAbsEnd   =   mktime(($aStartTime[0]),($aStartTime[1]+$sManualTime),($aStartTime[2]),date('m'),date('d'),date('Y'));
								$sAbsoluteEnd     =   date("Y-m-d H:i:s", $sProgramAbsEnd);
								$this->home_model->updateManualModeTimer($sProgramAbsStart,$sAbsoluteEnd);
								
								//Save Manual Mode Time.
								$this->home_model->updateManualModeTime($sManualTime);
							}
							else
							{
								$this->home_model->updateManualModeTimer('','');
							}	
						}
					}
						
					$sResponse      =   get_rlb_status();
					$sValves        =   $sResponse['valves'];
					$sRelays        =   $sResponse['relay'];
					$sPowercenter   =   $sResponse['powercenter'];
					
					if($iMode == 3 || $iMode == 1)
					{ //1-auto, 2-manual, 3-timeout
						//off all relays
						if($sRelays != '')
						{
							$sRelayNewResp = str_replace('1','0',$sRelays);
							onoff_rlb_relay($sRelayNewResp);
						}
						
						//off all valves
						if($sValves != '')
						{
							$sValveNewResp = str_replace(array('1','2'), '0', $sValves);
							onoff_rlb_valve($sValveNewResp);  
						}
						
						//off all power center
						if($sPowercenter != '')
						{
							$sPowerNewResp = str_replace('1','0',$sPowercenter);  
							onoff_rlb_powercenter($sPowerNewResp); 
						}
						
						//GET all Pump Devices.
						$aPumpDetails	=	$this->home_model->getAllPumpDetails();
						if(!empty($aPumpDetails))
						{
							foreach($aPumpDetails as $aPump)	
							{
								$sStatus	  = 0;
								$sPumpNumber  = $aResultEdit->pump_number;
								$sPumpType    = $aResultEdit->pump_type;
								$sPumpSubType = $aResultEdit->pump_sub_type;
								$sRelayNumber = $aResultEdit->relay_number;
								$sRelayNumber1 = $aResultEdit->relay_number_1;
								
								if($sPumpType == '12' || $sPumpType == '24' || $sPumpType == '2Speed')
								{
									if($sPumpType == '24')
									{
										$sNewResp = replace_return($sRelays, $sStatus, $sRelayNumber );
										onoff_rlb_relay($sNewResp);
										$this->home_model->updateDeviceRunTime($sName,$sDevice,$sStatus);
										
										$this->home_model->updateDeviceStauts($sName,$sDevice,$sStatus);
									}
									else if($sPumpType == '12')
									{
										$sNewResp = replace_return($sPowercenter, $sStatus, $sRelayNumber );
										onoff_rlb_powercenter($sNewResp);
										
										$this->home_model->updateDeviceStauts($sName,$sDevice,$sStatus);
									}
									if($sPumpType == '2Speed')
									{
										if($sPumpSubType == '24')
										{
											$sNewResp = replace_return($sRelays, 0, $sRelayNumber );
											onoff_rlb_relay($sNewResp);
											$this->home_model->updateDeviceRunTime($sName,$sDevice,$sStatus);
											
											$sNewResp = replace_return($sNewResp, '0', $sRelayNumber1 );
											onoff_rlb_relay($sNewResp);
											$this->home_model->updateDeviceRunTime($sName,$sDevice,$sStatus);
											
											$this->home_model->updateDeviceStauts($sName,$sDevice,$sStatus);
											
										}
										else if($sPumpSubType == '12')
										{
											$sNewResp = replace_return($sPowercenter, '0', $sRelayNumber );
											onoff_rlb_powercenter($sNewResp);
											
											$sNewResp = replace_return($sNewResp, '0', $sRelayNumber1 );
											onoff_rlb_powercenter($sNewResp);
												
											$this->home_model->updateDeviceStauts($sName,$sDevice,$sStatus);
										}
									}
								}
								else
								{
									if(preg_match('/Emulator/',$sPumpType))
									{
										$sNewResp =  $sName.' '.$sStatus;
										onoff_rlb_pump($sNewResp);
										
										if($sPumpType == 'Emulator12')
										{
											$sNewResp12 = replace_return($sPowercenter, $sStatus, $sRelayNumber );
											onoff_rlb_powercenter($sNewResp12);
										}
										if($sPumpType == 'Emulator24')
										{
											$sNewResp24 = replace_return($sRelays, $sStatus, $sRelayNumber );
											onoff_rlb_relay($sNewResp24);
											$this->home_model->updateDeviceRunTime($sRelayNumber,'R',$sStatus);
										}
										$this->home_model->updateDeviceStauts($sName,$sDevice,$sStatus);
									}
									else if(preg_match('/Intellicom/',$sPumpType))
									{
										$sNewResp =  $sName.' '.$sStatus;
										onoff_rlb_pump($sNewResp);
										
										if($sPumpType == 'Intellicom12')
										{
											$sNewResp12 = replace_return($sPowercenter, $sStatus, $sRelayNumber );
											onoff_rlb_powercenter($sNewResp12);
										}
										if($sPumpType == 'Intellicom24')
										{
											$sNewResp24 = replace_return($sRelays, $sStatus, $sRelayNumber );
											onoff_rlb_relay($sNewResp24);
											$this->home_model->updateDeviceRunTime($sRelayNumber,'R',$sStatus);
										}
										$this->home_model->updateDeviceStauts($sName,$sDevice,$sStatus);
									}
								}
							}
						}
					}
					
					$aResponse['code']      = 1;
					$aResponse['status']    = $this->aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
					$aResponse['data']      = $iMode;
					// Return Response to browser. This will exit the script.
					$this->webResponse($sformat, $aResponse);
				}
				else
				{
					//If mode is manual then add the manual start time and end time calculated using the manual time(in minute) added on settings page.
					if($iMode == 2)
					{
						$sManualTime	=	$this->home_model->getManualModeTime();
						
						if($iTime != '')
						{
							if($sManualTime != $iTime)
							{
								$sProgramAbsStart =   date("H:i:s", time());
								$aStartTime       =   explode(":",$sProgramAbsStart);
								$sProgramAbsEnd   =   mktime(($aStartTime[0]),($aStartTime[1]+$iTime),($aStartTime[2]),date('m'),date('d'),date('Y'));
								$sAbsoluteEnd     =   date("Y-m-d H:i:s", $sProgramAbsEnd);
								$this->home_model->updateManualModeTimer($sProgramAbsStart,$sAbsoluteEnd);
								
								//Update the new time in database.
								$this->home_model->updateManualModeTime($iTime);
								
								$aResponse['code']      = 1;
								$aResponse['status']    = $this->aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
								$aResponse['data']      = $iMode;
								// Return Response to browser. This will exit the script.
								$this->webResponse($sformat, $aResponse);
							}
							else							
							{
								$aResponse['code']      = 1;
								$aResponse['status']    = $this->aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
								$aResponse['data']      = 'Mode already activated!';
								// Return Response to browser. This will exit the script.
								$this->webResponse($sformat, $aResponse);
							}
						}
					}
					else
					{
						$aResponse['code']      = 1;
						$aResponse['status']    = $this->aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
						$aResponse['data']      = 'Mode already activated!';
						// Return Response to browser. This will exit the script.
						$this->webResponse($sformat, $aResponse);
					}
				}
            }
            else
            {
                $aResponse['code']      = 5;
                $aResponse['status']    = $this->aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
                $aResponse['data']      = 'Please enter Valid mode.';
                // Return Response to browser. This will exit the script.
                $this->webResponse($sformat, $aResponse);
            }
         } //END : Function to get the active mode for web service.
        
		/**
		* Function to Save the Program for the Device on IP/Board.
		* @param
		* @return : Validation message or Last Insert ID of the Program.
		**/	
        public function saveProgramWeb()
		{
			// Set default HTTP response of 'ok'
            $aResponse              =   array();
            $aResponse['code']      =   0;
            $aResponse['status']    =   404;
            $aResponse['data']      =   NULL;
            $sformat                =   isset($_GET['format']) ? $_GET['format'] : '' ; // Get response Format (json,xml,html etc.)
            $sAuth                  =   isset($_GET['auth']) ? $_GET['auth'] : '' ;// Check if Authentication is required.
            $this->isAuthenticationRequired =   $sAuth;
            
            // Optionally require connections to be made via HTTPS
            if( $this->isHTTPSRequired && $_SERVER['HTTPS'] != 'on' )
            {
                $aResponse['code']      = 2;
                $aResponse['status']    = $aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
                $aResponse['data']      = $aApiResponseCode[ $aResponse['code'] ]['Message'];

                // Return Response to browser. This will exit the script.
                $this->webResponse($sformat, $aResponse);
            }
            
            if($this->isAuthenticationRequired)
            {
                //START : Authorisation
                $sUsername       = isset($_GET['username']) ? $_GET['username'] : '' ;   // Get the username of webservice 
                $sPassword       = isset($_GET['password']) ? $_GET['password'] : '' ;   // Get the password of webservice 
                $this->webAuthorisation($sUsername, $sPassword,$sformat); // Check if username and password is valid.
                // END : Authorisation
            }
             
            $aResult            = array();
            $aResult['msg']     = "";
            $aResult['response']= 0;
            $aResult['status']  = 0;
                       
            $this->load->model('home_model');
			
			$ipID			 = isset($_GET['ip']) ? $_GET['ip'] : '' ; // IP ID
			if($ipID == '')
			{
				$aResponse['code']      = 5;
				$aResponse['status']    = $this->aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
				$aResponse['data']      = 'Please Enter Valid IP.';

				// Return Response to browser. This will exit the script.
				$this->webResponse($sformat, $aResponse);
			}
						
			$sProgramName 		= trim($_GET['sProgramName']);
			$sRelayNumber 		= trim($_GET['sRelayNumber']);
			$sProgramType 		= trim($_GET['sProgramType']);
			if($sProgramType == 2)
			$sProgramDays 		= explode(",",trim($_GET['sProgramDays']));
			else
			$sProgramDays 		= 0;	
		
			$sStartTime 		= trim($_GET['sStartTime']);
			$sEndTime		 	= trim($_GET['sEndTime']);
			$isAbsoluteProgram 	= trim($_GET['isAbsoluteProgram']);
			$sType				= trim($_GET['type']);
			
			
			$sErrorMsg			=	'';
			
			if($sProgramName == '')
			{
				$sErrorMsg			.=	'Please enter Program Name.<br />';
			}
			if($sRelayNumber == '')
			{
				$sErrorMsg			.=	'Please enter Device Number.<br />';
			}
			if($sProgramType == '')
			{
				$sErrorMsg			.=	'Please select Program Type.<br />';
			}
			if($sProgramType == '2')
			{
				if(empty($sProgramDays))
				{
					$sErrorMsg			.=	'Please select Program Days.<br />';
				}
			}
			if($sStartTime == '')
			{
				$sErrorMsg			.=	'Please select Program Start Time.<br />';
			}
			if($sEndTime == '')
			{
				$sErrorMsg			.=	'Please select Program End Time.<br />';
			}
			if($isAbsoluteProgram == '')
			{
				$sErrorMsg			.=	'Please select Program Absolute.<br />';
			}
			if($sType == '')
			{
				$sErrorMsg			.=	'Please enter Program Device Type.<br />';
			}
			else if($sType != 'R' && $sType != 'PS')
			{
				$sErrorMsg			.=	'Please enter Valid Program Device Type.<br />';
			}
			
			if($sErrorMsg != '')
			{
				$aResponse['code']      = 5;
				$aResponse['status']    = $this->aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
				$aResponse['data']      = $sErrorMsg;

				$this->webResponse($sformat, $aResponse);
				exit;
			}
			
			$startTime		=  $sStartTime.':00';	
			$endTime		=  $sEndTime.':00';		
			
			
			//START : CHECK if program time is already assined to another program.
				$sProgramDetails	=	$this->home_model->getProgramDetailsForDevice($sRelayNumber,$sType,$ipID);
				$alreadyExists		=	0;
				if(is_array($sProgramDetails) && !empty($sProgramDetails))
				{
					$cntDevicePrograms  = count($sProgramDetails);
					$aAllDays           = array( 1 => 'Monday', 2 => 'Tuesday', 3 => 'Wednesday', 4 => 'Thursday', 5 => 'Friday', 6 => 'Saturday', 7 => 'Sunday');
					foreach($sProgramDetails as $aResult)
					{
						if($sProgramType == '1')
						{
							if($startTime >= $aResult->start_time && $startTime <= $aResult->end_time)
							{
								$alreadyExists = 1;
								break;
							}
							else if($endTime >= $aResult->start_time && $endTime <= $aResult->end_time)
							{
								$alreadyExists = 1;
								break;
							}
							else if($startTime < $aResult->start_time && $endTime > $aResult->end_time)
							{
								$alreadyExists = 1;
								break;
							}
						}
						else if($sProgramType == '2')
						{
							$checkDaysExists	=	0;
							$existDays = explode(',',$aResult->program_days);
							if(!empty($sProgramDays))
							{
								foreach($sProgramDays as $days)
								{
									if(in_array($days,$existDays))
									{
										$checkDaysExists = 1;
										break;
									}
								}
								
								if($checkDaysExists == 1)
								{
									if($startTime >= $aResult->start_time && $startTime <= $aResult->end_time)
									{
										$alreadyExists = 1;
										break;
									}
									else if($endTime >= $aResult->start_time && $endTime <= $aResult->end_time)
									{
										$alreadyExists = 1;
										break;
									}
									else if($startTime < $aResult->start_time && $endTime > $aResult->end_time)
									{
										$alreadyExists = 1;
										break;
									}
								}
							}
							
						}
					}
				}
			//END : CHECK if program time is already assined to another program.
			if($alreadyExists == '1')
			{
				$aResponse['code']      = 5;
				$aResponse['status']    = $this->aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
				$aResponse['data']      = 'Selected Time is already assigned to other program!';

				$this->webResponse($sformat, $aResponse);
			}
			else
			{
				$aPost				= array('sProgramName'=>$sProgramName,
											'sProgramType'=>$sProgramType,
											'sProgramDays'=>$sProgramDays,
											'sStartTime'=>$sStartTime,
											'sEndTime'=>$sEndTime,
											'isAbsoluteProgram'=>$isAbsoluteProgram);
				
				$id =	$this->home_model->saveProgramDetails($aPost,$sRelayNumber,$sType,$ipID);
				
				$aResponse['code']      = 1;
                $aResponse['status']    = $this->aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
                $aResponse['data']      = $id;
                // Return Response to browser. This will exit the script.
                $this->webResponse($sformat, $aResponse);
			}
            
		}
		
		/**
		* Function to Get the All Program Details for Device(Relay/Pump) from IP/Board.
		* @param
		* @return : Validation message or Details of all programs for the Device.
		**/
		function getAllProgramDetails()
		{
			// Set default HTTP response of 'ok'
            $aResponse              =   array();
            $aResponse['code']      =   0;
            $aResponse['status']    =   404;
            $aResponse['data']      =   NULL;
            $sformat                =   isset($_GET['format']) ? $_GET['format'] : '' ; // Get response Format (json,xml,html etc.)
            $sAuth                  =   isset($_GET['auth']) ? $_GET['auth'] : '' ;// Check if Authentication is required.
            $this->isAuthenticationRequired =   $sAuth;
            
            // Optionally require connections to be made via HTTPS
            if( $this->isHTTPSRequired && $_SERVER['HTTPS'] != 'on' )
            {
                $aResponse['code']      = 2;
                $aResponse['status']    = $aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
                $aResponse['data']      = $aApiResponseCode[ $aResponse['code'] ]['Message'];

                // Return Response to browser. This will exit the script.
                $this->webResponse($sformat, $aResponse);
            }
            
			$sRelayNumber 		= trim($_GET['sRelayNumber']);
			$sType				= trim($_GET['type']);
			
			if($this->isAuthenticationRequired)
            {
                //START : Authorisation
                $sUsername       = isset($_GET['username']) ? $_GET['username'] : '' ;   // Get the username of webservice 
                $sPassword       = isset($_GET['password']) ? $_GET['password'] : '' ;   // Get the password of webservice 
                $this->webAuthorisation($sUsername, $sPassword,$sformat); // Check if username and password is valid.
                // END : Authorisation
            }
			
			$ipID			 = isset($_GET['ip']) ? $_GET['ip'] : '' ; // IP ID
			if($ipID == '')
			{
				$aResponse['code']      = 5;
				$aResponse['status']    = $this->aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
				$aResponse['data']      = 'Please Enter Valid IP.';

				// Return Response to browser. This will exit the script.
				$this->webResponse($sformat, $aResponse);
			}
			
			if($sRelayNumber == '')
			{
				$aResponse['code']      = 5;
				$aResponse['status']    = $this->aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
				$aResponse['data']      = 'Please enter valid Device number!';

				$this->webResponse($sformat, $aResponse);
			}
			if($sType == '')
			{
				$aResponse['code']      = 5;
				$aResponse['status']    = $this->aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
				$aResponse['data']      = 'Please enter valid Program type!';

				$this->webResponse($sformat, $aResponse);
			}
			else if($sType != 'R' && $sType != 'PS')
			{
				$aResponse['code']      = 5;
				$aResponse['status']    = $this->aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
				$aResponse['data']      = 'Please enter valid Program type!';

				$this->webResponse($sformat, $aResponse);
			}
             
            $aResult            = array();
            $aResult['msg']     = "";
            $aResult['response']= 0;
            $aResult['status']  = 0;
                       
            $this->load->model('home_model');
			
			$sDetails = $this->home_model->getProgramDetailsForDevice($sRelayNumber,$sType,$ipID);
			
			if(!empty($sDetails))
			{
				$aResponse['code']      = 1;
				$aResponse['status']    = $this->aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
				$aResponse['data']      = json_encode($sDetails);
				// Return Response to browser. This will exit the script.
				$this->webResponse($sformat, $aResponse);		
			}
			else
			{
				$aResponse['code']      = 5;
				$aResponse['status']    = $this->aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
				$aResponse['data']      = 'No Program Available!';

				$this->webResponse($sformat, $aResponse);
			}
			
		}
		
		/**
		* Function to update Program Details for Device(Relay/Pump) from IP/Board.
		* @param
		* @return : Validation message or Message of success.
		**/
		function updateProgramDetails()
		{
			// Set default HTTP response of 'ok'
            $aResponse              =   array();
            $aResponse['code']      =   0;
            $aResponse['status']    =   404;
            $aResponse['data']      =   NULL;
            $sformat                =   isset($_GET['format']) ? $_GET['format'] : '' ; // Get response Format (json,xml,html etc.)
            $sAuth                  =   isset($_GET['auth']) ? $_GET['auth'] : '' ;// Check if Authentication is required.
            $this->isAuthenticationRequired =   $sAuth;
            
            // Optionally require connections to be made via HTTPS
            if( $this->isHTTPSRequired && $_SERVER['HTTPS'] != 'on' )
            {
                $aResponse['code']      = 2;
                $aResponse['status']    = $aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
                $aResponse['data']      = $aApiResponseCode[ $aResponse['code'] ]['Message'];

                // Return Response to browser. This will exit the script.
                $this->webResponse($sformat, $aResponse);
            }
            
			if($this->isAuthenticationRequired)
            {
                //START : Authorisation
                $sUsername       = isset($_GET['username']) ? $_GET['username'] : '' ;   // Get the username of webservice 
                $sPassword       = isset($_GET['password']) ? $_GET['password'] : '' ;   // Get the password of webservice 
                $this->webAuthorisation($sUsername, $sPassword,$sformat); // Check if username and password is valid.
                // END : Authorisation
            }
			
			$ipID			 = isset($_GET['ip']) ? $_GET['ip'] : '' ; // IP ID
			if($ipID == '')
			{
				$aResponse['code']      = 5;
				$aResponse['status']    = $this->aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
				$aResponse['data']      = 'Please Enter Valid IP.';

				// Return Response to browser. This will exit the script.
				$this->webResponse($sformat, $aResponse);
			}
			
			$aResult            = array();
            $aResult['msg']     = "";
            $aResult['response']= 0;
            $aResult['status']  = 0;
			
			$sProgramID 		= trim($_GET['sProgramID']);
			$sProgramName 		= trim($_GET['sProgramName']);
			$sRelayNumber 		= trim($_GET['sRelayNumber']);
			$sProgramType 		= trim($_GET['sProgramType']);
			if($sProgramType == 2)
			$sProgramDays 		= explode(",",trim($_GET['sProgramDays']));
			else
			$sProgramDays 		= 0;	
		
			$sStartTime 		= trim($_GET['sStartTime']);
			$sEndTime		 	= trim($_GET['sEndTime']);
			$isAbsoluteProgram 	= trim($_GET['isAbsoluteProgram']);
			$sType				= trim($_GET['type']);
						
			$sErrorMsg			=	'';
			
			if($sProgramID == '')
			{
				$sErrorMsg			.=	'Please enter Program ID.<br />';
			}
			if($sProgramName == '')
			{
				$sErrorMsg			.=	'Please enter Program Name.<br />';
			}
			if($sRelayNumber == '')
			{
				$sErrorMsg			.=	'Please enter Device Number.<br />';
			}
			if($sProgramType == '')
			{
				$sErrorMsg			.=	'Please select Program Type.<br />';
			}
			if($sProgramType == '2')
			{
				if(empty($sProgramDays))
				{
					$sErrorMsg			.=	'Please select Program Days.<br />';
				}
			}
			if($sStartTime == '')
			{
				$sErrorMsg			.=	'Please select Program Start Time.<br />';
			}
			if($sEndTime == '')
			{
				$sErrorMsg			.=	'Please select Program End Time.<br />';
			}
			if($isAbsoluteProgram == '')
			{
				$sErrorMsg			.=	'Please select Program Absolute.<br />';
			}
			if($sType == '')
			{
				$sErrorMsg			.=	'Please enter Program Device Type.<br />';
			}
			else if($sType != 'R' && $sType != 'PS')
			{
				$sErrorMsg			.=	'Please enter Valid Program Device Type.<br />';
			}
			
			if($sErrorMsg != '')
			{
				$aResponse['code']      = 5;
				$aResponse['status']    = $this->aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
				$aResponse['data']      = $sErrorMsg;

				$this->webResponse($sformat, $aResponse);
				exit;
			}
			
			$startTime		=  $sStartTime.':00';	
			$endTime		=  $sEndTime.':00';
			
			//START : CHECK if program time is already assined to another program.
				$sProgramDetails	=	$this->home_model->getProgramDetailsForDevice($sRelayNumber,$sType,$ipID);
				$alreadyExists		=	0;
				if(is_array($sProgramDetails) && !empty($sProgramDetails))
				{
					$cntDevicePrograms  = count($sProgramDetails);
					$aAllDays           = array( 1 => 'Monday', 2 => 'Tuesday', 3 => 'Wednesday', 4 => 'Thursday', 5 => 'Friday', 6 => 'Saturday', 7 => 'Sunday');
					foreach($sProgramDetails as $aResult)
					{
						if($sProgramType == '1')
						{
							if($startTime >= $aResult->start_time && $startTime <= $aResult->end_time)
							{
								$alreadyExists = 1;
								break;
							}
							else if($endTime >= $aResult->start_time && $endTime <= $aResult->end_time)
							{
								$alreadyExists = 1;
								break;
							}
							else if($startTime < $aResult->start_time && $endTime > $aResult->end_time)
							{
								$alreadyExists = 1;
								break;
							}
						}
						else if($sProgramType == '2')
						{
							$checkDaysExists	=	0;
							$existDays = explode(',',$aResult->program_days);
							if(!empty($sProgramDays))
							{
								foreach($sProgramDays as $days)
								{
									if(in_array($days,$existDays))
									{
										$checkDaysExists = 1;
										break;
									}
								}
								
								if($checkDaysExists == 1)
								{
									if($startTime >= $aResult->start_time && $startTime <= $aResult->end_time)
									{
										$alreadyExists = 1;
										break;
									}
									else if($endTime >= $aResult->start_time && $endTime <= $aResult->end_time)
									{
										$alreadyExists = 1;
										break;
									}
									else if($startTime < $aResult->start_time && $endTime > $aResult->end_time)
									{
										$alreadyExists = 1;
										break;
									}
								}
							}
							
						}
					}
				}
			//END : CHECK if program time is already assined to another program.
			if($alreadyExists == '1')
			{
				$aResponse['code']      = 5;
				$aResponse['status']    = $this->aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
				$aResponse['data']      = 'Selected Time is already assigned to other program!';

				$this->webResponse($sformat, $aResponse);
			}
			else
			{
				$aPost				= array('sProgramName'=>$sProgramName,
											'sProgramType'=>$sProgramType,
											'sProgramDays'=>$sProgramDays,
											'sStartTime'=>$sStartTime,
											'sEndTime'=>$sEndTime,
											'isAbsoluteProgram'=>$isAbsoluteProgram);
				
				$this->home_model->updateProgramDetails($aPost,$sProgramID,$sRelayNumber,$sType);
				
				$aResponse['code']      = 1;
                $aResponse['status']    = $this->aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
                $aResponse['data']      = 'Program Details Updated Succesfully!';
                // Return Response to browser. This will exit the script.
                $this->webResponse($sformat, $aResponse);
			}
		}
		
		/**
		* Function to Delete Program Details for Device(Relay/Pump) from IP/Board.
		* @param
		* @return : Validation message or Message of success.
		**/
		function deleteProgram()
		{
			// Set default HTTP response of 'ok'
            $aResponse              =   array();
            $aResponse['code']      =   0;
            $aResponse['status']    =   404;
            $aResponse['data']      =   NULL;
            $sformat                =   isset($_GET['format']) ? $_GET['format'] : '' ; // Get response Format (json,xml,html etc.)
            $sAuth                  =   isset($_GET['auth']) ? $_GET['auth'] : '' ;// Check if Authentication is required.
            $this->isAuthenticationRequired =   $sAuth;
            
            // Optionally require connections to be made via HTTPS
            if( $this->isHTTPSRequired && $_SERVER['HTTPS'] != 'on' )
            {
                $aResponse['code']      = 2;
                $aResponse['status']    = $aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
                $aResponse['data']      = $aApiResponseCode[ $aResponse['code'] ]['Message'];

                // Return Response to browser. This will exit the script.
                $this->webResponse($sformat, $aResponse);
            }
            
			$sProgramID 		= trim($_GET['sProgramID']);
			
			if($this->isAuthenticationRequired)
            {
                //START : Authorisation
                $sUsername       = isset($_GET['username']) ? $_GET['username'] : '' ;   // Get the username of webservice 
                $sPassword       = isset($_GET['password']) ? $_GET['password'] : '' ;   // Get the password of webservice 
                $this->webAuthorisation($sUsername, $sPassword,$sformat); // Check if username and password is valid.
                // END : Authorisation
            }
			$ipID			 = isset($_GET['ip']) ? $_GET['ip'] : '' ; // IP ID
			if($ipID == '')
			{
				$aResponse['code']      = 5;
				$aResponse['status']    = $this->aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
				$aResponse['data']      = 'Please Enter Valid IP.';

				// Return Response to browser. This will exit the script.
				$this->webResponse($sformat, $aResponse);
			}
			
			if($sProgramID == '')
			{
				$aResponse['code']      = 5;
				$aResponse['status']    = $this->aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
				$aResponse['data']      = 'Please enter valid Program ID!';

				$this->webResponse($sformat, $aResponse);
			}
		 
            $aResult            = array();
            $aResult['msg']     = "";
            $aResult['response']= 0;
            $aResult['status']  = 0;
                       
            $this->load->model('home_model');
			
			$sDetails = $this->home_model->deleteProgramDetails($sProgramID);
			
			$aResponse['code']      = 1;
			$aResponse['status']    = $this->aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
			$aResponse['data']      = "Program Deleted Succesfully!";
			// Return Response to browser. This will exit the script.
			$this->webResponse($sformat, $aResponse);		
			
		}
		
		/**
		* Function to Get Program Details for Device(Relay/Pump) using Program ID from IP/Board.
		* @param
		* @return : Validation message or Program Details.
		**/
		function getParticularProgramDetails()
		{
			// Set default HTTP response of 'ok'
            $aResponse              =   array();
            $aResponse['code']      =   0;
            $aResponse['status']    =   404;
            $aResponse['data']      =   NULL;
            $sformat                =   isset($_GET['format']) ? $_GET['format'] : '' ; // Get response Format (json,xml,html etc.)
            $sAuth                  =   isset($_GET['auth']) ? $_GET['auth'] : '' ;// Check if Authentication is required.
            $this->isAuthenticationRequired =   $sAuth;
            
            // Optionally require connections to be made via HTTPS
            if( $this->isHTTPSRequired && $_SERVER['HTTPS'] != 'on' )
            {
                $aResponse['code']      = 2;
                $aResponse['status']    = $aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
                $aResponse['data']      = $aApiResponseCode[ $aResponse['code'] ]['Message'];

                // Return Response to browser. This will exit the script.
                $this->webResponse($sformat, $aResponse);
            }
            
			$sProgramID 		= trim($_GET['sProgramID']);
			
			if($this->isAuthenticationRequired)
            {
                //START : Authorisation
                $sUsername       = isset($_GET['username']) ? $_GET['username'] : '' ;   // Get the username of webservice 
                $sPassword       = isset($_GET['password']) ? $_GET['password'] : '' ;   // Get the password of webservice 
                $this->webAuthorisation($sUsername, $sPassword,$sformat); // Check if username and password is valid.
                // END : Authorisation
            }
			
			$ipID			 = isset($_GET['ip']) ? $_GET['ip'] : '' ; // IP ID
			if($ipID == '')
			{
				$aResponse['code']      = 5;
				$aResponse['status']    = $this->aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
				$aResponse['data']      = 'Please Enter Valid IP.';

				// Return Response to browser. This will exit the script.
				$this->webResponse($sformat, $aResponse);
			}
			
			if($sProgramID == '')
			{
				$aResponse['code']      = 5;
				$aResponse['status']    = $this->aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
				$aResponse['data']      = 'Please enter valid Program ID!';

				$this->webResponse($sformat, $aResponse);
			}
		 
            $aResult            = array();
            $aResult['msg']     = "";
            $aResult['response']= 0;
            $aResult['status']  = 0;
                       
            $this->load->model('home_model');
			
			$sDetails = $this->home_model->getProgramDetails($sProgramID);
			
			if(!empty($sDetails))
			{
				$aResponse['code']      = 1;
				$aResponse['status']    = $this->aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
				$aResponse['data']      = "Program Deleted Succesfully!";
				// Return Response to browser. This will exit the script.
				$this->webResponse($sformat, $aResponse);		
			}
			else
			{
				$aResponse['code']      = 5;
				$aResponse['status']    = $this->aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
				$aResponse['data']      = 'Details Not available for the Program!';

				$this->webResponse($sformat, $aResponse);
			}
		}
		
		/**
		* Function to Assign Relays to Valve.
		* @param
		* @return : Validation message or Success Message.
		**/
		public function assignRelaysToValve()
		{
			// Set default HTTP response of 'ok'
            $aResponse              =   array();
            $aResponse['code']      =   0;
            $aResponse['status']    =   404;
            $aResponse['data']      =   NULL;
            $sformat                =   isset($_GET['format']) ? $_GET['format'] : '' ; // Get response Format (json,xml,html etc.)
            $sAuth                  =   isset($_GET['auth']) ? $_GET['auth'] : '' ;// Check if Authentication is required.
            $this->isAuthenticationRequired =   $sAuth;
            
            // Optionally require connections to be made via HTTPS
            if( $this->isHTTPSRequired && $_SERVER['HTTPS'] != 'on' )
            {
                $aResponse['code']      = 2;
                $aResponse['status']    = $aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
                $aResponse['data']      = $aApiResponseCode[ $aResponse['code'] ]['Message'];

                // Return Response to browser. This will exit the script.
                $this->webResponse($sformat, $aResponse);
            }
            if($this->isAuthenticationRequired)
            {
                //START : Authorisation
                $sUsername       = isset($_GET['username']) ? $_GET['username'] : '' ;   // Get the username of webservice 
                $sPassword       = isset($_GET['password']) ? $_GET['password'] : '' ;   // Get the password of webservice 
                $this->webAuthorisation($sUsername, $sPassword,$sformat); // Check if username and password is valid.
                // END : Authorisation
            }
			
			$sRelay1 		= trim($_GET['rl1']);
			$sRelay2 		= trim($_GET['rl2']);
			$sDeviceID		= trim($_GET['nv']);
			$sDeviceIDOld	= trim($_GET['ov']);			
			
			if($sRelay1 == '')
			{
				$aResponse['code']      = 5;
				$aResponse['status']    = $this->aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
				$aResponse['data']      = 'Please enter valid Relay1!';

				$this->webResponse($sformat, $aResponse);
			}
			if($sRelay2 == '')
			{
				$aResponse['code']      = 5;
				$aResponse['status']    = $this->aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
				$aResponse['data']      = 'Please enter valid Relay2!';

				$this->webResponse($sformat, $aResponse);
			}
			
			$arrStartRelays	=	array(0,2,4,6,8,10,12,14);
			$arrEndRelays	=	array(1,3,5,7,9,11,13,15);
			
			if(!in_array($sRelay1,$arrStartRelays))
			{
				$aResponse['code']      = 5;
				$aResponse['status']    = $this->aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
				$aResponse['data']      = 'Relay1 is not valid relay sequence number!';

				$this->webResponse($sformat, $aResponse);
			}
			if(!in_array($sRelay2,$arrEndRelays))
			{
				$aResponse['code']      = 5;
				$aResponse['status']    = $this->aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
				$aResponse['data']      = 'Relay2 is not valid relay sequence number!';

				$this->webResponse($sformat, $aResponse);
			}
			
			$key = array_search($sRelay1, $arrStartRelays);
			
			if($sRelay2 != $arrEndRelays[$key])
			{
				$aResponse['code']      = 5;
				$aResponse['status']    = $this->aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
				$aResponse['data']      = 'Please enter the relays in sequence!';

				$this->webResponse($sformat, $aResponse);
			}
			
            $aResult            = array();
            $aResult['msg']     = "";
            $aResult['response']= 0;
            $aResult['status']  = 0;
                       
            $this->load->model('home_model');
			
			$ipID			 = isset($_GET['ip']) ? $_GET['ip'] : '' ; // IP ID
			if($ipID == '')
			{
				$aResponse['code']      = 5;
				$aResponse['status']    = $this->aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
				$aResponse['data']      = 'Please Enter Valid IP.';

				// Return Response to browser. This will exit the script.
				$this->webResponse($sformat, $aResponse);
			}
			//GET IP of Device
			$sDeviceIP		= 	$this->home_model->getBoardIPFromID($ipID);

			//Get SSH port when working on LOCAL.
			$shhPort	=	'';
			if(IS_LOCAL == '1')
			{
				//Get SSH port of the RLB board using IP.
				$shhPort = $this->home_model->getSSHPortFromID($ipID);
			}
			
			//Get the number of Devices(Blower,Light and Heater) from the settings.
			list($sIP,$sPort,$sExtra) = $this->home_model->getSettings();
			
			$this->home_model->saveValveRelays($sDeviceID,$sDeviceIDOld,$sDevice,$sRelay1,$sRelay2,$ipID);
			
			$arrValves	=	$this->home_model->getAllValvesHavingRelays($ipID);
			$strValves	=	'00000000';
			if(!empty($arrValves))
			{
				foreach($arrValves as $aValve)
				{
					$device_number = $aValve->device_number;
					$strValves[$device_number] = '1';
				}
			}
			
			$hexNumber = dechex(bindec(strrev($strValves)));
			
			$response	=	assignValvesToRelay($hexNumber,$sDeviceIP,$sPort,$shhPort)	;
			
			$aResponse['code']      = 1;
			$aResponse['status']    = $this->aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
			$aResponse['data']      = 'Relays assigned Succesfully!';

			$this->webResponse($sformat, $aResponse);
			
		}
		
		/**
		* Function to Stop pump if ON and Remove Pump Details.
		* @param
		* @return : Validation message or Success Message.
		**/
		public function removePumpDetails()
        {
			// Set default HTTP response of 'ok'
            $aResponse              =   array();
            $aResponse['code']      =   0;
            $aResponse['status']    =   404;
            $aResponse['data']      =   NULL;
            $sformat                =   isset($_GET['format']) ? $_GET['format'] : '' ; // Get response Format (json,xml,html etc.)
            $sAuth                  =   isset($_GET['auth']) ? $_GET['auth'] : '' ;// Check if Authentication is required.
            $this->isAuthenticationRequired =   $sAuth;
            
            // Optionally require connections to be made via HTTPS
            if( $this->isHTTPSRequired && $_SERVER['HTTPS'] != 'on' )
            {
                $aResponse['code']      = 2;
                $aResponse['status']    = $aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
                $aResponse['data']      = $aApiResponseCode[ $aResponse['code'] ]['Message'];

                // Return Response to browser. This will exit the script.
                $this->webResponse($sformat, $aResponse);
            }
            if($this->isAuthenticationRequired)
            {
                //START : Authorisation
                $sUsername       = isset($_GET['username']) ? $_GET['username'] : '' ;   // Get the username of webservice 
                $sPassword       = isset($_GET['password']) ? $_GET['password'] : '' ;   // Get the password of webservice 
                $this->webAuthorisation($sUsername, $sPassword,$sformat); // Check if username and password is valid.
                // END : Authorisation
            }
			
			$iPumpNumber	= trim($_GET['pn']);
			
			if($iPumpNumber == '')
			{
				$aResponse['code']      = 5;
				$aResponse['status']    = $this->aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
				$aResponse['data']      = 'Please enter valid Pump Number!';

				$this->webResponse($sformat, $aResponse);
			}
			if($iPumpNumber > 2)
			{
				$aResponse['code']      = 5;
				$aResponse['status']    = $this->aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
				$aResponse['data']      = 'Please enter pump number less than 3!';

				$this->webResponse($sformat, $aResponse);
			}
			
			if($iPumpNumber != '')
			{
				$this->load->model('home_model');
				
				$ipID			 = isset($_GET['ip']) ? $_GET['ip'] : '' ; // IP ID
				if($ipID == '')
				{
					$aResponse['code']      = 5;
					$aResponse['status']    = $this->aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
					$aResponse['data']      = 'Please Enter Valid IP.';

					// Return Response to browser. This will exit the script.
					$this->webResponse($sformat, $aResponse);
				}
				//GET IP of Device
				$sDeviceIP		= 	$this->home_model->getBoardIPFromID($ipID);

				//Get SSH port when working on LOCAL.
				$shhPort	=	'';
				if(IS_LOCAL == '1')
				{
					//Get SSH port of the RLB board using IP.
					$shhPort = $this->home_model->getSSHPortFromID($ipID);
				}

				//Get the number of Devices(Blower,Light and Heater) from the settings.
				list($sIP,$sPort,$sExtra) = $this->home_model->getSettings();
				
				$sResponse      =   get_rlb_status($sDeviceIP,$sPort,$shhPort); // Get the relay borad response from server.
				$sValves        =   $sResponse['valves']; // Valve Devices.
				$sRelays        =   $sResponse['relay'];  // Relay Devices.
				$sPowercenter   =   $sResponse['powercenter']; // Power Center Devices.
				
				//Pump device Status
				$sPump          =   array($sResponse['pump_seq_0_st'],$sResponse['pump_seq_1_st'],$sResponse['pump_seq_2_st']);
				
				if($sPump[$iPumpNumber] > 0) //Currently Pump is ON, make it OFF.
				{
					$aPumpDetails = $this->home_model->getPumpDetails($i,$ipID);						
					//Variable Initialization to blank.
					$sPumpNumber  	= '';
					$sPumpType  	= '';
					$sPumpSubType  	= '';
					$sPumpSpeed  	= '';
					$sPumpFlow 		= '';
					$sPumpClosure   = '';
					$sRelayNumber  	= '';

					if(is_array($aPumpDetails) && !empty($aPumpDetails))
					{
					  foreach($aPumpDetails as $aResultEdit)
					  { 
						$sPumpNumber  = $aResultEdit->pump_number;
						$sPumpType    = $aResultEdit->pump_type;
						$sPumpSubType = $aResultEdit->pump_sub_type;
						$sPumpSpeed   = $aResultEdit->pump_speed;
						$sPumpFlow    = $aResultEdit->pump_flow;
						$sPumpClosure = $aResultEdit->pump_closure;
						$sRelayNumber = $aResultEdit->relay_number;
					  }
					}
					
					$iPumpStatus = 0;
						
					if($sPumpType != '')
					{
						if($sPumpType == '12' || $sPumpType == '24')
						{
							if($sPumpType == '24')
							{
								$sNewResp = replace_return($sRelays, $iPumpStatus, $sRelayNumber );
								onoff_rlb_relay($sNewResp,$sDeviceIP,$sPort,$shhPort);
							}
							else if($sPumpType == '12')
							{
								$sNewResp = replace_return($sPowercenter, $iPumpStatus, $sRelayNumber );
								onoff_rlb_powercenter($sNewResp,$sDeviceIP,$sPort,$shhPort);
							}
						}
						else
						{
							if(preg_match('/Emulator/',$sPumpType))
							{
								$sNewResp = '';
								$sNewResp =  $sRelayName.' '.$iPumpStatus;
								onoff_rlb_pump($sNewResp,$sDeviceIP,$sPort,$shhPort);
								
								if($sPumpType == 'Emulator12')
								{
									$sNewResp12 = replace_return($sPowercenter, $iPumpStatus, $sRelayNumber );
									onoff_rlb_powercenter($sNewResp12,$sDeviceIP,$sPort,$shhPort);
								}
								if($sPumpType == 'Emulator24')
								{
									$sNewResp24 = replace_return($sRelays, $iPumpStatus, $sRelayNumber );
									onoff_rlb_relay($sNewResp24,$sDeviceIP,$sPort,$shhPort);
								}
							}
							else if(preg_match('/Intellicom/',$sPumpType))
							{
								$sNewResp = '';
								$sNewResp =  $sRelayName.' '.$iPumpStatus;
								onoff_rlb_pump($sNewResp,$sDeviceIP,$sPort,$shhPort);
								
								if($sPumpType == 'Intellicom12')
								{
									$sNewResp12 = replace_return($sPowercenter, $iPumpStatus, $sRelayNumber );
									onoff_rlb_powercenter($sNewResp12,$sDeviceIP,$sPort,$shhPort);
								}
								if($sPumpType == 'Intellicom24')
								{
									$sNewResp24 = replace_return($sRelays, $iPumpStatus, $sRelayNumber );
									onoff_rlb_relay($sNewResp24,$sDeviceIP,$sPort,$shhPort);
								}
							}
						}
					}
				}
			}
			
			//Remove Pump Details From database.
			$this->home_model->removePump($iPumpNumber,$ipID);
			
			//Remove the address associated with the pump on the relay board.
			$Pump	=	'pm'.$iPumpNumber;
			removePumpAddress($Pump,$sDeviceIP,$sPort,$shhPort);
			
			
			$aResponse['code']      = 1;
			$aResponse['status']    = $this->aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
			$aResponse['data']      = "Pump removed Succesfully!";
			// Return Response to browser. This will exit the script.
			$this->webResponse($sformat, $aResponse);

			exit;	
			
		}
		
		/**
		* Function to Send the Local IP details.
		* @param
		* @return : Validation message or IP Details.
		**/
		public function sendBoardLocalIP()
        {
			
            // Set default HTTP response of 'ok'
            $aResponse              =   array();
            $aResponse['code']      =   0;
            $aResponse['status']    =   404;
            $aResponse['data']      =   NULL;
            $sformat                =   isset($_GET['format']) ? $_GET['format'] : '' ; // Get response Format (json,xml,html etc.)
            $sAuth                  =   isset($_GET['auth']) ? $_GET['auth'] : '' ;// Check if Authentication is required.
            $this->isAuthenticationRequired =   $sAuth;
			    
            // Optionally require connections to be made via HTTPS
            if( $this->isHTTPSRequired && $_SERVER['HTTPS'] != 'on' )
            {
                $aResponse['code']      = 2;
                $aResponse['status']    = $aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
                $aResponse['data']      = $aApiResponseCode[ $aResponse['code'] ]['Message'];

                // Return Response to browser. This will exit the script.
                $this->webResponse($sformat, $aResponse);
            }
            
            if($this->isAuthenticationRequired)
            {
                //START : Authorisation
                $sUsername       = isset($_GET['username']) ? $_GET['username'] : '' ;   // Get the username of webservice 
                $sPassword       = isset($_GET['password']) ? $_GET['password'] : '' ;   // Get the password of webservice 
                $this->webAuthorisation($sUsername, $sPassword,$sformat); // Check if username and password is valid.
                // END : Authorisation
            }
            
            $aResult            = array();
            $aResult['msg']     = "";
            $aResult['response']  = 0;
                     
            $this->load->model('home_model');
            $aIPDetails = $this->home_model->getBoardIP(); 

			if(!empty($aIPDetails))
			{
				$aResponse['code']      = 1;
				$aResponse['status']    = $this->aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
				$aResponse['data']      = json_encode($aIPDetails);
				
				// Return Response to browser. This will exit the script.
				$this->webResponse($sformat, $aResponse);
				exit;
			}
			else
			{
				$aResponse['code']      = 5;
				$aResponse['status']    = $this->aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
				$aResponse['data']      = 'No IP is available!';

				// Return Response to browser. This will exit the script.
				$this->webResponse($sformat, $aResponse);
				exit;
			}
				
            
        } //END : function sendBoardLocalIP()
		
		/**
		* Function to Send Device Details for IP/Board.
		* @param
		* @return : Validation message or IP Details.
		**/
		public function sendIPDeviceDetails()
        {
			// Set default HTTP response of 'ok'
            $aResponse              =   array();
            $aResponse['code']      =   0;
            $aResponse['status']    =   404;
            $aResponse['data']      =   NULL;
            $sformat                =   isset($_GET['format']) ? $_GET['format'] : '' ; // Get response Format (json,xml,html etc.)
            $sAuth                  =   isset($_GET['auth']) ? $_GET['auth'] : '' ;// Check if Authentication is required.
            $this->isAuthenticationRequired =   $sAuth;
                
            // Optionally require connections to be made via HTTPS
            if( $this->isHTTPSRequired && $_SERVER['HTTPS'] != 'on' )
            {
                $aResponse['code']      = 2;
                $aResponse['status']    = $aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
                $aResponse['data']      = $aApiResponseCode[ $aResponse['code'] ]['Message'];

                // Return Response to browser. This will exit the script.
                $this->webResponse($sformat, $aResponse);
            }
            
            if($this->isAuthenticationRequired)
            {
                //START : Authorisation
                $sUsername       = isset($_GET['username']) ? $_GET['username'] : '' ;   // Get the username of webservice 
                $sPassword       = isset($_GET['password']) ? $_GET['password'] : '' ;   // Get the password of webservice 
                $this->webAuthorisation($sUsername, $sPassword,$sformat); // Check if username and password is valid.
                // END : Authorisation
            }
            
            #INPUTS
            $iIPID         = isset($_GET['ip']) ? $_GET['ip'] : '' ; // Get the IP ID.
            $sDevice       = isset($_GET['dvc'])  ? $_GET['dvc'] : '' ;  // Get the Device Type.
			
			if($iIPID == '')
			{
				$aResponse['code']      = 5;
				$aResponse['status']    = $this->aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
				$aResponse['data']      = 'Please Enter IP ID!';
				// Return Response.
				$this->webResponse($sformat, $aResponse);
				exit;
			}
			if($sDevice == '')
			{
				$aResponse['code']      = 5;
				$aResponse['status']    = $this->aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
				$aResponse['data']      = 'Please Enter Device Type!';

				// Return Response.
				$this->webResponse($sformat, $aResponse);
				exit;
			}
			
            
            $aResult            = array();
            $aResult['msg']     = "";
            $aResult['response']  = 0;
                                
            $this->load->model('home_model');
            //GET IP of Device
			$sDeviceIP		= 	$this->home_model->getBoardIPFromID($iIPID);
			
			if($sDeviceIP == '')
			{
				$aResponse['code']      = 5;
				$aResponse['status']    = $this->aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
				$aResponse['data']      = 'Invalid IP ID!';
				// Return Response.
				$this->webResponse($sformat, $aResponse);
				exit;
			}
			
			//Get saved IP and PORT 
			list($sIP,$sPort,$extra) = $this->home_model->getSettings();
			
			$shhPort	=	'';
			if(IS_LOCAL == '1')
			{
				//Get SSH port of the RLB board using IP.
				$shhPort = $this->home_model->getSSHPortFromID($iIPID);
			}
			
			//Get the status response of devices from relay board.
			$sResponse      =   get_rlb_status($sDeviceIP,$sPort,$shhPort);
			
			$sValves        =   $sResponse['valves'];   // Valve Device Status
			$sRelays        =   $sResponse['relay'];    // Relay Device Status
			$sPowercenter   =   $sResponse['powercenter']; // Power Center Device Status
			$sPump          =   array($sResponse['pump_seq_0_st'],$sResponse['pump_seq_1_st'],$sResponse['pump_seq_2_st']);
			
			$aResponseDetails		= array();
			
			if($sDevice == 'R')
			{
				$iCount=strlen($sRelays);
				
				for($i=0; $i<$iCount; $i++)
				{
					$relay = $sRelays[$i] ;
					
					if($relay != '.' && $relay != '')
					{
						$name = $this->home_model->getDeviceName($i,$sDevice,$iIPID);
											
						if($name == '')
							$name = 'Relay '.$i;
						
						$aResponseDetails[$i] = $name;
					}
					else
					{
						$aResponseDetails[$i] = '.';
					}
				}
			}
			else if($sDevice == 'P')
			{
				$iCount=strlen($sPowercenter);
				
				for($i=0; $i<$iCount; $i++)
				{
					$name = $this->home_model->getDeviceName($i,$sDevice,$iIPID);
											
					if($name == '')
						$name = 'PowerCenter '.$i;
						
					$aResponseDetails[$i] = $name;
				}
			}
			if($sDevice == 'V')
			{
				$iCount=strlen($sValves);
				
				for($i=0; $i<$iCount; $i++)
				{
					$relay = $sValves[$i] ;
					
					if($relay != '.' && $relay != '')
					{
						$name = $this->home_model->getDeviceName($i,$sDevice,$iIPID);
						
						//START : Get Valve Position Details.
						$aPositionName   =  $this->home_model->getPositionName($i,$sDevice,$iIPID);
						
						$strPosition1 = '';
						$strPosition2 = '';
						
						if($aPositionName[0] != '')
						$strPosition1	 =	$this->home_model->getPositionNameFromID($aPositionName[0]);
						if($aPositionName[1] != '')
						$strPosition2	 =	$this->home_model->getPositionNameFromID($aPositionName[1]);
						//END : Get Valve Position Details.
											
						if($name == '')
							$name = 'Valve '.$i;
						
						$aResponseDetails[$i] = array($name,$strPosition1,$strPosition2);
					}
					else
					{
						$aResponseDetails[$i] = '.';
					}
				}
			}
			if($sDevice == 'PS')
			{
				//$iCount=count($sPump);
				if($iIPID == 1)
					$iCount=$extra['PumpsNumber'];
				else if($iIPID > 1)
					$iCount=$extra['PumpsNumber2'];	
				
				
				for($i=1; $i<=$iCount; $i++)
				{
					$name = $this->home_model->getDeviceName($i,$sDevice,$iIPID);
					
					//Check If Configuration is available or not.
					$check = $this->home_model->checkConfiguration($i,$sDevice,$iIPID);
					
					if($check == '1')
					{
						if($name == '')
							$name = 'Pump '.$i;
							
						$aResponseDetails[$i] = $name;
					}
				}
			}
			if($sDevice == 'L')
			{
				//$iCount = $extra['LightNumber'];
				if($iIPID == 1)
					$iCount=$extra['LightNumber'];
				else if($iIPID > 1)
					$iCount=$extra['LightNumber2'];
				
				for($i=0;$i<$iCount;$i++)
				{
					$name = $this->home_model->getDeviceName($i,$sDevice,$iIPID);
											
					if($name == '')
						$name = 'Light '.$i;
						
					$aResponseDetails[$i] = $name;
				}
			}
			if($sDevice == 'H')
			{
				//$iCount = $extra['HeaterNumber'];
				
				if($iIPID == 1)
					$iCount=$extra['HeaterNumber'];
				else if($iIPID > 1)
					$iCount=$extra['HeaterNumber2'];
				
				for($i=0;$i<$iCount;$i++)
				{
					$name = $this->home_model->getDeviceName($i,$sDevice,$iIPID);
											
					if($name == '')
						$name = 'Heater '.$i;
						
					$aResponseDetails[$i] = $name;
				}
			}
			if($sDevice == 'B')
			{
				//$iCount = $extra['BlowerNumber'];
				if($iIPID == 1)
					$iCount=$extra['BlowerNumber'];
				else if($iIPID > 1)
					$iCount=$extra['BlowerNumber2'];
				
				for($i=0;$i<$iCount;$i++)
				{
					$name = $this->home_model->getDeviceName($i,$sDevice,$iIPID);
											
					if($name == '')
						$name = 'Blower '.$i;
						
					$aResponseDetails[$i] = $name;
				}
			}
			if($sDevice == 'M')
			{
				//$iCount = $extra['MiscNumber'];
				
				if($iIPID == 1)
					$iCount=$extra['MiscNumber'];
				else if($iIPID > 1)
					$iCount=$extra['MiscNumber2'];
				for($i=0;$i<$iCount;$i++)
				{
					$name = $this->home_model->getDeviceName($i,$sDevice,$iIPID);
											
					if($name == '')
						$name = 'Misc '.$i;
						
					$aResponseDetails[$i] = $name;
				}
			}
			
			$aResponse['code']      = 1;
			$aResponse['status']    = $this->aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
			$aResponse['data']      = json_encode($aResponseDetails);
			
			$this->webResponse($sformat, $aResponse);
				
            
        } //END : function sendBoardLocalIP()
		
		/**
		* Function to Create Custom Program For Devices.
		* @param
		* @return : Validation message or Success Message.
		**/
		public function createCustomProgram()
		{
			// Set default HTTP response of 'ok'
            $aResponse              =   array();
            $aResponse['code']      =   0;
            $aResponse['status']    =   404;
            $aResponse['data']      =   NULL;
            $sformat                =   isset($_GET['format']) ? $_GET['format'] : '' ; // Get response Format (json,xml,html etc.)
            $sAuth                  =   isset($_GET['auth']) ? $_GET['auth'] : '' ;// Check if Authentication is required.
            $this->isAuthenticationRequired =   $sAuth;
                
            // Optionally require connections to be made via HTTPS
            if( $this->isHTTPSRequired && $_SERVER['HTTPS'] != 'on' )
            {
                $aResponse['code']      = 2;
                $aResponse['status']    = $aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
                $aResponse['data']      = $aApiResponseCode[ $aResponse['code'] ]['Message'];

                // Return Response to browser. This will exit the script.
                $this->webResponse($sformat, $aResponse);
            }
            
            if($this->isAuthenticationRequired)
            {
                //START : Authorisation
                $sUsername       = isset($_GET['username']) ? $_GET['username'] : '' ;   // Get the username of webservice 
                $sPassword       = isset($_GET['password']) ? $_GET['password'] : '' ;   // Get the password of webservice 
                $this->webAuthorisation($sUsername, $sPassword,$sformat); // Check if username and password is valid.
                // END : Authorisation
            }
			
			//Input Data
			$aData	=	json_decode(trim($_GET['input_data']));
			$g_id	= 	$aData->g_id;
			
			if(empty($aData))
			{
				$aResponse['code']      = 5;
				$aResponse['status']    = $this->aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
				$aResponse['data']      = 'Invalid input data!';
				// Return Response.
				$this->webResponse($sformat, $aResponse);
				exit;
			}
			
			if($g_id == '')
			{
				$aResponse['code']      = 5;
				$aResponse['status']    = $this->aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
				$aResponse['data']      = 'Invalid GID!';
				// Return Response.
				$this->webResponse($sformat, $aResponse);
				exit;
			}
			
			$this->load->model('home_model');
			
			$CustomProgramID = $this->home_model->saveCustomProgram($g_id,json_encode($aData));
			
			$aResponse['code']      = 1;
			$aResponse['status']    = $this->aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
			$aResponse['data']      = "Program is saved successfully for GID - ".$g_id.'|||'.$CustomProgramID;
			
			$this->webResponse($sformat, $aResponse);
		}
		
		/**
		* Function to Edit Custom Program For Devices.
		* @param
		* @return : Validation message or Success Message.
		**/
		public function editCustomProgram()
		{
			// Set default HTTP response of 'ok'
            $aResponse              =   array();
            $aResponse['code']      =   0;
            $aResponse['status']    =   404;
            $aResponse['data']      =   NULL;
            $sformat                =   isset($_GET['format']) ? $_GET['format'] : '' ; // Get response Format (json,xml,html etc.)
            $sAuth                  =   isset($_GET['auth']) ? $_GET['auth'] : '' ;// Check if Authentication is required.
            $this->isAuthenticationRequired =   $sAuth;
                
            // Optionally require connections to be made via HTTPS
            if( $this->isHTTPSRequired && $_SERVER['HTTPS'] != 'on' )
            {
                $aResponse['code']      = 2;
                $aResponse['status']    = $aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
                $aResponse['data']      = $aApiResponseCode[ $aResponse['code'] ]['Message'];

                // Return Response to browser. This will exit the script.
                $this->webResponse($sformat, $aResponse);
            }
            
            if($this->isAuthenticationRequired)
            {
                //START : Authorisation
                $sUsername       = isset($_GET['username']) ? $_GET['username'] : '' ;   // Get the username of webservice 
                $sPassword       = isset($_GET['password']) ? $_GET['password'] : '' ;   // Get the password of webservice 
                $this->webAuthorisation($sUsername, $sPassword,$sformat); // Check if username and password is valid.
                // END : Authorisation
            }
			
			//Input Data
			$ID		=	trim($_GET['id']);
			$aData	=	json_decode(trim($_GET['input_data']));
			$g_id	= 	$aData->g_id;
			
			if($ID == '')
			{
				$aResponse['code']      = 5;
				$aResponse['status']    = $this->aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
				$aResponse['data']      = 'Invalid Program ID!';
				// Return Response.
				$this->webResponse($sformat, $aResponse);
				exit;
			}
			
			if(empty($aData))
			{
				$aResponse['code']      = 5;
				$aResponse['status']    = $this->aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
				$aResponse['data']      = 'Invalid input data!';
				// Return Response.
				$this->webResponse($sformat, $aResponse);
				exit;
			}
			
			if($g_id == '')
			{
				$aResponse['code']      = 5;
				$aResponse['status']    = $this->aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
				$aResponse['data']      = 'Invalid GID!';
				// Return Response.
				$this->webResponse($sformat, $aResponse);
				exit;
			}
			
			$this->load->model('home_model');
			
			$this->home_model->editCustomProgram($ID,$g_id,json_encode($aData));
			
			$aResponse['code']      = 1;
			$aResponse['status']    = $this->aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
			$aResponse['data']      = "Program is edited successfully for GID - ".$g_id;
			
			$this->webResponse($sformat, $aResponse);
		}
		//END: Edit Custom Program For Devices.
		
		/**
		* Function to Get Custom Program Details using ID.
		* @param
		* @return : Validation message or Details of the Program.
		**/
		public function getCustomProgram()
		{
			// Set default HTTP response of 'ok'
            $aResponse              =   array();
            $aResponse['code']      =   0;
            $aResponse['status']    =   404;
            $aResponse['data']      =   NULL;
            $sformat                =   isset($_GET['format']) ? $_GET['format'] : '' ; // Get response Format (json,xml,html etc.)
            $sAuth                  =   isset($_GET['auth']) ? $_GET['auth'] : '' ;// Check if Authentication is required.
            $this->isAuthenticationRequired =   $sAuth;
                
            // Optionally require connections to be made via HTTPS
            if( $this->isHTTPSRequired && $_SERVER['HTTPS'] != 'on' )
            {
                $aResponse['code']      = 2;
                $aResponse['status']    = $aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
                $aResponse['data']      = $aApiResponseCode[ $aResponse['code'] ]['Message'];

                // Return Response to browser. This will exit the script.
                $this->webResponse($sformat, $aResponse);
            }
            
            if($this->isAuthenticationRequired)
            {
                //START : Authorisation
                $sUsername       = isset($_GET['username']) ? $_GET['username'] : '' ;   // Get the username of webservice 
                $sPassword       = isset($_GET['password']) ? $_GET['password'] : '' ;   // Get the password of webservice 
                $this->webAuthorisation($sUsername, $sPassword,$sformat); // Check if username and password is valid.
                // END : Authorisation
            }
			
			//Input Data
			$iGID	=	trim($_GET['id']);
			
			if($iGID == '')
			{
				$aResponse['code']      = 5;
				$aResponse['status']    = $this->aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
				$aResponse['data']      = 'Invalid ID!';
				// Return Response.
				$this->webResponse($sformat, $aResponse);
				exit;
			}
			
			$this->load->model('home_model');
			
			$sResult	= array();
			
			//Get Program Details.
			$sResult['program'] = $this->home_model->getCustomProgram($iGID);
			
			//Get All IP Details.
			$aViewParameter['aIPDetails'] = $this->home_model->getBoardIP();
			list($sIP,$sPort,$extra) = $this->home_model->getSettings();
			
			$sResult['board_count']	=	count($aViewParameter['aIPDetails']);
			
			foreach($aViewParameter['aIPDetails'] as $IP)
			{
				$shhPort	=	'';
				if(IS_LOCAL == '1')
				{
					//Get SSH port of the RLB board using IP.
					$shhPort = $this->home_model->getSSHPortFromID($IP->id);
				}
				$sResponse		=	array();
				$sValves        =   ''; 
				$sRelays        =   '';  
				$sPowercenter   =   ''; 
				$sPump			=	'';	
				
				//Get the status response of devices from relay board.
				$sResponse      =   get_rlb_status($IP->ip,$sPort,$shhPort);
			
				$sValves        =   $sResponse['valves'];   // Valve Device Status
				$sRelays        =   $sResponse['relay'];    // Relay Device Status
				$sPowercenter   =   $sResponse['powercenter']; // Power Center Device Status
				$sPump          =   array($sResponse['pump_seq_0_st'],$sResponse['pump_seq_1_st'],$sResponse['pump_seq_2_st']);
				
				$iIPID = $IP->id;
				
				$iCount=strlen($sRelays);
				
				for($i=0; $i<$iCount; $i++)
				{
					$relay = $sRelays[$i] ;
					
					if($relay != '.' && $relay != '')
					{
						$name = $this->home_model->getDeviceName($i,'R',$iIPID);
											
						if($name == '')
							$name = 'Relay '.$i;
						
						$sResult['Relay'.$IP->id][$i] = $name;
					}
					else
					{
						$sResult['Relay'.$IP->id][$i] = '.';
					}
				}
			
				$iCount=strlen($sPowercenter);
				
				for($i=0; $i<$iCount; $i++)
				{
					$name = $this->home_model->getDeviceName($i,'P',$iIPID);
											
					if($name == '')
						$name = 'PowerCenter '.$i;
						
					$sResult['PowerCenter'.$IP->id][$i] = $name;
				}
			
				$iCount=strlen($sValves);
				
				for($i=0; $i<$iCount; $i++)
				{
					$relay = $sValves[$i] ;
					
					if($relay != '.' && $relay != '')
					{
						$name = $this->home_model->getDeviceName($i,'V',$iIPID);
						
						//START : Get Valve Position Details.
						$aPositionName   =  $this->home_model->getPositionName($i,'V',$iIPID);
						
						$strPosition1 = '';
						$strPosition2 = '';
						
						if($aPositionName[0] != '')
						$strPosition1	 =	$this->home_model->getPositionNameFromID($aPositionName[0]);
						if($aPositionName[1] != '')
						$strPosition2	 =	$this->home_model->getPositionNameFromID($aPositionName[1]);
						//END : Get Valve Position Details.
											
						if($name == '')
							$name = 'Valve '.$i;
						
						$sResult['Valve'.$IP->id][$i] = array($name,$strPosition1,$strPosition2);
					}
					else
					{
						$sResult['Valve'.$IP->id][$i] = '.';
					}
				}
				
				if($iIPID == 1)
					$iCount=$extra['PumpsNumber'];
				else if($iIPID > 1)
					$iCount=$extra['PumpsNumber2'];	
				//$iCount=count($sPump);
				
				for($i=1; $i<=$iCount; $i++)
				{
					$name = $this->home_model->getDeviceName($i,'PS',$iIPID);
					
					//Check If Configuration is available or not.
					$check = $this->home_model->checkConfiguration($i,'PS',$iIPID);
					
					if($check == '1')
					{
						if($name == '')
							$name = 'Pump '.$i;
							
						$sResult['Pump'.$IP->id][$i] = $name;
					}
				}
			
				$iCount = $extra['LightNumber'];
				for($i=0;$i<$iCount;$i++)
				{
					$name = $this->home_model->getDeviceName($i,'L',$iIPID);
											
					if($name == '')
						$name = 'Light '.$i;
						
					$sResult['Light'.$IP->id][$i] = $name;
				}
			
				$iCount = $extra['HeaterNumber'];
				for($i=0;$i<$iCount;$i++)
				{
					$name = $this->home_model->getDeviceName($i,'H',$iIPID);
											
					if($name == '')
						$name = 'Heater '.$i;
						
					$sResult['Heater'.$IP->id][$i] = $name;
				}
			
				$iCount = $extra['BlowerNumber'];
				for($i=0;$i<$iCount;$i++)
				{
					$name = $this->home_model->getDeviceName($i,'B',$iIPID);
											
					if($name == '')
						$name = 'Blower '.$i;
						
					$sResult['Blower'.$IP->id][$i] = $name;
				}
			
				$iCount = $extra['MiscNumber'];
				for($i=0;$i<$iCount;$i++)
				{
					$name = $this->home_model->getDeviceName($i,'M',$iIPID);
											
					if($name == '')
						$name = 'Misc '.$i;
						
					$sResult['Misc'.$IP->id][$i] = $name;
				}
			}
			
			$aResponse['code']      = 1;
			$aResponse['status']    = $this->aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
			$aResponse['data']      = json_encode($sResult);
			
			$this->webResponse($sformat, $aResponse);
		}
		
		
		/**
		* Function to Get All Custom Program Details for GID.
		* @param
		* @return : Validation message or Details of all Programs.
		**/
		public function getCustomProgramGID()
		{
			// Set default HTTP response of 'ok'
            $aResponse              =   array();
            $aResponse['code']      =   0;
            $aResponse['status']    =   404;
            $aResponse['data']      =   NULL;
            $sformat                =   isset($_GET['format']) ? $_GET['format'] : '' ; // Get response Format (json,xml,html etc.)
            $sAuth                  =   isset($_GET['auth']) ? $_GET['auth'] : '' ;// Check if Authentication is required.
            $this->isAuthenticationRequired =   $sAuth;
                
            // Optionally require connections to be made via HTTPS
            if( $this->isHTTPSRequired && $_SERVER['HTTPS'] != 'on' )
            {
                $aResponse['code']      = 2;
                $aResponse['status']    = $aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
                $aResponse['data']      = $aApiResponseCode[ $aResponse['code'] ]['Message'];

                // Return Response to browser. This will exit the script.
                $this->webResponse($sformat, $aResponse);
            }
            
            if($this->isAuthenticationRequired)
            {
                //START : Authorisation
                $sUsername       = isset($_GET['username']) ? $_GET['username'] : '' ;   // Get the username of webservice 
                $sPassword       = isset($_GET['password']) ? $_GET['password'] : '' ;   // Get the password of webservice 
                $this->webAuthorisation($sUsername, $sPassword,$sformat); // Check if username and password is valid.
                // END : Authorisation
            }
			
			//Input Data
			$iGID	=	trim($_GET['gid']);
			
			if($iGID == '')
			{
				$aResponse['code']      = 5;
				$aResponse['status']    = $this->aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
				$aResponse['data']      = 'Invalid GID!';
				// Return Response.
				$this->webResponse($sformat, $aResponse);
				exit;
			}
			
			$this->load->model('home_model');
			
			//Get Program Details.
			$sResult = $this->home_model->getAllCustomProgramGID($iGID);
			
			$aResponse['code']      = 1;
			$aResponse['status']    = $this->aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
			$aResponse['data']      = $sResult;
			
			$this->webResponse($sformat, $aResponse);
		}
		
		/**
		* Function to DELETE Custom Program Using ID.
		* @param
		* @return : Validation message or Success Message.
		**/
		public function deleteCustomProgram()
		{
			//Set default HTTP response of 'ok'
            $aResponse              =   array();
            $aResponse['code']      =   0;
            $aResponse['status']    =   404;
            $aResponse['data']      =   NULL;
            $sformat                =   isset($_GET['format']) ? $_GET['format'] : '' ; // Get response Format (json,xml,html etc.)
            $sAuth                  =   isset($_GET['auth']) ? $_GET['auth'] : '' ;// Check if Authentication is required.
            $this->isAuthenticationRequired =   $sAuth;
                
            // Optionally require connections to be made via HTTPS
            if( $this->isHTTPSRequired && $_SERVER['HTTPS'] != 'on' )
            {
                $aResponse['code']      = 2;
                $aResponse['status']    = $aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
                $aResponse['data']      = $aApiResponseCode[ $aResponse['code'] ]['Message'];

                // Return Response to browser. This will exit the script.
                $this->webResponse($sformat, $aResponse);
            }
            
            if($this->isAuthenticationRequired)
            {
                //START : Authorisation
                $sUsername       = isset($_GET['username']) ? $_GET['username'] : '' ;   // Get the username of webservice 
                $sPassword       = isset($_GET['password']) ? $_GET['password'] : '' ;   // Get the password of webservice 
                $this->webAuthorisation($sUsername, $sPassword,$sformat); // Check if username and password is valid.
                // END : Authorisation
            }
			
			//Input Data
			$iGID	=	trim($_GET['id']);
			
			if($iGID == '')
			{
				$aResponse['code']      = 5;
				$aResponse['status']    = $this->aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
				$aResponse['data']      = 'Invalid ID!';
				// Return Response.
				$this->webResponse($sformat, $aResponse);
				exit;
			}
			
			$this->load->model('home_model');
			
			//Get Program Details.
			$this->home_model->deleteCustomProgram($iGID);
			
			$aResponse['code']      = 1;
			$aResponse['status']    = $this->aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
			$aResponse['data']      = "Custom Program Deleted Succesfully!";
			
			$this->webResponse($sformat, $aResponse);
		}
		
		/**
		* Function to Save the Access of the Custom Program.
		* @param
		* @return : Validation message or Success Message.
		**/
		public function DisplayCustomProgram()
		{
			//Set default HTTP response of 'ok'
            $aResponse              =   array();
            $aResponse['code']      =   0;
            $aResponse['status']    =   404;
            $aResponse['data']      =   NULL;
            $sformat                =   isset($_GET['format']) ? $_GET['format'] : '' ; // Get response Format (json,xml,html etc.)
            $sAuth                  =   isset($_GET['auth']) ? $_GET['auth'] : '' ;// Check if Authentication is required.
            $this->isAuthenticationRequired =   $sAuth;
                
            // Optionally require connections to be made via HTTPS
            if( $this->isHTTPSRequired && $_SERVER['HTTPS'] != 'on' )
            {
                $aResponse['code']      = 2;
                $aResponse['status']    = $aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
                $aResponse['data']      = $aApiResponseCode[ $aResponse['code'] ]['Message'];

                // Return Response to browser. This will exit the script.
                $this->webResponse($sformat, $aResponse);
            }
            
            if($this->isAuthenticationRequired)
            {
                //START : Authorisation
                $sUsername       = isset($_GET['username']) ? $_GET['username'] : '' ;   // Get the username of webservice 
                $sPassword       = isset($_GET['password']) ? $_GET['password'] : '' ;   // Get the password of webservice 
                $this->webAuthorisation($sUsername, $sPassword,$sformat); // Check if username and password is valid.
                // END : Authorisation
            }
			
			//Input Data
			$iGID			=	trim($_GET['id']);
			$display_access	=	trim($_GET['display_access']);
			
			if($iGID == '')
			{
				$aResponse['code']      = 5;
				$aResponse['status']    = $this->aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
				$aResponse['data']      = 'Invalid ID!';
				// Return Response.
				$this->webResponse($sformat, $aResponse);
				exit;
			}
			if($display_access == '')
			{
				$aResponse['code']      = 5;
				$aResponse['status']    = $this->aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
				$aResponse['data']      = 'Please enter valid Access!';
				// Return Response.
				$this->webResponse($sformat, $aResponse);
				exit;
			}
			
			$this->load->model('home_model');
			
			//Get Program Details.
			$response = $this->home_model->updateAccessCustomProgram($iGID,$display_access);
			
			if($response == 'err')
			{
				$aResponse['code']      = 5;
				$aResponse['status']    = $this->aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
				$aResponse['data']      = "Custom Program not Available!";
			}
			else
			{
				$aResponse['code']      = 1;
				$aResponse['status']    = $this->aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
				$aResponse['data']      = "Custom Program Access Updated Succesfully!";
			}
			
			$this->webResponse($sformat, $aResponse);
		}
		
		/**
		* Function to Get Custom Program Details Whose Access is YES for GID.
		* @param
		* @return : Validation message or Details of all Programs.
		**/
		public function getAccessCustomProgramGID()
		{
			// Set default HTTP response of 'ok'
            $aResponse              =   array();
            $aResponse['code']      =   0;
            $aResponse['status']    =   404;
            $aResponse['data']      =   NULL;
            $sformat                =   isset($_GET['format']) ? $_GET['format'] : '' ; // Get response Format (json,xml,html etc.)
            $sAuth                  =   isset($_GET['auth']) ? $_GET['auth'] : '' ;// Check if Authentication is required.
            $this->isAuthenticationRequired =   $sAuth;
                
            // Optionally require connections to be made via HTTPS
            if( $this->isHTTPSRequired && $_SERVER['HTTPS'] != 'on' )
            {
                $aResponse['code']      = 2;
                $aResponse['status']    = $aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
                $aResponse['data']      = $aApiResponseCode[ $aResponse['code'] ]['Message'];

                // Return Response to browser. This will exit the script.
                $this->webResponse($sformat, $aResponse);
            }
            
            if($this->isAuthenticationRequired)
            {
                //START : Authorisation
                $sUsername       = isset($_GET['username']) ? $_GET['username'] : '' ;   // Get the username of webservice 
                $sPassword       = isset($_GET['password']) ? $_GET['password'] : '' ;   // Get the password of webservice 
                $this->webAuthorisation($sUsername, $sPassword,$sformat); // Check if username and password is valid.
                // END : Authorisation
            }
			
			//Input Data
			$iGID	=	trim($_GET['gid']);
			
			if($iGID == '')
			{
				$aResponse['code']      = 5;
				$aResponse['status']    = $this->aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
				$aResponse['data']      = 'Invalid GID!';
				// Return Response.
				$this->webResponse($sformat, $aResponse);
				exit;
			}
			
			$this->load->model('home_model');
			
			//Get Program Details.
			$sResult = $this->home_model->getAllAccessProgramGID($iGID);
			
			$aResponse['code']      = 1;
			$aResponse['status']    = $this->aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
			$aResponse['data']      = $sResult;
			
			$this->webResponse($sformat, $aResponse);
		}
		
		/**
		* Function to Start the custom Program.
		* @param
		* @return : Validation message or Success Message.
		**/
		public function runCustomProgram()
		{
			// Set default HTTP response of 'ok'
            $aResponse              =   array();
            $aResponse['code']      =   0;
            $aResponse['status']    =   404;
            $aResponse['data']      =   NULL;
            $sformat                =   isset($_GET['format']) ? $_GET['format'] : '' ; // Get response Format (json,xml,html etc.)
            $sAuth                  =   isset($_GET['auth']) ? $_GET['auth'] : '' ;// Check if Authentication is required.
            $this->isAuthenticationRequired =   $sAuth;
                
            // Optionally require connections to be made via HTTPS
            if( $this->isHTTPSRequired && $_SERVER['HTTPS'] != 'on' )
            {
                $aResponse['code']      = 2;
                $aResponse['status']    = $aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
                $aResponse['data']      = $aApiResponseCode[ $aResponse['code'] ]['Message'];

                // Return Response to browser. This will exit the script.
                $this->webResponse($sformat, $aResponse);
            }
            
            if($this->isAuthenticationRequired)
            {
                //START : Authorisation
                $sUsername       = isset($_GET['username']) ? $_GET['username'] : '' ;   // Get the username of webservice 
                $sPassword       = isset($_GET['password']) ? $_GET['password'] : '' ;   // Get the password of webservice 
                $this->webAuthorisation($sUsername, $sPassword,$sformat); // Check if username and password is valid.
                // END : Authorisation
            }
			
			//Input Data
			$iGID	=	trim($_GET['id']);
			
			if($iGID == '')
			{
				$aResponse['code']      = 5;
				$aResponse['status']    = $this->aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
				$aResponse['data']      = 'Invalid Program ID!';
				// Return Response.
				$this->webResponse($sformat, $aResponse);
				exit;
			}
			
			$this->load->model('home_model');
			$this->load->model('custom_model');
			
			$aCurrentProgramDetails = $this->home_model->getCustomProgramDetails($iGID);
			
			if(!empty($aCurrentProgramDetails))
			{
				foreach($aCurrentProgramDetails as $currentProgram)
				{
					$aCurrentDetails 	=	json_decode($currentProgram->program_details);
					$CurrentValveDevice	=	explode(",",$aCurrentDetails->g_rlb_valve_list);
					$afterProgram	 	=	$currentProgram->afterProgram;
					$previousState	 	= 	unserialize($currentProgram->previousState);
					
					//START : Get the first device of the custom program from all Devices.
					if(isset($aCurrentDetails->g_rlb_pump_list) && $aCurrentDetails->g_rlb_pump_list != '')
					{
						//Pump Device Details.
						$pumpDevice		=	explode(",",$aCurrentDetails->g_rlb_pump_list);
						$pumpSequence	=	explode(",",$aCurrentDetails->g_pump_sq);
						$pumpTime		=	explode(",",$aCurrentDetails->g_pump_time);
					}
					
					if(isset($aCurrentDetails->g_rlb_valve_list) && $aCurrentDetails->g_rlb_valve_list != '')
					{
						//Valve Device Details
						$valveDevice	=	explode(",",$aCurrentDetails->g_rlb_valve_list);	
						$valveSequence	=	explode(",",$aCurrentDetails->g_valve_sq);	
						$valveTime		=	explode(",",$aCurrentDetails->g_valve_time);
					}

					if(isset($aCurrentDetails->g_rlb_relay_list) && $aCurrentDetails->g_rlb_relay_list != '')
					{
						//Relay Device Details
						$relayDevice	=	explode(",",$aCurrentDetails->g_rlb_relay_list);	
						$relaySequence	=	explode(",",$aCurrentDetails->g_relay_sq);	
						$relayTime		=	explode(",",$aCurrentDetails->g_relay_time);				
					}
					
					if(isset($aCurrentDetails->g_rlb_powercenter_list) && $aCurrentDetails->g_rlb_powercenter_list != '')
					{
						//Relay Device Details
						$powerCenterDevice	=	explode(",",$aCurrentDetails->g_rlb_powercenter_list);	
						$powerCenterSequence	=	explode(",",$aCurrentDetails->g_powercenter_sq);	
						$powerCenterTime		=	explode(",",$aCurrentDetails->g_powercenter_time);				
					}
									
					if(!empty($pumpSequence))
					{
						foreach($pumpSequence as $seq => $key)
						{
							if($key != '')
							{
								if(!array_key_exists($key,$arrSequnceDevice))
								$arrSequnceDevice[$key] = array();
								
								array_push($arrSequnceDevice[$key],$pumpDevice[$seq].'|||'.$pumpTime[$seq].'|||PS');
							}
						}
					}
					
					//$valveSequence	=	array_flip($valveSequence);
					
					$arrAfterProgramDevice = array();
					if(!empty($valveSequence))
					{
						$k = 1;
						foreach($valveSequence as $seq => $key)
						{
							if($key != '')
							{
								if(!array_key_exists($key,$arrSequnceDevice))
								$arrSequnceDevice[$key] = array();
							
								array_push($arrSequnceDevice[$key],$valveDevice[$seq].'|||'.$valveTime[$seq].'|||V');
								
								//Valve to run after program end.
								$arr	=	explode('_',$valveDevice[$seq]);
								$strPosition = '';
								if($arr[1] == 1)
								{
									$strPosition = 2;
								}
								else if($arr[1] == 2)
								{
									$strPosition = 1;
								}
								
								$arrTemp 			=	explode("_",$valveDevice[$seq]);
								$ipIDTemp			=	$arrTemp[0];
								$sStatusTemp		=	$arrTemp[1];
								$deviceNumberTemp	=	$arrTemp[2];
								
								
								$valveAfterProgram = $arr[0].'_'.$strPosition.'_'.$arr[2];
								
								$lastRun = $this->home_model->getDeviceLastRun($deviceNumberTemp,'V',$ipIDTemp);
								
								if($lastRun != $sStatusTemp)
								{
									$arrAfterProgramDevice[$key] = $valveAfterProgram.'|||'.$valveTime[$seq].'|||V';
								
									$k++;
								}
								
								
								//$arrAfterProgramDevice[$k] = $valveAfterProgram.'|||'.$valveTime[$seq].'|||V';
								
								//$k++;
							}
						}
					}
					
					if(!empty($relaySequence))
					{
						foreach($relaySequence as $seq => $key)
						{
							if($key != '')
							{
								if(!array_key_exists($key,$arrSequnceDevice))
								$arrSequnceDevice[$key] = array();
								
								array_push($arrSequnceDevice[$key],$relayDevice[$seq].'|||'.$relayTime[$seq].'|||R');
							}
						}
					}
					
					if(!empty($powerCenterSequence))
					{
						foreach($powerCenterSequence as $seq => $key)
						{
							if($key != '')
							{
								if(!array_key_exists($key,$arrSequnceDevice))
								$arrSequnceDevice[$key] = array();
								
								array_push($arrSequnceDevice[$key],$powerCenterDevice[$seq].'|||'.$powerCenterTime[$seq].'|||P');
							}
						}
					}
					ksort($arrSequnceDevice);
					
					/* echo '<pre>';print_r($arrSequnceDevice);echo '</pre>';
					echo '<pre>';print_r($arrAfterProgramDevice);echo '</pre>';
					die('STOP'); */
					//END : Get the first device of the custom program from all Devices.
				}
			}
			
			//Check if the device valve from the program is Used in another running program.
			$aAllOnPrograms = $this->home_model->getOnCustomProgramOtherAfter();
			$alreadyHasValve = '0';
			
			if(!empty($aAllOnPrograms))
			{	
				foreach($aAllOnPrograms as $customProgram)
				{
					$aProgramDetails =	json_decode($customProgram->program_details);
					$valveDevice	=	explode(",",$aProgramDetails->g_rlb_valve_list);
				}
			}
			
			if(!empty($aAllOnPrograms) && $afterProgram == '0')
			{
				// Check If Valve is Running in any other Program.
				foreach($CurrentValveDevice as $Valve)
				{
					if(in_array($Valve,$valveDevice))
					{
						$aValve	= explode('_',$Valve);
						//START : Get Valve Position Details.
						$aPositionName   =  $this->home_model->getPositionName($aValve[2],'V',$aValve[0]);
						
						$strPosition1 = '';
						$strPosition2 = '';
						
						if($aPositionName[0] != '')
						$strPosition1	 =	$this->home_model->getPositionNameFromID($aPositionName[0]);
						if($aPositionName[1] != '')
						$strPosition2	 =	$this->home_model->getPositionNameFromID($aPositionName[1]);
						//END : Get Valve Position Details.
						
						$strPostition	=	'';
						if($aValve[1] == '1')
							$strPostition	=	$strPosition1;
						else if($aValve[1] == '2')
							$strPostition	=	$strPosition2;
						
						$aResponse['code']      = 5;
						$aResponse['status']    = $this->aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
						$aResponse['data']      = 'Valve '.$aValve[2].' '.$strPostition.' Position is already running in another program!';
						// Return Response.
						$this->webResponse($sformat, $aResponse);
						exit;
					}
				}
			}	
			
			
			if(empty($aAllOnPrograms))
			{
				$this->custom_model->deleteAllEntryFromCurrentAfter();
			}

			//First Check if that program is already ON.
			$sStatus = $this->home_model->chkCustomProgram($iGID);
			
			if($sStatus == '0')
			{
				$uniqueID	=	rand(1000000,9999999).time();
				
				//Check the Mode, if not manual then ON manual mode.
				$iActiveMode =  $this->home_model->getActiveMode();
				if($iActiveMode != 1)
				{
					$iMode	= 1;
					$this->home_model->updateMode($iMode);
				}
				
				//Get All IP Details.
				$aIPDetails = $this->home_model->getBoardIP();
				
				list($sIP,$sPort,$extra) = $this->home_model->getSettings();
				
				foreach($aIPDetails as $IP)
				{
					${'shhPort'.$IP->id}	=	'';
					if(IS_LOCAL == '1')
					{
						//Get SSH port of the RLB board using IP.
						${'shhPort'.$IP->id} = $this->home_model->getSSHPortFromID($IP->id);
					}
					$sResponse		=	array();
					$sValves        =   ''; 
					$sRelays        =   '';  
					$sPump			=	'';	
					
					//Get the status response of devices from relay board.
					$sResponse      =   get_rlb_status($IP->ip,$sPort,$shhPort);
				
					$sValves        =   $sResponse['valves']; // Valve Device Status
					$sRelays        =   $sResponse['relay'];  // Relay Device Status
					$sPowerCenter   =   $sResponse['powercenter']; // Power Center Device Status
					
					${'sRelays'.$IP->id} 		=	$sRelays;
					${'sValves'.$IP->id} 		=	$sValves;
					${'sPowerCenter'.$IP->id} 	=	$sPowerCenter;
					
					${'sPump'.$IP->id}	=	array($sResponse['pump_seq_0_st'],$sResponse['pump_seq_1_st'],$sResponse['pump_seq_2_st']);
					${'board'.$IP->id} 	=	$IP->ip;
					
					$arrExtraDetails[$IP->id] = array('sValves'=>${'sValves'.$IP->id},'board'=>${'board'.$IP->id},'shhPort'=>${'shhPort'.$IP->id});
				}
				
				//START :STOP ALL Devices Running in after program for the same program which is going to start.
				if($afterProgram == '1')	
				{
					$currentDeviceAfter = $this->custom_model->getCustomProgrmaAfterDevice($iGID);
					if($currentDeviceAfter != '')
					{
						$lastElement = end($currentDeviceAfter);
						
						foreach($currentDeviceAfter as $deviceDetails)
						{
							$currentSeq		=	$deviceDetails->current_sequence;
							$deviceType 	=   $deviceDetails->device_type;
							$ipID			=	$deviceDetails->ip_id;
							$sStatus		=	0;
							$deviceNumber	=	$deviceDetails->device_number;
							
							$sNewResp = replace_return($arrExtraDetails[$ipID]['sValves'], $sStatus, $deviceNumber);
							$arrExtraDetails[$ipID]['sValves'] = $sNewResp;
							onoff_rlb_valve($sNewResp,$arrExtraDetails[$ipID]['board'],$sPort,$arrExtraDetails[$ipID]['shhPort']);
							
							
							//Insert Entry in the Log Table for future Reference.
							$this->custom_model->saveCustomAfterEntryInLog($iGID,$deviceType);
							
							//Delete Entry From the current details Table.
							$this->custom_model->deleteCustomEntryFromAfter($iGID,$deviceType,$deviceNumber);
							
						}
					}
					
					$this->home_model->updateAfterProgram($iGID,'0');
				}
				//STOP : STOP ALL Devices Running in after program for the same program which is going to start.
				
				//START : To store the current position of Valve before starting first Device of Program.
				$arrValveKeepOn		   = array();
				$arrValveDefaultPosition		   = array();
				if(!empty($valveSequence))
				{
					$k = 1;
					foreach($valveSequence as $seq => $key)
					{
						if($key != '')
						{
							//Valve to run after program end.
							$arr	=	explode('_',$valveDevice[$seq]);
							$strPosition = '';
							if($arr[1] == 1)
							{
								$strPosition = 2;
							}
							else if($arr[1] == 2)
							{
								$strPosition = 1;
							}
							
							$arrTemp 			=	explode("_",$valveDevice[$seq]);
							$ipIDTemp			=	$arrTemp[0];
							$sStatusTemp		=	$arrTemp[1];
							$deviceNumberTemp	=	$arrTemp[2];
							
							$existingStatus 	=	${'sValves'.$ipIDTemp}[$deviceNumberTemp];
							
							$arrValveDefaultPosition[] = $deviceNumberTemp.'_'.$ipIDTemp;
							
							$arrValveKeepOn[]	= $ipIDTemp.'_'.$existingStatus.'_'.$deviceNumberTemp;
						}
					}
					
					
					if($arrValveDefaultPosition)
					{
						//START : If Default Position is running then stop those valve.
						$arrValveDetails = $this->home_model->getAllValveDefaultPositionRunnig();
						if($arrValveDetails)
						{
							foreach($arrValveDetails as $valveDetails)
							{
								$IpId			=	$valveDetails->ip_id;
								$Valve			=	$valveDetails->valve;
								
								$checkValve     = 	$Valve.'_'.$IpId;
								
								if(in_array($checkValve,$arrValveDefaultPosition))
								{
									$sNewResp = replace_return(${'sValves'.$IpId}, '0', $Valve);
									${'sValves'.$IpId} = $sNewResp;
									onoff_rlb_valve($sNewResp,${'board'.$IpId},$sPort,${'shhPort'.$IpId});
									
									$this->home_model->removeDefaultRunDetails($valveDetails->id);
								}
							}
						}
					}
				}
				
				//END : To store the current position of Valve before starting first Device of Program.
				
				//Start Custom Program.
				$this->home_model->startCustomProgram($iGID,$uniqueID);
				
				$this->home_model->updateExistingStatusValveForProgram($iGID,$arrValveKeepOn);
				
				//START : First Device ON.
				foreach($arrSequnceDevice[1] as $devices)
				{
					$aCurrentDevice	=	explode('|||',$devices);
					//START: First make valve device ON in the sequence.
					$sStatus		=	'1';
					$sRunTime		=	$aCurrentDevice[1];
					$deviceType 	=   $aCurrentDevice[2];
					$aDevice		=	explode("_",$aCurrentDevice[0]);
					if($deviceType == 'V')
					{
						$ipID			=	$aDevice[0];
						$sStatus		=	$aDevice[1];
						$deviceNumber	=	$aDevice[2];
					}
					else if($deviceType == 'PS' || $deviceType == 'R' || $deviceType == 'P')
					{
						$ipID			=	$aDevice[0];
						$deviceNumber	=	$aDevice[1];
					}
					
					if($deviceType	==	'PS')
					{
						require_once(APPPATH.'controllers/cron.php');
						$aObjCron = new Cron();   
						$aObjCron->cronMakePumpOnOFF($deviceNumber,$sStatus,${'board'.$ipID},$sPort,${'shhPort'.$ipID},$ipID);
						$strDevice		=	'Pump '.$deviceNumber;
					}
					else if($deviceType	== 'V')
					{
						$sNewResp = replace_return(${'sValves'.$ipID}, $sStatus, $deviceNumber);
						${'sValves'.$ipID} = $sNewResp;
						onoff_rlb_valve($sNewResp,${'board'.$ipID},$sPort,${'shhPort'.$ipID});
						
						$strDevice	=	'Valve '.$deviceNumber;	
					}
					else if($deviceType	== 'R')
					{
						$sNewResp = replace_return(${'sRelays'.$ipID}, $sStatus, $deviceNumber);
						${'sRelays'.$ipID} = $sNewResp;
						onoff_rlb_relay($sNewResp,${'board'.$ipID},$sPort,${'shhPort'.$ipID});
						
						$heaterNum = $this->home_model->chkHeater($deviceNumber,'24',$ipID);
									
						if($heaterNum != '')
						{
							$aHeaterDetails  =   $this->home_model->getHeaterDeviceDetails($heaterNum,$ipID);
							if(!empty($aHeaterDetails))
							{
								foreach($aHeaterDetails as $aHeater)
								{
									$sHeaterDetails  =   unserialize($aHeater->light_relay_number);
								}
								
								$PumpNumber   		=   $sHeaterDetails['Pump'];
							}
							if($PumpNumber != '')
							{
								$aPumpDetails =	$this->home_model->getPumpDetails($PumpNumber,$ipID);
								if(!empty($aPumpDetails))
								{
									foreach($aPumpDetails as $sPump)
									{
										//$this->cronMakePumpOnOFF($PumpNumber,'1',${'board'.$ipID},$sPort,${'shhPort'.$ipID},$ipID);
										
										require_once(APPPATH.'controllers/cron.php');
										$aObjCron = new Cron();   
										$aObjCron->cronMakePumpOnOFF($PumpNumber,'1',${'board'.$ipID},$sPort,${'shhPort'.$ipID},$ipID);
									}
								}
							}
						}
						
						$strDevice	=	'Relay '.$deviceNumber;	
					}
					else if($deviceType	== 'P')
					{
						$sNewResp = replace_return(${'sPowerCenter'.$ipID}, $sStatus, $deviceNumber);
						${'sPowerCenter'.$ipID} = $sNewResp;
						onoff_rlb_powercenter($sNewResp,${'board'.$ipID},$sPort,${'shhPort'.$ipID});
						
						$heaterNum = $this->home_model->chkHeater($deviceNumber,'12',$ipID);
												
						if($heaterNum != '')
						{
							$aHeaterDetails  =   $this->home_model->getHeaterDeviceDetails($heaterNum,$ipID);
							if(!empty($aHeaterDetails))
							{
								foreach($aHeaterDetails as $aHeater)
								{
									$sHeaterDetails  =   unserialize($aHeater->light_relay_number);
								}
								
								$PumpNumber   		=   $sHeaterDetails['Pump'];
							}
							if($PumpNumber != '')
							{
								$aPumpDetails =	$this->home_model->getPumpDetails($PumpNumber,$ipID);
								if(!empty($aPumpDetails))
								{
									foreach($aPumpDetails as $sPump)
									{
										//$this->cronMakePumpOnOFF($PumpNumber,'1',${'board'.$ipID},$sPort,${'shhPort'.$ipID},$ipID);
										
										require_once(APPPATH.'controllers/cron.php');
										$aObjCron = new Cron();   
										$aObjCron->cronMakePumpOnOFF($sPump->pump_number,'1',${'board'.$ipID},$sPort,${'shhPort'.$ipID},$ipID);
									}
								}
							}
						}
						
						$strDevice	=	'Power Center '.$deviceNumber;
					}
					
					$arrDetails		=	array('program_id'=>$iGID,
											  'current_on_device'=>$strDevice,
											  'device_type'=>$deviceType,
											  'device_number'=>$deviceNumber,
											  'current_on_time'=>$sRunTime,
											  'current_sequence'=>1,
											  'ip_id'=>$ipID,
											  'unique_id'=>$uniqueID);
					
					$this->custom_model->saveCustomCurrentRunningDevice($arrDetails);
				}
				//END : First Device ON. 
				
				 
				
				$aResponse['code']      = 1;
				$aResponse['status']    = $this->aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
				$aResponse['data']      = "Program Started Succesfully!";
				
				$this->webResponse($sformat, $aResponse);
			}
			else
			{
				$aResponse['code']      = 1;
				$aResponse['status']    = $this->aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
				$aResponse['data']      = "Program is Already Running!";
				
				$this->webResponse($sformat, $aResponse);
			}	
			
		}
		
		/**
		* Function to Stop the custom Program.
		* @param
		* @return : Validation message or Success Message.
		**/
		public function stopCustomProgram()
		{
			// Set default HTTP response of 'ok'
            $aResponse              =   array();
            $aResponse['code']      =   0;
            $aResponse['status']    =   404;
            $aResponse['data']      =   NULL;
            $sformat                =   isset($_GET['format']) ? $_GET['format'] : '' ; // Get response Format (json,xml,html etc.)
            $sAuth                  =   isset($_GET['auth']) ? $_GET['auth'] : '' ;// Check if Authentication is required.
            $this->isAuthenticationRequired =   $sAuth;
                
            // Optionally require connections to be made via HTTPS
            if( $this->isHTTPSRequired && $_SERVER['HTTPS'] != 'on' )
            {
                $aResponse['code']      = 2;
                $aResponse['status']    = $aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
                $aResponse['data']      = $aApiResponseCode[ $aResponse['code'] ]['Message'];

                // Return Response to browser. This will exit the script.
                $this->webResponse($sformat, $aResponse);
            }
            
            if($this->isAuthenticationRequired)
            {
                //START : Authorisation
                $sUsername       = isset($_GET['username']) ? $_GET['username'] : '' ;   // Get the username of webservice 
                $sPassword       = isset($_GET['password']) ? $_GET['password'] : '' ;   // Get the password of webservice 
                $this->webAuthorisation($sUsername, $sPassword,$sformat); // Check if username and password is valid.
                // END : Authorisation
            }
			
			//Input Data
			$iGID	=	trim($_GET['id']);
			
			if($iGID == '')
			{
				$aResponse['code']      = 5;
				$aResponse['status']    = $this->aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
				$aResponse['data']      = 'Invalid Program ID!';
				// Return Response.
				$this->webResponse($sformat, $aResponse);
				exit;
			}
			
			$this->load->model('home_model');
			$this->load->model('custom_model');
			
			//First Check if that program is already ON.
			$sStatus = $this->home_model->chkCustomProgram($iGID);
			
			if($sStatus == '1')
			{
				$afterProgram = 0;
				$programDetails = $this->home_model->getCustomProgramDetails($iGID);
				
				foreach($programDetails as $customProgram)
				{
					$aProgramDetails =	json_decode($customProgram->program_details);
					$previousState	 = 	unserialize($customProgram->previousState);
					
					if(isset($aProgramDetails->g_rlb_valve_list) && $aProgramDetails->g_rlb_valve_list != '')
					{
						//Valve Device Details
						$valveDevice	=	explode(",",$aProgramDetails->g_rlb_valve_list);	
						$valveSequence	=	explode(",",$aProgramDetails->g_valve_sq);	
						$valveTime		=	explode(",",$aProgramDetails->g_valve_time);
					}
					
					$arrProgramValve	=	array();

					$arrAfterProgramDevice = array();
					if(!empty($valveSequence))
					{
						$k = 1;
						foreach($valveSequence as $seq => $key)
						{
							if(!array_key_exists($key,$arrSequnceDevice))
							$arrSequnceDevice[$key] = array();
						
							//Valve to run after program end.
							$arr	=	explode('_',$valveDevice[$seq]);
							$strPosition = '';
							if($arr[1] == 1)
							{
								$strPosition = 2;
							}
							else if($arr[1] == 2)
							{
								$strPosition = 1;
							}
							
							$arrTemp 			=	explode("_",$valveDevice[$seq]);
							$ipIDTemp			=	$arrTemp[0];
							$sStatusTemp		=	$arrTemp[1];
							$deviceNumberTemp	=	$arrTemp[2];
							
							array_push($arrProgramValve,$valveDevice[$seq]);
							
							//$tempDevice			=	$ipIDTemp.'_'.$existingStatus.'_'.$deviceNumberTemp;
							
							$valveAfterProgram = $arr[0].'_'.$strPosition.'_'.$arr[2];
							
							//if($existingStatus != $sStatusTemp)
							if(!in_array($valveDevice[$seq],$previousState))	
							{
								$lastRun = $this->home_model->getDeviceLastRun($deviceNumberTemp,'V',$ipIDTemp);
								
								if($lastRun != $sStatusTemp)
								{
									$arrAfterProgramDevice[$key] = $valveAfterProgram.'|||'.$valveTime[$seq].'|||V';
								
									$k++;
								}
							}
							else
							{
								$arrValveKeepOn[] = $ipIDTemp.'_'.$deviceNumberTemp;
							}
							
							//$valveAfterProgram = $arr[0].'_'.$strPosition.'_'.$arr[2];
							
							//$arrAfterProgramDevice[$k] = $valveAfterProgram.'|||'.$valveTime[$seq].'|||V';
							
							//$k++;
						}
					}
					
					if(!empty($arrAfterProgramDevice))
					{
						$afterProgram	=	1;
					}
				}
				$afterProgram = 0;
				
				//Stop Custom Program.
				$this->home_model->stopCustomProgram($iGID,$afterProgram);
				
				$currentDevice = $this->custom_model->getCustomProgrmaCurrentDevice($iGID);
				
				if($currentDevice != '')
				{
					foreach($currentDevice as $deviceDetails)
					{
						$currentSeq		=	$deviceDetails->current_sequence;
						$deviceType 	=   $deviceDetails->device_type;
						$ipID			=	$deviceDetails->ip_id;
						$sStatus		=	0;
						$deviceNumber	=	$deviceDetails->device_number;
						
						$sDeviceIP		= 	$this->home_model->getBoardIPFromID($ipID);
						list($sIP,$sPort,$extra) = $this->home_model->getSettings();
			
						
						$shhPort	=	'';
						if(IS_LOCAL == '1')
						{
							//Get SSH port of the RLB board using IP.
							$shhPort = $this->home_model->getSSHPortFromID($ipID);
						}
						$sResponse		=	array();
						$sValves        =   ''; 
						$sRelays        =   '';  
						$sPump			=	'';	
						
						//Get the status response of devices from relay board.
						$sResponse      =   get_rlb_status($sDeviceIP,$sPort,$shhPort);
					
						$sValves        =   $sResponse['valves']; // Valve Device Status
						$sRelays        =   $sResponse['relay'];  // Relay Device Status
						$sPowerCenter   =   $sResponse['powercenter']; // Power Center Device Status
						
						${'sPump'.$IP->id}	=	array($sResponse['pump_seq_0_st'],$sResponse['pump_seq_1_st'],$sResponse['pump_seq_2_st']);
						
						if($deviceType == 'V')
						{
							$sNewResp = replace_return($sValves, $sStatus, $deviceNumber);
							$sValves = $sNewResp;
							onoff_rlb_valve($sNewResp,$sDeviceIP,$sPort,$shhPort);
						}
						else if($deviceType == 'PS')
						{	
							$this->webCustomMakePumpOnOFF($deviceNumber,$sStatus,$sDeviceIP,$sPort,$shhPort,$ipID);
						}
						else if($deviceType	== 'R')
						{
							$sNewResp = replace_return($sRelays, $sStatus, $deviceNumber);
							$sRelays = $sNewResp;
							onoff_rlb_relay($sNewResp,$sDeviceIP,$sPort,$shhPort);
							
							//START : Check if heater is assigned to that relay.
							$heaterNum = $this->home_model->chkHeater($deviceNumber,'24',$ipID);
							
							if($heaterNum != '')
							{
								$aHeaterDetails  =   $this->home_model->getHeaterDeviceDetails($heaterNum,$ipID);
								if(!empty($aHeaterDetails))
								{
									foreach($aHeaterDetails as $aHeater)
									$sHeaterDetails  =   unserialize($aHeater->light_relay_number);
									
									$PumpNumber   		=   $sHeaterDetails['Pump'];
								}
								if($PumpNumber != '')
								{
									$aPumpDetails =	$this->home_model->getPumpDetails($PumpNumber,$ipID);
									if(!empty($aPumpDetails))
									{
										foreach($aPumpDetails as $sPump)
										{
											$heaterStopTime =	date('Y-m-d H:i:s');
											$arrStopTime	=	explode(" ",$heaterStopTime);
											$aDate     		=   explode("-",$arrStopTime[0]);
											$aTime     		=   explode(":",$arrStopTime[1]);
											
											$sProgramAbsEnd =   mktime(($aTime[0]),($aTime[1]+5),($aTime[2]),$aDate[1],$aDate[2],$aDate[0]);
											$pumpStopTime   =   date("Y-m-d H:i:s", $sProgramAbsEnd);
											
											$this->home_model->updateRunAfterHeaterDetails($heaterNum,$sPump->pump_number,$heaterStopTime,$pumpStopTime,$ipID,$iGID);
										}
									}
								}
							}
						}
						else if($deviceType	== 'P')
						{
							$sNewResp = replace_return($sPowerCenter, $sStatus, $deviceNumber);
							$sPowerCenter = $sNewResp;
							onoff_rlb_powercenter($sNewResp,$sDeviceIP,$sPort,$shhPort);
							//START : Check if heater is assigned to that relay.
							$heaterNum = $this->home_model->chkHeater($deviceNumber,'12',$ipID);
							
							if($heaterNum != '')
							{
								$aHeaterDetails  =   $this->home_model->getHeaterDeviceDetails($heaterNum,$ipID);
								if(!empty($aHeaterDetails))
								{
									foreach($aHeaterDetails as $aHeater)
									$sHeaterDetails  =   unserialize($aHeater->light_relay_number);
									
									$PumpNumber   		=   $sHeaterDetails['Pump'];
								}
								if($PumpNumber != '')
								{
									$aPumpDetails =	$this->home_model->getPumpDetails($PumpNumber,$ipID);
									if(!empty($aPumpDetails))
									{
										foreach($aPumpDetails as $sPump)
										{
											$heaterStopTime =	date('Y-m-d H:i:s');
											$arrStopTime	=	explode(" ",$heaterStopTime);
											$aDate     		=   explode("-",$arrStopTime[0]);
											$aTime     		=   explode(":",$arrStopTime[1]);
											
											$sProgramAbsEnd =   mktime(($aTime[0]),($aTime[1]+5),($aTime[2]),$aDate[1],$aDate[2],$aDate[0]);
											$pumpStopTime   =   date("Y-m-d H:i:s", $sProgramAbsEnd);
											
											$this->home_model->updateRunAfterHeaterDetails($heaterNum,$sPump->pump_number,$heaterStopTime,$pumpStopTime,$ipID,$iGID);
										}
									}
								}
							}
						}
						
						//Insert Entry in the Log Table for future Reference.
						$this->custom_model->saveCustomEntryInLog($iGID,$deviceType);
						
						//Delete Entry From the current details Table.
						$this->custom_model->deleteCustomEntryFromCurrent($iGID,$deviceType,$deviceNumber);
						
					}
				}
				
				$OnCustomProgramDetails		= $this->home_model->getOnCustomProgramExcludeID($iGID);
				if(!empty($OnCustomProgramDetails))	
				{
					$OnCustomProgram    = 0;
				}
				else
					$OnCustomProgram    = 1;
				
				if($OnCustomProgram == 0)
				{
					if(!empty($arrProgramValve))
					{
						foreach($arrProgramValve as $valveDevice)
						{
							$arrTemp 			=	explode("_",$valveDevice);
							$ipIDTemp			=	$arrTemp[0];
							$sStatusTemp		=	$arrTemp[1];
							$deviceNumberTemp	=	$arrTemp[2];
							
							#START : GET Default Pool auto Position.
							$defaultPosition 	=	$this->home_model->getValveDefaultPosition($deviceNumberTemp,$ipIDTemp);
							
							$sDeviceIP		= 	$this->home_model->getBoardIPFromID($ipIDTemp);
							list($sIP,$sPort,$extra) = $this->home_model->getSettings();
				
							$shhPort	=	'';
							if(IS_LOCAL == '1')
							{
								//Get SSH port of the RLB board using IP.
								$shhPort = $this->home_model->getSSHPortFromID($ipIDTemp);
							}
							$sResponse		=	array();
							$sValves        =   ''; 
							$sRelays        =   '';  
							$sPump			=	'';	
							
							//Get the status response of devices from relay board.
							$sResponse      =   get_rlb_status($sDeviceIP,$sPort,$shhPort);
							$sValves        =   $sResponse['valves']; // Valve Device Status
							
							$sNewResp = replace_return($sValves, $defaultPosition, $deviceNumberTemp);
							$sValves = $sNewResp;
							onoff_rlb_valve($sNewResp,$sDeviceIP,$sPort,$shhPort);					
							#END : GET Default Pool auto Position.
							
							//START : INSERT THE VALVE DETAILS TO RUN VALVE FOR GIVEN TIME IN POOL MODE AUTO. IF TIME IS NOT SPECIFIED THEN IT WILL RUN FOR 1 MIN DEFAULT.
							
							$runTime = $this->home_model->getValveDefaultPositionTime($deviceNumberTemp,$ipIDTemp);
							if($runTime == 0)
							{
								$runTime = 1;
							}
							if($runTime == '')
							{
								$runTime = 1;
							}
							
							$arrValveDefaultRunDetails	=	array('program_id'=>$iGID,'valve'=>$deviceNumberTemp,'ip_id'=>$ipIDTemp,'runTime'=>$runTime);
							$this->home_model->insertValveDefaultRunDetails($arrValveDefaultRunDetails);
							
							//END : INSERT THE VALVE DETAILS TO RUN VALVE FOR GIVEN TIME IN POOL MODE AUTO. IF TIME IS NOT SPECIFIED THEN IT WILL RUN FOR 1 MIN DEFAULT.
						}
						//Remove the Previous Position of the valves.
						$this->home_model->removePreviousPositions($iGID);
					}
				}
				
				$aResponse['code']      = 1;
				$aResponse['status']    = $this->aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
				$aResponse['data']      = "Program Stopped Succesfully!|||".$OnCustomProgram;
				
				$this->webResponse($sformat, $aResponse);
			}
			else
			{
				$aResponse['code']      = 1;
				$aResponse['status']    = $this->aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
				$aResponse['data']      = "Program is Already Stopped!";
				
				$this->webResponse($sformat, $aResponse);
			}	
			
		}
		
	public function webCustomMakePumpOnOFF($sName,$sStatus,$sIP,$sDevicePort,$sShh,$sIdIP)
	{
		//$sName.">>".$sStatus.">>".$sIP.">>".$sDevicePort.">>".$sShh.">>".$sIdIP;
		
		$sResponse      =   get_rlb_status($sIP,$sDevicePort,$sShh);
		
        $this->load->model('home_model');
        $this->load->model('custom_model');
		
        $sRelays        =   $sResponse['relay'];    // Relay Device Status
        $sPowercenter   =   $sResponse['powercenter']; // Power Center Device Status
		
		$sDevice = 'PS';
		
		if($sDevice == 'PS') // If Device type is Pump
        {
			$aPumpDetails = $this->home_model->getPumpDetails($sName,$sIdIP);
			//Variable Initialization to blank.
			$sPumpNumber  	= '';
			$sPumpType  	= '';
			$sPumpSubType  	= '';
			$sPumpSpeed  	= '';
			$sPumpFlow 		= '';
			$sPumpClosure   = '';
			$sRelayNumber  	= '';
			$sRelayNumber1  = '';

			if(is_array($aPumpDetails) && !empty($aPumpDetails))
			{
			  foreach($aPumpDetails as $aResultEdit)
			  { 
				$sPumpNumber  = $aResultEdit->pump_number;
				$sPumpType    = $aResultEdit->pump_type;
				$sPumpSubType = $aResultEdit->pump_sub_type;
				$sPumpSpeed   = $aResultEdit->pump_speed;
				$sPumpFlow    = $aResultEdit->pump_flow;
				$sPumpClosure = $aResultEdit->pump_closure;
				$sRelayNumber = $aResultEdit->relay_number;
				$sRelayNumber1 = $aResultEdit->relay_number_1;
			  }
			}
			
			if($sPumpType != '')
			{
				if($sPumpType == '12' || $sPumpType == '24' || $sPumpType == '2Speed')
				{
					if($sPumpType == '24')
					{
						$sNewResp = replace_return($sRelays, $sStatus, $sRelayNumber );
						onoff_rlb_relay($sNewResp,$sIP,$sDevicePort,$sShh);
						$this->home_model->updateDeviceRunTime($sName,$sDevice,$sStatus,$sIdIP);
						
						$this->home_model->updateDeviceStauts($sName,$sDevice,$sStatus,$sIdIP);
					}
					else if($sPumpType == '12')
					{
						$sNewResp = replace_return($sPowercenter, $sStatus, $sRelayNumber );
						onoff_rlb_powercenter($sNewResp,$sIP,$sDevicePort,$sShh);
						
						$this->home_model->updateDeviceStauts($sName,$sDevice,$sStatus,$sIdIP);
					}
					if($sPumpType == '2Speed')
					{
						if($sPumpSubType == '24')
						{
							if($sStatus == '0')
							{
								$sNewResp = replace_return($sRelays, 0, $sRelayNumber );
								onoff_rlb_relay($sNewResp,$sIP,$sDevicePort,$sShh);
								$this->home_model->updateDeviceRunTime($sName,$sDevice,$sStatus,$sIdIP);
								
								$sNewResp = replace_return($sNewResp, '0', $sRelayNumber1 );
								onoff_rlb_relay($sNewResp,$sIP,$sDevicePort,$sShh);
								$this->home_model->updateDeviceRunTime($sName,$sDevice,$sStatus,$sIdIP);
							}
							if($sStatus == '1')
							{
								$sNewResp = replace_return($sRelays, $sStatus, $sRelayNumber );
								onoff_rlb_relay($sNewResp,$sIP,$sDevicePort,$sShh);
								$this->home_model->updateDeviceRunTime($sName,$sDevice,$sStatus,$sIdIP);
								
								$sNewResp = replace_return($sNewResp, '0', $sRelayNumber1 );
								onoff_rlb_relay($sNewResp,$sIP,$sDevicePort,$sShh);
								$this->home_model->updateDeviceRunTime($sName,$sDevice,$sStatus,$sIdIP);
							}
							if($sStatus == '2')
							{	
								$sStatus = '1';
								$sNewResp = replace_return($sRelays, $sStatus, $sRelayNumber1 );
								onoff_rlb_relay($sNewResp,$sIP,$sDevicePort,$sShh);
								$this->home_model->updateDeviceRunTime($sName,$sDevice,$sStatus,$sIdIP);
								
								$sNewResp = replace_return($sNewResp, '0', $sRelayNumber );
								onoff_rlb_relay($sNewResp,$sIP,$sDevicePort,$sShh);
								$this->home_model->updateDeviceRunTime($sName,$sDevice,$sStatus,$sIdIP);
							}
							
							$this->home_model->updateDeviceStauts($sName,$sDevice,$sStatus,$sIdIP);
							
						}
						else if($sPumpSubType == '12')
						{
							
							if($sStatus == '0')
							{
								$sNewResp = replace_return($sPowercenter, '0', $sRelayNumber );
								onoff_rlb_powercenter($sNewResp,$sIP,$sDevicePort,$sShh);
								
								$sNewResp = replace_return($sNewResp, '0', $sRelayNumber1 );
								onoff_rlb_powercenter($sNewResp,$sIP,$sDevicePort,$sShh);
							}
							if($sStatus == '1')
							{
								$sNewResp = replace_return($sPowercenter, $sStatus, $sRelayNumber );
								onoff_rlb_powercenter($sNewResp,$sIP,$sDevicePort,$sShh);
								
								$sNewResp = replace_return($sNewResp, '0', $sRelayNumber1 );
								onoff_rlb_powercenter($sNewResp,$sIP,$sDevicePort,$sShh);
							}
							if($sStatus == '2')
							{	
								$sStatus = '1';
								$sNewResp = replace_return($sPowercenter, $sStatus, $sRelayNumber1 );
								onoff_rlb_powercenter($sNewResp,$sIP,$sDevicePort,$sShh);
								
								$sNewResp = replace_return($sNewResp, '0', $sRelayNumber );
								onoff_rlb_powercenter($sNewResp,$sIP,$sDevicePort,$sShh);
								
								$sStatus = '2';
							}
							
							$this->home_model->updateDeviceStauts($sName,$sDevice,$sStatus,$sIdIP);
							
						}
							
						
					}
				}
				else
				{
					if(preg_match('/Emulator/',$sPumpType))
					{
						$sNewResp = '';

						if($sStatus == '0')
							$sNewResp =  $sName.' '.$sStatus;
						else if($sStatus == '1')
						{
							/* $sType          =   '';
							if($sPumpSubType == 'VS')
								$sType  =   '2'.' '.$sPumpSpeed;
							elseif ($sPumpSubType == 'VF')
								$sType  =   '3'.' '.$sPumpFlow; */
								
							if($sPumpSubType == 'VS')
								$sType  =   $sPumpSpeed;
							elseif ($sPumpSubType == 'VF')
								$sType  =   $sPumpFlow;	

							$sNewResp =  $sName.' '.$sType;    
						}
						
						onoff_rlb_pump($sNewResp,$sIP,$sDevicePort,$sShh);
						
						if($sPumpType == 'Emulator12')
						{
							$sNewResp12 = replace_return($sPowercenter, $sStatus, $sRelayNumber );
							onoff_rlb_powercenter($sNewResp12,$sIP,$sDevicePort,$sShh);
						}
						if($sPumpType == 'Emulator24')
						{
							$sNewResp24 = replace_return($sRelays, $sStatus, $sRelayNumber );
							onoff_rlb_relay($sNewResp24,$sIP,$sDevicePort,$sShh);
							$this->home_model->updateDeviceRunTime($sRelayNumber,'R',$sStatus,$sIdIP);
						}
						$this->home_model->updateDeviceStauts($sName,$sDevice,$sStatus,$sIdIP);
						
					}
					else if(preg_match('/Intellicom/',$sPumpType))
					{
						$sNewResp = '';

						if($sStatus == '0')
							$sNewResp =  $sName.' '.$sStatus;
						else if($sStatus == '1')
						{
							//$sType  =   '2'.' '.$sPumpSpeed;
							$sType    =   $sPumpSpeed;
							$sNewResp =  $sName.' '.$sType;    
						}
						
						onoff_rlb_pump($sNewResp,$sIP,$sDevicePort,$sShh);
						
						if($sPumpType == 'Intellicom12')
						{
							$sNewResp12 = replace_return($sPowercenter, $sStatus, $sRelayNumber );
							onoff_rlb_powercenter($sNewResp12,$sIP,$sDevicePort,$sShh);
						}
						if($sPumpType == 'Intellicom24')
						{
							$sNewResp24 = replace_return($sRelays, $sStatus, $sRelayNumber );
							onoff_rlb_relay($sNewResp24,$sIP,$sDevicePort,$sShh);
							$this->home_model->updateDeviceRunTime($sRelayNumber,'R',$sStatus,$sIdIP);
						}
						
						$this->home_model->updateDeviceStauts($sName,$sDevice,$sStatus,$sIdIP);
					}
				}
				
				//Update details of program to which pump is related.
				if($sStatus == 0)
				{
					$aProgramDetails	=	$this->home_model->getProgramDetailsForDevice($sName,$sDevice,$sIdIP);
					
					foreach($aProgramDetails as $Program)
					{
						if($Program->program_active == '1')
						{
							$this->home_model->updateProgramStatus($Program->program_id, 0);
							if($Program->program_absolute == '1')
							{
								$aAbsoluteDetails   = array(
								'absolute_s'  => $Program->program_absolute_start_time,             'absolute_e'  => $Program->program_absolute_end_time,
								'absolute_t'  => $Program->program_absolute_total_time,
								'absolute_ar' => $Program->program_absolute_run_time,
								'absolute_sd' => $Program->program_absolute_start_date,
								'absolute_st' => $Program->program_absolute_run);
															
								$this->home_model->updateAlreadyRunTime($Program->program_id, $aAbsoluteDetails);
								
							}
						}
					}
				}
				//$this->home_model->updateDeviceStauts($sName,$sDevice,$sStatus);
			}				
           
        }
		
	}
	
	/**
	* Function to Send custom Program notifications.
	* @param
	* @return : Validation message or Success Message.
	**/
	public function sendCustomProgramNotification()
	{
		// Set default HTTP response of 'ok'
		$aResponse              =   array();
		$aResponse['code']      =   0;
		$aResponse['status']    =   404;
		$aResponse['data']      =   NULL;
		$sformat                =   isset($_GET['format']) ? $_GET['format'] : '' ; // Get response Format (json,xml,html etc.)
		$sAuth                  =   isset($_GET['auth']) ? $_GET['auth'] : '' ;// Check if Authentication is required.
		$this->isAuthenticationRequired =   $sAuth;
			
		// Optionally require connections to be made via HTTPS
		if( $this->isHTTPSRequired && $_SERVER['HTTPS'] != 'on' )
		{
			$aResponse['code']      = 2;
			$aResponse['status']    = $aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
			$aResponse['data']      = $aApiResponseCode[ $aResponse['code'] ]['Message'];

			// Return Response to browser. This will exit the script.
			$this->webResponse($sformat, $aResponse);
		}
		
		if($this->isAuthenticationRequired)
		{
			//START : Authorisation
			$sUsername       = isset($_GET['username']) ? $_GET['username'] : '' ;   // Get the username of webservice 
			$sPassword       = isset($_GET['password']) ? $_GET['password'] : '' ;   // Get the password of webservice 
			$this->webAuthorisation($sUsername, $sPassword,$sformat); // Check if username and password is valid.
			// END : Authorisation
		}
			
		$this->load->model('custom_model');
		$this->load->model('home_model');
		
		//Get All On Program and Details.
		$aAllOnPrograms = $this->home_model->getOnCustomProgram();
		$arrProgramDetails =array();
		if(!empty($aAllOnPrograms))
		{
			foreach($aAllOnPrograms as $customProgram)
			{
				$arrProgramDetails = array();
				
				$unique_id	=	$customProgram->unique_id;
				$programID	=	$customProgram->id;
				
				$aProgramDetails =	json_decode($customProgram->program_details);
				
				$maxRunTime		 =	$aProgramDetails->g_custom_max_time;
				$programStart	 =	$customProgram->program_start;	
				$programEnd		 =	$customProgram->program_end;
				$programName	 =  trim(str_replace("_"," ",$aProgramDetails->g_custom_mode_name));
				
				
				$arrProgramDetails[$programID]['DateTime'] = date("Y-m-d H:i:s");
				$arrProgramDetails[$programID]['Name'] = 'Name : '.$programName;
				$arrProgramDetails[$programID]['After'] = 0;
				
				/* $time1      = new DateTime(date("Y-m-d H:i:s"));
				$time2      = new DateTime($programEnd);
				$interval   = $time2->diff($time1);
				$sTotalTime = $interval->format('%H:%I:%S'); */
				
				$time1     = new DateTime(date('Y-m-d H:i:s'));
				$time2      = new DateTime($programEnd);
				$sTotalTime = $time2->format('F d, Y H:i:s');
				
				$arrProgramDetails[$programID]['Time'] = $sTotalTime;
				
				if(isset($aProgramDetails->g_rlb_pump_list) && $aProgramDetails->g_rlb_pump_list != '')
				{
					//Pump Device Details.
					$pumpDevice		=	explode(",",$aProgramDetails->g_rlb_pump_list);
					$pumpSequence	=	explode(",",$aProgramDetails->g_pump_sq);
					$pumpTime		=	explode(",",$aProgramDetails->g_pump_time);
				}
				
				if(isset($aProgramDetails->g_rlb_valve_list) && $aProgramDetails->g_rlb_valve_list != '')
				{
					//Valve Device Details
					$valveDevice	=	explode(",",$aProgramDetails->g_rlb_valve_list);	
					$valveSequence	=	explode(",",$aProgramDetails->g_valve_sq);	
					$valveTime		=	explode(",",$aProgramDetails->g_valve_time);
				}

				if(isset($aProgramDetails->g_rlb_relay_list) && $aProgramDetails->g_rlb_relay_list != '')
				{
					//Relay Device Details
					$relayDevice	=	explode(",",$aProgramDetails->g_rlb_relay_list);	
					$relaySequence	=	explode(",",$aProgramDetails->g_relay_sq);	
					$relayTime		=	explode(",",$aProgramDetails->g_relay_time);				
				}
				
				if(isset($aProgramDetails->g_rlb_powercenter_list) && $aProgramDetails->g_rlb_powercenter_list != '')
				{
					//Relay Device Details
					$powerCenterDevice	=	explode(",",$aProgramDetails->g_rlb_powercenter_list);	
					$powerCenterSequence	=	explode(",",$aProgramDetails->g_powercenter_sq);	
					$powerCenterTime		=	explode(",",$aProgramDetails->g_powercenter_time);				
				}
								
				if(!empty($pumpSequence))
				{
					foreach($pumpSequence as $seq => $key)
					{
						if($key != '')
						{
							if(!array_key_exists($key,$arrSequnceDevice))
							$arrSequnceDevice[$key] = array();
							
							array_push($arrSequnceDevice[$key],$pumpDevice[$seq].'|||'.$pumpTime[$seq].'|||PS');
						}
						//$arrSequnceDevice[$seq] = $pumpDevice[$key].'|||'.$pumpTime[$key].'|||PS';
					}
				}
				
				//$valveSequence	=	array_flip($valveSequence);
				
				$arrAfterProgramDevice = array();
				$arrValveKeepOn		   = array();
				
				if(!empty($valveSequence))
				{
					
					$k = 1;
					foreach($valveSequence as $seq => $key)
					{
						if($key != '')
						{
							if(!array_key_exists($key,$arrSequnceDevice))
							$arrSequnceDevice[$key] = array();
						
							array_push($arrSequnceDevice[$key],$valveDevice[$seq].'|||'.$valveTime[$seq].'|||V');
							
							//Valve to run after program end.
							$arr	=	explode('_',$valveDevice[$seq]);
							$strPosition = '';
							if($arr[1] == 1)
							{
								$strPosition = 2;
							}
							else if($arr[1] == 2)
							{
								$strPosition = 1;
							}
							
							$arrTemp 			=	explode("_",$valveDevice[$seq]);
							$ipIDTemp			=	$arrTemp[0];
							$sStatusTemp		=	$arrTemp[1];
							$deviceNumberTemp	=	$arrTemp[2];
							
							$existingStatus 	=	${'sValves'.$ipIDTemp}[$deviceNumberTemp];
							
							$valveAfterProgram = $arr[0].'_'.$strPosition.'_'.$arr[2];
							
							if($existingStatus != $sStatusTemp)
							{
								$arrAfterProgramDevice[$k] = $valveAfterProgram.'|||'.$valveTime[$seq].'|||V';
								
								$k++;
							}
							else
							{
								$arrValveKeepOn[] = $ipIDTemp.'_'.$deviceNumberTemp;
							}
							
						}
						//array_push($arrAfterProgramDevice,$valveAfterProgram.'|||'.$valveTime[$seq].'|||V');
						
					}
				}
				
				if(!empty($relaySequence))
				{
					foreach($relaySequence as $seq => $key)
					{
						if($key != '')
						{
							if(!array_key_exists($key,$arrSequnceDevice))
							$arrSequnceDevice[$key] = array();
							
							array_push($arrSequnceDevice[$key],$relayDevice[$seq].'|||'.$relayTime[$seq].'|||R');
						}
					}
				}
				
				if(!empty($powerCenterSequence))
				{
					foreach($powerCenterSequence as $seq => $key)
					{
						if($key != '')
						{
							if(!array_key_exists($key,$arrSequnceDevice))
							$arrSequnceDevice[$key] = array();
							
							array_push($arrSequnceDevice[$key],$powerCenterDevice[$seq].'|||'.$powerCenterTime[$seq].'|||P');
						}
					}
				}
				
				ksort($arrSequnceDevice);
				ksort($arrAfterProgramDevice);
				
				//echo '<pre>';print_r($arrSequnceDevice);echo '</pre>';
				//die('STOP');
				$strContent = '';
				$currentDevice = $this->custom_model->getCustomProgrmaCurrentDevice($programID);
				
				//print_r($currentDevice);
				if($currentDevice != '')
				{
					foreach($currentDevice as $deviceDetails)
					{
						$sDeviceIP		= 	$this->home_model->getBoardIPFromID($deviceDetails->ip_id);
						
						$sRelayNameDb =  $this->home_model->getDeviceName($deviceDetails->device_number,$deviceDetails->device_type,$deviceDetails->ip_id);
						
						$time1      = new DateTime(date("H:i:s"));
						$time2      = new DateTime($deviceDetails->current_off_time);
						$interval   = $time2->diff($time1);
						$sTotalTime = $interval->format('%H:%I:%S');
						
						$strContent = $sRelayNameDb.'('.$deviceDetails->current_on_device.') - '.$sDeviceIP;
						$arrProgramDetails[$programID]['description'][] = $strContent.'|||'.$deviceDetails->current_on_time.'|||'.$deviceDetails->current_off_time.'|||'.$sTotalTime;
						
						$currentSeq		=	$deviceDetails->current_sequence;
					}
					
					$keys 	 = array_keys($arrSequnceDevice);
					$nextSeq = $keys[array_search($currentSeq,$keys)+1];
					
					if(isset($arrSequnceDevice[$nextSeq]) && $arrSequnceDevice[$nextSeq] != '')
					{
						foreach($arrSequnceDevice[$nextSeq] as $nextDevice)
						{
							$aCurrentDevice	=	explode('|||',$nextDevice);
							$sRunTime		=	$aCurrentDevice[1];
							$deviceType 	=   $aCurrentDevice[2];
							$aDevice		=	explode("_",$aCurrentDevice[0]);
							
							if($deviceType == 'V')
							{
								$ipID			=	$aDevice[0];
								$deviceNumber	=	$aDevice[2];
								$strName 		= 	'Valve '.$deviceNumber;
							}
							else if($deviceType == 'PS' || $deviceType == 'R' || $deviceType == 'P')
							{
								$ipID			=	$aDevice[0];
								$deviceNumber	=	$aDevice[1];
								if($deviceType == 'PS')
								$strName 		= 	'Pump '.$deviceNumber;
								if($deviceType == 'R')
								$strName 		= 	'Relay '.$deviceNumber;
								if($deviceType == 'P')
								$strName 		= 	'PowerCenter '.$deviceNumber;
							}
							
							$checkLog = $this->home_model->getDeviceRunLog($deviceNumber,$deviceType,$ipID,$programID,$unique_id);
							if($checkLog != '')
							{	
							}
							else
							{
								$sDeviceIP		= 	$this->home_model->getBoardIPFromID($ipID);
								$sRelayNameDb =  $this->home_model->getDeviceName($deviceNumber,$deviceType,$ipID);
									
								$arrProgramDetails[$programID]['nextdescription'][] = $sRelayNameDb.'('.$strName.') - '.$sDeviceIP;
							}
							
							
						}
					}
				}
				else
				{
					unset($arrProgramDetails);
				}
				//$arrProgramDetails[$programID]['description'] = 'Current On Device : '.$strContent;
			}
			//echo stripslashes(json_encode($arrProgramDetails));
		}
		
		$this->load->model('device_model');
		$arrAfterRunningProgramID = $this->device_model->getAllAfterRunningProgramID();
		if(!empty($arrAfterRunningProgramID))
		{
			foreach($arrAfterRunningProgramID as $ProgramID)
			{
				$aCurrentProgramDetails = $this->home_model->getCustomProgramDetails($ProgramID);
				foreach($aCurrentProgramDetails as $customProgram)
				{
					$aProgramDetails =	json_decode($customProgram->program_details);
					$programName	 =  trim(str_replace("_"," ",$aProgramDetails->g_custom_mode_name));
					$arrProgramDetails[$ProgramID]['Name'] 	= 'Name : '.$programName;
					$arrProgramDetails[$ProgramID]['After'] = 1;
				}
				
				$arrDevice = $this->device_model->selectRunningDeviceDetails($ProgramID);
				
				
				
				foreach($arrDevice as $key => $DeviceDetails)
				{
					$arrDeviceNumber=	explode("_",$key);
					$DeviceNumber	=	$arrDeviceNumber['0'];
					$DeviceIP		=	$arrDeviceNumber['1'];
					$sDeviceIP		= 	$this->home_model->getBoardIPFromID($DeviceIP);
					
					$sRelayNameDb 	=  $this->home_model->getDeviceName($DeviceNumber,$DeviceDetails['device_type'],$DeviceIP);
					
					$time1      = new DateTime(date("H:i:s"));
					$time2      = new DateTime($DeviceDetails['end_time']);
					$interval   = $time2->diff($time1);
					$sTotalTime = $interval->format('%H:%I:%S');
					
					$strDevice  = '';
					if($DeviceDetails['device_type'] == 'V')
						$strDevice  = 'Valve '.$DeviceNumber;
					else if($DeviceDetails['device_type'] == 'P')
						$strDevice  = 'Pump '.$DeviceNumber;
						
					$strContent = $sRelayNameDb.'('.$strDevice.') - '.$sDeviceIP;
					
					$arrProgramDetails[$ProgramID]['description'][] = $strContent.'|||'.$DeviceDetails['start_time'].'|||'.$DeviceDetails['end_time'].'|||'.$sTotalTime;
					
				} 
			}
		} 
		if($arrProgramDetails)
		{
			ksort($arrProgramDetails);
		}
		
		if(!empty($arrProgramDetails))
		{
			$aResponse['code']      = 1;
			$aResponse['status']    = $this->aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
			$aResponse['data']      = stripslashes(json_encode($arrProgramDetails));
			
			$this->webResponse($sformat, $aResponse);
			exit;
		}
		else
		{
			$aResponse['code']      = 5;
			$aResponse['status']    = $this->aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
			$aResponse['data']      = 'No Program is Running!';
			// Return Response.
			$this->webResponse($sformat, $aResponse);
			exit;
		}
	}
	
	/**
	* Function to Send the IP details.
	* @param
	* @return : If IP is changed then OLD IP and New IP.
	**/
	public function checkIPDetails()
	{
		// Set default HTTP response of 'ok'
		$aResponse              =   array();
		$aResponse['code']      =   0;
		$aResponse['status']    =   404;
		$aResponse['data']      =   NULL;
		$sformat                =   isset($_GET['format']) ? $_GET['format'] : '' ; // Get response Format (json,xml,html etc.)
		$sAuth                  =   isset($_GET['auth']) ? $_GET['auth'] : '' ;// Check if Authentication is required.
		$this->isAuthenticationRequired =   $sAuth;
			
		// Optionally require connections to be made via HTTPS
		if( $this->isHTTPSRequired && $_SERVER['HTTPS'] != 'on' )
		{
			$aResponse['code']      = 2;
			$aResponse['status']    = $aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
			$aResponse['data']      = $aApiResponseCode[ $aResponse['code'] ]['Message'];

			// Return Response to browser. This will exit the script.
			$this->webResponse($sformat, $aResponse);
		}
		
		if($this->isAuthenticationRequired)
		{
			//START : Authorisation
			$sUsername       = isset($_GET['username']) ? $_GET['username'] : '' ;   // Get the username of webservice 
			$sPassword       = isset($_GET['password']) ? $_GET['password'] : '' ;   // Get the password of webservice 
			$this->webAuthorisation($sUsername, $sPassword,$sformat); // Check if username and password is valid.
			// END : Authorisation
		}
		
		$arrResponse = array();
		$sSql   =   "SELECT ip_external,old_ip FROM rlb_setting WHERE id = '1' AND is_updated='1'";
        $query  =   $this->db->query($sSql);

        if ($query->num_rows() > 0)
        {
            foreach($query->result() as $rowResult)
            {
                $sDeviceNewIP = $rowResult->ip_external; 
                $sDeviceOldIP = $rowResult->old_ip; 
				
				$arrResponse['New'] = $sDeviceNewIP;
				$arrResponse['Old'] = $sDeviceOldIP;
            }
        }
		
		if($sDeviceNewIP == '' || $sDeviceOldIP == '')
		{
			$aResponse['code']      = 5;
			$aResponse['status']    = $this->aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
			$aResponse['data']      = 'There is Problem with IP!';
			// Return Response.
			$this->webResponse($sformat, $aResponse);
			exit;
		}
		
		$aResponse['code']      = 1;
		$aResponse['status']    = $this->aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
		$aResponse['data']      = stripslashes(json_encode($arrResponse));
		
		$this->webResponse($sformat, $aResponse);
		exit;
	}
	
	/**
	* Function to Send count of all on custom programs.
	* @param
	* @return : Count of On programs or blank.
	**/
	public function countofAllOnCustomPrograms()
	{
		// Set default HTTP response of 'ok'
		$aResponse              =   array();
		$aResponse['code']      =   0;
		$aResponse['status']    =   404;
		$aResponse['data']      =   NULL;
		$sformat                =   isset($_GET['format']) ? $_GET['format'] : '' ; // Get response Format (json,xml,html etc.)
		$sAuth                  =   isset($_GET['auth']) ? $_GET['auth'] : '' ;// Check if Authentication is required.
		$this->isAuthenticationRequired =   $sAuth;
			
		// Optionally require connections to be made via HTTPS
		if( $this->isHTTPSRequired && $_SERVER['HTTPS'] != 'on' )
		{
			$aResponse['code']      = 2;
			$aResponse['status']    = $aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
			$aResponse['data']      = $aApiResponseCode[ $aResponse['code'] ]['Message'];

			// Return Response to browser. This will exit the script.
			$this->webResponse($sformat, $aResponse);
		}
		
		if($this->isAuthenticationRequired)
		{
			//START : Authorisation
			$sUsername       = isset($_GET['username']) ? $_GET['username'] : '' ;   // Get the username of webservice 
			$sPassword       = isset($_GET['password']) ? $_GET['password'] : '' ;   // Get the password of webservice 
			$this->webAuthorisation($sUsername, $sPassword,$sformat); // Check if username and password is valid.
			// END : Authorisation
		}
		
		//START : Get Count of all On custom Programs.
		$this->load->model('home_model');
		$aAllOnPrograms = $this->home_model->getOnCustomProgram();
		
		$cntCustomProgram	=	0;
		
		if(!empty($aAllOnPrograms))
		{
			$cntCustomProgram	=	count($aAllOnPrograms);
		}
		else
		{
			$cntCustomProgram	=	0;
		}
		$aResponse['code']      = 1;
		$aResponse['status']    = $this->aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
		$aResponse['data']      = stripslashes($cntCustomProgram);
		
		$this->webResponse($sformat, $aResponse);
		exit;
	}
	
	/**
	* Function to Send Progress Bar details.
	* @param
	* @return : Count of On programs or blank.
	**/
	public function CustomProgramProgressBar()
	{
		// Set default HTTP response of 'ok'
		$aResponse              =   array();
		$aResponse['code']      =   0;
		$aResponse['status']    =   404;
		$aResponse['data']      =   NULL;
		$sformat                =   isset($_GET['format']) ? $_GET['format'] : '' ; // Get response Format (json,xml,html etc.)
		$sAuth                  =   isset($_GET['auth']) ? $_GET['auth'] : '' ;// Check if Authentication is required.
		$this->isAuthenticationRequired =   $sAuth;
			
		// Optionally require connections to be made via HTTPS
		if( $this->isHTTPSRequired && $_SERVER['HTTPS'] != 'on' )
		{
			$aResponse['code']      = 2;
			$aResponse['status']    = $aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
			$aResponse['data']      = $aApiResponseCode[ $aResponse['code'] ]['Message'];

			// Return Response to browser. This will exit the script.
			$this->webResponse($sformat, $aResponse);
		}
		
		if($this->isAuthenticationRequired)
		{
			//START : Authorisation
			$sUsername       = isset($_GET['username']) ? $_GET['username'] : '' ;   // Get the username of webservice 
			$sPassword       = isset($_GET['password']) ? $_GET['password'] : '' ;   // Get the password of webservice 
			$this->webAuthorisation($sUsername, $sPassword,$sformat); // Check if username and password is valid.
			// END : Authorisation
		}
		
		//START : Get Count of all On custom Programs.
		$this->load->model('home_model');
		
		$arrProgramDetails = array();
		$arrProgramDetails['empty'] = 0;
		//Get All On Program and Details.
		$aAllOnPrograms = $this->home_model->getOnCustomProgramForBar();
		
		if(!empty($aAllOnPrograms))
		{
			foreach($aAllOnPrograms as $customProgram)
			{
				$unique_id	=	$customProgram->unique_id;
				$programID	=	$customProgram->id;
				
				$aProgramDetails =	json_decode($customProgram->program_details);
				
				$maxRunTime		 =	$aProgramDetails->g_custom_max_time;
				$programStart	 =	$customProgram->program_start;	
				$programEnd		 =	$customProgram->program_end;
				$programName	 =  trim(str_replace("_"," ",$aProgramDetails->g_custom_mode_name));
				
				$arrProgramDetails[$programID]['Name'] = $programName;
				
				$time1     = new DateTime(date('Y-m-d H:i:s'));
				$time2     = new DateTime($programEnd);
				$interval  = $time2->diff($time1);
				$sTotalTime = $interval->format('%H:%I:%S');
								
				$arrProgramDetails[$programID]['EndTime'] = $sTotalTime;
				
				if(isset($aProgramDetails->g_rlb_pump_list) && $aProgramDetails->g_rlb_pump_list != '')
				{
					//Pump Device Details.
					$pumpDevice		=	explode(",",$aProgramDetails->g_rlb_pump_list);
					$pumpSequence	=	explode(",",$aProgramDetails->g_pump_sq);
					$pumpTime		=	explode(",",$aProgramDetails->g_pump_time);
				}
				
				if(isset($aProgramDetails->g_rlb_valve_list) && $aProgramDetails->g_rlb_valve_list != '')
				{
					//Valve Device Details
					$valveDevice	=	explode(",",$aProgramDetails->g_rlb_valve_list);	
					$valveSequence	=	explode(",",$aProgramDetails->g_valve_sq);	
					$valveTime		=	explode(",",$aProgramDetails->g_valve_time);
				}

				if(isset($aProgramDetails->g_rlb_relay_list) && $aProgramDetails->g_rlb_relay_list != '')
				{
					//Relay Device Details
					$relayDevice	=	explode(",",$aProgramDetails->g_rlb_relay_list);	
					$relaySequence	=	explode(",",$aProgramDetails->g_relay_sq);	
					$relayTime		=	explode(",",$aProgramDetails->g_relay_time);				
				}
				
				if(isset($aProgramDetails->g_rlb_powercenter_list) && $aProgramDetails->g_rlb_powercenter_list != '')
				{
					//Relay Device Details
					$powerCenterDevice	=	explode(",",$aProgramDetails->g_rlb_powercenter_list);	
					$powerCenterSequence	=	explode(",",$aProgramDetails->g_powercenter_sq);	
					$powerCenterTime		=	explode(",",$aProgramDetails->g_powercenter_time);				
				}
								
				if(!empty($pumpSequence))
				{
					foreach($pumpSequence as $seq => $key)
					{
						if($key != '')
						{
							if(!array_key_exists($key,$arrSequnceDevice))
							$arrSequnceDevice[$key] = array();
							
							array_push($arrSequnceDevice[$key],$pumpDevice[$seq].'|||'.$pumpTime[$seq].'|||PS');
						}
					}
				}
				
				//$valveSequence	=	array_flip($valveSequence);
				
				$arrAfterProgramDevice = array();
				$arrValveKeepOn		   = array();
				
				if(!empty($valveSequence))
				{
					
					$k = 1;
					foreach($valveSequence as $seq => $key)
					{
						if($key != '')
						{
							if(!array_key_exists($key,$arrSequnceDevice))
							$arrSequnceDevice[$key] = array();
						
							array_push($arrSequnceDevice[$key],$valveDevice[$seq].'|||'.$valveTime[$seq].'|||V');
						
						}
					}
				}
				
				if(!empty($relaySequence))
				{
					foreach($relaySequence as $seq => $key)
					{
						if($key != '')
						{
							if(!array_key_exists($key,$arrSequnceDevice))
							$arrSequnceDevice[$key] = array();
							
							array_push($arrSequnceDevice[$key],$relayDevice[$seq].'|||'.$relayTime[$seq].'|||R');
						}
					}
				}
				
				if(!empty($powerCenterSequence))
				{
					foreach($powerCenterSequence as $seq => $key)
					{
						if($key != '')
						{
							if(!array_key_exists($key,$arrSequnceDevice))
							$arrSequnceDevice[$key] = array();
							
							array_push($arrSequnceDevice[$key],$powerCenterDevice[$seq].'|||'.$powerCenterTime[$seq].'|||P');
						}
					}
				}
				
				ksort($arrSequnceDevice);
				
				$sTotalCustomProgramRunTime	= 0;
				$milestoneTime				= 0;
				$i=1;
				foreach($arrSequnceDevice as $device)
				{
					$strLabel= '';
					foreach($device as $deviceDetails)
					{
						$arrDeviceDetails 	=	explode('|||',$deviceDetails);
						$arrDevice		  	=	explode("_",$arrDeviceDetails[0]);
						
						$sDeviceIP			= 	$this->home_model->getBoardIPFromID($arrDevice[0]);
						
						$sRelayNameDb 		=	$this->home_model->getDeviceName($arrDevice[1],$arrDeviceDetails[2],$arrDevice[0]);
						
						if($sRelayNameDb == '')
						{
							$strTemp ='';
							if($arrDeviceDetails[2] == 'PS')
								$strTemp = 'Pump';
							if($arrDeviceDetails[2] == 'P')
								$strTemp = 'PowerCenter';
							if($arrDeviceDetails[2] == 'R')
								$strTemp = 'Relay';
							if($arrDeviceDetails[2] == 'V')
								$strTemp = 'Valve';
							$sRelayNameDb = $strTemp.' '.$arrDevice[1];
						}
						
						$strLabel 			.=   $sRelayNameDb.'('.$sDeviceIP.')<br>';
						
							
					}
					
					$arrProgramDetails[$programID]['milestone'][$i]['Lable'] = $strLabel;
					$arrProgramDetails[$programID]['milestone'][$i]['Time']	= $milestoneTime;
					
					foreach($device as $deviceDetails)
					{
						$arrDeviceDetails = explode('|||',$deviceDetails);
						$sTotalCustomProgramRunTime += $arrDeviceDetails[1];
						$milestoneTime+= $arrDeviceDetails[1];
						break;
					}
					
					$i++;
					
				}
				//$arrProgramDetails[$programID]['Device'] = $arrSequnceDevice;
				$arrProgramDetails[$programID]['TotalRunTime'] = $sTotalCustomProgramRunTime;
			}
		}
		else
		{
			$arrProgramDetails['empty'] = 1;
		}
		
		$aResponse['code']      = 1;
		$aResponse['status']    = $this->aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
		$aResponse['data']      = $arrProgramDetails;
		
		$this->webResponse($sformat, $aResponse);
		exit;
	}

	/**
	  * Function to Send the after program current running valve notifications for valve page.
	  * @param 
	  * @return
	**/
	public function afterProgramNotification()
	{
		// Set default HTTP response of 'ok'
		$aResponse              =   array();
		$aResponse['code']      =   0;
		$aResponse['status']    =   404;
		$aResponse['data']      =   NULL;
		$sformat                =   isset($_GET['format']) ? $_GET['format'] : '' ; // Get response Format (json,xml,html etc.)
		$sAuth                  =   isset($_GET['auth']) ? $_GET['auth'] : '' ;// Check if Authentication is required.
		$this->isAuthenticationRequired =   $sAuth;
			
		// Optionally require connections to be made via HTTPS
		if( $this->isHTTPSRequired && $_SERVER['HTTPS'] != 'on' )
		{
			$aResponse['code']      = 2;
			$aResponse['status']    = $aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
			$aResponse['data']      = $aApiResponseCode[ $aResponse['code'] ]['Message'];

			// Return Response to browser. This will exit the script.
			$this->webResponse($sformat, $aResponse);
		}
		
		if($this->isAuthenticationRequired)
		{
			//START : Authorisation
			$sUsername       = isset($_GET['username']) ? $_GET['username'] : '' ;   // Get the username of webservice 
			$sPassword       = isset($_GET['password']) ? $_GET['password'] : '' ;   // Get the password of webservice 
			$this->webAuthorisation($sUsername, $sPassword,$sformat); // Check if username and password is valid.
			// END : Authorisation
		}
		
		$this->load->model('home_model');
		$this->load->model('custom_model');
		$arrDetails = array();
		
		$arrAllAfterPrograms = $this->home_model->getAllAfterPrograms();
		if(!empty($arrAllAfterPrograms))
		{
			foreach($arrAllAfterPrograms as $afterProgram)
			{
				$ProgramID	=	$afterProgram->id;
				$UniqueID	=	$afterProgram->unique_id;
				$currentDevice = $this->custom_model->getCustomProgrmaAfterDevice($ProgramID);
				
				if(!empty($currentDevice))
				{
					foreach($currentDevice as $Device)
					{
						$DeviceNameTemp	= $Device->current_on_device;
						$DeviceType 	= $Device->device_type;
						$DeviceNum 		= $Device->device_number;
						$DeviceStart 	= $Device->current_on_time;
						$DeviceEnd 		= $Device->current_off_time;
						$DeviceSeq 		= $Device->current_sequence;
						$DeviceIP		= $Device->ip_id;
						
						//Get Device Name
						$DeviceName =  $this->home_model->getDeviceName($DeviceNum,$DeviceType,$DeviceIP);
						if($DeviceName == '')
							$strRelayName = $DeviceNameTemp;
						
						$arrDetails[] = $DeviceName.'|||'.$DeviceType.'|||'.$DeviceNum.'|||'.$DeviceStart.'|||'.$DeviceEnd.'|||'.$DeviceSeq.'|||'.$DeviceIP;
					}
				}
			}
			
			$aResponse['code']      = 1;
			$aResponse['status']    = $this->aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
			$aResponse['data']      = json_encode($arrDetails);
			
			$this->webResponse($sformat, $aResponse);
			exit;
		}
		else
		{
			$arrDetails[]			= "No after program is Running!";
			$aResponse['code']      = 1;
			$aResponse['status']    = $this->aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
			$aResponse['data']      = json_encode($arrDetails);
			
			$this->webResponse($sformat, $aResponse);
			exit;
		}
	}
	
	/**
	  * Function to check if the custom program is running or not..
	  * @param 
	  * @return Status of the custom program.
	**/
	public function sendCustomProgramRunning()
	{
		// Set default HTTP response of 'ok'
		$aResponse              =   array();
		$aResponse['code']      =   0;
		$aResponse['status']    =   404;
		$aResponse['data']      =   NULL;
		$sformat                =   isset($_GET['format']) ? $_GET['format'] : '' ; // Get response Format (json,xml,html etc.)
		$sAuth                  =   isset($_GET['auth']) ? $_GET['auth'] : '' ;// Check if Authentication is required.
		$this->isAuthenticationRequired =   $sAuth;
			
		// Optionally require connections to be made via HTTPS
		if( $this->isHTTPSRequired && $_SERVER['HTTPS'] != 'on' )
		{
			$aResponse['code']      = 2;
			$aResponse['status']    = $aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
			$aResponse['data']      = $aApiResponseCode[ $aResponse['code'] ]['Message'];

			// Return Response to browser. This will exit the script.
			$this->webResponse($sformat, $aResponse);
		}
		
		if($this->isAuthenticationRequired)
		{
			//START : Authorisation
			$sUsername       = isset($_GET['username']) ? $_GET['username'] : '' ;   // Get the username of webservice 
			$sPassword       = isset($_GET['password']) ? $_GET['password'] : '' ;   // Get the password of webservice 
			$this->webAuthorisation($sUsername, $sPassword,$sformat); // Check if username and password is valid.
			// END : Authorisation
		}
		
		$this->load->model('home_model');
		
		$programID = $_GET['id'];
		$programStatus = $this->home_model->getCustomProgramStatus($programID);
		$aResponse['code']      = 1;
		$aResponse['status']    = $this->aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
		$aResponse['data']      = $programStatus;
		
		$this->webResponse($sformat, $aResponse);
		exit;
	}
	
	/**
	  * Function to Send all On Custom Programs.
	  * @param 
	  * @return Status of the custom program.
	**/
	public function sendCustomOnProgramRunning()
	{
		// Set default HTTP response of 'ok'
		$aResponse              =   array();
		$aResponse['code']      =   0;
		$aResponse['status']    =   404;
		$aResponse['data']      =   NULL;
		$sformat                =   isset($_GET['format']) ? $_GET['format'] : '' ; // Get response Format (json,xml,html etc.)
		$sAuth                  =   isset($_GET['auth']) ? $_GET['auth'] : '' ;// Check if Authentication is required.
		$this->isAuthenticationRequired =   $sAuth;
			
		// Optionally require connections to be made via HTTPS
		if( $this->isHTTPSRequired && $_SERVER['HTTPS'] != 'on' )
		{
			$aResponse['code']      = 2;
			$aResponse['status']    = $aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
			$aResponse['data']      = $aApiResponseCode[ $aResponse['code'] ]['Message'];

			// Return Response to browser. This will exit the script.
			$this->webResponse($sformat, $aResponse);
		}
		
		if($this->isAuthenticationRequired)
		{
			//START : Authorisation
			$sUsername       = isset($_GET['username']) ? $_GET['username'] : '' ;   // Get the username of webservice 
			$sPassword       = isset($_GET['password']) ? $_GET['password'] : '' ;   // Get the password of webservice 
			$this->webAuthorisation($sUsername, $sPassword,$sformat); // Check if username and password is valid.
			// END : Authorisation
		}
		
		$this->load->model('home_model');
		
		$aAllOnPrograms = $this->home_model->getOnCustomProgram();
		
		$aResponse['code']      = 1;
		$aResponse['status']    = $this->aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
		$aResponse['data']      = $aAllOnPrograms;
		
		$this->webResponse($sformat, $aResponse);
		exit;
	}
	
	
	/**
	* Function to Check for the programs has valve same that is used in the Current ON program.
	* @param
	* @return : Program ID's.
	**/
	public function checkForProgramsHasValve()
	{
		// Set default HTTP response of 'ok'
		$aResponse              =   array();
		$aResponse['code']      =   0;
		$aResponse['status']    =   404;
		$aResponse['data']      =   NULL;
		$sformat                =   isset($_GET['format']) ? $_GET['format'] : '' ; // Get response Format (json,xml,html etc.)
		$sAuth                  =   isset($_GET['auth']) ? $_GET['auth'] : '' ;// Check if Authentication is required.
		$this->isAuthenticationRequired =   $sAuth;
			
		// Optionally require connections to be made via HTTPS
		if( $this->isHTTPSRequired && $_SERVER['HTTPS'] != 'on' )
		{
			$aResponse['code']      = 2;
			$aResponse['status']    = $aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
			$aResponse['data']      = $aApiResponseCode[ $aResponse['code'] ]['Message'];

			// Return Response to browser. This will exit the script.
			$this->webResponse($sformat, $aResponse);
		}
		
		if($this->isAuthenticationRequired)
		{
			//START : Authorisation
			$sUsername       = isset($_GET['username']) ? $_GET['username'] : '' ;   // Get the username of webservice 
			$sPassword       = isset($_GET['password']) ? $_GET['password'] : '' ;   // Get the password of webservice 
			$this->webAuthorisation($sUsername, $sPassword,$sformat); // Check if username and password is valid.
			// END : Authorisation
		}
		
		//Input Data
		$iGID	=	trim($_GET['id']);
		
		if($iGID == '')
		{
			$aResponse['code']      = 5;
			$aResponse['status']    = $this->aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
			$aResponse['data']      = 'Invalid Program ID!';
			// Return Response.
			$this->webResponse($sformat, $aResponse);
			exit;
		}
		
		$this->load->model('home_model');
		
		//Check if the device valve from the program is Used in another running program.
		$alreadyHasValve = '0';
		$aCurrentProgramDetails = 	$this->home_model->getCustomProgramDetails($iGID);
		$arrCurrentValve		=	array();
		if(!empty($aCurrentProgramDetails))
		{
			foreach($aCurrentProgramDetails as $currentProgram)
			{
				$aProgramDetails =	json_decode($currentProgram->program_details);
				$valveDevice	=	explode(",",$aProgramDetails->g_rlb_valve_list);
				
				foreach($valveDevice as $valve)
				{
					$tempValve			=	explode("_",$valve);
					$arrCurrentValve[] 	= 	$tempValve[0].'_'.$tempValve[2];
				}
					
			}
		}		
		$arrProgramID		 =	array();
		$arrGetOtherPrograms = $this->home_model->getOtherPrograms($iGID);
		
		if(!empty($arrGetOtherPrograms))
		{
			// Check If Valve is Running in any other Program.
			foreach($arrGetOtherPrograms as $OtherProgram)
			{
				$OtherProgramID		=	$OtherProgram->id;
				if(!in_array($OtherProgramID,$arrProgramID))
				{
					$aProgramDetails 	=	json_decode($OtherProgram->program_details);
					$OtherValveDevice	=	explode(",",$aProgramDetails->g_rlb_valve_list);
					
					$arrCheckValve		=	array();
					
					foreach($OtherValveDevice as $valve)
					{
						$tempValve	=	explode("_",$valve);
						$arrCheckValve[] = 	$tempValve[0].'_'.$tempValve[2];
					}
					
					foreach($arrCheckValve as $checkValve)
					{
						if(in_array($checkValve,$arrCurrentValve))
						{
							if(!in_array($OtherProgramID,$arrProgramID))
							{
								$arrProgramID[] = $OtherProgramID;
							}
							break;	
						}
					}
				}
			}
		}
			
		if(!empty($arrProgramID))
		{
			$aResponse['code']      = 1;
			$aResponse['status']    = $this->aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
			$aResponse['data']      = $arrProgramID;
			
			$this->webResponse($sformat, $aResponse);
			exit;
		}
		else
		{
			$aResponse['code']      = 1;
			$aResponse['status']    = $this->aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
			$aResponse['data']      = "No";
			
			$this->webResponse($sformat, $aResponse);
			exit;
		}
	}	
	
	/**
	* Function to Set the valve position depending on the mode selected By User.
	* @param
	* @return : 
	**/
	public function setValveModePosition()
	{
		// Set default HTTP response of 'ok'
		$aResponse              =   array();
		$aResponse['code']      =   0;
		$aResponse['status']    =   404;
		$aResponse['data']      =   NULL;
		$sformat                =   isset($_GET['format']) ? $_GET['format'] : '' ; // Get response Format (json,xml,html etc.)
		$sAuth                  =   isset($_GET['auth']) ? $_GET['auth'] : '' ;// Check if Authentication is required.
		$this->isAuthenticationRequired =   $sAuth;
			
		// Optionally require connections to be made via HTTPS
		if( $this->isHTTPSRequired && $_SERVER['HTTPS'] != 'on' )
		{
			$aResponse['code']      = 2;
			$aResponse['status']    = $aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
			$aResponse['data']      = $aApiResponseCode[ $aResponse['code'] ]['Message'];

			// Return Response to browser. This will exit the script.
			$this->webResponse($sformat, $aResponse);
		}
		
		if($this->isAuthenticationRequired)
		{
			//START : Authorisation
			$sUsername       = isset($_GET['username']) ? $_GET['username'] : '' ;   // Get the username of webservice 
			$sPassword       = isset($_GET['password']) ? $_GET['password'] : '' ;   // Get the password of webservice 
			$this->webAuthorisation($sUsername, $sPassword,$sformat); // Check if username and password is valid.
			// END : Authorisation
		}
		
		//Input Data
		$iGID	=	trim($_GET['id']);
		$Mode	=	trim($_GET['status']);
		
		if($iGID == '')
		{
			$aResponse['code']      = 5;
			$aResponse['status']    = $this->aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
			$aResponse['data']      = 'Invalid Program ID!';
			// Return Response.
			$this->webResponse($sformat, $aResponse);
			exit;
		}
		if($Mode == '')
		{
			$aResponse['code']      = 5;
			$aResponse['status']    = $this->aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
			$aResponse['data']      = 'Invalid Mode Selected!';
			// Return Response.
			$this->webResponse($sformat, $aResponse);
			exit;
		}
		else if($Mode != '0' && $Mode != '1')
		{
			$aResponse['code']      = 5;
			$aResponse['status']    = $this->aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
			$aResponse['data']      = 'Invalid Mode Selected!';
			// Return Response.
			$this->webResponse($sformat, $aResponse);
			exit;
		}
		
		$this->load->model('home_model');
		
		list($sIP,$sPort,$extra) = $this->home_model->getSettings();
		
		$programDetails = $this->home_model->getCustomProgramDetails($iGID);
		foreach($programDetails as $customProgram)
		{
			$aProgramDetails =	json_decode($customProgram->program_details);
			$previousState	 = 	unserialize($customProgram->previousState);
			
			if($Mode == '1')
			{
				foreach($previousState as $valveDevice)
				{
					$arrTemp 			=	explode("_",$valveDevice);
					$ipIDTemp			=	$arrTemp[0];
					$sStatusTemp		=	$arrTemp[1];
					$deviceNumberTemp	=	$arrTemp[2];
					
					$sDeviceIP			= 	$this->home_model->getBoardIPFromID($ipIDTemp);
					
					$shhPort	=	'';
					if(IS_LOCAL == '1')
					{
						//Get SSH port of the RLB board using IP.
						$shhPort = $this->home_model->getSSHPortFromID($ipIDTemp);
					}
					$sResponse		=	array();
					$sValves        =   ''; 
					
					//Get the status response of devices from relay board.
					$sResponse      =   get_rlb_status($sDeviceIP,$sPort,$shhPort);
					$sValves        =   $sResponse['valves']; // Valve Device Status
					
					$sNewResp = replace_return($sValves, $sStatusTemp, $deviceNumberTemp);
					onoff_rlb_valve($sNewResp,$sDeviceIP,$sPort,$shhPort);
					
					
				}
				
				$iMode = 2;
				$sManualTime	= $this->home_model->getManualModeTime();
				$this->home_model->updateMode($iMode);
					
				//If mode is manual then add the manual start time and end time calculated using the manual time(in minute) added on settings page.
				if($sManualTime != '')
				{
					$sProgramAbsStart 	=   date("Y-m-d H:i:s", time());
					$arrStart			=	explode(" ",$sProgramAbsStart);
					$aStartDate    		=   explode("-",$arrStart[0]);
					$aStartTime    		=   explode(":",$arrStart[1]);
					
					$sProgramAbsEnd   =   mktime($aStartTime[0],($aStartTime[1]+$sManualTime),$aStartTime[2],$aStartDate[1],$aStartDate[2],$aStartDate[0]);
					$sAbsoluteEnd     =   date("Y-m-d H:i:s", $sProgramAbsEnd);
					
					$this->home_model->updateManualModeTimer($sProgramAbsStart,$sAbsoluteEnd);
				}
				
				$this->home_model->removePreviousPositions($iGID);
			}
			else if($Mode == '0')
			{
				
				if(isset($aProgramDetails->g_rlb_valve_list) && $aProgramDetails->g_rlb_valve_list != '')
				{
					//Valve Device Details
					$valveDevice	=	explode(",",$aProgramDetails->g_rlb_valve_list);	
					$valveSequence	=	explode(",",$aProgramDetails->g_valve_sq);	
					$valveTime		=	explode(",",$aProgramDetails->g_valve_time);
				}
				
				$arrProgramValve	=	array();

				if(!empty($valveSequence))
				{
					foreach($valveSequence as $seq => $key)
					{
						array_push($arrProgramValve,$valveDevice[$seq]);
					}
				}
				
				if(!empty($arrProgramValve))
				{
					foreach($arrProgramValve as $valveDevice)
					{
						$arrTemp 			=	explode("_",$valveDevice);
						$ipIDTemp			=	$arrTemp[0];
						$sStatusTemp		=	$arrTemp[1];
						$deviceNumberTemp	=	$arrTemp[2];
						
						#START : GET Default Pool auto Position.
						$defaultPosition 	=	$this->home_model->getValveDefaultPosition($deviceNumberTemp,$ipIDTemp);
						
						$sDeviceIP		= 	$this->home_model->getBoardIPFromID($ipIDTemp);
						$shhPort	=	'';
						if(IS_LOCAL == '1')
						{
							//Get SSH port of the RLB board using IP.
							$shhPort = $this->home_model->getSSHPortFromID($ipIDTemp);
						}
						$sResponse		=	array();
						$sValves        =   ''; 
						$sRelays        =   '';  
						$sPump			=	'';	
						
						//Get the status response of devices from relay board.
						$sResponse      =   get_rlb_status($sDeviceIP,$sPort,$shhPort);
						$sValves        =   $sResponse['valves']; // Valve Device Status
						
						$sNewResp = replace_return($sValves, $defaultPosition, $deviceNumberTemp);
						$sValves = $sNewResp;
						onoff_rlb_valve($sNewResp,$sDeviceIP,$sPort,$shhPort);					
						#END : GET Default Pool auto Position.
						
						//START : INSERT THE VALVE DETAILS TO RUN VALVE FOR GIVEN TIME IN POOL MODE AUTO. IF TIME IS NOT SPECIFIED THEN IT WILL RUN FOR 1 MIN DEFAULT.
					
						$runTime = $this->home_model->getValveDefaultPositionTime($deviceNumberTemp,$ipIDTemp);
						if($runTime == 0)
						{
							$runTime = 1;
						}
						if($runTime == '')
						{
							$runTime = 1;
						}
								
						$arrValveDefaultRunDetails	=	array('program_id'=>$iGID,'valve'=>$deviceNumberTemp,'ip_id'=>$ipIDTemp,'runTime'=>$runTime);
						$this->home_model->insertValveDefaultRunDetails($arrValveDefaultRunDetails);
						
						//END : INSERT THE VALVE DETAILS TO RUN VALVE FOR GIVEN TIME IN POOL MODE AUTO. IF TIME IS NOT SPECIFIED THEN IT WILL RUN FOR 1 MIN DEFAULT.
					}
				}
			}
			
			//Remove the Previous Position of the valves.
			$this->home_model->removePreviousPositions($iGID);
		}
		
		$aResponse['code']      = 1;
		$aResponse['status']    = $this->aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
		$aResponse['data']      = "Selected Mode applied successfully!";
		
		$this->webResponse($sformat, $aResponse);
		exit;
	}
	
	/**
	* Function to Send the custom Program name.
	* @param
	* @return : 
	**/
	public function getCustomProgramName()
	{
		// Set default HTTP response of 'ok'
		$aResponse              =   array();
		$aResponse['code']      =   0;
		$aResponse['status']    =   404;
		$aResponse['data']      =   NULL;
		$sformat                =   isset($_GET['format']) ? $_GET['format'] : '' ; // Get response Format (json,xml,html etc.)
		$sAuth                  =   isset($_GET['auth']) ? $_GET['auth'] : '' ;// Check if Authentication is required.
		$this->isAuthenticationRequired =   $sAuth;
			
		// Optionally require connections to be made via HTTPS
		if( $this->isHTTPSRequired && $_SERVER['HTTPS'] != 'on' )
		{
			$aResponse['code']      = 2;
			$aResponse['status']    = $aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
			$aResponse['data']      = $aApiResponseCode[ $aResponse['code'] ]['Message'];

			// Return Response to browser. This will exit the script.
			$this->webResponse($sformat, $aResponse);
		}
		
		if($this->isAuthenticationRequired)
		{
			//START : Authorisation
			$sUsername       = isset($_GET['username']) ? $_GET['username'] : '' ;   // Get the username of webservice 
			$sPassword       = isset($_GET['password']) ? $_GET['password'] : '' ;   // Get the password of webservice 
			$this->webAuthorisation($sUsername, $sPassword,$sformat); // Check if username and password is valid.
			// END : Authorisation
		}
		
		//Input Data
		$ProgramID	=	trim($_GET['id']);
		
		if($ProgramID == '')
		{
			$aResponse['code']      = 5;
			$aResponse['status']    = $this->aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
			$aResponse['data']      = 'Invalid Program ID!';
			// Return Response.
			$this->webResponse($sformat, $aResponse);
			exit;
		}
		if(is_int($ProgramID))
		{
			$aResponse['code']      = 5;
			$aResponse['status']    = $this->aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
			$aResponse['data']      = 'Invalid Program ID!';
			// Return Response.
			$this->webResponse($sformat, $aResponse);
			exit;
		}
		
		$this->load->model('home_model');
		$arrProgramDetails = $this->home_model->getCustomProgramDetails($ProgramID);
			
		if(!empty($arrProgramDetails))
		{
			foreach($arrProgramDetails as $currentProgram)
			{
				$aCurrentDetails 	=	json_decode($currentProgram->program_details);
				$ProgramName	 	=	str_replace("_"," ",$aCurrentDetails->g_custom_mode_name);
				
				$aResponse['code']  =	1;
				$aResponse['status']=	$this->aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
				$aResponse['data']  =	$ProgramName;
				
				$this->webResponse($sformat, $aResponse);
				exit;
			}
		}
		else
		{
			$aResponse['code']      = 5;
			$aResponse['status']    = $this->aApiResponseCode[ $aResponse['code'] ]['HTTP Response'];
			$aResponse['data']      = 'No Program is available with given ID!';
			// Return Response.
			$this->webResponse($sformat, $aResponse);
			exit;
		}
	}
		
} //END : Class Web
    
    /* End of file web.php */
    /* Location: ./application/controllers/web.php */
?>
