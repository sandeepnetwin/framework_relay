<?php
/**
 *	Project : Relayboard 
 *	Program/Module Name : Device Controller 
 *	Author : Dhiraj S. 
 *	Creation Date : 28/06/2016 
 *	Description : Device related all functions.
 *	Modification History : 
 *	Change Date:  Name: 
**/
if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Device extends CI_Controller 
{
	//public $userID,$aPermissions,$aModules,$aAllActiveModule;

	public function __construct()  
	{
		parent::__construct();
		$this->load->library('form_validation');
		$this->load->helper('common_functions'); //Common functions will be available for all functions in the file.
		
		if (!$this->session->userdata('is_admin_login')) //START : Check if user login or not.
		{
			redirect('dashboard/login/');
			die;
		}  //END : Check if user login or not. 
		
		//Get Permission Details
		if($this->userID == '')
		$this->userID = $this->session->userdata('id');

		if($this->aPermissions == '')
		{
			$this->aPermissions 	= json_decode(getPermissionOfModule($this->userID));
			$this->aModules 		= $this->aPermissions->sPermissionModule;	
			$this->aAllActiveModule = $this->aPermissions->sActiveModule;
		}
		
		$this->load->model('home_model');
	}

	public function index() 
	{
		$aViewParameter         =   array(); // Array for passing parameter to view.
		$aViewParameter['page'] =   'Exclude Device'; 
		
		//Check if IP, PORT and Mode is set or not.
		list($sIpAddress, $sPortNo, $extra) = $this->home_model->getSettings();
		$aViewParameter['extra'] = $extra;
		$aViewParameter['sPort'] = $sPortNo;
		
		if($sIpAddress == '' && $sPortNo == '')
			redirect(site_url('home/setting/'));
		
		
		
		if($this->input->post('save') == 'Save Details')	
		{
			$arrDetails = array('R'=>$this->input->post('24VRelays'),
						   'P'=>$this->input->post('12VRelays'),
						   'V'=>$this->input->post('Valves'),
						   'PS'=>$this->input->post('Pumps'),
						   'H'=>$this->input->post('Heaters'),
						   'B'=>$this->input->post('Blowers'),
						   'L'=>$this->input->post('Lights'),
						   'M'=>$this->input->post('Miscs')
						   );
			$this->home_model->saveExcludeDevices($arrDetails);
		}
		
		$aViewParameter['excludeDevices'] = unserialize($this->home_model->getExcludeDevices());
		
		//GET IP and Board Name.
		$aViewParameter['aIPDetails'] = $this->home_model->getBoardIP();
		
		$sValveTemp1	=	'';
		$sValveTemp2	=	'';
		
		$t=1;
		//START : GET details for each IP.
		foreach($aViewParameter['aIPDetails'] as $IP)
		{
			$sResponse	= array();
			$sValves        =   '';
			$sRelays        =   '';
			$sPowercenter   =   '';
			$sTime          =   '';
			
			$shhPort	=	'';
			if(IS_LOCAL == '1')
			{
				//Get SSH port of the RLB board using IP.
				$shhPort = $this->home_model->getSSHPortFromID($IP->id);
			}
			
			//Get the status response of devices from relay board.
			$sResponse      =   get_rlb_status($IP->ip,$aViewParameter['sPort'],$shhPort);
			
		
			//Parameter for view
			$aViewParameter['response_'.$IP->id] =	$sResponse['response'];
			
			$sValves        =   $sResponse['valves']; // Valve Device Status
			$sRelays        =   $sResponse['relay'];  // Relay Device Status
			$sPowercenter   =   $sResponse['powercenter']; // Power Center Device Status
			$sTime          =   $sResponse['time']; // Server time from Response
			
			${"sValveTemp".$t} = $sValves;
			
			// Pump Device Status
			$sPump          =   array($sResponse['pump_seq_0_st'],$sResponse['pump_seq_1_st'],$sResponse['pump_seq_2_st']);
			// Temperature Sensor Device 
			$sTemprature    =   array($sResponse['TS0'],$sResponse['TS1'],$sResponse['TS2'],$sResponse['TS3'],$sResponse['TS4'],$sResponse['TS5']);

			//START : Parameter for View
			$aViewParameter['relay_count'.$IP->id]      =   strlen($sRelays);
			$aViewParameter['valve_count'.$IP->id]      =   strlen($sValves);
			$aViewParameter['power_count'.$IP->id]      =   strlen($sPowercenter);
			$aViewParameter['time'.$IP->id]             =   $sTime;
			//$aViewParameter['pump_count'.$IP->id]       =   count($sPump);
			
			$aViewParameter['ValveRelays'.$IP->id]	=	$this->home_model->getAllValvesHavingRelays($IP->id);
			
			if($IP->id == 1)
			{
				$aViewParameter['pump_count'.$IP->id] = $aViewParameter['extra']['PumpsNumber'];
			}
			else if($IP->id > 1)
			{
				$aViewParameter['pump_count'.$IP->id] = $aViewParameter['extra']['PumpsNumber2'];
			}
			
			
			for($i=1;$i<=$aViewParameter['pump_count'.$IP->id];$i++)
			{
				$aViewParameter['PumpValve'.$i.'_'.$IP->id] = $this->home_model->getPumpValve($i,$sValveTemp1,$sValveTemp2,$IP->id);
					
			}
			
			
			$aViewParameter['temprature_count'.$IP->id] =   count($sTemprature);

			$aViewParameter['sRelays'.$IP->id]          =   $sRelays; 
			$aViewParameter['sPowercenter'.$IP->id]     =   $sPowercenter;
			$aViewParameter['sValves'.$IP->id]          =   $sValves;
			$aViewParameter['Pumps'.$IP->id]		=	$this->home_model->getAllPumps($IP->id);
			
			if($aViewParameter['Pumps'.$IP->id] > 0)
			{
				$sPump	=	array();
				foreach($aViewParameter['Pumps'.$IP->id] as $pump)
				{
					$sPump[$pump->pump_number] = $pump->status;
					
				}
				$aViewParameter['sPump'.$IP->id]            =   $sPump;
			}
			else
			{
				for($i=1;$i<=$aViewParameter['pump_count'.$IP->id];$i++)
				{
					$sPump[$i] = 0;
				}
				$aViewParameter['sPump'.$IP->id]            =   $sPump;
			}
			
			
			$t++;
		}
		//END : GET details for each IP.
		
		$this->template->build('excludeDevice',$aViewParameter);
	}
	
	public function SaveExcludeDevice() 
	{
		$DeviceType = $this->input->post('DeviceType');
		$ExcludeDevices = $this->input->post('Device');
	}
	
	public function customProgram()
	{
		$aViewParameter         =   array(); // Array for passing parameter to view.
		$aViewParameter['page'] =   'Custom Programs'; 
		$this->load->model('device_model');
		
		$aViewParameter['msg']  	= '';
		$aViewParameter['errmsg']	= '';
		
		if($this->session->flashdata('success_msg_add') != '')
			$aViewParameter['msg'] = $this->session->flashdata('success_msg_add');
		if($this->session->flashdata('success_msg_edit') != '')
			$aViewParameter['msg'] = $this->session->flashdata('success_msg_edit');
		if($this->session->flashdata('err_msg_delete') != '')
			$aViewParameter['errmsg'] = $this->session->flashdata('err_msg_delete');
		
		$aViewParameter['allCustomPrograms'] = $this->device_model->getAllCustomPrograms();
		
		$this->template->build('customProgram',$aViewParameter);
	}

	public function changeCustomProgramDisplay()
	{
		$customProgramID = $this->input->post('customProgramID');
		$status   		 = $this->input->post('status');
		
		$this->load->model('device_model');
		
		$this->device_model->changeCustomProgramDisplay($customProgramID,$status);
		
		echo $status;
		exit;
	}

	public function addeditCustomProgram()
	{
		$aViewParameter         =   array(); // Array for passing parameter to view.
		$aViewParameter['page'] =   'Create Custom Programs';
		
		$this->load->model('device_model');
		$customProgramID = base64_decode($this->uri->segment("3"));
		if($customProgramID != '')
		{
			$aViewParameter['customProgramID'] = $customProgramID;
			$aViewParameter['customProgram']   = $this->device_model->getCustomProgramDetails($customProgramID);
		}
		if($this->input->post('command'))
		{
			$customProgramName = trim($this->input->post('customProgramName'));
			$customProgramTime = $this->input->post('customProgramTime');
			$customPumps	   = $this->input->post('customPumps');
			$customValves	   = $this->input->post('customValves');
			$customRelays	   = $this->input->post('customRelays');
			$customPowers	   = $this->input->post('customPowers');
			
			$customProgramStart	= '';
			$customProgramEnd	= '';
			$isSchedule		   	= $this->input->post('isSchedule');
			$sProgramType   	= $this->input->post('sProgramType');
			$sProgramDays   	=   '0';

			if($sProgramType == '2')
			{
				$sProgramDays   =   $this->input->post('sProgramDays');
				$sProgramDays   =   implode(',',$sProgramDays);
			}
			if($isSchedule == '1')
			{
				$customProgramStart	= $this->input->post('sStartTime').":00";
				$customProgramEnd	= $this->input->post('sEndTime').":00";
			}
			
			$ProgramTypeStartTime	= $this->input->post('ProgramTypeStartTime').":00";
			$ProgramTypeEndTime		= $this->input->post('ProgramTypeEndTime').":00";
			
			$arrCustomProgram  = array('g_id'=>1,
									   'g_custom_mode_name'=>$customProgramName,
									   'g_custom_max_time'=>$customProgramTime,
									   'relayboardProgram'=>'1',
									   'isSchedule'=>'1'
									  );
			$arrList	   = array();		
			$arrSeq	   	   = array();		
			$arrTime	   = array();		
			foreach($customPumps as $pumps)
			{
				$arrList[] = $pumps;
				$arrSeq[]  = $this->input->post('sequence_'.$pumps.'_PS');
				$arrTime[] = $this->input->post('time_'.$pumps.'_PS');
			}
			
			$arrCustomProgram['g_rlb_pump_list']  	= implode(",",$arrList);
			$arrCustomProgram['g_pump_sq']  		= implode(",",$arrSeq);
			$arrCustomProgram['g_pump_time']  		= implode(",",$arrTime);
			
			$arrList	   = array();		
			$arrSeq	   	   = array();		
			$arrTime	   = array();		
			foreach($customValves as $valve)
			{
				$arrList[] = $valve;
				$arrSeq[]  = $this->input->post('sequence_'.$valve.'_V');
				$arrTime[] = $this->input->post('time_'.$valve.'_V');
			}
			
			$arrCustomProgram['g_rlb_valve_list']  	= implode(",",$arrList);
			$arrCustomProgram['g_valve_sq']  		= implode(",",$arrSeq);
			$arrCustomProgram['g_valve_time']  		= implode(",",$arrTime);
			
			$arrList	   = array();		
			$arrSeq	   	   = array();		
			$arrTime	   = array();		
			foreach($customRelays as $relay)
			{
				$arrList[] = $relay;
				$arrSeq[]  = $this->input->post('sequence_'.$relay.'_R');
				$arrTime[] = $this->input->post('time_'.$relay.'_R');
			}
			
			$arrCustomProgram['g_rlb_relay_list']  	= implode(",",$arrList);
			$arrCustomProgram['g_relay_sq']  		= implode(",",$arrSeq);
			$arrCustomProgram['g_relay_time']  		= implode(",",$arrTime);
			
			$arrList	   = array();		
			$arrSeq	   	   = array();		
			$arrTime	   = array();		
			foreach($customPowers as $power)
			{
				$arrList[] = $power;
				$arrSeq[]  = $this->input->post('sequence_'.$power.'_P');
				$arrTime[] = $this->input->post('time_'.$power.'_P');
			}
			
			$arrCustomProgram['g_rlb_powercenter_list']  	= implode(",",$arrList);
			$arrCustomProgram['g_powercenter_sq']  			= implode(",",$arrSeq);
			$arrCustomProgram['g_powercenter_time']  		= implode(",",$arrTime);
			
			if($customProgramID != '')
			{
				$this->device_model->updateCustomProgram($customProgramID,json_encode($arrCustomProgram),$isSchedule,$customProgramStart,$customProgramEnd,$sProgramType,$sProgramDays,$ProgramTypeStartTime,$ProgramTypeEndTime);
				$this->session->set_flashdata('success_msg_edit', 'Custom Program Details Updated Successfully!');
			}
			else
			{
				$this->device_model->saveCustomProgram(json_encode($arrCustomProgram),$isSchedule,$customProgramStart,$customProgramEnd,$sProgramType,$sProgramDays,$ProgramTypeStartTime,$ProgramTypeEndTime);
				$this->session->set_flashdata('success_msg_add', 'Custom Program Details Added Successfully!');
			}
			redirect('device/customProgram');
			exit;
		}
		
		//Get All IP Details.
		$aViewParameter['aIPDetails'] = $this->home_model->getBoardIP();
		
		list($sIP,$sPort,$extra) = $this->home_model->getSettings();
		$aViewParameter['extraDetails'] = $extra;
		
		$aResponseDetails		= array();
		
		foreach($aViewParameter['aIPDetails'] as $IP)
		{
			$shhPort	=	'';
			if(IS_LOCAL == '1')
			{
				//Get SSH port of the RLB board using IP.
				$shhPort = $this->home_model->getSSHPortFromID($IP->id);
			}
			$sResponse		=	array();
			$sValves        =   ''; 
			$sRelays        =   '';  
			$sPowercenter   =   ''; 
			$sTime          =   '';
			$sPump			=	'';	
			$sTemprature	=	'';
			
			//Get the status response of devices from relay board.
			$sResponse      =   get_rlb_status($IP->ip,$sPort,$shhPort);
		
			$sValves        =   $sResponse['valves']; // Valve Device Status
			$sRelays        =   $sResponse['relay'];  // Relay Device Status
			$sPowercenter   =   $sResponse['powercenter']; // Power Center Device Status
				
			$iIPID 			=	$IP->id;
			
			$sDevice  = "R";
			$iCount=strlen($sRelays);
			
			for($i=0; $i<$iCount; $i++)
			{
				$relay = $sRelays[$i] ;
				
				if($relay != '.' && $relay != '')
				{
					$name = $this->home_model->getDeviceName($i,$sDevice,$iIPID);
										
					if($name == '')
						$name = 'Relay '.$i;
					
					$aResponseDetails[$IP->id][$sDevice][$i] = $name;
				}
				else
				{
					$aResponseDetails[$IP->id][$sDevice][$i] = '.';
				}
				
				//START : Check if Device is Heater and Has Pump.
				if($relay == '.')
					$aResponseDetails[$IP->id][$sDevice][$i] .= '|||0';
				else
				{
					$PumpNumber = $this->device_model->checkRelayAssignedToHeater($IP->id,$i,12);
					$aResponseDetails[$IP->id][$sDevice][$i] .= '|||'.$PumpNumber;	
				}
				//END : Check if Device is Heater and Has Pump.
			}
			
			$sDevice = "P";
			$iCount=strlen($sPowercenter);
			
			for($i=0; $i<$iCount; $i++)
			{
				$name = $this->home_model->getDeviceName($i,$sDevice,$iIPID);
										
				if($name == '')
					$name = 'PowerCenter '.$i;
					
				$aResponseDetails[$IP->id][$sDevice][$i] = $name;
				
				//START : Check if Device is Heater and Has Pump.
				$PumpNumber = $this->device_model->checkRelayAssignedToHeater($IP->id,$i,12);
				
				$aResponseDetails[$IP->id][$sDevice][$i] .= '|||'.$PumpNumber;
				//END : Check if Device is Heater and Has Pump.
			}
		
			$sDevice = "V";
			$iCount=strlen($sValves);
			
			for($i=0; $i<$iCount; $i++)
			{
				$relay = $sValves[$i] ;
				
				if($relay != '.' && $relay != '')
				{
					$name = $this->home_model->getDeviceName($i,$sDevice,$iIPID);
					
					//START : Get Valve Position Details.
					$aPositionName   =  $this->home_model->getPositionName($i,$sDevice,$iIPID);
					
					$strPosition1 = '';
					$strPosition2 = '';
					
					if($aPositionName[0] != '')
					$strPosition1	 =	$this->home_model->getPositionNameFromID($aPositionName[0]);
					if($aPositionName[1] != '')
					$strPosition2	 =	$this->home_model->getPositionNameFromID($aPositionName[1]);
					//END : Get Valve Position Details.
										
					if($name == '')
						$name = 'Valve '.$i;
					
					$aResponseDetails[$IP->id][$sDevice][$i] = array($name,$strPosition1,$strPosition2);
				}
				else
				{
					$aResponseDetails[$IP->id][$sDevice][$i] = '.';
				}
			}
		
			$sDevice = "PS";
			//$iCount=count($sPump);
			if($iIPID == 1)
				$iCount=$extra['PumpsNumber'];
			else if($iIPID > 1)
				$iCount=$extra['PumpsNumber2'];	
			
			
			for($i=1; $i<=$iCount; $i++)
			{
				$name = $this->home_model->getDeviceName($i,$sDevice,$iIPID);
				
				//Check If Configuration is available or not.
				$check = $this->home_model->checkConfiguration($i,$sDevice,$iIPID);
				
				if($check == '1')
				{
					if($name == '')
						$name = 'Pump '.$i;
						
					$aResponseDetails[$IP->id][$sDevice][$i] = $name;
				}
			}
		
			$sDevice = "L";
			//$iCount = $extra['LightNumber'];
			if($iIPID == 1)
				$iCount=$extra['LightNumber'];
			else if($iIPID > 1)
				$iCount=$extra['LightNumber2'];
			
			for($i=0;$i<$iCount;$i++)
			{
				$name = $this->home_model->getDeviceName($i,$sDevice,$iIPID);
										
				if($name == '')
					$name = 'Light '.$i;
					
				$aResponseDetails[$IP->id][$sDevice][$i] = $name;
			}
		
			//$iCount = $extra['HeaterNumber'];
			$sDevice = "H";
			if($iIPID == 1)
				$iCount=$extra['HeaterNumber'];
			else if($iIPID > 1)
				$iCount=$extra['HeaterNumber2'];
			
			for($i=0;$i<$iCount;$i++)
			{
				$name = $this->home_model->getDeviceName($i,$sDevice,$iIPID);
										
				if($name == '')
					$name = 'Heater '.$i;
					
				$aResponseDetails[$IP->id][$sDevice][$i] = $name;
			}
		
			$sDevice = "B";
			//$iCount = $extra['BlowerNumber'];
			if($iIPID == 1)
				$iCount=$extra['BlowerNumber'];
			else if($iIPID > 1)
				$iCount=$extra['BlowerNumber2'];
			
			for($i=0;$i<$iCount;$i++)
			{
				$name = $this->home_model->getDeviceName($i,$sDevice,$iIPID);
										
				if($name == '')
					$name = 'Blower '.$i;
					
				$aResponseDetails[$IP->id][$sDevice][$i] = $name;
			}
		
			//$iCount = $extra['MiscNumber'];
			$sDevice = "M";
			if($iIPID == 1)
				$iCount=$extra['MiscNumber'];
			else if($iIPID > 1)
				$iCount=$extra['MiscNumber2'];
			for($i=0;$i<$iCount;$i++)
			{
				$name = $this->home_model->getDeviceName($i,$sDevice,$iIPID);
										
				if($name == '')
					$name = 'Misc '.$i;
					
				$aResponseDetails[$IP->id][$sDevice][$i] = $name;
			}
			
		}
		$aViewParameter['deviceDetails'] = $aResponseDetails;
		$this->template->build("addEditCustomProgram",$aViewParameter);
	}

	public function deleteCustomProgram()
	{
		$this->load->model('device_model');
		$this->load->model('custom_model');
		$customProgramID = base64_decode($this->uri->segment("3"));
		
		if($customProgramID == '')
		{
			$this->session->set_flashdata('err_msg_delete', 'Please select Custom program!');
			redirect('device/customProgram');
			exit;
		}
		
		//START : Check if Program is Running if it is running then first stop all Devices related to program.
		//First Check if that program is already ON.
		$sStatus = $this->home_model->chkCustomProgram($customProgramID);
		if($sStatus == '1')
		{
			$programDetails = $this->home_model->getCustomProgramDetails($customProgramID);
			
			foreach($programDetails as $customProgram)
			{
				$aProgramDetails =	json_decode($customProgram->program_details);
				$previousState	 = 	unserialize($customProgram->previousState);
				
				if(isset($aProgramDetails->g_rlb_valve_list) && $aProgramDetails->g_rlb_valve_list != '')
				{
					//Valve Device Details
					$valveDevice	=	explode(",",$aProgramDetails->g_rlb_valve_list);	
					$valveSequence	=	explode(",",$aProgramDetails->g_valve_sq);	
					$valveTime		=	explode(",",$aProgramDetails->g_valve_time);
				}

				$arrAfterProgramDevice = array();
				if(!empty($valveSequence))
				{
					$k = 1;
					foreach($valveSequence as $seq => $key)
					{
						if(!array_key_exists($key,$arrSequnceDevice))
						$arrSequnceDevice[$key] = array();
					}
				}
			}
			$afterProgram	=	0;
			//Stop Custom Program.
			$this->home_model->stopCustomProgram($customProgramID,$afterProgram);
			
			$currentDevice = $this->custom_model->getCustomProgrmaCurrentDevice($customProgramID);
			
			if($currentDevice != '')
			{
				foreach($currentDevice as $deviceDetails)
				{
					$currentSeq		=	$deviceDetails->current_sequence;
					$deviceType 	=   $deviceDetails->device_type;
					$ipID			=	$deviceDetails->ip_id;
					$sStatus		=	0;
					$deviceNumber	=	$deviceDetails->device_number;
					
					$sDeviceIP		= 	$this->home_model->getBoardIPFromID($ipID);
					list($sIP,$sPort,$extra) = $this->home_model->getSettings();
							
					$shhPort	=	'';
					if(IS_LOCAL == '1')
					{
						//Get SSH port of the RLB board using IP.
						$shhPort = $this->home_model->getSSHPortFromID(ipID);
					}
					$sResponse		=	array();
					$sValves        =   ''; 
					$sRelays        =   '';  
					$sPump			=	'';	
					
					//Get the status response of devices from relay board.
					$sResponse      =   get_rlb_status($sDeviceIP,$sPort,$shhPort);
				
					$sValves        =   $sResponse['valves']; // Valve Device Status
					$sRelays        =   $sResponse['relay'];  // Relay Device Status
					$sPowerCenter   =   $sResponse['powercenter']; // Power Center Device Status
					
					${'sPump'.$IP->id}	=	array($sResponse['pump_seq_0_st'],$sResponse['pump_seq_1_st'],$sResponse['pump_seq_2_st']);
					
					if($deviceType == 'V')
					{
						$sNewResp = replace_return($sValves, $sStatus, $deviceNumber);
						$sValves = $sNewResp;
						onoff_rlb_valve($sNewResp,$sDeviceIP,$sPort,$shhPort);
					}
					else if($deviceType == 'PS')
					{	
						$this->deviceMakePumpOnOFF($deviceNumber,$sStatus,$sDeviceIP,$sPort,$shhPort,$ipID);
					}
					else if($deviceType	== 'R')
					{
						$sNewResp = replace_return($sRelays, $sStatus, $deviceNumber);
						$sRelays = $sNewResp;
						onoff_rlb_relay($sNewResp,$sDeviceIP,$sPort,$shhPort);
						
						//START : Check if heater is assigned to that relay.
						$heaterNum = $this->home_model->chkHeater($deviceNumber,'24',$ipID);
						
						if($heaterNum != '')
						{
							$aHeaterDetails  =   $this->home_model->getHeaterDeviceDetails($heaterNum,$ipID);
							if(!empty($aHeaterDetails))
							{
								foreach($aHeaterDetails as $aHeater)
								$sHeaterDetails  =   unserialize($aHeater->light_relay_number);
								
								$PumpNumber   		=   $sHeaterDetails['Pump'];
							}
							if($PumpNumber != '')
							{
								$aPumpDetails =	$this->home_model->getPumpDetails($PumpNumber,$ipID);
								if(!empty($aPumpDetails))
								{
									foreach($aPumpDetails as $sPump)
									{
										$heaterStopTime =	date('Y-m-d H:i:s');
										$arrStopTime	=	explode(" ",$heaterStopTime);
										$aDate     		=   explode("-",$arrStopTime[0]);
										$aTime     		=   explode(":",$arrStopTime[1]);
										
										$sProgramAbsEnd =   mktime(($aTime[0]),($aTime[1]+5),($aTime[2]),$aDate[1],$aDate[2],$aDate[0]);
										$pumpStopTime   =   date("Y-m-d H:i:s", $sProgramAbsEnd);
										
										$this->home_model->updateRunAfterHeaterDetails($heaterNum,$sPump->pump_number,$heaterStopTime,$pumpStopTime,$ipID,$customProgramID);
									}
								}
							}
						}
					}
					else if($deviceType	== 'P')
					{
						$sNewResp = replace_return($sPowerCenter, $sStatus, $deviceNumber);
						$sPowerCenter = $sNewResp;
						onoff_rlb_powercenter($sNewResp,$sDeviceIP,$sPort,$shhPort);
						
						//START : Check if heater is assigned to that relay.
						$heaterNum = $this->home_model->chkHeater($deviceNumber,'12',$ipID);
						
						if($heaterNum != '')
						{
							$aHeaterDetails  =   $this->home_model->getHeaterDeviceDetails($heaterNum,$ipID);
							if(!empty($aHeaterDetails))
							{
								foreach($aHeaterDetails as $aHeater)
								$sHeaterDetails  =   unserialize($aHeater->light_relay_number);
								
								$PumpNumber   		=   $sHeaterDetails['Pump'];
							}
							if($PumpNumber != '')
							{
								$aPumpDetails =	$this->home_model->getPumpDetails($PumpNumber,$ipID);
								if(!empty($aPumpDetails))
								{
									foreach($aPumpDetails as $sPump)
									{
										$heaterStopTime =	date('Y-m-d H:i:s');
										$arrStopTime	=	explode(" ",$heaterStopTime);
										$aDate     		=   explode("-",$arrStopTime[0]);
										$aTime     		=   explode(":",$arrStopTime[1]);
										
										$sProgramAbsEnd =   mktime(($aTime[0]),($aTime[1]+5),($aTime[2]),$aDate[1],$aDate[2],$aDate[0]);
										$pumpStopTime   =   date("Y-m-d H:i:s", $sProgramAbsEnd);
										
										$this->home_model->updateRunAfterHeaterDetails($heaterNum,$sPump->pump_number,$heaterStopTime,$pumpStopTime,$ipID,$customProgramID);
									}
								}
							}
						}
					}
					
					//Insert Entry in the Log Table for future Reference.
					$this->custom_model->saveCustomEntryInLog($customProgramID,$deviceType);
					
					//Delete Entry From the current details Table.
					$this->custom_model->deleteCustomEntryFromCurrent($customProgramID,$deviceType,$deviceNumber);
				}
			}
		}
		//END : Check if Program is Running if it is running then first stop all Devices related to program.
		
		$this->device_model->deleteCustomProgram($customProgramID);
		$this->session->set_flashdata('success_msg_edit', 'Custom Program Details Deleted Successfully!');
		redirect('device/customProgram');
		exit;
	}

	public function systemOperation()
	{
		$aViewParameter['page']         =   'home';
		
		if($this->input->post('iMode') != '')
		{
			$iMode = $this->input->post('iMode');
			
			if($iMode == '1')
			{
				shell_exec('sudo reboot');
			}
			else if($iMode == '2')
			{
				//shell_exec('sudo shutdown -h now');
				//shell_exec('sudo poweroff');
			}
		}
		
		$this->template->build('ShutdownReboot',$aViewParameter);
	}
	
	public function runCustomProgramTest()
	{
		$this->load->model('custom_model');
		$customProgramID = base64_decode($this->uri->segment("3"));
		
		if($customProgramID == '')
		{
			$this->session->set_flashdata('err_msg_delete', 'Please select Custom program!');
			redirect('device/customProgram');
			exit;
		}
		
		$aCurrentProgramDetails = $this->home_model->getCustomProgramDetails($customProgramID);
		if(!empty($aCurrentProgramDetails))
		{
			foreach($aCurrentProgramDetails as $currentProgram)
			{
				$aCurrentDetails 	=	json_decode($currentProgram->program_details);
				$CurrentValveDevice	=	explode(",",$aCurrentDetails->g_rlb_valve_list);
				$afterProgram	 	=	$currentProgram->afterProgram;
				
				//START : Get the first device of the custom program from all Devices.
				if(isset($aCurrentDetails->g_rlb_pump_list) && $aCurrentDetails->g_rlb_pump_list != '')
				{
					//Pump Device Details.
					$pumpDevice		=	explode(",",$aCurrentDetails->g_rlb_pump_list);
					$pumpSequence	=	explode(",",$aCurrentDetails->g_pump_sq);
					$pumpTime		=	explode(",",$aCurrentDetails->g_pump_time);
				}
				
				if(isset($aCurrentDetails->g_rlb_valve_list) && $aCurrentDetails->g_rlb_valve_list != '')
				{
					//Valve Device Details
					$valveDevice	=	explode(",",$aCurrentDetails->g_rlb_valve_list);	
					$valveSequence	=	explode(",",$aCurrentDetails->g_valve_sq);	
					$valveTime		=	explode(",",$aCurrentDetails->g_valve_time);
				}
				
				if(isset($aCurrentDetails->g_rlb_relay_list) && $aCurrentDetails->g_rlb_relay_list != '')
				{
					//Relay Device Details
					$relayDevice	=	explode(",",$aCurrentDetails->g_rlb_relay_list);	
					$relaySequence	=	explode(",",$aCurrentDetails->g_relay_sq);	
					$relayTime		=	explode(",",$aCurrentDetails->g_relay_time);				
				}
				
				if(isset($aCurrentDetails->g_rlb_powercenter_list) && $aCurrentDetails->g_rlb_powercenter_list != '')
				{
					//Relay Device Details
					$powerCenterDevice	=	explode(",",$aCurrentDetails->g_rlb_powercenter_list);	
					$powerCenterSequence	=	explode(",",$aCurrentDetails->g_powercenter_sq);	
					$powerCenterTime		=	explode(",",$aCurrentDetails->g_powercenter_time);				
				}
								
				if(!empty($pumpSequence))
				{
					foreach($pumpSequence as $seq => $key)
					{
						if($key != '')
						{
							if(!array_key_exists($key,$arrSequnceDevice))
							$arrSequnceDevice[$key] = array();
							
							array_push($arrSequnceDevice[$key],$pumpDevice[$seq].'|||'.$pumpTime[$seq].'|||PS');
						}
					}
				}
				
				//$valveSequence	=	array_flip($valveSequence);
				
				$arrAfterProgramDevice = array();
				
				if(!empty($valveSequence))
				{
					$k = 1;
					foreach($valveSequence as $seq => $key)
					{
						if($key != '')
						{
							if(!array_key_exists($key,$arrSequnceDevice))
							$arrSequnceDevice[$key] = array();
						
							array_push($arrSequnceDevice[$key],$valveDevice[$seq].'|||'.$valveTime[$seq].'|||V');
							
							//Valve to run after program end.
							$arr	=	explode('_',$valveDevice[$seq]);
							$strPosition = '';
							if($arr[1] == 1)
							{
								$strPosition = 2;
							}
							else if($arr[1] == 2)
							{
								$strPosition = 1;
							}
							
							$valveAfterProgram = $arr[0].'_'.$strPosition.'_'.$arr[2];
							
							$arrAfterProgramDevice[$k] = $valveAfterProgram.'|||'.$valveTime[$seq].'|||V';
							
							$k++;
						}
					}
				}
				
				if(!empty($relaySequence))
				{
					foreach($relaySequence as $seq => $key)
					{
						if($key != '')
						{
							if(!array_key_exists($key,$arrSequnceDevice))
							$arrSequnceDevice[$key] = array();
							
							array_push($arrSequnceDevice[$key],$relayDevice[$seq].'|||'.$relayTime[$seq].'|||R');
						}
					}
				}
				
				if(!empty($powerCenterSequence))
				{
					foreach($powerCenterSequence as $seq => $key)
					{
						if($key != '')
						{
							if(!array_key_exists($key,$arrSequnceDevice))
							$arrSequnceDevice[$key] = array();
							
							array_push($arrSequnceDevice[$key],$powerCenterDevice[$seq].'|||'.$powerCenterTime[$seq].'|||P');
						}
					}
				}
				ksort($arrSequnceDevice);
				
				//END : Get the first device of the custom program from all Devices.
			}
		}
		
		//Check if the device valve from the program is Used in another running program.
		$aAllOnPrograms = $this->home_model->getOnCustomProgram();
		$alreadyHasValve = '0';
		
		if(!empty($aAllOnPrograms))
		{	
			foreach($aAllOnPrograms as $customProgram)
			{
				$aProgramDetails =	json_decode($customProgram->program_details);
				$valveDevice	=	explode(",",$aProgramDetails->g_rlb_valve_list);
			}
		}
		
		if(!empty($aAllOnPrograms))
		{
			// Check If Valve is Running in any other Program.
			foreach($CurrentValveDevice as $Valve)
			{
				if(in_array($Valve,$valveDevice))
				{
					$aValve	= explode('_',$Valve);
					//START : Get Valve Position Details.
					$aPositionName   =  $this->home_model->getPositionName($aValve[2],'V',$aValve[0]);
					
					$strPosition1 = '';
					$strPosition2 = '';
					
					if($aPositionName[0] != '')
					$strPosition1	 =	$this->home_model->getPositionNameFromID($aPositionName[0]);
					if($aPositionName[1] != '')
					$strPosition2	 =	$this->home_model->getPositionNameFromID($aPositionName[1]);
					//END : Get Valve Position Details.
					
					$strPostition	=	'';
					if($aValve[1] == '1')
						$strPostition	=	$strPosition1;
					else if($aValve[1] == '2')
						$strPostition	=	$strPosition2;
					
					$this->session->set_flashdata('err_msg_delete', 'Valve '.$aValve[2].' '.$strPostition.' Position is already running in another program!');
					redirect('device/customProgram');
					exit;
				}
			}
		}	
		
		
		if(empty($aAllOnPrograms))
		{
			$this->custom_model->deleteAllEntryFromCurrentAfter();
		}

		//First Check if that program is already ON.
		$sStatus = $this->home_model->chkCustomProgram($customProgramID);
		
		if($sStatus == '0')
		{
			$uniqueID	=	rand(1000000,9999999).time();
			
			//Check the Mode, if not manual then ON manual mode.
			$iActiveMode =  $this->home_model->getActiveMode();
			if($iActiveMode != 1)
			{
				$iMode	= 1;
				$this->home_model->updateMode($iMode);
			}
			
			//Get All IP Details.
			$aIPDetails = $this->home_model->getBoardIP();
			
			list($sIP,$sPort,$extra) = $this->home_model->getSettings();
			
			foreach($aIPDetails as $IP)
			{
				${'shhPort'.$IP->id}	=	'';
				if(IS_LOCAL == '1')
				{
					//Get SSH port of the RLB board using IP.
					${'shhPort'.$IP->id} = $this->home_model->getSSHPortFromID($IP->id);
				}
				$sResponse		=	array();
				$sValves        =   ''; 
				$sRelays        =   '';  
				$sPump			=	'';	
				
				//Get the status response of devices from relay board.
				$sResponse      =   get_rlb_status($IP->ip,$sPort,$shhPort);
			
				$sValves        =   $sResponse['valves']; // Valve Device Status
				$sRelays        =   $sResponse['relay'];  // Relay Device Status
				$sPowerCenter   =   $sResponse['powercenter']; // Power Center Device Status
				
				${'sRelays'.$IP->id} 		=	$sRelays;
				${'sValves'.$IP->id} 		=	$sValves;
				${'sPowerCenter'.$IP->id} 	=	$sPowerCenter;
				
				${'sPump'.$IP->id}	=	array($sResponse['pump_seq_0_st'],$sResponse['pump_seq_1_st'],$sResponse['pump_seq_2_st']);
				${'board'.$IP->id} 	=	$IP->ip;
				
				$arrExtraDetails[$IP->id] = array('sValves'=>${'sValves'.$IP->id},'board'=>${'board'.$IP->id},'shhPort'=>${'shhPort'.$IP->id});
			}
			
			//START :STOP ALL Devices Running in after program for the same program which is going to start.
			if($afterProgram == '1')	
			{
				$currentDeviceAfter = $this->custom_model->getCustomProgrmaAfterDevice($customProgramID);
				if($currentDeviceAfter != '')
				{
					$lastElement = end($currentDeviceAfter);
					
					foreach($currentDeviceAfter as $deviceDetails)
					{
						$currentSeq		=	$deviceDetails->current_sequence;
						$deviceType 	=   $deviceDetails->device_type;
						$ipID			=	$deviceDetails->ip_id;
						$sStatus		=	0;
						$deviceNumber	=	$deviceDetails->device_number;
						
						$sNewResp = replace_return($arrExtraDetails[$ipID]['sValves'], $sStatus, $deviceNumber);
						$arrExtraDetails[$ipID]['sValves'] = $sNewResp;
						onoff_rlb_valve($sNewResp,$arrExtraDetails[$ipID]['board'],$sPort,$arrExtraDetails[$ipID]['shhPort']);
						
						
						//Insert Entry in the Log Table for future Reference.
						$this->custom_model->saveCustomAfterEntryInLog($customProgramID,$deviceType);
						
						//Delete Entry From the current details Table.
						$this->custom_model->deleteCustomEntryFromAfter($customProgramID,$deviceType,$deviceNumber);
						
					}
				}
				
				$this->home_model->updateAfterProgram($customProgramID,'0');
			}
			//STOP : STOP ALL Devices Running in after program for the same program which is going to start.
			
			//START : To store the current position of Valve before starting first Device of Program.
			$arrValveKeepOn		    = array();
			$arrValveDefaultPosition= array();  
			
			if(!empty($valveSequence))
			{
				$k = 1;
				foreach($valveSequence as $seq => $key)
				{
					if($key != '')
					{
						//Valve to run after program end.
						$arr	=	explode('_',$valveDevice[$seq]);
						$strPosition = '';
						if($arr[1] == 1)
						{
							$strPosition = 2;
						}
						else if($arr[1] == 2)
						{
							$strPosition = 1;
						}
						
						$arrTemp 			=	explode("_",$valveDevice[$seq]);
						$ipIDTemp			=	$arrTemp[0];
						$sStatusTemp		=	$arrTemp[1];
						$deviceNumberTemp	=	$arrTemp[2];
						
						$existingStatus 	=	${'sValves'.$ipIDTemp}[$deviceNumberTemp];
						
						$arrValveDefaultPosition[] = $deviceNumberTemp.'_'.$ipIDTemp;
						
						$arrValveKeepOn[]	= $ipIDTemp.'_'.$existingStatus.'_'.$deviceNumberTemp;
					}
				}
				
				if($arrValveDefaultPosition)
				{
					//START : If Default Position is running then stop those valve.
					$arrValveDetails = $this->home_model->getAllValveDefaultPositionRunnig();
					if($arrValveDetails)
					{
						foreach($arrValveDetails as $valveDetails)
						{
							$IpId			=	$valveDetails->ip_id;
							$Valve			=	$valveDetails->valve;
							
							$checkValve     = 	$Valve.'_'.$IpId;
							
							if(in_array($checkValve,$arrValveDefaultPosition))
							{
								$sNewResp = replace_return(${'sValves'.$IpId}, '0', $Valve);
								${'sValves'.$IpId} = $sNewResp;
								onoff_rlb_valve($sNewResp,${'board'.$IpId},$sPort,${'shhPort'.$IpId});
								
								$this->home_model->removeDefaultRunDetails($valveDetails->id);
							}
						}
					}
				}
			}
			//END : To store the current position of Valve before starting first Device of Program.
			
			//Start Custom Program.
			$this->home_model->startCustomProgram($customProgramID,$uniqueID);
			
			$this->home_model->updateExistingStatusValveForProgram($customProgramID,$arrValveKeepOn);
			
			//START : First Device ON.
			foreach($arrSequnceDevice[1] as $devices)
			{
				$aCurrentDevice	=	explode('|||',$devices);
				//START: First make valve device ON in the sequence.
				$sStatus		=	'1';
				$sRunTime		=	$aCurrentDevice[1];
				$deviceType 	=   $aCurrentDevice[2];
				$aDevice		=	explode("_",$aCurrentDevice[0]);
				if($deviceType == 'V')
				{
					$ipID			=	$aDevice[0];
					$sStatus		=	$aDevice[1];
					$deviceNumber	=	$aDevice[2];
				}
				else if($deviceType == 'PS' || $deviceType == 'R' || $deviceType == 'P')
				{
					$ipID			=	$aDevice[0];
					$deviceNumber	=	$aDevice[1];
				}
				
				if($deviceType	==	'PS')
				{
					require_once(APPPATH.'controllers/cron.php');
					$aObjCron = new Cron();   
					$aObjCron->cronMakePumpOnOFF($deviceNumber,$sStatus,${'board'.$ipID},$sPort,${'shhPort'.$ipID},$ipID);
					$strDevice		=	'Pump '.$deviceNumber;
				}
				else if($deviceType	== 'V')
				{
					$sNewResp = replace_return(${'sValves'.$ipID}, $sStatus, $deviceNumber);
					${'sValves'.$ipID} = $sNewResp;
					#onoff_rlb_valve($sNewResp,${'board'.$ipID},$sPort,${'shhPort'.$ipID});
					
					$strDevice	=	'Valve '.$deviceNumber;	
				}
				else if($deviceType	== 'R')
				{
					$sNewResp = replace_return(${'sRelays'.$ipID}, $sStatus, $deviceNumber);
					${'sRelays'.$ipID} = $sNewResp;
					onoff_rlb_relay($sNewResp,${'board'.$ipID},$sPort,${'shhPort'.$ipID});
					
					$heaterNum = $this->home_model->chkHeater($deviceNumber,'24',$ipID);
								
					if($heaterNum != '')
					{
						$aHeaterDetails  =   $this->home_model->getHeaterDeviceDetails($heaterNum,$ipID);
						if(!empty($aHeaterDetails))
						{
							foreach($aHeaterDetails as $aHeater)
							{
								$sHeaterDetails  =   unserialize($aHeater->light_relay_number);
							}
							
							$PumpNumber   		=   $sHeaterDetails['Pump'];
						}
						if($PumpNumber != '')
						{
							$aPumpDetails =	$this->home_model->getPumpDetails($PumpNumber,$ipID);
							if(!empty($aPumpDetails))
							{
								foreach($aPumpDetails as $sPump)
								{
									//$this->cronMakePumpOnOFF($PumpNumber,'1',${'board'.$ipID},$sPort,${'shhPort'.$ipID},$ipID);
									
									require_once(APPPATH.'controllers/cron.php');
									$aObjCron = new Cron();   
									$aObjCron->cronMakePumpOnOFF($PumpNumber,'1',${'board'.$ipID},$sPort,${'shhPort'.$ipID},$ipID);
								}
							}
						}
					}
					
					$strDevice	=	'Relay '.$deviceNumber;	
				}
				else if($deviceType	== 'P')
				{
					$sNewResp = replace_return(${'sPowerCenter'.$ipID}, $sStatus, $deviceNumber);
					${'sPowerCenter'.$ipID} = $sNewResp;
					onoff_rlb_powercenter($sNewResp,${'board'.$ipID},$sPort,${'shhPort'.$ipID});
					
					$heaterNum = $this->home_model->chkHeater($deviceNumber,'12',$ipID);
											
					if($heaterNum != '')
					{
						$aHeaterDetails  =   $this->home_model->getHeaterDeviceDetails($heaterNum,$ipID);
						if(!empty($aHeaterDetails))
						{
							foreach($aHeaterDetails as $aHeater)
							{
								$sHeaterDetails  =   unserialize($aHeater->light_relay_number);
							}
							
							$PumpNumber   		=   $sHeaterDetails['Pump'];
						}
						if($PumpNumber != '')
						{
							$aPumpDetails =	$this->home_model->getPumpDetails($PumpNumber,$ipID);
							if(!empty($aPumpDetails))
							{
								foreach($aPumpDetails as $sPump)
								{
									//$this->cronMakePumpOnOFF($PumpNumber,'1',${'board'.$ipID},$sPort,${'shhPort'.$ipID},$ipID);
									
									require_once(APPPATH.'controllers/cron.php');
									$aObjCron = new Cron();   
									$aObjCron->cronMakePumpOnOFF($sPump->pump_number,'1',${'board'.$ipID},$sPort,${'shhPort'.$ipID},$ipID);
								}
							}
						}
					}
					
					$strDevice	=	'Power Center '.$deviceNumber;
				}
				
				$arrDetails		=	array('program_id'=>$customProgramID,
										  'current_on_device'=>$strDevice,
										  'device_type'=>$deviceType,
										  'device_number'=>$deviceNumber,
										  'current_on_time'=>$sRunTime,
										  'current_sequence'=>1,
										  'ip_id'=>$ipID,
										  'unique_id'=>$uniqueID);
				
				$this->custom_model->saveCustomCurrentRunningDevice($arrDetails);
			}
			//END : First Device ON. 
			$this->session->set_flashdata('success_msg_add', 'Custom Program started Successfully!');
			redirect('device/customProgram');
		}
	}
	
	public function runCustomProgram()
	{
		$this->load->model('custom_model');
		$customProgramID = base64_decode($this->uri->segment("3"));
		
		if($customProgramID == '')
		{
			$this->session->set_flashdata('err_msg_delete', 'Please select Custom program!');
			redirect('device/customProgram');
			exit;
		}
		
		$aCurrentProgramDetails = $this->home_model->getCustomProgramDetails($customProgramID);
		if(!empty($aCurrentProgramDetails))
		{
			foreach($aCurrentProgramDetails as $currentProgram)
			{
				$aCurrentDetails 	=	json_decode($currentProgram->program_details);
				$CurrentValveDevice	=	explode(",",$aCurrentDetails->g_rlb_valve_list);
				$afterProgram	 	=	$currentProgram->afterProgram;
				
				//START : Get the first device of the custom program from all Devices.
				if(isset($aCurrentDetails->g_rlb_pump_list) && $aCurrentDetails->g_rlb_pump_list != '')
				{
					//Pump Device Details.
					$pumpDevice		=	explode(",",$aCurrentDetails->g_rlb_pump_list);
					$pumpSequence	=	explode(",",$aCurrentDetails->g_pump_sq);
					$pumpTime		=	explode(",",$aCurrentDetails->g_pump_time);
				}
				
				if(isset($aCurrentDetails->g_rlb_valve_list) && $aCurrentDetails->g_rlb_valve_list != '')
				{
					//Valve Device Details
					$valveDevice	=	explode(",",$aCurrentDetails->g_rlb_valve_list);	
					$valveSequence	=	explode(",",$aCurrentDetails->g_valve_sq);	
					$valveTime		=	explode(",",$aCurrentDetails->g_valve_time);
				}
				
				if(isset($aCurrentDetails->g_rlb_relay_list) && $aCurrentDetails->g_rlb_relay_list != '')
				{
					//Relay Device Details
					$relayDevice	=	explode(",",$aCurrentDetails->g_rlb_relay_list);	
					$relaySequence	=	explode(",",$aCurrentDetails->g_relay_sq);	
					$relayTime		=	explode(",",$aCurrentDetails->g_relay_time);				
				}
				
				if(isset($aCurrentDetails->g_rlb_powercenter_list) && $aCurrentDetails->g_rlb_powercenter_list != '')
				{
					//Relay Device Details
					$powerCenterDevice	=	explode(",",$aCurrentDetails->g_rlb_powercenter_list);	
					$powerCenterSequence	=	explode(",",$aCurrentDetails->g_powercenter_sq);	
					$powerCenterTime		=	explode(",",$aCurrentDetails->g_powercenter_time);				
				}
								
				if(!empty($pumpSequence))
				{
					foreach($pumpSequence as $seq => $key)
					{
						if($key != '')
						{
							if(!array_key_exists($key,$arrSequnceDevice))
							$arrSequnceDevice[$key] = array();
							
							array_push($arrSequnceDevice[$key],$pumpDevice[$seq].'|||'.$pumpTime[$seq].'|||PS');
						}
					}
				}
				
				//$valveSequence	=	array_flip($valveSequence);
				
				$arrAfterProgramDevice = array();
				
				if(!empty($valveSequence))
				{
					$k = 1;
					foreach($valveSequence as $seq => $key)
					{
						if($key != '')
						{
							if(!array_key_exists($key,$arrSequnceDevice))
							$arrSequnceDevice[$key] = array();
						
							array_push($arrSequnceDevice[$key],$valveDevice[$seq].'|||'.$valveTime[$seq].'|||V');
							
							//Valve to run after program end.
							$arr	=	explode('_',$valveDevice[$seq]);
							$strPosition = '';
							if($arr[1] == 1)
							{
								$strPosition = 2;
							}
							else if($arr[1] == 2)
							{
								$strPosition = 1;
							}
							
							$valveAfterProgram = $arr[0].'_'.$strPosition.'_'.$arr[2];
							
							$arrAfterProgramDevice[$k] = $valveAfterProgram.'|||'.$valveTime[$seq].'|||V';
							
							$k++;
						}
					}
				}
				
				if(!empty($relaySequence))
				{
					foreach($relaySequence as $seq => $key)
					{
						if($key != '')
						{
							if(!array_key_exists($key,$arrSequnceDevice))
							$arrSequnceDevice[$key] = array();
							
							array_push($arrSequnceDevice[$key],$relayDevice[$seq].'|||'.$relayTime[$seq].'|||R');
						}
					}
				}
				
				if(!empty($powerCenterSequence))
				{
					foreach($powerCenterSequence as $seq => $key)
					{
						if($key != '')
						{
							if(!array_key_exists($key,$arrSequnceDevice))
							$arrSequnceDevice[$key] = array();
							
							array_push($arrSequnceDevice[$key],$powerCenterDevice[$seq].'|||'.$powerCenterTime[$seq].'|||P');
						}
					}
				}
				ksort($arrSequnceDevice);
				
				//END : Get the first device of the custom program from all Devices.
			}
		}
		
		//Check if the device valve from the program is Used in another running program.
		$aAllOnPrograms = $this->home_model->getOnCustomProgram();
		$alreadyHasValve = '0';
		
		if(!empty($aAllOnPrograms))
		{	
			foreach($aAllOnPrograms as $customProgram)
			{
				$aProgramDetails =	json_decode($customProgram->program_details);
				$valveDevice	=	explode(",",$aProgramDetails->g_rlb_valve_list);
			}
		}
		
		if(!empty($aAllOnPrograms))
		{
			// Check If Valve is Running in any other Program.
			foreach($CurrentValveDevice as $Valve)
			{
				if(in_array($Valve,$valveDevice))
				{
					$aValve	= explode('_',$Valve);
					//START : Get Valve Position Details.
					$aPositionName   =  $this->home_model->getPositionName($aValve[2],'V',$aValve[0]);
					
					$strPosition1 = '';
					$strPosition2 = '';
					
					if($aPositionName[0] != '')
					$strPosition1	 =	$this->home_model->getPositionNameFromID($aPositionName[0]);
					if($aPositionName[1] != '')
					$strPosition2	 =	$this->home_model->getPositionNameFromID($aPositionName[1]);
					//END : Get Valve Position Details.
					
					$strPostition	=	'';
					if($aValve[1] == '1')
						$strPostition	=	$strPosition1;
					else if($aValve[1] == '2')
						$strPostition	=	$strPosition2;
					
					$this->session->set_flashdata('err_msg_delete', 'Valve '.$aValve[2].' '.$strPostition.' Position is already running in another program!');
					redirect('device/customProgram');
					exit;
				}
			}
		}	
		
		
		if(empty($aAllOnPrograms))
		{
			$this->custom_model->deleteAllEntryFromCurrentAfter();
		}

		//First Check if that program is already ON.
		$sStatus = $this->home_model->chkCustomProgram($customProgramID);
		
		if($sStatus == '0')
		{
			$uniqueID	=	rand(1000000,9999999).time();
			
			//Check the Mode, if not manual then ON manual mode.
			$iActiveMode =  $this->home_model->getActiveMode();
			if($iActiveMode != 1)
			{
				$iMode	= 1;
				$this->home_model->updateMode($iMode);
			}
			
			//Get All IP Details.
			$aIPDetails = $this->home_model->getBoardIP();
			
			list($sIP,$sPort,$extra) = $this->home_model->getSettings();
			
			foreach($aIPDetails as $IP)
			{
				${'shhPort'.$IP->id}	=	'';
				if(IS_LOCAL == '1')
				{
					//Get SSH port of the RLB board using IP.
					${'shhPort'.$IP->id} = $this->home_model->getSSHPortFromID($IP->id);
				}
				$sResponse		=	array();
				$sValves        =   ''; 
				$sRelays        =   '';  
				$sPump			=	'';	
				
				//Get the status response of devices from relay board.
				$sResponse      =   get_rlb_status($IP->ip,$sPort,$shhPort);
			
				$sValves        =   $sResponse['valves']; // Valve Device Status
				$sRelays        =   $sResponse['relay'];  // Relay Device Status
				$sPowerCenter   =   $sResponse['powercenter']; // Power Center Device Status
				
				${'sRelays'.$IP->id} 		=	$sRelays;
				${'sValves'.$IP->id} 		=	$sValves;
				${'sPowerCenter'.$IP->id} 	=	$sPowerCenter;
				
				${'sPump'.$IP->id}	=	array($sResponse['pump_seq_0_st'],$sResponse['pump_seq_1_st'],$sResponse['pump_seq_2_st']);
				${'board'.$IP->id} 	=	$IP->ip;
				
				$arrExtraDetails[$IP->id] = array('sValves'=>${'sValves'.$IP->id},'board'=>${'board'.$IP->id},'shhPort'=>${'shhPort'.$IP->id});
			}
			
			//START :STOP ALL Devices Running in after program for the same program which is going to start.
			if($afterProgram == '1')	
			{
				$currentDeviceAfter = $this->custom_model->getCustomProgrmaAfterDevice($customProgramID);
				if($currentDeviceAfter != '')
				{
					$lastElement = end($currentDeviceAfter);
					
					foreach($currentDeviceAfter as $deviceDetails)
					{
						$currentSeq		=	$deviceDetails->current_sequence;
						$deviceType 	=   $deviceDetails->device_type;
						$ipID			=	$deviceDetails->ip_id;
						$sStatus		=	0;
						$deviceNumber	=	$deviceDetails->device_number;
						
						$sNewResp = replace_return($arrExtraDetails[$ipID]['sValves'], $sStatus, $deviceNumber);
						$arrExtraDetails[$ipID]['sValves'] = $sNewResp;
						onoff_rlb_valve($sNewResp,$arrExtraDetails[$ipID]['board'],$sPort,$arrExtraDetails[$ipID]['shhPort']);
						
						
						//Insert Entry in the Log Table for future Reference.
						$this->custom_model->saveCustomAfterEntryInLog($customProgramID,$deviceType);
						
						//Delete Entry From the current details Table.
						$this->custom_model->deleteCustomEntryFromAfter($customProgramID,$deviceType,$deviceNumber);
						
					}
				}
				
				$this->home_model->updateAfterProgram($customProgramID,'0');
			}
			//STOP : STOP ALL Devices Running in after program for the same program which is going to start.
			
			//START : To store the current position of Valve before starting first Device of Program.
			$arrValveKeepOn		    = array();
			$arrValveDefaultPosition= array();  
			
			if(!empty($valveSequence))
			{
				$k = 1;
				foreach($valveSequence as $seq => $key)
				{
					if($key != '')
					{
						//Valve to run after program end.
						$arr	=	explode('_',$valveDevice[$seq]);
						$strPosition = '';
						if($arr[1] == 1)
						{
							$strPosition = 2;
						}
						else if($arr[1] == 2)
						{
							$strPosition = 1;
						}
						
						$arrTemp 			=	explode("_",$valveDevice[$seq]);
						$ipIDTemp			=	$arrTemp[0];
						$sStatusTemp		=	$arrTemp[1];
						$deviceNumberTemp	=	$arrTemp[2];
						
						$existingStatus 	=	${'sValves'.$ipIDTemp}[$deviceNumberTemp];
						
						$arrValveDefaultPosition[] = $deviceNumberTemp.'_'.$ipIDTemp;
						
						$arrValveKeepOn[]	= $ipIDTemp.'_'.$existingStatus.'_'.$deviceNumberTemp;
					}
				}
				
				if($arrValveDefaultPosition)
				{
					//START : If Default Position is running then stop those valve.
					$arrValveDetails = $this->home_model->getAllValveDefaultPositionRunnig();
					if($arrValveDetails)
					{
						foreach($arrValveDetails as $valveDetails)
						{
							$IpId			=	$valveDetails->ip_id;
							$Valve			=	$valveDetails->valve;
							
							$checkValve     = 	$Valve.'_'.$IpId;
							
							if(in_array($checkValve,$arrValveDefaultPosition))
							{
								$sNewResp = replace_return(${'sValves'.$IpId}, '0', $Valve);
								${'sValves'.$IpId} = $sNewResp;
								onoff_rlb_valve($sNewResp,${'board'.$IpId},$sPort,${'shhPort'.$IpId});
								
								$this->home_model->removeDefaultRunDetails($valveDetails->id);
							}
						}
					}
				}
			}
			//END : To store the current position of Valve before starting first Device of Program.
			
			//Start Custom Program.
			$this->home_model->startCustomProgram($customProgramID,$uniqueID);
			$this->custom_model->saveCustomStartSourceDetails($customProgramID,'1',date('Y-m-d H:i:s'));
			$this->home_model->updateExistingStatusValveForProgram($customProgramID,$arrValveKeepOn);
			
			//START : First Device ON.
			foreach($arrSequnceDevice[1] as $devices)
			{
				$aCurrentDevice	=	explode('|||',$devices);
				//START: First make valve device ON in the sequence.
				$sStatus		=	'1';
				$sRunTime		=	$aCurrentDevice[1];
				$deviceType 	=   $aCurrentDevice[2];
				$aDevice		=	explode("_",$aCurrentDevice[0]);
				if($deviceType == 'V')
				{
					$ipID			=	$aDevice[0];
					$sStatus		=	$aDevice[1];
					$deviceNumber	=	$aDevice[2];
				}
				else if($deviceType == 'PS' || $deviceType == 'R' || $deviceType == 'P')
				{
					$ipID			=	$aDevice[0];
					$deviceNumber	=	$aDevice[1];
				}
				
				if($deviceType	==	'PS')
				{
					require_once(APPPATH.'controllers/cron.php');
					$aObjCron = new Cron();   
					$aObjCron->cronMakePumpOnOFF($deviceNumber,$sStatus,${'board'.$ipID},$sPort,${'shhPort'.$ipID},$ipID);
					$strDevice		=	'Pump '.$deviceNumber;
				}
				else if($deviceType	== 'V')
				{
					$sNewResp = replace_return(${'sValves'.$ipID}, $sStatus, $deviceNumber);
					${'sValves'.$ipID} = $sNewResp;
					onoff_rlb_valve($sNewResp,${'board'.$ipID},$sPort,${'shhPort'.$ipID});
					
					$strDevice	=	'Valve '.$deviceNumber;	
				}
				else if($deviceType	== 'R')
				{
					$sNewResp = replace_return(${'sRelays'.$ipID}, $sStatus, $deviceNumber);
					${'sRelays'.$ipID} = $sNewResp;
					onoff_rlb_relay($sNewResp,${'board'.$ipID},$sPort,${'shhPort'.$ipID});
					
					$heaterNum = $this->home_model->chkHeater($deviceNumber,'24',$ipID);
								
					if($heaterNum != '')
					{
						$aHeaterDetails  =   $this->home_model->getHeaterDeviceDetails($heaterNum,$ipID);
						if(!empty($aHeaterDetails))
						{
							foreach($aHeaterDetails as $aHeater)
							{
								$sHeaterDetails  =   unserialize($aHeater->light_relay_number);
							}
							
							$PumpNumber   		=   $sHeaterDetails['Pump'];
						}
						if($PumpNumber != '')
						{
							$aPumpDetails =	$this->home_model->getPumpDetails($PumpNumber,$ipID);
							if(!empty($aPumpDetails))
							{
								foreach($aPumpDetails as $sPump)
								{
									//$this->cronMakePumpOnOFF($PumpNumber,'1',${'board'.$ipID},$sPort,${'shhPort'.$ipID},$ipID);
									
									require_once(APPPATH.'controllers/cron.php');
									$aObjCron = new Cron();   
									$aObjCron->cronMakePumpOnOFF($PumpNumber,'1',${'board'.$ipID},$sPort,${'shhPort'.$ipID},$ipID);
								}
							}
						}
					}
					
					$strDevice	=	'Relay '.$deviceNumber;	
				}
				else if($deviceType	== 'P')
				{
					$sNewResp = replace_return(${'sPowerCenter'.$ipID}, $sStatus, $deviceNumber);
					${'sPowerCenter'.$ipID} = $sNewResp;
					onoff_rlb_powercenter($sNewResp,${'board'.$ipID},$sPort,${'shhPort'.$ipID});
					
					$heaterNum = $this->home_model->chkHeater($deviceNumber,'12',$ipID);
											
					if($heaterNum != '')
					{
						$aHeaterDetails  =   $this->home_model->getHeaterDeviceDetails($heaterNum,$ipID);
						if(!empty($aHeaterDetails))
						{
							foreach($aHeaterDetails as $aHeater)
							{
								$sHeaterDetails  =   unserialize($aHeater->light_relay_number);
							}
							
							$PumpNumber   		=   $sHeaterDetails['Pump'];
						}
						if($PumpNumber != '')
						{
							$aPumpDetails =	$this->home_model->getPumpDetails($PumpNumber,$ipID);
							if(!empty($aPumpDetails))
							{
								foreach($aPumpDetails as $sPump)
								{
									//$this->cronMakePumpOnOFF($PumpNumber,'1',${'board'.$ipID},$sPort,${'shhPort'.$ipID},$ipID);
									
									require_once(APPPATH.'controllers/cron.php');
									$aObjCron = new Cron();   
									$aObjCron->cronMakePumpOnOFF($sPump->pump_number,'1',${'board'.$ipID},$sPort,${'shhPort'.$ipID},$ipID);
								}
							}
						}
					}
					
					$strDevice	=	'Power Center '.$deviceNumber;
				}
				
				$arrDetails		=	array('program_id'=>$customProgramID,
										  'current_on_device'=>$strDevice,
										  'device_type'=>$deviceType,
										  'device_number'=>$deviceNumber,
										  'current_on_time'=>$sRunTime,
										  'current_sequence'=>1,
										  'ip_id'=>$ipID,
										  'unique_id'=>$uniqueID);
				
				$this->custom_model->saveCustomCurrentRunningDevice($arrDetails);
			}
			//END : First Device ON. 
			$this->session->set_flashdata('success_msg_add', 'Custom Program started Successfully!');
			redirect('device/customProgram');
		}
	}
		
	/**
	* Function to Stop the custom Program.
	* @param
	* @return : Validation message or Success Message.
	**/
	public function offCustomProgram()
	{
		$customProgramID = $this->input->post('customProgramID');
		
		if($customProgramID == '')
		{
			echo "Program is Not Valid!";
			exit;
		}
		
		$this->load->model('custom_model');
		
		//First Check if that program is already ON.
		$sStatus = $this->home_model->chkCustomProgram($customProgramID);
		
		if($sStatus == '1')
		{
			$afterProgram = 0;
			$programDetails = $this->home_model->getCustomProgramDetails($customProgramID);
			
			foreach($programDetails as $customProgram)
			{
				$aProgramDetails =	json_decode($customProgram->program_details);
				$previousState	 = 	unserialize($customProgram->previousState);
				
				if(isset($aProgramDetails->g_rlb_valve_list) && $aProgramDetails->g_rlb_valve_list != '')
				{
					//Valve Device Details
					$valveDevice	=	explode(",",$aProgramDetails->g_rlb_valve_list);	
					$valveSequence	=	explode(",",$aProgramDetails->g_valve_sq);	
					$valveTime		=	explode(",",$aProgramDetails->g_valve_time);
				}
				
				$arrProgramValve	=	array();

				$arrAfterProgramDevice = array();
				if(!empty($valveSequence))
				{
					$k = 1;
					foreach($valveSequence as $seq => $key)
					{
						if(!array_key_exists($key,$arrSequnceDevice))
						$arrSequnceDevice[$key] = array();
					
						//Valve to run after program end.
						$arr	=	explode('_',$valveDevice[$seq]);
						$strPosition = '';
						if($arr[1] == 1)
						{
							$strPosition = 2;
						}
						else if($arr[1] == 2)
						{
							$strPosition = 1;
						}
						
						$arrTemp 			=	explode("_",$valveDevice[$seq]);
						$ipIDTemp			=	$arrTemp[0];
						$sStatusTemp		=	$arrTemp[1];
						$deviceNumberTemp	=	$arrTemp[2];
						
						array_push($arrProgramValve,$valveDevice[$seq]);
						
						//$tempDevice			=	$ipIDTemp.'_'.$existingStatus.'_'.$deviceNumberTemp;
						
						$valveAfterProgram = $arr[0].'_'.$strPosition.'_'.$arr[2];
						
						//if($existingStatus != $sStatusTemp)
						if(!in_array($valveDevice[$seq],$previousState))	
						{
							$lastRun = $this->home_model->getDeviceLastRun($deviceNumberTemp,'V',$ipIDTemp);
							
							if($lastRun != $sStatusTemp)
							{
								$arrAfterProgramDevice[$key] = $valveAfterProgram.'|||'.$valveTime[$seq].'|||V';
							
								$k++;
							}
						}
						else
						{
							$arrValveKeepOn[] = $ipIDTemp.'_'.$deviceNumberTemp;
						}
					}
				}
			}
			$afterProgram = 0;
			
			//Stop Custom Program.
			$this->home_model->stopCustomProgram($customProgramID,$afterProgram);
			$this->custom_model->saveCustomStopSourceDetails($customProgramID,'1',date('Y-m-d H:i:s'),'0');
			$currentDevice = $this->custom_model->getCustomProgrmaCurrentDevice($customProgramID);
			
			if($currentDevice != '')
			{
				foreach($currentDevice as $deviceDetails)
				{
					$currentSeq		=	$deviceDetails->current_sequence;
					$deviceType 	=   $deviceDetails->device_type;
					$ipID			=	$deviceDetails->ip_id;
					$sStatus		=	0;
					$deviceNumber	=	$deviceDetails->device_number;
					
					$sDeviceIP		= 	$this->home_model->getBoardIPFromID($ipID);
					list($sIP,$sPort,$extra) = $this->home_model->getSettings();
		
					
					$shhPort	=	'';
					if(IS_LOCAL == '1')
					{
						//Get SSH port of the RLB board using IP.
						$shhPort = $this->home_model->getSSHPortFromID($ipID);
					}
					$sResponse		=	array();
					$sValves        =   ''; 
					$sRelays        =   '';  
					$sPump			=	'';	
					
					//Get the status response of devices from relay board.
					$sResponse      =   get_rlb_status($sDeviceIP,$sPort,$shhPort);
				
					$sValves        =   $sResponse['valves']; // Valve Device Status
					$sRelays        =   $sResponse['relay'];  // Relay Device Status
					$sPowerCenter   =   $sResponse['powercenter']; // Power Center Device Status
					
					${'sPump'.$IP->id}	=	array($sResponse['pump_seq_0_st'],$sResponse['pump_seq_1_st'],$sResponse['pump_seq_2_st']);
					
					if($deviceType == 'V')
					{
						$sNewResp = replace_return($sValves, $sStatus, $deviceNumber);
						$sValves = $sNewResp;
						onoff_rlb_valve($sNewResp,$sDeviceIP,$sPort,$shhPort);
					}
					else if($deviceType == 'PS')
					{	
						$this->deviceMakePumpOnOFF($deviceNumber,$sStatus,$sDeviceIP,$sPort,$shhPort,$ipID);
					}
					else if($deviceType	== 'R')
					{
						$sNewResp = replace_return($sRelays, $sStatus, $deviceNumber);
						$sRelays = $sNewResp;
						onoff_rlb_relay($sNewResp,$sDeviceIP,$sPort,$shhPort);
						
						//START : Check if heater is assigned to that relay.
						$heaterNum = $this->home_model->chkHeater($deviceNumber,'24',$ipID);
						
						if($heaterNum != '')
						{
							$aHeaterDetails  =   $this->home_model->getHeaterDeviceDetails($heaterNum,$ipID);
							if(!empty($aHeaterDetails))
							{
								foreach($aHeaterDetails as $aHeater)
								$sHeaterDetails  =   unserialize($aHeater->light_relay_number);
								
								$PumpNumber   		=   $sHeaterDetails['Pump'];
							}
							if($PumpNumber != '')
							{
								$aPumpDetails =	$this->home_model->getPumpDetails($PumpNumber,$ipID);
								if(!empty($aPumpDetails))
								{
									foreach($aPumpDetails as $sPump)
									{
										$heaterStopTime =	date('Y-m-d H:i:s');
										$arrStopTime	=	explode(" ",$heaterStopTime);
										$aDate     		=   explode("-",$arrStopTime[0]);
										$aTime     		=   explode(":",$arrStopTime[1]);
										
										$sProgramAbsEnd =   mktime(($aTime[0]),($aTime[1]+5),($aTime[2]),$aDate[1],$aDate[2],$aDate[0]);
										$pumpStopTime   =   date("Y-m-d H:i:s", $sProgramAbsEnd);
										
										$this->home_model->updateRunAfterHeaterDetails($heaterNum,$sPump->pump_number,$heaterStopTime,$pumpStopTime,$ipID,$customProgramID);
									}
								}
							}
						}
					}
					else if($deviceType	== 'P')
					{
						$sNewResp = replace_return($sPowerCenter, $sStatus, $deviceNumber);
						$sPowerCenter = $sNewResp;
						onoff_rlb_powercenter($sNewResp,$sDeviceIP,$sPort,$shhPort);
						//START : Check if heater is assigned to that relay.
						$heaterNum = $this->home_model->chkHeater($deviceNumber,'12',$ipID);
						
						if($heaterNum != '')
						{
							$aHeaterDetails  =   $this->home_model->getHeaterDeviceDetails($heaterNum,$ipID);
							if(!empty($aHeaterDetails))
							{
								foreach($aHeaterDetails as $aHeater)
								$sHeaterDetails  =   unserialize($aHeater->light_relay_number);
								
								$PumpNumber   		=   $sHeaterDetails['Pump'];
							}
							if($PumpNumber != '')
							{
								$aPumpDetails =	$this->home_model->getPumpDetails($PumpNumber,$ipID);
								if(!empty($aPumpDetails))
								{
									foreach($aPumpDetails as $sPump)
									{
										$heaterStopTime =	date('Y-m-d H:i:s');
										$arrStopTime	=	explode(" ",$heaterStopTime);
										$aDate     		=   explode("-",$arrStopTime[0]);
										$aTime     		=   explode(":",$arrStopTime[1]);
										
										$sProgramAbsEnd =   mktime(($aTime[0]),($aTime[1]+5),($aTime[2]),$aDate[1],$aDate[2],$aDate[0]);
										$pumpStopTime   =   date("Y-m-d H:i:s", $sProgramAbsEnd);
										
										$this->home_model->updateRunAfterHeaterDetails($heaterNum,$sPump->pump_number,$heaterStopTime,$pumpStopTime,$ipID,$customProgramID);
									}
								}
							}
						}
					}
					
					//Insert Entry in the Log Table for future Reference.
					$this->custom_model->saveCustomEntryInLog($customProgramID,$deviceType);
					
					//Delete Entry From the current details Table.
					$this->custom_model->deleteCustomEntryFromCurrent($customProgramID,$deviceType,$deviceNumber);
				}
			}
			
			$OnCustomProgramDetails		= $this->home_model->getOnCustomProgramExcludeID($customProgramID);
			if(!empty($OnCustomProgramDetails))	
			{
				$OnCustomProgram    = 0;
			}
			else
				$OnCustomProgram    = 1;
			
			if($OnCustomProgram == 0)
			{
				if(!empty($arrProgramValve))
				{
					foreach($arrProgramValve as $valveDevice)
					{
						$arrTemp 			=	explode("_",$valveDevice);
						$ipIDTemp			=	$arrTemp[0];
						$sStatusTemp		=	$arrTemp[1];
						$deviceNumberTemp	=	$arrTemp[2];
						
						#START : GET Default Pool auto Position.
						$defaultPosition 	=	$this->home_model->getValveDefaultPosition($deviceNumberTemp,$ipIDTemp);
						
						$sDeviceIP		= 	$this->home_model->getBoardIPFromID($ipIDTemp);
						list($sIP,$sPort,$extra) = $this->home_model->getSettings();
			
						$shhPort	=	'';
						if(IS_LOCAL == '1')
						{
							//Get SSH port of the RLB board using IP.
							$shhPort = $this->home_model->getSSHPortFromID($ipIDTemp);
						}
						$sResponse		=	array();
						$sValves        =   ''; 
						$sRelays        =   '';  
						$sPump			=	'';	
						
						//Get the status response of devices from relay board.
						$sResponse      =   get_rlb_status($sDeviceIP,$sPort,$shhPort);
						$sValves        =   $sResponse['valves']; // Valve Device Status
						
						$sNewResp = replace_return($sValves, $defaultPosition, $deviceNumberTemp);
						$sValves = $sNewResp;
						onoff_rlb_valve($sNewResp,$sDeviceIP,$sPort,$shhPort);
						
						#END : GET Default Pool auto Position.
						
						//START : INSERT THE VALVE DETAILS TO RUN VALVE FOR GIVEN TIME IN POOL MODE AUTO. IF TIME IS NOT SPECIFIED THEN IT WILL RUN FOR 1 MIN DEFAULT.
						
						$runTime = $this->home_model->getValveDefaultPositionTime($deviceNumberTemp,$ipIDTemp);
						if($runTime == 0)
						{
							$runTime = 1;
						}
						if($runTime == '')
						{
							$runTime = 1;
						}
						
						$arrValveDefaultRunDetails	=	array('program_id'=>$customProgramID,'valve'=>$deviceNumberTemp,'ip_id'=>$ipIDTemp,'runTime'=>$runTime);
						$this->home_model->insertValveDefaultRunDetails($arrValveDefaultRunDetails);
						
						//END : INSERT THE VALVE DETAILS TO RUN VALVE FOR GIVEN TIME IN POOL MODE AUTO. IF TIME IS NOT SPECIFIED THEN IT WILL RUN FOR 1 MIN DEFAULT.
					}
					$this->home_model->removePreviousPositions($customProgramID);
				}
			}

			

			echo "Program Stopped Succesfully!|||".$OnCustomProgram;
			exit;
		}
		else
		{
			echo 'Program is Already Stopped!';
			exit;
		}	
		
	}
	
	
	/**
	* Function to set the Device Previous Position where they were before custom program start.
	* @param
	* @return : Validation message or Success Message.
	**/
	public function setDevicePreviousPosition()
	{
		$customProgramID = $this->input->post('customProgramID');
		list($sIP,$sPort,$extra) = $this->home_model->getSettings();
		
		$programDetails = $this->home_model->getCustomProgramDetails($customProgramID);
		foreach($programDetails as $customProgram)
		{
			$aProgramDetails =	json_decode($customProgram->program_details);
			$previousState	 = 	unserialize($customProgram->previousState);
			
			foreach($previousState as $valveDevice)
			{
				$arrTemp 			=	explode("_",$valveDevice);
				$ipIDTemp			=	$arrTemp[0];
				$sStatusTemp		=	$arrTemp[1];
				$deviceNumberTemp	=	$arrTemp[2];
				
				$sDeviceIP			= 	$this->home_model->getBoardIPFromID($ipIDTemp);
				
				$shhPort	=	'';
				if(IS_LOCAL == '1')
				{
					//Get SSH port of the RLB board using IP.
					$shhPort = $this->home_model->getSSHPortFromID($ipIDTemp);
				}
				$sResponse		=	array();
				$sValves        =   ''; 
				
				//Get the status response of devices from relay board.
				$sResponse      =   get_rlb_status($sDeviceIP,$sPort,$shhPort);
				$sValves        =   $sResponse['valves']; // Valve Device Status
				
				$sNewResp = replace_return($sValves, $sStatusTemp, $deviceNumberTemp);
				onoff_rlb_valve($sNewResp,$sDeviceIP,$sPort,$shhPort);
			}
			
			$iMode = 2;
			$sManualTime	= $this->home_model->getManualModeTime();
			$this->home_model->updateMode($iMode);
				
			//If mode is manual then add the manual start time and end time calculated using the manual time(in minute) added on settings page.
			if($sManualTime != '')
			{
				$sProgramAbsStart 	=   date("Y-m-d H:i:s", time());
				$arrStart			=	explode(" ",$sProgramAbsStart);
				$aStartDate    		=   explode("-",$arrStart[0]);
				$aStartTime    		=   explode(":",$arrStart[1]);
				
				$sProgramAbsEnd   =   mktime($aStartTime[0],($aStartTime[1]+$sManualTime),$aStartTime[2],$aStartDate[1],$aStartDate[2],$aStartDate[0]);
				$sAbsoluteEnd     =   date("Y-m-d H:i:s", $sProgramAbsEnd);
				
				$this->home_model->updateManualModeTimer($sProgramAbsStart,$sAbsoluteEnd);
			}
		}
		$this->home_model->removePreviousPositions($customProgramID);
	}
	
	/**
	* Function to set the Device Default Position of Pool Mode Auto.
	* @param
	* @return : Validation message or Success Message.
	**/
	public function setDeviceDefaultPosition()
	{
		$customProgramID = $this->input->post('customProgramID');
		list($sIP,$sPort,$extra) = $this->home_model->getSettings();
		
		$programDetails = $this->home_model->getCustomProgramDetails($customProgramID);
		foreach($programDetails as $customProgram)
		{
			$aProgramDetails =	json_decode($customProgram->program_details);
						
			if(isset($aProgramDetails->g_rlb_valve_list) && $aProgramDetails->g_rlb_valve_list != '')
			{
				//Valve Device Details
				$valveDevice	=	explode(",",$aProgramDetails->g_rlb_valve_list);	
				$valveSequence	=	explode(",",$aProgramDetails->g_valve_sq);	
				$valveTime		=	explode(",",$aProgramDetails->g_valve_time);
			}
			
			$arrProgramValve	=	array();

			if(!empty($valveSequence))
			{
				foreach($valveSequence as $seq => $key)
				{
					array_push($arrProgramValve,$valveDevice[$seq]);
				}
			}
			
			if(!empty($arrProgramValve))
			{
				foreach($arrProgramValve as $valveDevice)
				{
					$arrTemp 			=	explode("_",$valveDevice);
					$ipIDTemp			=	$arrTemp[0];
					$sStatusTemp		=	$arrTemp[1];
					$deviceNumberTemp	=	$arrTemp[2];
					
					#START : GET Default Pool auto Position.
					$defaultPosition 	=	$this->home_model->getValveDefaultPosition($deviceNumberTemp,$ipIDTemp);
					
					$sDeviceIP		= 	$this->home_model->getBoardIPFromID($ipIDTemp);
					$shhPort	=	'';
					if(IS_LOCAL == '1')
					{
						//Get SSH port of the RLB board using IP.
						$shhPort = $this->home_model->getSSHPortFromID($ipIDTemp);
					}
					$sResponse		=	array();
					$sValves        =   ''; 
					$sRelays        =   '';  
					$sPump			=	'';	
					
					//Get the status response of devices from relay board.
					$sResponse      =   get_rlb_status($sDeviceIP,$sPort,$shhPort);
					$sValves        =   $sResponse['valves']; // Valve Device Status
					
					$sNewResp = replace_return($sValves, $defaultPosition, $deviceNumberTemp);
					$sValves = $sNewResp;
					onoff_rlb_valve($sNewResp,$sDeviceIP,$sPort,$shhPort);					
					#END : GET Default Pool auto Position.
					
					//START : INSERT THE VALVE DETAILS TO RUN VALVE FOR GIVEN TIME IN POOL MODE AUTO. IF TIME IS NOT SPECIFIED THEN IT WILL RUN FOR 1 MIN DEFAULT.
					
					$runTime = $this->home_model->getValveDefaultPositionTime($deviceNumberTemp,$ipIDTemp);
					if($runTime == 0)
					{
						$runTime = 1;
					}
					if($runTime == '')
					{
						$runTime = 1;
					}
							
					$arrValveDefaultRunDetails	=	array('program_id'=>$customProgramID,'valve'=>$deviceNumberTemp,'ip_id'=>$ipIDTemp,'runTime'=>$runTime);
					$this->home_model->insertValveDefaultRunDetails($arrValveDefaultRunDetails);
					
					//END : INSERT THE VALVE DETAILS TO RUN VALVE FOR GIVEN TIME IN POOL MODE AUTO. IF TIME IS NOT SPECIFIED THEN IT WILL RUN FOR 1 MIN DEFAULT.
				}
			}
		}
		$this->home_model->removePreviousPositions($customProgramID);
	}
	
	public function deviceMakePumpOnOFF($sName,$sStatus,$sIP,$sDevicePort,$sShh,$sIdIP)
	{
		//echo $sName.">>".$sStatus.">>".$sIP.">>".$sDevicePort.">>".$sShh.">>".$sIdIP;
		//die('STOP');
		
		$sResponse      =   get_rlb_status($sIP,$sDevicePort,$sShh);
        
        $sRelays        =   $sResponse['relay'];    // Relay Device Status
        $sPowercenter   =   $sResponse['powercenter']; // Power Center Device Status
		
		$sDevice = 'PS';
		
		if($sDevice == 'PS') // If Device type is Pump
        {
			$aPumpDetails = $this->home_model->getPumpDetails($sName,$sIdIP);
			//Variable Initialization to blank.
			$sPumpNumber  	= '';
			$sPumpType  	= '';
			$sPumpSubType  	= '';
			$sPumpSpeed  	= '';
			$sPumpFlow 		= '';
			$sPumpClosure   = '';
			$sRelayNumber  	= '';
			$sRelayNumber1  = '';
			
			if(is_array($aPumpDetails) && !empty($aPumpDetails))
			{
			  foreach($aPumpDetails as $aResultEdit)
			  { 
				$sPumpNumber  = $aResultEdit->pump_number;
				$sPumpType    = $aResultEdit->pump_type;
				$sPumpSubType = $aResultEdit->pump_sub_type;
				$sPumpSpeed   = $aResultEdit->pump_speed;
				$sPumpFlow    = $aResultEdit->pump_flow;
				$sPumpClosure = $aResultEdit->pump_closure;
				$sRelayNumber = $aResultEdit->relay_number;
				$sRelayNumber1 = $aResultEdit->relay_number_1;
				$sPumpStatus  = $aResultEdit->status;
			  }
			}
			
			if(($sPumpStatus == $sStatus) && $sPumpStatus != 0)
			{
			}
			else
			{
				if($sPumpType != '')
				{
					if($sPumpType == '12' || $sPumpType == '24' || $sPumpType == '2Speed')
					{
						if($sPumpType == '24')
						{
							$sNewResp = replace_return($sRelays, $sStatus, $sRelayNumber );
							onoff_rlb_relay($sNewResp,$sIP,$sDevicePort,$sShh);
							$this->home_model->updateDeviceRunTime($sName,$sDevice,$sStatus,$sIdIP);
							
							$this->home_model->updateDeviceStauts($sName,$sDevice,$sStatus,$sIdIP);
						}
						else if($sPumpType == '12')
						{
							$sNewResp = replace_return($sPowercenter, $sStatus, $sRelayNumber );
							onoff_rlb_powercenter($sNewResp,$sIP,$sDevicePort,$sShh);
							
							$this->home_model->updateDeviceStauts($sName,$sDevice,$sStatus,$sIdIP);
						}
						if($sPumpType == '2Speed')
						{
							if($sPumpSubType == '24')
							{
								if($sStatus == '0')
								{
									$sNewResp = replace_return($sRelays, 0, $sRelayNumber );
									onoff_rlb_relay($sNewResp,$sIP,$sDevicePort,$sShh);
									$this->home_model->updateDeviceRunTime($sName,$sDevice,$sStatus,$sIdIP);
									
									$sNewResp = replace_return($sNewResp, '0', $sRelayNumber1 );
									onoff_rlb_relay($sNewResp,$sIP,$sDevicePort,$sShh);
									$this->home_model->updateDeviceRunTime($sName,$sDevice,$sStatus,$sIdIP);
								}
								if($sStatus == '1')
								{
									$sNewResp = replace_return($sRelays, $sStatus, $sRelayNumber );
									onoff_rlb_relay($sNewResp,$sIP,$sDevicePort,$sShh);
									$this->home_model->updateDeviceRunTime($sName,$sDevice,$sStatus,$sIdIP);
									
									$sNewResp = replace_return($sNewResp, '0', $sRelayNumber1 );
									onoff_rlb_relay($sNewResp,$sIP,$sDevicePort,$sShh);
									$this->home_model->updateDeviceRunTime($sName,$sDevice,$sStatus,$sIdIP);
								}
								if($sStatus == '2')
								{	
									$sStatus = '1';
									$sNewResp = replace_return($sRelays, $sStatus, $sRelayNumber1 );
									onoff_rlb_relay($sNewResp,$sIP,$sDevicePort,$sShh);
									$this->home_model->updateDeviceRunTime($sName,$sDevice,$sStatus,$sIdIP);
									
									$sNewResp = replace_return($sNewResp, '0', $sRelayNumber );
									onoff_rlb_relay($sNewResp,$sIP,$sDevicePort,$sShh);
									$this->home_model->updateDeviceRunTime($sName,$sDevice,$sStatus,$sIdIP);
								}
								
								$this->home_model->updateDeviceStauts($sName,$sDevice,$sStatus,$sIdIP);
								
							}
							else if($sPumpSubType == '12')
							{
								
								if($sStatus == '0')
								{
									$sNewResp = replace_return($sPowercenter, '0', $sRelayNumber );
									onoff_rlb_powercenter($sNewResp,$sIP,$sDevicePort,$sShh);
									
									$sNewResp = replace_return($sNewResp, '0', $sRelayNumber1 );
									onoff_rlb_powercenter($sNewResp,$sIP,$sDevicePort,$sShh);
								}
								if($sStatus == '1')
								{
									$sNewResp = replace_return($sPowercenter, $sStatus, $sRelayNumber );
									onoff_rlb_powercenter($sNewResp,$sIP,$sDevicePort,$sShh);
									
									$sNewResp = replace_return($sNewResp, '0', $sRelayNumber1 );
									onoff_rlb_powercenter($sNewResp,$sIP,$sDevicePort,$sShh);
								}
								if($sStatus == '2')
								{	
									$sStatus = '1';
									$sNewResp = replace_return($sPowercenter, $sStatus, $sRelayNumber1 );
									onoff_rlb_powercenter($sNewResp,$sIP,$sDevicePort,$sShh);
									
									$sNewResp = replace_return($sNewResp, '0', $sRelayNumber );
									onoff_rlb_powercenter($sNewResp,$sIP,$sDevicePort,$sShh);
									
									$sStatus = '2';
								}
								
								$this->home_model->updateDeviceStauts($sName,$sDevice,$sStatus,$sIdIP);
								
							}
								
							
						}
					}
					else
					{
						if(preg_match('/Emulator/',$sPumpType))
						{
							$sNewResp = '';

							if($sStatus == '0')
								$sNewResp =  $sName.' '.$sStatus;
							else if($sStatus == '1')
							{
								/* $sType          =   '';
								if($sPumpSubType == 'VS')
									$sType  =   '2'.' '.$sPumpSpeed;
								elseif ($sPumpSubType == 'VF')
									$sType  =   '3'.' '.$sPumpFlow; */
									
								if($sPumpSubType == 'VS')
									$sType  =   $sPumpSpeed;
								elseif ($sPumpSubType == 'VF')
									$sType  =   $sPumpFlow;	

								$sNewResp =  $sName.' '.$sType;    
							}
							
							onoff_rlb_pump($sNewResp,$sIP,$sDevicePort,$sShh);
							
							if($sPumpType == 'Emulator12')
							{
								$sNewResp12 = replace_return($sPowercenter, $sStatus, $sRelayNumber );
								onoff_rlb_powercenter($sNewResp12,$sIP,$sDevicePort,$sShh);
							}
							if($sPumpType == 'Emulator24')
							{
								$sNewResp24 = replace_return($sRelays, $sStatus, $sRelayNumber );
								onoff_rlb_relay($sNewResp24,$sIP,$sDevicePort,$sShh);
								$this->home_model->updateDeviceRunTime($sRelayNumber,'R',$sStatus,$sIdIP);
							}
							$this->home_model->updateDeviceStauts($sName,$sDevice,$sStatus,$sIdIP);
							
						}
						else if(preg_match('/Intellicom/',$sPumpType))
						{
							$sNewResp = '';

							if($sStatus == '0')
								$sNewResp =  $sName.' '.$sStatus;
							else if($sStatus == '1')
							{
								//$sType  =   '2'.' '.$sPumpSpeed;
								$sType    =   $sPumpSpeed;
								$sNewResp =  $sName.' '.$sType;    
							}
							
							onoff_rlb_pump($sNewResp,$sIP,$sDevicePort,$sShh);
							
							if($sPumpType == 'Intellicom12')
							{
								$sNewResp12 = replace_return($sPowercenter, $sStatus, $sRelayNumber );
								onoff_rlb_powercenter($sNewResp12,$sIP,$sDevicePort,$sShh);
							}
							if($sPumpType == 'Intellicom24')
							{
								$sNewResp24 = replace_return($sRelays, $sStatus, $sRelayNumber );
								onoff_rlb_relay($sNewResp24,$sIP,$sDevicePort,$sShh);
								$this->home_model->updateDeviceRunTime($sRelayNumber,'R',$sStatus,$sIdIP);
							}
							
							$this->home_model->updateDeviceStauts($sName,$sDevice,$sStatus,$sIdIP);
						}
					}
					
					//Update details of program to which pump is related.
					if($sStatus == 0)
					{
						$aProgramDetails	=	$this->home_model->getProgramDetailsForDevice($sName,$sDevice,$sIdIP);
						
						foreach($aProgramDetails as $Program)
						{
							if($Program->program_active == '1')
							{
								$this->home_model->updateProgramStatus($Program->program_id, 0);
								if($Program->program_absolute == '1')
								{
									$aAbsoluteDetails   = array(
									'absolute_s'  => $Program->program_absolute_start_time,             'absolute_e'  => $Program->program_absolute_end_time,
									'absolute_t'  => $Program->program_absolute_total_time,
									'absolute_ar' => $Program->program_absolute_run_time,
									'absolute_sd' => $Program->program_absolute_start_date,
									'absolute_st' => $Program->program_absolute_run);
																
									$this->home_model->updateAlreadyRunTime($Program->program_id, $aAbsoluteDetails);
									
								}
							}
						}
					}
					//$this->home_model->updateDeviceStauts($sName,$sDevice,$sStatus);
				}
			}
           
        }
		
	}
	
	/**
	  * Function to Save Vera Light Device Settings using ajax.
	  * @param 
	  * @return
	**/
	public function saveVeraLightSetting()
	{
		$deviceID			= $this->input->post('deviceID');
		$deviceIPID			= $this->input->post('deviceIPID');
		$DeviceNumber		= $this->input->post('DeviceNumber');
		$DeviceManufacturer	= $this->input->post('DeviceManufacturer');
		$DeviceModel		= $this->input->post('DeviceModel');
		$IsSlider			= $this->input->post('IsSlider');
		
		$arrDetails			=	array('DeviceNumber'=>$DeviceNumber,
									  'DeviceManufacturer'=>$DeviceManufacturer,
									  'DeviceModel'=>$DeviceModel,
									  'IsSlider'=>$IsSlider
									  );
			
		$this->home_model->saveVeraLightDetails($deviceID,$deviceIPID,$arrDetails);
	}
	
	/**
	* Function to check if the Valve Default Position is Running.
	* 
	* @return
	*/
	public function CheckValveDefaultPositionRun()
	{
		$this->load->model('home_model');
		$CheckValveDefaultRunning = $this->home_model->CheckIfValveDefaultPositionRunning();
		
		echo $CheckValveDefaultRunning;
		exit;
	}
	
	/**
	* Function to Take the SD card image backup and save on the other server.
	* 
	* @return
	*/
	public function SaveSDCardImageBackup()
	{
		
	}
	
	/**
	* Function to get the Count of Running Valves.
	* 
	* @return
	*/
	public function GetRunningValveCount()
	{
		$this->load->model('home_model');
		list($sIpAddress, $sPortNo, $extra) = $this->home_model->getSettings();
		
		$ArrValves = array();
		//GET IP and Board Name.
		$aViewParameter['aIPDetails'] = $this->home_model->getBoardIP();
		
		//START : GET details for each IP.
		foreach($aViewParameter['aIPDetails'] as $IP)
		{
			$sResponse	= array();
			$sValves        =   '';
			$shhPort	=	'';
			if(IS_LOCAL == '1')
			{
				//Get SSH port of the RLB board using IP.
				$shhPort = $this->home_model->getSSHPortFromID($IP->id);
			}
			//Get the status response of devices from relay board.
			$sResponse      =   get_rlb_status($IP->ip,$sPortNo,$shhPort);
			$sValves        =   $sResponse['valves']; // Valve Device Status
			
			$ArrValves[$IP->id] = $sValves;
		}
		
		$OnValves = 0;
		
		foreach($ArrValves as $Valves)
		{
			$OnValves += substr_count($Valves, '1');
			$OnValves += substr_count($Valves, '2');
		}
		
		echo $OnValves;
		exit;
	}
	
	public function testing()
	{
		$this->load->model('device_model');
		$this->device_model->checkRelayAssignedToHeater(1,1,12);
	}
	
	/**
	* Function to show the custom program run log.
	* 
	* @return
	*/
	public function customProgramLog()
	{
		$this->load->model('custom_model');
		$aViewParameter['LogDetails'] = array();
		
		if($this->input->post('searchLog') == 'Search')
		{
			$sFromDate		=	$this->input->post('sFromDate');
			$sToDate		=	$this->input->post('sToDate');
			$CustomProgram	=	$this->input->post('CustomProgram');
			
			//$GetLogDetails = $this->custom_model->GetCustomProgramLog($sFromDate,$sToDate);
		}
		
		$GetAllCustomPrograms = $this->custom_model->GetAllActiveCustomPrograms();
		
		$aViewParameter['CustomPrograms'] = $GetAllCustomPrograms;
		$this->template->build('CustomProgramLog',$aViewParameter);
	}

}//END : Class Device

/* End of file device.php */
/* Location: ./application/controllers/device.php */