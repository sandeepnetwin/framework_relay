#!/bin/bash
while (sleep 15 && /usr/bin/php /var/www/html/relayboard/index.php cron pumpResponse) &
do
  wait $!
done
