
/*---------------------------------------------------------------
  SQL DB BACKUP 01.03.2017 03:45 
  TABLES: *
  ---------------------------------------------------------------*/

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";
--
-- Database: `relay_db`
--
-- --------------------------------------------------------

--
-- Table structure for table `ci_sessions`
--

CREATE TABLE IF NOT EXISTS `ci_sessions` (
  `session_id` varchar(40) NOT NULL DEFAULT '0',
  `ip_address` varchar(45) NOT NULL DEFAULT '0',
  `user_agent` varchar(120) NOT NULL,
  `last_activity` int(10) unsigned NOT NULL DEFAULT '0',
  `user_data` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `rlb_access_permissions`
--

CREATE TABLE IF NOT EXISTS `rlb_access_permissions` (
`id` int(10) NOT NULL,
  `user_id` int(5) NOT NULL,
  `module_id` int(5) NOT NULL,
  `access` enum('0','1','2') NOT NULL DEFAULT '0' COMMENT '0=block,1=View,2=View and change',
  `modified_date` datetime NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `rlb_access_permissions`
--

INSERT INTO `rlb_access_permissions` (`id`, `user_id`, `module_id`, `access`, `modified_date`) VALUES
(1, 4, 2, '1', '2015-08-24 08:14:43'),
(2, 4, 3, '1', '2015-08-24 08:14:43'),
(3, 4, 4, '1', '2015-08-24 08:14:44'),
(4, 4, 5, '0', '2015-08-24 08:14:44'),
(5, 4, 6, '0', '2015-08-24 08:14:44'),
(6, 4, 7, '2', '2015-08-24 08:14:44'),
(7, 4, 8, '1', '2015-08-24 08:14:44'),
(8, 4, 9, '1', '2015-08-24 08:14:44'),
(9, 4, 10, '1', '2015-08-24 08:14:44'),
(10, 4, 11, '1', '2015-08-24 08:14:44'),
(11, 4, 12, '1', '2015-08-24 08:14:44'),
(12, 4, 13, '0', '2015-08-24 08:14:44'),
(13, 5, 2, '1', '2015-12-28 07:28:21'),
(14, 5, 3, '1', '2015-12-28 07:28:21'),
(15, 5, 4, '0', '2015-12-28 07:28:21'),
(16, 5, 5, '1', '2015-12-28 07:28:21'),
(17, 5, 6, '0', '2015-12-28 07:28:21'),
(18, 5, 7, '0', '2015-12-28 07:28:21'),
(19, 5, 8, '1', '2015-12-28 07:28:22'),
(20, 5, 9, '1', '2015-12-28 07:28:22'),
(21, 5, 10, '1', '2015-12-28 07:28:22'),
(22, 5, 11, '0', '2015-12-28 07:28:22'),
(23, 5, 12, '0', '2015-12-28 07:28:22'),
(24, 5, 13, '0', '2015-12-28 07:28:22'),
(25, 5, 15, '0', '2015-12-28 07:28:22'),
(26, 5, 16, '0', '2015-12-28 07:28:22'),
(27, 5, 17, '0', '2015-12-28 07:28:22'),
(28, 5, 18, '0', '2015-12-28 07:28:22'),
(29, 5, 19, '0', '2015-12-28 07:28:22'),
(30, 5, 20, '0', '2015-12-28 07:28:23'),
(31, 5, 21, '1', '2015-12-28 07:28:23');

-- --------------------------------------------------------

--
-- Table structure for table `rlb_admin_users`
--

CREATE TABLE IF NOT EXISTS `rlb_admin_users` (
`id` int(11) NOT NULL,
  `username` varchar(150) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `block` tinyint(4) NOT NULL DEFAULT '0',
  `user_type` enum('SA','A') DEFAULT 'SA' COMMENT 'SA: Super Admin,A: Admin',
  `name` varchar(250) NOT NULL,
  `created_date` datetime NOT NULL,
  `parent_id` int(5) NOT NULL,
  `last_login` datetime NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `rlb_admin_users`
--

INSERT INTO `rlb_admin_users` (`id`, `username`, `email`, `password`, `block`, `user_type`, `name`, `created_date`, `parent_id`, `last_login`) VALUES
(1, 'admin', 'dhiraj.netwin@yahoo.com', 'YWRtaW4xMjM=', 0, 'SA', 'Admin', '0000-00-00 00:00:00', 0, '2017-12-14 22:55:02'),
(5, 'test', 'test@test.com', 'dGVzdDEyMw==', 0, 'A', 'Test', '2015-10-05 08:04:18', 1, '2016-01-22 08:22:34');

-- --------------------------------------------------------

--
-- Table structure for table `rlb_analog_device`
--

CREATE TABLE IF NOT EXISTS `rlb_analog_device` (
`analog_id` int(10) NOT NULL,
  `analog_input` int(10) NOT NULL,
  `analog_name` varchar(150) NOT NULL,
  `analog_device` varchar(100) NOT NULL,
  `analog_device_type` varchar(100) NOT NULL,
  `device_direction` int(5) NOT NULL,
  `analog_device_modified_date` datetime NOT NULL,
  `ip_id` int(5) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `rlb_analog_device`
--

INSERT INTO `rlb_analog_device` (`analog_id`, `analog_input`, `analog_name`, `analog_device`, `analog_device_type`, `device_direction`, `analog_device_modified_date`, `ip_id`) VALUES
(1, 0, 'AP0', '10', 'R', 0, '2016-01-22 11:19:21', 1),
(2, 1, 'AP1', '0', 'V', 1, '2016-01-22 11:19:21', 1),
(3, 2, 'AP2', '0', 'P', 0, '2016-01-22 11:19:21', 1),
(4, 3, 'AP3', '0', 'L', 0, '2016-01-22 11:19:22', 1),
(5, 0, 'AP0', '1', 'R', 0, '2016-01-22 11:19:22', 2),
(6, 1, 'AP1', '1', 'P', 0, '2016-01-22 11:19:22', 2),
(7, 2, 'AP2', '2', 'V', 2, '2016-01-22 11:19:22', 2),
(8, 3, 'AP3', '1', 'L', 0, '2016-01-22 11:19:22', 2);

-- --------------------------------------------------------

--
-- Table structure for table `rlb_board_ip`
--

CREATE TABLE IF NOT EXISTS `rlb_board_ip` (
`id` int(5) NOT NULL,
  `ip` varchar(150) NOT NULL,
  `name` text NOT NULL,
  `status` enum('0','1') NOT NULL DEFAULT '0',
  `ssh_port` varchar(10) DEFAULT NULL,
  `local_port` int(5) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `rlb_board_ip`
--

INSERT INTO `rlb_board_ip` (`id`, `ip`, `name`, `status`, `ssh_port`, `local_port`) VALUES
(1, '192.168.0.50', 'Device1', '0', '', 2222),
(3, '192.168.1.7', 'Device1', '1', '', 22);

-- --------------------------------------------------------

--
-- Table structure for table `rlb_custom_program`
--

CREATE TABLE IF NOT EXISTS `rlb_custom_program` (
`id` int(10) NOT NULL,
  `g_id` int(10) NOT NULL,
  `program_details` text NOT NULL,
  `is_on` enum('0','1') NOT NULL,
  `isremoved` enum('0','1') NOT NULL DEFAULT '0',
  `display_access` enum('0','1') NOT NULL DEFAULT '0',
  `already_running` enum('0','1') NOT NULL DEFAULT '0',
  `unique_id` varchar(255) NOT NULL,
  `program_start` varchar(250) DEFAULT NULL,
  `program_end` varchar(250) DEFAULT NULL,
  `afterProgram` enum('0','1') NOT NULL DEFAULT '0',
  `previousState` text NOT NULL,
  `is_schedule` enum('0','1') NOT NULL DEFAULT '0',
  `program_schedule_start` varchar(100) NOT NULL,
  `program_schedule_end` varchar(100) NOT NULL,
  `schedule_run` enum('0','1') NOT NULL DEFAULT '0',
  `program_type` int(2) NOT NULL COMMENT '0 - Daily,1 - Weekly',
  `program_days` varchar(50) NOT NULL COMMENT '0 - All, 1- Mon ... 7- Sat'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `rlb_custom_program_after`
--

CREATE TABLE IF NOT EXISTS `rlb_custom_program_after` (
`id` int(10) NOT NULL,
  `program_id` int(10) NOT NULL,
  `current_on_device` varchar(150) NOT NULL,
  `device_type` varchar(10) NOT NULL,
  `device_number` int(5) NOT NULL,
  `current_on_time` datetime NOT NULL,
  `current_off_time` datetime NOT NULL,
  `current_device_complete` enum('0','1') NOT NULL DEFAULT '0',
  `current_sequence` varchar(10) NOT NULL,
  `ip_id` int(5) NOT NULL,
  `unique_id` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `rlb_custom_program_current`
--

CREATE TABLE IF NOT EXISTS `rlb_custom_program_current` (
`id` int(10) NOT NULL,
  `program_id` int(10) NOT NULL,
  `current_on_device` varchar(150) NOT NULL,
  `device_type` varchar(10) NOT NULL,
  `device_number` int(5) NOT NULL,
  `current_on_time` datetime NOT NULL,
  `current_off_time` datetime NOT NULL,
  `current_device_complete` enum('0','1') NOT NULL DEFAULT '0',
  `current_sequence` varchar(10) NOT NULL,
  `ip_id` int(5) NOT NULL,
  `unique_id` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `rlb_custom_program_log`
--

CREATE TABLE IF NOT EXISTS `rlb_custom_program_log` (
`id` int(10) NOT NULL,
  `program_id` int(10) NOT NULL,
  `device` varchar(150) NOT NULL,
  `device_type` varchar(10) NOT NULL,
  `device_number` int(5) NOT NULL,
  `device_start` datetime NOT NULL,
  `device_stop` datetime NOT NULL,
  `device_complete_run` enum('0','1') NOT NULL DEFAULT '0',
  `current_sequence` varchar(5) NOT NULL,
  `ip_id` int(5) NOT NULL,
  `unique_id` varchar(255) NOT NULL,
  `afterDevice` enum('0','1') NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `rlb_custom_program_run_details`
--

CREATE TABLE IF NOT EXISTS `rlb_custom_program_run_details` (
  `id` int(10) NOT NULL,
  `CustomProgramId` int(10) NOT NULL,
  `StartedFrom` enum('0','1','2','3','4') NOT NULL DEFAULT '0' COMMENT '''0'' => No Source , ''1'' => Relayboard, ''2'' => Relayboard Scheduled, ''3'' => Secured Showing, ''4'' => Subsection',
  `StoppedFrom` enum('0','1','2','3','4') NOT NULL DEFAULT '0' COMMENT '''0'' => No Source , ''1'' => Relayboard, ''2'' => Relayboard Scheduled, ''3'' => Secured Showing, ''4'' => Subsection',
  `IsCompleted` enum('0','1') NOT NULL DEFAULT '0',
  `StartDate` datetime NOT NULL,
  `EndDate` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `rlb_device`
--

CREATE TABLE IF NOT EXISTS `rlb_device` (
`device_id` int(10) NOT NULL,
  `device_number` int(10) NOT NULL,
  `device_name` varchar(150) NOT NULL,
  `device_type` varchar(100) NOT NULL,
  `device_power_type` varchar(10) DEFAULT NULL COMMENT '0=24VAC,1=12VDC',
  `device_position` text,
  `device_total_time` varchar(100) NOT NULL,
  `device_start_time` varchar(100) NOT NULL,
  `device_end_time` varchar(100) NOT NULL,
  `last_updated_date` datetime NOT NULL,
  `is_pool_or_spa` enum('0','1','2') NOT NULL DEFAULT '0' COMMENT '0=Other,1=Spa,2=Pool',
  `valve_relay_number` varchar(150) NOT NULL,
  `light_relay_number` text NOT NULL,
  `ip_id` int(5) NOT NULL,
  `show_dashboard` enum('0','1') NOT NULL DEFAULT '0',
  `valvePump` text NOT NULL,
  `temperature_offset` float(10,2) NOT NULL,
  `DeviceType` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `rlb_device_last_run_details`
--

CREATE TABLE IF NOT EXISTS `rlb_device_last_run_details` (
`id` int(10) NOT NULL,
  `device_number` int(5) NOT NULL,
  `device_type` varchar(100) NOT NULL,
  `device_position` varchar(100) NOT NULL,
  `ip_id` int(5) NOT NULL,
  `added_date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `rlb_exclude_device`
--

CREATE TABLE IF NOT EXISTS `rlb_exclude_device` (
`id` int(5) NOT NULL,
  `exclude_devices` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `rlb_heater_run`
--

CREATE TABLE IF NOT EXISTS `rlb_heater_run` (
`id` int(10) NOT NULL,
  `heaterNumber` int(5) NOT NULL,
  `ip_id` int(5) NOT NULL,
  `heaterRun` enum('0','1') NOT NULL DEFAULT '0',
  `heaterStart` datetime NOT NULL,
  `heaterEnd` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `rlb_logs`
--

CREATE TABLE IF NOT EXISTS `rlb_logs` (
`id` int(10) NOT NULL,
  `Service` text NOT NULL,
  `ServiceMessage` text NOT NULL,
  `ServiceDevice` text NOT NULL,
  `ServiceDeviceNumber` int(5) NOT NULL,
  `ServiceDeviceIP` int(5) NOT NULL,
  `ServiceCommand` text NOT NULL,
  `ServiceDateTime` datetime NOT NULL,
  `ServiceStatus` enum('0','1') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `rlb_modes`
--

CREATE TABLE IF NOT EXISTS `rlb_modes` (
`mode_id` int(11) NOT NULL,
  `mode_name` varchar(255) NOT NULL,
  `mode_status` int(1) NOT NULL DEFAULT '0',
  `start_time` datetime NOT NULL,
  `timer_total` varchar(150) NOT NULL,
  `timer_start` varchar(150) NOT NULL,
  `timer_end` varchar(150) NOT NULL,
  `unique_id` varchar(100) NOT NULL
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `rlb_modes`
--

INSERT INTO `rlb_modes` (`mode_id`, `mode_name`, `mode_status`, `start_time`, `timer_total`, `timer_start`, `timer_end`, `unique_id`) VALUES
(1, 'Auto', 1, '2017-12-15 12:39:19', '', '', '', ''),
(2, 'Manual', 0, '0000-00-00 00:00:00', '480', '2017-02-27 12:37:18', '2017-02-27 20:37:18', ''),
(3, 'Time-Out', 0, '0000-00-00 00:00:00', '', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `rlb_mode_questions`
--

CREATE TABLE IF NOT EXISTS `rlb_mode_questions` (
`id` int(5) NOT NULL,
  `general` text NOT NULL,
  `device` text NOT NULL,
  `heater` text NOT NULL,
  `more` text NOT NULL,
  `added_date` datetime NOT NULL,
  `last_modified` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `rlb_pool_spa_current`
--

CREATE TABLE IF NOT EXISTS `rlb_pool_spa_current` (
`id` int(10) NOT NULL,
  `mode_id` int(5) NOT NULL,
  `current_on_device` varchar(255) NOT NULL,
  `device_type` varchar(10) NOT NULL,
  `device_number` varchar(10) NOT NULL,
  `current_on_time` datetime NOT NULL,
  `current_off_time` datetime NOT NULL,
  `current_device_complete` enum('0','1') NOT NULL,
  `current_unique_id` varchar(100) NOT NULL,
  `current_sequence` int(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `rlb_pool_spa_log`
--

CREATE TABLE IF NOT EXISTS `rlb_pool_spa_log` (
`id` int(10) NOT NULL,
  `mode_id` int(5) NOT NULL,
  `unique_id` varchar(100) NOT NULL,
  `device` varchar(150) NOT NULL,
  `device_type` varchar(10) NOT NULL,
  `device_number` varchar(10) NOT NULL,
  `device_start` datetime NOT NULL,
  `device_stop` datetime NOT NULL,
  `device_complete_run` enum('0','1','2') NOT NULL DEFAULT '0',
  `current_sequence` int(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `rlb_pool_spa_mode`
--

CREATE TABLE IF NOT EXISTS `rlb_pool_spa_mode` (
`id` int(5) NOT NULL,
  `mode_name` varchar(150) NOT NULL,
  `mode_status` enum('0','1') NOT NULL DEFAULT '0',
  `total_run_time` varchar(100) NOT NULL,
  `last_start_date` datetime NOT NULL,
  `last_end_date` datetime NOT NULL,
  `unique_id` varchar(100) NOT NULL,
  `all_device_on` enum('0','1') NOT NULL DEFAULT '0'
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `rlb_pool_spa_mode`
--

INSERT INTO `rlb_pool_spa_mode` (`id`, `mode_name`, `mode_status`, `total_run_time`, `last_start_date`, `last_end_date`, `unique_id`, `all_device_on`) VALUES
(1, 'Pool', '1', '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '', '0'),
(2, 'Spa', '0', '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '', '0'),
(3, 'Both', '0', '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '', '0'),
(4, 'Pool Auto', '0', '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '', '0');

-- --------------------------------------------------------

--
-- Table structure for table `rlb_position`
--

CREATE TABLE IF NOT EXISTS `rlb_position` (
`id` int(5) NOT NULL,
  `position_name` varchar(250) NOT NULL,
  `position_device` varchar(100) NOT NULL,
  `position_active` enum('0','1') NOT NULL DEFAULT '0',
  `position_added_date` datetime NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `rlb_position`
--

INSERT INTO `rlb_position` (`id`, `position_name`, `position_device`, `position_active`, `position_added_date`) VALUES
(2, 'Pool', '', '1', '2015-12-04 07:51:03'),
(3, 'Spa', '', '1', '2015-12-04 07:51:08'),
(4, 'Other', '', '1', '2015-12-04 07:51:16'),
(5, 'Waterfall', '', '1', '2015-12-04 07:55:54'),
(6, 'Spa 1 Open', '', '1', '2016-06-22 09:34:15'),
(7, 'Spa 1 Closed', '', '1', '2016-06-22 09:34:33'),
(8, 'Spa 2 open', '', '1', '2016-06-22 09:36:23'),
(9, 'Spa 2 closed', '', '1', '2016-06-22 09:36:36'),
(10, 'Spa 1 ', '', '1', '2016-06-22 09:39:24'),
(11, 'Spa 2', '', '1', '2016-06-22 09:39:34'),
(12, 'Spa 2 Jets On', '', '1', '2016-06-22 09:45:28'),
(13, 'Spa 2 Jets Off', '', '1', '2016-06-22 09:45:39'),
(14, 'Waterfall on', '', '1', '2016-06-22 09:48:39'),
(15, 'Waterfall off', '', '1', '2016-06-22 09:48:48'),
(16, 'F Pool Return', '', '1', '2016-06-22 09:53:41'),
(17, 'F Pool Waterfall', '', '1', '2016-06-22 09:59:16'),
(18, 'Jet Stream', '', '1', '2016-06-22 10:08:53'),
(19, 'Solar On', '', '1', '2016-06-22 10:11:09'),
(20, 'Solar Off', '', '1', '2016-06-22 10:11:22');

-- --------------------------------------------------------

--
-- Table structure for table `rlb_powercenters`
--

CREATE TABLE IF NOT EXISTS `rlb_powercenters` (
`powercenter_id` int(11) NOT NULL,
  `powercenter_number` int(11) NOT NULL,
  `powercenter_name` varchar(100) NOT NULL
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `rlb_powercenters`
--

INSERT INTO `rlb_powercenters` (`powercenter_id`, `powercenter_number`, `powercenter_name`) VALUES
(1, 0, 'Test powercenter0'),
(2, 4, 'pc4 edit'),
(3, 2, 'Testing'),
(4, 1, 'PowerCenter1');

-- --------------------------------------------------------

--
-- Table structure for table `rlb_program`
--

CREATE TABLE IF NOT EXISTS `rlb_program` (
`program_id` int(11) NOT NULL,
  `program_name` varchar(255) NOT NULL,
  `device_number` varchar(8) NOT NULL,
  `device_type` varchar(8) NOT NULL,
  `program_type` int(2) NOT NULL COMMENT '1-Daily, 2-Weekly',
  `program_days` varchar(255) NOT NULL COMMENT '0-All, 1-Mon, 2-Tue...7-Sun',
  `start_time` varchar(255) NOT NULL,
  `end_time` varchar(255) NOT NULL,
  `program_created_date` datetime NOT NULL,
  `program_modified_date` datetime NOT NULL,
  `program_delete` int(1) NOT NULL DEFAULT '0',
  `program_active` int(1) NOT NULL DEFAULT '0',
  `program_absolute` enum('0','1') NOT NULL DEFAULT '0',
  `program_absolute_start_time` varchar(100) DEFAULT NULL,
  `program_absolute_end_time` varchar(100) DEFAULT NULL,
  `program_absolute_total_time` varchar(100) DEFAULT NULL,
  `program_absolute_run_time` varchar(100) DEFAULT NULL,
  `program_absolute_start_date` date DEFAULT NULL,
  `program_absolute_run` enum('0','1') NOT NULL DEFAULT '0',
  `is_on_after_reboot` enum('0','1') NOT NULL DEFAULT '0',
  `program_work_in_mode` enum('0','1') NOT NULL DEFAULT '0',
  `ip_id` int(5) NOT NULL,
  `valvePosition` int(5) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `rlb_pump_device`
--

CREATE TABLE IF NOT EXISTS `rlb_pump_device` (
`pump_id` int(10) NOT NULL,
  `pump_number` int(5) NOT NULL,
  `pump_type` enum('12','24','Intellicom','Emulator','Intellicom12','Intellicom24','Emulator12','Emulator24','2Speed') NOT NULL,
  `pump_sub_type` enum('VS','VF','12','24') NOT NULL,
  `pump_speed` varchar(150) NOT NULL,
  `pump_flow` varchar(250) NOT NULL,
  `pump_closure` varchar(150) NOT NULL,
  `relay_number` varchar(10) NOT NULL,
  `pump_address` varchar(50) NOT NULL,
  `pump_modified_date` datetime NOT NULL,
  `relay_number_1` varchar(10) NOT NULL,
  `status` enum('0','1','2') NOT NULL DEFAULT '0',
  `ip_id` int(5) NOT NULL,
  `pump_on` enum('0','1') NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `rlb_pump_heater`
--

CREATE TABLE IF NOT EXISTS `rlb_pump_heater` (
`id` int(10) NOT NULL,
  `pump` varchar(10) NOT NULL,
  `end_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `rlb_pump_response`
--

CREATE TABLE IF NOT EXISTS `rlb_pump_response` (
`id` int(10) NOT NULL,
  `pump_number` int(5) NOT NULL,
  `pump_response_time` datetime NOT NULL,
  `pump_response` varchar(255) DEFAULT NULL,
  `ip_id` int(5) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `rlb_reboot_history`
--

CREATE TABLE IF NOT EXISTS `rlb_reboot_history` (
`id` int(10) NOT NULL,
  `details` text NOT NULL,
  `ip_id` int(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `rlb_relays`
--

CREATE TABLE IF NOT EXISTS `rlb_relays` (
`relay_id` int(11) NOT NULL,
  `relay_number` int(11) NOT NULL,
  `relay_name` varchar(100) NOT NULL
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `rlb_relays`
--

INSERT INTO `rlb_relays` (`relay_id`, `relay_number`, `relay_name`) VALUES
(1, 0, 'Test Realy 1'),
(2, 2, 'Test for relay 2'),
(3, 3, 'Test for relay3 editedaf'),
(4, 5, 'rl5'),
(5, 10, 'relay 10'),
(6, 1, 'Test Relay 11111');

-- --------------------------------------------------------

--
-- Table structure for table `rlb_relay_prog`
--

CREATE TABLE IF NOT EXISTS `rlb_relay_prog` (
`relay_prog_id` int(11) NOT NULL,
  `relay_prog_name` varchar(255) NOT NULL,
  `relay_number` varchar(8) NOT NULL,
  `relay_prog_type` int(2) NOT NULL COMMENT '1-Daily, 2-Weekly',
  `relay_prog_days` varchar(255) NOT NULL COMMENT '0-All, 1-Mon, 2-Tue...7-Sun',
  `relay_start_time` varchar(255) NOT NULL,
  `relay_end_time` varchar(255) NOT NULL,
  `relay_prog_created_date` datetime NOT NULL,
  `relay_prog_modified_date` datetime NOT NULL,
  `relay_prog_delete` int(1) NOT NULL DEFAULT '0',
  `relay_prog_active` int(1) NOT NULL DEFAULT '0',
  `relay_prog_absolute` enum('0','1') NOT NULL DEFAULT '0',
  `relay_prog_absolute_start_time` varchar(100) DEFAULT NULL,
  `relay_prog_absolute_end_time` varchar(100) DEFAULT NULL,
  `relay_prog_absolute_total_time` varchar(100) DEFAULT NULL,
  `relay_prog_absolute_run_time` varchar(100) DEFAULT NULL,
  `relay_prog_absolute_start_date` date DEFAULT NULL,
  `relay_prog_absolute_run` enum('0','1') NOT NULL DEFAULT '0'
) ENGINE=MyISAM AUTO_INCREMENT=12 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `rlb_relay_prog`
--

INSERT INTO `rlb_relay_prog` (`relay_prog_id`, `relay_prog_name`, `relay_number`, `relay_prog_type`, `relay_prog_days`, `relay_start_time`, `relay_end_time`, `relay_prog_created_date`, `relay_prog_modified_date`, `relay_prog_delete`, `relay_prog_active`, `relay_prog_absolute`, `relay_prog_absolute_start_time`, `relay_prog_absolute_end_time`, `relay_prog_absolute_total_time`, `relay_prog_absolute_run_time`, `relay_prog_absolute_start_date`, `relay_prog_absolute_run`) VALUES
(1, 'test', '0', 1, '0', '23:00:00', '23:30:00', '2015-04-03 15:40:46', '2015-07-10 12:37:12', 0, 0, '0', NULL, NULL, NULL, NULL, NULL, '0'),
(2, 'newtest1', '0', 2, '2,3,6', '14:00:00', '20:00:00', '2015-04-07 00:00:00', '2015-04-07 00:00:00', 0, 0, '0', NULL, NULL, NULL, NULL, NULL, '0'),
(3, 'testrelay0', '0', 2, '1,4,5', '22:00:00', '23:30:00', '2015-04-07 00:00:00', '2015-04-07 00:00:00', 0, 0, '0', NULL, NULL, NULL, NULL, NULL, '0'),
(4, 'testrelay1', '1', 1, '0', '10:00:00', '13:00:00', '2015-04-08 00:00:00', '2015-04-08 00:00:00', 0, 0, '0', NULL, NULL, NULL, NULL, NULL, '0'),
(5, 'Weeklytest', '0', 2, '2,6', '01:00:00', '01:30:00', '2015-04-20 00:00:00', '2015-04-20 00:00:00', 1, 0, '0', NULL, NULL, NULL, NULL, NULL, '0'),
(6, '</>', '0', 1, '0', '</>', '</>', '2015-04-24 00:00:00', '2015-04-24 00:00:00', 1, 0, '0', NULL, NULL, NULL, NULL, NULL, '0'),
(7, 'dhiraj Test', '0', 1, '0', '02:00:00', '02:30:00', '2015-07-06 00:00:00', '2015-07-13 12:50:40', 0, 0, '1', NULL, NULL, '00:30:00', '', NULL, '0'),
(8, 'Test', '0', 2, '2,4,6', '00:00:00', '01:00:00', '2015-07-09 07:31:37', '0000-00-00 00:00:00', 1, 0, '0', NULL, NULL, NULL, NULL, NULL, '0'),
(9, 'Test Relay 1', '1', 2, '2,3,4', '00:30:00', '01:00:00', '2015-07-09 08:38:46', '2015-07-09 08:40:21', 1, 0, '0', NULL, NULL, NULL, NULL, NULL, '0'),
(10, 'Program2', '1', 2, '2,3', '02:00:00', '04:00:00', '2015-07-09 09:05:11', '2015-07-09 09:05:23', 0, 0, '0', NULL, NULL, NULL, NULL, NULL, '0'),
(11, 'Test Relay Number', '0', 2, '3', '01:00:00', '02:00:00', '2015-07-09 11:41:53', '2015-07-10 14:56:21', 0, 0, '1', NULL, NULL, '01:00:00', NULL, NULL, '0');

-- --------------------------------------------------------

--
-- Table structure for table `rlb_run_after_heater`
--

CREATE TABLE IF NOT EXISTS `rlb_run_after_heater` (
`id` int(10) NOT NULL,
  `heaterNumber` int(10) NOT NULL,
  `pumpNumber` int(10) NOT NULL,
  `heaterStopTime` datetime NOT NULL,
  `PumpStopTime` datetime NOT NULL,
  `ip_id` int(5) NOT NULL,
  `runComplete` enum('0','1') NOT NULL DEFAULT '0',
  `program_id` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `rlb_setting`
--

CREATE TABLE IF NOT EXISTS `rlb_setting` (
`id` int(5) NOT NULL,
  `ip_address` varchar(100) DEFAULT NULL,
  `port_no` varchar(100) DEFAULT NULL,
  `port_no_2` varchar(150) NOT NULL,
  `extra` text NOT NULL,
  `ip_external` varchar(150) NOT NULL,
  `old_ip` varchar(200) NOT NULL,
  `is_updated` enum('0','1') NOT NULL DEFAULT '0'
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `rlb_setting`
--

INSERT INTO `rlb_setting` (`id`, `ip_address`, `port_no`, `port_no_2`, `extra`, `ip_external`, `old_ip`, `is_updated`) VALUES
(1, '192.168.1.7', '13330', '13331', 'a:24:{s:9:"Pool_Temp";i:1;s:17:"Pool_Temp_Address";s:3:"TS0";s:8:"Spa_Temp";i:0;s:16:"Spa_Temp_Address";s:0:"";s:11:"PumpsNumber";s:1:"1";s:11:"ValveNumber";s:1:"2";s:10:"Remote_Spa";s:1:"1";s:11:"LightNumber";s:1:"1";s:12:"HeaterNumber";s:1:"1";s:12:"BlowerNumber";s:1:"1";s:10:"MiscNumber";s:1:"1";s:18:"Remote_Spa_display";s:1:"1";s:8:"SecondIP";s:1:"0";s:15:"showTemperature";s:1:"1";s:16:"showTemperature2";s:1:"1";s:17:"level_measurement";d:17.5;s:12:"PumpsNumber2";s:1:"0";s:12:"ValveNumber2";s:1:"0";s:12:"LightNumber2";s:1:"0";s:13:"HeaterNumber2";s:1:"0";s:13:"BlowerNumber2";s:1:"0";s:11:"MiscNumber2";s:1:"0";s:11:"Remote_Spa2";s:1:"0";s:19:"Remote_Spa_display2";s:1:"0";}', '72.193.38.98', '72.193.38.98', '0');

-- --------------------------------------------------------

--
-- Table structure for table `rlb_site_modules`
--

CREATE TABLE IF NOT EXISTS `rlb_site_modules` (
`id` int(10) NOT NULL,
  `module_name` varchar(250) NOT NULL,
  `module_active` enum('0','1') NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `rlb_site_modules`
--

INSERT INTO `rlb_site_modules` (`id`, `module_name`, `module_active`) VALUES
(2, '24V AC Relayz', '1'),
(3, '12V DC Power Center Relay', '1'),
(4, 'Modes', '1'),
(5, 'Lights', '1'),
(6, 'Spa Devices', '1'),
(7, 'Pool Devices', '1'),
(8, 'Valve', '1'),
(9, 'Pump', '1'),
(10, 'Temperature Sensors', '1'),
(11, 'Input', '1'),
(12, 'Settings', '1'),
(13, 'Status', '1'),
(15, 'Log', '1'),
(16, 'Light', '1'),
(17, 'Heater', '1'),
(18, 'Pool and Spa', '1'),
(19, 'Blower', '1'),
(20, 'Miscellaneous', '1'),
(21, 'Advance Settings', '1');

-- --------------------------------------------------------

--
-- Table structure for table `rlb_valves`
--

CREATE TABLE IF NOT EXISTS `rlb_valves` (
`valve_id` int(11) NOT NULL,
  `valve_number` int(11) NOT NULL,
  `valve_name` varchar(100) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `rlb_valve_default_position`
--

CREATE TABLE IF NOT EXISTS `rlb_valve_default_position` (
`id` int(5) NOT NULL,
  `valve` int(5) NOT NULL,
  `ip_id` int(5) NOT NULL,
  `position` int(5) NOT NULL,
  `positiontime` int(5) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `rlb_valve_default_position`
--

INSERT INTO `rlb_valve_default_position` (`id`, `valve`, `ip_id`, `position`, `positiontime`) VALUES
(1, 0, 1, 1, 1),
(2, 1, 1, 1, 1),
(3, 2, 1, 1, 1),
(4, 4, 1, 1, 1),
(5, 5, 1, 1, 1),
(6, 6, 1, 2, 1),
(7, 0, 2, 1, 1),
(8, 1, 2, 2, 1),
(9, 2, 2, 2, 1),
(10, 3, 2, 2, 1),
(11, 4, 2, 1, 1),
(12, 5, 2, 2, 1);

-- --------------------------------------------------------

--
-- Table structure for table `rlb_valve_default_position_current`
--

CREATE TABLE IF NOT EXISTS `rlb_valve_default_position_current` (
`id` int(10) NOT NULL,
  `run_id` int(10) NOT NULL,
  `current_on_device` varchar(150) NOT NULL,
  `current_on_device_type` varchar(10) NOT NULL,
  `current_on_device_number` int(5) NOT NULL,
  `current_on_device_start` datetime NOT NULL,
  `current_on_device_stop` datetime NOT NULL,
  `current_device_complete` enum('0','1') NOT NULL DEFAULT '0',
  `current_sequence` varchar(10) NOT NULL,
  `ip_id` int(5) NOT NULL,
  `unique_id` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `rlb_valve_default_position_log`
--

CREATE TABLE IF NOT EXISTS `rlb_valve_default_position_log` (
  `id` int(10) NOT NULL,
  `run_id` int(10) NOT NULL,
  `device` varchar(150) NOT NULL,
  `device_type` varchar(10) NOT NULL,
  `device_number` int(5) NOT NULL,
  `device_start` datetime NOT NULL,
  `device_stop` datetime NOT NULL,
  `device_complete_run` enum('0','1') NOT NULL DEFAULT '0',
  `current_sequence` varchar(5) NOT NULL,
  `ip_id` int(5) NOT NULL,
  `unique_id` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `rlb_valve_default_position_mode_run`
--

CREATE TABLE IF NOT EXISTS `rlb_valve_default_position_mode_run` (
  `id` int(10) NOT NULL,
  `UniqueID` varchar(50) NOT NULL,
  `DeviceNumberToRun` int(2) NOT NULL,
  `StartDateTime` datetime NOT NULL,
  `EndDateTime` datetime NOT NULL,
  `IsCompleted` enum('0','1') NOT NULL DEFAULT '0' COMMENT '''0'' => Not Completed, ''1'' => Completed',
  `StartedFrom` enum('0','1','2','3') NOT NULL DEFAULT '0' COMMENT '''0'' => No Source , ''1'' => Relayboard, ''2'' => Subsection,''3''=> Manual',
  `StoppedFrom` enum('0','1','2','3') NOT NULL DEFAULT '0' COMMENT '''0'' => No Source , ''1'' => Relayboard, ''2'' => Subsection,''3''=> Manual',
  `IsRunning` enum('0','1') NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `rlb_valve_default_position_run`
--

CREATE TABLE IF NOT EXISTS `rlb_valve_default_position_run` (
`id` int(10) NOT NULL,
  `program_id` int(5) NOT NULL,
  `valve` int(5) NOT NULL,
  `ip_id` int(5) NOT NULL,
  `start_time` datetime NOT NULL,
  `end_time` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `rlb_vera_details`
--

CREATE TABLE IF NOT EXISTS `rlb_vera_details` (
`id` int(5) NOT NULL,
  `VeraUsername` varchar(150) NOT NULL,
  `VeraPassword` varchar(50) NOT NULL,
  `VeraVersion` int(2) NOT NULL,
  `VeraPhone` varchar(50) NOT NULL,
  `VeraAddedDate` datetime NOT NULL,
  `VeraModifiedDate` datetime NOT NULL,
  `VeraServer` varchar(250) NOT NULL,
  `VeraSession` varchar(250) NOT NULL,
  `VeraPKDevice` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `ci_sessions`
--
ALTER TABLE `ci_sessions`
 ADD PRIMARY KEY (`session_id`), ADD KEY `last_activity_idx` (`last_activity`);

--
-- Indexes for table `rlb_access_permissions`
--
ALTER TABLE `rlb_access_permissions`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `rlb_admin_users`
--
ALTER TABLE `rlb_admin_users`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `rlb_analog_device`
--
ALTER TABLE `rlb_analog_device`
 ADD PRIMARY KEY (`analog_id`);

--
-- Indexes for table `rlb_board_ip`
--
ALTER TABLE `rlb_board_ip`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `rlb_custom_program`
--
ALTER TABLE `rlb_custom_program`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `rlb_custom_program_after`
--
ALTER TABLE `rlb_custom_program_after`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `rlb_custom_program_current`
--
ALTER TABLE `rlb_custom_program_current`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `rlb_custom_program_log`
--
ALTER TABLE `rlb_custom_program_log`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `rlb_device`
--
ALTER TABLE `rlb_device`
 ADD PRIMARY KEY (`device_id`);

--
-- Indexes for table `rlb_device_last_run_details`
--
ALTER TABLE `rlb_device_last_run_details`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `rlb_exclude_device`
--
ALTER TABLE `rlb_exclude_device`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `rlb_heater_run`
--
ALTER TABLE `rlb_heater_run`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `rlb_logs`
--
ALTER TABLE `rlb_logs`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `rlb_modes`
--
ALTER TABLE `rlb_modes`
 ADD PRIMARY KEY (`mode_id`);

--
-- Indexes for table `rlb_mode_questions`
--
ALTER TABLE `rlb_mode_questions`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `rlb_pool_spa_current`
--
ALTER TABLE `rlb_pool_spa_current`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `rlb_pool_spa_log`
--
ALTER TABLE `rlb_pool_spa_log`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `rlb_pool_spa_mode`
--
ALTER TABLE `rlb_pool_spa_mode`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `rlb_position`
--
ALTER TABLE `rlb_position`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `rlb_powercenters`
--
ALTER TABLE `rlb_powercenters`
 ADD PRIMARY KEY (`powercenter_id`);

--
-- Indexes for table `rlb_program`
--
ALTER TABLE `rlb_program`
 ADD PRIMARY KEY (`program_id`);

--
-- Indexes for table `rlb_pump_device`
--
ALTER TABLE `rlb_pump_device`
 ADD PRIMARY KEY (`pump_id`);

--
-- Indexes for table `rlb_pump_heater`
--
ALTER TABLE `rlb_pump_heater`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `rlb_pump_response`
--
ALTER TABLE `rlb_pump_response`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `rlb_reboot_history`
--
ALTER TABLE `rlb_reboot_history`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `rlb_relays`
--
ALTER TABLE `rlb_relays`
 ADD PRIMARY KEY (`relay_id`);

--
-- Indexes for table `rlb_relay_prog`
--
ALTER TABLE `rlb_relay_prog`
 ADD PRIMARY KEY (`relay_prog_id`);

--
-- Indexes for table `rlb_run_after_heater`
--
ALTER TABLE `rlb_run_after_heater`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `rlb_setting`
--
ALTER TABLE `rlb_setting`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `rlb_site_modules`
--
ALTER TABLE `rlb_site_modules`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `rlb_valves`
--
ALTER TABLE `rlb_valves`
 ADD PRIMARY KEY (`valve_id`);

--
-- Indexes for table `rlb_valve_default_position`
--
ALTER TABLE `rlb_valve_default_position`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `rlb_valve_default_position_current`
--
ALTER TABLE `rlb_valve_default_position_current`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `rlb_valve_default_position_run`
--
ALTER TABLE `rlb_valve_default_position_run`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `rlb_vera_details`
--
ALTER TABLE `rlb_vera_details`
 ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `rlb_access_permissions`
--
ALTER TABLE `rlb_access_permissions`
MODIFY `id` int(10) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=32;
--
-- AUTO_INCREMENT for table `rlb_admin_users`
--
ALTER TABLE `rlb_admin_users`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `rlb_analog_device`
--
ALTER TABLE `rlb_analog_device`
MODIFY `analog_id` int(10) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `rlb_board_ip`
--
ALTER TABLE `rlb_board_ip`
MODIFY `id` int(5) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `rlb_custom_program`
--
ALTER TABLE `rlb_custom_program`
MODIFY `id` int(10) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `rlb_custom_program_after`
--
ALTER TABLE `rlb_custom_program_after`
MODIFY `id` int(10) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `rlb_custom_program_current`
--
ALTER TABLE `rlb_custom_program_current`
MODIFY `id` int(10) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `rlb_custom_program_log`
--
ALTER TABLE `rlb_custom_program_log`
MODIFY `id` int(10) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `rlb_device`
--
ALTER TABLE `rlb_device`
MODIFY `device_id` int(10) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `rlb_device_last_run_details`
--
ALTER TABLE `rlb_device_last_run_details`
MODIFY `id` int(10) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `rlb_exclude_device`
--
ALTER TABLE `rlb_exclude_device`
MODIFY `id` int(5) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `rlb_heater_run`
--
ALTER TABLE `rlb_heater_run`
MODIFY `id` int(10) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `rlb_logs`
--
ALTER TABLE `rlb_logs`
MODIFY `id` int(10) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `rlb_modes`
--
ALTER TABLE `rlb_modes`
MODIFY `mode_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `rlb_mode_questions`
--
ALTER TABLE `rlb_mode_questions`
MODIFY `id` int(5) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `rlb_pool_spa_current`
--
ALTER TABLE `rlb_pool_spa_current`
MODIFY `id` int(10) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `rlb_pool_spa_log`
--
ALTER TABLE `rlb_pool_spa_log`
MODIFY `id` int(10) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `rlb_pool_spa_mode`
--
ALTER TABLE `rlb_pool_spa_mode`
MODIFY `id` int(5) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `rlb_position`
--
ALTER TABLE `rlb_position`
MODIFY `id` int(5) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=21;
--
-- AUTO_INCREMENT for table `rlb_powercenters`
--
ALTER TABLE `rlb_powercenters`
MODIFY `powercenter_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `rlb_program`
--
ALTER TABLE `rlb_program`
MODIFY `program_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `rlb_pump_device`
--
ALTER TABLE `rlb_pump_device`
MODIFY `pump_id` int(10) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `rlb_pump_heater`
--
ALTER TABLE `rlb_pump_heater`
MODIFY `id` int(10) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `rlb_pump_response`
--
ALTER TABLE `rlb_pump_response`
MODIFY `id` int(10) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `rlb_reboot_history`
--
ALTER TABLE `rlb_reboot_history`
MODIFY `id` int(10) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `rlb_relays`
--
ALTER TABLE `rlb_relays`
MODIFY `relay_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `rlb_relay_prog`
--
ALTER TABLE `rlb_relay_prog`
MODIFY `relay_prog_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=12;
--
-- AUTO_INCREMENT for table `rlb_run_after_heater`
--
ALTER TABLE `rlb_run_after_heater`
MODIFY `id` int(10) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `rlb_setting`
--
ALTER TABLE `rlb_setting`
MODIFY `id` int(5) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `rlb_site_modules`
--
ALTER TABLE `rlb_site_modules`
MODIFY `id` int(10) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=22;
--
-- AUTO_INCREMENT for table `rlb_valves`
--
ALTER TABLE `rlb_valves`
MODIFY `valve_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `rlb_valve_default_position`
--
ALTER TABLE `rlb_valve_default_position`
MODIFY `id` int(5) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=13;
--
-- AUTO_INCREMENT for table `rlb_valve_default_position_current`
--
ALTER TABLE `rlb_valve_default_position_current`
MODIFY `id` int(10) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `rlb_valve_default_position_run`
--
ALTER TABLE `rlb_valve_default_position_run`
MODIFY `id` int(10) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `rlb_vera_details`
--
ALTER TABLE `rlb_vera_details`
MODIFY `id` int(5) NOT NULL AUTO_INCREMENT;