#!/bin/bash
while true
do
 /usr/bin/php /var/www/relayboard/index.php cron pumpResponse
sleep 15
done
