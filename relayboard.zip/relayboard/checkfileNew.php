<?php
/* echo date('Y-m-d H:i:s');
die; */
// string to search in a filename.
$searchString = '\0';//\x00 //\x95
//$searchString = 'api.hostip.';$filesFound = array();$pattern  = '\0';$pattern2 = '\x95';$patterns = array('\0'); $regex = '/' .implode('|', $patterns) .'/'; //echo $content = file_get_contents("/var/www/relayboard/assets/style.css_24_05_2016");//die;function listFolderFiles($dir,&$filesFound){    $ffs = scandir($dir);	/* foreach($ffs as $ff){		if(!is_dir($dir.'/'.$ff))		{			$content = file_get_contents("$ff");			//echo '<br>---------------------------------</br>';			if(preg_match('/\0/',$content,$matches))			{					$filesFound[] = $ff;			} 		}		else		{			if(is_dir($dir.'/'.$ff)) listFolderFiles($dir.'/'.$ff,$filesFound);		}	}		return $filesFound; */		    //echo '<ol>';    foreach($ffs as $ff){        if($ff != '.' && $ff != '..'){            //echo '<li>'.$ff;            if(is_dir($dir.'/'.$ff)) listFolderFiles($dir.'/'.$ff,$filesFound);			else			{				//if($ff == 'style.css_24_05_2016')				{					$content = file_get_contents($dir.'/'.$ff);					//$content = file_get_contents("/var/www/relayboard/assets/style.css_24_05_2016");					//echo '<br>---------------------------------</br>';					if(preg_match('/\0/',$content,$matches))					{							$filesFound[] = $dir.'/'.$ff;					} 				}			}			//echo '</li>';        }    }  //  echo '</ol>';	return $filesFound;}listFolderFiles('/var/www/relayboard',$filesFound);echo "output the results: $dir<br>";echo '<pre>';print_r($filesFound);echo '</pre>';

// all files in my/dir with the extension 
// .php 
/* $dir = '';
$files = glob($dir.'*.*');
// array populated with files found 
// containing the search string.
$filesFound = array();
// iterate through the files and determine 
// if the filename contains the search string.
foreach($files as $file) {	//echo '<br>'.$file;	if($file == 'jquery.sidr.min.js_30_05_2016')	{
		$content = file_get_contents("$file");		//echo '<br>---------------------------------</br>';		//if (strpos($content, $searchString) !== false) {					if(preg_match('/\0/',$content,$matches))		{	
			 $filesFound[] = $file;
		} 	}	//echo $file.'<br>';
}


//output the results.
echo "output the results: $dir<br>";
echo '<pre>';
print_r($filesFound);
echo '</pre>'; */

?>