<?php

$url = 'https://vera-us-oem-relay41.mios.com/relay/relay/relay/device/35011801/session/010490CB278FC10C61889B4B8751709B2EFC83/port_3480/data_request?id=scene&action=create';

$AuthToken = 'eyJFeHBpcmVzIjoxNDQ1NTA5Mjc1LCJHZW5lcmF0ZWQiOjE0NDU0MjI4NzUsIlBlcm1pc3Npb25zIjpbeyJQS19QZXJtaXNzaW9uIjoxLCJNb2RlIjoxfSx7IlBLX1Blcm1pc3Npb24iOjIsIk1vZGUiOjF9LHsiUEtfUGVybWlzc2lvbiI6MywiTW9kZSI6MX0seyJQS19QZXJtaXNzaW9uIjo0LCJNb2RlIjoxfSx7IlBLX1Blcm1pc3Npb24iOjYsIk1vZGUiOjF9LHsiUEtfUGVybWlzc2lvbiI6OSwiTW9kZSI6MX0seyJQS19QZXJtaXNzaW9uIjoxNCwiTW9kZSI6MX0seyJQS19QZXJtaXNzaW9uIjoxNSwiTW9kZSI6MX0seyJQS19QZXJtaXNzaW9uIjoxNywiTW9kZSI6MX0seyJQS19QZXJtaXNzaW9uIjoxOCwiTW9kZSI6MX0seyJQS19QZXJtaXNzaW9uIjoxOSwiTW9kZSI6MX0seyJQS19QZXJtaXNzaW9uIjoyMCwiTW9kZSI6MX0seyJQS19QZXJtaXNzaW9uIjoyMSwiTW9kZSI6MX0seyJQS19QZXJtaXNzaW9uIjoyMiwiTW9kZSI6MX0seyJQS19QZXJtaXNzaW9uIjoyMywiTW9kZSI6MX0seyJQS19QZXJtaXNzaW9uIjoyNSwiTW9kZSI6MX0seyJQS19QZXJtaXNzaW9uIjoyNiwiTW9kZSI6MX0seyJQS19QZXJtaXNzaW9uIjoyNywiTW9kZSI6MX0seyJQS19QZXJtaXNzaW9uIjoyOCwiTW9kZSI6MX0seyJQS19QZXJtaXNzaW9uIjoyOSwiTW9kZSI6MX0seyJQS19QZXJtaXNzaW9uIjozMCwiTW9kZSI6MX0seyJQS19QZXJtaXNzaW9uIjo0MSwiTW9kZSI6MX0seyJQS19QZXJtaXNzaW9uIjo0MiwiTW9kZSI6MX0seyJQS19QZXJtaXNzaW9uIjo0MywiTW9kZSI6MX0seyJQS19QZXJtaXNzaW9uIjo1MiwiTW9kZSI6MX0seyJQS19QZXJtaXNzaW9uIjo2MiwiTW9kZSI6MX0seyJQS19QZXJtaXNzaW9uIjo3MiwiTW9kZSI6MX0seyJQS19QZXJtaXNzaW9uIjo4MiwiTW9kZSI6MX0seyJQS19QZXJtaXNzaW9uIjo5MiwiTW9kZSI6MX0seyJQS19QZXJtaXNzaW9uIjoxMDIsIk1vZGUiOjF9LHsiUEtfUGVybWlzc2lvbiI6MTEyLCJNb2RlIjoxfSx7IlBLX1Blcm1pc3Npb24iOjEyMiwiTW9kZSI6MX0seyJQS19QZXJtaXNzaW9uIjoxMzIsIk1vZGUiOjF9LHsiUEtfUGVybWlzc2lvbiI6MTQyLCJNb2RlIjoxfSx7IlBLX1Blcm1pc3Npb24iOjE1MiwiTW9kZSI6MX0seyJQS19QZXJtaXNzaW9uIjoxNjIsIk1vZGUiOjF9LHsiUEtfUGVybWlzc2lvbiI6MTcyLCJNb2RlIjoxfSx7IlBLX1Blcm1pc3Npb24iOjE4MiwiTW9kZSI6MX0seyJQS19QZXJtaXNzaW9uIjoxOTIsIk1vZGUiOjF9LHsiUEtfUGVybWlzc2lvbiI6MjAyLCJNb2RlIjoxfSx7IlBLX1Blcm1pc3Npb24iOjIxMiwiTW9kZSI6MX0seyJQS19QZXJtaXNzaW9uIjoyMjIsIk1vZGUiOjF9LHsiUEtfUGVybWlzc2lvbiI6MjMyLCJNb2RlIjoxfSx7IlBLX1Blcm1pc3Npb24iOjI0MiwiTW9kZSI6MX0seyJQS19QZXJtaXNzaW9uIjoyNTIsIk1vZGUiOjF9LHsiUEtfUGVybWlzc2lvbiI6MjYyLCJNb2RlIjoxfSx7IlBLX1Blcm1pc3Npb24iOjI3MiwiTW9kZSI6MX0seyJQS19QZXJtaXNzaW9uIjoyODIsIk1vZGUiOjF9LHsiUEtfUGVybWlzc2lvbiI6MjkyLCJNb2RlIjoxfSx7IlBLX1Blcm1pc3Npb24iOjMwMiwiTW9kZSI6MX0seyJQS19QZXJtaXNzaW9uIjozMTIsIk1vZGUiOjF9LHsiUEtfUGVybWlzc2lvbiI6MzIyLCJNb2RlIjoxfSx7IlBLX1Blcm1pc3Npb24iOjMzMiwiTW9kZSI6MX0seyJQS19QZXJtaXNzaW9uIjozNDIsIk1vZGUiOjF9LHsiUEtfUGVybWlzc2lvbiI6NDgyLCJNb2RlIjoxfSx7IlBLX1Blcm1pc3Npb24iOjQ5MiwiTW9kZSI6MX0seyJQS19QZXJtaXNzaW9uIjo1ODIsIk1vZGUiOjF9LHsiUEtfUGVybWlzc2lvbiI6Njg1LCJNb2RlIjoxfSx7IlBLX1Blcm1pc3Npb24iOjcwNSwiTW9kZSI6MX0seyJQS19QZXJtaXNzaW9uIjo3MzEsIk1vZGUiOjF9LHsiUEtfUGVybWlzc2lvbiI6MTU5NiwiTW9kZSI6MX0seyJQS19QZXJtaXNzaW9uIjoxNjA2LCJNb2RlIjoxfSx7IlBLX1Blcm1pc3Npb24iOjE2MTYsIk1vZGUiOjF9LHsiUEtfUGVybWlzc2lvbiI6MTYyNiwiTW9kZSI6MX1dLCJQS19BY2NvdW50IjoyMzAyNDEsIlBLX0FjY291bnRUeXBlIjo1LCJQS19BY2NvdW50Q2hpbGQiOjAsIlBLX0FjY291bnRfUGFyZW50IjoyMzc1LCJQS19BcHAiOjAsIlBLX09lbSI6MSwiUEtfT2VtX1VzZXIiOiIiLCJQS19QZXJtaXNzaW9uUm9sZSI6MTAsIlBLX1VzZXIiOjEyNjc3NjEsIlBLX1NlcnZlcl9BdXRoIjoxLCJQS19TZXJ2ZXJfQWNjb3VudCI6NiwiUEtfU2VydmVyX0V2ZW50IjoxNCwiU2VydmVyX0F1dGgiOiJ2ZXJhLXVzLW9lbS1hdXRoYTExLm1pb3MuY29tIiwiVXNlcm5hbWUiOiIyNjVncmVhdGR1a2UifQ==';
$AuthSigToken = 'UBhQrDt9amynhDOpHxS2cz77LrLHOO+WndoayuulSOQMtXhtPN+to2mpPHJmohyk142jfgdVKIvaZUZZzAN8mQncoZgbXo2KkA+z0rwYeBXvRYdosRuG67ufDKGXr6NE1TQLqpZtMkPAhbf/eUjkbwuB3ieaDc0CYNaCN2KPA9ZoEt3MzY/IcoWOl06pxZj3CQyocIUQdrex1NShvnpJWIYp7QJbcLsPKieqDL4gzX6GvVxPSbpBfhVOuBei7tqwnHGChx9p6LnOijICqGpGwRwC3/EN28os7vaksDkOIR7ScohmZYcp5WOCfHnaa+ws0MGa1vV9On14FX+DPaG5Zg==';

$aPostData = array('json' => '{"scene_name":"om","name":"om","groups":[{"delay":0,"actions":[{"device":"14","service":"urn:upnp-org:serviceId:HVAC_UserOperatingMode1","action":"SetModeTarget","arguments":[{"name":"NewModeTarget","value":"CoolOn"}]}]}],"triggers":[{"name":"tttttttt","enabled":1,"device":"12","template":"1","arguments":[{"id":1,"value":"0"}]}],"timers":[],"lua":"","users": "","modeStatus": "0","id": 1000001}');

$array = array(
			'scene_name' => 'om',
			'name'	=> 'om',
			'groups' => array('delay'=>0,'actions'=>array('device'=>14,'service'=>'urn:upnp-org:serviceId:HVAC_UserOperatingMode1','action'=>'SetModeTarget','arguments'=>array('name'=>'NewModeTarget','value'=>'CoolOn'))),
			'triggers'=>array('name'=>'tttttttt','enabled'=>1,'device'=>12,'template'=>1,'arguments'=>array('id'=>1,'value'=>0)),
			'timers'=>array(),
			'lua'=>'',
			'users'=>'',
			'modeStatus'=>'0',
			'id'=>'1000001'
		 );

$data_string = json_encode($array);
//die;
$fields_string = '';
   foreach($aPostData as $key=>$value) { $fields_string .= $key.'='.$value.'&'; }
   $fields_string = rtrim($fields_string, '&');



$request = new HttpRequest();
$request->setUrl('https://vera-us-oem-relay41.mios.com/relay/relay/relay/device/35011801/session/010490CB278FC10C61889B4B8751709B2EFC83/port_3480/data_request');
$request->setMethod(HTTP_METH_POST);

$request->setQueryData(array(
  'id' => 'scene',
  'action' => 'create',
  'json' => '{"scene_name":"om","name":"om","groups":{"delay":0,"actions":{"device":14,"service":"urn:upnp-org:serviceId:HVAC_UserOperatingMode1","action":"SetModeTarget","arguments":{"name":"NewModeTarget","value":"CoolOn"}}},"triggers":{"name":"tttttttt","enabled":1,"device":12,"template":1,"arguments":{"id":1,"value":0}},"timers":[],"lua":"","users":"","modeStatus":"0","id":"1000001"}'
));

$request->setHeaders(array(
  'postman-token' => '56135670-dbce-de4b-42b2-91a47ed1cbdf',
  'cache-control' => 'no-cache',
  'mmsauthsig' => 'UBhQrDt9amynhDOpHxS2cz77LrLHOO+WndoayuulSOQMtXhtPN+to2mpPHJmohyk142jfgdVKIvaZUZZzAN8mQncoZgbXo2KkA+z0rwYeBXvRYdosRuG67ufDKGXr6NE1TQLqpZtMkPAhbf/eUjkbwuB3ieaDc0CYNaCN2KPA9ZoEt3MzY/IcoWOl06pxZj3CQyocIUQdrex1NShvnpJWIYp7QJbcLsPKieqDL4gzX6GvVxPSbpBfhVOuBei7tqwnHGChx9p6LnOijICqGpGwRwC3/EN28os7vaksDkOIR7ScohmZYcp5WOCfHnaa+ws0MGa1vV9On14FX+DPaG5Zg==',
  'mmsauth' => 'eyJFeHBpcmVzIjoxNDQ1NTA5Mjc1LCJHZW5lcmF0ZWQiOjE0NDU0MjI4NzUsIlBlcm1pc3Npb25zIjpbeyJQS19QZXJtaXNzaW9uIjoxLCJNb2RlIjoxfSx7IlBLX1Blcm1pc3Npb24iOjIsIk1vZGUiOjF9LHsiUEtfUGVybWlzc2lvbiI6MywiTW9kZSI6MX0seyJQS19QZXJtaXNzaW9uIjo0LCJNb2RlIjoxfSx7IlBLX1Blcm1pc3Npb24iOjYsIk1vZGUiOjF9LHsiUEtfUGVybWlzc2lvbiI6OSwiTW9kZSI6MX0seyJQS19QZXJtaXNzaW9uIjoxNCwiTW9kZSI6MX0seyJQS19QZXJtaXNzaW9uIjoxNSwiTW9kZSI6MX0seyJQS19QZXJtaXNzaW9uIjoxNywiTW9kZSI6MX0seyJQS19QZXJtaXNzaW9uIjoxOCwiTW9kZSI6MX0seyJQS19QZXJtaXNzaW9uIjoxOSwiTW9kZSI6MX0seyJQS19QZXJtaXNzaW9uIjoyMCwiTW9kZSI6MX0seyJQS19QZXJtaXNzaW9uIjoyMSwiTW9kZSI6MX0seyJQS19QZXJtaXNzaW9uIjoyMiwiTW9kZSI6MX0seyJQS19QZXJtaXNzaW9uIjoyMywiTW9kZSI6MX0seyJQS19QZXJtaXNzaW9uIjoyNSwiTW9kZSI6MX0seyJQS19QZXJtaXNzaW9uIjoyNiwiTW9kZSI6MX0seyJQS19QZXJtaXNzaW9uIjoyNywiTW9kZSI6MX0seyJQS19QZXJtaXNzaW9uIjoyOCwiTW9kZSI6MX0seyJQS19QZXJtaXNzaW9uIjoyOSwiTW9kZSI6MX0seyJQS19QZXJtaXNzaW9uIjozMCwiTW9kZSI6MX0seyJQS19QZXJtaXNzaW9uIjo0MSwiTW9kZSI6MX0seyJQS19QZXJtaXNzaW9uIjo0MiwiTW9kZSI6MX0seyJQS19QZXJtaXNzaW9uIjo0MywiTW9kZSI6MX0seyJQS19QZXJtaXNzaW9uIjo1MiwiTW9kZSI6MX0seyJQS19QZXJtaXNzaW9uIjo2MiwiTW9kZSI6MX0seyJQS19QZXJtaXNzaW9uIjo3MiwiTW9kZSI6MX0seyJQS19QZXJtaXNzaW9uIjo4MiwiTW9kZSI6MX0seyJQS19QZXJtaXNzaW9uIjo5MiwiTW9kZSI6MX0seyJQS19QZXJtaXNzaW9uIjoxMDIsIk1vZGUiOjF9LHsiUEtfUGVybWlzc2lvbiI6MTEyLCJNb2RlIjoxfSx7IlBLX1Blcm1pc3Npb24iOjEyMiwiTW9kZSI6MX0seyJQS19QZXJtaXNzaW9uIjoxMzIsIk1vZGUiOjF9LHsiUEtfUGVybWlzc2lvbiI6MTQyLCJNb2RlIjoxfSx7IlBLX1Blcm1pc3Npb24iOjE1MiwiTW9kZSI6MX0seyJQS19QZXJtaXNzaW9uIjoxNjIsIk1vZGUiOjF9LHsiUEtfUGVybWlzc2lvbiI6MTcyLCJNb2RlIjoxfSx7IlBLX1Blcm1pc3Npb24iOjE4MiwiTW9kZSI6MX0seyJQS19QZXJtaXNzaW9uIjoxOTIsIk1vZGUiOjF9LHsiUEtfUGVybWlzc2lvbiI6MjAyLCJNb2RlIjoxfSx7IlBLX1Blcm1pc3Npb24iOjIxMiwiTW9kZSI6MX0seyJQS19QZXJtaXNzaW9uIjoyMjIsIk1vZGUiOjF9LHsiUEtfUGVybWlzc2lvbiI6MjMyLCJNb2RlIjoxfSx7IlBLX1Blcm1pc3Npb24iOjI0MiwiTW9kZSI6MX0seyJQS19QZXJtaXNzaW9uIjoyNTIsIk1vZGUiOjF9LHsiUEtfUGVybWlzc2lvbiI6MjYyLCJNb2RlIjoxfSx7IlBLX1Blcm1pc3Npb24iOjI3MiwiTW9kZSI6MX0seyJQS19QZXJtaXNzaW9uIjoyODIsIk1vZGUiOjF9LHsiUEtfUGVybWlzc2lvbiI6MjkyLCJNb2RlIjoxfSx7IlBLX1Blcm1pc3Npb24iOjMwMiwiTW9kZSI6MX0seyJQS19QZXJtaXNzaW9uIjozMTIsIk1vZGUiOjF9LHsiUEtfUGVybWlzc2lvbiI6MzIyLCJNb2RlIjoxfSx7IlBLX1Blcm1pc3Npb24iOjMzMiwiTW9kZSI6MX0seyJQS19QZXJtaXNzaW9uIjozNDIsIk1vZGUiOjF9LHsiUEtfUGVybWlzc2lvbiI6NDgyLCJNb2RlIjoxfSx7IlBLX1Blcm1pc3Npb24iOjQ5MiwiTW9kZSI6MX0seyJQS19QZXJtaXNzaW9uIjo1ODIsIk1vZGUiOjF9LHsiUEtfUGVybWlzc2lvbiI6Njg1LCJNb2RlIjoxfSx7IlBLX1Blcm1pc3Npb24iOjcwNSwiTW9kZSI6MX0seyJQS19QZXJtaXNzaW9uIjo3MzEsIk1vZGUiOjF9LHsiUEtfUGVybWlzc2lvbiI6MTU5NiwiTW9kZSI6MX0seyJQS19QZXJtaXNzaW9uIjoxNjA2LCJNb2RlIjoxfSx7IlBLX1Blcm1pc3Npb24iOjE2MTYsIk1vZGUiOjF9LHsiUEtfUGVybWlzc2lvbiI6MTYyNiwiTW9kZSI6MX1dLCJQS19BY2NvdW50IjoyMzAyNDEsIlBLX0FjY291bnRUeXBlIjo1LCJQS19BY2NvdW50Q2hpbGQiOjAsIlBLX0FjY291bnRfUGFyZW50IjoyMzc1LCJQS19BcHAiOjAsIlBLX09lbSI6MSwiUEtfT2VtX1VzZXIiOiIiLCJQS19QZXJtaXNzaW9uUm9sZSI6MTAsIlBLX1VzZXIiOjEyNjc3NjEsIlBLX1NlcnZlcl9BdXRoIjoxLCJQS19TZXJ2ZXJfQWNjb3VudCI6NiwiUEtfU2VydmVyX0V2ZW50IjoxNCwiU2VydmVyX0F1dGgiOiJ2ZXJhLXVzLW9lbS1hdXRoYTExLm1pb3MuY29tIiwiVXNlcm5hbWUiOiIyNjVncmVhdGR1a2UifQ=='
));

try {
  $response = $request->send();

  echo $response->getBody();
} catch (HttpException $ex) {
  echo $ex;
}






		


?>