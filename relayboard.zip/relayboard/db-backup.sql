
/*---------------------------------------------------------------
  SQL DB BACKUP 01.01.2017 03:46 
  TABLES: *
  ---------------------------------------------------------------*/

/*---------------------------------------------------------------
  TABLE: `ci_sessions`
  ---------------------------------------------------------------*/
DROP TABLE IF EXISTS `ci_sessions`;
CREATE TABLE `ci_sessions` (
  `session_id` varchar(40) NOT NULL DEFAULT '0',
  `ip_address` varchar(45) NOT NULL DEFAULT '0',
  `user_agent` varchar(120) NOT NULL,
  `last_activity` int(10) unsigned NOT NULL DEFAULT '0',
  `user_data` text NOT NULL,
  PRIMARY KEY (`session_id`),
  KEY `last_activity_idx` (`last_activity`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*---------------------------------------------------------------
  TABLE: `rlb_access_permissions`
  ---------------------------------------------------------------*/
DROP TABLE IF EXISTS `rlb_access_permissions`;
CREATE TABLE `rlb_access_permissions` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `user_id` int(5) NOT NULL,
  `module_id` int(5) NOT NULL,
  `access` enum('0','1','2') NOT NULL DEFAULT '0' COMMENT '0=block,1=View,2=View and change',
  `modified_date` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=latin1;
INSERT INTO `rlb_access_permissions` VALUES   ('1','4','2','1','2015-08-24 08:14:43');
INSERT INTO `rlb_access_permissions` VALUES ('2','4','3','1','2015-08-24 08:14:43');
INSERT INTO `rlb_access_permissions` VALUES ('3','4','4','1','2015-08-24 08:14:44');
INSERT INTO `rlb_access_permissions` VALUES ('4','4','5','0','2015-08-24 08:14:44');
INSERT INTO `rlb_access_permissions` VALUES ('5','4','6','0','2015-08-24 08:14:44');
INSERT INTO `rlb_access_permissions` VALUES ('6','4','7','2','2015-08-24 08:14:44');
INSERT INTO `rlb_access_permissions` VALUES ('7','4','8','1','2015-08-24 08:14:44');
INSERT INTO `rlb_access_permissions` VALUES ('8','4','9','1','2015-08-24 08:14:44');
INSERT INTO `rlb_access_permissions` VALUES ('9','4','10','1','2015-08-24 08:14:44');
INSERT INTO `rlb_access_permissions` VALUES ('10','4','11','1','2015-08-24 08:14:44');
INSERT INTO `rlb_access_permissions` VALUES ('11','4','12','1','2015-08-24 08:14:44');
INSERT INTO `rlb_access_permissions` VALUES ('12','4','13','0','2015-08-24 08:14:44');
INSERT INTO `rlb_access_permissions` VALUES ('13','5','2','1','2015-12-28 07:28:21');
INSERT INTO `rlb_access_permissions` VALUES ('14','5','3','1','2015-12-28 07:28:21');
INSERT INTO `rlb_access_permissions` VALUES ('15','5','4','0','2015-12-28 07:28:21');
INSERT INTO `rlb_access_permissions` VALUES ('16','5','5','1','2015-12-28 07:28:21');
INSERT INTO `rlb_access_permissions` VALUES ('17','5','6','0','2015-12-28 07:28:21');
INSERT INTO `rlb_access_permissions` VALUES ('18','5','7','0','2015-12-28 07:28:21');
INSERT INTO `rlb_access_permissions` VALUES ('19','5','8','1','2015-12-28 07:28:22');
INSERT INTO `rlb_access_permissions` VALUES ('20','5','9','1','2015-12-28 07:28:22');
INSERT INTO `rlb_access_permissions` VALUES ('21','5','10','1','2015-12-28 07:28:22');
INSERT INTO `rlb_access_permissions` VALUES ('22','5','11','0','2015-12-28 07:28:22');
INSERT INTO `rlb_access_permissions` VALUES ('23','5','12','0','2015-12-28 07:28:22');
INSERT INTO `rlb_access_permissions` VALUES ('24','5','13','0','2015-12-28 07:28:22');
INSERT INTO `rlb_access_permissions` VALUES ('25','5','15','0','2015-12-28 07:28:22');
INSERT INTO `rlb_access_permissions` VALUES ('26','5','16','0','2015-12-28 07:28:22');
INSERT INTO `rlb_access_permissions` VALUES ('27','5','17','0','2015-12-28 07:28:22');
INSERT INTO `rlb_access_permissions` VALUES ('28','5','18','0','2015-12-28 07:28:22');
INSERT INTO `rlb_access_permissions` VALUES ('29','5','19','0','2015-12-28 07:28:22');
INSERT INTO `rlb_access_permissions` VALUES ('30','5','20','0','2015-12-28 07:28:23');
INSERT INTO `rlb_access_permissions` VALUES ('31','5','21','1','2015-12-28 07:28:23');

/*---------------------------------------------------------------
  TABLE: `rlb_admin_users`
  ---------------------------------------------------------------*/
DROP TABLE IF EXISTS `rlb_admin_users`;
CREATE TABLE `rlb_admin_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(150) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `block` tinyint(4) NOT NULL DEFAULT '0',
  `user_type` enum('SA','A') DEFAULT 'SA' COMMENT 'SA: Super Admin,A: Admin',
  `name` varchar(250) NOT NULL,
  `created_date` datetime NOT NULL,
  `parent_id` int(5) NOT NULL,
  `last_login` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;
INSERT INTO `rlb_admin_users` VALUES   ('1','admin','dhiraj.netwin@yahoo.com','YWRtaW4xMjM=','0','SA','Admin','0000-00-00 00:00:00','0','2016-12-30 02:16:51');
INSERT INTO `rlb_admin_users` VALUES ('5','test','test@test.com','dGVzdDEyMw==','0','A','Test','2015-10-05 08:04:18','1','2016-01-22 08:22:34');

/*---------------------------------------------------------------
  TABLE: `rlb_analog_device`
  ---------------------------------------------------------------*/
DROP TABLE IF EXISTS `rlb_analog_device`;
CREATE TABLE `rlb_analog_device` (
  `analog_id` int(10) NOT NULL AUTO_INCREMENT,
  `analog_input` int(10) NOT NULL,
  `analog_name` varchar(150) NOT NULL,
  `analog_device` varchar(100) NOT NULL,
  `analog_device_type` varchar(100) NOT NULL,
  `device_direction` int(5) NOT NULL,
  `analog_device_modified_date` datetime NOT NULL,
  `ip_id` int(5) NOT NULL,
  PRIMARY KEY (`analog_id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;
INSERT INTO `rlb_analog_device` VALUES   ('1','0','AP0','10','R','0','2016-01-22 11:19:21','1');
INSERT INTO `rlb_analog_device` VALUES ('2','1','AP1','0','V','1','2016-01-22 11:19:21','1');
INSERT INTO `rlb_analog_device` VALUES ('3','2','AP2','0','P','0','2016-01-22 11:19:21','1');
INSERT INTO `rlb_analog_device` VALUES ('4','3','AP3','0','L','0','2016-01-22 11:19:22','1');
INSERT INTO `rlb_analog_device` VALUES ('5','0','AP0','1','R','0','2016-01-22 11:19:22','2');
INSERT INTO `rlb_analog_device` VALUES ('6','1','AP1','1','P','0','2016-01-22 11:19:22','2');
INSERT INTO `rlb_analog_device` VALUES ('7','2','AP2','2','V','2','2016-01-22 11:19:22','2');
INSERT INTO `rlb_analog_device` VALUES ('8','3','AP3','1','L','0','2016-01-22 11:19:22','2');

/*---------------------------------------------------------------
  TABLE: `rlb_board_ip`
  ---------------------------------------------------------------*/
DROP TABLE IF EXISTS `rlb_board_ip`;
CREATE TABLE `rlb_board_ip` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `ip` varchar(150) NOT NULL,
  `name` text NOT NULL,
  `status` enum('0','1') NOT NULL DEFAULT '0',
  `ssh_port` varchar(10) DEFAULT NULL,
  `local_port` int(5) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
INSERT INTO `rlb_board_ip` VALUES   ('1','192.168.0.50','Device1','1','','2222');
INSERT INTO `rlb_board_ip` VALUES ('2','192.168.0.115','Device2','1','','222');

/*---------------------------------------------------------------
  TABLE: `rlb_custom_program`
  ---------------------------------------------------------------*/
DROP TABLE IF EXISTS `rlb_custom_program`;
CREATE TABLE `rlb_custom_program` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `g_id` int(10) NOT NULL,
  `program_details` text NOT NULL,
  `is_on` enum('0','1') NOT NULL,
  `isremoved` enum('0','1') NOT NULL DEFAULT '0',
  `display_access` enum('0','1') NOT NULL DEFAULT '0',
  `already_running` enum('0','1') NOT NULL DEFAULT '0',
  `unique_id` varchar(255) NOT NULL,
  `program_start` varchar(250) DEFAULT NULL,
  `program_end` varchar(250) DEFAULT NULL,
  `afterProgram` enum('0','1') NOT NULL DEFAULT '0',
  `previousState` text NOT NULL,
  `is_schedule` enum('0','1') NOT NULL DEFAULT '0',
  `program_schedule_start` varchar(100) NOT NULL,
  `program_schedule_end` varchar(100) NOT NULL,
  `schedule_run` enum('0','1') NOT NULL DEFAULT '0',
  `program_type` int(2) NOT NULL COMMENT '0 - Daily,1 - Weekly',
  `program_days` varchar(50) NOT NULL COMMENT '0 - All, 1- Mon ... 7- Sat',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=58 DEFAULT CHARSET=latin1;
INSERT INTO `rlb_custom_program` VALUES   ('1','15','{\"g_id\":\"15\",\"g_custom_mode_name\":\"Indoor_Spa\",\"g_rlb_pump_list\":\"1_2\",\"g_pump_sq\":\"7\",\"g_pump_time\":\"200\",\"g_rlb_valve_list\":\"1_2_4,1_1_5,1_2_6,2_2_0,2_2_3,2_1_4,2_2_5\",\"g_valve_sq\":\"3,6,6,1,2,4,5\",\"g_valve_time\":\"1,1,1,1,1,1,1\",\"g_custom_max_time\":\"400\",\"g_rlb_relay_list\":\"1_15\",\"g_relay_sq\":\"7\",\"g_relay_time\":\"200\",\"g_rlb_powercenter_list\":\"1_0\",\"g_powercenter_sq\":\"7\",\"g_powercenter_time\":\"200\"}','1','0','1','1','55252841483261389','2017-01-01 01:03:09','2017-01-01 07:43:09','0','a:7:{i:0;s:5:\"1_0_4\";i:1;s:5:\"1_0_5\";i:2;s:5:\"1_0_6\";i:3;s:5:\"2_0_0\";i:4;s:5:\"2_0_3\";i:5;s:5:\"2_0_4\";i:6;s:5:\"2_0_5\";}','0','0000-00-00 00:00:00','0000-00-00 00:00:00','0','0','');
INSERT INTO `rlb_custom_program` VALUES ('2','1','{\"g_id\":1,\"g_custom_mode_name\":\"Outdoor Spa 2 waterfall on\",\"g_custom_max_time\":\"20\",\"relayboardProgram\":\"1\",\"isSchedule\":\"1\",\"g_rlb_pump_list\":\"1_2\",\"g_pump_sq\":\"10\",\"g_pump_time\":\"1\",\"g_rlb_valve_list\":\"1_2_4,1_2_5,1_1_6,2_2_0,2_1_2,2_1_3,2_2_4,2_1_5\",\"g_valve_sq\":\"1,2,3,4,5,6,7,8\",\"g_valve_time\":\"1,1,1,1,1,1,1,1\",\"g_rlb_relay_list\":\"1_6\",\"g_relay_sq\":\"10\",\"g_relay_time\":\"1\",\"g_rlb_powercenter_list\":\"1_0\",\"g_powercenter_sq\":\"10\",\"g_powercenter_time\":\"1\"}','0','0','0','0','','2016-11-17 03:51:19','2016-11-17 04:11:19','0','','','','','0','0','');
INSERT INTO `rlb_custom_program` VALUES ('3','15','{\"g_id\":\"15\",\"g_custom_mode_name\":\"Indoor_Spa_Fill_10_Minute\",\"g_rlb_pump_list\":\"1_1\",\"g_pump_sq\":\"4\",\"g_pump_time\":\"10\",\"g_rlb_valve_list\":\"1_1_0,1_1_4,2_2_0,2_1_4,2_2_5\",\"g_valve_sq\":\"1,2,2,3,3\",\"g_valve_time\":\"1,1,1,1,1\",\"g_custom_max_time\":\"20\",\"g_rlb_relay_list\":\"null\",\"g_relay_sq\":\"\",\"g_relay_time\":\"\",\"g_rlb_powercenter_list\":\"null\",\"g_powercenter_sq\":\"\",\"g_powercenter_time\":\"\"}','0','0','1','0','','2016-12-30 00:28:15','2016-12-30 00:48:15','0','','0','0000-00-00 00:00:00','0000-00-00 00:00:00','0','0','');
INSERT INTO `rlb_custom_program` VALUES ('4','10','{\"g_id\":\"10\",\"g_custom_mode_name\":\"Custom_program_From_Local\",\"g_rlb_pump_list\":\"1_1,1_2\",\"g_pump_sq\":\"1,3\",\"g_pump_time\":\"10,1\",\"g_rlb_valve_list\":\"1_2_0,1_1_4\",\"g_valve_sq\":\"2,1\",\"g_valve_time\":\"20,5\",\"g_custom_max_time\":\"40\",\"g_rlb_relay_list\":\"null\",\"g_relay_sq\":\"\",\"g_relay_time\":\"\",\"g_rlb_powercenter_list\":\"null\",\"g_powercenter_sq\":\"\",\"g_powercenter_time\":\"\"}','0','0','1','0','','2016-07-21 06:13:48','2016-07-21 06:53:48','0','','0','0000-00-00 00:00:00','0000-00-00 00:00:00','0','0','');
INSERT INTO `rlb_custom_program` VALUES ('5','10','{\"g_id\":\"10\",\"g_custom_mode_name\":\"custom_program_local\",\"g_rlb_pump_list\":\"1_1\",\"g_pump_sq\":\"1\",\"g_pump_time\":\"10\",\"g_rlb_valve_list\":\"1_1_0,1_2_0\",\"g_valve_sq\":\"1,4\",\"g_valve_time\":\"20,1\",\"g_custom_max_time\":\"41\",\"g_rlb_relay_list\":\"1_7\",\"g_relay_sq\":\"2\",\"g_relay_time\":\"10\",\"g_rlb_powercenter_list\":\"1_1\",\"g_powercenter_sq\":\"3\",\"g_powercenter_time\":\"10\"}','0','0','1','0','','2016-07-21 05:30:00','2016-07-21 06:11:00','0','','0','0000-00-00 00:00:00','0000-00-00 00:00:00','0','0','');
INSERT INTO `rlb_custom_program` VALUES ('6','15','{\"g_id\":\"15\",\"g_custom_mode_name\":\"Waterfalls\",\"g_rlb_pump_list\":\"1_2\",\"g_pump_sq\":\"3\",\"g_pump_time\":\"60\",\"g_rlb_valve_list\":\"1_2_5,1_1_6,2_1_1,2_2_2\",\"g_valve_sq\":\"2,2,1,1\",\"g_valve_time\":\"1,1,1,1\",\"g_custom_max_time\":\"70\",\"g_rlb_relay_list\":\"null\",\"g_relay_sq\":\"\",\"g_relay_time\":\"\",\"g_rlb_powercenter_list\":\"null\",\"g_powercenter_sq\":\"\",\"g_powercenter_time\":\"\"}','0','0','1','0','','2016-12-31 22:31:48','2016-12-31 23:41:48','0','','0','0000-00-00 00:00:00','0000-00-00 00:00:00','0','0','');
INSERT INTO `rlb_custom_program` VALUES ('43','10','{\"g_id\":\"10\",\"g_custom_mode_name\":\"30_Jun_Local\",\"g_custom_max_time\":\"20\",\"g_rlb_pump_list\":\"1_1\",\"g_pump_sq\":\"1\",\"g_pump_time\":\"1\",\"g_rlb_valve_list\":\"2_2_0\",\"g_valve_sq\":\"2\",\"g_valve_time\":\"1\",\"g_rlb_relay_list\":\"1_7,2_15\",\"g_relay_sq\":\"3,4\",\"g_relay_time\":\"1,1\",\"g_rlb_powercenter_list\":\"1_1\",\"g_powercenter_sq\":\"5\",\"g_powercenter_time\":\"1\"}','0','0','0','0','',NULL,NULL,'0','','0','0000-00-00 00:00:00','0000-00-00 00:00:00','0','0','');
INSERT INTO `rlb_custom_program` VALUES ('44','16','{\"g_id\":\"16\",\"g_custom_mode_name\":\"Testing__Custom_program_\",\"g_custom_max_time\":\"200\",\"g_rlb_pump_list\":\"1_2\",\"g_pump_sq\":\"1\",\"g_pump_time\":\"1\",\"g_rlb_valve_list\":\"1_1_0\",\"g_valve_sq\":\"2\",\"g_valve_time\":\"1\",\"g_rlb_relay_list\":\"1_6,2_12\",\"g_relay_sq\":\"3,4\",\"g_relay_time\":\"1,1\",\"g_rlb_powercenter_list\":\"null\",\"g_powercenter_sq\":\"\",\"g_powercenter_time\":\"\"}','0','0','0','0','',NULL,NULL,'0','','0','0000-00-00 00:00:00','0000-00-00 00:00:00','0','0','');
INSERT INTO `rlb_custom_program` VALUES ('45','15','{\"g_id\":\"15\",\"g_custom_mode_name\":\"Spa_2_Clean_1_hr\",\"g_rlb_pump_list\":\"1_1\",\"g_pump_sq\":\"6\",\"g_pump_time\":\"60\",\"g_rlb_valve_list\":\"1_2_4,1_2_5,1_1_6,2_2_0,2_1_2,2_1_3,2_2_4,2_1_5\",\"g_valve_sq\":\"4,1,2,3,2,3,5,4\",\"g_valve_time\":\"1,1,1,1,1,1,1,1\",\"g_custom_max_time\":\"480\",\"g_rlb_relay_list\":\"null\",\"g_relay_sq\":\"\",\"g_relay_time\":\"\",\"g_rlb_powercenter_list\":\"null\",\"g_powercenter_sq\":\"\",\"g_powercenter_time\":\"\"}','0','0','1','0','','2016-12-28 16:10:41','2016-12-29 00:10:41','0','','0','0000-00-00 00:00:00','0000-00-00 00:00:00','0','0','');
INSERT INTO `rlb_custom_program` VALUES ('46','1','{\"g_id\":1,\"g_custom_mode_name\":\"Spa 1 and Waterfall (no jets)\",\"g_custom_max_time\":\"1200\",\"relayboardProgram\":\"1\",\"isSchedule\":\"1\",\"g_rlb_pump_list\":\"1_2\",\"g_pump_sq\":\"8\",\"g_pump_time\":\"1000\",\"g_rlb_valve_list\":\"1_2_4,1_2_5,1_1_6,2_2_0,2_1_1,2_2_2,2_2_3,2_1_4,2_2_5\",\"g_valve_sq\":\"2,6,1,1,3,5,2,3,4\",\"g_valve_time\":\"1,1,1,1,1,1,1,1,1\",\"g_rlb_relay_list\":\"1_15\",\"g_relay_sq\":\"8\",\"g_relay_time\":\"1001\",\"g_rlb_powercenter_list\":\"1_0\",\"g_powercenter_sq\":\"8\",\"g_powercenter_time\":\"1000\"}','0','0','1','0','','2016-12-02 14:12:14','2016-12-03 10:12:14','0','','','','','0','0','');
INSERT INTO `rlb_custom_program` VALUES ('47','10','{\"g_id\":\"15\",\"g_custom_mode_name\":\"Spa_2_Clean_1_hr\",\"g_rlb_pump_list\":\"1_1\",\"g_pump_sq\":\"6\",\"g_pump_time\":\"1\",\"g_rlb_valve_list\":\"1_2_4,1_2_5,1_1_6,2_2_0,2_1_2,2_1_3,2_2_4,2_1_5\",\"g_valve_sq\":\"4,1,2,3,2,3,5,4\",\"g_valve_time\":\"1,1,1,1,1,1,1,1\",\"g_custom_max_time\":\"480\",\"g_rlb_relay_list\":\"null\",\"g_relay_sq\":\"\",\"g_relay_time\":\"\",\"g_rlb_powercenter_list\":\"null\",\"g_powercenter_sq\":\"\",\"g_powercenter_time\":\"\"}','0','0','1','0','','2016-08-18 04:02:39','2016-08-18 12:02:39','0','','0','','','0','0','');
INSERT INTO `rlb_custom_program` VALUES ('48','1','{\"g_id\":1,\"g_custom_mode_name\":\"Heat Pool 4 Hours\",\"g_custom_max_time\":\"244\",\"relayboardProgram\":\"1\",\"isSchedule\":\"1\",\"g_rlb_pump_list\":\"\",\"g_pump_sq\":\"\",\"g_pump_time\":\"\",\"g_rlb_valve_list\":\"1_1_4,2_1_0\",\"g_valve_sq\":\"1,2\",\"g_valve_time\":\"1,1\",\"g_rlb_relay_list\":\"\",\"g_relay_sq\":\"\",\"g_relay_time\":\"\",\"g_rlb_powercenter_list\":\"1_1\",\"g_powercenter_sq\":\"3\",\"g_powercenter_time\":\"240\"}','0','0','1','0','','2016-12-22 09:24:16','2016-12-24 02:04:16','0','','','','','0','1','0');
INSERT INTO `rlb_custom_program` VALUES ('49','1','{\"g_id\":1,\"g_custom_mode_name\":\"test program 19 june\",\"g_custom_max_time\":\"10\",\"relayboardProgram\":\"1\",\"isSchedule\":\"1\",\"g_rlb_pump_list\":\"\",\"g_pump_sq\":\"\",\"g_pump_time\":\"\",\"g_rlb_valve_list\":\"1_2_4\",\"g_valve_sq\":\"1\",\"g_valve_time\":\"5\",\"g_rlb_relay_list\":\"\",\"g_relay_sq\":\"\",\"g_relay_time\":\"\",\"g_rlb_powercenter_list\":\"\",\"g_powercenter_sq\":\"\",\"g_powercenter_time\":\"\"}','0','0','1','0','','2016-08-30 03:36:17','2016-08-30 03:46:17','0','','','','','0','0','');
INSERT INTO `rlb_custom_program` VALUES ('50','15','{\"g_id\":\"15\",\"g_custom_mode_name\":\"Indoor_Spa_test\",\"g_rlb_pump_list\":\"1_2\",\"g_pump_sq\":\"7\",\"g_pump_time\":\"55\",\"g_rlb_valve_list\":\"1_2_4,1_1_5,1_2_6,2_2_0,2_2_3,2_1_4,2_2_5\",\"g_valve_sq\":\"3,6,6,1,2,4,5\",\"g_valve_time\":\"1,1,1,1,1,1,1\",\"g_custom_max_time\":\"400\",\"g_rlb_relay_list\":\"1_15\",\"g_relay_sq\":\"7\",\"g_relay_time\":\"55\",\"g_rlb_powercenter_list\":\"1_0\",\"g_powercenter_sq\":\"7\",\"g_powercenter_time\":\"55\"}','0','1','0','0','','2016-08-26 02:18:04','2016-08-26 08:58:04','0','','0','0000-00-00 00:00:00','0000-00-00 00:00:00','0','0','');
INSERT INTO `rlb_custom_program` VALUES ('51','15','{\"g_id\":\"15\",\"g_custom_mode_name\":\"Heat_Pool_5_hour_Spa_Return\",\"g_rlb_pump_list\":\"null\",\"g_pump_sq\":\"\",\"g_pump_time\":\"\",\"g_rlb_valve_list\":\"1_1_0,1_1_4,2_2_0\",\"g_valve_sq\":\"1,2,3\",\"g_valve_time\":\"1,1,1\",\"g_custom_max_time\":\"300\",\"g_rlb_relay_list\":\"null\",\"g_relay_sq\":\"\",\"g_relay_time\":\"\",\"g_rlb_powercenter_list\":\"1_1\",\"g_powercenter_sq\":\"4\",\"g_powercenter_time\":\"254\"}','0','0','1','0','','2016-12-31 22:31:35','2017-01-01 03:31:35','0','','0','','','0','0','');
INSERT INTO `rlb_custom_program` VALUES ('52','1','{\"g_id\":\"1\",\"g_custom_mode_name\":\"28_dec\",\"g_custom_max_time\":\"10\",\"g_rlb_pump_list\":\"null\",\"g_pump_sq\":\"\",\"g_pump_time\":\"\",\"g_rlb_valve_list\":\"1_1_0\",\"g_valve_sq\":\"1,2\",\"g_valve_time\":\"1,1\",\"g_rlb_relay_list\":\"null\",\"g_relay_sq\":\"\",\"g_relay_time\":\"\",\"g_rlb_powercenter_list\":\"null\",\"g_powercenter_sq\":\"\",\"g_powercenter_time\":\"\"}','0','1','0','0','',NULL,NULL,'0','','0','','','0','0','');
INSERT INTO `rlb_custom_program` VALUES ('53','10','{\"g_id\":\"10\",\"g_custom_mode_name\":\"dec_28\",\"g_custom_max_time\":\"10\",\"g_rlb_pump_list\":\"null\",\"g_pump_sq\":\"\",\"g_pump_time\":\"\",\"g_rlb_valve_list\":\"1_1_0,1_2_0\",\"g_valve_sq\":\"1,2\",\"g_valve_time\":\"1,1\",\"g_rlb_relay_list\":\"null\",\"g_relay_sq\":\"\",\"g_relay_time\":\"\",\"g_rlb_powercenter_list\":\"null\",\"g_powercenter_sq\":\"\",\"g_powercenter_time\":\"\"}','0','1','0','0','',NULL,NULL,'0','','0','','','0','0','');
INSERT INTO `rlb_custom_program` VALUES ('54','1','{\"g_id\":\"1\",\"g_custom_mode_name\":\"28_dec_2016_year\",\"g_custom_max_time\":\"10\",\"g_rlb_pump_list\":\"null\",\"g_pump_sq\":\"\",\"g_pump_time\":\"\",\"g_rlb_valve_list\":\"1_1_0\",\"g_valve_sq\":\"1,2\",\"g_valve_time\":\"1,1\",\"g_rlb_relay_list\":\"null\",\"g_relay_sq\":\"\",\"g_relay_time\":\"\",\"g_rlb_powercenter_list\":\"null\",\"g_powercenter_sq\":\"\",\"g_powercenter_time\":\"\"}','0','1','0','0','',NULL,NULL,'0','','0','','','0','0','');
INSERT INTO `rlb_custom_program` VALUES ('55','10','{\"g_id\":\"10\",\"g_custom_mode_name\":\"test\",\"g_custom_max_time\":\"10\",\"g_rlb_pump_list\":\"null\",\"g_pump_sq\":\"\",\"g_pump_time\":\"\",\"g_rlb_valve_list\":\"1_1_0\",\"g_valve_sq\":\"1,2\",\"g_valve_time\":\"1,1\",\"g_rlb_relay_list\":\"1_1_0,1_1_0\",\"g_relay_sq\":\"\",\"g_relay_time\":\"\",\"g_rlb_powercenter_list\":\"null\",\"g_powercenter_sq\":\"\",\"g_powercenter_time\":\"\"}','0','1','0','0','',NULL,NULL,'0','','0','','','0','0','');
INSERT INTO `rlb_custom_program` VALUES ('56','10','{\"g_id\":\"10\",\"g_custom_mode_name\":\"test\",\"g_rlb_pump_list\":\"null\",\"g_pump_sq\":\"\",\"g_pump_time\":\"\",\"g_rlb_valve_list\":\"1_1_0,1_1_0\",\"g_valve_sq\":\"1,2\",\"g_valve_time\":\"1,1\",\"g_custom_max_time\":\"10\",\"g_rlb_relay_list\":\"null\",\"g_relay_sq\":\"\",\"g_relay_time\":\"\",\"g_rlb_powercenter_list\":\"null\",\"g_powercenter_sq\":\"\",\"g_powercenter_time\":\"\"}','0','0','0','0','',NULL,NULL,'0','','0','','','0','0','');
INSERT INTO `rlb_custom_program` VALUES ('57','10','{\"g_id\":\"10\",\"g_custom_mode_name\":\"test_2\",\"g_custom_max_time\":\"10\",\"g_rlb_pump_list\":\"null\",\"g_pump_sq\":\"\",\"g_pump_time\":\"\",\"g_rlb_valve_list\":\"1_1_0,1_1_0\",\"g_valve_sq\":\"1,2\",\"g_valve_time\":\"1,1\",\"g_rlb_relay_list\":\"null\",\"g_relay_sq\":\"\",\"g_relay_time\":\"\",\"g_rlb_powercenter_list\":\"null\",\"g_powercenter_sq\":\"\",\"g_powercenter_time\":\"\"}','0','0','0','0','',NULL,NULL,'0','','0','','','0','0','');

/*---------------------------------------------------------------
  TABLE: `rlb_custom_program_after`
  ---------------------------------------------------------------*/
DROP TABLE IF EXISTS `rlb_custom_program_after`;
CREATE TABLE `rlb_custom_program_after` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `program_id` int(10) NOT NULL,
  `current_on_device` varchar(150) NOT NULL,
  `device_type` varchar(10) NOT NULL,
  `device_number` int(5) NOT NULL,
  `current_on_time` datetime NOT NULL,
  `current_off_time` datetime NOT NULL,
  `current_device_complete` enum('0','1') NOT NULL DEFAULT '0',
  `current_sequence` varchar(10) NOT NULL,
  `ip_id` int(5) NOT NULL,
  `unique_id` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*---------------------------------------------------------------
  TABLE: `rlb_custom_program_current`
  ---------------------------------------------------------------*/
DROP TABLE IF EXISTS `rlb_custom_program_current`;
CREATE TABLE `rlb_custom_program_current` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `program_id` int(10) NOT NULL,
  `current_on_device` varchar(150) NOT NULL,
  `device_type` varchar(10) NOT NULL,
  `device_number` int(5) NOT NULL,
  `current_on_time` datetime NOT NULL,
  `current_off_time` datetime NOT NULL,
  `current_device_complete` enum('0','1') NOT NULL DEFAULT '0',
  `current_sequence` varchar(10) NOT NULL,
  `ip_id` int(5) NOT NULL,
  `unique_id` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=170 DEFAULT CHARSET=latin1;
INSERT INTO `rlb_custom_program_current` VALUES   ('167','1','Pump 2','PS','2','2017-01-01 01:12:02','2017-01-01 04:32:02','0','7','1','55252841483261389');
INSERT INTO `rlb_custom_program_current` VALUES ('168','1','Relay 15','R','15','2017-01-01 01:12:02','2017-01-01 04:32:02','0','7','1','55252841483261389');
INSERT INTO `rlb_custom_program_current` VALUES ('169','1','Power Center 0','P','0','2017-01-01 01:12:02','2017-01-01 04:32:02','0','7','1','55252841483261389');

/*---------------------------------------------------------------
  TABLE: `rlb_custom_program_log`
  ---------------------------------------------------------------*/
DROP TABLE IF EXISTS `rlb_custom_program_log`;
CREATE TABLE `rlb_custom_program_log` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `program_id` int(10) NOT NULL,
  `device` varchar(150) NOT NULL,
  `device_type` varchar(10) NOT NULL,
  `device_number` int(5) NOT NULL,
  `device_start` datetime NOT NULL,
  `device_stop` datetime NOT NULL,
  `device_complete_run` enum('0','1') NOT NULL DEFAULT '0',
  `current_sequence` varchar(5) NOT NULL,
  `ip_id` int(5) NOT NULL,
  `unique_id` varchar(255) NOT NULL,
  `afterDevice` enum('0','1') NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=latin1;
/*---------------------------------------------------------------
  TABLE: `rlb_device`
  ---------------------------------------------------------------*/
DROP TABLE IF EXISTS `rlb_device`;
CREATE TABLE `rlb_device` (
  `device_id` int(10) NOT NULL AUTO_INCREMENT,
  `device_number` int(10) NOT NULL,
  `device_name` varchar(150) NOT NULL,
  `device_type` varchar(100) NOT NULL,
  `device_power_type` varchar(10) DEFAULT NULL COMMENT '0=24VAC,1=12VDC',
  `device_position` text,
  `device_total_time` varchar(100) NOT NULL,
  `device_start_time` varchar(100) NOT NULL,
  `device_end_time` varchar(100) NOT NULL,
  `last_updated_date` datetime NOT NULL,
  `is_pool_or_spa` enum('0','1','2') NOT NULL DEFAULT '0' COMMENT '0=Other,1=Spa,2=Pool',
  `valve_relay_number` varchar(150) NOT NULL,
  `light_relay_number` text NOT NULL,
  `ip_id` int(5) NOT NULL,
  `show_dashboard` enum('0','1') NOT NULL DEFAULT '0',
  `valvePump` text NOT NULL,
  `temperature_offset` float(10,2) NOT NULL,
  `DeviceType` varchar(100) NOT NULL,
  PRIMARY KEY (`device_id`)
) ENGINE=InnoDB AUTO_INCREMENT=165 DEFAULT CHARSET=latin1;
INSERT INTO `rlb_device` VALUES   ('1','0','Spa Heater','P',NULL,NULL,'','','','2016-06-22 15:33:30','2','','','1','0','','0.00','');
INSERT INTO `rlb_device` VALUES ('2','0','RelayName0','R',NULL,NULL,'20','','','2015-10-05 11:20:33','0','','','1','0','','0.00','');
INSERT INTO `rlb_device` VALUES ('3','1','Pool Heater','P',NULL,NULL,'','','','2016-06-22 15:33:55','2','','','1','0','','0.00','');
INSERT INTO `rlb_device` VALUES ('4','1','Test Relay 2','R',NULL,NULL,'','','','2015-09-19 13:25:31','1','','','1','0','','0.00','');
INSERT INTO `rlb_device` VALUES ('8','2','','R',NULL,NULL,'30','','','2015-10-07 13:30:36','1','','','1','0','','0.00','');
INSERT INTO `rlb_device` VALUES ('9','10','','R',NULL,NULL,'','08:13:57','08:23:57','2015-08-21 14:20:01','0','','','1','0','','0.00','');
INSERT INTO `rlb_device` VALUES ('10','0','Board Temperature','T',NULL,NULL,'','','','2015-11-06 11:10:14','0','','0000000000000000','1','0','','0.00','');
INSERT INTO `rlb_device` VALUES ('11','12','','R','0',NULL,'','','','2015-08-12 10:22:14','0','','','1','0','','0.00','');
INSERT INTO `rlb_device` VALUES ('12','2','','P','1',NULL,'','','','2015-09-23 10:30:03','0','','','1','0','','0.00','');
INSERT INTO `rlb_device` VALUES ('15','6','Spa 2 Blower','R',NULL,NULL,'20','','','2016-06-22 10:17:01','1','','','1','0','','0.00','');
INSERT INTO `rlb_device` VALUES ('31','3','','P',NULL,NULL,'','','','2015-09-21 08:41:48','2','','','1','0','','0.00','');
INSERT INTO `rlb_device` VALUES ('34','1','Spa 2','T',NULL,NULL,'','','','2016-11-16 17:31:49','0','','28FFF08F50140001','1','1','','-6.00','');
INSERT INTO `rlb_device` VALUES ('35','3','','R',NULL,NULL,'','','','2015-09-23 07:12:35','1','','','1','0','','0.00','');
INSERT INTO `rlb_device` VALUES ('36','2','Indoor Pool ?','T',NULL,NULL,'','','','2016-11-16 17:55:16','0','','28FF2070501400B4','1','1','','-10.00','');
INSERT INTO `rlb_device` VALUES ('40','0','Misc Light','L',NULL,NULL,'','','','2016-09-13 03:47:10','1','','a:7:{s:10:\"sRelayType\";s:2:\"12\";s:12:\"sRelayNumber\";s:1:\"7\";s:11:\"Temeprature\";s:0:\"\";s:4:\"Pump\";s:0:\"\";s:7:\"maxTemp\";s:0:\"\";s:10:\"desireTemp\";s:0:\"\";s:6:\"maxRun\";s:0:\"\";}','1','0','','0.00','Relayboard');
INSERT INTO `rlb_device` VALUES ('44','0','Pool Heater','H',NULL,NULL,'','','','2016-07-14 03:20:06','1','','a:7:{s:10:\"sRelayType\";s:2:\"12\";s:12:\"sRelayNumber\";s:1:\"1\";s:11:\"Temeprature\";s:1:\"2\";s:4:\"Pump\";s:1:\"1\";s:7:\"maxTemp\";s:3:\"100\";s:10:\"desireTemp\";s:2:\"90\";s:6:\"maxRun\";s:2:\"50\";}','1','0','','0.00','');
INSERT INTO `rlb_device` VALUES ('93','1','Spa Heater','H',NULL,NULL,'','','','2016-10-13 17:57:10','0','','a:7:{s:10:\"sRelayType\";s:2:\"12\";s:12:\"sRelayNumber\";s:1:\"0\";s:11:\"Temeprature\";s:1:\"1\";s:4:\"Pump\";s:1:\"1\";s:7:\"maxTemp\";s:3:\"100\";s:10:\"desireTemp\";s:2:\"83\";s:6:\"maxRun\";s:3:\"600\";}','1','0','','0.00','');
INSERT INTO `rlb_device` VALUES ('98','0','','B',NULL,NULL,'','','','2016-01-21 14:07:25','1','','a:2:{s:10:\"sRelayType\";s:2:\"12\";s:12:\"sRelayNumber\";s:1:\"1\";}','1','0','','0.00','');
INSERT INTO `rlb_device` VALUES ('100','0','misc1','M',NULL,NULL,'','','','2016-06-24 00:21:35','1','','a:2:{s:10:\"sRelayType\";s:2:\"24\";s:12:\"sRelayNumber\";s:2:\"14\";}','1','0','','0.00','');
INSERT INTO `rlb_device` VALUES ('101','1','misc2','M',NULL,NULL,'','','','2016-06-24 00:21:14','2','','a:2:{s:10:\"sRelayType\";s:2:\"24\";s:12:\"sRelayNumber\";s:1:\"7\";}','1','0','','0.00','');
INSERT INTO `rlb_device` VALUES ('118','4','','R',NULL,NULL,'','','','0000-00-00 00:00:00','0','','','1','0','','0.00','');
INSERT INTO `rlb_device` VALUES ('119','7','Auto fill Indoor Pool','R',NULL,NULL,'','','','2016-06-22 10:15:05','1','','','1','0','','0.00','');
INSERT INTO `rlb_device` VALUES ('120','0','RelayName1Device2','R',NULL,NULL,'20','','','2016-01-25 11:39:39','2','','','2','0','','0.00','');
INSERT INTO `rlb_device` VALUES ('122','0','Testing','P',NULL,NULL,'','','','2016-01-14 11:20:41','1','','','2','0','','0.00','');
INSERT INTO `rlb_device` VALUES ('123','1','','P',NULL,NULL,'','','','2016-01-14 11:08:56','2','','','2','0','','0.00','');
INSERT INTO `rlb_device` VALUES ('124','0','Board Temperature','T',NULL,NULL,'','','','2016-01-14 12:46:39','0','','','2','0','','0.00','');
INSERT INTO `rlb_device` VALUES ('129','0','#13 Solar On Off','V',NULL,'a:2:{s:9:\"position1\";s:2:\"20\";s:9:\"position2\";s:2:\"19\";}','','','','2016-11-16 16:53:03','2','a:2:{s:6:\"Relay1\";s:1:\"0\";s:6:\"Relay2\";s:1:\"1\";}','','1','0','{\"pump\":\"3\",\"valve_type\":\"1\"}','0.00','');
INSERT INTO `rlb_device` VALUES ('131','0','','B',NULL,NULL,'','','','2016-06-24 00:19:52','2','','a:2:{s:10:\"sRelayType\";s:2:\"24\";s:12:\"sRelayNumber\";s:2:\"13\";}','2','0','','0.00','');
INSERT INTO `rlb_device` VALUES ('134','1','','L',NULL,NULL,'','','','2016-06-24 00:20:44','2','','a:2:{s:10:\"sRelayType\";s:2:\"24\";s:12:\"sRelayNumber\";s:2:\"15\";}','2','0','','0.00','');
INSERT INTO `rlb_device` VALUES ('135','0','','L',NULL,NULL,'','','','2016-02-02 12:35:50','1','','a:2:{s:10:\"sRelayType\";s:2:\"12\";s:12:\"sRelayNumber\";s:1:\"0\";}','2','0','','0.00','');
INSERT INTO `rlb_device` VALUES ('142','14','F Pool Pump','R',NULL,NULL,'35','','','2016-06-22 10:14:10','0','','','1','0','','0.00','');
INSERT INTO `rlb_device` VALUES ('143','0','#9 Pump 1 Return Spa or Pool','V',NULL,'a:2:{s:9:\"position1\";s:1:\"2\";s:9:\"position2\";s:1:\"3\";}','','','','2016-06-22 09:31:50','0','a:2:{s:6:\"Relay1\";s:1:\"0\";s:6:\"Relay2\";s:1:\"1\";}','','2','0','{\"pump\":\"1\",\"valve_type\":\"1\"}','0.00','');
INSERT INTO `rlb_device` VALUES ('144','1','','H',NULL,NULL,'','','','2016-02-02 11:37:40','0','','a:2:{s:10:\"sRelayType\";s:2:\"12\";s:12:\"sRelayNumber\";s:1:\"1\";}','2','0','','0.00','');
INSERT INTO `rlb_device` VALUES ('145','0','Testing','M',NULL,NULL,'','','','2016-06-24 00:21:36','0','','a:2:{s:10:\"sRelayType\";s:2:\"24\";s:12:\"sRelayNumber\";s:2:\"14\";}','2','0','','0.00','');
INSERT INTO `rlb_device` VALUES ('146','1','Pump 1','PS',NULL,NULL,'','','','2016-06-29 12:00:58','1','','','1','0','','0.00','');
INSERT INTO `rlb_device` VALUES ('147','2','Jet Pump','PS',NULL,NULL,'','','','2016-07-01 17:21:01','0','','','1','0','','0.00','');
INSERT INTO `rlb_device` VALUES ('148','1','#1 return f Pool waterfall or Jet stream','V',NULL,'a:2:{s:9:\"position1\";s:2:\"18\";s:9:\"position2\";s:2:\"16\";}','','','','2016-11-16 17:01:55','2','a:2:{s:6:\"Relay1\";s:1:\"2\";s:6:\"Relay2\";s:1:\"3\";}','','1','0','{\"pump\":\"3\",\"valve_type\":\"1\"}','0.00','');
INSERT INTO `rlb_device` VALUES ('149','2','#2 Return F Pool or F Waterfall','V',NULL,'a:2:{s:9:\"position1\";s:2:\"17\";s:9:\"position2\";s:2:\"16\";}','','','','2016-06-22 10:00:22','0','a:2:{s:6:\"Relay1\";s:1:\"4\";s:6:\"Relay2\";s:1:\"5\";}','','1','0','{\"pump\":\"3\",\"valve_type\":\"1\"}','0.00','');
INSERT INTO `rlb_device` VALUES ('150','4','#7 Pump 1 suction Spa or Pool','V',NULL,'a:2:{s:9:\"position1\";s:1:\"2\";s:9:\"position2\";s:1:\"3\";}','','','','2016-06-22 10:01:51','0','a:2:{s:6:\"Relay1\";s:1:\"8\";s:6:\"Relay2\";s:1:\"9\";}','','1','0','{\"pump\":\"1\",\"valve_type\":\"0\"}','0.00','');
INSERT INTO `rlb_device` VALUES ('151','5','#5 Jet Pump Return  Spa 1 or Spa 2','V',NULL,'a:2:{s:9:\"position1\";s:2:\"10\";s:9:\"position2\";s:2:\"11\";}','','','','2016-11-18 15:24:31','0','a:2:{s:6:\"Relay1\";s:2:\"10\";s:6:\"Relay2\";s:2:\"11\";}','','1','0','{\"pump\":\"2\",\"valve_type\":\"1\"}','0.00','');
INSERT INTO `rlb_device` VALUES ('152','6','#6 Jet Pump Suction Spa1 or Spa 2','V',NULL,'a:2:{s:9:\"position1\";s:2:\"11\";s:9:\"position2\";s:2:\"10\";}','','','','2016-06-22 10:05:20','0','a:2:{s:6:\"Relay1\";s:2:\"12\";s:6:\"Relay2\";s:2:\"13\";}','','1','0','{\"pump\":\"2\",\"valve_type\":\"0\"}','0.00','');
INSERT INTO `rlb_device` VALUES ('153','1','#3 Waterfall on or off','V',NULL,'a:2:{s:9:\"position1\";s:2:\"14\";s:9:\"position2\";s:2:\"15\";}','','','','2016-06-22 09:49:02','0','a:2:{s:6:\"Relay1\";s:1:\"2\";s:6:\"Relay2\";s:1:\"3\";}','','2','0','{\"pump\":\"1\",\"valve_type\":\"1\"}','0.00','');
INSERT INTO `rlb_device` VALUES ('154','2','#4 Spa 2 Jets on and off','V',NULL,'a:2:{s:9:\"position1\";s:2:\"12\";s:9:\"position2\";s:2:\"13\";}','','','','2016-06-22 09:46:27','0','a:2:{s:6:\"Relay1\";s:1:\"4\";s:6:\"Relay2\";s:1:\"5\";}','','2','0','','0.00','');
INSERT INTO `rlb_device` VALUES ('155','3','#8 Suction spa 1 or spa 2','V',NULL,'a:2:{s:9:\"position1\";s:2:\"11\";s:9:\"position2\";s:2:\"10\";}','','','','2016-06-22 09:42:54','0','a:2:{s:6:\"Relay1\";s:1:\"6\";s:6:\"Relay2\";s:1:\"7\";}','','2','0','{\"pump\":\"1\",\"valve_type\":\"0\"}','0.00','');
INSERT INTO `rlb_device` VALUES ('156','4','#10 Spa 1 Return On or Off','V',NULL,'a:2:{s:9:\"position1\";s:1:\"6\";s:9:\"position2\";s:1:\"7\";}','','','','2016-06-22 09:35:18','0','a:2:{s:6:\"Relay1\";s:1:\"8\";s:6:\"Relay2\";s:1:\"9\";}','','2','0','','0.00','');
INSERT INTO `rlb_device` VALUES ('157','5','#11 Spa 2 Return','V',NULL,'a:2:{s:9:\"position1\";s:1:\"8\";s:9:\"position2\";s:1:\"9\";}','','','','2016-06-22 09:37:26','0','a:2:{s:6:\"Relay1\";s:2:\"10\";s:6:\"Relay2\";s:2:\"11\";}','','2','0','','0.00','');
INSERT INTO `rlb_device` VALUES ('158','15','Spa 1 Blower','R',NULL,NULL,'','','','2016-06-22 10:16:14','0','','','1','0','','0.00','');
INSERT INTO `rlb_device` VALUES ('159','14','Auto fill f pool','R',NULL,NULL,'','','','2016-06-22 10:18:16','0','','','2','0','','0.00','');
INSERT INTO `rlb_device` VALUES ('160','15','Auto fill Spa 2','R',NULL,NULL,'','','','2016-06-22 10:18:46','0','','','2','0','','0.00','');
INSERT INTO `rlb_device` VALUES ('161','3','Fiberglass Pool Pump','PS',NULL,NULL,'','','','2016-06-27 11:06:00','0','','','1','0','','0.00','');
INSERT INTO `rlb_device` VALUES ('162','3','Spa 1','T',NULL,NULL,'','','','2016-11-16 17:33:21','0','','28FF2EE950150342','1','1','','0.00','');
INSERT INTO `rlb_device` VALUES ('163','4','','T',NULL,NULL,'','','','2016-11-16 17:34:00','0','','28FF5D7851140082','1','1','','0.00','');
INSERT INTO `rlb_device` VALUES ('164','5','','T',NULL,NULL,'','','','2016-11-16 17:36:30','0','','28FFD34A5014000F','1','1','','0.00','');

/*---------------------------------------------------------------
  TABLE: `rlb_device_last_run_details`
  ---------------------------------------------------------------*/
DROP TABLE IF EXISTS `rlb_device_last_run_details`;
CREATE TABLE `rlb_device_last_run_details` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `device_number` int(5) NOT NULL,
  `device_type` varchar(100) NOT NULL,
  `device_position` varchar(100) NOT NULL,
  `ip_id` int(5) NOT NULL,
  `added_date` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=latin1;
INSERT INTO `rlb_device_last_run_details` VALUES   ('1','2','V','2','1','2016-11-16 17:03:25');
INSERT INTO `rlb_device_last_run_details` VALUES ('2','0','V','1','2','2016-12-28 17:47:02');
INSERT INTO `rlb_device_last_run_details` VALUES ('3','5','V','1','2','2016-12-15 12:18:14');
INSERT INTO `rlb_device_last_run_details` VALUES ('4','1','V','2','1','2016-11-16 17:02:09');
INSERT INTO `rlb_device_last_run_details` VALUES ('5','6','V','1','1','2016-11-17 03:05:14');
INSERT INTO `rlb_device_last_run_details` VALUES ('6','0','V','1','1','2016-11-17 14:00:56');
INSERT INTO `rlb_device_last_run_details` VALUES ('8','4','V','1','1','2016-12-28 17:46:00');
INSERT INTO `rlb_device_last_run_details` VALUES ('9','5','V','2','1','2016-11-17 03:04:14');
INSERT INTO `rlb_device_last_run_details` VALUES ('10','4','V','2','2','2016-12-15 12:18:12');
INSERT INTO `rlb_device_last_run_details` VALUES ('11','3','V','1','2','2016-12-28 17:45:48');
INSERT INTO `rlb_device_last_run_details` VALUES ('12','2','V','2','2','2016-11-17 03:18:23');
INSERT INTO `rlb_device_last_run_details` VALUES ('13','1','V','2','2','2016-08-29 02:06:35');

/*---------------------------------------------------------------
  TABLE: `rlb_exclude_device`
  ---------------------------------------------------------------*/
DROP TABLE IF EXISTS `rlb_exclude_device`;
CREATE TABLE `rlb_exclude_device` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `exclude_devices` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
INSERT INTO `rlb_exclude_device` VALUES   ('1','a:8:{s:1:\"R\";a:3:{i:0;s:3:\"7_1\";i:1;s:4:\"14_2\";i:2;s:4:\"15_2\";}s:1:\"P\";b:0;s:1:\"V\";b:0;s:2:\"PS\";b:0;s:1:\"H\";b:0;s:1:\"B\";b:0;s:1:\"L\";b:0;s:1:\"M\";b:0;}');

/*---------------------------------------------------------------
  TABLE: `rlb_heater_run`
  ---------------------------------------------------------------*/
DROP TABLE IF EXISTS `rlb_heater_run`;
CREATE TABLE `rlb_heater_run` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `heaterNumber` int(5) NOT NULL,
  `ip_id` int(5) NOT NULL,
  `heaterRun` enum('0','1') NOT NULL DEFAULT '0',
  `heaterStart` datetime NOT NULL,
  `heaterEnd` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;
INSERT INTO `rlb_heater_run` VALUES   ('1','1','1','1','2017-01-01 01:12:02','2017-01-01 11:12:02');
INSERT INTO `rlb_heater_run` VALUES ('2','0','1','1','2016-12-31 22:36:02','2016-12-31 23:26:02');
INSERT INTO `rlb_heater_run` VALUES ('3','1','2','0','0000-00-00 00:00:00','0000-00-00 00:00:00');

/*---------------------------------------------------------------
  TABLE: `rlb_logs`
  ---------------------------------------------------------------*/
DROP TABLE IF EXISTS `rlb_logs`;
CREATE TABLE `rlb_logs` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `Service` text NOT NULL,
  `ServiceMessage` text NOT NULL,
  `ServiceDevice` text NOT NULL,
  `ServiceDeviceNumber` int(5) NOT NULL,
  `ServiceDeviceIP` int(5) NOT NULL,
  `ServiceCommand` text NOT NULL,
  `ServiceDateTime` datetime NOT NULL,
  `ServiceStatus` enum('0','1') NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*---------------------------------------------------------------
  TABLE: `rlb_mode_questions`
  ---------------------------------------------------------------*/
DROP TABLE IF EXISTS `rlb_mode_questions`;
CREATE TABLE `rlb_mode_questions` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `general` text NOT NULL,
  `device` text NOT NULL,
  `heater` text NOT NULL,
  `more` text NOT NULL,
  `added_date` datetime NOT NULL,
  `last_modified` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
INSERT INTO `rlb_mode_questions` VALUES   ('1','a:11:{s:4:\"type\";s:4:\"both\";s:13:\"pool_max_temp\";s:2:\"50\";s:9:\"pool_temp\";s:2:\"50\";s:11:\"pool_manual\";s:3:\"480\";s:12:\"spa_max_temp\";s:3:\"104\";s:15:\"spa_temperature\";s:3:\"102\";s:10:\"spa_manual\";s:3:\"480\";s:12:\"temperature1\";s:3:\"0_1\";s:12:\"temperature2\";s:3:\"0_1\";s:17:\"display_pool_temp\";s:3:\"Yes\";s:16:\"display_spa_temp\";s:3:\"Yes\";}','','','N;','2016-07-11 21:29:26','2016-09-14 23:04:49');

/*---------------------------------------------------------------
  TABLE: `rlb_modes`
  ---------------------------------------------------------------*/
DROP TABLE IF EXISTS `rlb_modes`;
CREATE TABLE `rlb_modes` (
  `mode_id` int(11) NOT NULL AUTO_INCREMENT,
  `mode_name` varchar(255) NOT NULL,
  `mode_status` int(1) NOT NULL DEFAULT '0',
  `start_time` datetime NOT NULL,
  `timer_total` varchar(150) NOT NULL,
  `timer_start` varchar(150) NOT NULL,
  `timer_end` varchar(150) NOT NULL,
  `unique_id` varchar(100) NOT NULL,
  PRIMARY KEY (`mode_id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;
INSERT INTO `rlb_modes` VALUES   ('1','Auto','1','2017-01-01 01:03:09','','','','');
INSERT INTO `rlb_modes` VALUES ('2','Manual','0','0000-00-00 00:00:00','480','2017-01-01 01:00:41','2017-01-01 09:00:41','');
INSERT INTO `rlb_modes` VALUES ('3','Time-Out','0','0000-00-00 00:00:00','','','','');

/*---------------------------------------------------------------
  TABLE: `rlb_pool_spa_current`
  ---------------------------------------------------------------*/
DROP TABLE IF EXISTS `rlb_pool_spa_current`;
CREATE TABLE `rlb_pool_spa_current` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `mode_id` int(5) NOT NULL,
  `current_on_device` varchar(255) NOT NULL,
  `device_type` varchar(10) NOT NULL,
  `device_number` varchar(10) NOT NULL,
  `current_on_time` datetime NOT NULL,
  `current_off_time` datetime NOT NULL,
  `current_device_complete` enum('0','1') NOT NULL,
  `current_unique_id` varchar(100) NOT NULL,
  `current_sequence` int(5) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*---------------------------------------------------------------
  TABLE: `rlb_pool_spa_log`
  ---------------------------------------------------------------*/
DROP TABLE IF EXISTS `rlb_pool_spa_log`;
CREATE TABLE `rlb_pool_spa_log` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `mode_id` int(5) NOT NULL,
  `unique_id` varchar(100) NOT NULL,
  `device` varchar(150) NOT NULL,
  `device_type` varchar(10) NOT NULL,
  `device_number` varchar(10) NOT NULL,
  `device_start` datetime NOT NULL,
  `device_stop` datetime NOT NULL,
  `device_complete_run` enum('0','1','2') NOT NULL DEFAULT '0',
  `current_sequence` int(5) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*---------------------------------------------------------------
  TABLE: `rlb_pool_spa_mode`
  ---------------------------------------------------------------*/
DROP TABLE IF EXISTS `rlb_pool_spa_mode`;
CREATE TABLE `rlb_pool_spa_mode` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `mode_name` varchar(150) NOT NULL,
  `mode_status` enum('0','1') NOT NULL DEFAULT '0',
  `total_run_time` varchar(100) NOT NULL,
  `last_start_date` datetime NOT NULL,
  `last_end_date` datetime NOT NULL,
  `unique_id` varchar(100) NOT NULL,
  `all_device_on` enum('0','1') NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
INSERT INTO `rlb_pool_spa_mode` VALUES   ('1','Pool','1','','0000-00-00 00:00:00','0000-00-00 00:00:00','','0');
INSERT INTO `rlb_pool_spa_mode` VALUES ('2','Spa','0','','0000-00-00 00:00:00','0000-00-00 00:00:00','','0');
INSERT INTO `rlb_pool_spa_mode` VALUES ('3','Both','0','','0000-00-00 00:00:00','0000-00-00 00:00:00','','0');
INSERT INTO `rlb_pool_spa_mode` VALUES ('4','Pool Auto','0','','0000-00-00 00:00:00','0000-00-00 00:00:00','','0');

/*---------------------------------------------------------------
  TABLE: `rlb_position`
  ---------------------------------------------------------------*/
DROP TABLE IF EXISTS `rlb_position`;
CREATE TABLE `rlb_position` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `position_name` varchar(250) NOT NULL,
  `position_device` varchar(100) NOT NULL,
  `position_active` enum('0','1') NOT NULL DEFAULT '0',
  `position_added_date` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=latin1;
INSERT INTO `rlb_position` VALUES   ('2','Pool','','1','2015-12-04 07:51:03');
INSERT INTO `rlb_position` VALUES ('3','Spa','','1','2015-12-04 07:51:08');
INSERT INTO `rlb_position` VALUES ('4','Other','','1','2015-12-04 07:51:16');
INSERT INTO `rlb_position` VALUES ('5','Waterfall','','1','2015-12-04 07:55:54');
INSERT INTO `rlb_position` VALUES ('6','Spa 1 Open','','1','2016-06-22 09:34:15');
INSERT INTO `rlb_position` VALUES ('7','Spa 1 Closed','','1','2016-06-22 09:34:33');
INSERT INTO `rlb_position` VALUES ('8','Spa 2 open','','1','2016-06-22 09:36:23');
INSERT INTO `rlb_position` VALUES ('9','Spa 2 closed','','1','2016-06-22 09:36:36');
INSERT INTO `rlb_position` VALUES ('10','Spa 1 ','','1','2016-06-22 09:39:24');
INSERT INTO `rlb_position` VALUES ('11','Spa 2','','1','2016-06-22 09:39:34');
INSERT INTO `rlb_position` VALUES ('12','Spa 2 Jets On','','1','2016-06-22 09:45:28');
INSERT INTO `rlb_position` VALUES ('13','Spa 2 Jets Off','','1','2016-06-22 09:45:39');
INSERT INTO `rlb_position` VALUES ('14','Waterfall on','','1','2016-06-22 09:48:39');
INSERT INTO `rlb_position` VALUES ('15','Waterfall off','','1','2016-06-22 09:48:48');
INSERT INTO `rlb_position` VALUES ('16','F Pool Return','','1','2016-06-22 09:53:41');
INSERT INTO `rlb_position` VALUES ('17','F Pool Waterfall','','1','2016-06-22 09:59:16');
INSERT INTO `rlb_position` VALUES ('18','Jet Stream','','1','2016-06-22 10:08:53');
INSERT INTO `rlb_position` VALUES ('19','Solar On','','1','2016-06-22 10:11:09');
INSERT INTO `rlb_position` VALUES ('20','Solar Off','','1','2016-06-22 10:11:22');

/*---------------------------------------------------------------
  TABLE: `rlb_powercenters`
  ---------------------------------------------------------------*/
DROP TABLE IF EXISTS `rlb_powercenters`;
CREATE TABLE `rlb_powercenters` (
  `powercenter_id` int(11) NOT NULL AUTO_INCREMENT,
  `powercenter_number` int(11) NOT NULL,
  `powercenter_name` varchar(100) NOT NULL,
  PRIMARY KEY (`powercenter_id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
INSERT INTO `rlb_powercenters` VALUES   ('1','0','Test powercenter0');
INSERT INTO `rlb_powercenters` VALUES ('2','4','pc4 edit');
INSERT INTO `rlb_powercenters` VALUES ('3','2','Testing');
INSERT INTO `rlb_powercenters` VALUES ('4','1','PowerCenter1');

/*---------------------------------------------------------------
  TABLE: `rlb_program`
  ---------------------------------------------------------------*/
DROP TABLE IF EXISTS `rlb_program`;
CREATE TABLE `rlb_program` (
  `program_id` int(11) NOT NULL AUTO_INCREMENT,
  `program_name` varchar(255) NOT NULL,
  `device_number` varchar(8) NOT NULL,
  `device_type` varchar(8) NOT NULL,
  `program_type` int(2) NOT NULL COMMENT '1-Daily, 2-Weekly',
  `program_days` varchar(255) NOT NULL COMMENT '0-All, 1-Mon, 2-Tue...7-Sun',
  `start_time` varchar(255) NOT NULL,
  `end_time` varchar(255) NOT NULL,
  `program_created_date` datetime NOT NULL,
  `program_modified_date` datetime NOT NULL,
  `program_delete` int(1) NOT NULL DEFAULT '0',
  `program_active` int(1) NOT NULL DEFAULT '0',
  `program_absolute` enum('0','1') NOT NULL DEFAULT '0',
  `program_absolute_start_time` varchar(100) DEFAULT NULL,
  `program_absolute_end_time` varchar(100) DEFAULT NULL,
  `program_absolute_total_time` varchar(100) DEFAULT NULL,
  `program_absolute_run_time` varchar(100) DEFAULT NULL,
  `program_absolute_start_date` date DEFAULT NULL,
  `program_absolute_run` enum('0','1') NOT NULL DEFAULT '0',
  `is_on_after_reboot` enum('0','1') NOT NULL DEFAULT '0',
  `program_work_in_mode` enum('0','1') NOT NULL DEFAULT '0',
  `ip_id` int(5) NOT NULL,
  `valvePosition` int(5) NOT NULL DEFAULT '0',
  PRIMARY KEY (`program_id`)
) ENGINE=MyISAM AUTO_INCREMENT=32 DEFAULT CHARSET=latin1;
INSERT INTO `rlb_program` VALUES   ('1','Daily Filtering','1','PS','1','0','06:00:00','12:00:00','2016-06-22 16:17:41','2016-06-23 09:01:42','1','0','0',NULL,NULL,'06:00:00',NULL,NULL,'0','0','0','1','0');
INSERT INTO `rlb_program` VALUES ('2','Daily Filtering F Pool','3','PS','1','0','11:05:00','20:05:00','2016-06-22 16:21:13','0000-00-00 00:00:00','0','0','0',NULL,NULL,'09:00:00',NULL,NULL,'0','0','1','1','0');
INSERT INTO `rlb_program` VALUES ('3','Spa 2 Filtering','4','V','1','0','11:00:00','12:00:00','2016-06-23 09:03:07','0000-00-00 00:00:00','1','0','',NULL,NULL,'01:00:00',NULL,NULL,'0','0','0','1','2');
INSERT INTO `rlb_program` VALUES ('4','Daily Filtering','3','V','1','0','11:00:00','12:05:00','2016-06-23 09:04:28','0000-00-00 00:00:00','1','0','',NULL,NULL,'01:05:00',NULL,NULL,'0','0','0','2','1');
INSERT INTO `rlb_program` VALUES ('5','Daily 11:00 Filtering Start','0','V','1','0','11:01:00','12:00:00','2016-06-23 09:06:33','0000-00-00 00:00:00','1','0','',NULL,NULL,'00:59:00',NULL,NULL,'0','0','0','2','1');
INSERT INTO `rlb_program` VALUES ('6','Daily 11:00 Filtering Start','5','V','1','0','11:01:00','12:00:00','2016-06-23 09:08:26','0000-00-00 00:00:00','1','0','',NULL,NULL,'00:59:00',NULL,NULL,'0','0','0','2','1');
INSERT INTO `rlb_program` VALUES ('7','Daily 11:00 Filtering Start','4','V','1','0','11:01:00','12:00:00','2016-06-23 09:09:37','0000-00-00 00:00:00','1','0','',NULL,NULL,'00:59:00',NULL,NULL,'0','0','0','2','2');
INSERT INTO `rlb_program` VALUES ('8','Daily 11:00 Filtering End','4','V','1','0','12:05:00','12:10:00','2016-06-23 09:11:26','0000-00-00 00:00:00','1','0','',NULL,NULL,'00:05:00',NULL,NULL,'0','0','0','2','1');
INSERT INTO `rlb_program` VALUES ('9','Daily 11:00 Filtering End','5','V','1','0','12:05:00','12:10:00','2016-06-23 09:12:56','0000-00-00 00:00:00','1','0','',NULL,NULL,'00:05:00',NULL,NULL,'0','0','0','2','2');
INSERT INTO `rlb_program` VALUES ('10','Daily 11:00 Filtering End','4','V','1','0','12:05:00','12:10:00','2016-06-23 09:14:09','0000-00-00 00:00:00','1','0','',NULL,NULL,'00:05:00',NULL,NULL,'0','0','0','1','1');
INSERT INTO `rlb_program` VALUES ('11','Daily 11:00 Filtering End','0','V','1','0','12:04:00','12:10:00','2016-06-23 09:16:27','0000-00-00 00:00:00','1','0','',NULL,NULL,'00:06:00',NULL,NULL,'0','0','0','2','1');
INSERT INTO `rlb_program` VALUES ('12','Daily 11:00 Filtering End','3','V','1','0','12:05:00','12:10:00','2016-06-23 09:17:49','0000-00-00 00:00:00','1','0','',NULL,NULL,'00:05:00',NULL,NULL,'0','0','0','2','2');
INSERT INTO `rlb_program` VALUES ('13','Test Program','0','V','1','0','01:00:00','01:10:00','2016-06-24 01:17:39','0000-00-00 00:00:00','1','0','',NULL,NULL,'00:10:00',NULL,NULL,'0','0','0','1','1');
INSERT INTO `rlb_program` VALUES ('14','Test Program','1','PS','1','0','01:05:00','01:10:00','2016-06-24 01:18:08','0000-00-00 00:00:00','1','0','',NULL,NULL,'00:05:00',NULL,NULL,'0','0','0','1','0');
INSERT INTO `rlb_program` VALUES ('15','Test Program','6','R','1','0','01:05:00','01:10:00','2016-06-24 01:18:59','0000-00-00 00:00:00','1','0','',NULL,NULL,'00:05:00',NULL,NULL,'0','0','0','1','0');
INSERT INTO `rlb_program` VALUES ('16','Test Program','1','PS','1','0','04:35:00','05:55:00','2016-06-24 02:01:29','2016-06-24 04:35:26','1','0','1','','','01:20:00','','2016-06-24','1','0','1','1','0');
INSERT INTO `rlb_program` VALUES ('17','Test Program','0','V','1','0','03:15:00','03:50:00','2016-06-24 02:02:12','2016-06-24 03:15:42','1','0','0','','','00:35:00','00:00:00','2016-06-24','0','0','0','1','1');
INSERT INTO `rlb_program` VALUES ('18','Test Program','6','R','1','0','01:00:00','01:10:00','2016-06-24 02:02:55','0000-00-00 00:00:00','1','0','',NULL,NULL,'00:10:00',NULL,NULL,'0','0','0','1','0');
INSERT INTO `rlb_program` VALUES ('19','Test Program 2','2','PS','1','0','04:30:00','05:55:00','2016-06-24 03:26:07','2016-06-24 04:35:53','0','0','0',NULL,NULL,'01:25:00',NULL,NULL,'0','0','0','1','0');
INSERT INTO `rlb_program` VALUES ('31','test 1','4','V','1','0','22:20:00','22:35:00','2016-06-27 22:14:56','0000-00-00 00:00:00','1','0','',NULL,NULL,'00:15:00',NULL,NULL,'0','0','1','1','1');
INSERT INTO `rlb_program` VALUES ('20','Daily Filtering','1','PS','1','0','11:40:00','16:40:00','2016-06-27 11:36:36','2016-06-27 22:18:52','0','0','1','','','05:00:00','','2016-06-27','1','0','1','1','0');
INSERT INTO `rlb_program` VALUES ('21','Spa 2 Filtering On','4','V','1','0','12:00:00','12:01:00','2016-06-27 11:40:24','2016-06-27 11:42:08','1','0','',NULL,NULL,'00:01:00',NULL,NULL,'0','0','1','1','2');
INSERT INTO `rlb_program` VALUES ('22','Spa 2 Daily Filtering','4','V','1','0','13:01:00','13:02:00','2016-06-27 11:43:19','0000-00-00 00:00:00','1','0','',NULL,NULL,'00:01:00',NULL,NULL,'0','0','1','1','1');
INSERT INTO `rlb_program` VALUES ('23','Spa 2 Daily Filtering','3','V','1','0','12:01:00','12:02:00','2016-06-27 11:44:46','0000-00-00 00:00:00','1','0','',NULL,NULL,'00:01:00',NULL,NULL,'0','0','1','2','1');
INSERT INTO `rlb_program` VALUES ('24','Spa 2 Daily Filtering Off','3','V','1','0','13:01:00','13:02:00','2016-06-27 11:45:31','0000-00-00 00:00:00','1','0','',NULL,NULL,'00:01:00',NULL,NULL,'0','0','1','2','2');
INSERT INTO `rlb_program` VALUES ('25','Spa 2 Daily Filtering','0','V','1','0','12:03:00','12:04:00','2016-06-27 11:46:28','0000-00-00 00:00:00','1','0','',NULL,NULL,'00:01:00',NULL,NULL,'0','0','1','2','2');
INSERT INTO `rlb_program` VALUES ('26','Spa 2 Daily Filtering Off','0','V','1','0','13:03:00','13:04:00','2016-06-27 11:47:33','0000-00-00 00:00:00','1','0','',NULL,NULL,'00:01:00',NULL,NULL,'0','0','1','2','1');
INSERT INTO `rlb_program` VALUES ('27','Spa 2 Daily Filtering','5','V','1','0','12:04:00','12:05:00','2016-06-27 11:48:58','0000-00-00 00:00:00','1','0','',NULL,NULL,'00:01:00',NULL,NULL,'0','0','1','2','1');
INSERT INTO `rlb_program` VALUES ('28','Spa 2 Daily Filtering Off','5','V','1','0','13:04:00','13:05:00','2016-06-27 11:49:44','0000-00-00 00:00:00','1','0','',NULL,NULL,'00:01:00',NULL,NULL,'0','0','1','2','1');
INSERT INTO `rlb_program` VALUES ('29','Spa 2 Daily Filtering','4','V','1','0','12:04:00','12:05:00','2016-06-27 11:50:40','0000-00-00 00:00:00','1','0','',NULL,NULL,'00:01:00',NULL,NULL,'0','0','1','2','2');
INSERT INTO `rlb_program` VALUES ('30','Spa 2 Daily Filtering Off','4','V','1','0','13:04:00','13:05:00','2016-06-27 11:51:07','0000-00-00 00:00:00','1','0','',NULL,NULL,'00:01:00',NULL,NULL,'0','0','1','2','1');

/*---------------------------------------------------------------
  TABLE: `rlb_pump_device`
  ---------------------------------------------------------------*/
DROP TABLE IF EXISTS `rlb_pump_device`;
CREATE TABLE `rlb_pump_device` (
  `pump_id` int(10) NOT NULL AUTO_INCREMENT,
  `pump_number` int(5) NOT NULL,
  `pump_type` enum('12','24','Intellicom','Emulator','Intellicom12','Intellicom24','Emulator12','Emulator24','2Speed') NOT NULL,
  `pump_sub_type` enum('VS','VF','12','24') NOT NULL,
  `pump_speed` varchar(150) NOT NULL,
  `pump_flow` varchar(250) NOT NULL,
  `pump_closure` varchar(150) NOT NULL,
  `relay_number` varchar(10) NOT NULL,
  `pump_address` varchar(50) NOT NULL,
  `pump_modified_date` datetime NOT NULL,
  `relay_number_1` varchar(10) NOT NULL,
  `status` enum('0','1','2') NOT NULL DEFAULT '0',
  `ip_id` int(5) NOT NULL,
  `pump_on` enum('0','1') NOT NULL DEFAULT '0',
  PRIMARY KEY (`pump_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;
INSERT INTO `rlb_pump_device` VALUES   ('1','1','Emulator','VS','3110','','1','','60','2016-06-21 23:29:32','','1','1','0');
INSERT INTO `rlb_pump_device` VALUES ('2','2','Emulator','VS','3100','','0','','61','2016-06-22 10:33:30','','1','1','0');
INSERT INTO `rlb_pump_device` VALUES ('3','3','24','','','','1','14','','2016-11-16 16:59:12','','0','1','0');

/*---------------------------------------------------------------
  TABLE: `rlb_pump_heater`
  ---------------------------------------------------------------*/
DROP TABLE IF EXISTS `rlb_pump_heater`;
CREATE TABLE `rlb_pump_heater` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `pump` varchar(10) NOT NULL,
  `end_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*---------------------------------------------------------------
  TABLE: `rlb_pump_response`
  ---------------------------------------------------------------*/
DROP TABLE IF EXISTS `rlb_pump_response`;
CREATE TABLE `rlb_pump_response` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `pump_number` int(5) NOT NULL,
  `pump_response_time` datetime NOT NULL,
  `pump_response` varchar(255) DEFAULT NULL,
  `ip_id` int(5) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*---------------------------------------------------------------
  TABLE: `rlb_reboot_history`
  ---------------------------------------------------------------*/
DROP TABLE IF EXISTS `rlb_reboot_history`;
CREATE TABLE `rlb_reboot_history` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `details` text NOT NULL,
  `ip_id` int(5) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=365 DEFAULT CHARSET=latin1;
INSERT INTO `rlb_reboot_history` VALUES   ('1','a:5:{s:9:\"sResponse\";s:120:\"S,145,0,1,12:22:00,3,06,000.000.,......00......00,00000000,0,0,0,0,12515,98.9F,89.0F,,87.6F,88.7F,85.3F,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"000.000.\";s:7:\"sRelays\";s:16:\"......00......00\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','1');
INSERT INTO `rlb_reboot_history` VALUES ('2','a:5:{s:9:\"sResponse\";s:101:\"S,181,0,1,12:21:54,3,06,000000..,............0000,00000000,0,0,0,0,12515,100.0F,,,,,,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"000000..\";s:7:\"sRelays\";s:16:\"............0000\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','2');
INSERT INTO `rlb_reboot_history` VALUES ('3','a:5:{s:9:\"sResponse\";s:126:\"S,003,0,0,11:39:13,3,06,000.000.,......00......10,00000000,0,0,0,0,12531,101.5F,86.9F,86.8F,85.7F,81.5F,84.7F,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"000.000.\";s:7:\"sRelays\";s:16:\"......00......10\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:3:{i:0;s:1:\"1\";i:1;s:1:\"2\";i:2;s:1:\"3\";}}','1');
INSERT INTO `rlb_reboot_history` VALUES ('4','a:5:{s:9:\"sResponse\";s:100:\"S,192,0,0,11:39:14,3,06,000000..,............0000,00000000,0,0,0,0,12531,98.8F,,,,,,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"000000..\";s:7:\"sRelays\";s:16:\"............0000\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','2');
INSERT INTO `rlb_reboot_history` VALUES ('5','a:5:{s:9:\"sResponse\";s:126:\"S,006,0,0,23:54:36,3,06,000.000.,......00......00,00000000,0,0,0,0,12515,101.4F,86.5F,86.6F,84.9F,86.0F,84.0F,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"000.000.\";s:7:\"sRelays\";s:16:\"......00......00\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','1');
INSERT INTO `rlb_reboot_history` VALUES ('6','a:5:{s:9:\"sResponse\";s:100:\"S,146,0,1,11:38:52,3,06,000000..,............0000,00000000,0,0,0,0,12515,97.8F,,,,,,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"000000..\";s:7:\"sRelays\";s:16:\"............0000\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','2');
INSERT INTO `rlb_reboot_history` VALUES ('7','a:5:{s:9:\"sResponse\";s:126:\"S,065,0,0,23:59:17,3,06,000.000.,......00......00,00000000,0,0,0,0,12500,100.0F,83.9F,84.0F,83.2F,84.2F,83.0F,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"000.000.\";s:7:\"sRelays\";s:16:\"......00......00\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','1');
INSERT INTO `rlb_reboot_history` VALUES ('8','a:5:{s:9:\"sResponse\";s:100:\"S,111,0,2,11:38:31,3,06,000000..,............0000,00000000,0,0,0,0,12515,97.8F,,,,,,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"000000..\";s:7:\"sRelays\";s:16:\"............0000\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','2');
INSERT INTO `rlb_reboot_history` VALUES ('9','a:5:{s:9:\"sResponse\";s:126:\"S,023,0,0,23:59:19,3,06,000.000.,......00......00,00000000,0,0,0,0,12515,102.5F,86.8F,87.2F,85.7F,86.9F,85.2F,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"000.000.\";s:7:\"sRelays\";s:16:\"......00......00\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','1');
INSERT INTO `rlb_reboot_history` VALUES ('10','a:5:{s:9:\"sResponse\";s:100:\"S,175,0,3,11:38:10,3,06,000000..,............0000,00000000,0,0,0,0,12531,98.8F,,,,,,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"000000..\";s:7:\"sRelays\";s:16:\"............0000\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','2');
INSERT INTO `rlb_reboot_history` VALUES ('11','a:5:{s:9:\"sResponse\";s:126:\"S,244,0,0,23:59:16,3,06,000.000.,......00......00,00000000,0,0,0,0,12500,103.6F,86.0F,86.1F,85.8F,86.0F,86.2F,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"000.000.\";s:7:\"sRelays\";s:16:\"......00......00\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','1');
INSERT INTO `rlb_reboot_history` VALUES ('12','a:5:{s:9:\"sResponse\";s:101:\"S,006,0,4,11:37:48,3,06,000000..,............0000,00000000,0,0,0,0,12531,103.3F,,,,,,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"000000..\";s:7:\"sRelays\";s:16:\"............0000\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','2');
INSERT INTO `rlb_reboot_history` VALUES ('13','a:5:{s:9:\"sResponse\";s:125:\"S,143,0,0,23:59:19,3,06,000.000.,......00......00,00000000,0,0,0,0,12500,99.2F,92.1F,92.6F,90.3F,92.3F,93.0F,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"000.000.\";s:7:\"sRelays\";s:16:\"......00......00\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','1');
INSERT INTO `rlb_reboot_history` VALUES ('14','a:5:{s:9:\"sResponse\";s:101:\"S,078,0,5,11:37:27,3,06,000000..,............0000,00000000,0,0,0,0,12515,103.4F,,,,,,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"000000..\";s:7:\"sRelays\";s:16:\"............0000\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','2');
INSERT INTO `rlb_reboot_history` VALUES ('15','a:5:{s:9:\"sResponse\";s:125:\"S,026,0,0,23:59:24,3,06,000.000.,......00......00,00000000,0,0,0,0,12500,93.4F,85.8F,86.3F,86.0F,86.0F,86.6F,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"000.000.\";s:7:\"sRelays\";s:16:\"......00......00\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','1');
INSERT INTO `rlb_reboot_history` VALUES ('16','a:5:{s:9:\"sResponse\";s:100:\"S,213,0,6,11:37:06,3,06,000000..,............0000,00000000,0,0,0,0,12515,97.5F,,,,,,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"000000..\";s:7:\"sRelays\";s:16:\"............0000\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','2');
INSERT INTO `rlb_reboot_history` VALUES ('17','a:5:{s:9:\"sResponse\";s:125:\"S,189,0,0,23:59:19,3,06,000.000.,......00......00,01000000,0,0,0,0,12484,97.6F,88.7F,88.5F,86.9F,88.7F,90.1F,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"000.000.\";s:7:\"sRelays\";s:16:\"......00......00\";s:12:\"sPowercenter\";s:8:\"01000000\";s:5:\"sPump\";a:0:{}}','1');
INSERT INTO `rlb_reboot_history` VALUES ('18','a:5:{s:9:\"sResponse\";s:101:\"S,014,0,7,11:36:45,3,06,000000..,............0000,00000000,0,0,0,0,12515,101.2F,,,,,,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"000000..\";s:7:\"sRelays\";s:16:\"............0000\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','2');
INSERT INTO `rlb_reboot_history` VALUES ('19','a:5:{s:9:\"sResponse\";s:125:\"S,085,0,0,23:59:25,3,06,000.000.,......00......00,00000000,0,0,0,0,12484,83.6F,74.4F,73.2F,74.1F,77.0F,76.9F,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"000.000.\";s:7:\"sRelays\";s:16:\"......00......00\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','1');
INSERT INTO `rlb_reboot_history` VALUES ('20','a:5:{s:9:\"sResponse\";s:100:\"S,210,0,1,11:36:28,3,06,000000..,............0000,00000000,0,0,0,0,12515,87.8F,,,,,,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"000000..\";s:7:\"sRelays\";s:16:\"............0000\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','2');
INSERT INTO `rlb_reboot_history` VALUES ('21','a:5:{s:9:\"sResponse\";s:125:\"S,226,0,0,19:37:08,3,06,000.000.,......00......00,00000000,0,0,0,0,12484,89.4F,80.0F,80.0F,80.8F,80.6F,82.9F,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"000.000.\";s:7:\"sRelays\";s:16:\"......00......00\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','1');
INSERT INTO `rlb_reboot_history` VALUES ('22','a:5:{s:9:\"sResponse\";s:100:\"S,252,0,0,19:37:04,3,06,000000..,............0000,00000000,0,0,0,0,12500,93.3F,,,,,,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"000000..\";s:7:\"sRelays\";s:16:\"............0000\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','2');
INSERT INTO `rlb_reboot_history` VALUES ('23','a:5:{s:9:\"sResponse\";s:125:\"S,138,0,0,23:59:22,3,06,000.000.,......00......00,00000000,0,0,0,0,12484,92.4F,85.6F,86.1F,84.9F,86.0F,86.7F,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"000.000.\";s:7:\"sRelays\";s:16:\"......00......00\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','1');
INSERT INTO `rlb_reboot_history` VALUES ('24','a:5:{s:9:\"sResponse\";s:100:\"S,169,0,1,19:36:45,3,06,000000..,............0000,00000000,0,0,0,0,12500,96.5F,,,,,,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"000000..\";s:7:\"sRelays\";s:16:\"............0000\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','2');
INSERT INTO `rlb_reboot_history` VALUES ('25','a:5:{s:9:\"sResponse\";s:125:\"S,030,0,0,23:59:19,3,06,000.000.,......00......00,00000000,0,0,0,0,12500,91.2F,84.4F,84.5F,83.8F,84.2F,85.4F,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"000.000.\";s:7:\"sRelays\";s:16:\"......00......00\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','1');
INSERT INTO `rlb_reboot_history` VALUES ('26','a:5:{s:9:\"sResponse\";s:100:\"S,078,0,2,19:36:26,3,06,010000..,............0000,00000000,0,0,0,0,12515,95.5F,,,,,,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"010000..\";s:7:\"sRelays\";s:16:\"............0000\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','2');
INSERT INTO `rlb_reboot_history` VALUES ('27','a:5:{s:9:\"sResponse\";s:125:\"S,117,0,0,23:59:18,3,06,000.100.,......00......00,00000000,0,0,0,0,12500,90.5F,84.1F,84.1F,82.6F,79.7F,84.5F,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"000.100.\";s:7:\"sRelays\";s:16:\"......00......00\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:1:{i:0;s:1:\"1\";}}','1');
INSERT INTO `rlb_reboot_history` VALUES ('28','a:5:{s:9:\"sResponse\";s:100:\"S,152,0,3,19:36:08,3,06,210202..,............0000,00000000,0,0,0,0,12515,95.9F,,,,,,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"210202..\";s:7:\"sRelays\";s:16:\"............0000\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','2');
INSERT INTO `rlb_reboot_history` VALUES ('29','a:5:{s:9:\"sResponse\";s:125:\"S,148,0,0,23:59:24,3,06,000.000.,......00......00,00000000,0,0,0,0,12500,88.8F,82.1F,82.1F,80.9F,77.9F,83.3F,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"000.000.\";s:7:\"sRelays\";s:16:\"......00......00\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:1:{i:0;s:1:\"1\";}}','1');
INSERT INTO `rlb_reboot_history` VALUES ('30','a:5:{s:9:\"sResponse\";s:100:\"S,169,0,4,19:35:51,3,06,000000..,............0000,00000000,0,0,0,0,12515,92.9F,,,,,,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"000000..\";s:7:\"sRelays\";s:16:\"............0000\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','2');
INSERT INTO `rlb_reboot_history` VALUES ('31','a:5:{s:9:\"sResponse\";s:125:\"S,127,0,0,23:59:26,3,06,100.000.,......00......00,00000000,0,0,0,0,12500,90.4F,83.1F,83.1F,81.5F,82.4F,83.8F,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"100.000.\";s:7:\"sRelays\";s:16:\"......00......00\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','1');
INSERT INTO `rlb_reboot_history` VALUES ('32','a:5:{s:9:\"sResponse\";s:100:\"S,003,0,5,19:35:33,3,06,010000..,............0000,00000000,0,0,0,0,12515,94.1F,,,,,,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"010000..\";s:7:\"sRelays\";s:16:\"............0000\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','2');
INSERT INTO `rlb_reboot_history` VALUES ('33','a:5:{s:9:\"sResponse\";s:125:\"S,163,0,0,23:59:24,3,06,000.001.,......00......00,00000000,0,0,0,0,12500,96.0F,83.9F,84.0F,81.6F,83.3F,82.2F,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"000.001.\";s:7:\"sRelays\";s:16:\"......00......00\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','1');
INSERT INTO `rlb_reboot_history` VALUES ('34','a:5:{s:9:\"sResponse\";s:100:\"S,075,0,6,19:35:16,3,06,000000..,............0000,00000000,0,0,0,0,12531,94.8F,,,,,,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"000000..\";s:7:\"sRelays\";s:16:\"............0000\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','2');
INSERT INTO `rlb_reboot_history` VALUES ('35','a:5:{s:9:\"sResponse\";s:125:\"S,147,0,0,23:59:19,3,06,000.001.,......00......00,00000000,0,0,0,0,12500,92.3F,83.9F,84.0F,82.7F,83.3F,82.0F,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"000.001.\";s:7:\"sRelays\";s:16:\"......00......00\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','1');
INSERT INTO `rlb_reboot_history` VALUES ('36','a:5:{s:9:\"sResponse\";s:100:\"S,172,0,7,19:34:57,3,06,000000..,............0000,00000000,0,0,0,0,12531,94.2F,,,,,,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"000000..\";s:7:\"sRelays\";s:16:\"............0000\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','2');
INSERT INTO `rlb_reboot_history` VALUES ('37','a:5:{s:9:\"sResponse\";s:125:\"S,062,0,0,23:59:28,3,06,000.000.,......00......00,00000000,0,0,0,0,12500,93.9F,79.7F,79.4F,80.7F,78.8F,78.4F,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"000.000.\";s:7:\"sRelays\";s:16:\"......00......00\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','1');
INSERT INTO `rlb_reboot_history` VALUES ('38','a:5:{s:9:\"sResponse\";s:100:\"S,237,0,1,19:34:40,3,06,000000..,............0000,00000000,0,0,0,0,12531,90.6F,,,,,,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"000000..\";s:7:\"sRelays\";s:16:\"............0000\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','2');
INSERT INTO `rlb_reboot_history` VALUES ('39','a:5:{s:9:\"sResponse\";s:125:\"S,249,0,0,23:59:22,3,06,000.000.,......00......00,00000000,0,0,0,0,12484,94.3F,82.2F,82.4F,81.6F,81.5F,81.1F,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"000.000.\";s:7:\"sRelays\";s:16:\"......00......00\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','1');
INSERT INTO `rlb_reboot_history` VALUES ('40','a:5:{s:9:\"sResponse\";s:100:\"S,150,0,2,19:34:23,3,06,000200..,............0000,00000000,0,0,0,0,12531,93.7F,,,,,,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"000200..\";s:7:\"sRelays\";s:16:\"............0000\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','2');
INSERT INTO `rlb_reboot_history` VALUES ('41','a:5:{s:9:\"sResponse\";s:125:\"S,071,0,0,23:59:17,3,06,000.000.,......00......00,00000000,0,0,0,0,12500,96.6F,83.3F,83.6F,81.5F,78.8F,81.7F,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"000.000.\";s:7:\"sRelays\";s:16:\"......00......00\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','1');
INSERT INTO `rlb_reboot_history` VALUES ('42','a:5:{s:9:\"sResponse\";s:100:\"S,253,0,3,19:34:04,3,06,000200..,............0000,00000000,0,0,0,0,12515,95.3F,,,,,,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"000200..\";s:7:\"sRelays\";s:16:\"............0000\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','2');
INSERT INTO `rlb_reboot_history` VALUES ('43','a:5:{s:9:\"sResponse\";s:125:\"S,015,0,0,23:59:21,3,06,000.000.,......00......00,00000000,0,0,0,0,12515,98.7F,81.6F,81.3F,80.7F,81.5F,81.8F,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"000.000.\";s:7:\"sRelays\";s:16:\"......00......00\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','1');
INSERT INTO `rlb_reboot_history` VALUES ('44','a:5:{s:9:\"sResponse\";s:100:\"S,100,0,4,19:33:46,3,06,000200..,............0000,00000000,0,0,0,0,12531,97.5F,,,,,,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"000200..\";s:7:\"sRelays\";s:16:\"............0000\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','2');
INSERT INTO `rlb_reboot_history` VALUES ('45','a:5:{s:9:\"sResponse\";s:126:\"S,153,0,0,23:59:15,3,06,000.100.,......00......00,00000000,0,0,0,0,12515,101.4F,84.3F,84.3F,83.2F,79.7F,83.4F,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"000.100.\";s:7:\"sRelays\";s:16:\"......00......00\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:1:{i:0;s:1:\"1\";}}','1');
INSERT INTO `rlb_reboot_history` VALUES ('46','a:5:{s:9:\"sResponse\";s:100:\"S,047,0,5,19:33:26,3,06,200212..,............0000,00000000,0,0,0,0,12515,98.7F,,,,,,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"200212..\";s:7:\"sRelays\";s:16:\"............0000\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','2');
INSERT INTO `rlb_reboot_history` VALUES ('47','a:5:{s:9:\"sResponse\";s:125:\"S,185,0,0,23:59:20,3,06,000.000.,......00......00,00000000,0,0,0,0,12500,95.8F,87.6F,87.6F,86.6F,86.9F,84.7F,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"000.000.\";s:7:\"sRelays\";s:16:\"......00......00\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:1:{i:0;s:1:\"1\";}}','1');
INSERT INTO `rlb_reboot_history` VALUES ('48','a:5:{s:9:\"sResponse\";s:100:\"S,113,0,6,19:33:06,3,06,200212..,............0000,00000000,0,0,0,0,12515,99.6F,,,,,,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"200212..\";s:7:\"sRelays\";s:16:\"............0000\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','2');
INSERT INTO `rlb_reboot_history` VALUES ('49','a:5:{s:9:\"sResponse\";s:125:\"S,115,0,0,23:59:23,3,06,000.000.,......00......00,00000000,0,0,0,0,12500,94.4F,86.9F,87.1F,85.9F,86.9F,83.6F,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"000.000.\";s:7:\"sRelays\";s:16:\"......00......00\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:1:{i:0;s:1:\"1\";}}','1');
INSERT INTO `rlb_reboot_history` VALUES ('50','a:5:{s:9:\"sResponse\";s:100:\"S,177,0,7,19:32:47,3,06,200212..,............0000,00000000,0,0,0,0,12515,98.6F,,,,,,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"200212..\";s:7:\"sRelays\";s:16:\"............0000\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','2');
INSERT INTO `rlb_reboot_history` VALUES ('51','a:5:{s:9:\"sResponse\";s:125:\"S,185,0,0,23:59:25,3,06,000.000.,......10......00,10000000,0,0,0,0,12515,99.6F,86.3F,86.7F,85.8F,86.9F,83.8F,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"000.000.\";s:7:\"sRelays\";s:16:\"......10......00\";s:12:\"sPowercenter\";s:8:\"10000000\";s:5:\"sPump\";a:1:{i:0;s:1:\"2\";}}','1');
INSERT INTO `rlb_reboot_history` VALUES ('52','a:5:{s:9:\"sResponse\";s:100:\"S,221,0,1,19:32:29,3,06,000000..,............0000,00000000,0,0,0,0,12531,98.2F,,,,,,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"000000..\";s:7:\"sRelays\";s:16:\"............0000\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','2');
INSERT INTO `rlb_reboot_history` VALUES ('53','a:5:{s:9:\"sResponse\";s:125:\"S,021,0,0,23:59:23,3,06,000.200.,......00......00,00000000,0,0,0,0,12500,98.4F,83.5F,87.5F,85.2F,86.9F,84.2F,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"000.200.\";s:7:\"sRelays\";s:16:\"......00......00\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:1:{i:0;s:1:\"2\";}}','1');
INSERT INTO `rlb_reboot_history` VALUES ('54','a:5:{s:9:\"sResponse\";s:100:\"S,007,0,2,19:32:10,3,06,000001..,............0000,00000000,0,0,0,0,12531,98.6F,,,,,,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"000001..\";s:7:\"sRelays\";s:16:\"............0000\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','2');
INSERT INTO `rlb_reboot_history` VALUES ('55','a:5:{s:9:\"sResponse\";s:126:\"S,117,0,0,23:59:15,3,06,000.000.,......00......00,00000000,0,0,0,0,12500,100.5F,85.6F,86.5F,84.9F,86.0F,83.9F,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"000.000.\";s:7:\"sRelays\";s:16:\"......00......00\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:1:{i:0;s:1:\"2\";}}','1');
INSERT INTO `rlb_reboot_history` VALUES ('56','a:5:{s:9:\"sResponse\";s:100:\"S,239,0,3,19:31:52,3,06,000000..,............0000,00000000,0,0,0,0,12531,97.4F,,,,,,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"000000..\";s:7:\"sRelays\";s:16:\"............0000\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','2');
INSERT INTO `rlb_reboot_history` VALUES ('57','a:5:{s:9:\"sResponse\";s:126:\"S,054,0,0,23:59:16,3,06,000.000.,......00......00,00000000,0,0,0,0,12500,104.3F,87.6F,88.1F,86.0F,87.8F,85.7F,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"000.000.\";s:7:\"sRelays\";s:16:\"......00......00\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','1');
INSERT INTO `rlb_reboot_history` VALUES ('58','a:5:{s:9:\"sResponse\";s:101:\"S,068,0,4,19:31:31,3,06,000000..,............0000,00000000,0,0,0,0,12515,100.4F,,,,,,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"000000..\";s:7:\"sRelays\";s:16:\"............0000\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','2');
INSERT INTO `rlb_reboot_history` VALUES ('59','a:5:{s:9:\"sResponse\";s:126:\"S,226,0,0,23:59:20,3,06,100.100.,......00......00,00000000,0,0,0,0,12500,102.4F,88.8F,89.5F,87.1F,86.9F,87.0F,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"100.100.\";s:7:\"sRelays\";s:16:\"......00......00\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','1');
INSERT INTO `rlb_reboot_history` VALUES ('60','a:5:{s:9:\"sResponse\";s:101:\"S,134,0,5,19:31:11,3,06,000000..,............0000,00000000,0,0,0,0,12531,100.7F,,,,,,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"000000..\";s:7:\"sRelays\";s:16:\"............0000\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','2');
INSERT INTO `rlb_reboot_history` VALUES ('61','a:5:{s:9:\"sResponse\";s:125:\"S,206,0,0,23:59:23,3,06,100.000.,......00......00,00000000,0,0,0,0,12515,99.7F,90.8F,91.6F,89.3F,91.4F,87.9F,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"100.000.\";s:7:\"sRelays\";s:16:\"......00......00\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','1');
INSERT INTO `rlb_reboot_history` VALUES ('62','a:5:{s:9:\"sResponse\";s:101:\"S,113,0,6,19:30:49,3,06,010000..,............0000,00000000,0,0,0,0,12515,101.9F,,,,,,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"010000..\";s:7:\"sRelays\";s:16:\"............0000\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','2');
INSERT INTO `rlb_reboot_history` VALUES ('63','a:5:{s:9:\"sResponse\";s:126:\"S,145,0,0,23:59:15,3,06,000.000.,......00......00,00000000,0,0,0,0,12515,102.5F,91.6F,92.1F,90.3F,91.4F,88.4F,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"000.000.\";s:7:\"sRelays\";s:16:\"......00......00\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','1');
INSERT INTO `rlb_reboot_history` VALUES ('64','a:5:{s:9:\"sResponse\";s:101:\"S,177,0,7,19:30:27,3,06,010000..,............0000,00000000,0,0,0,0,12515,103.0F,,,,,,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"010000..\";s:7:\"sRelays\";s:16:\"............0000\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','2');
INSERT INTO `rlb_reboot_history` VALUES ('65','a:5:{s:9:\"sResponse\";s:125:\"S,045,0,0,23:59:18,3,06,000.000.,......00......00,00000000,0,0,0,0,12500,99.1F,91.4F,91.9F,90.3F,91.4F,88.4F,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"000.000.\";s:7:\"sRelays\";s:16:\"......00......00\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','1');
INSERT INTO `rlb_reboot_history` VALUES ('66','a:5:{s:9:\"sResponse\";s:101:\"S,251,0,1,19:30:06,3,06,010000..,............0000,00000000,0,0,0,0,12515,102.5F,,,,,,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"010000..\";s:7:\"sRelays\";s:16:\"............0000\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','2');
INSERT INTO `rlb_reboot_history` VALUES ('67','a:5:{s:9:\"sResponse\";s:126:\"S,115,0,0,23:59:18,3,06,000.000.,......00......00,00000000,0,0,0,0,12500,105.7F,91.4F,91.9F,90.5F,91.4F,88.8F,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"000.000.\";s:7:\"sRelays\";s:16:\"......00......00\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','1');
INSERT INTO `rlb_reboot_history` VALUES ('68','a:5:{s:9:\"sResponse\";s:101:\"S,060,0,2,19:29:45,3,06,010000..,............0000,00000000,0,0,0,0,12515,103.6F,,,,,,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"010000..\";s:7:\"sRelays\";s:16:\"............0000\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','2');
INSERT INTO `rlb_reboot_history` VALUES ('69','a:5:{s:9:\"sResponse\";s:126:\"S,132,0,0,23:59:15,3,06,000.000.,......00......00,00000000,0,0,0,0,12500,100.0F,92.5F,92.9F,92.0F,92.3F,93.1F,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"000.000.\";s:7:\"sRelays\";s:16:\"......00......00\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','1');
INSERT INTO `rlb_reboot_history` VALUES ('70','a:5:{s:9:\"sResponse\";s:101:\"S,127,0,3,19:29:24,3,06,010000..,............0000,00000000,0,0,0,0,12515,104.2F,,,,,,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"010000..\";s:7:\"sRelays\";s:16:\"............0000\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','2');
INSERT INTO `rlb_reboot_history` VALUES ('71','a:5:{s:9:\"sResponse\";s:126:\"S,205,0,0,23:59:19,3,06,000.100.,......00......00,00000000,0,0,0,0,12484,101.0F,92.2F,92.3F,91.7F,83.3F,93.7F,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"000.100.\";s:7:\"sRelays\";s:16:\"......00......00\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','1');
INSERT INTO `rlb_reboot_history` VALUES ('72','a:5:{s:9:\"sResponse\";s:101:\"S,247,0,4,19:29:03,3,06,210112..,............0000,00000000,0,0,0,0,12515,105.9F,,,,,,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"210112..\";s:7:\"sRelays\";s:16:\"............0000\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','2');
INSERT INTO `rlb_reboot_history` VALUES ('73','a:5:{s:9:\"sResponse\";s:126:\"S,194,0,0,23:59:16,3,06,100.101.,......00......00,00000000,0,0,0,0,12500,108.6F,93.5F,93.9F,92.0F,84.2F,90.8F,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"100.101.\";s:7:\"sRelays\";s:16:\"......00......00\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','1');
INSERT INTO `rlb_reboot_history` VALUES ('74','a:5:{s:9:\"sResponse\";s:101:\"S,248,0,5,19:28:42,3,06,210012..,............0000,00000000,0,0,0,0,12515,109.2F,,,,,,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"210012..\";s:7:\"sRelays\";s:16:\"............0000\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','2');
INSERT INTO `rlb_reboot_history` VALUES ('75','a:5:{s:9:\"sResponse\";s:126:\"S,148,0,0,23:59:19,3,06,000.001.,......00......00,00000000,0,0,0,0,12500,104.6F,92.3F,92.2F,90.8F,92.3F,90.2F,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"000.001.\";s:7:\"sRelays\";s:16:\"......00......00\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','1');
INSERT INTO `rlb_reboot_history` VALUES ('76','a:5:{s:9:\"sResponse\";s:101:\"S,183,0,6,19:28:21,3,06,012000..,............0000,00000000,0,0,0,0,12515,106.8F,,,,,,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"012000..\";s:7:\"sRelays\";s:16:\"............0000\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','2');
INSERT INTO `rlb_reboot_history` VALUES ('77','a:5:{s:9:\"sResponse\";s:126:\"S,119,0,0,23:59:19,3,06,000.000.,......00......00,00000000,0,0,0,0,12500,104.0F,87.5F,87.2F,86.9F,86.9F,87.2F,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"000.000.\";s:7:\"sRelays\";s:16:\"......00......00\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','1');
INSERT INTO `rlb_reboot_history` VALUES ('78','a:5:{s:9:\"sResponse\";s:101:\"S,029,0,7,19:28:01,3,06,012000..,............0000,00000000,0,0,0,0,12500,100.5F,,,,,,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"012000..\";s:7:\"sRelays\";s:16:\"............0000\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','2');
INSERT INTO `rlb_reboot_history` VALUES ('79','a:5:{s:9:\"sResponse\";s:126:\"S,017,0,0,23:59:15,3,06,000.000.,......00......00,00000000,0,0,0,0,12500,103.7F,85.8F,85.3F,85.4F,85.1F,86.5F,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"000.000.\";s:7:\"sRelays\";s:16:\"......00......00\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','1');
INSERT INTO `rlb_reboot_history` VALUES ('80','a:5:{s:9:\"sResponse\";s:101:\"S,094,0,1,19:27:43,3,06,012000..,............0000,00000000,0,0,0,0,12500,101.3F,,,,,,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"012000..\";s:7:\"sRelays\";s:16:\"............0000\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','2');
INSERT INTO `rlb_reboot_history` VALUES ('81','a:5:{s:9:\"sResponse\";s:126:\"S,245,0,0,23:59:15,3,06,000.000.,......00......00,00000000,0,0,0,0,12500,103.9F,87.2F,87.4F,86.7F,86.9F,87.7F,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"000.000.\";s:7:\"sRelays\";s:16:\"......00......00\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','1');
INSERT INTO `rlb_reboot_history` VALUES ('82','a:5:{s:9:\"sResponse\";s:101:\"S,026,0,2,19:27:24,3,06,010000..,............0000,00000000,0,0,0,0,12500,102.2F,,,,,,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"010000..\";s:7:\"sRelays\";s:16:\"............0000\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','2');
INSERT INTO `rlb_reboot_history` VALUES ('83','a:5:{s:9:\"sResponse\";s:126:\"S,007,0,0,23:59:23,3,06,000.000.,......00......00,00000000,0,0,0,0,12484,103.0F,88.1F,88.0F,87.8F,89.6F,88.5F,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"000.000.\";s:7:\"sRelays\";s:16:\"......00......00\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:1:{i:0;s:1:\"2\";}}','1');
INSERT INTO `rlb_reboot_history` VALUES ('84','a:5:{s:9:\"sResponse\";s:101:\"S,183,0,3,19:27:05,3,06,010000..,............0000,00000000,0,0,0,0,12500,102.9F,,,,,,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"010000..\";s:7:\"sRelays\";s:16:\"............0000\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','2');
INSERT INTO `rlb_reboot_history` VALUES ('85','a:5:{s:9:\"sResponse\";s:125:\"S,015,0,0,23:59:21,3,06,000.000.,......00......00,00000000,0,0,0,0,12468,92.8F,74.0F,72.2F,82.4F,80.6F,81.2F,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"000.000.\";s:7:\"sRelays\";s:16:\"......00......00\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','1');
INSERT INTO `rlb_reboot_history` VALUES ('86','a:5:{s:9:\"sResponse\";s:100:\"S,181,0,4,19:26:46,3,06,010000..,............0000,00000000,0,0,0,0,12500,91.1F,,,,,,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"010000..\";s:7:\"sRelays\";s:16:\"............0000\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','2');
INSERT INTO `rlb_reboot_history` VALUES ('87','a:5:{s:9:\"sResponse\";s:125:\"S,245,0,0,23:59:31,3,06,100.100.,......00......00,00000000,0,0,0,0,12484,97.8F,80.3F,80.2F,79.9F,80.6F,83.3F,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"100.100.\";s:7:\"sRelays\";s:16:\"......00......00\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','1');
INSERT INTO `rlb_reboot_history` VALUES ('88','a:5:{s:9:\"sResponse\";s:100:\"S,095,0,5,19:26:32,3,06,010100..,............0000,00000000,0,0,0,0,12500,96.6F,,,,,,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"010100..\";s:7:\"sRelays\";s:16:\"............0000\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','2');
INSERT INTO `rlb_reboot_history` VALUES ('89','a:5:{s:9:\"sResponse\";s:125:\"S,127,0,0,23:59:24,3,06,000.100.,......00......00,00000000,0,0,0,0,12484,95.6F,84.7F,84.7F,83.4F,84.2F,84.9F,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"000.100.\";s:7:\"sRelays\";s:16:\"......00......00\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','1');
INSERT INTO `rlb_reboot_history` VALUES ('90','a:5:{s:9:\"sResponse\";s:100:\"S,042,0,6,19:26:14,3,06,010000..,............0000,00000000,0,0,0,0,12500,96.5F,,,,,,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"010000..\";s:7:\"sRelays\";s:16:\"............0000\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','2');
INSERT INTO `rlb_reboot_history` VALUES ('91','a:5:{s:9:\"sResponse\";s:126:\"S,116,0,0,23:59:16,3,06,000.000.,......00......00,00000000,0,0,0,0,12500,103.4F,84.9F,84.9F,84.1F,84.2F,85.0F,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"000.000.\";s:7:\"sRelays\";s:16:\"......00......00\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','1');
INSERT INTO `rlb_reboot_history` VALUES ('92','a:5:{s:9:\"sResponse\";s:100:\"S,106,0,7,19:25:55,3,06,010000..,............0000,00000000,0,0,0,0,12515,97.0F,,,,,,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"010000..\";s:7:\"sRelays\";s:16:\"............0000\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','2');
INSERT INTO `rlb_reboot_history` VALUES ('93','a:5:{s:9:\"sResponse\";s:126:\"S,140,0,0,23:59:20,3,06,000.000.,......00......00,00000000,0,0,0,0,12500,102.4F,83.8F,83.8F,82.7F,83.3F,83.5F,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"000.000.\";s:7:\"sRelays\";s:16:\"......00......00\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','1');
INSERT INTO `rlb_reboot_history` VALUES ('94','a:5:{s:9:\"sResponse\";s:100:\"S,017,0,1,19:25:36,3,06,010000..,............0000,00000000,0,0,0,0,12515,96.6F,,,,,,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"010000..\";s:7:\"sRelays\";s:16:\"............0000\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','2');
INSERT INTO `rlb_reboot_history` VALUES ('95','a:5:{s:9:\"sResponse\";s:125:\"S,248,0,0,23:59:31,3,06,000.100.,......00......00,00000000,0,0,0,0,12484,96.9F,83.3F,83.6F,81.2F,83.3F,82.9F,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"000.100.\";s:7:\"sRelays\";s:16:\"......00......00\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','1');
INSERT INTO `rlb_reboot_history` VALUES ('96','a:5:{s:9:\"sResponse\";s:100:\"S,090,0,2,19:25:19,3,06,210102..,............0000,00000000,0,0,0,0,12515,96.2F,,,,,,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"210102..\";s:7:\"sRelays\";s:16:\"............0000\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','2');
INSERT INTO `rlb_reboot_history` VALUES ('97','a:5:{s:9:\"sResponse\";s:125:\"S,091,0,0,23:59:24,3,06,000.000.,......00......00,00000000,0,0,0,0,12500,96.6F,83.0F,83.5F,82.0F,83.3F,82.3F,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"000.000.\";s:7:\"sRelays\";s:16:\"......00......00\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','1');
INSERT INTO `rlb_reboot_history` VALUES ('98','a:5:{s:9:\"sResponse\";s:100:\"S,241,0,3,19:25:02,3,06,210100..,............0000,00000000,0,0,0,0,12515,95.2F,,,,,,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"210100..\";s:7:\"sRelays\";s:16:\"............0000\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','2');
INSERT INTO `rlb_reboot_history` VALUES ('99','a:5:{s:9:\"sResponse\";s:125:\"S,067,0,0,23:59:28,3,06,000.000.,......00......00,00000000,0,0,0,0,12500,99.4F,81.4F,82.0F,81.7F,81.5F,81.6F,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"000.000.\";s:7:\"sRelays\";s:16:\"......00......00\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','1');
INSERT INTO `rlb_reboot_history` VALUES ('100','a:5:{s:9:\"sResponse\";s:100:\"S,043,0,4,19:24:45,3,06,210100..,............0000,00000000,0,0,0,0,12515,94.0F,,,,,,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"210100..\";s:7:\"sRelays\";s:16:\"............0000\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','2');
INSERT INTO `rlb_reboot_history` VALUES ('101','a:5:{s:9:\"sResponse\";s:127:\"S,022,0,0,23:59:27,3,02,000.012.,......00......00,00000000,0,0,0,0,12500,90.2F,80.2F,79.9F,79.1F,78.8F,82.7F,21.83,000000,21.83\";s:7:\"sValves\";s:8:\"000.012.\";s:7:\"sRelays\";s:16:\"......00......00\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','1');
INSERT INTO `rlb_reboot_history` VALUES ('102','a:5:{s:9:\"sResponse\";s:100:\"S,059,0,5,19:24:28,3,06,022200..,............0000,00000000,0,0,0,0,12515,94.4F,,,,,,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"022200..\";s:7:\"sRelays\";s:16:\"............0000\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','2');
INSERT INTO `rlb_reboot_history` VALUES ('103','a:5:{s:9:\"sResponse\";s:127:\"S,067,0,0,23:59:26,3,02,100.112.,......00......00,00000000,0,0,0,0,12500,93.0F,80.9F,80.6F,79.3F,80.6F,84.0F,21.18,000000,21.18\";s:7:\"sValves\";s:8:\"100.112.\";s:7:\"sRelays\";s:16:\"......00......00\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','1');
INSERT INTO `rlb_reboot_history` VALUES ('104','a:5:{s:9:\"sResponse\";s:100:\"S,114,0,6,19:24:11,3,06,222212..,............0000,00000000,0,0,0,0,12500,97.5F,,,,,,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"222212..\";s:7:\"sRelays\";s:16:\"............0000\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','2');
INSERT INTO `rlb_reboot_history` VALUES ('105','a:5:{s:9:\"sResponse\";s:127:\"S,174,0,0,23:59:21,3,02,100.112.,......00......00,00000000,0,0,0,0,12500,94.3F,84.5F,84.5F,83.2F,84.2F,85.8F,21.02,000000,21.02\";s:7:\"sValves\";s:8:\"100.112.\";s:7:\"sRelays\";s:16:\"......00......00\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','1');
INSERT INTO `rlb_reboot_history` VALUES ('106','a:5:{s:9:\"sResponse\";s:100:\"S,108,0,7,19:23:53,3,06,222212..,............0000,00000000,0,0,0,0,12500,98.8F,,,,,,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"222212..\";s:7:\"sRelays\";s:16:\"............0000\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','2');
INSERT INTO `rlb_reboot_history` VALUES ('107','a:5:{s:9:\"sResponse\";s:127:\"S,003,0,0,23:59:23,3,02,000.000.,......00......00,00000000,0,0,0,0,12515,96.7F,90.1F,89.9F,88.9F,89.6F,90.2F,21.09,000000,21.07\";s:7:\"sValves\";s:8:\"000.000.\";s:7:\"sRelays\";s:16:\"......00......00\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','1');
INSERT INTO `rlb_reboot_history` VALUES ('108','a:5:{s:9:\"sResponse\";s:101:\"S,173,0,1,19:23:33,3,06,222212..,............0000,00000000,0,0,0,0,12515,102.4F,,,,,,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"222212..\";s:7:\"sRelays\";s:16:\"............0000\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','2');
INSERT INTO `rlb_reboot_history` VALUES ('109','a:5:{s:9:\"sResponse\";s:127:\"S,150,0,0,23:59:23,3,02,000.112.,......00......00,00000000,0,0,0,0,12500,94.1F,85.4F,85.3F,84.8F,85.1F,86.2F,21.19,000000,21.14\";s:7:\"sValves\";s:8:\"000.112.\";s:7:\"sRelays\";s:16:\"......00......00\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','1');
INSERT INTO `rlb_reboot_history` VALUES ('110','a:5:{s:9:\"sResponse\";s:100:\"S,048,0,2,19:23:14,3,06,222212..,............0000,00000000,0,0,0,0,12515,98.4F,,,,,,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"222212..\";s:7:\"sRelays\";s:16:\"............0000\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','2');
INSERT INTO `rlb_reboot_history` VALUES ('111','a:5:{s:9:\"sResponse\";s:127:\"S,010,0,0,23:59:24,3,02,000.112.,......00......00,00000000,0,0,0,0,12500,93.5F,84.2F,83.9F,83.9F,83.3F,85.1F,21.30,000000,21.25\";s:7:\"sValves\";s:8:\"000.112.\";s:7:\"sRelays\";s:16:\"......00......00\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','1');
INSERT INTO `rlb_reboot_history` VALUES ('112','a:5:{s:9:\"sResponse\";s:100:\"S,169,0,3,19:22:56,3,06,222212..,............0000,00000000,0,0,0,0,12515,97.9F,,,,,,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"222212..\";s:7:\"sRelays\";s:16:\"............0000\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','2');
INSERT INTO `rlb_reboot_history` VALUES ('113','a:5:{s:9:\"sResponse\";s:127:\"S,213,0,0,23:59:23,3,02,000.000.,......00......00,00000000,0,0,0,0,12500,92.2F,82.3F,82.2F,82.2F,81.5F,84.0F,13.76,000000,13.74\";s:7:\"sValves\";s:8:\"000.000.\";s:7:\"sRelays\";s:16:\"......00......00\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','1');
INSERT INTO `rlb_reboot_history` VALUES ('114','a:5:{s:9:\"sResponse\";s:100:\"S,107,0,4,19:22:37,3,06,000000..,............0000,00000000,0,0,0,0,12515,96.5F,,,,,,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"000000..\";s:7:\"sRelays\";s:16:\"............0000\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','2');
INSERT INTO `rlb_reboot_history` VALUES ('115','a:5:{s:9:\"sResponse\";s:127:\"S,187,0,0,23:59:26,3,02,000.112.,......00......00,00000000,0,0,0,0,12500,91.0F,81.2F,80.9F,79.5F,80.6F,82.9F,18.06,000000,18.03\";s:7:\"sValves\";s:8:\"000.112.\";s:7:\"sRelays\";s:16:\"......00......00\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','1');
INSERT INTO `rlb_reboot_history` VALUES ('116','a:5:{s:9:\"sResponse\";s:100:\"S,248,0,5,19:22:21,3,06,122212..,............0000,00000000,0,0,0,0,12500,95.6F,,,,,,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"122212..\";s:7:\"sRelays\";s:16:\"............0000\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','2');
INSERT INTO `rlb_reboot_history` VALUES ('117','a:5:{s:9:\"sResponse\";s:127:\"S,085,0,0,23:59:30,3,02,000.000.,......00......00,00000000,0,0,0,0,12484,92.0F,85.0F,85.1F,83.2F,84.2F,85.6F,18.39,000000,18.34\";s:7:\"sValves\";s:8:\"000.000.\";s:7:\"sRelays\";s:16:\"......00......00\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','1');
INSERT INTO `rlb_reboot_history` VALUES ('118','a:5:{s:9:\"sResponse\";s:100:\"S,058,0,6,19:22:03,3,06,122212..,............0000,00000000,0,0,0,0,12515,97.6F,,,,,,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"122212..\";s:7:\"sRelays\";s:16:\"............0000\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','2');
INSERT INTO `rlb_reboot_history` VALUES ('119','a:5:{s:9:\"sResponse\";s:127:\"S,171,0,0,23:59:27,3,02,000.000.,......00......00,00000000,0,0,0,0,12484,93.9F,87.6F,87.7F,86.2F,87.8F,87.9F,18.43,000000,18.43\";s:7:\"sValves\";s:8:\"000.000.\";s:7:\"sRelays\";s:16:\"......00......00\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','1');
INSERT INTO `rlb_reboot_history` VALUES ('120','a:5:{s:9:\"sResponse\";s:101:\"S,122,0,7,19:21:45,3,06,122212..,............0000,00000000,0,0,0,0,12515,100.1F,,,,,,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"122212..\";s:7:\"sRelays\";s:16:\"............0000\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','2');
INSERT INTO `rlb_reboot_history` VALUES ('121','a:5:{s:9:\"sResponse\";s:127:\"S,184,0,0,23:59:35,3,02,000.000.,......00......00,00000000,0,0,0,0,12484,87.1F,79.4F,77.8F,79.6F,77.9F,80.5F,16.98,000000,16.98\";s:7:\"sValves\";s:8:\"000.000.\";s:7:\"sRelays\";s:16:\"......00......00\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','1');
INSERT INTO `rlb_reboot_history` VALUES ('122','a:5:{s:9:\"sResponse\";s:100:\"S,205,0,1,19:21:29,3,06,122212..,............0000,00000000,0,0,0,0,12515,92.8F,,,,,,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"122212..\";s:7:\"sRelays\";s:16:\"............0000\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','2');
INSERT INTO `rlb_reboot_history` VALUES ('123','a:5:{s:9:\"sResponse\";s:127:\"S,148,0,0,23:59:26,3,02,000.000.,......00......00,00000000,0,0,0,0,12484,81.2F,74.5F,72.8F,74.6F,72.5F,74.1F,17.17,000000,17.13\";s:7:\"sValves\";s:8:\"000.000.\";s:7:\"sRelays\";s:16:\"......00......00\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','1');
INSERT INTO `rlb_reboot_history` VALUES ('124','a:5:{s:9:\"sResponse\";s:100:\"S,087,0,2,19:21:14,3,06,122212..,............0000,00000000,0,0,0,0,12515,87.1F,,,,,,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"122212..\";s:7:\"sRelays\";s:16:\"............0000\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','2');
INSERT INTO `rlb_reboot_history` VALUES ('125','a:5:{s:9:\"sResponse\";s:127:\"S,067,0,0,23:59:28,3,02,000.000.,......00......00,00000000,0,0,0,0,12484,87.8F,80.4F,79.6F,79.5F,79.7F,81.4F,17.42,000000,17.42\";s:7:\"sValves\";s:8:\"000.000.\";s:7:\"sRelays\";s:16:\"......00......00\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','1');
INSERT INTO `rlb_reboot_history` VALUES ('126','a:5:{s:9:\"sResponse\";s:100:\"S,154,0,3,19:20:58,3,06,122212..,............0000,00000000,0,0,0,0,12515,93.5F,,,,,,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"122212..\";s:7:\"sRelays\";s:16:\"............0000\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','2');
INSERT INTO `rlb_reboot_history` VALUES ('127','a:5:{s:9:\"sResponse\";s:127:\"S,071,0,0,23:59:28,3,02,000.000.,......00......00,00000000,0,0,0,0,12484,90.8F,84.4F,84.5F,83.1F,84.2F,84.9F,17.66,000000,17.63\";s:7:\"sValves\";s:8:\"000.000.\";s:7:\"sRelays\";s:16:\"......00......00\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','1');
INSERT INTO `rlb_reboot_history` VALUES ('128','a:5:{s:9:\"sResponse\";s:100:\"S,010,0,4,19:20:40,3,06,122212..,............0000,00000000,0,0,0,0,12515,96.6F,,,,,,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"122212..\";s:7:\"sRelays\";s:16:\"............0000\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','2');
INSERT INTO `rlb_reboot_history` VALUES ('129','a:5:{s:9:\"sResponse\";s:127:\"S,028,0,0,23:59:26,3,02,000.000.,......00......00,00000000,0,0,0,0,12484,96.4F,77.6F,76.4F,77.8F,76.1F,79.0F,16.41,000000,16.38\";s:7:\"sValves\";s:8:\"000.000.\";s:7:\"sRelays\";s:16:\"......00......00\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','1');
INSERT INTO `rlb_reboot_history` VALUES ('130','a:5:{s:9:\"sResponse\";s:100:\"S,103,0,5,19:20:22,3,06,000000..,............0000,00000000,0,0,0,0,12515,94.3F,,,,,,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"000000..\";s:7:\"sRelays\";s:16:\"............0000\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','2');
INSERT INTO `rlb_reboot_history` VALUES ('131','a:5:{s:9:\"sResponse\";s:127:\"S,205,0,0,23:59:18,3,02,000.000.,......00......00,00000000,0,0,0,0,12500,94.4F,78.1F,77.3F,77.5F,77.0F,78.8F,16.62,000000,16.59\";s:7:\"sValves\";s:8:\"000.000.\";s:7:\"sRelays\";s:16:\"......00......00\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','1');
INSERT INTO `rlb_reboot_history` VALUES ('132','a:5:{s:9:\"sResponse\";s:100:\"S,206,0,6,19:20:06,3,06,000000..,............0000,00000000,0,0,0,0,12515,91.1F,,,,,,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"000000..\";s:7:\"sRelays\";s:16:\"............0000\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','2');
INSERT INTO `rlb_reboot_history` VALUES ('133','a:5:{s:9:\"sResponse\";s:127:\"S,103,0,0,23:59:32,3,02,000.000.,......00......00,00000000,0,0,0,0,12484,92.5F,74.8F,72.7F,75.3F,72.5F,77.5F,16.80,000000,16.74\";s:7:\"sValves\";s:8:\"000.000.\";s:7:\"sRelays\";s:16:\"......00......00\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','1');
INSERT INTO `rlb_reboot_history` VALUES ('134','a:5:{s:9:\"sResponse\";s:100:\"S,164,0,7,19:19:52,3,06,000000..,............0000,00000000,0,0,0,0,12515,90.3F,,,,,,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"000000..\";s:7:\"sRelays\";s:16:\"............0000\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','2');
INSERT INTO `rlb_reboot_history` VALUES ('135','a:5:{s:9:\"sResponse\";s:127:\"S,215,0,0,23:59:26,3,02,000.000.,......00......00,00000000,0,0,0,0,12500,95.5F,78.1F,76.8F,77.9F,76.1F,80.0F,16.45,000000,16.45\";s:7:\"sValves\";s:8:\"000.000.\";s:7:\"sRelays\";s:16:\"......00......00\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','1');
INSERT INTO `rlb_reboot_history` VALUES ('136','a:5:{s:9:\"sResponse\";s:100:\"S,204,0,1,19:19:35,3,06,000000..,............0000,00000000,0,0,0,0,12515,94.8F,,,,,,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"000000..\";s:7:\"sRelays\";s:16:\"............0000\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','2');
INSERT INTO `rlb_reboot_history` VALUES ('137','a:5:{s:9:\"sResponse\";s:128:\"S,047,0,0,23:59:23,3,02,100.000.,......00......00,00000000,0,0,0,0,12500,100.2F,80.6F,79.8F,80.5F,79.7F,81.8F,16.44,000000,16.39\";s:7:\"sValves\";s:8:\"100.000.\";s:7:\"sRelays\";s:16:\"......00......00\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','1');
INSERT INTO `rlb_reboot_history` VALUES ('138','a:5:{s:9:\"sResponse\";s:100:\"S,053,0,2,19:19:17,3,06,000000..,............0000,00000000,0,0,0,0,12515,97.9F,,,,,,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"000000..\";s:7:\"sRelays\";s:16:\"............0000\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','2');
INSERT INTO `rlb_reboot_history` VALUES ('139','a:5:{s:9:\"sResponse\";s:128:\"S,075,0,0,23:59:25,3,02,000.000.,......00......00,00000000,0,0,0,0,12500,103.0F,83.3F,83.6F,80.8F,78.8F,84.0F,16.55,000000,16.51\";s:7:\"sValves\";s:8:\"000.000.\";s:7:\"sRelays\";s:16:\"......00......00\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','1');
INSERT INTO `rlb_reboot_history` VALUES ('140','a:5:{s:9:\"sResponse\";s:100:\"S,046,0,3,19:18:58,3,06,000000..,............0000,00000000,0,0,0,0,12515,98.4F,,,,,,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"000000..\";s:7:\"sRelays\";s:16:\"............0000\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','2');
INSERT INTO `rlb_reboot_history` VALUES ('141','a:5:{s:9:\"sResponse\";s:128:\"S,235,0,0,23:59:19,3,02,000.000.,......00......00,00000000,0,0,0,0,12500,103.6F,84.0F,84.4F,82.3F,83.3F,84.0F,16.65,000000,16.63\";s:7:\"sValves\";s:8:\"000.000.\";s:7:\"sRelays\";s:16:\"......00......00\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','1');
INSERT INTO `rlb_reboot_history` VALUES ('142','a:5:{s:9:\"sResponse\";s:100:\"S,137,0,4,19:18:40,3,06,000000..,............0000,00000000,0,0,0,0,12515,98.4F,,,,,,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"000000..\";s:7:\"sRelays\";s:16:\"............0000\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','2');
INSERT INTO `rlb_reboot_history` VALUES ('143','a:5:{s:9:\"sResponse\";s:128:\"S,007,0,0,23:59:15,3,02,000.000.,......00......00,00000000,0,0,0,0,12500,102.5F,83.2F,83.2F,81.8F,82.4F,83.3F,16.76,000000,16.72\";s:7:\"sValves\";s:8:\"000.000.\";s:7:\"sRelays\";s:16:\"......00......00\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','1');
INSERT INTO `rlb_reboot_history` VALUES ('144','a:5:{s:9:\"sResponse\";s:100:\"S,205,0,5,19:18:20,3,06,000000..,............0000,00000000,0,0,0,0,12515,98.5F,,,,,,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"000000..\";s:7:\"sRelays\";s:16:\"............0000\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','2');
INSERT INTO `rlb_reboot_history` VALUES ('145','a:5:{s:9:\"sResponse\";s:127:\"S,093,0,0,23:59:18,3,02,000.000.,......00......00,00000000,0,0,0,0,12500,97.7F,81.8F,81.8F,81.2F,81.5F,81.6F,17.04,000000,17.02\";s:7:\"sValves\";s:8:\"000.000.\";s:7:\"sRelays\";s:16:\"......00......00\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','1');
INSERT INTO `rlb_reboot_history` VALUES ('146','a:5:{s:9:\"sResponse\";s:100:\"S,016,0,6,19:18:01,3,06,000000..,............0000,00000000,0,0,0,0,12515,93.5F,,,,,,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"000000..\";s:7:\"sRelays\";s:16:\"............0000\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','2');
INSERT INTO `rlb_reboot_history` VALUES ('147','a:5:{s:9:\"sResponse\";s:127:\"S,065,0,0,23:59:23,3,02,000.000.,......00......00,00000000,0,0,0,0,12500,88.5F,77.8F,77.6F,77.8F,77.0F,77.6F,17.36,000000,17.34\";s:7:\"sValves\";s:8:\"000.000.\";s:7:\"sRelays\";s:16:\"......00......00\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','1');
INSERT INTO `rlb_reboot_history` VALUES ('148','a:5:{s:9:\"sResponse\";s:100:\"S,171,0,7,19:17:46,3,06,000000..,............0000,00000000,0,0,0,0,12515,88.7F,,,,,,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"000000..\";s:7:\"sRelays\";s:16:\"............0000\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','2');
INSERT INTO `rlb_reboot_history` VALUES ('149','a:5:{s:9:\"sResponse\";s:127:\"S,193,0,0,23:59:27,3,02,000.002.,......00......00,00000000,0,0,0,0,12500,88.9F,74.8F,74.3F,83.6F,77.0F,74.9F,17.47,000000,17.45\";s:7:\"sValves\";s:8:\"000.002.\";s:7:\"sRelays\";s:16:\"......00......00\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:1:{i:0;s:1:\"1\";}}','1');
INSERT INTO `rlb_reboot_history` VALUES ('150','a:5:{s:9:\"sResponse\";s:100:\"S,167,0,1,19:17:32,3,06,222200..,............0000,00000000,0,0,0,0,12531,86.2F,,,,,,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"222200..\";s:7:\"sRelays\";s:16:\"............0000\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','2');
INSERT INTO `rlb_reboot_history` VALUES ('151','a:5:{s:9:\"sResponse\";s:127:\"S,089,0,0,23:59:18,3,02,000.000.,......00......00,00000000,0,0,0,0,12500,89.8F,71.9F,70.4F,72.6F,69.8F,74.2F,17.46,000000,17.43\";s:7:\"sValves\";s:8:\"000.000.\";s:7:\"sRelays\";s:16:\"......00......00\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','1');
INSERT INTO `rlb_reboot_history` VALUES ('152','a:5:{s:9:\"sResponse\";s:100:\"S,063,0,2,19:17:17,3,06,000000..,............0000,00000000,0,0,0,0,12531,88.9F,,,,,,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"000000..\";s:7:\"sRelays\";s:16:\"............0000\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','2');
INSERT INTO `rlb_reboot_history` VALUES ('153','a:5:{s:9:\"sResponse\";s:127:\"S,078,0,0,23:59:26,3,02,000.000.,......00......00,00000000,0,0,0,0,12500,91.3F,75.1F,74.6F,75.2F,74.3F,75.8F,17.45,000000,17.42\";s:7:\"sValves\";s:8:\"000.000.\";s:7:\"sRelays\";s:16:\"......00......00\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','1');
INSERT INTO `rlb_reboot_history` VALUES ('154','a:5:{s:9:\"sResponse\";s:100:\"S,026,0,3,19:17:01,3,06,000000..,............0000,00000000,0,0,0,0,12531,91.1F,,,,,,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"000000..\";s:7:\"sRelays\";s:16:\"............0000\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','2');
INSERT INTO `rlb_reboot_history` VALUES ('155','a:5:{s:9:\"sResponse\";s:127:\"S,006,0,0,23:59:28,3,02,000.000.,......00......00,00000000,0,0,0,0,12500,96.5F,78.9F,79.0F,77.9F,78.8F,78.6F,17.52,000000,17.48\";s:7:\"sValves\";s:8:\"000.000.\";s:7:\"sRelays\";s:16:\"......00......00\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','1');
INSERT INTO `rlb_reboot_history` VALUES ('156','a:5:{s:9:\"sResponse\";s:100:\"S,124,0,4,19:16:46,3,06,000000..,............0000,00000000,0,0,0,0,12515,90.8F,,,,,,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"000000..\";s:7:\"sRelays\";s:16:\"............0000\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','2');
INSERT INTO `rlb_reboot_history` VALUES ('157','a:5:{s:9:\"sResponse\";s:127:\"S,149,0,0,23:59:26,3,02,000.000.,......00......00,00000000,0,0,0,0,12500,97.9F,78.5F,78.1F,77.6F,77.9F,78.8F,17.21,000000,17.20\";s:7:\"sValves\";s:8:\"000.000.\";s:7:\"sRelays\";s:16:\"......00......00\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','1');
INSERT INTO `rlb_reboot_history` VALUES ('158','a:5:{s:9:\"sResponse\";s:100:\"S,005,0,5,19:16:28,3,06,000000..,............0000,00000000,0,0,0,0,12515,94.3F,,,,,,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"000000..\";s:7:\"sRelays\";s:16:\"............0000\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','2');
INSERT INTO `rlb_reboot_history` VALUES ('159','a:5:{s:9:\"sResponse\";s:127:\"S,109,0,0,23:59:27,3,02,000.000.,......00......01,10000000,0,0,0,0,12500,87.2F,77.8F,77.3F,93.3F,83.3F,79.5F,16.43,000000,16.37\";s:7:\"sValves\";s:8:\"000.000.\";s:7:\"sRelays\";s:16:\"......00......01\";s:12:\"sPowercenter\";s:8:\"10000000\";s:5:\"sPump\";a:2:{i:0;s:1:\"1\";i:1;s:1:\"2\";}}','1');
INSERT INTO `rlb_reboot_history` VALUES ('160','a:5:{s:9:\"sResponse\";s:100:\"S,077,0,6,19:16:11,3,06,000000..,............0000,00000000,0,0,0,0,12515,90.5F,,,,,,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"000000..\";s:7:\"sRelays\";s:16:\"............0000\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','2');
INSERT INTO `rlb_reboot_history` VALUES ('161','a:5:{s:9:\"sResponse\";s:127:\"S,214,0,0,23:59:32,3,02,000.000.,......00......00,00000000,0,0,0,0,12500,88.7F,82.6F,82.9F,81.2F,82.4F,83.8F,16.51,000000,16.49\";s:7:\"sValves\";s:8:\"000.000.\";s:7:\"sRelays\";s:16:\"......00......00\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','1');
INSERT INTO `rlb_reboot_history` VALUES ('162','a:5:{s:9:\"sResponse\";s:100:\"S,033,0,7,19:15:54,3,06,000000..,............0000,00000000,0,0,0,0,12531,93.0F,,,,,,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"000000..\";s:7:\"sRelays\";s:16:\"............0000\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','2');
INSERT INTO `rlb_reboot_history` VALUES ('163','a:5:{s:9:\"sResponse\";s:127:\"S,094,0,0,23:59:28,3,02,000.000.,......00......00,00000000,0,0,0,0,12500,84.9F,78.0F,77.5F,78.5F,77.0F,78.4F,16.72,000000,16.70\";s:7:\"sValves\";s:8:\"000.000.\";s:7:\"sRelays\";s:16:\"......00......00\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','1');
INSERT INTO `rlb_reboot_history` VALUES ('164','a:5:{s:9:\"sResponse\";s:100:\"S,248,0,1,19:15:38,3,06,000000..,............0000,00000000,0,0,0,0,12531,88.6F,,,,,,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"000000..\";s:7:\"sRelays\";s:16:\"............0000\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','2');
INSERT INTO `rlb_reboot_history` VALUES ('165','a:5:{s:9:\"sResponse\";s:127:\"S,105,0,0,23:59:25,3,02,000.000.,......00......00,00000000,0,0,0,0,12500,82.0F,76.0F,75.3F,75.9F,75.2F,76.1F,16.97,000000,16.95\";s:7:\"sValves\";s:8:\"000.000.\";s:7:\"sRelays\";s:16:\"......00......00\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','1');
INSERT INTO `rlb_reboot_history` VALUES ('166','a:5:{s:9:\"sResponse\";s:100:\"S,058,0,2,19:15:22,3,06,000000..,............0000,00000000,0,0,0,0,12531,86.0F,,,,,,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"000000..\";s:7:\"sRelays\";s:16:\"............0000\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','2');
INSERT INTO `rlb_reboot_history` VALUES ('167','a:5:{s:9:\"sResponse\";s:127:\"S,185,0,0,23:59:30,3,02,000.000.,......00......00,00000000,0,0,0,0,12515,73.2F,67.8F,65.9F,68.3F,65.3F,68.7F,17.21,000000,17.20\";s:7:\"sValves\";s:8:\"000.000.\";s:7:\"sRelays\";s:16:\"......00......00\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','1');
INSERT INTO `rlb_reboot_history` VALUES ('168','a:5:{s:9:\"sResponse\";s:100:\"S,151,0,3,19:15:09,3,06,000000..,............0000,00000000,0,0,0,0,12531,76.8F,,,,,,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"000000..\";s:7:\"sRelays\";s:16:\"............0000\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','2');
INSERT INTO `rlb_reboot_history` VALUES ('169','a:5:{s:9:\"sResponse\";s:127:\"S,102,0,0,23:59:26,3,02,000.000.,......00......00,00000000,0,0,0,0,12500,75.2F,68.5F,66.9F,69.4F,66.2F,69.1F,17.08,000000,17.07\";s:7:\"sValves\";s:8:\"000.000.\";s:7:\"sRelays\";s:16:\"......00......00\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','1');
INSERT INTO `rlb_reboot_history` VALUES ('170','a:5:{s:9:\"sResponse\";s:100:\"S,095,0,4,19:14:56,3,06,000000..,............0000,00000000,0,0,0,0,12546,78.5F,,,,,,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"000000..\";s:7:\"sRelays\";s:16:\"............0000\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','2');
INSERT INTO `rlb_reboot_history` VALUES ('171','a:5:{s:9:\"sResponse\";s:127:\"S,062,0,0,23:59:31,3,02,000.000.,......00......00,00000000,0,0,0,0,12500,76.6F,68.8F,66.9F,69.7F,66.2F,69.7F,17.23,000000,17.23\";s:7:\"sValves\";s:8:\"000.000.\";s:7:\"sRelays\";s:16:\"......00......00\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','1');
INSERT INTO `rlb_reboot_history` VALUES ('172','a:5:{s:9:\"sResponse\";s:100:\"S,160,0,5,19:14:43,3,06,000000..,............0000,00000000,0,0,0,0,12546,80.0F,,,,,,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"000000..\";s:7:\"sRelays\";s:16:\"............0000\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','2');
INSERT INTO `rlb_reboot_history` VALUES ('173','a:5:{s:9:\"sResponse\";s:127:\"S,023,0,0,23:59:26,3,02,000.000.,......00......00,00000000,0,0,0,0,12500,77.9F,70.0F,68.0F,70.5F,67.1F,71.0F,17.31,000000,17.27\";s:7:\"sValves\";s:8:\"000.000.\";s:7:\"sRelays\";s:16:\"......00......00\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','1');
INSERT INTO `rlb_reboot_history` VALUES ('174','a:5:{s:9:\"sResponse\";s:100:\"S,038,0,6,19:14:29,3,06,000000..,............0000,00000000,0,0,0,0,12531,81.6F,,,,,,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"000000..\";s:7:\"sRelays\";s:16:\"............0000\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','2');
INSERT INTO `rlb_reboot_history` VALUES ('175','a:5:{s:9:\"sResponse\";s:127:\"S,229,0,0,23:59:28,3,02,000.000.,......00......00,00000000,0,0,0,0,12500,79.0F,71.8F,70.9F,71.7F,69.8F,71.2F,17.35,000000,17.34\";s:7:\"sValves\";s:8:\"000.000.\";s:7:\"sRelays\";s:16:\"......00......00\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','1');
INSERT INTO `rlb_reboot_history` VALUES ('176','a:5:{s:9:\"sResponse\";s:100:\"S,103,0,7,19:14:16,3,06,000000..,............0000,00000000,0,0,0,0,12531,82.7F,,,,,,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"000000..\";s:7:\"sRelays\";s:16:\"............0000\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','2');
INSERT INTO `rlb_reboot_history` VALUES ('177','a:5:{s:9:\"sResponse\";s:127:\"S,163,0,0,23:59:32,3,02,000.000.,......00......00,00000000,0,0,0,0,12500,81.6F,73.0F,72.6F,72.8F,71.6F,74.6F,17.49,000000,17.43\";s:7:\"sValves\";s:8:\"000.000.\";s:7:\"sRelays\";s:16:\"......00......00\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','1');
INSERT INTO `rlb_reboot_history` VALUES ('178','a:5:{s:9:\"sResponse\";s:100:\"S,100,0,1,19:14:01,3,06,000000..,............0000,00000000,0,0,0,0,12531,85.2F,,,,,,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"000000..\";s:7:\"sRelays\";s:16:\"............0000\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','2');
INSERT INTO `rlb_reboot_history` VALUES ('179','a:5:{s:9:\"sResponse\";s:127:\"S,122,0,0,23:59:28,3,02,000.000.,......00......00,00000000,0,0,0,0,12500,88.6F,81.7F,81.7F,79.9F,81.5F,81.6F,17.10,000000,17.09\";s:7:\"sValves\";s:8:\"000.000.\";s:7:\"sRelays\";s:16:\"......00......00\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','1');
INSERT INTO `rlb_reboot_history` VALUES ('180','a:5:{s:9:\"sResponse\";s:100:\"S,004,0,2,19:13:46,3,06,000000..,............0000,00000000,0,0,0,0,12531,92.6F,,,,,,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"000000..\";s:7:\"sRelays\";s:16:\"............0000\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','2');
INSERT INTO `rlb_reboot_history` VALUES ('181','a:5:{s:9:\"sResponse\";s:127:\"S,077,0,0,23:59:23,3,02,000.000.,......00......00,00000000,0,0,0,0,12484,79.4F,72.1F,70.3F,77.5F,69.8F,71.9F,15.48,000000,15.45\";s:7:\"sValves\";s:8:\"000.000.\";s:7:\"sRelays\";s:16:\"......00......00\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','1');
INSERT INTO `rlb_reboot_history` VALUES ('182','a:5:{s:9:\"sResponse\";s:100:\"S,172,0,3,19:13:31,3,06,000000..,............0000,00000000,0,0,0,0,12515,82.9F,,,,,,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"000000..\";s:7:\"sRelays\";s:16:\"............0000\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','2');
INSERT INTO `rlb_reboot_history` VALUES ('183','a:5:{s:9:\"sResponse\";s:127:\"S,194,0,0,23:59:38,3,02,000.000.,......00......00,00000000,0,0,0,0,12484,81.1F,73.7F,72.4F,91.0F,77.0F,75.1F,15.49,000000,15.44\";s:7:\"sValves\";s:8:\"000.000.\";s:7:\"sRelays\";s:16:\"......00......00\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','1');
INSERT INTO `rlb_reboot_history` VALUES ('184','a:5:{s:9:\"sResponse\";s:100:\"S,118,0,4,19:13:18,3,06,000000..,............0000,00000000,0,0,0,0,12500,84.7F,,,,,,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"000000..\";s:7:\"sRelays\";s:16:\"............0000\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','2');
INSERT INTO `rlb_reboot_history` VALUES ('185','a:5:{s:9:\"sResponse\";s:127:\"S,190,0,0,23:59:36,3,02,000.000.,......00......00,00000000,0,0,0,0,12515,72.1F,66.7F,65.4F,66.7F,64.4F,66.5F,15.42,000000,15.37\";s:7:\"sValves\";s:8:\"000.000.\";s:7:\"sRelays\";s:16:\"......00......00\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','1');
INSERT INTO `rlb_reboot_history` VALUES ('186','a:5:{s:9:\"sResponse\";s:100:\"S,213,0,5,19:13:06,3,06,000000..,............0000,00000000,0,0,0,0,12546,75.5F,,,,,,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"000000..\";s:7:\"sRelays\";s:16:\"............0000\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','2');
INSERT INTO `rlb_reboot_history` VALUES ('187','a:5:{s:9:\"sResponse\";s:127:\"S,127,0,0,23:59:37,3,02,100.000.,......00......00,00000000,0,0,0,0,12500,73.6F,67.0F,66.1F,76.8F,74.3F,67.0F,15.46,000000,15.46\";s:7:\"sValves\";s:8:\"100.000.\";s:7:\"sRelays\";s:16:\"......00......00\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','1');
INSERT INTO `rlb_reboot_history` VALUES ('188','a:5:{s:9:\"sResponse\";s:100:\"S,013,0,6,19:12:55,3,06,000000..,............0000,00000000,0,0,0,0,12531,76.6F,,,,,,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"000000..\";s:7:\"sRelays\";s:16:\"............0000\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','2');
INSERT INTO `rlb_reboot_history` VALUES ('189','a:5:{s:9:\"sResponse\";s:127:\"S,045,0,0,23:59:36,3,02,000.000.,......00......00,00000000,0,0,0,0,12515,78.2F,72.3F,72.4F,84.0F,75.2F,72.1F,15.30,000000,15.28\";s:7:\"sValves\";s:8:\"000.000.\";s:7:\"sRelays\";s:16:\"......00......00\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','1');
INSERT INTO `rlb_reboot_history` VALUES ('190','a:5:{s:9:\"sResponse\";s:100:\"S,186,0,7,19:12:43,3,06,000000..,............0000,00000000,0,0,0,0,12531,81.5F,,,,,,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"000000..\";s:7:\"sRelays\";s:16:\"............0000\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','2');
INSERT INTO `rlb_reboot_history` VALUES ('191','a:5:{s:9:\"sResponse\";s:127:\"S,052,0,0,23:59:34,3,02,000.000.,......00......00,00000000,0,0,0,0,12500,76.8F,69.5F,68.5F,69.2F,72.5F,69.8F,15.41,000000,15.36\";s:7:\"sValves\";s:8:\"000.000.\";s:7:\"sRelays\";s:16:\"......00......00\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','1');
INSERT INTO `rlb_reboot_history` VALUES ('192','a:5:{s:9:\"sResponse\";s:100:\"S,253,0,1,19:12:30,3,06,000000..,............0000,00000000,0,0,0,0,12546,80.4F,,,,,,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"000000..\";s:7:\"sRelays\";s:16:\"............0000\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','2');
INSERT INTO `rlb_reboot_history` VALUES ('193','a:5:{s:9:\"sResponse\";s:127:\"S,069,0,0,23:59:26,3,02,000.000.,......00......00,00000000,0,0,0,0,12500,87.5F,69.0F,67.8F,68.8F,71.6F,70.4F,15.42,000000,15.37\";s:7:\"sValves\";s:8:\"000.000.\";s:7:\"sRelays\";s:16:\"......00......00\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','1');
INSERT INTO `rlb_reboot_history` VALUES ('194','a:5:{s:9:\"sResponse\";s:100:\"S,069,0,2,19:12:17,3,06,000000..,............0000,00000000,0,0,0,0,12531,85.2F,,,,,,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"000000..\";s:7:\"sRelays\";s:16:\"............0000\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','2');
INSERT INTO `rlb_reboot_history` VALUES ('195','a:5:{s:9:\"sResponse\";s:127:\"S,189,0,0,23:59:27,3,02,000.000.,......00......00,00000000,0,0,0,0,12500,89.8F,71.3F,70.1F,70.9F,72.5F,72.6F,15.48,000000,15.44\";s:7:\"sValves\";s:8:\"000.000.\";s:7:\"sRelays\";s:16:\"......00......00\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','1');
INSERT INTO `rlb_reboot_history` VALUES ('196','a:5:{s:9:\"sResponse\";s:100:\"S,155,0,3,19:12:01,3,06,000000..,............0000,00000000,0,0,0,0,12531,88.5F,,,,,,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"000000..\";s:7:\"sRelays\";s:16:\"............0000\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','2');
INSERT INTO `rlb_reboot_history` VALUES ('197','a:5:{s:9:\"sResponse\";s:127:\"S,196,0,0,23:59:29,3,02,000.000.,......00......00,00000000,0,0,0,0,12484,90.4F,70.4F,69.8F,70.4F,71.6F,73.4F,15.56,000000,15.51\";s:7:\"sValves\";s:8:\"000.000.\";s:7:\"sRelays\";s:16:\"......00......00\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','1');
INSERT INTO `rlb_reboot_history` VALUES ('198','a:5:{s:9:\"sResponse\";s:100:\"S,220,0,4,19:11:46,3,06,000000..,............0000,00000000,0,0,0,0,12515,87.0F,,,,,,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"000000..\";s:7:\"sRelays\";s:16:\"............0000\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','2');
INSERT INTO `rlb_reboot_history` VALUES ('199','a:5:{s:9:\"sResponse\";s:127:\"S,174,0,0,23:59:30,3,02,000.000.,......00......00,00000000,0,0,0,0,12500,92.4F,73.7F,73.0F,74.0F,72.5F,75.5F,16.65,000000,16.65\";s:7:\"sValves\";s:8:\"000.000.\";s:7:\"sRelays\";s:16:\"......00......00\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','1');
INSERT INTO `rlb_reboot_history` VALUES ('200','a:5:{s:9:\"sResponse\";s:100:\"S,020,0,5,19:11:31,3,06,000000..,............0000,00000000,0,0,0,0,12531,89.2F,,,,,,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"000000..\";s:7:\"sRelays\";s:16:\"............0000\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','2');
INSERT INTO `rlb_reboot_history` VALUES ('201','a:5:{s:9:\"sResponse\";s:127:\"S,017,0,0,23:59:32,3,02,000.000.,......00......00,00000000,0,0,0,0,12500,94.9F,76.8F,76.7F,76.6F,77.9F,77.0F,16.08,000000,16.02\";s:7:\"sValves\";s:8:\"000.000.\";s:7:\"sRelays\";s:16:\"......00......00\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','1');
INSERT INTO `rlb_reboot_history` VALUES ('202','a:5:{s:9:\"sResponse\";s:100:\"S,167,0,6,19:11:16,3,06,000000..,............0000,00000000,0,0,0,0,12531,88.5F,,,,,,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"000000..\";s:7:\"sRelays\";s:16:\"............0000\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','2');
INSERT INTO `rlb_reboot_history` VALUES ('203','a:5:{s:9:\"sResponse\";s:127:\"S,245,0,0,23:59:28,3,02,000.000.,......00......00,00000000,0,0,0,0,12500,91.3F,74.8F,74.0F,79.3F,73.4F,75.0F,16.06,000000,16.05\";s:7:\"sValves\";s:8:\"000.000.\";s:7:\"sRelays\";s:16:\"......00......00\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','1');
INSERT INTO `rlb_reboot_history` VALUES ('204','a:5:{s:9:\"sResponse\";s:100:\"S,143,0,7,19:11:00,3,06,000000..,............0000,00000000,0,0,0,0,12515,85.7F,,,,,,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"000000..\";s:7:\"sRelays\";s:16:\"............0000\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','2');
INSERT INTO `rlb_reboot_history` VALUES ('205','a:5:{s:9:\"sResponse\";s:127:\"S,149,0,0,23:59:28,3,02,000.000.,......00......00,00000000,0,0,0,0,12500,77.1F,66.4F,64.7F,71.6F,74.3F,67.0F,16.24,000000,16.22\";s:7:\"sValves\";s:8:\"000.000.\";s:7:\"sRelays\";s:16:\"......00......00\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','1');
INSERT INTO `rlb_reboot_history` VALUES ('206','a:5:{s:9:\"sResponse\";s:100:\"S,219,0,1,19:10:47,3,06,000000..,............0000,00000000,0,0,0,0,12531,77.2F,,,,,,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"000000..\";s:7:\"sRelays\";s:16:\"............0000\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','2');
INSERT INTO `rlb_reboot_history` VALUES ('207','a:5:{s:9:\"sResponse\";s:127:\"S,048,0,0,23:59:31,3,02,000.000.,......00......00,00000000,0,0,0,0,12515,77.1F,63.1F,61.6F,63.1F,70.7F,65.0F,16.41,000000,16.35\";s:7:\"sValves\";s:8:\"000.000.\";s:7:\"sRelays\";s:16:\"......00......00\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','1');
INSERT INTO `rlb_reboot_history` VALUES ('208','a:5:{s:9:\"sResponse\";s:100:\"S,028,0,2,19:10:37,3,06,000000..,............0000,00000000,0,0,0,0,12546,77.2F,,,,,,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"000000..\";s:7:\"sRelays\";s:16:\"............0000\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','2');
INSERT INTO `rlb_reboot_history` VALUES ('209','a:5:{s:9:\"sResponse\";s:127:\"S,065,0,0,23:59:31,3,02,000.000.,......00......00,00000000,0,0,0,0,12500,82.1F,64.5F,63.6F,64.5F,62.6F,66.1F,16.37,000000,16.36\";s:7:\"sValves\";s:8:\"000.000.\";s:7:\"sRelays\";s:16:\"......00......00\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','1');
INSERT INTO `rlb_reboot_history` VALUES ('210','a:5:{s:9:\"sResponse\";s:100:\"S,165,0,3,19:10:26,3,06,000000..,............0000,00000000,0,0,0,0,12546,76.8F,,,,,,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"000000..\";s:7:\"sRelays\";s:16:\"............0000\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','2');
INSERT INTO `rlb_reboot_history` VALUES ('211','a:5:{s:9:\"sResponse\";s:127:\"S,174,0,0,23:59:35,3,02,000.000.,......00......00,00000000,0,0,0,0,12515,81.7F,63.6F,62.0F,63.6F,61.7F,65.9F,16.48,000000,16.43\";s:7:\"sValves\";s:8:\"000.000.\";s:7:\"sRelays\";s:16:\"......00......00\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','1');
INSERT INTO `rlb_reboot_history` VALUES ('212','a:5:{s:9:\"sResponse\";s:100:\"S,249,0,4,19:10:16,3,06,000000..,............0000,00000000,0,0,0,0,12546,77.9F,,,,,,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"000000..\";s:7:\"sRelays\";s:16:\"............0000\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','2');
INSERT INTO `rlb_reboot_history` VALUES ('213','a:5:{s:9:\"sResponse\";s:127:\"S,230,0,0,23:59:31,3,02,000.000.,......00......00,00000000,0,0,0,0,12500,77.5F,59.6F,56.8F,60.4F,56.3F,63.1F,16.60,000000,16.56\";s:7:\"sValves\";s:8:\"000.000.\";s:7:\"sRelays\";s:16:\"......00......00\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','1');
INSERT INTO `rlb_reboot_history` VALUES ('214','a:5:{s:9:\"sResponse\";s:100:\"S,093,0,5,19:10:05,3,06,000000..,............0000,00000000,0,0,0,0,12546,74.5F,,,,,,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"000000..\";s:7:\"sRelays\";s:16:\"............0000\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','2');
INSERT INTO `rlb_reboot_history` VALUES ('215','a:5:{s:9:\"sResponse\";s:127:\"S,246,0,0,23:59:28,3,02,000.000.,......00......00,00000000,0,0,0,0,12500,82.7F,65.3F,63.4F,69.6F,70.7F,66.0F,18.26,000000,18.24\";s:7:\"sValves\";s:8:\"000.000.\";s:7:\"sRelays\";s:16:\"......00......00\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','1');
INSERT INTO `rlb_reboot_history` VALUES ('216','a:5:{s:9:\"sResponse\";s:100:\"S,175,0,6,19:09:53,3,06,000000..,............0000,00000000,0,0,0,0,12531,80.2F,,,,,,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"000000..\";s:7:\"sRelays\";s:16:\"............0000\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','2');
INSERT INTO `rlb_reboot_history` VALUES ('217','a:5:{s:9:\"sResponse\";s:127:\"S,022,0,0,23:59:30,3,02,000.000.,......00......00,00000000,0,0,0,0,12500,84.1F,65.5F,64.2F,65.5F,63.5F,67.2F,18.30,000000,18.27\";s:7:\"sValves\";s:8:\"000.000.\";s:7:\"sRelays\";s:16:\"......00......00\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','1');
INSERT INTO `rlb_reboot_history` VALUES ('218','a:5:{s:9:\"sResponse\";s:100:\"S,229,0,7,19:09:41,3,06,000000..,............0000,00000000,0,0,0,0,12531,81.6F,,,,,,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"000000..\";s:7:\"sRelays\";s:16:\"............0000\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','2');
INSERT INTO `rlb_reboot_history` VALUES ('219','a:5:{s:9:\"sResponse\";s:127:\"S,169,0,0,23:59:28,3,02,000.000.,......00......00,00000000,0,0,0,0,12500,87.9F,72.3F,71.9F,75.4F,77.9F,71.5F,15.73,000000,15.71\";s:7:\"sValves\";s:8:\"000.000.\";s:7:\"sRelays\";s:16:\"......00......00\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','1');
INSERT INTO `rlb_reboot_history` VALUES ('220','a:5:{s:9:\"sResponse\";s:100:\"S,063,0,1,19:09:27,3,06,000000..,............0000,00000000,0,0,0,0,12531,88.0F,,,,,,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"000000..\";s:7:\"sRelays\";s:16:\"............0000\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','2');
INSERT INTO `rlb_reboot_history` VALUES ('221','a:5:{s:9:\"sResponse\";s:127:\"S,105,0,0,23:59:29,3,02,000.000.,......00......00,00000000,0,0,0,0,12500,81.6F,75.1F,75.0F,78.5F,82.4F,76.1F,15.80,000000,15.79\";s:7:\"sValves\";s:8:\"000.000.\";s:7:\"sRelays\";s:16:\"......00......00\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','1');
INSERT INTO `rlb_reboot_history` VALUES ('222','a:5:{s:9:\"sResponse\";s:100:\"S,233,0,2,19:09:12,3,06,000000..,............0000,00000000,0,0,0,0,12531,85.3F,,,,,,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"000000..\";s:7:\"sRelays\";s:16:\"............0000\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','2');
INSERT INTO `rlb_reboot_history` VALUES ('223','a:5:{s:9:\"sResponse\";s:127:\"S,060,0,0,23:59:30,3,02,000.000.,......00......00,00000000,0,0,0,0,12500,76.2F,68.7F,67.4F,69.5F,76.1F,69.2F,15.86,000000,15.84\";s:7:\"sValves\";s:8:\"000.000.\";s:7:\"sRelays\";s:16:\"......00......00\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','1');
INSERT INTO `rlb_reboot_history` VALUES ('224','a:5:{s:9:\"sResponse\";s:100:\"S,034,0,3,19:08:59,3,06,000000..,............0000,00000000,0,0,0,0,12546,79.8F,,,,,,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"000000..\";s:7:\"sRelays\";s:16:\"............0000\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','2');
INSERT INTO `rlb_reboot_history` VALUES ('225','a:5:{s:9:\"sResponse\";s:127:\"S,144,0,0,05:39:50,3,02,000.000.,......00......00,00000000,0,0,0,0,12500,74.4F,68.3F,66.9F,68.1F,71.6F,67.3F,15.96,000000,15.95\";s:7:\"sValves\";s:8:\"000.000.\";s:7:\"sRelays\";s:16:\"......00......00\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','1');
INSERT INTO `rlb_reboot_history` VALUES ('226','a:5:{s:9:\"sResponse\";s:100:\"S,000,0,0,08:30:58,3,06,000000..,............0000,00000000,0,0,0,0,12546,78.2F,,,,,,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"000000..\";s:7:\"sRelays\";s:16:\"............0000\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','2');
INSERT INTO `rlb_reboot_history` VALUES ('227','a:5:{s:9:\"sResponse\";s:127:\"S,089,0,0,23:59:31,3,02,000.000.,......00......00,01000000,0,0,0,0,12500,81.3F,74.6F,75.1F,80.3F,76.1F,74.2F,16.10,000000,16.04\";s:7:\"sValves\";s:8:\"000.000.\";s:7:\"sRelays\";s:16:\"......00......00\";s:12:\"sPowercenter\";s:8:\"01000000\";s:5:\"sPump\";a:1:{i:0;s:1:\"1\";}}','1');
INSERT INTO `rlb_reboot_history` VALUES ('228','a:5:{s:9:\"sResponse\";s:100:\"S,091,0,1,08:30:45,3,06,000000..,............0000,00000000,0,0,0,0,12531,84.8F,,,,,,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"000000..\";s:7:\"sRelays\";s:16:\"............0000\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','2');
INSERT INTO `rlb_reboot_history` VALUES ('229','a:5:{s:9:\"sResponse\";s:127:\"S,031,0,0,23:59:31,3,02,000.000.,......00......00,01000000,0,0,0,0,12500,83.4F,77.8F,78.0F,76.6F,77.9F,77.6F,15.30,000000,15.27\";s:7:\"sValves\";s:8:\"000.000.\";s:7:\"sRelays\";s:16:\"......00......00\";s:12:\"sPowercenter\";s:8:\"01000000\";s:5:\"sPump\";a:0:{}}','1');
INSERT INTO `rlb_reboot_history` VALUES ('230','a:5:{s:9:\"sResponse\";s:100:\"S,160,0,2,08:30:31,3,06,000000..,............0000,00000000,0,0,0,0,12531,87.6F,,,,,,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"000000..\";s:7:\"sRelays\";s:16:\"............0000\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','2');
INSERT INTO `rlb_reboot_history` VALUES ('231','a:5:{s:9:\"sResponse\";s:127:\"S,053,0,0,13:05:23,3,02,000.000.,......00......00,00000000,0,0,0,0,12500,78.4F,72.5F,72.5F,72.5F,71.6F,72.5F,15.39,000000,15.37\";s:7:\"sValves\";s:8:\"000.000.\";s:7:\"sRelays\";s:16:\"......00......00\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','1');
INSERT INTO `rlb_reboot_history` VALUES ('232','a:5:{s:9:\"sResponse\";s:100:\"S,017,0,0,13:25:32,3,06,000000..,............0000,00000000,0,0,0,0,12531,82.7F,,,,,,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"000000..\";s:7:\"sRelays\";s:16:\"............0000\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','2');
INSERT INTO `rlb_reboot_history` VALUES ('233','a:5:{s:9:\"sResponse\";s:127:\"S,118,0,3,23:59:31,3,02,000.000.,......00......00,00000000,0,0,0,0,12484,78.8F,64.9F,64.6F,68.7F,68.9F,66.4F,17.52,000000,17.51\";s:7:\"sValves\";s:8:\"000.000.\";s:7:\"sRelays\";s:16:\"......00......00\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','1');
INSERT INTO `rlb_reboot_history` VALUES ('234','a:5:{s:9:\"sResponse\";s:100:\"S,240,0,6,11:26:10,3,06,000000..,............0000,00000000,0,0,0,0,12515,79.5F,,,,,,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"000000..\";s:7:\"sRelays\";s:16:\"............0000\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','2');
INSERT INTO `rlb_reboot_history` VALUES ('235','a:5:{s:9:\"sResponse\";s:127:\"S,110,0,0,23:59:36,3,02,000.000.,......00......00,01000000,0,0,0,0,12484,81.5F,67.3F,67.6F,67.6F,79.7F,67.9F,16.44,000000,16.43\";s:7:\"sValves\";s:8:\"000.000.\";s:7:\"sRelays\";s:16:\"......00......00\";s:12:\"sPowercenter\";s:8:\"01000000\";s:5:\"sPump\";a:1:{i:0;s:1:\"1\";}}','1');
INSERT INTO `rlb_reboot_history` VALUES ('236','a:5:{s:9:\"sResponse\";s:100:\"S,078,0,7,11:25:58,3,06,000000..,............0000,00000000,0,0,0,0,12515,82.4F,,,,,,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"000000..\";s:7:\"sRelays\";s:16:\"............0000\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','2');
INSERT INTO `rlb_reboot_history` VALUES ('237','a:5:{s:9:\"sResponse\";s:127:\"S,012,0,0,23:59:38,3,02,000.000.,......00......00,01000000,0,0,0,0,12484,82.5F,68.2F,68.1F,69.5F,88.7F,67.9F,16.13,000000,16.13\";s:7:\"sValves\";s:8:\"000.000.\";s:7:\"sRelays\";s:16:\"......00......00\";s:12:\"sPowercenter\";s:8:\"01000000\";s:5:\"sPump\";a:1:{i:0;s:1:\"1\";}}','1');
INSERT INTO `rlb_reboot_history` VALUES ('238','a:5:{s:9:\"sResponse\";s:100:\"S,196,0,1,11:25:47,3,06,000000..,............0000,00000000,0,0,0,0,12515,81.3F,,,,,,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"000000..\";s:7:\"sRelays\";s:16:\"............0000\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','2');
INSERT INTO `rlb_reboot_history` VALUES ('239','a:5:{s:9:\"sResponse\";s:127:\"S,126,0,0,23:59:37,3,02,000.000.,......00......01,10000000,0,0,0,0,12500,85.2F,71.7F,70.9F,93.5F,83.3F,70.3F,16.13,000000,16.12\";s:7:\"sValves\";s:8:\"000.000.\";s:7:\"sRelays\";s:16:\"......00......01\";s:12:\"sPowercenter\";s:8:\"10000000\";s:5:\"sPump\";a:2:{i:0;s:1:\"1\";i:1;s:1:\"2\";}}','1');
INSERT INTO `rlb_reboot_history` VALUES ('240','a:5:{s:9:\"sResponse\";s:100:\"S,215,0,2,11:25:35,3,06,000000..,............0000,00000000,0,0,0,0,12515,85.8F,,,,,,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"000000..\";s:7:\"sRelays\";s:16:\"............0000\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','2');
INSERT INTO `rlb_reboot_history` VALUES ('241','a:5:{s:9:\"sResponse\";s:127:\"S,023,0,0,23:59:36,3,02,000.000.,......00......00,00000000,0,0,0,0,12500,78.5F,65.3F,64.4F,66.5F,84.2F,65.6F,16.14,000000,16.10\";s:7:\"sValves\";s:8:\"000.000.\";s:7:\"sRelays\";s:16:\"......00......00\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','1');
INSERT INTO `rlb_reboot_history` VALUES ('242','a:5:{s:9:\"sResponse\";s:100:\"S,104,0,3,11:25:23,3,06,000000..,............0000,00000000,0,0,0,0,12531,76.0F,,,,,,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"000000..\";s:7:\"sRelays\";s:16:\"............0000\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','2');
INSERT INTO `rlb_reboot_history` VALUES ('243','a:5:{s:9:\"sResponse\";s:127:\"S,157,0,0,23:59:34,3,02,000.000.,......00......01,10000000,0,0,0,0,12484,75.2F,62.7F,61.6F,90.2F,73.4F,64.6F,16.14,000000,16.11\";s:7:\"sValves\";s:8:\"000.000.\";s:7:\"sRelays\";s:16:\"......00......01\";s:12:\"sPowercenter\";s:8:\"10000000\";s:5:\"sPump\";a:2:{i:0;s:1:\"1\";i:1;s:1:\"2\";}}','1');
INSERT INTO `rlb_reboot_history` VALUES ('244','a:5:{s:9:\"sResponse\";s:100:\"S,192,0,4,11:25:15,3,06,000000..,............0000,00000000,0,0,0,0,12531,72.3F,,,,,,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"000000..\";s:7:\"sRelays\";s:16:\"............0000\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','2');
INSERT INTO `rlb_reboot_history` VALUES ('245','a:5:{s:9:\"sResponse\";s:127:\"S,061,0,0,23:59:34,3,02,000.000.,......00......00,00000000,0,0,0,0,12500,75.0F,61.6F,60.2F,63.6F,76.1F,62.0F,16.81,000000,16.79\";s:7:\"sValves\";s:8:\"000.000.\";s:7:\"sRelays\";s:16:\"......00......00\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','1');
INSERT INTO `rlb_reboot_history` VALUES ('246','a:5:{s:9:\"sResponse\";s:100:\"S,239,0,5,11:25:07,3,06,000000..,............0000,00000000,0,0,0,0,12531,73.0F,,,,,,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"000000..\";s:7:\"sRelays\";s:16:\"............0000\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','2');
INSERT INTO `rlb_reboot_history` VALUES ('247','a:5:{s:9:\"sResponse\";s:127:\"S,226,0,0,23:59:39,3,02,000.000.,......00......00,00000000,0,0,0,0,12500,76.6F,61.0F,59.6F,72.1F,71.6F,61.3F,16.92,000000,16.90\";s:7:\"sValves\";s:8:\"000.000.\";s:7:\"sRelays\";s:16:\"......00......00\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','1');
INSERT INTO `rlb_reboot_history` VALUES ('248','a:5:{s:9:\"sResponse\";s:100:\"S,252,0,6,11:25:00,3,06,000000..,............0000,00000000,0,0,0,0,12531,75.2F,,,,,,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"000000..\";s:7:\"sRelays\";s:16:\"............0000\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','2');
INSERT INTO `rlb_reboot_history` VALUES ('249','a:5:{s:9:\"sResponse\";s:127:\"S,025,0,0,23:59:35,3,02,000.000.,......00......00,00000000,0,0,0,0,12500,75.5F,60.5F,59.2F,62.2F,59.0F,61.6F,16.83,000000,16.78\";s:7:\"sValves\";s:8:\"000.000.\";s:7:\"sRelays\";s:16:\"......00......00\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','1');
INSERT INTO `rlb_reboot_history` VALUES ('250','a:5:{s:9:\"sResponse\";s:100:\"S,201,0,7,11:24:50,3,06,000000..,............0000,00000000,0,0,0,0,12531,76.3F,,,,,,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"000000..\";s:7:\"sRelays\";s:16:\"............0000\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','2');
INSERT INTO `rlb_reboot_history` VALUES ('251','a:5:{s:9:\"sResponse\";s:127:\"S,025,0,0,23:59:38,3,02,000.000.,......00......00,00000000,0,0,0,0,12500,76.7F,61.7F,61.1F,63.1F,68.9F,62.4F,16.81,000000,16.71\";s:7:\"sValves\";s:8:\"000.000.\";s:7:\"sRelays\";s:16:\"......00......00\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','1');
INSERT INTO `rlb_reboot_history` VALUES ('252','a:5:{s:9:\"sResponse\";s:100:\"S,203,0,1,11:24:40,3,06,000000..,............0000,00000000,0,0,0,0,12531,77.5F,,,,,,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"000000..\";s:7:\"sRelays\";s:16:\"............0000\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','2');
INSERT INTO `rlb_reboot_history` VALUES ('253','a:5:{s:9:\"sResponse\";s:127:\"S,197,0,1,00:59:36,3,02,000.000.,......00......11,10000000,0,0,0,0,12500,78.0F,59.5F,57.2F,63.4F,57.2F,62.4F,17.03,000000,16.97\";s:7:\"sValves\";s:8:\"000.000.\";s:7:\"sRelays\";s:16:\"......00......11\";s:12:\"sPowercenter\";s:8:\"10000000\";s:5:\"sPump\";a:0:{}}','1');
INSERT INTO `rlb_reboot_history` VALUES ('254','a:5:{s:9:\"sResponse\";s:100:\"S,080,0,0,06:51:26,3,06,000000..,............0000,00000000,0,0,0,0,12531,75.4F,,,,,,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"000000..\";s:7:\"sRelays\";s:16:\"............0000\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','2');
INSERT INTO `rlb_reboot_history` VALUES ('255','a:5:{s:9:\"sResponse\";s:127:\"S,091,0,0,23:59:37,3,02,000.000.,......00......00,00000000,0,0,0,0,12500,74.0F,59.1F,57.7F,61.0F,57.2F,60.9F,16.88,000000,16.86\";s:7:\"sValves\";s:8:\"000.000.\";s:7:\"sRelays\";s:16:\"......00......00\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','1');
INSERT INTO `rlb_reboot_history` VALUES ('256','a:5:{s:9:\"sResponse\";s:100:\"S,179,0,1,06:51:17,3,06,000000..,............0000,00000000,0,0,0,0,12546,74.4F,,,,,,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"000000..\";s:7:\"sRelays\";s:16:\"............0000\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','2');
INSERT INTO `rlb_reboot_history` VALUES ('257','a:5:{s:9:\"sResponse\";s:127:\"S,210,0,0,23:59:34,3,02,000.000.,......00......00,00000000,0,0,0,0,12500,75.9F,59.7F,58.6F,64.5F,65.3F,61.8F,16.95,000000,16.89\";s:7:\"sValves\";s:8:\"000.000.\";s:7:\"sRelays\";s:16:\"......00......00\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:1:{i:0;s:1:\"1\";}}','1');
INSERT INTO `rlb_reboot_history` VALUES ('258','a:5:{s:9:\"sResponse\";s:100:\"S,204,0,2,06:51:08,3,06,200000..,............0000,00000000,0,0,0,0,12531,75.2F,,,,,,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"200000..\";s:7:\"sRelays\";s:16:\"............0000\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','2');
INSERT INTO `rlb_reboot_history` VALUES ('259','a:5:{s:9:\"sResponse\";s:127:\"S,190,0,0,23:59:36,3,02,000.000.,......00......00,00000000,0,0,0,0,12500,75.4F,59.2F,58.3F,58.8F,57.2F,61.3F,16.97,000000,16.94\";s:7:\"sValves\";s:8:\"000.000.\";s:7:\"sRelays\";s:16:\"......00......00\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','1');
INSERT INTO `rlb_reboot_history` VALUES ('260','a:5:{s:9:\"sResponse\";s:100:\"S,095,0,3,06:50:58,3,06,000000..,............0000,00000000,0,0,0,0,12531,73.9F,,,,,,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"000000..\";s:7:\"sRelays\";s:16:\"............0000\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','2');
INSERT INTO `rlb_reboot_history` VALUES ('261','a:5:{s:9:\"sResponse\";s:127:\"S,177,0,0,23:59:38,3,02,000.000.,......00......00,00000000,0,0,0,0,12500,73.9F,58.1F,56.5F,55.3F,55.4F,60.4F,17.18,000000,17.12\";s:7:\"sValves\";s:8:\"000.000.\";s:7:\"sRelays\";s:16:\"......00......00\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','1');
INSERT INTO `rlb_reboot_history` VALUES ('262','a:5:{s:9:\"sResponse\";s:100:\"S,160,0,4,06:50:49,3,06,000000..,............0000,00000000,0,0,0,0,12531,73.3F,,,,,,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"000000..\";s:7:\"sRelays\";s:16:\"............0000\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','2');
INSERT INTO `rlb_reboot_history` VALUES ('263','a:5:{s:9:\"sResponse\";s:127:\"S,220,0,0,23:59:39,3,02,000.000.,......00......00,00000000,0,0,0,0,12500,72.1F,56.8F,54.6F,53.0F,53.6F,59.2F,17.07,000000,17.04\";s:7:\"sValves\";s:8:\"000.000.\";s:7:\"sRelays\";s:16:\"......00......00\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','1');
INSERT INTO `rlb_reboot_history` VALUES ('264','a:5:{s:9:\"sResponse\";s:100:\"S,226,0,5,06:50:40,3,06,000000..,............0000,00000000,0,0,0,0,12546,70.9F,,,,,,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"000000..\";s:7:\"sRelays\";s:16:\"............0000\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','2');
INSERT INTO `rlb_reboot_history` VALUES ('265','a:5:{s:9:\"sResponse\";s:127:\"S,138,0,0,23:59:34,3,02,000.000.,......00......00,00000000,0,0,0,0,12500,71.4F,55.6F,53.6F,56.0F,52.7F,58.4F,19.24,000000,19.17\";s:7:\"sValves\";s:8:\"000.000.\";s:7:\"sRelays\";s:16:\"......00......00\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','1');
INSERT INTO `rlb_reboot_history` VALUES ('266','a:5:{s:9:\"sResponse\";s:100:\"S,163,0,6,06:50:32,3,06,000000..,............0000,00000000,0,0,0,0,12531,70.9F,,,,,,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"000000..\";s:7:\"sRelays\";s:16:\"............0000\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','2');
INSERT INTO `rlb_reboot_history` VALUES ('267','a:5:{s:9:\"sResponse\";s:0:\"\";s:7:\"sValves\";s:0:\"\";s:7:\"sRelays\";s:0:\"\";s:12:\"sPowercenter\";s:0:\"\";s:5:\"sPump\";a:0:{}}','1');
INSERT INTO `rlb_reboot_history` VALUES ('268','a:5:{s:9:\"sResponse\";s:100:\"S,137,0,7,06:51:24,3,06,000000..,............0000,00000000,0,0,0,0,12531,71.5F,,,,,,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"000000..\";s:7:\"sRelays\";s:16:\"............0000\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','2');
INSERT INTO `rlb_reboot_history` VALUES ('269','a:5:{s:9:\"sResponse\";s:0:\"\";s:7:\"sValves\";s:0:\"\";s:7:\"sRelays\";s:0:\"\";s:12:\"sPowercenter\";s:0:\"\";s:5:\"sPump\";a:0:{}}','1');
INSERT INTO `rlb_reboot_history` VALUES ('270','a:5:{s:9:\"sResponse\";s:100:\"S,161,0,1,06:50:16,3,06,000000..,............0000,00000000,0,0,0,0,12531,71.4F,,,,,,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"000000..\";s:7:\"sRelays\";s:16:\"............0000\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','2');
INSERT INTO `rlb_reboot_history` VALUES ('271','a:5:{s:9:\"sResponse\";s:0:\"\";s:7:\"sValves\";s:0:\"\";s:7:\"sRelays\";s:0:\"\";s:12:\"sPowercenter\";s:0:\"\";s:5:\"sPump\";a:0:{}}','1');
INSERT INTO `rlb_reboot_history` VALUES ('272','a:5:{s:9:\"sResponse\";s:100:\"S,229,0,2,06:50:10,3,06,000000..,............0000,00000000,0,0,0,0,12546,68.6F,,,,,,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"000000..\";s:7:\"sRelays\";s:16:\"............0000\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','2');
INSERT INTO `rlb_reboot_history` VALUES ('273','a:5:{s:9:\"sResponse\";s:0:\"\";s:7:\"sValves\";s:0:\"\";s:7:\"sRelays\";s:0:\"\";s:12:\"sPowercenter\";s:0:\"\";s:5:\"sPump\";a:0:{}}','1');
INSERT INTO `rlb_reboot_history` VALUES ('274','a:5:{s:9:\"sResponse\";s:0:\"\";s:7:\"sValves\";s:0:\"\";s:7:\"sRelays\";s:0:\"\";s:12:\"sPowercenter\";s:0:\"\";s:5:\"sPump\";a:0:{}}','2');
INSERT INTO `rlb_reboot_history` VALUES ('275','a:5:{s:9:\"sResponse\";s:123:\"S,206,0,0,09:12:16,3,02,000.000.,......10......10,10000000,0,0,0,0,0,74.2F,53.5F,51.8F,50.9F,60.0F,54.6F,17.48,000000,17.45\";s:7:\"sValves\";s:8:\"000.000.\";s:7:\"sRelays\";s:16:\"......10......10\";s:12:\"sPowercenter\";s:8:\"10000000\";s:5:\"sPump\";a:3:{i:0;s:1:\"1\";i:1;s:1:\"2\";i:2;s:1:\"3\";}}','1');
INSERT INTO `rlb_reboot_history` VALUES ('276','a:5:{s:9:\"sResponse\";s:100:\"S,138,0,0,10:12:35,3,06,000000..,............0000,00000000,0,0,0,0,12546,65.6F,,,,,,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"000000..\";s:7:\"sRelays\";s:16:\"............0000\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','2');
INSERT INTO `rlb_reboot_history` VALUES ('277','a:5:{s:9:\"sResponse\";s:102:\"S,070,0,0,11:52:48,3,02,000.000.,......00......00,00000000,0,0,0,0,12546,59.0F,,,,,,17.88,000000,17.79\";s:7:\"sValves\";s:8:\"000.000.\";s:7:\"sRelays\";s:16:\"......00......00\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','1');
INSERT INTO `rlb_reboot_history` VALUES ('278','a:5:{s:9:\"sResponse\";s:100:\"S,065,0,0,11:51:30,3,06,000000..,............0000,00000000,0,0,0,0,12562,59.9F,,,,,,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"000000..\";s:7:\"sRelays\";s:16:\"............0000\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','2');
INSERT INTO `rlb_reboot_history` VALUES ('279','a:5:{s:9:\"sResponse\";s:102:\"S,200,0,1,00:02:13,3,02,000.000.,......00......00,00000000,0,0,0,0,12546,66.1F,,,,,,17.80,000000,17.77\";s:7:\"sValves\";s:8:\"000.000.\";s:7:\"sRelays\";s:16:\"......00......00\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','1');
INSERT INTO `rlb_reboot_history` VALUES ('280','a:5:{s:9:\"sResponse\";s:100:\"S,062,0,1,11:51:26,3,06,000000..,............0000,00000000,0,0,0,0,12546,66.9F,,,,,,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"000000..\";s:7:\"sRelays\";s:16:\"............0000\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','2');
INSERT INTO `rlb_reboot_history` VALUES ('281','a:5:{s:9:\"sResponse\";s:102:\"S,093,0,1,00:02:10,3,02,000.000.,......00......00,00000000,0,0,0,0,12531,69.8F,,,,,,18.06,000000,18.00\";s:7:\"sValves\";s:8:\"000.000.\";s:7:\"sRelays\";s:16:\"......00......00\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','1');
INSERT INTO `rlb_reboot_history` VALUES ('282','a:5:{s:9:\"sResponse\";s:100:\"S,127,0,2,11:51:22,3,06,000000..,............0000,00000000,0,0,0,0,12546,70.3F,,,,,,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"000000..\";s:7:\"sRelays\";s:16:\"............0000\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','2');
INSERT INTO `rlb_reboot_history` VALUES ('283','a:5:{s:9:\"sResponse\";s:102:\"S,055,0,1,00:02:13,3,02,000.000.,......00......00,00000000,0,0,0,0,12546,64.7F,,,,,,18.20,000000,18.14\";s:7:\"sValves\";s:8:\"000.000.\";s:7:\"sRelays\";s:16:\"......00......00\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','1');
INSERT INTO `rlb_reboot_history` VALUES ('284','a:5:{s:9:\"sResponse\";s:100:\"S,204,0,3,11:51:18,3,06,000000..,............0000,00000000,0,0,0,0,12546,64.0F,,,,,,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"000000..\";s:7:\"sRelays\";s:16:\"............0000\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','2');
INSERT INTO `rlb_reboot_history` VALUES ('285','a:5:{s:9:\"sResponse\";s:102:\"S,178,0,1,00:02:10,3,02,000.000.,......00......00,00000000,0,0,0,0,12531,62.5F,,,,,,18.18,000000,18.19\";s:7:\"sValves\";s:8:\"000.000.\";s:7:\"sRelays\";s:16:\"......00......00\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','1');
INSERT INTO `rlb_reboot_history` VALUES ('286','a:5:{s:9:\"sResponse\";s:100:\"S,013,0,4,11:51:15,3,06,000000..,............0000,00000000,0,0,0,0,12546,61.6F,,,,,,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"000000..\";s:7:\"sRelays\";s:16:\"............0000\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','2');
INSERT INTO `rlb_reboot_history` VALUES ('287','a:5:{s:9:\"sResponse\";s:102:\"S,130,0,1,00:02:14,3,02,000.000.,......00......00,00000000,0,0,0,0,12546,55.1F,,,,,,19.36,000000,19.32\";s:7:\"sValves\";s:8:\"000.000.\";s:7:\"sRelays\";s:16:\"......00......00\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','1');
INSERT INTO `rlb_reboot_history` VALUES ('288','a:5:{s:9:\"sResponse\";s:100:\"S,248,0,5,11:51:12,3,06,000000..,............0000,00000000,0,0,0,0,12562,59.7F,,,,,,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"000000..\";s:7:\"sRelays\";s:16:\"............0000\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','2');
INSERT INTO `rlb_reboot_history` VALUES ('289','a:5:{s:9:\"sResponse\";s:102:\"S,171,0,1,00:02:16,3,02,000.000.,......00......10,00000000,0,0,0,0,12531,59.6F,,,,,,19.48,000000,19.42\";s:7:\"sValves\";s:8:\"000.000.\";s:7:\"sRelays\";s:16:\"......00......10\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','1');
INSERT INTO `rlb_reboot_history` VALUES ('290','a:5:{s:9:\"sResponse\";s:100:\"S,231,0,6,11:51:12,3,06,000000..,............0000,00000000,0,0,0,0,12562,56.9F,,,,,,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"000000..\";s:7:\"sRelays\";s:16:\"............0000\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','2');
INSERT INTO `rlb_reboot_history` VALUES ('291','a:5:{s:9:\"sResponse\";s:102:\"S,151,0,1,00:02:22,3,02,000.002.,......00......00,00000000,0,0,0,0,12546,51.1F,,,,,,19.57,000000,19.51\";s:7:\"sValves\";s:8:\"000.002.\";s:7:\"sRelays\";s:16:\"......00......00\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','1');
INSERT INTO `rlb_reboot_history` VALUES ('292','a:5:{s:9:\"sResponse\";s:100:\"S,213,0,7,11:51:12,3,06,000000..,............0000,00000000,0,0,0,0,12578,55.3F,,,,,,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"000000..\";s:7:\"sRelays\";s:16:\"............0000\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','2');
INSERT INTO `rlb_reboot_history` VALUES ('293','a:5:{s:9:\"sResponse\";s:102:\"S,100,0,1,00:02:20,3,02,000.000.,......00......00,00000000,0,0,0,0,12546,55.1F,,,,,,19.45,000000,19.39\";s:7:\"sValves\";s:8:\"000.000.\";s:7:\"sRelays\";s:16:\"......00......00\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','1');
INSERT INTO `rlb_reboot_history` VALUES ('294','a:5:{s:9:\"sResponse\";s:100:\"S,029,0,1,11:51:11,3,06,000000..,............0000,00000000,0,0,0,0,12546,58.2F,,,,,,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"000000..\";s:7:\"sRelays\";s:16:\"............0000\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','2');
INSERT INTO `rlb_reboot_history` VALUES ('295','a:5:{s:9:\"sResponse\";s:102:\"S,010,0,1,00:02:18,3,02,000.000.,......00......00,00000000,0,0,0,0,12546,52.3F,,,,,,19.61,000000,19.55\";s:7:\"sValves\";s:8:\"000.000.\";s:7:\"sRelays\";s:16:\"......00......00\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','1');
INSERT INTO `rlb_reboot_history` VALUES ('296','a:5:{s:9:\"sResponse\";s:100:\"S,096,0,2,11:51:12,3,06,000000..,............0000,00000000,0,0,0,0,12546,56.1F,,,,,,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"000000..\";s:7:\"sRelays\";s:16:\"............0000\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','2');
INSERT INTO `rlb_reboot_history` VALUES ('297','a:5:{s:9:\"sResponse\";s:102:\"S,124,0,1,00:02:19,3,02,000.000.,......00......00,00000000,0,0,0,0,12546,51.8F,,,,,,17.78,000000,17.73\";s:7:\"sValves\";s:8:\"000.000.\";s:7:\"sRelays\";s:16:\"......00......00\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','1');
INSERT INTO `rlb_reboot_history` VALUES ('298','a:5:{s:9:\"sResponse\";s:100:\"S,162,0,3,11:51:14,3,06,000000..,............0000,00000000,0,0,0,0,12562,55.4F,,,,,,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"000000..\";s:7:\"sRelays\";s:16:\"............0000\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','2');
INSERT INTO `rlb_reboot_history` VALUES ('299','a:5:{s:9:\"sResponse\";s:102:\"S,081,0,1,00:02:18,3,02,000.000.,......00......00,00000000,0,0,0,0,12546,45.1F,,,,,,17.99,000000,17.98\";s:7:\"sValves\";s:8:\"000.000.\";s:7:\"sRelays\";s:16:\"......00......00\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','1');
INSERT INTO `rlb_reboot_history` VALUES ('300','a:5:{s:9:\"sResponse\";s:100:\"S,227,0,4,11:51:16,3,06,000000..,............0000,00000000,0,0,0,0,12562,49.3F,,,,,,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"000000..\";s:7:\"sRelays\";s:16:\"............0000\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','2');
INSERT INTO `rlb_reboot_history` VALUES ('301','a:5:{s:9:\"sResponse\";s:102:\"S,081,0,1,00:02:20,3,02,000.000.,......00......00,00000000,0,0,0,0,12546,44.9F,,,,,,18.26,000000,18.21\";s:7:\"sValves\";s:8:\"000.000.\";s:7:\"sRelays\";s:16:\"......00......00\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','1');
INSERT INTO `rlb_reboot_history` VALUES ('302','a:5:{s:9:\"sResponse\";s:100:\"S,036,0,5,11:51:19,3,06,000000..,............0000,00000000,0,0,0,0,12562,49.1F,,,,,,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"000000..\";s:7:\"sRelays\";s:16:\"............0000\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','2');
INSERT INTO `rlb_reboot_history` VALUES ('303','a:5:{s:9:\"sResponse\";s:102:\"S,152,0,1,00:02:17,3,02,000.000.,......00......00,00000000,0,0,0,0,12546,53.7F,,,,,,18.20,000000,18.14\";s:7:\"sValves\";s:8:\"000.000.\";s:7:\"sRelays\";s:16:\"......00......00\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','1');
INSERT INTO `rlb_reboot_history` VALUES ('304','a:5:{s:9:\"sResponse\";s:100:\"S,202,0,6,11:51:22,3,06,000000..,............0000,00000000,0,0,0,0,12562,57.7F,,,,,,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"000000..\";s:7:\"sRelays\";s:16:\"............0000\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','2');
INSERT INTO `rlb_reboot_history` VALUES ('305','a:5:{s:9:\"sResponse\";s:102:\"S,248,0,1,00:02:17,3,02,000.000.,......00......01,10000000,0,0,0,0,12531,53.3F,,,,,,19.07,000000,19.02\";s:7:\"sValves\";s:8:\"000.000.\";s:7:\"sRelays\";s:16:\"......00......01\";s:12:\"sPowercenter\";s:8:\"10000000\";s:5:\"sPump\";a:2:{i:0;s:1:\"1\";i:1;s:1:\"2\";}}','1');
INSERT INTO `rlb_reboot_history` VALUES ('306','a:5:{s:9:\"sResponse\";s:100:\"S,018,0,7,11:51:25,3,06,000000..,............0000,00000000,0,0,0,0,12562,54.7F,,,,,,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"000000..\";s:7:\"sRelays\";s:16:\"............0000\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','2');
INSERT INTO `rlb_reboot_history` VALUES ('307','a:5:{s:9:\"sResponse\";s:102:\"S,166,0,1,00:02:22,3,02,000.000.,......00......00,00000000,0,0,0,0,12546,46.3F,,,,,,19.23,000000,19.17\";s:7:\"sValves\";s:8:\"000.000.\";s:7:\"sRelays\";s:16:\"......00......00\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','1');
INSERT INTO `rlb_reboot_history` VALUES ('308','a:5:{s:9:\"sResponse\";s:100:\"S,073,0,1,11:51:27,3,06,000000..,............0000,00000000,0,0,0,0,12562,50.2F,,,,,,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"000000..\";s:7:\"sRelays\";s:16:\"............0000\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','2');
INSERT INTO `rlb_reboot_history` VALUES ('309','a:5:{s:9:\"sResponse\";s:102:\"S,120,0,1,00:02:24,3,02,000.000.,......00......00,00000000,0,0,0,0,12546,47.9F,,,,,,19.17,000000,19.14\";s:7:\"sValves\";s:8:\"000.000.\";s:7:\"sRelays\";s:16:\"......00......00\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','1');
INSERT INTO `rlb_reboot_history` VALUES ('310','a:5:{s:9:\"sResponse\";s:100:\"S,139,0,2,11:51:30,3,06,000000..,............0000,00000000,0,0,0,0,12562,52.0F,,,,,,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"000000..\";s:7:\"sRelays\";s:16:\"............0000\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','2');
INSERT INTO `rlb_reboot_history` VALUES ('311','a:5:{s:9:\"sResponse\";s:102:\"S,136,0,1,00:02:16,3,02,000.000.,......00......00,00000000,0,0,0,0,12546,50.3F,,,,,,18.06,000000,18.00\";s:7:\"sValves\";s:8:\"000.000.\";s:7:\"sRelays\";s:16:\"......00......00\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','1');
INSERT INTO `rlb_reboot_history` VALUES ('312','a:5:{s:9:\"sResponse\";s:100:\"S,206,0,3,11:51:32,3,06,000000..,............0000,00000000,0,0,0,0,12546,55.0F,,,,,,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"000000..\";s:7:\"sRelays\";s:16:\"............0000\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','2');
INSERT INTO `rlb_reboot_history` VALUES ('313','a:5:{s:9:\"sResponse\";s:102:\"S,207,0,1,00:02:16,3,02,000.000.,......00......00,00000000,0,0,0,0,12546,52.0F,,,,,,17.88,000000,17.86\";s:7:\"sValves\";s:8:\"000.000.\";s:7:\"sRelays\";s:16:\"......00......00\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','1');
INSERT INTO `rlb_reboot_history` VALUES ('314','a:5:{s:9:\"sResponse\";s:100:\"S,016,0,4,11:51:32,3,06,000000..,............0000,00000000,0,0,0,0,12562,55.6F,,,,,,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"000000..\";s:7:\"sRelays\";s:16:\"............0000\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','2');
INSERT INTO `rlb_reboot_history` VALUES ('315','a:5:{s:9:\"sResponse\";s:102:\"S,202,0,1,00:02:19,3,02,000.000.,......00......00,00000000,0,0,0,0,12546,43.5F,,,,,,18.14,000000,18.14\";s:7:\"sValves\";s:8:\"000.000.\";s:7:\"sRelays\";s:16:\"......00......00\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','1');
INSERT INTO `rlb_reboot_history` VALUES ('316','a:5:{s:9:\"sResponse\";s:100:\"S,081,0,5,11:51:37,3,06,000000..,............0000,00000000,0,0,0,0,12562,47.6F,,,,,,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"000000..\";s:7:\"sRelays\";s:16:\"............0000\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','2');
INSERT INTO `rlb_reboot_history` VALUES ('317','a:5:{s:9:\"sResponse\";s:102:\"S,137,0,1,00:02:18,3,02,000.000.,......00......00,00000000,0,0,0,0,12546,52.3F,,,,,,18.34,000000,18.29\";s:7:\"sValves\";s:8:\"000.000.\";s:7:\"sRelays\";s:16:\"......00......00\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','1');
INSERT INTO `rlb_reboot_history` VALUES ('318','a:5:{s:9:\"sResponse\";s:100:\"S,168,0,6,11:51:40,3,06,000000..,............0000,00000000,0,0,0,0,12562,56.8F,,,,,,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"000000..\";s:7:\"sRelays\";s:16:\"............0000\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','2');
INSERT INTO `rlb_reboot_history` VALUES ('319','a:5:{s:9:\"sResponse\";s:102:\"S,093,0,1,00:02:19,3,02,000.000.,......00......00,00000000,0,0,0,0,12546,48.5F,,,,,,20.21,000000,20.20\";s:7:\"sValves\";s:8:\"000.000.\";s:7:\"sRelays\";s:16:\"......00......00\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','1');
INSERT INTO `rlb_reboot_history` VALUES ('320','a:5:{s:9:\"sResponse\";s:100:\"S,219,0,7,11:51:42,3,06,000000..,............0000,00000000,0,0,0,0,12562,53.6F,,,,,,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"000000..\";s:7:\"sRelays\";s:16:\"............0000\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','2');
INSERT INTO `rlb_reboot_history` VALUES ('321','a:5:{s:9:\"sResponse\";s:102:\"S,165,0,1,00:02:17,3,02,000.000.,......00......00,00000000,0,0,0,0,12546,52.7F,,,,,,20.36,000000,20.30\";s:7:\"sValves\";s:8:\"000.000.\";s:7:\"sRelays\";s:16:\"......00......00\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','1');
INSERT INTO `rlb_reboot_history` VALUES ('322','a:5:{s:9:\"sResponse\";s:100:\"S,198,0,1,11:51:43,3,06,000000..,............0000,00000000,0,0,0,0,12562,58.1F,,,,,,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"000000..\";s:7:\"sRelays\";s:16:\"............0000\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','2');
INSERT INTO `rlb_reboot_history` VALUES ('323','a:5:{s:9:\"sResponse\";s:102:\"S,016,0,1,00:02:15,3,02,000.000.,......00......00,00000000,0,0,0,0,12531,53.6F,,,,,,20.24,000000,20.18\";s:7:\"sValves\";s:8:\"000.000.\";s:7:\"sRelays\";s:16:\"......00......00\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','1');
INSERT INTO `rlb_reboot_history` VALUES ('324','a:5:{s:9:\"sResponse\";s:100:\"S,008,0,2,11:51:43,3,06,000000..,............0000,00000000,0,0,0,0,12562,58.1F,,,,,,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"000000..\";s:7:\"sRelays\";s:16:\"............0000\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','2');
INSERT INTO `rlb_reboot_history` VALUES ('325','a:5:{s:9:\"sResponse\";s:102:\"S,143,0,1,00:02:18,3,02,000.000.,......00......00,00000000,0,0,0,0,12531,53.8F,,,,,,20.45,000000,20.39\";s:7:\"sValves\";s:8:\"000.000.\";s:7:\"sRelays\";s:16:\"......00......00\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','1');
INSERT INTO `rlb_reboot_history` VALUES ('326','a:5:{s:9:\"sResponse\";s:100:\"S,073,0,3,11:51:44,3,06,000000..,............0000,00000000,0,0,0,0,12546,58.2F,,,,,,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"000000..\";s:7:\"sRelays\";s:16:\"............0000\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','2');
INSERT INTO `rlb_reboot_history` VALUES ('327','a:5:{s:9:\"sResponse\";s:102:\"S,107,0,1,00:02:10,3,02,000.000.,......00......00,00000000,0,0,0,0,12531,52.9F,,,,,,17.34,000000,17.30\";s:7:\"sValves\";s:8:\"000.000.\";s:7:\"sRelays\";s:16:\"......00......00\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','1');
INSERT INTO `rlb_reboot_history` VALUES ('328','a:5:{s:9:\"sResponse\";s:100:\"S,138,0,4,11:51:44,3,06,000000..,............0000,00000000,0,0,0,0,12546,57.1F,,,,,,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"000000..\";s:7:\"sRelays\";s:16:\"............0000\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','2');
INSERT INTO `rlb_reboot_history` VALUES ('329','a:5:{s:9:\"sResponse\";s:102:\"S,175,0,1,00:02:15,3,02,000.000.,......00......00,00000000,0,0,0,0,12531,53.4F,,,,,,17.64,000000,17.58\";s:7:\"sValves\";s:8:\"000.000.\";s:7:\"sRelays\";s:16:\"......00......00\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','1');
INSERT INTO `rlb_reboot_history` VALUES ('330','a:5:{s:9:\"sResponse\";s:100:\"S,203,0,5,11:51:44,3,06,000000..,............0000,00000000,0,0,0,0,12546,57.7F,,,,,,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"000000..\";s:7:\"sRelays\";s:16:\"............0000\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','2');
INSERT INTO `rlb_reboot_history` VALUES ('331','a:5:{s:9:\"sResponse\";s:102:\"S,108,0,1,00:02:12,3,02,000.000.,......00......00,01000000,0,0,0,0,12531,66.5F,,,,,,15.92,000000,15.88\";s:7:\"sValves\";s:8:\"000.000.\";s:7:\"sRelays\";s:16:\"......00......00\";s:12:\"sPowercenter\";s:8:\"01000000\";s:5:\"sPump\";a:1:{i:0;s:1:\"1\";}}','1');
INSERT INTO `rlb_reboot_history` VALUES ('332','a:5:{s:9:\"sResponse\";s:100:\"S,161,0,6,11:51:42,3,06,000000..,............0000,00000000,0,0,0,0,12546,68.6F,,,,,,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"000000..\";s:7:\"sRelays\";s:16:\"............0000\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','2');
INSERT INTO `rlb_reboot_history` VALUES ('333','a:5:{s:9:\"sResponse\";s:102:\"S,117,0,1,00:02:12,3,02,000.000.,......00......00,00000000,0,0,0,0,12546,53.4F,,,,,,16.06,000000,16.02\";s:7:\"sValves\";s:8:\"000.000.\";s:7:\"sRelays\";s:16:\"......00......00\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','1');
INSERT INTO `rlb_reboot_history` VALUES ('334','a:5:{s:9:\"sResponse\";s:100:\"S,140,0,7,11:51:40,3,06,000000..,............0000,00000000,0,0,0,0,12562,56.6F,,,,,,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"000000..\";s:7:\"sRelays\";s:16:\"............0000\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','2');
INSERT INTO `rlb_reboot_history` VALUES ('335','a:5:{s:9:\"sResponse\";s:102:\"S,017,0,1,00:02:19,3,02,000.000.,......00......00,00000000,0,0,0,0,12562,38.6F,,,,,,16.45,000000,16.45\";s:7:\"sValves\";s:8:\"000.000.\";s:7:\"sRelays\";s:16:\"......00......00\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','1');
INSERT INTO `rlb_reboot_history` VALUES ('336','a:5:{s:9:\"sResponse\";s:100:\"S,182,0,1,11:51:45,3,06,000000..,............0000,00000000,0,0,0,0,12578,43.7F,,,,,,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"000000..\";s:7:\"sRelays\";s:16:\"............0000\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','2');
INSERT INTO `rlb_reboot_history` VALUES ('337','a:5:{s:9:\"sResponse\";s:102:\"S,013,0,1,00:02:21,3,02,000.000.,......00......00,00000000,0,0,0,0,12562,40.8F,,,,,,16.65,000000,16.59\";s:7:\"sValves\";s:8:\"000.000.\";s:7:\"sRelays\";s:16:\"......00......00\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','1');
INSERT INTO `rlb_reboot_history` VALUES ('338','a:5:{s:9:\"sResponse\";s:100:\"S,247,0,2,11:51:52,3,06,000000..,............0000,00000000,0,0,0,0,12562,44.4F,,,,,,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"000000..\";s:7:\"sRelays\";s:16:\"............0000\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','2');
INSERT INTO `rlb_reboot_history` VALUES ('339','a:5:{s:9:\"sResponse\";s:102:\"S,160,0,1,00:02:22,3,02,000.000.,......00......00,01000000,0,0,0,0,12562,48.1F,,,,,,18.26,000000,18.23\";s:7:\"sValves\";s:8:\"000.000.\";s:7:\"sRelays\";s:16:\"......00......00\";s:12:\"sPowercenter\";s:8:\"01000000\";s:5:\"sPump\";a:1:{i:0;s:1:\"1\";}}','1');
INSERT INTO `rlb_reboot_history` VALUES ('340','a:5:{s:9:\"sResponse\";s:100:\"S,007,0,3,11:51:58,3,06,000000..,............0000,00000000,0,0,0,0,12562,47.8F,,,,,,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"000000..\";s:7:\"sRelays\";s:16:\"............0000\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','2');
INSERT INTO `rlb_reboot_history` VALUES ('341','a:5:{s:9:\"sResponse\";s:102:\"S,096,0,1,00:02:17,3,02,000.000.,......00......00,00000000,0,0,0,0,12546,59.8F,,,,,,18.31,000000,18.26\";s:7:\"sValves\";s:8:\"000.000.\";s:7:\"sRelays\";s:16:\"......00......00\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','1');
INSERT INTO `rlb_reboot_history` VALUES ('342','a:5:{s:9:\"sResponse\";s:100:\"S,247,0,4,11:52:01,3,06,000000..,............0000,00000000,0,0,0,0,12562,59.7F,,,,,,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"000000..\";s:7:\"sRelays\";s:16:\"............0000\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','2');
INSERT INTO `rlb_reboot_history` VALUES ('343','a:5:{s:9:\"sResponse\";s:102:\"S,113,0,1,00:02:13,3,02,000.000.,......00......00,00000000,0,0,0,0,12531,62.6F,,,,,,18.00,000000,17.95\";s:7:\"sValves\";s:8:\"000.000.\";s:7:\"sRelays\";s:16:\"......00......00\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','1');
INSERT INTO `rlb_reboot_history` VALUES ('344','a:5:{s:9:\"sResponse\";s:100:\"S,125,0,5,11:52:02,3,06,000000..,............0000,00000000,0,0,0,0,12546,64.4F,,,,,,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"000000..\";s:7:\"sRelays\";s:16:\"............0000\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','2');
INSERT INTO `rlb_reboot_history` VALUES ('345','a:5:{s:9:\"sResponse\";s:102:\"S,231,0,0,17:41:17,3,02,000.000.,......00......00,01000000,0,0,0,0,12531,60.9F,,,,,,17.41,000000,17.38\";s:7:\"sValves\";s:8:\"000.000.\";s:7:\"sRelays\";s:16:\"......00......00\";s:12:\"sPowercenter\";s:8:\"01000000\";s:5:\"sPump\";a:0:{}}','1');
INSERT INTO `rlb_reboot_history` VALUES ('346','a:5:{s:9:\"sResponse\";s:100:\"S,120,0,6,11:52:04,3,06,000000..,............0000,00000000,0,0,0,0,12531,62.6F,,,,,,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"000000..\";s:7:\"sRelays\";s:16:\"............0000\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','2');
INSERT INTO `rlb_reboot_history` VALUES ('347','a:5:{s:9:\"sResponse\";s:102:\"S,047,0,1,00:02:16,3,02,000.000.,......00......00,00000000,0,0,0,0,12531,61.8F,,,,,,17.28,000000,17.28\";s:7:\"sValves\";s:8:\"000.000.\";s:7:\"sRelays\";s:16:\"......00......00\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','1');
INSERT INTO `rlb_reboot_history` VALUES ('348','a:5:{s:9:\"sResponse\";s:100:\"S,094,0,7,11:52:03,3,06,000000..,............0000,00000000,0,0,0,0,12531,61.4F,,,,,,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"000000..\";s:7:\"sRelays\";s:16:\"............0000\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','2');
INSERT INTO `rlb_reboot_history` VALUES ('349','a:5:{s:9:\"sResponse\";s:102:\"S,161,0,1,00:02:18,3,02,000.000.,......00......00,00000000,0,0,0,0,12546,52.8F,,,,,,17.45,000000,17.42\";s:7:\"sValves\";s:8:\"000.000.\";s:7:\"sRelays\";s:16:\"......00......00\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','1');
INSERT INTO `rlb_reboot_history` VALUES ('350','a:5:{s:9:\"sResponse\";s:100:\"S,141,0,1,11:52:07,3,06,000000..,............0000,00000000,0,0,0,0,12562,54.6F,,,,,,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"000000..\";s:7:\"sRelays\";s:16:\"............0000\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','2');
INSERT INTO `rlb_reboot_history` VALUES ('351','a:5:{s:9:\"sResponse\";s:102:\"S,112,0,1,00:02:20,3,02,000.000.,......00......00,00000000,0,0,0,0,12531,47.8F,,,,,,17.80,000000,17.74\";s:7:\"sValves\";s:8:\"000.000.\";s:7:\"sRelays\";s:16:\"......00......00\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','1');
INSERT INTO `rlb_reboot_history` VALUES ('352','a:5:{s:9:\"sResponse\";s:100:\"S,169,0,2,11:52:10,3,06,000000..,............0000,00000000,0,0,0,0,12562,50.6F,,,,,,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"000000..\";s:7:\"sRelays\";s:16:\"............0000\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','2');
INSERT INTO `rlb_reboot_history` VALUES ('353','a:5:{s:9:\"sResponse\";s:102:\"S,222,0,1,00:02:26,3,02,000.000.,......00......00,01000000,0,0,0,0,12546,46.7F,,,,,,17.84,000000,17.78\";s:7:\"sValves\";s:8:\"000.000.\";s:7:\"sRelays\";s:16:\"......00......00\";s:12:\"sPowercenter\";s:8:\"01000000\";s:5:\"sPump\";a:1:{i:0;s:1:\"1\";}}','1');
INSERT INTO `rlb_reboot_history` VALUES ('354','a:5:{s:9:\"sResponse\";s:100:\"S,078,0,3,11:52:15,3,06,000000..,............0000,00000000,0,0,0,0,12562,49.7F,,,,,,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"000000..\";s:7:\"sRelays\";s:16:\"............0000\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','2');
INSERT INTO `rlb_reboot_history` VALUES ('355','a:5:{s:9:\"sResponse\";s:102:\"S,185,0,1,00:02:24,3,02,000.000.,......00......00,00000000,0,0,0,0,12546,48.4F,,,,,,17.78,000000,17.74\";s:7:\"sValves\";s:8:\"000.000.\";s:7:\"sRelays\";s:16:\"......00......00\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','1');
INSERT INTO `rlb_reboot_history` VALUES ('356','a:5:{s:9:\"sResponse\";s:100:\"S,122,0,4,11:52:19,3,06,000000..,............0000,00000000,0,0,0,0,12546,51.5F,,,,,,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"000000..\";s:7:\"sRelays\";s:16:\"............0000\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','2');
INSERT INTO `rlb_reboot_history` VALUES ('357','a:5:{s:9:\"sResponse\";s:102:\"S,165,0,1,00:02:24,3,02,000.100.,......00......00,00000000,0,0,0,0,12531,51.4F,,,,,,11.04,000000,11.61\";s:7:\"sValves\";s:8:\"000.100.\";s:7:\"sRelays\";s:16:\"......00......00\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','1');
INSERT INTO `rlb_reboot_history` VALUES ('358','a:5:{s:9:\"sResponse\";s:100:\"S,218,0,5,11:52:23,3,06,200210..,............0000,00000000,0,0,0,0,12546,54.6F,,,,,,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"200210..\";s:7:\"sRelays\";s:16:\"............0000\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','2');
INSERT INTO `rlb_reboot_history` VALUES ('359','a:5:{s:9:\"sResponse\";s:102:\"S,043,0,1,00:02:17,3,02,000.000.,......00......00,01000000,0,0,0,0,12531,53.4F,,,,,,17.50,000000,17.48\";s:7:\"sValves\";s:8:\"000.000.\";s:7:\"sRelays\";s:16:\"......00......00\";s:12:\"sPowercenter\";s:8:\"01000000\";s:5:\"sPump\";a:0:{}}','1');
INSERT INTO `rlb_reboot_history` VALUES ('360','a:5:{s:9:\"sResponse\";s:100:\"S,038,0,6,11:52:23,3,06,000210..,............0000,00000000,0,0,0,0,12546,57.5F,,,,,,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"000210..\";s:7:\"sRelays\";s:16:\"............0000\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','2');
INSERT INTO `rlb_reboot_history` VALUES ('361','a:5:{s:9:\"sResponse\";s:102:\"S,128,0,1,00:02:24,3,02,000.000.,......00......01,10000000,0,0,0,0,12531,57.7F,,,,,,17.72,000000,17.66\";s:7:\"sValves\";s:8:\"000.000.\";s:7:\"sRelays\";s:16:\"......00......01\";s:12:\"sPowercenter\";s:8:\"10000000\";s:5:\"sPump\";a:2:{i:0;s:1:\"1\";i:1;s:1:\"2\";}}','1');
INSERT INTO `rlb_reboot_history` VALUES ('362','a:5:{s:9:\"sResponse\";s:100:\"S,131,0,7,11:52:26,3,06,000000..,............0000,00000000,0,0,0,0,12546,59.6F,,,,,,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"000000..\";s:7:\"sRelays\";s:16:\"............0000\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','2');
INSERT INTO `rlb_reboot_history` VALUES ('363','a:5:{s:9:\"sResponse\";s:102:\"S,091,0,1,00:02:18,3,02,000.012.,......00......00,10000000,0,0,0,0,12531,59.1F,,,,,,11.01,000000,10.95\";s:7:\"sValves\";s:8:\"000.012.\";s:7:\"sRelays\";s:16:\"......00......00\";s:12:\"sPowercenter\";s:8:\"10000000\";s:5:\"sPump\";a:2:{i:0;s:1:\"1\";i:1;s:1:\"2\";}}','1');
INSERT INTO `rlb_reboot_history` VALUES ('364','a:5:{s:9:\"sResponse\";s:100:\"S,115,0,1,11:52:27,3,06,000000..,............0000,00000000,0,0,0,0,12531,60.8F,,,,,,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"000000..\";s:7:\"sRelays\";s:16:\"............0000\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','2');

/*---------------------------------------------------------------
  TABLE: `rlb_relay_prog`
  ---------------------------------------------------------------*/
DROP TABLE IF EXISTS `rlb_relay_prog`;
CREATE TABLE `rlb_relay_prog` (
  `relay_prog_id` int(11) NOT NULL AUTO_INCREMENT,
  `relay_prog_name` varchar(255) NOT NULL,
  `relay_number` varchar(8) NOT NULL,
  `relay_prog_type` int(2) NOT NULL COMMENT '1-Daily, 2-Weekly',
  `relay_prog_days` varchar(255) NOT NULL COMMENT '0-All, 1-Mon, 2-Tue...7-Sun',
  `relay_start_time` varchar(255) NOT NULL,
  `relay_end_time` varchar(255) NOT NULL,
  `relay_prog_created_date` datetime NOT NULL,
  `relay_prog_modified_date` datetime NOT NULL,
  `relay_prog_delete` int(1) NOT NULL DEFAULT '0',
  `relay_prog_active` int(1) NOT NULL DEFAULT '0',
  `relay_prog_absolute` enum('0','1') NOT NULL DEFAULT '0',
  `relay_prog_absolute_start_time` varchar(100) DEFAULT NULL,
  `relay_prog_absolute_end_time` varchar(100) DEFAULT NULL,
  `relay_prog_absolute_total_time` varchar(100) DEFAULT NULL,
  `relay_prog_absolute_run_time` varchar(100) DEFAULT NULL,
  `relay_prog_absolute_start_date` date DEFAULT NULL,
  `relay_prog_absolute_run` enum('0','1') NOT NULL DEFAULT '0',
  PRIMARY KEY (`relay_prog_id`)
) ENGINE=MyISAM AUTO_INCREMENT=12 DEFAULT CHARSET=latin1;
INSERT INTO `rlb_relay_prog` VALUES   ('1','test','0','1','0','23:00:00','23:30:00','2015-04-03 15:40:46','2015-07-10 12:37:12','0','0','0',NULL,NULL,NULL,NULL,NULL,'0');
INSERT INTO `rlb_relay_prog` VALUES ('2','newtest1','0','2','2,3,6','14:00:00','20:00:00','2015-04-07 00:00:00','2015-04-07 00:00:00','0','0','0',NULL,NULL,NULL,NULL,NULL,'0');
INSERT INTO `rlb_relay_prog` VALUES ('3','testrelay0','0','2','1,4,5','22:00:00','23:30:00','2015-04-07 00:00:00','2015-04-07 00:00:00','0','0','0',NULL,NULL,NULL,NULL,NULL,'0');
INSERT INTO `rlb_relay_prog` VALUES ('4','testrelay1','1','1','0','10:00:00','13:00:00','2015-04-08 00:00:00','2015-04-08 00:00:00','0','0','0',NULL,NULL,NULL,NULL,NULL,'0');
INSERT INTO `rlb_relay_prog` VALUES ('5','Weeklytest','0','2','2,6','01:00:00','01:30:00','2015-04-20 00:00:00','2015-04-20 00:00:00','1','0','0',NULL,NULL,NULL,NULL,NULL,'0');
INSERT INTO `rlb_relay_prog` VALUES ('6','</>','0','1','0','</>','</>','2015-04-24 00:00:00','2015-04-24 00:00:00','1','0','0',NULL,NULL,NULL,NULL,NULL,'0');
INSERT INTO `rlb_relay_prog` VALUES ('7','dhiraj Test','0','1','0','02:00:00','02:30:00','2015-07-06 00:00:00','2015-07-13 12:50:40','0','0','1',NULL,NULL,'00:30:00','',NULL,'0');
INSERT INTO `rlb_relay_prog` VALUES ('8','Test','0','2','2,4,6','00:00:00','01:00:00','2015-07-09 07:31:37','0000-00-00 00:00:00','1','0','0',NULL,NULL,NULL,NULL,NULL,'0');
INSERT INTO `rlb_relay_prog` VALUES ('9','Test Relay 1','1','2','2,3,4','00:30:00','01:00:00','2015-07-09 08:38:46','2015-07-09 08:40:21','1','0','0',NULL,NULL,NULL,NULL,NULL,'0');
INSERT INTO `rlb_relay_prog` VALUES ('10','Program2','1','2','2,3','02:00:00','04:00:00','2015-07-09 09:05:11','2015-07-09 09:05:23','0','0','0',NULL,NULL,NULL,NULL,NULL,'0');
INSERT INTO `rlb_relay_prog` VALUES ('11','Test Relay Number','0','2','3','01:00:00','02:00:00','2015-07-09 11:41:53','2015-07-10 14:56:21','0','0','1',NULL,NULL,'01:00:00',NULL,NULL,'0');

/*---------------------------------------------------------------
  TABLE: `rlb_relays`
  ---------------------------------------------------------------*/
DROP TABLE IF EXISTS `rlb_relays`;
CREATE TABLE `rlb_relays` (
  `relay_id` int(11) NOT NULL AUTO_INCREMENT,
  `relay_number` int(11) NOT NULL,
  `relay_name` varchar(100) NOT NULL,
  PRIMARY KEY (`relay_id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;
INSERT INTO `rlb_relays` VALUES   ('1','0','Test Realy 1');
INSERT INTO `rlb_relays` VALUES ('2','2','Test for relay 2');
INSERT INTO `rlb_relays` VALUES ('3','3','Test for relay3 editedaf');
INSERT INTO `rlb_relays` VALUES ('4','5','rl5');
INSERT INTO `rlb_relays` VALUES ('5','10','relay 10');
INSERT INTO `rlb_relays` VALUES ('6','1','Test Relay 11111');

/*---------------------------------------------------------------
  TABLE: `rlb_run_after_heater`
  ---------------------------------------------------------------*/
DROP TABLE IF EXISTS `rlb_run_after_heater`;
CREATE TABLE `rlb_run_after_heater` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `heaterNumber` int(10) NOT NULL,
  `pumpNumber` int(10) NOT NULL,
  `heaterStopTime` datetime NOT NULL,
  `PumpStopTime` datetime NOT NULL,
  `ip_id` int(5) NOT NULL,
  `runComplete` enum('0','1') NOT NULL DEFAULT '0',
  `program_id` int(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
INSERT INTO `rlb_run_after_heater` VALUES   ('1','0','1','2017-01-01 01:00:38','2017-01-01 01:05:38','1','1','51');
INSERT INTO `rlb_run_after_heater` VALUES ('2','1','1','2016-12-31 21:58:02','2016-12-31 22:03:02','1','1','1');

/*---------------------------------------------------------------
  TABLE: `rlb_setting`
  ---------------------------------------------------------------*/
DROP TABLE IF EXISTS `rlb_setting`;
CREATE TABLE `rlb_setting` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `ip_address` varchar(100) DEFAULT NULL,
  `port_no` varchar(100) DEFAULT NULL,
  `port_no_2` varchar(150) NOT NULL,
  `extra` text NOT NULL,
  `ip_external` varchar(150) NOT NULL,
  `old_ip` varchar(200) NOT NULL,
  `is_updated` enum('0','1') NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
INSERT INTO `rlb_setting` VALUES   ('1','192.168.0.103','13330','13331','a:24:{s:9:\"Pool_Temp\";s:1:\"1\";s:17:\"Pool_Temp_Address\";s:3:\"TS0\";s:8:\"Spa_Temp\";s:1:\"0\";s:16:\"Spa_Temp_Address\";s:0:\"\";s:11:\"PumpsNumber\";s:1:\"3\";s:11:\"ValveNumber\";i:6;s:10:\"Remote_Spa\";s:1:\"1\";s:11:\"LightNumber\";s:1:\"1\";s:12:\"HeaterNumber\";s:1:\"2\";s:12:\"BlowerNumber\";s:1:\"1\";s:10:\"MiscNumber\";s:1:\"2\";s:18:\"Remote_Spa_display\";s:1:\"1\";s:12:\"PumpsNumber2\";s:1:\"1\";s:12:\"ValveNumber2\";s:1:\"6\";s:12:\"LightNumber2\";s:1:\"2\";s:13:\"HeaterNumber2\";s:1:\"1\";s:13:\"BlowerNumber2\";s:1:\"4\";s:11:\"MiscNumber2\";s:3:\"100\";s:11:\"Remote_Spa2\";s:1:\"0\";s:19:\"Remote_Spa_display2\";s:1:\"0\";s:8:\"SecondIP\";s:1:\"1\";s:15:\"showTemperature\";s:1:\"1\";s:16:\"showTemperature2\";s:1:\"1\";s:17:\"level_measurement\";s:4:\"17.5\";}','72.193.38.98','72.193.38.98','0');

/*---------------------------------------------------------------
  TABLE: `rlb_site_modules`
  ---------------------------------------------------------------*/
DROP TABLE IF EXISTS `rlb_site_modules`;
CREATE TABLE `rlb_site_modules` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `module_name` varchar(250) NOT NULL,
  `module_active` enum('0','1') NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=latin1;
INSERT INTO `rlb_site_modules` VALUES   ('2','24V AC Relayz','1');
INSERT INTO `rlb_site_modules` VALUES ('3','12V DC Power Center Relay','1');
INSERT INTO `rlb_site_modules` VALUES ('4','Modes','1');
INSERT INTO `rlb_site_modules` VALUES ('5','Lights','1');
INSERT INTO `rlb_site_modules` VALUES ('6','Spa Devices','1');
INSERT INTO `rlb_site_modules` VALUES ('7','Pool Devices','1');
INSERT INTO `rlb_site_modules` VALUES ('8','Valve','1');
INSERT INTO `rlb_site_modules` VALUES ('9','Pump','1');
INSERT INTO `rlb_site_modules` VALUES ('10','Temperature Sensors','1');
INSERT INTO `rlb_site_modules` VALUES ('11','Input','1');
INSERT INTO `rlb_site_modules` VALUES ('12','Settings','1');
INSERT INTO `rlb_site_modules` VALUES ('13','Status','1');
INSERT INTO `rlb_site_modules` VALUES ('15','Log','1');
INSERT INTO `rlb_site_modules` VALUES ('16','Light','1');
INSERT INTO `rlb_site_modules` VALUES ('17','Heater','1');
INSERT INTO `rlb_site_modules` VALUES ('18','Pool and Spa','1');
INSERT INTO `rlb_site_modules` VALUES ('19','Blower','1');
INSERT INTO `rlb_site_modules` VALUES ('20','Miscellaneous','1');
INSERT INTO `rlb_site_modules` VALUES ('21','Advance Settings','1');

/*---------------------------------------------------------------
  TABLE: `rlb_valve_default_position`
  ---------------------------------------------------------------*/
DROP TABLE IF EXISTS `rlb_valve_default_position`;
CREATE TABLE `rlb_valve_default_position` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `valve` int(5) NOT NULL,
  `ip_id` int(5) NOT NULL,
  `position` int(5) NOT NULL,
  `positiontime` int(5) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=latin1;
INSERT INTO `rlb_valve_default_position` VALUES   ('1','0','1','1','1');
INSERT INTO `rlb_valve_default_position` VALUES ('2','1','1','1','1');
INSERT INTO `rlb_valve_default_position` VALUES ('3','2','1','1','1');
INSERT INTO `rlb_valve_default_position` VALUES ('4','4','1','1','1');
INSERT INTO `rlb_valve_default_position` VALUES ('5','5','1','1','1');
INSERT INTO `rlb_valve_default_position` VALUES ('6','6','1','2','1');
INSERT INTO `rlb_valve_default_position` VALUES ('7','0','2','1','1');
INSERT INTO `rlb_valve_default_position` VALUES ('8','1','2','2','1');
INSERT INTO `rlb_valve_default_position` VALUES ('9','2','2','2','1');
INSERT INTO `rlb_valve_default_position` VALUES ('10','3','2','2','1');
INSERT INTO `rlb_valve_default_position` VALUES ('11','4','2','1','1');
INSERT INTO `rlb_valve_default_position` VALUES ('12','5','2','2','1');

/*---------------------------------------------------------------
  TABLE: `rlb_valve_default_position_run`
  ---------------------------------------------------------------*/
DROP TABLE IF EXISTS `rlb_valve_default_position_run`;
CREATE TABLE `rlb_valve_default_position_run` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `program_id` int(5) NOT NULL,
  `valve` int(5) NOT NULL,
  `ip_id` int(5) NOT NULL,
  `start_time` datetime NOT NULL,
  `end_time` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*---------------------------------------------------------------
  TABLE: `rlb_valves`
  ---------------------------------------------------------------*/
DROP TABLE IF EXISTS `rlb_valves`;
CREATE TABLE `rlb_valves` (
  `valve_id` int(11) NOT NULL AUTO_INCREMENT,
  `valve_number` int(11) NOT NULL,
  `valve_name` varchar(100) NOT NULL,
  PRIMARY KEY (`valve_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

/*---------------------------------------------------------------
  TABLE: `rlb_vera_details`
  ---------------------------------------------------------------*/
DROP TABLE IF EXISTS `rlb_vera_details`;
CREATE TABLE `rlb_vera_details` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `VeraUsername` varchar(150) NOT NULL,
  `VeraPassword` varchar(50) NOT NULL,
  `VeraVersion` int(2) NOT NULL,
  `VeraPhone` varchar(50) NOT NULL,
  `VeraAddedDate` datetime NOT NULL,
  `VeraModifiedDate` datetime NOT NULL,
  `VeraServer` varchar(250) NOT NULL,
  `VeraSession` varchar(250) NOT NULL,
  `VeraPKDevice` varchar(250) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
