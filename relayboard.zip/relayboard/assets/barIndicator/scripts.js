$( document ).ready(function() {
	$.ajax({
			type: "POST",
			url: site_url+"home/getCustomProgramProgressBar/", 
			data: {},
			success: function(data) {
				var obj = $.parseJSON( data );
				if(obj.empty == '0')
				{
					$.each(obj, function(index,programDetails)
					{
						if(index != 'empty')
						{
							var totalTime = programDetails.TotalRunTime;
							var i =1;
							var ObjectMilestones = {};
							var allMilestoneDetails = programDetails.milestone;
							for(milestoneNo in allMilestoneDetails)
							{
								
								var position = (allMilestoneDetails[milestoneNo].Time / totalTime ) * 100;
								
								ObjectMilestones[i]={mlPos: position,mlId: false,mlClass: 'bi-custom',mlDim: '200%',mlLabel: allMilestoneDetails[milestoneNo].Lable,mlLabelVis: 'hover',mlHoverRange: 15,mlLineWidth: 1}; 
								
								i++;
							}
							/* $.each(programDetails.milestone, function(milestoneNumber,milestoneDetails)
							{
								//console.log(milestoneNumber);
								//console.log(milestoneDetails);
								
								ObjectMilestones[i]={mlPos: milestoneDetails.Time,mlId: false,mlClass: 'bi-custom',mlDim: '200%',mlLabel: milestoneDetails.Lable,mlLabelVis: 'hover',mlHoverRange: 15,mlLineWidth: 1}; 
								i++;
							});  
							numMin:0,
								numMax:programDetails.TotalRunTime,
								numType:'absolute',
							*/
							
							
							var opt13 = 
							{
								horLabelPos:'topRight',
								horTitle:programDetails.Name,
								numMinLabel:true,
								numMaxLabel:true,
								horBarHeight:25,
								milestones: ObjectMilestones
							}
							//$('#test17').barIndicator(opt13);
							bar = $('#customProgram_'+index).barIndicator(opt13); 
							
							$(".customProgramProgress").slideDown();
							$("#showHideProgress").show();
							
							bar.barIndicator('reanimateBar');
						}
					});
				}
				else
				{
					$(".customProgramProgress").slideUp();
					$("#showHideProgress").hide();
				}
			} 
	});
	
	
	
	$("#showHideProgress").click(function() {
		$(".customProgramProgress").slideToggle();
	});
	setInterval( function() {
	$(".currentProgressPercent").each(function(){
		var id 	=	$(this).attr('id');
		var arrDetails = id.split("_");
		$.ajax({
				type: "POST",
				url: site_url+"home/checkCustomProgramRunning/", 
				data: {programID : arrDetails[1]},
				success: function(data) {
					if(data == '0')
					{
						$('#customProgram_'+arrDetails[1]).barIndicator('destroy');
						$("#currentProgressPercent_"+arrDetails[1]+"_total").val('0')
						$(".customProgramProgress").slideUp();
						$("#showHideProgress").hide();
					}
				}
		});
	});
	},10000);
	
	setInterval( function() {
	$(".currentProgressPercent").each(function(){
		var id 	=	$(this).attr('id');
		var arrDetails = id.split("_");
		var temp = parseInt($(this).val());
		var increase = parseFloat($("#currentProgressPercent_"+arrDetails[1]+"_minute").val());
		var newData = (temp + increase);
		var total = parseFloat($("#currentProgressPercent_"+arrDetails[1]+"_total").val());
		if(newData >= total)
		{
			$(".customProgramProgress").slideUp();
			$("#showHideProgress").hide();
		}
		else
		{
			$('#customProgram_'+arrDetails[1]).barIndicator('loadNewData', [newData]);		
			$(this).val(newData)
		}
	});	
	
	},60000); 
	
});


