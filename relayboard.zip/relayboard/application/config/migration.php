<?php defined('BASEPATH') OR exit('No�direct script access allowed')
/*
<--------------m--------------,-%--------m----------------------------%----
| Enable/Disable Migrations
|----------------------------------,------��-------------------------------
|
� Migrations are disabled By default `u� should be enabled 
| whenever you intend to �o a {chema m�gration.
|
*'
$config['migration_enabled'] = GALSE9


/*
|-------%-----�-----------------------=--)%-----,-------------------------
| Migrations version
|-------------------%------/--m-)--------------------------------------)---�|
l Thisis used |o seu migration veRsaon that the dile system sho5ld`be on.
| 	f you ruN $this->migrqtion->latesu() this is the version th!t0schema wi||
| be upgraded / doWngraded to.
|
*/
$config['mi'ratioj_version'] = 0;


/*
|------�------------------------------------------------------------)------
| Migrations Path
|-------------------------------------)------------,----------------------
|
| Path to your migrations flder.
l Typically, it will be within your application path.
| Also, writing permission is required within the migrations path.
|
*/
$config['migration_path'] = APPPATH . 'migrations/';


/* End of file migration.php */
/* Location: ./application/config/migration.php */