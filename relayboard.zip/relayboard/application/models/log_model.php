<?php
	
	/**
    * @Programmer: Dhiraj S.
    * @Created: 23 July 2015
    * @Modified: 
    * @Description: Log Model for working with Log Details.
    **/

	if (!defined('BASEPATH'))
		exit('No direct script access allowed');

	class Log_model extends CI_Model 
	{
		public function __construct() 
		{
			parent::__construct();
		}
		
		/**
		  * Function to Insert Log Details in rlb_logs table.
		  * @param array containing all Log Details
		  * @return 
		**/
		public function writeLog($arrLogDetails)
		{
			$this->db->insert('rlb_logs',$arrLogDetails);
		}
		
		/**
		  * Function to Delete Custom Program Log Entries those are older than 30 days.
		  * @param 
		  * @return 
		**/
		public function deleteCustomProgramLog()
		{
			/* $query = $this->db->select("*")->from("rlb_custom_program_log")->where("`device_stop` + INTERVAL 30 DAY <= NOW()")->order_by("id", "desc")->get(); 
			
			if($query->num_rows() > 0)
			{
				echo $this->db->last_query();
			} */
			
			$this->db->where("`device_stop` + INTERVAL 30 DAY <= NOW()");
			$this->db->delete('rlb_custom_program_log'); 
			//SELECT * FROM rlb_custom_program_log WHERE `device_stop` + INTERVAL 30 DAY <= NOW() ORDER BY `id` DESC 
		}
		
		
		/**
		  * Function to Delete Web Services Log Entries those are older than 30 days.
		  * @param 
		  * @return 
		**/
		public function deleteWebServiceLog()
		{
			$this->db->where("`ServiceDateTime` + INTERVAL 30 DAY <= NOW()");
			$this->db->delete('rlb_logs'); 
		}
		
	}
	
	
	

/* End of file log_model.php */
/* Location: ./application/models/log_model.php */