<?php
	
	/**
    * @Programmer: Dhiraj S.
    * @Created: 14 Mar 2017
    * @Modified: 
    * @Description: Configuration Model for working with Relayboard Configurations.
    **/

	if (!defined('BASEPATH'))
		exit('No direct script access allowed');

	class Configuration_model extends CI_Model 
	{
		public function __construct() 
		{
			parent::__construct();
		}
		
		/**
		  * Function to Run the queries.
		  * @param Query
		  * @return 
		**/
		public function RunQuery($Query)
		{
			$this->db->query($Query);
		}
		
		/**
		  * Function to Get All device Details.
		  * @param 
		  * @return Array containing Device Details
		**/
		public function AllDevicesForConfiguration($IP)
		{
			$this->db->select("*");
			$DeviceType = array('T', 'PS');
			$this->db->where_in('device_type', $DeviceType);
			$this->db->where('ip_id', $IP);
			//$this->db->where('device_type', 'T');
			$Query  = $this->db->get("rlb_device");
			
			if($Query->num_rows() > 0)
			{
				return $Query->result();
			}
			
			return '';
		}
		
		/**
		  * Function to Save Local IP address of Board.
		  * @param $IP
		  * @return Array containing Device Details
		**/
		public function SaveLocalIP($IP)
		{
			$arrInsert = array('ip'=>$IP,'name'=>'Board 1','status'=>'1','local_port'=>'2222');
		}
		
		public function SaveLocalIPProperty($ArrPostData)
		{
			$this->db->truncate('rlb_board_ip');
			
			$Board1IP 	= $ArrPostData['Board1IP'];
			$Board2IP 	= $ArrPostData['Board2IP'];
			$Board1Name = $ArrPostData['Board1Name'];
			$Board2Name = $ArrPostData['Board2Name'];
			$Board1Port = $ArrPostData['Board1Port'];
			$Board2Port = $ArrPostData['Board2Port'];
			
			if($Board1Name == '')
				$Board1Name = "Board 1";
			if($Board2Name == '')
				$Board2Name = "Board 2";	
			
			$ArrInsertBoard1  = array('ip'=>$Board1IP,'name'=>$Board1Name,'status'=>'1','local_port'=>$Board1Port); 
			$ArrInsertBoard2  = array('ip'=>$Board2IP,'name'=>$Board2Name,'status'=>'1','local_port'=>$Board2Port); 
			
			$this->db->insert('rlb_board_ip',$ArrInsertBoard1);
			$this->db->insert('rlb_board_ip',$ArrInsertBoard2);
		}
		
		public function SaveRelayForValve($ValveID,$Relay1,$Relay2,$IpID)
		{
			$this->db->select('device_id');
			$this->db->where(array('device_number'=>$sDeviceID,'device_type'=>'V','ip_id'=>$ipID));
			$QueryCheckDevice = $this->db->get('rlb_device');
			$ArrDeviceRelays = array('Relay1'=>$Relay1,'Relay2'=>$Relay2);
			
			if($QueryCheckDevice->num_rows() > 0)
			{
				foreach($QueryCheckDevice->result() as $Result)
				{
					$this->db->where('device_id',$Result->device_id);
					$ArrUpdateData = array('valve_relay_number'=>serialize($aRelays),'last_updated_date'=>date('Y-m-d H:i:s'));
					$this->db->update('rlb_device',$ArrUpdateData);
				}
			}
			else
			{
				$ArrInsertData = array('device_number' => $sDeviceID,
									   'device_type' => 'V',
									   'valve_relay_number' => serialize($aRelays),
									   'last_updated_date'=>date('Y-m-d H:i:s'),
									   'ip_id'=>$IpID);
				$this->db->insert('rlb_device',$ArrInsertData);					   
			}
			
			$this->db->where('device_type', 'V');
			$this->db->where('valve_relay_number', '');
			$this->db->where('ip_id', $IpID);
			$this->db->delete('rlb_device'); 
			
		}
	}
/* End of file configuration_model.php */
/* Location: ./application/models/configuration_model.php */