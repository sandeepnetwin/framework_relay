<?php
	@session_start();
	$strTitle = isset($Title) && $Title != '' ?  $Title :'Dashboard'  ;  
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">
	<link rel="shortcut icon" href="<?php echo HTTP_CSS_PATH; ?>favicon.png">
    <title>Relay Board <?php echo '- '.$strTitle;?></title>
   <!-- main JS libs -->
	<script src="<?php echo HTTP_JS_PATH; ?>libs/jquery-1.10.2.min.js"></script>
	<script src="<?php echo HTTP_JS_PATH; ?>libs/jquery-ui.min.js"></script>
	<script src="<?php echo HTTP_JS_PATH; ?>libs/bootstrap.min.js"></script>

	<!-- Style CSS -->
	<link href="<?php echo HTTP_CSS_PATH; ?>bootstrap.css" media="screen" rel="stylesheet">
	<link href="<?php echo HTTP_ASSETS_PATH; ?>style.css" media="screen" rel="stylesheet">

	<!-- General Scripts -->
	<script src="<?php echo HTTP_JS_PATH; ?>general.js"></script>

	<!-- custom input -->
	<script src="<?php echo HTTP_JS_PATH; ?>jquery.customInput.js"></script>
  
	<link rel="stylesheet" href="<?php echo HTTP_CSS_PATH; ?>chosen.css">
	<script src="<?php echo HTTP_JS_PATH; ?>chosen.jquery.min.js" type="text/javascript"></script>
	<script type="text/javascript" src="<?php echo HTTP_JS_PATH; ?>jquery.powerful-placeholder.min.js"></script>
	
	<script>
		jQuery(document).ready(function($) {
			if($("[placeholder]").size() > 0) {
				$.Placeholder.init();
			}
			
			var pull 		= $('#pull');
				menu 		= $('nav ul');
				menuHeight	= menu.height();

			$(pull).on('click', function(e) {
				e.preventDefault();
				menu.slideToggle();
			});

			$(window).resize(function(){
        		var w = $(window).width();
        		if(w > 320 && menu.is(':hidden')) {
        			menu.removeAttr('style');
        		}
    		});
		});
		
	</script>
  </head>
<body>
    <?php
    $pg = isset($page) && $page != '' ?  $page :'home'  ;    
    ?>

    <div class="body-wrap">
    <div class="content">
        <!--container-->
        <div class="container">
		<div class="row">
                <div class="col-sm-12">
				    <!-- Website Menu -->
                    <ul class="menu style2 boxed clearfix">
                        <li <?php if($pg == 'home') {echo 'class="customHover"';}?>><a href="<?php echo base_url();?>"><img src="<?php echo HTTP_IMAGES_PATH.'icons/home.png';?>" width="24" style="vertical-align: middle !important;" alt="Home"> Home</a></li>
                        <li <?php if($pg == 'setting') {echo 'class="customHover"';}?>>
                            <a href="<?php echo base_url('home/setting/');?>"><img src="<?php echo HTTP_IMAGES_PATH.'icons/setting.png';?>" width="24" style="vertical-align: middle !important;" alt="Settings"> Settings</a>
                        </li>
                        <li <?php if($pg == 'device') {echo 'class="customHover"';}?>>
                            <a href="<?php echo base_url('home/PoolSpaSetting/');?>"><img src="<?php echo HTTP_IMAGES_PATH.'icons/device.png';?>" width="24" style="vertical-align: middle !important;" alt="Relay/Device">Pool & Spa</a>
						</li>
                        <li <?php if($pg == 'status') {echo 'class="customHover"';}?>>
                            <a href="<?php echo base_url('home/systemStatus/');?>"><img src="<?php echo HTTP_IMAGES_PATH.'icons/info.png';?>" width="24" style="vertical-align: middle !important;" alt="Status"> Status</a>
                        </li>
                        <li <?php if($pg == 'log') {echo 'class="customHover"';}?>><a href="<?php echo base_url('home/getLogDetails'); ?>" ><img src="<?php echo HTTP_IMAGES_PATH.'icons/log.png';?>" width="24" style="vertical-align: middle !important;"> Log</a></li>
                        <li><a href="<?php echo base_url('dashboard/logout'); ?>"><img src="<?php echo HTTP_IMAGES_PATH.'icons/logout.png';?>" width="24" style="vertical-align: middle !important;" alt="Logout"> Logout</a></li>
                    </ul>
                    <!--/ Website Menu -->
                </div>
            </div>
            <!--/ row -->
            