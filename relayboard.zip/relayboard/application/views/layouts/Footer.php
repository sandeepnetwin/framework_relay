	<hr />
     <footer>
     <p style="text-align:center; color:#FFF;">&nbsp; &copy; <?php echo date('Y') ?> Crystal Properties & Investments, Inc. All rights reserved. </p>
     </footer>
     
    <!-- Placed at the end of the document so the pages load faster -->
    </div><!-- /#container -->
     </div><!-- /.content -->
    </div><!-- /.body-wrap --> 
  </body>
</html>