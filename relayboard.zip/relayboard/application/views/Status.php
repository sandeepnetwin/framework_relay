<?php
$BoardNumber = (int)$this->home_model->getBoardNumber();
$sAccess 		= '';
$sModule	    = 13;

  //Get Permission Details
  $userID = $this->session->userdata('id');
  $aPermissions = json_decode(getPermissionOfModule($userID));
 
  $aModules 		= $aPermissions->sPermissionModule;	
  $aAllActiveModule = $aPermissions->sActiveModule;
  
  $sAccessKey	= 'access_'.$sModule;
			  
  if(!empty($aModules))
  {
	  if(in_array($sModule,$aModules->ids))
	  {
		 $sAccess 		= $aModules->$sAccessKey;
	  }
	  else if(!in_array($sModule,$aModules->ids)) 
	  {
		$sAccess 		= '0'; 
	  }
  }
  
  if($sAccess == '')
	$sAccess = '2' ; 
  
  if($sAccess == '0') {redirect(site_url('home/'));}
  


$aName      = array('ID','SEQ','MODE','DOW','WCK','RTC','ERR','VLV','RLY','PCN','AP0','AP1',
                    'AP2','AP3','APS','TS0','TS1','TS2','TS3','TS4','TS5','LVI','RSC','LVA',
                    'PM0','PM1','PM2');

$aDesc      = array('Record identifier','Sequence number that runs from 000 ... 255','Mode',
                    'Day of week (0 – Sunday ... 6 – Saturday)','Wall clock (24 hour clock)',
                    'RTC status','HEX',
                    'Valve status, a ‘.’ indicates the valve is not configured',
                    'Relay status, a ‘.’ indicates the output is assigned to a valve',
                    'Power center status','Analog input 0','Analog input 1','Analog input 2','Analog input 3',
                    'DC supply voltage','Temperature sensor 0 / Controller temperature','Temperature sensor 1',
                    'Temperature sensor 2','Temperature sensor 3','Temperature sensor 4','Temperature sensor 5',
                    'Level measurement [inch] instant','Remote Spa Control and digital input status','Level measurement [inch] average',
                    'Status of pump sequencer 0','Status of pump sequencer 1','Status of pump sequencer 2');
					
	$sResponse		=	'';
	$iFirstIPId		=	'';	
	$sDescription  	=	'';
	
	if($sBoard != '')
		$iFirstIPId		=	$sBoard;
?>
<style>
.fancybox-inner 
	{
		height:40px !important;
	}
	
	.navbar-toggle {
		background-color: transparent !important;
		background-image: none !important;
		border: 1px solid transparent !important;
		border-radius: 4px !important;
		float: left !important;
		margin-bottom: 8px !important;
		margin-right: 15px !important;
		margin-top: 8px !important;
		padding: 9px 10px !important;
		position: relative !important;
	}
	
	.navbar-toggle .icon-bar {
		border-radius: 1px !important;
		display: block !important;
		height: 2px !important;
		width: 22px !important;
	}
</style>
<script type="text/javascript" src="<?php echo HTTP_ASSETS_PATH.'fancybox/source/jquery.fancybox.js?v=2.1.5';?>"></script>
<link rel="stylesheet" type="text/css" href="<?php echo HTTP_ASSETS_PATH.'fancybox/source/jquery.fancybox.css?v=2.1.5';?>" media="screen" />
<script type="text/javascript">
//var $a = $.noConflict();
$(document).ready(function() {
	$('.fancybox').fancybox({'closeBtn' : false,'helpers': {'overlay' : {'closeClick': false}}
	});
	
	setInterval( function() 
	{
		var IPID = $("#IpId").val();
		$.ajax({
				type: "POST",
				url: "<?php echo site_url('home/getSystemStatusAjax/');?>", 
				data: {IPID:IPID},
				success: function(response)
				{
					var obj = $.parseJSON(response);
					$("#boardStatus_"+IPID).html(obj.real);
					$("#responseDetails_"+IPID).html(obj.description);
				}
		});
		
	},30000);
	
	$("#link-refresh-real").click(function(){
		$("#checkLink").trigger('click');
		var IPID = $("#IpId").val();
		$.ajax({
				type: "POST",
				url: "<?php echo site_url('home/getSystemStatusAjax/');?>", 
				data: {IPID:IPID},
				success: function(response)
				{
					var obj = $.parseJSON(response);
					$("#boardStatus_"+IPID).html(obj.real);
					$("#responseDetails_"+IPID).html(obj.description);
					parent.$.fancybox.close();
				}
		});
	});
	
	$("#link-refresh-details").click(function(){
		var IPID = $("#IpId").val();
		$("#checkLink").trigger('click');
		$.ajax({
				type: "POST",
				url: "<?php echo site_url('home/getSystemStatusAjax/');?>", 
				data: {IPID:IPID},
				success: function(response)
				{
					var obj = $.parseJSON(response);
					$("#boardStatus_"+IPID).html(obj.real);
					$("#responseDetails_"+IPID).html(obj.description);
					parent.$.fancybox.close();
				}
		});
	});
});

</script>	

    <div class="row">
	  <div class="col-lg-12">
		<ol class="breadcrumb">
		  <li><img src="<?php echo HTTP_IMAGES_PATH.'icons/home.png';?>" width="24" style="vertical-align: middle !important;">&nbsp;<a href="<?php echo site_url();?>">Home</a> </li>
		  <li class="active">System Status</li>
		</ol>
	  </div>
	</div><!-- /.row -->
	
	<div class="row">
		<div class="col-lg-12">
		<span style="color:#FFF; font-weight:bold;">Select Board : </span>
		<select id="selBoard" name="selBoard" onchange="showBoardDetails(this.value);">
			<option value="">--IP(Name)--</option>
			<?php if(!empty($aIPDetails))
					{
						foreach($aIPDetails as $IP)
						{
							//First IP ID to show selected.
							if($iFirstIPId == '')
								$iFirstIPId = $IP->id;
							
							$sDetails	=	$IP->ip;
							if($IP->name != '')
							{
								$sDetails .= ' ('.$IP->name.')';
							}
							
							$sShow	=	'display:none';
							if($iFirstIPId == $IP->id)
							{ 
								$sShow	=	'';
							} 
							
							//Real Response.
							$sResponse	.=	'<p id="boardStatus_'.$IP->id.'" style="word-wrap: break-word; color:#C9376E; font-weight:bold;'.$sShow.'">'.${"response_".$IP->id}.'</p>';	
							
							$aResponse	= explode(',',${"response_".$IP->id});
							$cntRows	= count($aResponse);	
							
							$sDescription.= '<tbody id="responseDetails_'.$IP->id.'" style="'.$sShow.'">';
							//Response Details.
							for($i=0; $i<$cntRows; $i++)
							{
								  $sRes   = '';
								  $sDesc  = '';

								  if(preg_match('/TS/',$aName[$i]) && $aResponse[$i] == '')
									$sRes = '0F';
								  else
									$sRes = $aResponse[$i];

								  if($aDesc[$i] == 'HEX')
								  {
									  $sDesc  = '<strong>Hex error status :</strong><br>
												<table class="table table-hover" style="width: 80%;">
												  <thead>
													<tr>
													  <th class="header">Bit</th>
													  <th class="header">Hex</th>
													  <th class="header">Description</th>
													</tr>
												  </thead>
												  <tbody>
													<tr>
													  <td>0</td>
													  <td>01</td>
													  <td>One Wire Bus (temperature sensors)</td>
													</tr>
													<tr>  
													  <td>1</td>
													  <td>02</td>
													  <td>Wall clock</td>
													</tr>
													<tr>  
													  <td>2</td>
													  <td>04</td>
													  <td>Level measurement</td>
													</tr>
													<tr>  
													  <td>3</td>
													  <td>08</td>
													  <td>I2C Bus</td>
													</tr>
													<tr>  
													  <td>4</td>
													  <td>10</td>
													  <td>24VAC feed</td>
													</tr>
													<tr>    
													  <td>5</td>
													  <td>20</td>
													  <td>TBA</td>
													</tr>
													<tr>  
													  <td>6</td>
													  <td>40</td>
													  <td>TBA</td>
													</tr>
													<tr>  
													  <td>7</td>
													  <td>80</td>
													  <td>TBA</td>
													</tr>
												  </tbody>
												</table>
												 ';
								  }  
								  else
									$sDesc =   $aDesc[$i];
								
								if($aName[$i] == 'ERR')	
								{
									$sDescription.= '<tr>
										<td>'.$i.'</td>
										<td>'.$aName[$i].'</td>
										<td colspan="2">'.$sRes.'</td>
										</tr>';
									
									$sDescription.='<tr>
										<td colspan="4">'.$sDesc.'</td>
										</tr>'; 							
								}
								else
								{
								  $sDescription.= '<tr>
										<td>'.$i.'</td>
										<td>'.$aName[$i].'</td>
										<td><div id="morris-chart-area"><p style="word-wrap: break-word;">'.$sRes.'</p></div></td>
										<td><p style="word-wrap: break-word;">'.$sDesc.'</p></td>
										</tr>';
								}
							}
							$sDescription.= '</tbody>';
			?>
							<option value="<?php echo $IP->id;?>" <?php if($iFirstIPId == $IP->id){ echo 'selected="selected"';} ?>><?php echo $sDetails;?></option>
			<?php		}
					}
					
			?>		
		</select>	
		</div>
	</div>  
	
	<div class="row"><div class="col-lg-12">&nbsp;</div></div>	
	
	<div class="row">
	  <div class="col-sm-4">
		<div class="widget-container widget-stats boxed green-line">
			<div class="widget-title">
				<a href="javascript:void(0);" class="link-refresh" id="link-refresh-real"><span class="glyphicon glyphicon-refresh"></span></a>
				<h3>Real Response</h3>
			</div>
			<div class="stats-content clearfix">
				<div class="stats-content-right" style="width:96% !important; margin-left:5px; margin-right:5px; margin-top:10px; float:none;" id="link-refresh-real-details">
				<?php echo $sResponse; ?>			
				</div>
			</div>
		</div>
	</div>
	  
	  <div class="col-sm-8">
			<!-- Statistics -->
			<div class="widget-container widget-stats boxed green-line">
				<div class="widget-title">
					<a href="javascript:void(0);" class="link-refresh" id="link-refresh-details"><span class="glyphicon glyphicon-refresh"></span></a>
					<h3>System Response Details</h3>
				</div>
				<div class="stats-content clearfix">
					<div class="stats-content-right" style="width:100% !important; margin-left:5px; margin-right:5px; float:none;">
					<table class="table table-hover">
					  <thead>
						<tr>
						  <th class="header">Field</th>
						  <th class="header">Name</th>
						  <th class="header">Status</th>
						  <th class="header">Description</th>
						</tr>
					  </thead>
					   <?php echo $sDescription;?>
					  </table>
					</div>
				</div>
			</div>
			<!--/ Statistics -->
		</div>
	</div><!-- /.row -->
        
    
<script type="text/javascript">
function showBoardDetails(board)
{
	if(board == '')
	{
		alert("Please select IP first!");
		return false;
	}
	
	$("#IpId").val(board);
	$("#checkLink").trigger('click');
	var IpId = $("#IpId").val();
	location.href='<?php echo base_url('home/systemStatus');?>'+'/'+Base64.encode(IpId);
	/* $.ajax({
				type: "POST",
				url: "<?php echo site_url('home/getRealResponse/');?>", 
				data: {sIdIP:board},
				success: function(data) {
					var Obj = $.parseJSON(data);
					$("[id^='boardStatus_']").hide();
					$("[id^='responseDetails_']").hide();
					
					$("#boardStatus_"+board).html(Obj.response);
					$("#responseDetails_"+board).html(Obj.description);
					
					$("#boardStatus_"+board).show();
					$("#responseDetails_"+board).show();
					
					parent.$.fancybox.close();
				}
			}); */
	//boardStatus_2
	//responseDetails_2
}
</script>

<input type="hidden" id="IpId" value="<?php echo $iFirstIPId;?>">
<a class="fancybox" id="checkLink" href="#inline1" style="display:none;">&nbsp;</a>
<div id="inline1" style="text-align:center !important; display:none;"><img src="<?php echo HTTP_ASSETS_PATH.'images/loading.gif';?>" width="32" alt="loading..."></div>