<?php
$sAccess 		= '';
$sModule	    = 13;

  //Get Permission Details
  $userID = $this->session->userdata('id');
  $aPermissions = json_decode(getPermissionOfModule($userID));
 
  $aModules 		= $aPermissions->sPermissionModule;	
  $aAllActiveModule = $aPermissions->sActiveModule;
  
  $sAccessKey	= 'access_'.$sModule;
			  
  if(!empty($aModules))
  {
	  if(in_array($sModule,$aModules->ids))
	  {
		 $sAccess 		= $aModules->$sAccessKey;
	  }
	  else if(!in_array($sModule,$aModules->ids)) 
	  {
		$sAccess 		= '0'; 
	  }
  }
  
  if($sAccess == '')
	$sAccess = '2' ; 
  
  if($sAccess == '0') {redirect(site_url('home/'));}
$aResponse  = explode(',', $response);
$cntRows    = count($aResponse);

$aName      = array('ID','SEQ','MODE','DOW','WCK','RTC','ERR','VLV','RLY','PCN','AP0','AP1',
                    'AP2','AP3','APS','TS0','TS1','TS2','TS3','TS4','TS5','LVI','RSC','LVA',
                    'PM0','PM1','PM2');

$aDesc      = array('Record identifier','Sequence number that runs from 000 ... 255','Mode',
                    'Day of week (0 – Sunday ... 6 – Saturday)','Wall clock (24 hour clock)',
                    'RTC status','HEX',
                    'Valve status, a ‘.’ indicates the valve is not configured',
                    'Relay status, a ‘.’ indicates the output is assigned to a valve',
                    'Power center status','Analog input 0','Analog input 1','Analog input 2','Analog input 3',
                    'DC supply voltage','Temperature sensor 0 / Controller temperature','Temperature sensor 1',
                    'Temperature sensor 2','Temperature sensor 3','Temperature sensor 4','Temperature sensor 5',
                    'Level measurement [inch] instant','Remote Spa Control and digital input status','Level measurement [inch] average',
                    'Status of pump sequencer 0','Status of pump sequencer 1','Status of pump sequencer 2');
?>

    <div class="row">
	  <div class="col-lg-12">
		<ol class="breadcrumb">
		  <li><img src="<?php echo HTTP_IMAGES_PATH.'icons/home.png';?>" width="24" style="vertical-align: middle !important;">&nbsp;<a href="<?php echo site_url();?>">Home</a> </li>
		  <li class="active">System Status</li>
		</ol>
	  </div>
	</div><!-- /.row -->
	<div class="row">
	  
	  <div class="col-sm-4">
		<div class="widget-container widget-stats boxed green-line">
			<div class="widget-title">
				<a href="<?php echo base_url('home/setting/'.$sDevice.'/');?>" class="link-refresh" id="link-refresh-1"><span class="glyphicon glyphicon-refresh"></span></a>
				<h3>Real Response</h3>
			</div>
			<div class="stats-content clearfix">
				<div class="stats-content-right" style="width:96% !important; margin-left:5px; margin-right:5px; margin-top:10px; float:none;">
				<p style="word-wrap: break-word; color:#C9376E; font-weight:bold;"><?php echo $response; ?></p>
				</div>
			</div>
		</div>
	</div>
	  
	  <div class="col-sm-8">
			<!-- Statistics -->
			<div class="widget-container widget-stats boxed green-line">
				<div class="widget-title">
					<a href="<?php echo base_url('home/systemStatus/');?>" class="link-refresh" id="link-refresh-1"><span class="glyphicon glyphicon-refresh"></span></a>
					<h3>System Response Details</h3>
				</div>
				<div class="stats-content clearfix">
					<div class="stats-content-right" style="width:100% !important; margin-left:5px; margin-right:5px; float:none;">
					<table class="table table-hover">
					  <thead>
						<tr>
						  <th class="header">Field</th>
						  <th class="header">Name</th>
						  <th class="header">Status</th>
						  <th class="header">Description</th>
						</tr>
					  </thead>
					   <tbody>
					  <?php
						  
						  for($i=0; $i<$cntRows; $i++)
						  {
							  $sRes   = '';
							  $sDesc  = '';

							  if(preg_match('/TS/',$aName[$i]) && $aResponse[$i] == '')
								$sRes = '0F';
							  else
								$sRes = $aResponse[$i];

							  if($aDesc[$i] == 'HEX')
							  {
								  $sDesc  = '<strong>Hex error status :</strong><br>
											<table class="table table-hover" style="width: 80%;">
											  <thead>
												<tr>
												  <th class="header">Bit</th>
												  <th class="header">Hex</th>
												  <th class="header">Description</th>
												</tr>
											  </thead>
											  <tbody>
												<tr>
												  <td>0</td>
												  <td>01</td>
												  <td>One Wire Bus (temperature sensors)</td>
												</tr>
												<tr>  
												  <td>1</td>
												  <td>02</td>
												  <td>Wall clock</td>
												</tr>
												<tr>  
												  <td>2</td>
												  <td>04</td>
												  <td>Level measurement</td>
												</tr>
												<tr>  
												  <td>3</td>
												  <td>08</td>
												  <td>I2C Bus</td>
												</tr>
												<tr>  
												  <td>4</td>
												  <td>10</td>
												  <td>24VAC feed</td>
												</tr>
												<tr>    
												  <td>5</td>
												  <td>20</td>
												  <td>TBA</td>
												</tr>
												<tr>  
												  <td>6</td>
												  <td>40</td>
												  <td>TBA</td>
												</tr>
												<tr>  
												  <td>7</td>
												  <td>80</td>
												  <td>TBA</td>
												</tr>
											  </tbody>
											</table>
											 ';
							  }  
							  else
								$sDesc =   $aDesc[$i];
							
							if($aName[$i] == 'ERR')	
							{
								echo '<tr>
									<td>'.$i.'</td>
									<td>'.$aName[$i].'</td>
									<td colspan="2">'.$sRes.'</td>
									</tr>';
								
								echo '<tr>
									<td colspan="4">'.$sDesc.'</td>
									</tr>'; 							
							}
							else
							{
							  echo '<tr>
									<td>'.$i.'</td>
									<td>'.$aName[$i].'</td>
									<td><div id="morris-chart-area"><p style="word-wrap: break-word;">'.$sRes.'</p></div></td>
									<td><p style="word-wrap: break-word;">'.$sDesc.'</p></td>
									</tr>';
							}
						  }
					  ?>
					 
					  </tbody>
					  </table>
					</div>
				</div>
			</div>
			<!--/ Statistics -->
		</div>
	</div><!-- /.row -->
        
    
<script type="text/javascript">
</script>

<?php

?>