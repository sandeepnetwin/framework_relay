<?php
    /**
    * @Programmer: Dhiraj S.
    * @Created: 18 April 2017
    * @Modified: 
    * @Description: Relayboard related Notification(SD card Storage Details, IP change details).
    **/
?>
<script type="text/javascript" src="<?php echo HTTP_JS_PATH; ?>snap.svg-min.js"></script>

<link href="<?php echo HTTP_CSS_PATH; ?>piechart.css" media="screen" rel="stylesheet">
<script src="<?php echo HTTP_JS_PATH; ?>piechart.js"></script>
    <div id="page-wrapper">

        <div class="row">
			  <div class="col-lg-12">
				<ol class="breadcrumb">
						  <li><img src="<?php echo HTTP_IMAGES_PATH.'icons/home.png';?>" width="24" style="vertical-align: middle !important;">&nbsp;<a href="<?php echo site_url();?>">Home</a> </li>
						  <li class="active">Notification</li>
				</ol>
			 
            
			</div>
		</div>
        <!-- /.row -->
        <div class="row">
          <div class="col-lg-6 pie">
		  
			<!-- SD card information block -->
            <div class="panel panel-primary">
              <div class="panel-heading" style="border-top-left-radius: 0px;border-top-right-radius: 0px;">
                <h3 class="panel-title" style="color:#FFF;">SD Card Details</h3>
              </div>
              <div class="panel-body">
                <div id="morris-chart-area">
                   <?php //echo "<pre>$sdcommandReponse</pre>" ?>
				   
				   <!-- pie chart code is added here -->
				   <div class="row">
				   <div class="col-md-12" style="text-align:center">
				  <ul data-pie-id="svg">
					<li data-value="<?php echo $used_space ?>">Used <?php echo $used_space ?> GB</li>
					<li data-value="<?php echo $free_space ?>">Free <?php echo $free_space ?> GB</li> 
				  </ul>
				</div>
				</div>
				
				<div class="row">
				<div class="col-md-12">
				  <div id="svg"></div>
				</div>  
				</div>   
				   <!-- end pie chart code -->
				   
				
                </div>
              </div>
            </div>
			<!-- End SD card information block -->
          </div>
        </div><!-- /.row -->
      </div><!-- /#page-wrapper -->

