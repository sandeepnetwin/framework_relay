<?php
$this->load->model('home_model');
$sAccess 		= '';
$sModule	    = '';
$sDeviceFullName = '';

?>
<script type="text/javascript" src="<?php echo HTTP_ASSETS_PATH.'fancybox/source/jquery.fancybox.js?v=2.1.5';?>"></script>
<link rel="stylesheet" type="text/css" href="<?php echo HTTP_ASSETS_PATH.'fancybox/source/jquery.fancybox.css?v=2.1.5';?>" media="screen" />
<?php if($sDevice != 'V') { ?>
<script type="text/javascript">
var $a = $.noConflict();
$a(document).ready(function() {
	$a('.fancybox').fancybox({'closeBtn' : false,'helpers': {'overlay' : {'closeClick': false}}
	});
});
</script>
<?php } ?>	
<link href="<?php echo HTTP_ASSETS_PATH.'progressbar/css/static.css';?>" rel="stylesheet"/>
<script src="<?php echo HTTP_ASSETS_PATH.'progressbar/js/static.min.js';?>"></script>
<script src="<?php echo HTTP_ASSETS_PATH.'progressbar/dist/js/jquery.progresstimer.js';?>"></script>


<script type="text/javascript">
jQuery(document).ready(function($) {
	$(".relayButton").click(function()
	{
		//$a('.fancybox').fancybox();
		<?php if($iActiveMode == '2') { ?>
		$(".loading-progress").show();
		var progress = $(".loading-progress").progressTimer({
			timeLimit: 10,
			onFinish: function () {
			  //$(".loading-progress").hide();
			  parent.$a.fancybox.close();
			}
		});
		
		$a("#checkLink").trigger('click');
		
		
		//$a('.fancybox-inner').height(450);
		//$a.fancybox.reposition();
		
		var relayNumber = $(this).val();
		var status		= '';
		if($("#lableRelay-"+relayNumber).hasClass('checked'))
		{	
			status	=	0;
		}
		else
		{
			status = 1;
		}
		
		
		 $.ajax({
			type: "POST",
			url: "<?php echo site_url('home/updateStatusOnOff/');?>", 
			data: {sName:relayNumber,sStatus:status,sDevice:'R'},
			success: function(data) {
				if($("#lableRelay-"+relayNumber).hasClass('checked'))
				{	
					$("#lableRelay-"+relayNumber).removeClass('checked');
				}
				else
				{
					$("#lableRelay-"+relayNumber).addClass('checked');
				}
				
			}
		}).error(function(){
        progress.progressTimer('error', {
            errorText:'ERROR!',
            onFinish:function(){
                alert('There was an error processing your information!');
            }
        });
		}).done(function(){
			progress.progressTimer('complete');
		});
		 <?php } else {  ?>
		  alert('You can perform this operation in manual mode only.');
		 <?php } ?> 
	});
	
	$(".powerButton").click(function()
	{
		<?php if($iActiveMode == '2') { ?>
		 $(".loading-progress").show();
		var progress = $(".loading-progress").progressTimer({
			timeLimit: 10,
			onFinish: function () {
			  //$(".loading-progress").hide();
			  parent.$a.fancybox.close();
			}
		});
		
		$a("#checkLink").trigger('click');
		
		
		var relayNumber = $(this).val();
		var status		= '';
		if($("#lablePower-"+relayNumber).hasClass('checked'))
		{	
			status	=	0;
		}
		else
		{
			status = 1;
		}
		
		
		 $.ajax({
			type: "POST",
			url: "<?php echo site_url('home/updateStatusOnOff/');?>", 
			data: {sName:relayNumber,sStatus:status,sDevice:'P'},
			success: function(data) {
				if($("#lablePower-"+relayNumber).hasClass('checked'))
				{	
					$("#lablePower-"+relayNumber).removeClass('checked');
				}
				else
				{
					$("#lablePower-"+relayNumber).addClass('checked');
				}
				
			}
		}).error(function(){
        progress.progressTimer('error', {
            errorText:'ERROR!',
            onFinish:function(){
                alert('There was an error processing your information!');
            }
        });
		}).done(function(){
			progress.progressTimer('complete');
		});
		 <?php } else {  ?>
		  alert('You can perform this operation in manual mode only.');
		 <?php } ?> 
	});
	
	$(".pumpsButton").click(function()
	{
		<?php if($iActiveMode == '2') { ?>
		$(".loading-progress").show();
		var progress = $(".loading-progress").progressTimer({
			timeLimit: 10,
			onFinish: function () {
			  //$(".loading-progress").hide();
				setTimeout(function(){location.reload();parent.$a.fancybox.close();},1000);
				
			}
		});
		
		$a("#checkLink").trigger('click');
		
		var relayNumber = $(this).val();
		var status		= '';
		if($("#lablePump-"+relayNumber).hasClass('checked'))
		{	
			status	=	0;
		}
		else
		{
			status = 1;
		}
		
		<?php //if($iActiveMode == '2') { ?>
		 $.ajax({
			type: "POST",
			url: "<?php echo site_url('home/updateStatusOnOff/');?>", 
			data: {sName:relayNumber,sStatus:status,sDevice:'PS'},
			success: function(data) {
				
				if($("#lablePump-"+relayNumber).hasClass('checked'))
				{	
					$("#lablePump-"+relayNumber).removeClass('checked');
				}
				else
				{
					$("#lablePump-"+relayNumber).addClass('checked');
				}
				
				
				
			}
		}).error(function(){
        progress.progressTimer('error', {
            errorText:'ERROR!',
            onFinish:function(){
                alert('There was an error processing your information!');
            }
        });
		}).done(function(){
			progress.progressTimer('complete');
		});
		 <?php } else {  ?>
		  alert('You can perform this operation in manual mode only.');
		  
		 <?php } ?> 
	});
	
	$(".lightButton").click(function(){
        var chkVal      = $(this).val();
        var arrDetails	= chkVal.split("|||");	
        
        var lightNumber = arrDetails[0];
        var relayNumber = arrDetails[2];
        var sDevice     = '';
        
        if(arrDetails[1] == '24')
            sDevice     =   'R';    
        else if(arrDetails[1] == '12')
            sDevice     =   'P';
        
        <?php if($iActiveMode == '2') { ?>
        $(".loading-progress").show();
        var progress = $(".loading-progress").progressTimer({
                timeLimit: 10,
                onFinish: function () {
                    //$(".loading-progress").hide();
                    parent.$a.fancybox.close();
                }
        });
        
        
        $a("#checkLink").trigger('click');

        var status		= '';
        if($("#lableRelay-"+lightNumber).hasClass('checked'))
        {	
                status	=	0;
        }
        else
        {
                status = 1;
        }


            $.ajax({
                type: "POST",
                url: "<?php echo site_url('home/updateStatusOnOff/');?>", 
                data: {sName:relayNumber,sStatus:status,sDevice:sDevice},
                success: function(data) {
					if($("#lableRelay-"+lightNumber).hasClass('checked'))
					{	
						$("#lableRelay-"+lightNumber).removeClass('checked');
						 $("#lightImage_"+lightNumber).attr('src','<?php echo HTTP_IMAGES_PATH."icons/light_off.png";?>');
					}
					else
					{
						$("#lableRelay-"+lightNumber).addClass('checked');
						 $("#lightImage_"+lightNumber).attr('src','<?php echo HTTP_IMAGES_PATH."icons/light_on.png";?>');
						
					}

                }
        }).error(function(){
            progress.progressTimer('error', {
                errorText:'ERROR!',
                onFinish:function(){
                    alert('There was an error processing your information!');
                }
            });
        }).done(function(){
                progress.progressTimer('complete');
        });
            <?php } else {  ?>
            alert('You can perform this operation in manual mode only.');
            <?php } ?> 
    });
});
</script>
<p><a class="fancybox" id="checkLink" href="#inline1" style="display:none;">&nbsp;</a>
<div id="inline1" style="width:250px;height:40px; display:none;"><div class="loading-progress"></div></div></p>
    <div id="page-wrapper">

        <div class="row">
          <div class="col-lg-12">
            <ol class="breadcrumb" style="float:left;">
                <li><img src="<?php echo HTTP_IMAGES_PATH.'icons/home.png';?>" width="24" style="vertical-align: middle !important;">&nbsp;<a href="<?php echo site_url();?>">Home</a> </li>
                <li class="active">Spa Device</li>
            </ol>
				<ol class="breadcrumb" style="float:right;">
		  <li><a href="<?php echo base_url('home/setting/R/');?>">24V AC Relays</a></li>
		  <li><a href="<?php echo base_url('home/setting/P/');?>">12V DC Relays</a></li>
		  <li><a href="<?php echo base_url('home/setting/V/');?>">Valve</a></li>
		  <li><a href="<?php echo base_url('home/setting/PS/');?>">Pump</a></li>
		  <li><a href="<?php echo base_url('home/setting/T/');?>">Temperature Sensors</a></li>
		</ol>
            <?php if($sucess == '1') { ?>
              <div class="alert alert-success alert-dismissable">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                Details saved successfully! 
              </div>
            <?php } ?>
          </div>
        </div>
        <!-- /.row -->
        <div class="row">
        <?php //if($sDevice == 'R') 
		$sDevice                = 'R' ;
		$sDeviceFullName 	= '24V AC Relay';
		$sModule	    	= 2;
		
		$sAccessKey	= 'access_'.$sModule;
			  
		  if(!empty($aModules))
		  {
			  if(in_array($sModule,$aModules->ids))
			  {
				 $sAccess 		= $aModules->$sAccessKey;
			  }
		  }
	  
		if($sAccess == '')
			$sAccess = '2' ; 
	  
		if($sAccess == '0') {redirect(site_url('home/'));}
		
		{ //Relay Device Start  ?>
        
        <?php if($sAccess == '1' || $sAccess == '2') { ?> 
        
        <div class="col-sm-4">
            <div class="widget-container widget-stats boxed green-line">
            <div class="widget-title">
                    <a href="<?php echo base_url('home/PoolDevice');?>" class="link-refresh" id="link-refresh-1"><span class="glyphicon glyphicon-refresh"></span></a>
                    <h3>24V AC Relay ON/OFF</h3>
            </div>
            <div class="stats-content clearfix">
                    <div class="stats-content-right" style="width:96% !important; margin-left:5px; margin-right:5px; margin-top:10px; float:none;">
                            <?php
                                    $spaRelayDeviceCnt = 0;
                                    for ($i=0;$i < $relay_count; $i++)
                                    {
                                            $iRelayVal = $sRelays[$i];
                                            
                                            if($iRelayVal != '' && $iRelayVal !='.') 
                                            {
                                                    $strChecked	=	'';
                                                    if($iRelayVal == '1')
                                                            $strChecked	=	'class="checked"';

                                                    $sRelayNameDb =  $this->home_model->getDeviceName($i,$sDevice);
                                                    $strRelayName = 'Relay '.$i;
                                                    if($sRelayNameDb != '')
                                                            $strRelayName .= ' ('.$sRelayNameDb.')';
                                                    
                                                    $sMainType =	$this->home_model->getDeviceMainType($i,$sDevice);
                                                    if($sMainType == '2')
                                                    {
                                                        $spaRelayDeviceCnt++;
                            ?>      
                                                <div class="rowCheckbox switch">
                                                            <div class="custom-checkbox"><input type="checkbox" value="<?php echo $i;?>" id="relay-<?php echo $i?>" name="relay-<?php echo $i?>" class="relayButton" hidefocus="true" style="outline: medium none;">
                                                                    <label <?php echo $strChecked;?>  id="lableRelay-<?php echo $i?>" for="relay-<?php echo $i?>"><span style="color:#C9376E; float:right;"><?php echo $strRelayName;?></span></label>
                                                            </div>
                                                    </div>
                            <?php           
                                                    }
                                            }		
                                        }
                                        if($spaRelayDeviceCnt == 0)
                                        {
                                            echo '<div class="rowCheckbox switch"><span style="color:#C9376E; font-weight:bold;">No Device available!</span></div><div style="height:10px;">&nbsp;</div>';
                                        }
                            ?> 
                    </div>
            </div>
            </div>
        </div>
        
        <?php } ?>
        <?php } ?> <!-- END : Relay Device -->
        
        <?php //if($sDevice == 'P') 
		$sDevice            = 'P' 	;
		$sDeviceFullName = '12V DC Power Center Relay';
		$sModule	       = 3;
		
		$sAccessKey	= 'access_'.$sModule;
			  
		  if(!empty($aModules))
		  {
			  if(in_array($sModule,$aModules->ids))
			  {
				 $sAccess 		= $aModules->$sAccessKey;
			  }
		  }
	  
		if($sAccess == '')
			$sAccess = '2' ; 
	  
		if($sAccess == '0') {redirect(site_url('home/'));}	
	
		{  //Power center Device Start?>
		<?php if($sAccess == '1' || $sAccess == '2') 
			  { 
		?>
               
                    <div class="col-sm-4">
                            <div class="widget-container widget-stats boxed green-line">
                            <div class="widget-title">
                                    <a href="<?php echo base_url('home/PoolDevice');?>" class="link-refresh" id="link-refresh-1"><span class="glyphicon glyphicon-refresh"></span></a>
                                    <h3>12V DC Relays ON/OFF</h3>
                            </div>
                            <div class="stats-content clearfix">
                                    <div class="stats-content-right" style="width:96% !important; margin-left:5px; margin-right:5px; margin-top:10px; float:none;">
                                    <?php
                                                    $spaPowerDeviceCnt  =   0;
                                                    for ($i=0;$i < $power_count; $i++)
                                                    {
                                                            $iRelayVal = $sPowercenter[$i];

                                                            if($iRelayVal != '' && $iRelayVal !='.') 
                                                            {
                                                                    $strChecked	=	'';
                                                                    if($iRelayVal == '1')
                                                                            $strChecked	=	'class="checked"';

                                                                    $sRelayNameDb =  $this->home_model->getDeviceName($i,$sDevice);
                                                                    $strRelayName = 'PowerCenter '.$i;
                                                                    if($sRelayNameDb != '')
                                                                            $strRelayName .= ' ('.$sRelayNameDb.')';
                                                                    
                                                                    $sMainType =	$this->home_model->getDeviceMainType($i,$sDevice);
                                                                    if($sMainType == '2')
                                                                    {
                                                                        $spaPowerDeviceCnt++;
                                            ?>
                                                                <div class="rowCheckbox switch">
                                                                            <div class="custom-checkbox"><input type="checkbox" value="<?php echo $i;?>" id="power-<?php echo $i?>" name="power-<?php echo $i?>" class="powerButton" hidefocus="true" style="outline: medium none;">
                                                                                    <label <?php echo $strChecked;?>  id="lablePower-<?php echo $i?>" for="power-<?php echo $i?>"><span style="color:#C9376E; float:right;"><?php echo $strRelayName;?></span></label>
                                                                            </div>
                                                                    </div>
                                            <?php           
                                                                    }
                                                            }		
                                                        }
                                                        if($spaPowerDeviceCnt == 0)
                                                        {
                                                            echo '<div class="rowCheckbox switch"><span style="color:#C9376E; font-weight:bold;">No Device available!</span></div><div style="height:10px;">&nbsp;</div>';
                                                        }
                                            ?> 
                            </div>
                            </div>
                            </div>
                    </div>
               
        <?php } ?>
        <?php } ?> <!-- END : Power Center Device -->
       
        <?php //if($sDevice == 'V') 
		
		$sDevice            = 'V' 	;
		$sDeviceFullName 	= 'Valve';
		$sModule	       	= 8;
                $iValveNumber = $extra['ValveNumber'];
                
               $sAccessKey	= 'access_'.$sModule;
			  
		  if(!empty($aModules))
		  {
			  if(in_array($sModule,$aModules->ids))
			  {
				 $sAccess 		= $aModules->$sAccessKey;
			  }
		  }
	  
		if($sAccess == '')
			$sAccess = '2' ; 
	  
		if($sAccess == '0') {redirect(site_url('home/'));}
		
		{ // Valve Start ?>
		 <?php if($sAccess == '1' || $sAccess == '2') { ?>
		<link href="<?php echo site_url('assets/switchy/switchy.css'); ?>" rel="stylesheet" />
		<script type="text/javascript" src="<?php echo site_url('assets/switchy/switchy.js'); ?>"></script>
		<script type="text/javascript" src="<?php echo site_url('assets/switchy/jquery.event.drag.js'); ?>"></script>
		<script type="text/javascript" src="<?php echo site_url('assets/switchy/jquery.animate-color.js'); ?>"></script>
		<script>
		var iActiveMode = '<?php echo $iActiveMode;?>';
		var sAccess 	= '<?php echo $sAccess;?>';
		</script>

		<div class="col-sm-4">
				<div class="widget-container widget-stats boxed green-line">
				<div class="widget-title">
						<a href="<?php echo base_url('home/PoolDevice');?>" class="link-refresh" id="link-refresh-1"><span class="glyphicon glyphicon-refresh"></span></a>
						<h3>Valve ON/OFF</h3>
				</div>
				<div class="stats-content clearfix">
						<div class="stats-content-right" style="width:96% !important; margin-left:5px; margin-right:5px; margin-top:10px; float:none;">
						<?php
								if( $iValveNumber == 0 || $iValveNumber == '' )
								{ ?>

										<tr>
											<td>
												<span style="color:red">Please add number of Vavles in the <a href="<?php echo base_url('home/setting/');?>">Settings</a> Page!</span>
											</td>
										</tr>

								<?php 
								}
								else
								{
										$spaValveDeviceCnt= 0;
										//START : Valve Device 
										$arrValve	=	array(0,1,2,3,4,5,6,7);
										$j=0;
										$remainigCount	=	0;
										$chkValve		=	0;

										if(!empty($ValveRelays))
										{
											foreach($ValveRelays as $valve)
											{
													$i = $valve->device_number;
													$j = $i *2;

													unset($arrValve[$i]);

													$iValvesVal = $sValves[$i];
													$iValvesNewValSb1 = 1;
													$iValvesNewValSb2 = 2 ;
													if($iValvesVal == 1)
													{
														$iValvesNewValSb1 = 0;
													}
													if($iValvesVal == 2)
													{
														$iValvesNewValSb2 = 1;
													}
													$sValvesVal1 = false;
													$sValvesVal2 = false;
													if($iValvesVal == 1)
														$sValvesVal1 = true;
													if($iValvesVal == 2)
														$sValvesVal2 = true;
													//$sValvesNameDb = get_device_name(3, $i);

													$sValvesNameDb =  $this->home_model->getDeviceName($i,$sDevice);
													if($sValvesNameDb == '')
														$sValvesNameDb = 'Add Name';

													$aPositionName   =  $this->home_model->getPositionName($i,$sDevice);
													$aRelayNumber    =  json_decode($this->home_model->getValveRelayNumber($i,$sDevice));
													$sMainType	     =  $this->home_model->getDeviceMainType($i,$sDevice);

													if($iValvesVal == '.' || $iValvesVal == '')
															continue;

													if($iValvesVal != '' && $iValvesVal != '.' && !empty($aRelayNumber) && $sMainType == '2') 
													{
														$spaValveDeviceCnt++;
												?>
														<div class="row">
														<div class="col-sm-12">
													<div class="span1 valve-<?php echo $i?>" value="1" style="margin-top: 10px; width: auto; color: #428BCA;font-weight: bold; cursor: pointer; float: left;"><?php if($aPositionName[0] == ''){ echo 'Spa';} else { echo $aPositionName[0];} ?></div>
														<div class="span2" style="margin-left:5px; margin-right:5px; float: left;" >
														<select id='switch-me-<?php echo $i;?>'>
														<option value='1' <?php if($iValvesVal == '1') { echo 'selected="selected"';} ?>>Spa</option>
														<option value='0' <?php if($iValvesVal == '0' || $iValvesVal == '') { echo 'selected="selected"';} ?>></option>
														<option value='2' <?php if($iValvesVal == '2') { echo 'selected="selected"';} ?>>Pool</option>
														</select>
														<div class="valve-<?php echo $i?>" value="0" id="off-<?php echo $i;?>" style="color: red;font-weight: bold;width: 0; margin-left: 30px; cursor: pointer;">
																OFF
</div>                              </div>
														<div class="span1 valve-<?php echo $i?>" value="2" style="margin-top: 10px; width: auto; color: #428BCA;font-weight: bold; cursor: pointer; float: left;"><?php if($aPositionName[1] == ''){ echo 'Pool';} else { echo $aPositionName[1];} ?></div>
														<div style="float: right;margin-right: 10px;margin-top: 10px;"><strong><span style="color:#C9376E;"><?php echo 'Valve '.$i; ?></span></strong></div>
														<script type="text/javascript">
															$(function()
															{
																		var bgColor = '#E8E8E8';
																		<?php if($iValvesVal == '1' || $iValvesVal == '2') { ?>
																						bgColor = '#45A31F';
																		<?php } else { ?>
																						bgColor = '#E8E8E8';
																		<?php } ?>

																		$('#switch-me-<?php echo $i;?>').switchy();

																		$('.valve-<?php echo $i?>').on('click', function(event){
																				//event.preventDefault();
																				//return false;
																				$('#switch-me-<?php echo $i;?>').val($(this).attr('value')).change();
																		});

																		$('#switch-me-<?php echo $i;?>').next('.switchy-container').find('.switchy-bar').animate({
																						backgroundColor: bgColor
																				});

																		$('#switch-me-<?php echo $i;?>').on('change', function(event)
																		{
																				if(sAccess == 2)
																				{
																						if(iActiveMode != 2)
																						{
																								var bConfirm	=	confirm('You will need to change to Manual mode to make this change.\nWould you like to activate manual mode?' );
																								if(bConfirm)
																								{
																										$.ajax({
																												type: "POST",
																												url: "<?php echo site_url('analog/changeMode');?>", 
																												data: {iMode:'2'},
																												success: function(data) {
																												}
																										});
																										//event.preventDefault();
																										//return false;
																										// Animate Switchy Bar background color
																										var bgColor = '#E8E8E8';

																										if ($(this).val() == '1' || $(this).val() == '2')
																										{
																												bgColor = '#45A31F';
																										} 
																										$('#switch-me-<?php echo $i;?>').next('.switchy-container').find('.switchy-bar').animate({
																												backgroundColor: bgColor
																										});


																										//$("#loading_valve_<?php //echo $i;?>").css('visibility','visible');
																										$.ajax({
																												type: "POST",
																												url: "<?php echo site_url('home/updateStatusOnOff');?>", 
																												data: {sName:'<?php echo $i;?>',sStatus:$(this).val(),sDevice:'<?php echo $sDevice;?>'},
																												success: function(data) {
																												//$("#loading_valve_<?php //echo $i;?>").css('visibility','hidden');
																												location.reload();
																												}

																										});
																								}
																						}
																						else											
																						{
																								//event.preventDefault();
																								//return false;
																								// Animate Switchy Bar background color
																								var bgColor = '#E8E8E8';

																								if ($(this).val() == '1' || $(this).val() == '2')
																								{
																										bgColor = '#45A31F';
																								} 
																								$('#switch-me-<?php echo $i;?>').next('.switchy-container').find('.switchy-bar').animate({
																										backgroundColor: bgColor
																								});


																								//$("#loading_valve_<?php //echo $i;?>").css('visibility','visible');
																								$.ajax({
																										type: "POST",
																										url: "<?php echo site_url('home/updateStatusOnOff');?>", 
																										data: {sName:'<?php echo $i;?>',sStatus:$(this).val(),sDevice:'<?php echo $sDevice;?>'},
																										success: function(data) {
																										//$("#loading_valve_<?php //echo $i;?>").css('visibility','hidden');
																										}

																								});
																						}
																				}
																		});
																});
													</script>
													</div>
												</div>
												<div style="height:10px;">&nbsp;</div>
								<?php           }
												 $chkValve++;
												}		
										}
										$remainigCount	=	$iValveNumber - $chkValve;
										//for ($i=0;$i < $valve_count; $i++)	
										//for ($i=0;$i < $remainigCount ; $i++)
										foreach($arrValve as $i)	
										{
												if($remainigCount == 0)	
														break;

												$remainigCount--;

												$j = $i * 2;

												$iValvesVal = $sValves[$i];
												$iValvesNewValSb1 = 1;
												$iValvesNewValSb2 = 2 ;
												if($iValvesVal == 1)
												{
													$iValvesNewValSb1 = 0;
												}
												if($iValvesVal == 2)
												{
													$iValvesNewValSb2 = 1;
												}
												$sValvesVal1 = false;
												$sValvesVal2 = false;
												if($iValvesVal == 1)
													$sValvesVal1 = true;
												if($iValvesVal == 2)
													$sValvesVal2 = true;
												//$sValvesNameDb = get_device_name(3, $i);

												$sValvesNameDb =  $this->home_model->getDeviceName($i,$sDevice);


												$aPositionName   =  $this->home_model->getPositionName($i,$sDevice);
												$aRelayNumber    =  json_decode($this->home_model->getValveRelayNumber($i,$sDevice));
												$iPower	 	     =  $this->home_model->getDevicePower($i,$sDevice);
												$sMainType	     =  $this->home_model->getDeviceMainType($i,$sDevice);

										if($iValvesVal != '' && $iValvesVal != '.' && !empty($aRelayNumber) && $sMainType == '2') 
										{
											$spaValveDeviceCnt++;
										?>
												<div class="row">
												<div class="col-sm-12">
												<div class="span1 valve-<?php echo $i?>" value="1" style="margin-top: 10px; width: auto; color: #428BCA;font-weight: bold; cursor: pointer; float: left;"><?php if($aPositionName[0] == ''){ echo 'Spa';} else { echo $aPositionName[0];} ?></div>
												<div class="span2" style="margin-left:5px; margin-right:5px; float: left;" >
												<select id='switch-me-<?php echo $i;?>'>
												<option value='1' <?php if($iValvesVal == '1') { echo 'selected="selected"';} ?>>Spa</option>
												<option value='0' <?php if($iValvesVal == '0' || $iValvesVal == '') { echo 'selected="selected"';} ?>></option>
												<option value='2' <?php if($iValvesVal == '2') { echo 'selected="selected"';} ?>>Pool</option>
												</select>
												<div class="valve-<?php echo $i?>" value="0" id="off-<?php echo $i;?>" style="color: red;font-weight: bold;width: 0; margin-left: 30px; cursor: pointer;">
														OFF
</div>                              </div>
												<div class="span1 valve-<?php echo $i?>" value="2" style="margin-top: 10px; width: auto; color: #428BCA;font-weight: bold; cursor: pointer; float: left;"><?php if($aPositionName[1] == ''){ echo 'Pool';} else { echo $aPositionName[1];} ?></div>
												<div style="float: right;margin-right: 10px;margin-top: 10px;"><strong><span style="color:#C9376E;"><?php echo 'Valve '.$i; ?></span></strong></div>
												<script type="text/javascript">
															$(function()
															{
																		var bgColor = '#E8E8E8';
																		<?php if($iValvesVal == '1' || $iValvesVal == '2') { ?>
																						bgColor = '#45A31F';
																		<?php } else { ?>
																						bgColor = '#E8E8E8';
																		<?php } ?>

																		$('#switch-me-<?php echo $i;?>').switchy();

																		$('.valve-<?php echo $i?>').on('click', function(event){
																				//event.preventDefault();
																				//return false;
																				$('#switch-me-<?php echo $i;?>').val($(this).attr('value')).change();
																		});

																		$('#switch-me-<?php echo $i;?>').next('.switchy-container').find('.switchy-bar').animate({
																						backgroundColor: bgColor
																				});

																		$('#switch-me-<?php echo $i;?>').on('change', function(event)
																		{
																				if(sAccess == 2)
																				{
																						if(iActiveMode != 2)
																						{
																								var bConfirm	=	confirm('You will need to change to Manual mode to make this change.\nWould you like to activate manual mode?' );
																								if(bConfirm)
																								{
																										$.ajax({
																												type: "POST",
																												url: "<?php echo site_url('analog/changeMode');?>", 
																												data: {iMode:'2'},
																												success: function(data) {
																												}
																										});
																										//event.preventDefault();
																										//return false;
																										// Animate Switchy Bar background color
																										var bgColor = '#E8E8E8';

																										if ($(this).val() == '1' || $(this).val() == '2')
																										{
																												bgColor = '#45A31F';
																										} 
																										$('#switch-me-<?php echo $i;?>').next('.switchy-container').find('.switchy-bar').animate({
																												backgroundColor: bgColor
																										});


																										//$("#loading_valve_<?php //echo $i;?>").css('visibility','visible');
																										$.ajax({
																												type: "POST",
																												url: "<?php echo site_url('home/updateStatusOnOff');?>", 
																												data: {sName:'<?php echo $i;?>',sStatus:$(this).val(),sDevice:'<?php echo $sDevice;?>'},
																												success: function(data) {
																												//$("#loading_valve_<?php //echo $i;?>").css('visibility','hidden');
																												location.reload();
																												}

																										});
																								}
																						}
																						else											
																						{
																								//event.preventDefault();
																								//return false;
																								// Animate Switchy Bar background color
																								var bgColor = '#E8E8E8';

																								if ($(this).val() == '1' || $(this).val() == '2')
																								{
																										bgColor = '#45A31F';
																								} 
																								$('#switch-me-<?php echo $i;?>').next('.switchy-container').find('.switchy-bar').animate({
																										backgroundColor: bgColor
																								});


																								//$("#loading_valve_<?php //echo $i;?>").css('visibility','visible');
																								$.ajax({
																										type: "POST",
																										url: "<?php echo site_url('home/updateStatusOnOff');?>", 
																										data: {sName:'<?php echo $i;?>',sStatus:$(this).val(),sDevice:'<?php echo $sDevice;?>'},
																										success: function(data) {
																										//$("#loading_valve_<?php //echo $i;?>").css('visibility','hidden');
																										}

																								});
																						}
																				}
																		});
																});
												</script> 
										</div>
										</div>
										<div style="height:10px;">&nbsp;</div>
								<?php }	
									}
								}
								if($spaValveDeviceCnt == 0)
								{
									 echo '<div class="rowCheckbox switch"><span style="color:#C9376E; font-weight:bold;">No Device available!</span></div><div style="height:10px;">&nbsp;</div>';
								}
								?>
						</div>
				</div>
				</div>
                        </div>
		 <?php }} ?> <!-- END : Valve Device -->  
		 </div>
        <div class="row">
        <?php //if($sDevice == 'PS') 
		
 
		$sDevice            = 'PS' 	;
		$sDeviceFullName 	= 'Pump Sequencer';
		$sModule	        = 9;
		$iPumpsNumber	=	$extra['PumpsNumber'];
		$sAccessKey	= 'access_'.$sModule;
			  
		  if(!empty($aModules))
		  {
			  if(in_array($sModule,$aModules->ids))
			  {
				 $sAccess 		= $aModules->$sAccessKey;
			  }
		  }
	  
		if($sAccess == '')
			$sAccess = '2' ; 
	  
		if($sAccess == '0') {redirect(site_url('home/'));}
		
		{  // START : Pump Device?>
		<?php if($sAccess == 1 || $sAccess == 2) { ?>
			
			<div class="col-sm-8">
					<div class="widget-container widget-stats boxed green-line">
					<div class="widget-title">
						<a href="<?php echo base_url('home/PoolDevice');?>" class="link-refresh" id="link-refresh-1"><span class="glyphicon glyphicon-refresh"></span></a>
						<h3>PUMP ON/OFF</h3>
					</div>
					<div class="stats-content clearfix">
						<div class="stats-content-right" style="width:96% !important; margin-left:5px; margin-right:5px; margin-top:10px; float:none;">
						<?php
                    
								if( $iPumpsNumber == 0 || $iPumpsNumber == '' )
								{ ?>
									
									<div class="row">
										<div class="col-sm-12">
											<span style="color:red">Please add number of Pumps in the <a href="<?php echo base_url('home/setting/');?>">Settings</a> Page!</span>
										</div>
									</div>
									
								<?php 
								}
								else
								{
									$spaPumpDeviceCnt	=	0;
									$arrPump		=	array(0,1,2);
									$remainigCount	=	0;
									$chkPump		=	0;
									if(!empty($Pumps))
									{
										foreach($Pumps as $pump)
										{
											
										$i= $pump->pump_number;
										unset($arrPump[$i]);		
										$iPumpVal = $sPump[$i];
										$sPumpNameDb =  $this->home_model->getDeviceName($i,$sDevice);
										if($sPumpNameDb == '')
										  $sPumpNameDb = 'Add Name';
										
										$sStatus2Speed	=	'';
										
										$aPumpDetails = $this->home_model->getPumpDetails($i);
										$sPumpType		=	'';
										if(!empty($aPumpDetails))
										{
											foreach($aPumpDetails as $aResultEdit)
											{
												$sPumpType    = $aResultEdit->pump_type;//Pump Type
												$sPumpRelay   = $aResultEdit->relay_number;//Assigned Relay Number
												$sPumpRelay1   = $aResultEdit->relay_number_1;//Assigned Relay Number
												if($sPumpType == '12')
												{
													$iPumpVal = $sPowercenter[$sPumpRelay]; //Taken the status
												}
												else if($sPumpType == '24')
												{
													$iPumpVal = $sRelays[$sPumpRelay];//Taken the status
												}
												else if($sPumpType == '2Speed')
												{
													$sPumpSubType    = $aResultEdit->pump_sub_type;//Pump SUB Type
													$sStatus2Speed   = $aResultEdit->status;//Pump SUB Type
													
													if($sStatus2Speed == '0')
													{
														$iPumpVal        = $sStatus2Speed;
													}
													else if($sStatus2Speed == '1')											
													{
														if($sPumpSubType == '12')
														{
															$iPumpVal = $sPowercenter[$sPumpRelay]; //Taken the status
														}
														else if($sPumpSubType == '24')
														{
															$iPumpVal = $sRelays[$sPumpRelay];//Taken the status
														}
													}
													else if($sStatus2Speed == '2')											
													{
														if($sPumpSubType == '12')
														{
															$iPumpVal = $sPowercenter[$sPumpRelay1]; //Taken the status
														}
														else if($sPumpSubType == '24')
														{
															$iPumpVal = $sRelays[$sPumpRelay1];//Taken the status
														}
													}
												}
												else if(preg_match('/Emulator/',$sPumpType))
												{
													 $iPumpVal = $sPump[$i];
												}
											}
										}	//END : Getting assigned relay status from the Server.
										$sPumpVal = false;
										if($iPumpVal)
										  $sPumpVal = true;
										
										$strChecked	=	'';
										if($iPumpVal > 0)
											$strChecked	=	'class="checked"';
									  
										$sMainType	 = $this->home_model->getDeviceMainType($i,$sDevice);
										
										$strPumpName = 'Pump '.$i;
										if($sPumpNameDb != '' && $sPumpNameDb != 'Add Name')
											$strPumpName .= '('.$sPumpNameDb.')';
										
										if($sStatus2Speed == '')
											$sStatus2Speed = '0';
										
										if($sMainType == '2')
										{
											$spaPumpDeviceCnt++;
								?>
										<div class="row">
										<div class="col-sm-12">
										<?php if($sPumpType == '2Speed') { ?>
										<script>
										var iActiveMode = '<?php echo $iActiveMode;?>';
										var sAccess 	= '<?php echo $sAccess;?>';
										</script>
										<link href="<?php echo site_url('assets/switchy/switchy.css'); ?>" rel="stylesheet" />
										<script type="text/javascript" src="<?php echo site_url('assets/switchy/switchy.js'); ?>"></script>
										<script type="text/javascript" src="<?php echo site_url('assets/switchy/jquery.event.drag.js'); ?>"></script>
										<script type="text/javascript" src="<?php echo site_url('assets/switchy/jquery.animate-color.js'); ?>"></script>
										<div class="span1 pump-<?php echo $i?>" value="1" style="margin-top: 10px; width: auto; color: #428BCA;font-weight: bold; cursor: pointer; float: left;">Relay 1</div>
										<div class="span2" style="margin-left:5px; margin-right:5px; float: left;" >
										<select id='switch-me-<?php echo $i;?>'>
										<option value='1' <?php if($sStatus2Speed == '1') { echo 'selected="selected"';} ?>>Spa</option>
										<option value='0' <?php if($sStatus2Speed == '0' || $iPumpVal == '') { echo 'selected="selected"';} ?>></option>
										<option value='2' <?php if($sStatus2Speed == '2') { echo 'selected="selected"';} ?>>Pool</option>
										</select>
										<div class="pump-<?php echo $i?>" value="0" id="off-<?php echo $i;?>" style="color: red;font-weight: bold;width: 0; margin-left: 30px; cursor: pointer;">
											OFF
										</div>                              </div>
										<div class="span1 pump-<?php echo $i?>" value="2" style="margin-top: 10px; width: auto; color: #428BCA;font-weight: bold; cursor: pointer; float: left;">Relay 2</div>
										<div style="margin-top:10px; float:right; color:#C9376E;"><strong><?php echo $strPumpName;?></strong></div>
										
									  <script type="text/javascript">
									  
									  $(function()
									  {
										  var bgColor = '#E8E8E8';
											<?php if($iPumpVal == '1' || $iPumpVal == '2') { ?>
													bgColor = '#45A31F';
											<?php } else { ?>
													bgColor = '#E8E8E8';
											<?php } ?>
											
											$('#switch-me-<?php echo $i;?>').switchy();
											
											$('.pump-<?php echo $i?>').on('click', function(event){
												//event.preventDefault();
												//return false;
												$('#switch-me-<?php echo $i;?>').val($(this).attr('value')).change();
											});
											
											$('#switch-me-<?php echo $i;?>').next('.switchy-container').find('.switchy-bar').animate({
													backgroundColor: bgColor
												});
											
											$('#switch-me-<?php echo $i;?>').on('change', function(event)
											{
												if(sAccess == 2)
												{
													if(iActiveMode != 2)
													{
														var bConfirm	=	confirm('You will need to change to Manual mode to make this change.\nWould you like to activate manual mode?' );
														if(bConfirm)
														{
															$.ajax({
																type: "POST",
																url: "<?php echo site_url('analog/changeMode');?>", 
																data: {iMode:'2'},
																success: function(data) {
																}
															});
															//event.preventDefault();
															//return false;
															// Animate Switchy Bar background color
															var bgColor = '#E8E8E8';

															if ($(this).val() == '1' || $(this).val() == '2')
															{
																bgColor = '#45A31F';
															} 
															$('#switch-me-<?php echo $i;?>').next('.switchy-container').find('.switchy-bar').animate({
																backgroundColor: bgColor
															});
														
															
															//$("#loading_valve_<?php //echo $i;?>").css('visibility','visible');
															$.ajax({
																type: "POST",
																url: "<?php echo site_url('home/updateStatusOnOff');?>", 
																data: {sName:'<?php echo $i;?>',sStatus:$(this).val(),sDevice:'<?php echo $sDevice;?>'},
																success: function(data) {
																//$("#loading_valve_<?php //echo $i;?>").css('visibility','hidden');
																location.reload();
																}

															});
														}
													}
													else											
													{
														//event.preventDefault();
														//return false;
														// Animate Switchy Bar background color
														var bgColor = '#E8E8E8';

														if ($(this).val() == '1' || $(this).val() == '2')
														{
															bgColor = '#45A31F';
														} 
														$('#switch-me-<?php echo $i;?>').next('.switchy-container').find('.switchy-bar').animate({
															backgroundColor: bgColor
														});
													
														
														//$("#loading_valve_<?php //echo $i;?>").css('visibility','visible');
														$.ajax({
															type: "POST",
															url: "<?php echo site_url('home/updateStatusOnOff');?>", 
															data: {sName:'<?php echo $i;?>',sStatus:$(this).val(),sDevice:'<?php echo $sDevice;?>'},
															success: function(data) {
															//$("#loading_valve_<?php //echo $i;?>").css('visibility','hidden');
															}

														});
													}
												}
											});
										});
								   </script>
								   
										<?php } else if($sPumpType != '') { ?>
										
										<?php if(preg_match('/Emulator/',$sPumpType)) { ?>
										<script>
										  $(document).ready(function() {
											setInterval( function() {
												$.getJSON('<?php echo site_url('cron/pumpResponseLatest/');?>', {iPumpID: "<?php echo $i;?>"}, function(json) {
													
													if(json == '')
													{
														$("#lablePump-"+<?php echo $i;?>).removeClass('checked');
														$("#pumpRealResponse_"+<?php echo $i;?>).html('');
													}
													else
													{
														$("#pumpRealResponse_"+<?php echo $i;?>).html(json);
														if($("#lablePump-"+<?php echo $i;?>).hasClass('checked'))
														{}
														else
														{
															$("#lablePump-"+<?php echo $i;?>).addClass('checked');
														}
													}
												});
												},30000);
										  });
										</script>										  
										   <?php } ?>
										<div class="rowCheckbox switch">
											<div class="custom-checkbox"><input type="checkbox" value="<?php echo $i;?>" id="pumps-<?php echo $i?>" name="pumps-<?php echo $i?>" class="pumpsButton" hidefocus="true" style="outline: medium none;">
												<label style="margin-left: 60px;" <?php echo $strChecked;?>  id="lablePump-<?php echo $i?>" for="pumps-<?php echo $i?>"><span style="float:right; color:#C9376E;"><?php echo $strPumpName;?></span></label>
											</div>
										</div>
											<?php if(preg_match('/Emulator/',$sPumpType)) { ?>
											<div id="pumpRealResponse_<?php echo $i;?>" style="color: #164c87;font-weight: bold;"><?php if($iPumpVal > 0) { echo $strPumpsResponse		= $this->home_model->selectPumpsLatestResponse($i); }?></div>
											<?php } ?>
										<?php } ?>
										</div>
										</div>
										<div style="height:20px;">&nbsp;</div>
										<?php } ?>
									<?php 
										$chkPump++;
									}
									?>
								<?php } ?>
								<?php 
									$remainigCount	=	$iPumpsNumber - $chkPump;
									//for ($i=0;$i < $valve_count; $i++)	
									//for ($i=0;$i < $remainigCount ; $i++)
									foreach($arrPump as $i)	
									{
										if($remainigCount == 0)	
											break;
										
										$remainigCount--;
												
									//for ($i=0;$i < $pump_count; $i++)
									//{
										$iPumpVal = $sPump[$i];
										/* $iPumpNewValSb = 1;
										if($iPumpVal == 1)
										{
										  $iPumpNewValSb = 0;
										}
										$sPumpVal = false;
										if($iPumpVal)
										  $sPumpVal = true; */
										//$sRelayNameDb = get_device_name(1, $i);
									
										$sPumpNameDb =  $this->home_model->getDeviceName($i,$sDevice);
										if($sPumpNameDb == '')
										  $sPumpNameDb = 'Add Name';
										
										//$iPower	 = $this->home_model->getDevicePower($i,$sDevice);
										
										//$sPowercenter = '01000000'		;
										//START : Getting assigned relay status from the Server.	
										//Details of Pump
										
										$sStatus2Speed	=	'';
										
										$aPumpDetails = $this->home_model->getPumpDetails($i);
										$sPumpType		=	'';
										if(!empty($aPumpDetails))
										{
											foreach($aPumpDetails as $aResultEdit)
											{
												$sPumpType    = $aResultEdit->pump_type;//Pump Type
												$sPumpRelay   = $aResultEdit->relay_number;//Assigned Relay Number
												$sPumpRelay1   = $aResultEdit->relay_number_1;//Assigned Relay Number
												if($sPumpType == '12')
												{
													$iPumpVal = $sPowercenter[$sPumpRelay]; //Taken the status
												}
												else if($sPumpType == '24')
												{
													$iPumpVal = $sRelays[$sPumpRelay];//Taken the status
												}
												else if($sPumpType == '2Speed')
												{
													$sPumpSubType    = $aResultEdit->pump_sub_type;//Pump SUB Type
													$sStatus2Speed   = $aResultEdit->status;//Pump SUB Type
													
													
													if($sStatus2Speed == '0')
													{
														$iPumpVal        = $sStatus2Speed;
													}
													else if($sStatus2Speed == '1')											
													{
														if($sPumpSubType == '12')
														{
															$iPumpVal = $sPowercenter[$sPumpRelay]; //Taken the status
														}
														else if($sPumpSubType == '24')
														{
															$iPumpVal = $sRelays[$sPumpRelay];//Taken the status
														}
													}
													else if($sStatus2Speed == '2')											
													{
														if($sPumpSubType == '12')
														{
															$iPumpVal = $sPowercenter[$sPumpRelay1]; //Taken the status
														}
														else if($sPumpSubType == '24')
														{
															$iPumpVal = $sRelays[$sPumpRelay1];//Taken the status
														}
													}
												}
												else if(preg_match('/Emulator/',$sPumpType))
												{
													 $iPumpVal = $sPump[$i];
												}
											}
										}	//END : Getting assigned relay status from the Server.
										$sPumpVal = false;
										if($iPumpVal)
										  $sPumpVal = true;
									  
										$sMainType	 = $this->home_model->getDeviceMainType($i,$sDevice);
										
										$strChecked	=	'';
										if($iPumpVal > '1')
											$strChecked	=	'class="checked"';
										
										$strPumpName = 'Pump '.$i;
										if($sPumpNameDb != '' && $sPumpNameDb != 'Add Name')
											$strPumpName .= ' ('.$sPumpNameDb.')';
										
										if($sStatus2Speed == '')
											$sStatus2Speed = '0';
										
										if($sMainType == '2')
										{
											$spaPumpDeviceCnt++;
								?>	
										<div class="row">
										<div class="col-sm-12">
										<?php if($sPumpType == '2Speed') { ?>
										<script>
										var iActiveMode = '<?php echo $iActiveMode;?>';
										var sAccess 	= '<?php echo $sAccess;?>';
										</script>
										<link href="<?php echo site_url('assets/switchy/switchy.css'); ?>" rel="stylesheet" />
										<script type="text/javascript" src="<?php echo site_url('assets/switchy/switchy.js'); ?>"></script>
										<script type="text/javascript" src="<?php echo site_url('assets/switchy/jquery.event.drag.js'); ?>"></script>
										<script type="text/javascript" src="<?php echo site_url('assets/switchy/jquery.animate-color.js'); ?>"></script>
										<div class="span1 pump-<?php echo $i?>" value="1" style="margin-top: 10px; width: auto; color: #428BCA;font-weight: bold; cursor: pointer; float: left;">Relay 1</div>
										<div class="span2" style="margin-left:5px; margin-right:5px; float: left;" >
										<select id='switch-me-<?php echo $i;?>'>
										<option value='1' <?php if($sStatus2Speed == '1') { echo 'selected="selected"';} ?>>Spa</option>
										<option value='0' <?php if($sStatus2Speed == '0' || $iPumpVal == '') { echo 'selected="selected"';} ?>></option>
										<option value='2' <?php if($sStatus2Speed == '2') { echo 'selected="selected"';} ?>>Pool</option>
										</select>
										<div class="pump-<?php echo $i?>" value="0" id="off-<?php echo $i;?>" style="color: red;font-weight: bold;width: 0; margin-left: 30px; cursor: pointer;">
											OFF
				</div>                              </div>
										<div class="span1 pump-<?php echo $i?>" value="2" style="margin-top: 10px; width: auto; color: #428BCA;font-weight: bold; cursor: pointer; float: left;">Relay 2</div>
										<div style="margin-top:10px; float:right; color:#C9376E;"><strong><?php echo $strPumpName;?></strong></div>
									  <script type="text/javascript">
									  
									  $(function()
									  {
										  var bgColor = '#E8E8E8';
											<?php if($iPumpVal == '1' || $iPumpVal == '2') { ?>
													bgColor = '#45A31F';
											<?php } else { ?>
													bgColor = '#E8E8E8';
											<?php } ?>
											
											$('#switch-me-<?php echo $i;?>').switchy();
											
											$('.pump-<?php echo $i?>').on('click', function(event){
												//event.preventDefault();
												//return false;
												$('#switch-me-<?php echo $i;?>').val($(this).attr('value')).change();
											});
											
											$('#switch-me-<?php echo $i;?>').next('.switchy-container').find('.switchy-bar').animate({
													backgroundColor: bgColor
												});
											
											$('#switch-me-<?php echo $i;?>').on('change', function(event)
											{
												if(sAccess == 2)
												{
													if(iActiveMode != 2)
													{
														var bConfirm	=	confirm('You will need to change to Manual mode to make this change.\nWould you like to activate manual mode?' );
														if(bConfirm)
														{
															$.ajax({
																type: "POST",
																url: "<?php echo site_url('analog/changeMode');?>", 
																data: {iMode:'2'},
																success: function(data) {
																}
															});
															//event.preventDefault();
															//return false;
															// Animate Switchy Bar background color
															var bgColor = '#E8E8E8';

															if ($(this).val() == '1' || $(this).val() == '2')
															{
																bgColor = '#45A31F';
															} 
															$('#switch-me-<?php echo $i;?>').next('.switchy-container').find('.switchy-bar').animate({
																backgroundColor: bgColor
															});
														
															
															//$("#loading_valve_<?php //echo $i;?>").css('visibility','visible');
															$.ajax({
																type: "POST",
																url: "<?php echo site_url('home/updateStatusOnOff');?>", 
																data: {sName:'<?php echo $i;?>',sStatus:$(this).val(),sDevice:'<?php echo $sDevice;?>'},
																success: function(data) {
																//$("#loading_valve_<?php //echo $i;?>").css('visibility','hidden');
																location.reload();
																}

															});
														}
													}
													else											
													{
														//event.preventDefault();
														//return false;
														// Animate Switchy Bar background color
														var bgColor = '#E8E8E8';

														if ($(this).val() == '1' || $(this).val() == '2')
														{
															bgColor = '#45A31F';
														} 
														$('#switch-me-<?php echo $i;?>').next('.switchy-container').find('.switchy-bar').animate({
															backgroundColor: bgColor
														});
													
														
														//$("#loading_valve_<?php //echo $i;?>").css('visibility','visible');
														$.ajax({
															type: "POST",
															url: "<?php echo site_url('home/updateStatusOnOff');?>", 
															data: {sName:'<?php echo $i;?>',sStatus:$(this).val(),sDevice:'<?php echo $sDevice;?>'},
															success: function(data) {
															//$("#loading_valve_<?php //echo $i;?>").css('visibility','hidden');
															}

														});
													}
												}
											});
										});
								   </script>
								   
										<?php } else if($sPumpType != '') { ?>
										 <div class="rowCheckbox switch">
											<div class="custom-checkbox"><input type="checkbox" value="<?php echo $i;?>" id="pumps-<?php echo $i?>" name="pumps-<?php echo $i?>" class="pumpsButton" hidefocus="true" style="outline: medium none;">
												<label style="margin-left: 60px;" <?php echo $strChecked;?>  id="lablePump-<?php echo $i?>" for="pumps-<?php echo $i?>"><span style="color:#C9376E;float:right;" ><?php echo $strPumpName;?></span></label>
											</div>
										</div>
										
										<?php } else if($sPumpType == '') { ?>
										<span style="color:#E94180;"><strong>Pump <?php echo $i; ?> not configured.</strong></span>
										<?php } ?>
										</div>
										</div>
										<div style="height:20px;">&nbsp;</div>
										<?php } ?>
									<?php } ?>
							<?php } ?>
							<?php
								if($spaPumpDeviceCnt == 0)
								{
									 echo '<div class="rowCheckbox switch"><span style="color:#C9376E; font-weight:bold;">No Device available!</span></div><div style="height:10px;">&nbsp;</div>';
								}
							?>
						</div>
					</div>
					</div>
				</div>
			
        <?php }
			} ?> <!-- END : Pump Device -->
			
			<?php
			
				$sDevice            = 'L' 	;
				$sDeviceFullName 	= 'Pump Sequencer';
				$numLight			= $extra['LightNumber'];
				/* $sModule	        = 9;
				$iPumpsNumber	=	$extra['PumpsNumber'];
				$sAccessKey	= 'access_'.$sModule;
					  
				  if(!empty($aModules))
				  {
					  if(in_array($sModule,$aModules->ids))
					  {
						 $sAccess 		= $aModules->$sAccessKey;
					  }
				  }
			  
				if($sAccess == '')
					$sAccess = '2' ; 
			  
				if($sAccess == '0') {redirect(site_url('home/'));} */
			
			?>
			<div class="col-sm-4">
			<div class="widget-container widget-stats boxed green-line">
					<div class="widget-title">
						<a href="<?php echo base_url('home/PoolDevice');?>" class="link-refresh" id="link-refresh-1"><span class="glyphicon glyphicon-refresh"></span></a>
						<h3>Light ON/OFF</h3>
					</div>
					<div class="stats-content clearfix">
						<div class="stats-content-right" style="width:96% !important; margin-left:5px; margin-right:5px; float:none; margin-top:10px;">
						<?php
						$spaLightDeviceCnt	=	0;
						for ($i=0;$i<$numLight; $i++)
						{	
							$strLightName	=   'Light '.$i;
																
								$sRelayType     =   '';
								$sRelayNumber   =   '';
								$strLight	=   'light_off.png';
								
								$aLightDetails  =   $this->home_model->getLightDeviceDetails($i);
								if(!empty($aLightDetails))
								{
									foreach($aLightDetails as $aLight)
									$sRelayDetails  =   unserialize($aLight->light_relay_number);
									
									$sRelayType     =   $sRelayDetails['sRelayType'];
									$sRelayNumber   =   $sRelayDetails['sRelayNumber'];
									
									if($sRelayType == '24')
									{
										$sLightStatus   =   $sRelays[$sRelayNumber];
										if($sLightStatus)
											$strLight   =   'light_on.png';
									}
									if($sRelayType == '12')
									{
										$sLightStatus   =   $sPowercenter[$sRelayNumber];
										if($sLightStatus)
											$strLight   =   'light_on.png';
									}
								}
								
								$sMainType	 = $this->home_model->getDeviceMainType($i,$sDevice);
								
								if($sMainType == '2')
								{
										$spaLightDeviceCnt++;
								if($sRelayNumber != '')
								{
									
					?>
					
					<div class="rowCheckbox switch">
					<img id="lightImage_<?php echo $i;?>" src="<?php echo HTTP_IMAGES_PATH.'icons/'.$strLight;?>" style="width:64px;">
						<div class="custom-checkbox" style="float:right; margin-right:10px; margin-top:20px;"><input type="checkbox" value="<?php echo $i.'|||'.$sRelayType.'|||'.$sRelayNumber;?>" id="relay-<?php echo $i?>" name="relay-<?php echo $i?>" class="lightButton" hidefocus="true" style="outline: medium none;">
							<label <?php echo $strChecked;?>  id="lableRelay-<?php echo $i?>" for="relay-<?php echo $i?>"><span style="color:#C9376E;"><?php echo $strLightName;?></span></label>
						</div>
					</div>
					<?php } ?>
					<?php          echo '<div style="height:30px;">&nbsp;</div>'; }  ?>
					<?php 			
						 }
						 if($spaLightDeviceCnt == 0)
						 {
							 echo '<div class="rowCheckbox switch"><span style="color:#C9376E; font-weight:bold;">No Device available!</span></div><div style="height:10px;">&nbsp;</div>';
						 }
							 
						 
					?> 
						</div>
					</div>
			</div>
		</div>
		</div>
	  
