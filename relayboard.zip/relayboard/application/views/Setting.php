<?php

$sAccess 		=	'';
$sModule	    =	12;

//Get Permission Details
	$userID = $this->session->userdata('id');
	$aPermissions = json_decode(getPermissionOfModule($userID));
	
	$aModules 		= $aPermissions->sPermissionModule;	
	$aAllActiveModule = $aPermissions->sActiveModule;

	$sAccessKey	= 'access_'.$sModule;
			  
	if(!empty($aModules))
	{
	  if(in_array($sModule,$aModules->ids))
	  {
		 $sAccess 		= $aModules->$sAccessKey;
	  }
	  else if(!in_array($sModule,$aModules->ids)) 
	  {
		$sAccess 		= '0'; 
	  }
	}

if($sAccess == '')
   $sAccess = '2' ; 

	if($sAccess == '0') 
	{
		redirect(site_url('home/'));
	}


if($sIP == '')
  $sIP =  IP_ADDRESS;

if($sPort == '')
  $sPort =  PORT_NO; 

$numPumps		=	0;
$numValve		=	0;
$numLight		=	0;
$numHeater		=	0;
$numBlower		=	0;

if(isset($extra['PumpsNumber']))
	$numPumps		=	$extra['PumpsNumber'];
if(isset($extra['ValveNumber']))
	$numValve		=	$extra['ValveNumber'];
if(isset($extra['LightNumber']))
	$numLight		=	$extra['LightNumber'];
if(isset($extra['HeaterNumber']))
	$numHeater		=	$extra['HeaterNumber'];
if(isset($extra['BlowerNumber']))
	$numBlower		=	$extra['BlowerNumber'];

?>
    <div id="page-wrapper">
        <div class="row">
          <div class="col-lg-12">
            <ol class="breadcrumb">
			  <li><img src="<?php echo HTTP_IMAGES_PATH.'icons/home.png';?>" width="24" style="vertical-align: middle !important;">&nbsp;<a href="<?php echo site_url();?>">Home</a> </li>
			  <li class="active">Setting</li>
			</ol>
            <?php if($sucess == '1') { ?>
              <div class="alert alert-success alert-dismissable">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                Details saved successfully! 
              </div>
            <?php } ?>
            <?php if($err_sucess == '1') { ?>
              <div class="alert alert-success alert-dismissable" style="background-color: #FFC0CB;border: 1px solid #FFC0CB; color:red;">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                IP and Port details required! 
              </div>
            <?php } ?>
            
          </div>
        </div><!-- /.row -->
        <div class="row">
          <div class="col-lg-12">
            <div class="panel panel-primary">
              <div class="panel-heading" style="border-top-left-radius: 0px;border-top-right-radius: 0px;">
                <h3 class="panel-title" style="color:#FFF;">Settings Page</h3>
              </div>
              <div class="panel-body">
                <div id="morris-chart-area">
                  <form action="<?php if($sAccess == 2) {echo site_url('home/setting');}?>" method="post" name="settingForm" id="settingForm">
				  <input type="hidden" id="command" name="command" value="">
                    <table border="0" cellspacing="0" cellpadding="0" width="100%">
                      <tr>
                        <td width="24%"><strong>IP ADDRESS:</strong></td>
                        <td width="1%">&nbsp;</td>
                        <td width="75%"><input type="text" class="form-control" placeholder="Enter ip address" name="relay_ip_address" value="<?php echo $sIP;?>" id="relay_ip_address" <?php if($sAccess == 1) { echo 'disabled="disabled"';} ?>></td>
                      </tr>
                      <tr><td colspan="3">&nbsp;</td></tr>
                      <tr>
                        <td width="10%"><strong>PORT NO:</strong></td>
                        <td width="1%">&nbsp;</td>
                        <td width="89%"><input type="text" class="form-control" placeholder="Enter port no" name="relay_port_no" value="<?php echo $sPort;?>" id="relay_port_no" <?php if($sAccess == 1) { echo 'disabled="disabled"';} ?>></td>
                      </tr>
                      <tr><td colspan="3">&nbsp;</td></tr>
                      <tr>
                        <td width="10%"><strong>Display Desired Pool Temp on Home Page:</strong></td>
                        <td width="1%">&nbsp;</td>
                        <td width="89%"><input type="radio" name="showPoolTemp" value="0" <?php if(isset($extra['Pool_Temp']) && $extra['Pool_Temp'] == '0') { echo 'checked="checked";';}?> checked="checked" <?php if($sAccess == 1) { echo 'disabled="disabled"';} ?>>&nbsp;No&nbsp;&nbsp;<input type="radio" name="showPoolTemp" value="1" <?php if(isset($extra['Pool_Temp']) && $extra['Pool_Temp'] == '1') { echo 'checked="checked";';}?> <?php if($sAccess == 1) { echo 'disabled="disabled"';} ?>>&nbsp;Yes
						<div style="height:10px;">&nbsp;</div>
						<div id="poolTempID" style="display:<?php if(isset($extra['Pool_Temp_Address']) && $extra['Pool_Temp_Address'] != '') { echo ''; } else {echo 'none';}?>">
						<strong>Select :</strong> <select name="selPoolTemp" id="selPoolTemp" class="form-control" style="width: 180px;  display:inline !important;" <?php if($sAccess == 1) { echo 'disabled="disabled"';} ?>>
						<?php
								foreach($aTemprature as $key=>$temprature)
								{
									$strTemp	=	'';
									if($temprature != '')
									{
										$strTemp = '( '.$temprature.' )';
									}
									
									$strSelect	=	'';
									if(isset($extra['Pool_Temp_Address']) && $extra['Pool_Temp_Address'] != '')
									{
										if($extra['Pool_Temp_Address'] == $key)
										{
											$strSelect	=	'selected="selected"';
										}
									}
									
									echo '<option value="'.$key.'" '.$strSelect.'>'.$key.' '.$strTemp.'</option>';
								}

						?>
						</div>
						</td>
                      </tr>
                      <tr><td colspan="3">&nbsp;</td></tr>
					  <tr>
                        <td width="10%"><strong>Display Desired Spa Temp on home page:</strong></td>
                        <td width="1%">&nbsp;</td>
                        <td width="89%"><input type="radio" name="showSpaTemp" value="0" <?php if((isset($extra['Pool_Temp']) && $extra['Spa_Temp'] == '0')) { echo 'checked="checked";';}?> checked="checked" <?php if($sAccess == 1) { echo 'disabled="disabled"';} ?>>&nbsp;No&nbsp;&nbsp;<input type="radio" name="showSpaTemp" value="1" <?php if((isset($extra['Pool_Temp']) && $extra['Spa_Temp'] == '1')) { echo 'checked="checked";';}?> <?php if($sAccess == 1) { echo 'disabled="disabled"';} ?>>&nbsp;Yes
						<div style="height:10px;">&nbsp;</div>
						<div id="spaTempID" style="display:<?php if(isset($extra['Spa_Temp_Address']) && $extra['Spa_Temp_Address'] != '') { echo ''; } else {echo 'none';}?>">
						<strong>Select :</strong> <select name="selSpaTemp" id="selSpaTemp" class="form-control" style="width: 180px; display:inline !important;" <?php if($sAccess == 1) { echo 'disabled="disabled"';} ?>>
						<?php
								foreach($aTemprature as $key=>$temprature)
								{
									$strTemp	=	'';
									if($temprature != '')
									{
										$strTemp = '( '.$temprature.' )';
									}
									
									$strSelect	=	'';
									if(isset($extra['Spa_Temp_Address']) && $extra['Spa_Temp_Address'] != '')
									{
										if($extra['Spa_Temp_Address'] == $key)
										{
											$strSelect	=	'selected="selected"';
										}
									}	
									
									echo '<option value="'.$key.'" '.$strSelect.'>'.$key.' '.$strTemp.'</option>';
								}

						?>
						</div>
						</td>
                      </tr>
					  <tr><td colspan="3">&nbsp;</td></tr>
					  
					  <tr>
                        <td width="10%"><strong>Maximum Manual Mode threshold expressed in minutes: </strong></td>
                        <td width="1%">&nbsp;</td>
                        <td width="89%"><input type="text" name="manualMinutes" id="manualMinutes" value="<?php echo $manualMinutes;?>" class="form-control" style="width: 180px;" <?php if($sAccess == 1) { echo 'disabled="disabled"';} ?>><strong style="color:#428BCA;">(The system will automatically change from Manual mode to auto mode after the threshold has been exceeded.)</strong>
						</td>
                      </tr>
					  
					  <tr><td colspan="3">&nbsp;</td></tr>
					  
					  <tr>
                        <td width="10%"><strong>Enter Number of Pumps: </strong></td>
                        <td width="1%">&nbsp;</td>
                        <td width="89%"><input type="text" name="numPumps" id="numPumps" value="<?php echo $numPumps;?>" class="form-control" style="width: 180px;" <?php if($sAccess == 1) { echo 'disabled="disabled"';} ?>>
						</td>
                      </tr>
					  
					  <tr><td colspan="3">&nbsp;</td></tr>
					  
					  <tr>
                        <td width="10%"><strong>Enter Number of Valves: </strong></td>
                        <td width="1%">&nbsp;</td>
                        <td width="89%"><input type="text" name="numValve" id="numValve" value="<?php echo $numValve;?>" class="form-control" style="width: 180px;" <?php if($sAccess == 1) { echo 'disabled="disabled"';} ?>>
						</td>
                      </tr>
					  
					  <tr><td colspan="3">&nbsp;</td></tr>
					  
					  <tr>
                        <td width="10%"><strong>Enter Number of Lights: </strong></td>
                        <td width="1%">&nbsp;</td>
                        <td width="89%"><input type="text" name="numLight" id="numLight" value="<?php echo $numLight;?>" class="form-control" style="width: 180px;" <?php if($sAccess == 1) { echo 'disabled="disabled"';} ?>>
						</td>
                      </tr>
					  
					  <tr><td colspan="3">&nbsp;</td></tr>
					  
					  <tr>
                        <td width="10%"><strong>Enter Number of Heater: </strong></td>
                        <td width="1%">&nbsp;</td>
                        <td width="89%"><input type="text" name="numHeater" id="numHeater" value="<?php echo $numHeater;?>" class="form-control" style="width: 180px;" <?php if($sAccess == 1) { echo 'disabled="disabled"';} ?>>
						</td>
                      </tr>
					  
					  <tr><td colspan="3">&nbsp;</td></tr>
					  
					  <tr>
                        <td width="10%"><strong>Enter Number of Blower: </strong></td>
                        <td width="1%">&nbsp;</td>
                        <td width="89%"><input type="text" name="numBlower" id="numBlower" value="<?php echo $numBlower;?>" class="form-control" style="width: 180px;" <?php if($sAccess == 1) { echo 'disabled="disabled"';} ?>>
						</td>
                      </tr>
					  
					  <tr><td colspan="3">&nbsp;</td></tr>
					  
					  <tr>
                        <td width="10%"><strong>Display Remote spa on Dashboard?: </strong></td>
                        <td width="1%">&nbsp;</td>
                        <td width="89%"><input type="radio" name="showRemoteSpa" value="0" <?php if((isset($extra['Remote_Spa']) && $extra['Remote_Spa'] == '0')) { echo 'checked="checked";';}?> checked="checked" <?php if($sAccess == 1) { echo 'disabled="disabled"';} ?>>&nbsp;No&nbsp;&nbsp;<input type="radio" name="showRemoteSpa" value="1" <?php if((isset($extra['Remote_Spa']) && $extra['Remote_Spa'] == '1')) { echo 'checked="checked";';}?> <?php if($sAccess == 1) { echo 'disabled="disabled"';} ?>>&nbsp;Yes
						</td>
                      </tr>
					  
					  
					  
                      <tr><td colspan="3">&nbsp;</td></tr>
                      <tr><td colspan="3"><!--<input type="<?php if($sAccess == 2) { echo 'submit';} else { echo 'button';} ?>" name="command" value="Save Setting" class="btn btn-success" onclick="return checkModeSelected();">-->
					  <a href="javascript:void(0);" <?php if($sAccess == 2) { ?> onclick="checkModeSelected();" <?php } ?> class="btn btn-green"><span>Save Setting</span></a>
					  </td></tr>
                      
                    </table>
                  </form>
                </div>
              </div>
            </div>
          </div>
        </div><!-- /.row -->
      </div><!-- /#page-wrapper -->
<script type="text/javascript">
$(document).ready(function (){
	$("input[name='showPoolTemp']").click(function(){
		var checkedVal =	$(this).val();
		if(checkedVal == '1')
		{
			$("#poolTempID").show();
		}
		else
		{
			$("#poolTempID").hide();
		}
	});
	
	$("input[name='showSpaTemp']").click(function(){
		var checkedVal =	$(this).val();
		if(checkedVal == '1')
		{
			$("#spaTempID").show();
		}
		else
		{
			$("#spaTempID").hide();
		}
	});	
});
  function checkModeSelected()
  {
    var sRelayMode 		= 	$("#relay_mode").val();
	var manualMinutes	=	$("#manualMinutes").val();
	$("#command").val('');
    if(sRelayMode == '0')
    {
      $("#relay_mode").css('border','1px solid #B40404');
      alert('Please select Mode!');
      return false;
    }
    else
    {
      $("#relay_mode").css('border','');
    }
	
	if(manualMinutes != '')
	{
		if(isNaN(manualMinutes))
		{
			$("#manualMinutes").css('border','1px solid #B40404');
			alert("Please enter valid minutes!")
			return false;
		}
		else
		{
			$("#manualMinutes").css('border','');
			
		}
	}
	
	$("#command").val('Save Setting');
	document.settingForm.submit();
	//return true;
	

  }
  
  
</script>
<?php

?>