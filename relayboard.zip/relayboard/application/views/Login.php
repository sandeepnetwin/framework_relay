<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>Relay Board - Login</title>
	
	<!-- main JS libs -->
	<script src="<?php echo HTTP_JS_PATH; ?>libs/jquery-1.10.2.min.js"></script>
	<script src="<?php echo HTTP_JS_PATH; ?>libs/jquery-ui.min.js"></script>
	<script src="<?php echo HTTP_JS_PATH; ?>libs/bootstrap.min.js"></script>

	<!-- Style CSS -->
	<link href="<?php echo HTTP_CSS_PATH; ?>bootstrap.css" media="screen" rel="stylesheet">
	<link href="<?php echo HTTP_ASSETS_PATH; ?>style.css" media="screen" rel="stylesheet">

	<!-- General Scripts -->
	<script src="<?php echo HTTP_JS_PATH; ?>general.js"></script>

	<!-- custom input -->
	<script src="<?php echo HTTP_JS_PATH; ?>jquery.customInput.js"></script>
  
	<link rel="stylesheet" href="<?php echo HTTP_CSS_PATH; ?>chosen.css">
	<script src="<?php echo HTTP_JS_PATH; ?>chosen.jquery.min.js" type="text/javascript"></script>
	<script type="text/javascript" src="<?php echo HTTP_JS_PATH; ?>jquery.powerful-placeholder.min.js"></script>
	
	<script>
		jQuery(document).ready(function($) {
			if($("[placeholder]").size() > 0) {
				$.Placeholder.init();
			}
			
			jQuery('#contact-name').chosen({ width: "100%" });
			jQuery('#commentForm .link-reset').click(function(){
				jQuery("#contact-name").trigger("chosen:updated");
			});
			
			jQuery("#signup").click(function(){
				if(jQuery(this).prop('checked') == true)
				{
					jQuery("#remember").val('1');
				}
				else
				{
					jQuery("#remember").val('0');
				}
			});
			
		});
		jQuery('#commentForm .link-reset').click(function(){
            myNicEditor.removeInstance('nicedit-message');
            $('#nicedit-message').val('');
            myNicEditor.panelInstance('nicedit-message');
        });
	</script>
	<style>
	@media screen and (min-device-width: 320px) and (max-device-width: 480px) 
	{ 
		.add-comment
		{
			max-width:90% !important;
		}
	}
	</style
    </head>

<body>
<div class="body-wrap">
    <div class="content">
        <!--container-->
        <div class="container">
				
				<div class="add-comment contact-form styled boxed green-line" style="margin:0 auto; max-width:65%; height:<?php if(validation_errors() != '') { echo '350px;';} else { echo '300px;';}?>">
				
				<div class="comment-form">
					<form name="commentForm" action="<?php echo base_url('dashboard/do_login/'); ?>" method="post" id="commentForm">
					<input type="hidden" name="remember" value="0" id="remember">
						<div class="inner">
							<div class="field_text">
								<h2>Login</h2>
							</div>
							<?php if(validation_errors() != '') {
								echo '<span style="color:#FF0000">'.validation_errors().'</span>';
							} ?>
							<?php if($error != '') {
								echo '<span style="color:#FF0000">'.$error.'</span>';
							} ?>
							
							<div class="field_text">
								<input type="text" name="username" id="username" placeholder="User Name">
							</div>

							<div class="field_text omega">
								<input type="password" name="password" id="password" placeholder="Password">
							</div>
							<div class="rowSubmit clearfix">
								<span class="btn btn-icon btn-icon-login btn-submit btn-green">
									<input type="submit" id="send" value="Login" />
								</span>
								<div class="input_styled checklist" style="width:300px;">
									<div class="rowCheckbox">
										<input type="checkbox" id="signup" value="1" name="signup" >
										<label for="signup">Remeber Me</label>
									</div>
								</div>	
								
							</div>	
							
						</div>
					</form>
				</div>
			</div>
    </div>
	</div>
	</div>
  </body>
</html>