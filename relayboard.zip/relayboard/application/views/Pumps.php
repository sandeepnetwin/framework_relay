<!-- START : PUMPS -->
<div class="row">
	<?php
		if(!empty($aIPDetails))
		{
			foreach($aIPDetails as $aIP)
			{
				if($aIP->id <= 1)
					$iPumpsNumber = $extra['PumpsNumber'];
			    else if($aIP->id > 1)
					$iPumpsNumber = $extra['PumpsNumber2'];
				
				//$totalPumps = count(${'Pumps'.$aIP->id});
				
				//if($totalPumps == 0)
					$totalPumps = $iPumpsNumber;
	?>
	<div class="col-sm-6" id="onoffbuttons_<?php echo $aIP->id;?>" style="display:<?php if($aIP->id != $iFirstIPId){ echo 'none';} ?>">
		<div class="widget-container widget-stats boxed green-line">
		<div class="refreshLoading" id="refreshLoading_<?php echo $aIP->id;?>"><img src="<?php echo base_url("assets/images/loading.gif");?>" alt="loading">&nbsp;Refreshing Devices....</div>
		<div class="widget-title">
			<a href="javascript:void(0);" class="link-refresh" id="link-refresh-1" onclick="refreshDeviceStatus('PS');"><span class="glyphicon glyphicon-refresh"></span></a>
			<h3>ON/OFF</h3>
		</div>
		<div class="stats-content clearfix">
			<div class="stats-content-right" style="width:96% !important; margin-left:5px; margin-right:5px; margin-top:10px; float:none;">
			<?php
				if( $iPumpsNumber == 0 || $iPumpsNumber == '' )
				{ 
			?>
					<div class="row">
						<div class="col-sm-12">
							<span style="color:red">Please add number of Pumps in the <a href="<?php echo base_url('home/setting/');?>">Settings</a> Page!</span>
						</div>
					</div>
						
			<?php 
				}
				else
				{
					
					//$arrPump		=	array(0,1,2);
					$arrPump		=	range(1, $totalPumps);
					$remainigCount	=	0;
					$chkPump		=	0;
					if(!empty(${"Pumps".$aIP->id}))
					{
						foreach(${"Pumps".$aIP->id} as $pump)
						{
							
						$i= $pump->pump_number;
						$key = array_search($i, $arrPump); 
						unset($arrPump[$key]);		
						$iPumpVal = $sPump[$i];
						$sPumpNameDb =  $this->home_model->getDeviceName($i,$sDevice,$aIP->id);
						if($sPumpNameDb == '')
						  $sPumpNameDb = 'Add Name';
						
						$sStatus2Speed	=	'';
						
						$aPumpDetails = $this->home_model->getPumpDetails($i,$aIP->id);
						$sPumpType		=	'';
						if(!empty($aPumpDetails))
						{
							foreach($aPumpDetails as $aResultEdit)
							{
								$sPumpStatus  = $aResultEdit->status;
								$sPumpType    = $aResultEdit->pump_type;//Pump Type
								$sPumpRelay   = $aResultEdit->relay_number;//Assigned Relay Number
								$sPumpRelay1   = $aResultEdit->relay_number_1;//Assigned Relay Number
								if($sPumpType == '12')
								{
									$iPumpVal = ${"sPowercenter".$aIP->id}[$sPumpRelay]; //Taken the status
								}
								else if($sPumpType == '24')
								{
									$iPumpVal = ${"sRelays".$aIP->id}[$sPumpRelay];//Taken the status
								}
								else if($sPumpType == '2Speed')
								{
									$sPumpSubType    = $aResultEdit->pump_sub_type;//Pump SUB Type
									$sStatus2Speed   = $aResultEdit->status;//Pump SUB Type
									
									if($sStatus2Speed == '0')
									{
										$iPumpVal        = $sStatus2Speed;
									}
									else if($sStatus2Speed == '1')											
									{
										if($sPumpSubType == '12')
										{
											$iPumpVal = ${"sPowercenter".$aIP->id}[$sPumpRelay]; //Taken the status
										}
										else if($sPumpSubType == '24')
										{
											$iPumpVal = ${"sRelays".$aIP->id}[$sPumpRelay];//Taken the status
										}
									}
									else if($sStatus2Speed == '2')											
									{
										if($sPumpSubType == '12')
										{
											$iPumpVal = ${"sPowercenter".$aIP->id}[$sPumpRelay1]; //Taken the status
										}
										else if($sPumpSubType == '24')
										{
											$iPumpVal = ${"sRelays".$aIP->id}[$sPumpRelay1];//Taken the status
										}
									}
								}
								else if(preg_match('/Emulator/',$sPumpType))
								{
									 $iPumpVal = ${"sPump".$aIP->id}[$i];
								}
							}
						}	//END : Getting assigned relay status from the Server.
						
						$iPumpVal = $sPumpStatus;
						$sPumpVal = false;
						if($iPumpVal)
						  $sPumpVal = true;
						
						$strChecked	=	'';
						if($iPumpVal > 0)
							$strChecked	=	'class="checked"';
					  
						$sMainType	 = $this->home_model->getDeviceMainType($i,$sDevice,$aIP->id);
						
						$strPumpName = '<span style="float:right">Pump '.$i.'</span>';
						if($sPumpNameDb != '' && $sPumpNameDb != 'Add Name')
							$strPumpName .= '<br>('.$sPumpNameDb.')';
						
						if($sStatus2Speed == '')
							$sStatus2Speed = '0';
						
						//Check if Device is Excluded.
						$IsExcluded = $this->home_model->getDeviceExcluded($i,$sDevice,$aIP->id);
						
						//Get Port Number
						/* $sDevicePort	=	$this->home_model->getDevicePort($i,$sDevice);
						
						if($sDevicePort == '')
							$sDevicePort = 0;
						
						$strPortClass	=	'port_'.$sDevicePort; */
				?>
							<div class="row">
							<div class="col-sm-12">
							<?php if($sPumpType == '2Speed') { ?>
							<script>
							var iActiveMode = '<?php echo $iActiveMode;?>';
							var sAccess 	= '<?php echo $sAccess;?>';
							</script>
							<link href="<?php echo site_url('assets/switchy/switchy.css'); ?>" rel="stylesheet" />
							<script type="text/javascript" src="<?php echo site_url('assets/switchy/switchy.js'); ?>"></script>
							<script type="text/javascript" src="<?php echo site_url('assets/switchy/jquery.event.drag.js'); ?>"></script>
							<script type="text/javascript" src="<?php echo site_url('assets/switchy/jquery.animate-color.js'); ?>"></script>
							<div class="span1 pump-<?php echo $i?>-<?php echo $aIP->id;?>" value="1" style="margin-top: 10px; width: auto; color: #428BCA;font-weight: bold; cursor: pointer; float: left;">Relay 1</div>
							<div class="span2" style="margin-left:5px; margin-right:5px; float: left;" >
							<select id='switch-me-<?php echo $i;?>-<?php echo $aIP->id;?>'>
							<option value='1' <?php if($sStatus2Speed == '1') { echo 'selected="selected"';} ?>>Spa</option>
							<option value='0' <?php if($sStatus2Speed == '0' || $iPumpVal == '') { echo 'selected="selected"';} ?>></option>
							<option value='2' <?php if($sStatus2Speed == '2') { echo 'selected="selected"';} ?>>Pool</option>
							</select>
							<input type="hidden" name="hidIsManual_<?php echo $i;?>_<?php echo $aIP->id;?>_all" value="" id="hidIsManual_<?php echo $i;?>_<?php echo $aIP->id;?>_all">
							<div class="pump-<?php echo $i?>-<?php echo $aIP->id;?>" value="0" id="off-<?php echo $i;?>-<?php echo $aIP->id;?>" style="color: red;font-weight: bold;width: 0; margin-left: 30px; cursor: pointer;">
								OFF
							</div>                              </div>
							<div class="span1 pump-<?php echo $i?>-<?php echo $aIP->id;?>" value="2" style="margin-top: 10px; width: auto; color: #428BCA;font-weight: bold; cursor: pointer; float: left;">Relay 2</div>
							<div style="margin-top:10px; float:right; color:#C9376E;"><strong><?php echo $strPumpName;?></strong></div>
							
						  <script type="text/javascript">
						  
						  $(function()
						  {
							  var bgColor = '#E8E8E8';
								<?php if($iPumpVal == '1' || $iPumpVal == '2') { ?>
										bgColor = '#45A31F';
								<?php } else { ?>
										bgColor = '#E8E8E8';
								<?php } ?>
								
								$('#switch-me-<?php echo $i;?>-<?php echo $aIP->id;?>').switchy();
								
								$('.pump-<?php echo $i?>-<?php echo $aIP->id;?>').on('click', function(event){
									var iActiveMode = $("#hidActiveMode").val();
									if(iActiveMode != 3)
									{
										if(iActiveMode != 2)
										{
											$('#hidIsManual_<?php echo $i;?>_<?php echo $aIP->id;?>_all').val('1');
										}
										$('#switch-me-<?php echo $i;?>-<?php echo $aIP->id;?>').val($(this).attr('value')).change();
									}
									else
									{
										alert('You can perform this operation in Time-out Mode.');
									}
								});
								
								$('#switch-me-<?php echo $i;?>-<?php echo $aIP->id;?>').next('.switchy-container').find('.switchy-bar').animate({
										backgroundColor: bgColor
									});
								
								$('#switch-me-<?php echo $i;?>-<?php echo $aIP->id;?>').on('change', function(event)
								{
									var iActiveMode = $("#hidActiveMode").val();
									var relayNumber = '<?php echo $i?>';
									if(sAccess == 2)
									{
										var idDetails = $(this).attr('id');
											
										var aDetails  = idDetails.split("-");
										var hidIsManual = $('#hidIsManual_'+aDetails[2]+'_'+aDetails[3]+'_all').val();
										
										var chkConfirm = true;
										
										<?php if($IsExcluded == 0) { ?>
										if(hidIsManual == '1')
										{
											if(iActiveMode != 2)
											{
												if(cntOnPrograms >= 1)
												{
													chkConfirm = confirm("Are you sure you want to make this device ON/OFF?\nThis will stop all Custom Programs/Programs running in background!");
												}
												if(chkConfirm)
												{
													$.ajax({
														type: "POST",
														url: "<?php echo site_url('analog/changeMode');?>", 
														data: {iMode:'2'},
														success: function(data) {
															$("#hidActiveMode").val('2');
														}
													});
												}
											}
											$('#hidIsManual_'+aDetails[2]+'_'+aDetails[3]+'_all').val('');
											
										}
										<?php } ?>
										if(chkConfirm)
										{
											var bgColor = '#E8E8E8';

											if ($(this).val() == '1' || $(this).val() == '2')
											{
												bgColor = '#45A31F';
											} 
											$('#switch-me-<?php echo $i;?>-<?php echo $aIP->id;?>').next('.switchy-container').find('.switchy-bar').animate({
												backgroundColor: bgColor
											});
											
											if($(this).val() == '0')
											{
												$('#switch-me-<?php echo $i;?>-<?php echo $aIP->id;?>').next('.switchy-container').find('.switchy-slider').animate({
													'left': '20px'
												},"fast");
											}
											else if($(this).val() == '1')
											{
												$('#switch-me-<?php echo $i;?>-<?php echo $aIP->id;?>').next('.switchy-container').find('.switchy-slider').animate({
													'left': '0px'
												},"fast");
											}
											else if($(this).val() == '2')
											{
												$('#switch-me-<?php echo $i;?>-<?php echo $aIP->id;?>').next('.switchy-container').find('.switchy-slider').animate({
													'left': '40px'
												},"fast");
											}	
										
											
											$.ajax({
												type: "POST",
												url: "<?php echo site_url('home/updateStatusOnOff');?>", 
												data: {sName:'<?php echo $i;?>',sStatus:$(this).val(),sDevice:'<?php echo $sDevice;?>',sIdIP:'<?php echo $aIP->id;?>'},
												success: function(data) {
													//$("#hidActiveMode").val(iActiveMode);
												}

											});
										}
									}
								});
							});
					   </script>
					   
							<?php } else if($sPumpType != '') { ?>
							
							<?php if(preg_match('/Emulator/',$sPumpType)) { ?>
							<script>
							  $(document).ready(function() {
								setInterval( function() {
									$.getJSON('<?php echo site_url('cron/pumpResponseLatest/');?>', {iPumpID: "<?php echo $i;?>",sIpId : '<?php echo $aIP->id;?>'}, function(json) {
										
										if(json == '')
										{
											//$("#lablePump-"+<?php echo $i;?>+"-"+<?php echo $aIP->id;?>).removeClass('checked');
											$("#pumpRealResponse_"+<?php echo $i;?>+"_"+<?php echo $aIP->id;?>).html('');
											$("#pumpProgrmaStatus_"+<?php echo $i;?>+"_"+<?php echo $aIP->id;?>).html('');
										}
										else
										{
											$("#pumpRealResponse_"+<?php echo $i;?>+"_"+<?php echo $aIP->id;?>).html(json);
											if($("#lablePump-"+<?php echo $i;?>+"-"+<?php echo $aIP->id;?>).hasClass('checked'))
											{}
											else
											{
												$("#lablePump-"+<?php echo $i;?>+"-"+<?php echo $aIP->id;?>).addClass('checked');
											}
										}
									});
									},30000);
									
									setInterval( function() {
									$.getJSON('<?php echo site_url('cron/getPumpProgramStatus/');?>', {iPumpID: "<?php echo $i;?>",sIpId : '<?php echo $aIP->id;?>'}, function(json) {
										
										if(json == '')
										{
											$("#pumpProgrmaStatus_"+<?php echo $i;?>+"_"+<?php echo $aIP->id;?>).html('');
										}
										else
										{
											$("#pumpProgrmaStatus_"+<?php echo $i;?>+"_"+<?php echo $aIP->id;?>).html(json);
										}
									});
									},30000);
									
							  });
							</script>										  
							   <?php } ?>
							<div class="rowCheckbox switch">
								<div class="custom-checkbox"><input type="checkbox" value="<?php echo $i;?>" id="pumps-<?php echo $i?>" name="pumps-<?php echo $i?>" class="pumpsButton" data-exclude ="<?php echo $IsExcluded;?>" hidefocus="true" style="outline: medium none;">
									<label style="margin-left: 10px;" <?php echo $strChecked;?>  id="lablePump-<?php echo $i?>-<?php echo $aIP->id;?>" for="pumps-<?php echo $i?>"><span style="float:right; color:#C9376E;"><?php echo $strPumpName;?></span></label>
								</div>
							</div>
								<?php if(preg_match('/Emulator/',$sPumpType)) { ?>
								<div id="pumpRealResponse_<?php echo $i;?>_<?php echo $aIP->id;?>" style="color: #164c87;font-weight: bold;"><?php if($iPumpVal > 0) { echo $strPumpsResponse		= $this->home_model->selectPumpsLatestResponse($i,$aIP->id); }?></div>
								<div id="pumpProgrmaStatus_<?php echo $i;?>_<?php echo $aIP->id;?>" style="color: #c9376e;font-weight: bold;"><?php if($iPumpVal > 0)
								{
									$aAllActiveProgram	=	$this->home_model->getAllActiveProgramsForPump($i,$aIP->id);
									$strMessage		=	'';	
									if(!empty($aAllActiveProgram))
									{
										foreach($aAllActiveProgram as $aActiveProgram)
										{
											if($aActiveProgram->device_type == 'PS')
											{
												$aPumpDetails 	=	$this->home_model->getPumpDetails($aActiveProgram->device_number,$aIP->id);
												
												if(is_array($aPumpDetails) && !empty($aPumpDetails))
												{
													foreach($aPumpDetails as $aResultEdit)
													{ 
														$sPumpNumber  = $aResultEdit->pump_number;
														$sPumpType    = $aResultEdit->pump_type;
														$sPumpSubType = $aResultEdit->pump_sub_type;
														$sPumpSpeed   = $aResultEdit->pump_speed;
													}
												}
												
												if($strMessage != '')
												{
													$strMessage .= ' <br /><strong>'.$aActiveProgram->program_name.'</strong> Program is Running for <strong>Pump '.$aActiveProgram->device_number.'</strong>';
													
													if($sPumpType	==	'Emulator' && $sPumpSubType == 'VS')
													{
														$strMessage .= ' With <strong>Speed '.$sPumpSpeed.' </strong>';
													}
													$strMessage .= '!';
												}
												else
												{
													$strMessage .= '<strong>'.$aActiveProgram->program_name.'</strong> Program is Running for <strong>Pump '.$aActiveProgram->device_number.'</strong>';
													
													if($sPumpType	==	'Emulator' && $sPumpSubType == 'VS')
													{
														$strMessage .= ' With <strong>Speed '.$sPumpSpeed.' </strong>';
													}
													$strMessage .= '!';
												}
											}
										}
									}	
									echo $strMessage;		
								}?></div>
								<?php } ?>
							<?php } ?>
							</div>
							</div>
							<div style="height:20px;">&nbsp;</div>
						<?php 
							$chkPump++;
						}
						?>
					<?php } ?>
					<?php 
						$remainigCount	=	$iPumpsNumber - $chkPump;
						//for ($i=0;$i < $valve_count; $i++)	
						//for ($i=0;$i < $remainigCount ; $i++)
						//	echo '<pre>';print_r($arrPump);echo '</pre>';
						foreach($arrPump as $i)	
						{
							if($remainigCount == 0)	
								break;
							
							$remainigCount--;
									
						//for ($i=0;$i < $pump_count; $i++)
						//{
							$iPumpVal = ${"sPump".$aIP->id}[$i];
							/* $iPumpNewValSb = 1;
							if($iPumpVal == 1)
							{
							  $iPumpNewValSb = 0;
							}
							$sPumpVal = false;
							if($iPumpVal)
							  $sPumpVal = true; */
							//$sRelayNameDb = get_device_name(1, $i);
						
							$sPumpNameDb =  $this->home_model->getDeviceName($i,$sDevice,$aIP->id);
							if($sPumpNameDb == '')
							  $sPumpNameDb = 'Add Name';
						  
							//Check if Device is Excluded.
							$IsExcluded = $this->home_model->getDeviceExcluded($i,$sDevice,$aIP->id);
							
							//$iPower	 = $this->home_model->getDevicePower($i,$sDevice);
							
							//$sPowercenter = '01000000'		;
							//START : Getting assigned relay status from the Server.	
							//Details of Pump
							
							$sStatus2Speed	=	'';
							
							$aPumpDetails = $this->home_model->getPumpDetails($i,$aIP->id);
							$sPumpType		=	'';
							if(!empty($aPumpDetails))
							{
								foreach($aPumpDetails as $aResultEdit)
								{
									$sPumpStatus  = $aResultEdit->status;
									$sPumpType    = $aResultEdit->pump_type;//Pump Type
									$sPumpRelay   = $aResultEdit->relay_number;//Assigned Relay Number
									$sPumpRelay1   = $aResultEdit->relay_number_1;//Assigned Relay Number
									if($sPumpType == '12')
									{
										$iPumpVal = ${"sPowercenter".$aIP->id}[$sPumpRelay]; //Taken the status
									}
									else if($sPumpType == '24')
									{
										$iPumpVal = ${"sRelays".$aIP->id}[$sPumpRelay];//Taken the status
									}
									else if($sPumpType == '2Speed')
									{
										$sPumpSubType    = $aResultEdit->pump_sub_type;//Pump SUB Type
										$sStatus2Speed   = $aResultEdit->status;//Pump SUB Type
										
										
										if($sStatus2Speed == '0')
										{
											$iPumpVal        = $sStatus2Speed;
										}
										else if($sStatus2Speed == '1')											
										{
											if($sPumpSubType == '12')
											{
												$iPumpVal = ${"sPowercenter".$aIP->id}[$sPumpRelay]; //Taken the status
											}
											else if($sPumpSubType == '24')
											{
												$iPumpVal = ${"sRelays".$aIP->id}[$sPumpRelay];//Taken the status
											}
										}
										else if($sStatus2Speed == '2')											
										{
											if($sPumpSubType == '12')
											{
												$iPumpVal = ${"sPowercenter".$aIP->id}[$sPumpRelay1]; //Taken the status
											}
											else if($sPumpSubType == '24')
											{
												$iPumpVal = ${"sRelays".$aIP->id}[$sPumpRelay1];//Taken the status
											}
										}
									}
									else if(preg_match('/Emulator/',$sPumpType))
									{
										 $iPumpVal = ${"sPump".$aIP->id}[$i];
									}
								}
							}	//END : Getting assigned relay status from the Server.
							
							$iPumpVal = $sPumpStatus;
							$sPumpVal = false;
							if($iPumpVal)
							  $sPumpVal = true;
						  
							$sMainType	 = $this->home_model->getDeviceMainType($i,$sDevice,$aIP->id);
							
							$strChecked	=	'';
							if($iPumpVal >= '1')
								$strChecked	=	'class="checked"';
							
							$strPumpName = '<span style="float:right">Pump '.$i.'</span>';
							if($sPumpNameDb != '' && $sPumpNameDb != 'Add Name')
								$strPumpName .= '<br>('.$sPumpNameDb.')';
							
							if($sStatus2Speed == '')
								$sStatus2Speed = '0';
							
					?>	
							<div class="row">
							<div class="col-sm-12">
							<?php if($sPumpType == '2Speed') { ?>
							<script>
								var iActiveMode = '<?php echo $iActiveMode;?>';
								var sAccess 	= '<?php echo $sAccess;?>';
							</script>
							<link href="<?php echo site_url('assets/switchy/switchy.css'); ?>" rel="stylesheet" />
							<script type="text/javascript" src="<?php echo site_url('assets/switchy/switchy.js'); ?>"></script>
							<script type="text/javascript" src="<?php echo site_url('assets/switchy/jquery.event.drag.js'); ?>"></script>
							<script type="text/javascript" src="<?php echo site_url('assets/switchy/jquery.animate-color.js'); ?>"></script>
							<div class="span1 pump-<?php echo $i?>-<?php echo $aIP->id;?>" value="1" style="margin-top: 10px; width: auto; color: #428BCA;font-weight: bold; cursor: pointer; float: left;">Relay 1</div>
							<div class="span2" style="margin-left:5px; margin-right:5px; float: left;" >
							<select id='switch-me-<?php echo $i;?>-<?php echo $aIP->id;?>'>
							<option value='1' <?php if($sStatus2Speed == '1') { echo 'selected="selected"';} ?>>Spa</option>
							<option value='0' <?php if($sStatus2Speed == '0' || $iPumpVal == '') { echo 'selected="selected"';} ?>></option>
							<option value='2' <?php if($sStatus2Speed == '2') { echo 'selected="selected"';} ?>>Pool</option>
							</select>
							<input type="hidden" name="hidIsManual_<?php echo $i;?>_<?php echo $aIP->id;?>_all" value="" id="hidIsManual_<?php echo $i;?>_<?php echo $aIP->id;?>_all">
							<div class="pump-<?php echo $i?>-<?php echo $aIP->id;?>" value="0" id="off-<?php echo $i;?>-<?php echo $aIP->id;?>" style="color: red;font-weight: bold;width: 0; margin-left: 30px; cursor: pointer;">
								OFF
	</div>                              </div>
							<div class="span1 pump-<?php echo $i?>-<?php echo $aIP->id;?>" value="2" style="margin-top: 10px; width: auto; color: #428BCA;font-weight: bold; cursor: pointer; float: left;">Relay 2</div>
							<div style="margin-top:10px; float:right; color:#C9376E;"><strong><?php echo $strPumpName;?></strong></div>
						  <script type="text/javascript">
						  
						  $(function()
						  {
							  var bgColor = '#E8E8E8';
								<?php if($iPumpVal == '1' || $iPumpVal == '2') { ?>
										bgColor = '#45A31F';
								<?php } else { ?>
										bgColor = '#E8E8E8';
								<?php } ?>
								
								$('#switch-me-<?php echo $i;?>-<?php echo $aIP->id;?>').switchy();
								
								$('.pump-<?php echo $i?>-<?php echo $aIP->id;?>').on('click', function(event){
									//event.preventDefault();
									//return false;
									var iActiveMode = $("#hidActiveMode").val();
									if(iActiveMode != 3)
									{
										if(iActiveMode != 2)
										{
											$('#hidIsManual_<?php echo $i;?>_<?php echo $aIP->id;?>_all').val('1');
										}
										$('#switch-me-<?php echo $i;?>-<?php echo $aIP->id;?>').val($(this).attr('value')).change();
									}
									else
									{
										alert('You can perform this operation in Time-out Mode.');
									}
								});
								
								$('#switch-me-<?php echo $i;?>-<?php echo $aIP->id;?>').next('.switchy-container').find('.switchy-bar').animate({
										backgroundColor: bgColor
									});
								
								$('#switch-me-<?php echo $i;?>-<?php echo $aIP->id;?>').on('change', function(event)
								{
									var iActiveMode = $("#hidActiveMode").val();
									if(sAccess == 2)
									{
										
										var idDetails = $(this).attr('id');
											
										var aDetails  = idDetails.split("-");
										var hidIsManual = $('#hidIsManual_'+aDetails[2]+'_'+aDetails[3]+'_all').val();
										
										var chkConfirm = true;
										
										<?php if($IsExcluded == 0) { ?>
										if(hidIsManual == '1')
										{
											if(iActiveMode != 2)
											{
												if(cntOnPrograms >= 1)
												{
													chkConfirm = confirm("Are you sure you want to make this device ON/OFF?\nThis will stop all Custom Programs/Programs running in background!");
												}
												if(chkConfirm)
												{
													$.ajax({
														type: "POST",
														url: "<?php echo site_url('analog/changeMode');?>", 
														data: {iMode:'2'},
														success: function(data) {
															$("#hidActiveMode").val('2');
														}
													});
												}
											}
											$('#hidIsManual_'+aDetails[2]+'_'+aDetails[3]+'_all').val('');
											
										}
										<?php } ?>
										if(chkConfirm)
										{
											var bgColor = '#E8E8E8';

											if ($(this).val() == '1' || $(this).val() == '2')
											{
												bgColor = '#45A31F';
											} 
											$('#switch-me-<?php echo $i;?>-<?php echo $aIP->id;?>').next('.switchy-container').find('.switchy-bar').animate({
												backgroundColor: bgColor
											});
											
											if($(this).val() == '0')
											{
												$('#switch-me-<?php echo $i;?>-<?php echo $aIP->id;?>').next('.switchy-container').find('.switchy-slider').animate({
													'left': '20px'
												},"fast");
											}
											else if($(this).val() == '1')
											{
												$('#switch-me-<?php echo $i;?>-<?php echo $aIP->id;?>').next('.switchy-container').find('.switchy-slider').animate({
													'left': '0px'
												},"fast");
											}
											else if($(this).val() == '2')
											{
												$('#switch-me-<?php echo $i;?>-<?php echo $aIP->id;?>').next('.switchy-container').find('.switchy-slider').animate({
													'left': '40px'
												},"fast");
											}
										
											
											$.ajax({
												type: "POST",
												url: "<?php echo site_url('home/updateStatusOnOff');?>", 
												data: {sName:'<?php echo $i;?>',sStatus:$(this).val(),sDevice:'<?php echo $sDevice;?>',sIdIP:'<?php echo $aIP->id;?>'},
												success: function(data) {
													//$("#hidActiveMode").val(iActiveMode);
												}

											});
										}
									}
								});
							});
					   </script>
					   
							<?php } else if($sPumpType != '') { ?>
							<?php if(preg_match('/Emulator/',$sPumpType)) { ?>
							<script>
							  $(document).ready(function() {
								setInterval( function() {
									$.getJSON('<?php echo site_url('cron/pumpResponseLatest/');?>', {iPumpID: "<?php echo $i;?>",sIpId : '<?php echo $aIP->id;?>'}, function(json) {
										
										if(json == '')
										{
											//$("#lablePump-"+<?php echo $i;?>+"-"+<?php echo $aIP->id;?>).removeClass('checked');
											$("#pumpRealResponse_"+<?php echo $i;?>+"_"+<?php echo $aIP->id;?>).html('');
											$("#pumpProgrmaStatus_"+<?php echo $i;?>+"_"+<?php echo $aIP->id;?>).html('');
										}
										else
										{
											$("#pumpRealResponse_"+<?php echo $i;?>+"_"+<?php echo $aIP->id;?>).html(json);
											if($("#lablePump-"+<?php echo $i;?>+"-"+<?php echo $aIP->id;?>).hasClass('checked'))
											{}
											else
											{
												$("#lablePump-"+<?php echo $i;?>+"-"+<?php echo $aIP->id;?>).addClass('checked');
											}
										}
									});
									},30000);
									
									setInterval( function() {
									$.getJSON('<?php echo site_url('cron/getPumpProgramStatus/');?>', {iPumpID: "<?php echo $i;?>",sIpId : '<?php echo $aIP->id;?>'}, function(json) {
										
										if(json == '')
										{
											$("#pumpProgrmaStatus_"+<?php echo $i;?>+"_"+<?php echo $aIP->id;?>).html('');
										}
										else
										{
											$("#pumpProgrmaStatus_"+<?php echo $i;?>+"_"+<?php echo $aIP->id;?>).html(json);
										}
									});
									},30000);
									
							  });
							</script>
							<?php } ?>
							 <div class="rowCheckbox switch">
								<div class="custom-checkbox"><input type="checkbox" value="<?php echo $i;?>" id="pumps-<?php echo $i?>" name="pumps-<?php echo $i?>" class="pumpsButton" hidefocus="true" style="outline: medium none;" data-exclude ="<?php echo $IsExcluded;?>">
									<label style="margin-left: 10px;" <?php echo $strChecked;?>  id="lablePump-<?php echo $i?>-<?php echo $aIP->id;?>" for="pumps-<?php echo $i?>"><span style="color:#C9376E;float:right;" ><?php echo $strPumpName;?></span></label>
								</div>
							</div>
							
							<?php if(preg_match('/Emulator/',$sPumpType)) { ?>
								<div id="pumpRealResponse_<?php echo $i;?>_<?php echo $aIP->id;?>" style="color: #164c87;font-weight: bold;"><?php if($iPumpVal > 0) { echo $strPumpsResponse		= $this->home_model->selectPumpsLatestResponse($i,$aIP->id); }?></div>
								<div id="pumpProgrmaStatus_<?php echo $i;?>_<?php echo $aIP->id;?>" style="color: #c9376e;font-weight: bold;"><?php if($iPumpVal > 0)
								{
									$aAllActiveProgram	=	$this->home_model->getAllActiveProgramsForPump($i,$aIP->id);
									$strMessage		=	'';	
									if(!empty($aAllActiveProgram))
									{
										foreach($aAllActiveProgram as $aActiveProgram)
										{
											if($aActiveProgram->device_type == 'PS')
											{
												$aPumpDetails 	=	$this->home_model->getPumpDetails($aActiveProgram->device_number,$aIP->id);
												
												if(is_array($aPumpDetails) && !empty($aPumpDetails))
												{
													foreach($aPumpDetails as $aResultEdit)
													{ 
														$sPumpNumber  = $aResultEdit->pump_number;
														$sPumpType    = $aResultEdit->pump_type;
														$sPumpSubType = $aResultEdit->pump_sub_type;
														$sPumpSpeed   = $aResultEdit->pump_speed;
													}
												}
												
												if($strMessage != '')
												{
													$strMessage .= ' <br /><strong>'.$aActiveProgram->program_name.'</strong> Program is Running for <strong>Pump '.$aActiveProgram->device_number.'</strong>';
													
													if($sPumpType	==	'Emulator' && $sPumpSubType == 'VS')
													{
														$strMessage .= ' With <strong>Speed '.$sPumpSpeed.' </strong>';
													}
													$strMessage .= '!';
												}
												else
												{
													$strMessage .= '<strong>'.$aActiveProgram->program_name.'</strong> Program is Running for <strong>Pump '.$aActiveProgram->device_number.'</strong>';
													
													if($sPumpType	==	'Emulator' && $sPumpSubType == 'VS')
													{
														$strMessage .= ' With <strong>Speed '.$sPumpSpeed.' </strong>';
													}
													$strMessage .= '!';
												}
											}
										}
									}	
									echo $strMessage;		
								}?></div>
								<?php } ?>
							
							<?php } else if($sPumpType == '') { ?>
							<span style="color:#E94180;"><strong>Pump <?php echo $i; ?> not configured.</strong></span>
							<?php } ?>
							</div>
							</div>
							<div style="height:20px;">&nbsp;</div>
						<?php } ?>
				<?php } ?>
			</div>
		</div>
		</div>
	</div>
	  
	<div class="col-sm-6" id="relayConfigure_<?php echo $aIP->id;?>" style="display:<?php if($aIP->id != $iFirstIPId){ echo 'none';} ?>">
			<!-- Statistics -->
			<div class="widget-container widget-stats boxed green-line">
				<div class="widget-title">
					<a href="<?php echo base_url('home/setting/'.$sDevice.'/');?>" class="link-refresh" id="link-refresh-1"><span class="glyphicon glyphicon-refresh"></span></a>
					<h3>PUMP Settings</h3>
				</div>
				<div class="stats-content clearfix">
					<div class="stats-content-right" style="width:100% !important; margin-left:5px; margin-right:5px; float:none;">
				
				  <table class="table table-hover">
					<thead>
					  <tr>
						<th class="header">Pump</th>
					  </tr>
					</thead>
					<tbody>
					
					<?php
		
					if( $iPumpsNumber == 0 || $iPumpsNumber == '' )
					{ ?>
						
						<tr>
							<td>
								<div class="row">
									<div class="col-sm-12">
										<span style="color:red">Please add number of Pumps in the <a href="<?php echo base_url('home/setting/');?>">Settings</a> Page!</span>
									</div>	
								</div>
							</td>
						</tr>
						
					<?php 
					}
					else
					{
						//$arrPump		=	array(0,1,2);
						$arrPump		=	range(1,$totalPumps);
						$remainigCount	=	0;
						$chkPump		=	0;
						if(!empty($Pumps))
						{
							foreach($Pumps as $pump)
							{
								
							$i= $pump->pump_number;
							$key = array_search($i, $arrPump); // $key = 2;
							unset($arrPump[$key]);		
							//unset($arrPump[$i]);		
							//for ($i=0;$i < $pump_count; $i++)
							//{
							$iPumpVal = $sPump[$i];
							/* $iPumpNewValSb = 1;
							if($iPumpVal == 1)
							{
							  $iPumpNewValSb = 0;
							}
							$sPumpVal = false;
							if($iPumpVal)
							  $sPumpVal = true; */
							//$sRelayNameDb = get_device_name(1, $i);
						
							$sPumpNameDb =  $this->home_model->getDeviceName($i,$sDevice,$aIP->id);
							if($sPumpNameDb == '')
							  $sPumpNameDb = 'Add Name';
							
							//$iPower	 = $this->home_model->getDevicePower($i,$sDevice);
							$sStatus2Speed	=	'';
							//$sPowercenter = '01000000'		;
							//START : Getting assigned relay status from the Server.	
							//Details of Pump
							$aPumpDetails = $this->home_model->getPumpDetails($i,$aIP->id);
							$sPumpType		=	'';
							$sPumpSpeed		=	'';
							$isExists		=	0;
							if(!empty($aPumpDetails))
							{
								foreach($aPumpDetails as $aResultEdit)
								{
									$isExists	  =	1;
									
									$sPumpType    = $aResultEdit->pump_type;//Pump Type
									$sPumpRelay   = $aResultEdit->relay_number;//Assigned Relay Number
									$sPumpRelay1   = $aResultEdit->relay_number_1;//Assigned Relay Number
									if($sPumpType == '12')
									{
										$iPumpVal = ${"sPowercenter".$aIP->id}[$sPumpRelay]; //Taken the status
									}
									else if($sPumpType == '24')
									{
										$iPumpVal = ${"sRelays".$aIP->id}[$sPumpRelay];//Taken the status
									}
									else if($sPumpType == '2Speed')
									{
										$sPumpSubType    = $aResultEdit->pump_sub_type;//Pump SUB Type
										$sStatus2Speed   = $aResultEdit->status;//Pump SUB Type
										
										
										if($sStatus2Speed == '0')
										{
											$iPumpVal        = $sStatus2Speed;
										}
										else if($sStatus2Speed == '1')											
										{
											if($sPumpSubType == '12')
											{
												$iPumpVal = ${"sPowercenter".$aIP->id}[$sPumpRelay]; //Taken the status
											}
											else if($sPumpSubType == '24')
											{
												$iPumpVal = ${"sRelays".$aIP->id}[$sPumpRelay];//Taken the status
											}
										}
										else if($sStatus2Speed == '2')											
										{
											if($sPumpSubType == '12')
											{
												$iPumpVal = ${"sPowercenter".$aIP->id}[$sPumpRelay1]; //Taken the status
											}
											else if($sPumpSubType == '24')
											{
												$iPumpVal = ${"sRelays".$aIP->id}[$sPumpRelay1];//Taken the status
											}
										}
									}
									else if(preg_match('/Emulator/',$sPumpType) || preg_match('/Intellicom/',$sPumpType))
									{
										 $iPumpVal 		= $sPump[$i];
										 $sPumpSpeed 	= $aResultEdit->pump_speed;	
									}
								}
							}//END : Getting assigned relay status from the Server.
							
							$sPumpVal = false;
							if($iPumpVal)
							  $sPumpVal = true;
						  
							$strChecked	=	'';
							if($iPumpVal >= '1')
								$strChecked	=	'class="checked"';
						  
							$sMainType	 = $this->home_model->getDeviceMainType($i,$sDevice,$aIP->id);
							
							$strPumpName = 'Pump '.$i;
							if($sPumpNameDb != '' && $sPumpNameDb != 'Add Name')
								$strPumpName .= ' ('.$sPumpNameDb.')';
					?>
						<tr>
						<td>
						<div class="row">
							<?php if(in_array($i.'_'.$aIP->id, $excludeDevices['PS'])) { ?>
							<div class="col-sm-12">
								
									<div style="position: relative;top:0;margin-bottom:10px;" class="ribbon ribbon-green"><span style="line-height:0px; font-size:14px;"><?php echo EXCLUDE_DEVICE;?></span></div>
								
							</div>
							<?php } ?>
							<div class="col-sm-3">
								Pump <?php echo $i;?><br />(<a href="<?php if($sAccess == 2) { echo site_url('home/deviceName/'.base64_encode($i).'/'.base64_encode($sDevice).'/'.base64_encode($aIP->id)); } else { echo 'javascript:void(0);';}?>" ><?php echo $sPumpNameDb;?></a>)
									<?php if($iPumpVal >= '1'){?>&nbsp;&nbsp;<a style="padding:6px 0;" class="btn btn-small btn-caps pumpsOffButton" href="javascript:void(0);" data-device="<?php echo $i;?>"><span>Off Pump</span></a><?php } ?>
							</div>
							<div class="col-sm-3">

								<div class="rowRadio">
									<div class="custom-radio">
									<strong class="customType">Type</strong><br><br>
									
									<input class="pumpRadio" type="radio" id="radio-other-<?php echo $i;?>-<?php echo $aIP->id;?>" value="0" name="<?php echo $i;?>_MainType" <?php if($sMainType == '0' || $sMainType == ''){ echo 'checked="checked"';}?> <?php if($sAccess == '1') { echo 'disabled="disabled"';}?> hidefocus="true" style="outline: medium none;">
									<label id="relay_other_<?php echo $i;?>_<?php echo $aIP->id;?>" for="radio-other-<?php echo $i;?>-<?php echo $aIP->id;?>" class="<?php if($sMainType == '0' || $sMainType == ''){ echo 'checked';}?>" style="display:inline-block;">Other</label>
									
									<input class="pumpRadio" type="radio" id="radio-spa-<?php echo $i;?>-<?php echo $aIP->id;?>" name="<?php echo $i;?>_MainType" value="1" <?php if($sMainType == '1'){ echo 'checked="checked"';}?> <?php if($sAccess == '1') { echo 'disabled="disabled"';}?> hidefocus="true" style="outline: medium none;">
									<label id="relay_spa_<?php echo $i;?>_<?php echo $aIP->id;?>" for="radio-spa-<?php echo $i;?>-<?php echo $aIP->id;?>" class="<?php if($sMainType == '1'){ echo 'checked';}?>" style="display:inline-block;">Spa</label>
									
									<input class="pumpRadio" type="radio" id="radio-pool-<?php echo $i;?>-<?php echo $aIP->id;?>" name="<?php echo $i;?>_MainType" value="2" <?php if($sMainType == '2'){ echo 'checked="checked"';}?> <?php if($sAccess == '1') { echo 'disabled="disabled"';}?> hidefocus="true" style="outline: medium none;">
									<label id="relay_pool_<?php echo $i;?>_<?php echo $aIP->id;?>" for="radio-pool-<?php echo $i;?>-<?php echo $aIP->id;?>" class="<?php if($sMainType == '2'){ echo 'checked';}?>" style="display:inline-block;">Pool</label>
									
									&nbsp;&nbsp;<span id="loadingImgPumpType_<?php echo $i.'_'.$aIP->id;?>" style="display:none;"><img src="<?php echo site_url('assets/images/loading.gif');?>" alt="Loading...." width="32" height="32"></span>
									</div>
								</div>
							</div>
							<div class="col-sm-6">
								<strong class="customType">Settings</strong><br><br>
								<a class="btn btn-green btn-small" href="<?php if($sAccess == 2){echo site_url('home/pumpConfigure/'.base64_encode($i).'/'.base64_encode($aIP->id));}else{echo 'javscript:void(0);';}?>" style="padding:6px 0;"><span>Configure</span></a>
								<a class="btn btn-small" href="<?php if($sAccess == 2){ echo site_url('home/setProgramsPump/'.base64_encode($i).'/'.base64_encode('ip='.$aIP->id));} else {echo 'javascript:void(0);';}?>" style="padding:6px 0;"><span>Programs</span></a>
								<?php 
									if(preg_match('/Emulator/',$sPumpType) || preg_match('/Intellicom/',$sPumpType)) {
								?>									
								<div style="padding-top: 10px; padding-bottom: 10px;">
								Change Speed: <br />
									<input type="text" class="pumpSpeedSet" name="pageSpeed_<?php echo $i;?>_<?php echo $aIP->id;?>" id="pageSpeed0" value="<?php echo $sPumpSpeed;?>" style="width:72% !important;"
									onBlur="changePumpSpeed(this.value,'<?php echo $i;?>');">
									
								</div>
								<?php } ?>
								<?php if($isExists == 1) { ?>
								<div style="padding-top: 10px; padding-bottom: 10px;">
								<a style="padding:6px 0;" href="javascript:void(0);" onclick="removePump('<?php echo $i;?>','<?php echo $aIP->id;?>')" class="btn btn-small"><span>Remove Pump Configuration</span>
								</a>&nbsp;&nbsp;<span id="loadingImgPumpRemove_<?php echo $i.'_'.$aIP->id;?>" style="display:none;"><img src="<?php echo site_url('assets/images/loading.gif');?>" alt="Loading...." width="32" height="32"></span>
								</div>
								<?php } ?>	
							</div>	
						</td>
						</tr>
						<?php 
								$chkPump++;
						} ?>
							
						<?php }
								
							$remainigCount	=	$iPumpsNumber - $chkPump;
							//for ($i=0;$i < $valve_count; $i++)	
							//for ($i=0;$i < $remainigCount ; $i++)
							foreach($arrPump as $i)	
							{
								if($remainigCount == 0)	
									break;
								
								$remainigCount--;
										
								$iPumpVal = $sPump[$i];
							
								$sPumpNameDb =  $this->home_model->getDeviceName($i,$sDevice,$aIP->id);
								if($sPumpNameDb == '')
								  $sPumpNameDb = 'Add Name';
								
								$sStatus2Speed	=	'';
								
								//Details of Pump
								$aPumpDetails = $this->home_model->getPumpDetails($i,$aIP->id);
								$sPumpType		=	'';
								$sPumpSpeed 	= 	'';	
								$isExists		=	0;
								if(!empty($aPumpDetails))
								{
									foreach($aPumpDetails as $aResultEdit)
									{
										$isExists	  = 1;	
										$sPumpType    = $aResultEdit->pump_type;//Pump Type
										$sPumpRelay   = $aResultEdit->relay_number;//Assigned Relay Number
										$sPumpRelay1   = $aResultEdit->relay_number_1;//Assigned Relay Number
										if($sPumpType == '12')
										{
											$iPumpVal = ${"sPowercenter".$aIP->id}[$sPumpRelay]; //Taken the status
										}
										else if($sPumpType == '24')
										{
											$iPumpVal = ${"sRelays".$aIP->id}[$sPumpRelay];//Taken the status
										}
										else if($sPumpType == '2Speed')
										{
											$sPumpSubType    = $aResultEdit->pump_sub_type;//Pump SUB Type
											$sStatus2Speed   = $aResultEdit->status;//Pump SUB Type
											
											
											if($sStatus2Speed == '0')
											{
												$iPumpVal        = $sStatus2Speed;
											}
											else if($sStatus2Speed == '1')											
											{
												if($sPumpSubType == '12')
												{
													$iPumpVal = ${"sPowercenter".$aIP->id}[$sPumpRelay]; //Taken the status
												}
												else if($sPumpSubType == '24')
												{
													$iPumpVal = ${"sRelays".$aIP->id}[$sPumpRelay];//Taken the status
												}
											}
											else if($sStatus2Speed == '2')											
											{
												if($sPumpSubType == '12')
												{
													$iPumpVal = ${"sPowercenter".$aIP->id}[$sPumpRelay1]; //Taken the status
												}
												else if($sPumpSubType == '24')
												{
													$iPumpVal = ${"sRelays".$aIP->id}[$sPumpRelay1];//Taken the status
												}
											}
										}
										else if(preg_match('/Emulator/',$sPumpType) || preg_match('/Intellicom/',$sPumpType))
										{
											 $iPumpVal 		= $sPump[$i];
											 $sPumpSpeed 	= $aResultEdit->pump_speed;	
										}
									}
								}	//END : Getting assigned relay status from the Server.
								
								$sPumpVal = false;
								if($iPumpVal)
								  $sPumpVal = true;
							  
								$sMainType	 = $this->home_model->getDeviceMainType($i,$sDevice,$aIP->id);
								
								$strChecked	=	'';
								if($iPumpVal == '1')
									$strChecked	=	'class="checked"';
								
								$strPumpName = 'Pump '.$i;
								if($sPumpNameDb != '')
									$strPumpName .= ' ('.$sPumpNameDb.')';
						?>	
						<tr>
						<td>
						<div class="row">
							<?php if(in_array($i.'_'.$aIP->id, $excludeDevices['PS'])) { ?>
							<div class="col-sm-12">
								
									<div style="position: relative;top:0;margin-bottom:10px;" class="ribbon ribbon-green"><span style="line-height:0px; font-size:14px;"><?php echo EXCLUDE_DEVICE;?></span></div>
								
							</div>
							<?php } ?>
							<div class="col-sm-3">
								Pump <?php echo $i;?><br />(<a href="<?php if($sAccess == 2) { echo site_url('home/deviceName/'.base64_encode($i).'/'.base64_encode($sDevice).'/'.base64_encode($aIP->id)); } else { echo 'javascript:void(0);';}?>" ><?php echo $sPumpNameDb;?></a>)
									<?php if($iPumpVal >= '1') { ?>&nbsp;&nbsp;<a style="padding:6px 0;" class="btn btn-small btn-caps pumpsOffButton" href="javascript:void(0);" data-device="<?php echo $i;?>"><span>Off Pump</span>	</a>
								<?php } ?>
							</div>
							<div class="col-sm-3">
							<div class="rowRadio">
							<div class="custom-radio">
								<strong class="customType">Type</strong><br><br>
								<input class="pumpRadio" type="radio" id="radio-other-<?php echo $i;?>-<?php echo $aIP->id;?>" value="0" name="<?php echo $i;?>_MainType" <?php if($sMainType == '0' || $sMainType == ''){ echo 'checked="checked"';}?> <?php if($sAccess == '1') { echo 'disabled="disabled"';}?> hidefocus="true" style="outline: medium none;">
								<label id="relay_other_<?php echo $i;?>_<?php echo $aIP->id;?>" for="radio-other-<?php echo $i;?>-<?php echo $aIP->id;?>" class="<?php if($sMainType == '0' || $sMainType == ''){ echo 'checked';}?>">Other</label>
								
								<input class="pumpRadio" type="radio" id="radio-spa-<?php echo $i;?>-<?php echo $aIP->id;?>" name="<?php echo $i;?>_MainType" value="1" <?php if($sMainType == '1'){ echo 'checked="checked"';}?> <?php if($sAccess == '1') { echo 'disabled="disabled"';}?> hidefocus="true" style="outline: medium none;">
								<label id="relay_spa_<?php echo $i;?>_<?php echo $aIP->id;?>" for="radio-spa-<?php echo $i;?>-<?php echo $aIP->id;?>" class="<?php if($sMainType == '1'){ echo 'checked';}?>">Spa</label>
								
								<input class="pumpRadio" type="radio" id="radio-pool-<?php echo $i;?>-<?php echo $aIP->id;?>" name="<?php echo $i;?>_MainType" value="2" <?php if($sMainType == '2'){ echo 'checked="checked"';}?> <?php if($sAccess == '1') { echo 'disabled="disabled"';}?> hidefocus="true" style="outline: medium none;">
								<label id="relay_pool_<?php echo $i;?>_<?php echo $aIP->id;?>" for="radio-pool-<?php echo $i;?>-<?php echo $aIP->id;?>" class="<?php if($sMainType == '2'){ echo 'checked';}?>">Pool</label>
								
								&nbsp;&nbsp;<span id="loadingImgPumpType_<?php echo $i.'_'.$aIP->id;?>" style="display:none;"><img src="<?php echo site_url('assets/images/loading.gif');?>" alt="Loading...." width="32" height="32"></span>
							</div>
							</div>
						</div>
						<div class="col-sm-6">
							<strong class="customType">Setting</strong><br><br>
							<a class="btn btn-green btn-small" style="padding:6px 0;" href="<?php if($sAccess == 2){echo site_url('home/pumpConfigure/'.base64_encode($i).'/'.base64_encode($aIP->id));}else{echo 'javscript:void(0);';}?>"><span>Configure</span></a>
							<a class="btn btn-small" style="padding:6px 0;" href="<?php if($sAccess == 2){ echo site_url('home/setProgramsPump/'.base64_encode($i).'/'.base64_encode('ip='.$aIP->id));} else {echo 'javascript:void(0);';}?>"><span>Programs</span></a>
							<?php 
							if(preg_match('/Emulator/',$sPumpType) || preg_match('/Intellicom/',$sPumpType)) {
						?>									
						<div style="padding-top: 10px; padding-bottom: 10px;">
						Change Speed: <br />
						<input type="text" class="pumpSpeedSet" name="pageSpeed_<?php echo $i;?>_<?php echo $aIP->id;?>" id="pageSpeed0" value="<?php echo $sPumpSpeed;?>" style="width:72% !important;" onBlur="changePumpSpeed(this.value,'<?php echo $i;?>');">						
						
						</div>
							<?php } ?>	
						<?php if($isExists == 1) { ?>
							<div style="padding-top: 10px; padding-bottom: 10px;">
							<a href="javascript:void(0);" style="padding:6px 0;" onclick="removePump('<?php echo $i;?>','<?php echo $aIP->id;?>')" class="btn btn-small"><span>Remove Pump Configuration</span>
							</a>&nbsp;&nbsp;<span id="loadingImgPumpRemove_<?php echo $i;?>_<?php echo $aIP->id;?>" style="display:none;"><img src="<?php echo site_url('assets/images/loading.gif');?>" alt="Loading...." width="32" height="32"></span>
							</div>
						<?php } ?>
						</div>	
						</td>
						</tr>
								<?php } ?>
						<?php } ?>		
					</tbody>
					</table>
					</div>
				</div>
			</div>
			<!--/ Statistics -->
		</div>
	<?php	}
		}
	?>
</div><!-- /.row -->
<!-- END : PUMPS -->