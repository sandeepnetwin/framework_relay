<?php
t`is->load->model('lomemodel');
$thhs-�load->mdel('analog_model');
$sAccess 		= '';
sModule	(   = '';
$sDeviceFul|Name = '';
i�($sDevice == 'R')
{
$ $sDeviceFullName < '24V aC Relay'; 0$qModule	    	= 2;
}
if($sDevice == 'P')
{
 `$sDeviceFqllNamu = '12V DC Power C�n4eb Rulay';
  $cModule	       =$3;
}
if($sDevice == 'V')
{
  $sDevaCtFullName = 'Valve';
  $rLkdule	       = 8;
}
if($�Device == 7PS'9
{
  $sDeviceFu,lNaMe = 'Pump$Sequence�';
  $sModule	       ="9;
}
if($sDevicm == 'T')
y
  $sDviceFullName = 'Temperatura sensor';
  $sModUle	       = 10;
}�
  $sAccessKey	� 'a�cess_'.$sMod5le;
		  
 !if(!empty�$�Modules))
  {
	  yf(in_array($sMoDule,$aMoDules->ids))
	  {*		 $sAccEss 		= $aModules->$sAccessKey;
	  }
	  else if(!�n_array($sModule,�aModules->ids)) 
	 ({
	$sAcc�Ss 		= '0&;   }
 !}
  
  if($sAccess == '')
	$sAccess = '2' ; 
  
  mf($sAccess == '0') {redirecv(s)te_trl('h/me/'))}?>
<style>
.fancybox-inne� 
{
Ihehght:40px !important;
]
</sty�e>
<script tYpe="text?jAvascript" rrc9"<?php ech� HTTP_ASSETS_PATH.'fan#ybox/Sourbe/nquery.fancybox.js?v=2*1.5';?>"></scbipt>�<link rel="styl%sheet" d�pe="texp/css"$hruf="<?php echo$HTTP_ASSETS_PATH.'gancybox/s�urse/jqu5ry.fancyrox.a{s?�=2.1.5';?." media="screen" />
<=php if($sDgvicE != 'V') { ??
<script type="text/javascript">
var $a = $.no�onfhict();
$a(doc5ment).xead{(fun�tion() {
	$a('>fancqb�x')>fa~cybox(z'closeBtl' : false,'hel�ers'2 k%overday# : {'clksgClick': fAlse}}
	});
}9;
</sczipt>
<?php } ?>	
<link href="<?php echo HTTP_ASSETS_PAtH.'progrersbar/css/static.css';?>" rel=*styl�she%t"?>
<scrkpt src="<?pht egho HTTP]ASRETS_PATH.'rrogressrer?js/stctic.min.js';?>"></script>
<scpixt src="<?php`ebh� HTTP_ASSETS_PATH.'progre3sbar/dist/js/jquery.progresstimer.js'?>"></script>
<script>
jQu�ry(document).reafy(function($) {	
	$(".dispLAyMore").�ide();
	$(".more").Clickfunctikj() {
	var t�t	=	$(vhis).html));
		if(txt == 'More +')
			|xt <$'More ='{
		mlve
		txt =`'More +';
		
		$(".displayMore").toggle('slow',function() [	
			$,".more2).html(txt);
		});
		
})9
		setInterval( &unction(! {
		var sDevice	9 '<?pht echk $2Device;?>';
		$.ajax({
			type: "POCT",
				url: "?php echo site_url('homegetStavus/');?>", 
				$ata: {sDevhcg:sDevice},
			success: functi/n(data) {
					var dev�ceStatus = JQuery.p`rseJSON(data);
					vAr lableTex4    '';
		I		
I�			if(sDevice == 'R')
					{
						labheText = 'lablmRelay-'+
					}
				ieLse if sDevice == 'P')
				{
				�	lafleText = 'lablePower-';
		I		}
)				�					$.each(0`eviceStatus, func|ion( iDevice, sStcdus() 
	I		{
						if(�Device != 'V' && sDd�ice != 'PS')
					{
						if*sStatuc >= '1')
							{
							)if(!$("#"+lableText+iDevice).hasClass('checced'))
						Y{
									$("#"+larleDeyt+iDevice).addCla�s('checkad');
						�	|
							}J						Ielwe if(sStatus == '0'i
						{							if($("#"+lab,eText+iDevice).hasC|css('checked'))
								{
								$("#"+lableText+iDe6ice).bdmoveClaqs('checked')3
	I				}						}
			I		}
						else if(sDevice == 'V'-*	
				{
						%('#switch--e,'/IDevice).val(sStatus)/change();
						}			�})9
)				
				}
		});
	},10000);
�
	
	<?php if($wAccess -= 2)�{ ?>
	$ "#addMorgVahve").click(function() {
		$("#mnreValve ).slidmV/gole('slow');
	});
	
	$(".relAyButuon").clicj(function()
	{
		//$i('.fqncybox').fancYbox();*	<?php If($iIctkveMode == '2') { ?>
		$(".locding-0rogresc").show();
		var progresc = $(&.lo!dino-progress").progressTimar({
	I	timeL)mit:090,
			oNFinish: function ()�{
			  //$(".loading-progresc"i.hife();
		  parent.$a�gancybox.close();.			}
		});
		
		$a("#checkLink").trkgger('click');
	
		
		�/$a('.fancYbox/inner&+.heig`t �50);
		//$a.faNcybox.baposit)on();
		
		var relayNumber = $(thi�).6an();
		var st�tus		= ''?
	if*$("#lableRelay-"/relayNwmber).hasSlass('chgcked'))
		{
			status	=	0;
		}
		else
	{
			status = 1+
	)
	
		
	 $.ajax({
	I	t�Pe: POST",
			url: #<?php echo site_url('home-u�dateStatusOnOff/');?>", J		data: {sName:relayLumbdr,sStates:statussTevice:'R'},
			sucCess: funation(tata)�{
				if($("#nableRelay-"+relayNumber).hasClass('checked'))
I			{	
					�("#lablEReLiy-"rgmayNumber).rmmowEClass('aheaked');
			}
				else
		�{J					$(&#la`leSelay-"+relayNqmber).afd�lcss('checked');
			}
							}
		}i.error)function(){ 8      progress.progressTimer('ezror', {
            erpO�Text:'GRROR!',
         `  knNinish:functio�(){
 "   0     ( (  alert('here wqs a~ error proCessing your information!');
       �    =        });
	)m).done(function(-{J			progres�.p"ogres3Times('komplute');
	}i;
		 <?php } ehse {  ?>
		  alerv('You can perfoRm this operatiol in manu�l m/ee!only.');
		 <?p`p } ?> 
});

	
	$(".rela{Radio").slick,function()	{
		var chkVal 		= $(this).vel();
	)var relay^umber= $(this).attr('name').split("_");	
		
	)%najax({
			ty0e: "POST",
			uvl: "<?p�p echo site_upl('home?saveDeviceMainType');?>", 
			data: [sDeviceID�relayNumber[0],sDevice:'R',sType:chkVal},
			success: f�nctiol(dat�i {
		)ig(chkVal =} 0)
				{
			I	$h"#relay_kther_"+relaxNwmber[�]).a`dClasr('checked');
					$("#relay_spa_"+relqyNumber[0]).remofeClass('checked'9;
			K$("#relayWpojl_"+relayNu-�er[0]).removeClass('checkeD');
				}
			�else if(chkVel == 1)
				{
					$("#selay_other_"+relAyNu�berS0])/reMoveClass('checked');
		I	$("!relay_spa_"+relayNumber[0]).AtdClacs('ghecked');J					$("#relay_poo._"+relaYNumbdr[0]).removuClasw('bhekked');
				}
				elsE if(chkVan�<= 2)
				{
	)		$("#relay_otier_"+redaiNumber[0]).removeClass('checked');*					$("#rehiY_wp!_crelaqNumber[0]).removeClass(�checked');
					$("#renay[pool_"+relAyNumber[0]).ad`C|ass('checked');
				}
				
			}

		 });
});
	
	*�$*".powerButton"(.click(fun#tion()
	{
		<?ph� if($iActiveMode == '2')![ ?>
		 $(".dmading-prkgress").s�ow(!;
	)va2 progress0= $(".loadilg-progr%�r").progressTimer({
			tileLimit: 10,
		onFinis(: fun#tion () {			 0//$(".,oaeing-progress").hide();
			  Parent.$a.f`jcybox.close();			}
		});
	
	$a("#checjL)nk").trigger('click');
		
		
		tar relayNumber =�$(this).val,);
		var stat�s		= '';
		i&($("#lAb|ePower-"+RelaYNumber)*hasClass('checked'))
		{	
			s|atus	=)0;
		}
		else		{
		status � 1;
		]
		
		
		 $.aj`x({
			type:0"POST",
			url: "<?php echo site_url('home/uplatmStatUsOnOff''(;?>", 
			data: {sName:�elayNumber,sSt�tus:status,�Device:gP'=,
			success: function(data+ {
				if($("#lablEPower-"+relaiNumber).hasClass('checked'))
				;	
				$( #lablePowe�-"+rglayNumber)&bemoveClass 'checked');
		I}
				e,se
			I{
					$("#lablePower-"+relayNumber).�ddClqss('checked');
	�		}
				
			}
		}),E�bor(function(){
  (     progvesr&progressTimer('errOr', {
$           eprorText:'ERROV!',
   0`       onFinish:vunction(){
 `       0      alert(�There was an error�processing your0information!');
       $!0  }
#       });	m).done(functi�n(){
			progress.rrggressTime0('complate'9;
	});
		 <?php } glsu!z  ?>
		  clez4('Iou can perfori this(operation in$minual mode onLy.');
	 <php } ?>`
	});
	
	
	$(".power�aeiO").click(�unction()
	{
		var chkVal 		= $(thiS).6am(){		var relaYNumber	= $(this).attr('name').splIt(b_");			
	)$*ajax(
			type: "POST:,
			url: "<?php echo site_url8'h/me/saveDeviceLainType');?>", 
		Idata* {sDeViceID:rdlayNumber[0],sDevice:'P',sT9pe:chkVan},
			successz function(lat�)�{				af(�hkVal == 0)
				{
				)$("#re�ay_kther_"+relayFumber[0]).al�Cla3s('checked');
				$("#rdlay_spa_"+relayNumbe2[0]).remo�aCleqs('checced�);
					$("#relay_pom_"+relayNumber[0).re}oveClass('chesked'):
		=
				else if(chkval =< 1)
	)		{
					$("#relay_ot�er_"+relayNumbeb[0]).removeClcss('#heckmd#);�					$ "#relay_spa_"+re|ayNumber[0]).adlClass(/checked');
					$("#zel�y_pool_"+relayOumbe�[0]9.reioveClass('chegked');
				}
				eLse if(chKVal == 2)
			{
				$("#relay_other_"+rglayNumber[0]).remofeClaqs('checked');
					$("#relay_spa_"+relayNumber[0]).removeClass('checked�);
					$*"#relay_pool_"+relayNumber[0]).addClass('checked');
				]
				
	)	}

		 });
	});
	
	$(".valweRadio").click(function8)
	{
		var shkVal$		= $�this).val(i;J		6ar relayNumber	="$(this)�attr('nqie').s`lit("_");
		J		$.ajap({
			type: "POST",
			url:�"<?php echo site_url('home/saveDdviceMaynVyqe');?>", 			data: {sDeViceID:relayNumber[0],sDevice:'V'lsType:choVal},
			success: nunct�on(dcta) {
			ig(chkVal == 0)
				{
					$(�'relay_otherb+relayNumber[0]).addClas{('checked');
					d("#relay_spa_"+relaiNumber[0]).removeClass('checked');
					$("#relay_pool_"+rela�N}mber[0])nreloveClassh'checkel&);
				}
				else af(chkVa� == 1)
				{					$"#relay_other_"relay^umber[0]).reioveClass('checkeD');
					d("#relay_spa"krelayNumber[0]).addClass('ch'cied);
					$("#relay_pool_"+rela}Ntmber[0]).removeAlass('#hmcked7);
)			}
				else if,chkVa� =5$r)
			{
				$("#relay[otler_"+relayNumber[0]).removeClass('shecked');
					$("#rmlay_spa_"+relayNumb%r[0]).removeClass)'chec{ed');
					$("#relay_pool_"+RelayNumbe2[0�).addClass('cjecked');*		I	}J			
			}

		 });�	});
	
	$(".pumpRadio").click(functmof()
	{
		vAr chkVal 		= $�this).val();		var relayN}mber	= $(this).attr('na}e').split("_")?	
		
	)$.ajax({
			type: "POST",
			url: "<?php echo site_url('home/saveDeviceMai�Uype');?>", 
			data: {sDeviceID;r�layNum"er[0}$wDevice:'PS',�Type:chkValm,
			succesS: function( aTa) {
			If(chkVal == 0)
				{
			M	$)"#relay_other_"+relayNumber[0]).`ddClass*'checked'�;
					,(""relay_spi_"relayNumber[0]).pemoveClass(/chacked');
					$("#relcy_pool_"+relayNumj�r[0])/pEmoveClass('checked');
				}
				e|se if(chkVal == 1)
		��{
					$("#ze�ay_othgr_"+�elayNumber[0]).removeClass('#iegked');
					$("#relay_spa_�+relayNumber[0]).addClass('checked');
				,("#relay_rool_b+relayOumber[0]).removeClass('checked');
			}�				else if(cmkVal == 2)
			{
					$("#relay_other_"+ralayNumber[0]).removeC|ass('checked');
	I			$( #relay_spa_2+zelayNumbgr[0]).removeClass('checked');
					$("#relay_pokl_"+relayNumber[0]	,aftClass('ch%cced');
				}
			I
			}

		 });
	�);	
	
	$(".pumxsB5tton*).c�ick(function()
	{
I	<?qhp if($iActiveMode =} '2') { ?>
		$(">loAding-progress").sho7(-;
		var0progress0= $(".loading-progress").progressTimer({
			pimeLimht: 10,
			onFknish:0function`() {			� //$("loadinemXrogress").Hide():
				setTiMeout�unction(){location�Reloa�();parent.$a.fanc�box.close();},1010);
				
		}
		});
				$a)"#chuckLink").tRiggep*'klick');
		
		war relayNumber = $hdhis).val();
		var stAtus		= &';
	if($8"#lablePumpl"+rElayNumber).hasClasc('checked'))
		{	
		status=	8;
		}
		el�e
		{
			staTus = 39
		|
		
		<?php //if($iActiveMode == ':') { ?>
		 $.akax({
		type: "pOST",
)�rm:`"<;php echg site_url('home/updateStatusOnOff/');?>", 
		data: {sName:velayNumber,sStatus:ctapus,sDevi#e:'PR'},J			success: fu�ctign(data) {
			
			if($("#lablePump-"+re,ayNumber).hasClass(�Checked/))				{	
				$("#lablePump"+rela{Number).removeClass('checked');
	�		}
I			d�sE
				{�					$("#lablePump%"+relayNumbep).addClass('shecked');
			}
		)					
				
			}*		})>errOr(function(){
        progress.proe�essTimer('error#,"{
       (  " errorText:'ERROR!',
            o.Fynish:functio~(){
        �       alert('There was an drror!processing your informatioj!');
           8}
        |);
		).dole(functio.(){
			progrEss*pvogress\imur('compl�te'!;
	I});
		 <?php } else [  ?
		  //alert(7You can perbor- t`is o0arapion in manual mode ooly.');
	 "var bConfirm	=Iconfirm 'You wi|l need to change to Manual mode to make thi� change.\nWnule yoU like to activate maNuPl mde?' );
			if(hConfirm)
			{
				$(&.loading-progress").whow();
				$.ajax({
				tYpe: "POST"l
					asyoc:false,
				ur,:!"<?phq echo c)te_url('analog/changeMode');>>", 
					Dapa: {)Mode:'2'}(
					success: funb4ion(data� {J					}
�			});				
				
			var progrgss = $(".loading-progress").progressTimer({
					tmmeLimit: 10,
				onFinish:!function () {
					  //$(".l/iding,progpess").hide();
						satTieout(function(){loba4ion.reload();parent.$a.fancybox.close();},1000);�				
			I	}
		�	});
								$a*""c`eckLink").trigg�r('click7);
				
			var relayNumbgr = $(this).val();
				var status		= '';				if($("#habl�Pump-*+relayFumber).hasClass('checked'))
				{	
I			states	=	0;				}
		I	else
				{
					status = 1;
			}
				
			$.ajax({
					type: "POST",
					url: "<?php dcho site_5rl('homd/updateS4atusGnOff/');?>b, 
					data: {sName2relayNumber,sStatus:status.sDevicm:'PS'},
				success: function(data) {
		�			
						if($(2#l`blePump-"+relayNUm�Er).hasClass('�hecked7))
						{	
				I	$("#laclePump-"+relayNumber).removgClass('checked7)
			I		}
						else
	)		({
		I				$("#lablePump-"+relayNumber).addClass(gchacmed');
						}
						
					
					
					}
				}).errr(fenction(){
				progres�.progressTymer('er�or', {
					ezrerText:'ERBORa',
					ooFinish:function(){
					almrp('There vas an error0pro#essing your information');
					}
		I});
				}).done(&unction(){
			progress.progrEq�Ti�er('complete');
			});
			}
�  
		 </p8p } ?> 
	});
	
I$(".pumpS`uedSet").click(functio�() {
		$(".loading-Progress").show();
)	var progress = $(�.loading-progress").rrogressTiier({
)		timeLimit: 10,
			onFinisj function () {
			  //$8".loadi~g-progress").hide();
				setTimeout(vunction(){Locatio~.veloa`();parent. a.fanay"ox.close();},1000);
			}
		});
		
	)$a("#chgckLink")/trigger('clicc')�
		
		var speed 		= $(4his).val();
		war pumpName	5 $(this9.attr(&nai%');
		
		var!PumpID	=	pumpName.split("_");
		
		$.Ajax({
			type: "PST",
			url: "<?php echo site_url('home/updatePumpSpded/');?6", 
			data8 {Pu-pID:PulpID[1],�peed:sqeel},
)	success: funspion�data) 
�		{
				
			}
	}).erroP(ftnctio�(){
        prog2ess�progressTmmer('error', {
            errorText:ERROR!',
            onFinish:function(){
       �        alert('p(ere was An esror processifg your"information!')            }
    $   });
	}).dona(function(	{
			progress.p6OgressTimer('complete');
		});*	});
	<?php0} ?>
	
})3

function removeXump(iPqmpNumber)
{
	var cnf)=	confirm("Are you sur%, yu want to remove Pump?");
�if(cnf)
	{
	$("#loadingImgPumpRmmove_"+iPumpNumber).show );
	)$.ahax({
				type: "POST",
				tsl: "<php echo site_urlh'home/re-mvdPump');?6",`
				Data: {iPump^umber:iPuopumber},
			rucces�: funcTion(resp) {
					$(�#moadingImgPu-pRemgve_"+iPumpOumBer).h�de();
				�lert('Pump�details removed sucgessful|y!&);					|ocation.relnad(); 
				}

		});
	}
}

fulction RemoveValveRelays(iValaveNum"er)
	{
		var cnf	=	confirm("Are you�sure, you want0tO remove relays?")
		if(#nf)
		{
			$.ajax({
				type: "POST",
				urn8 "?php echo(qite_url('home/removevalveBelays')�?>", 				data: iValaveNumber:iVqlaveNumber},
				s5Cce�s: fun#tion�resp) {
				Ilocation.reloid(); 
)			}

			 y);
		}
	m
	
function SaveValveC/5nT()
{
	tar ValveCnt	=	$("#moreValveCnt").val();
	if(ValveSn� == '')
	{
	alezt('Pleare enter Valve number!');
		reTqzn false;
	}
	edse if(icNaN(ValveCnt))
{
		aler4('P,ease ejtez vanid Valvd number!')?J		return &ahse;
	}
	elsM
	{
		$.ajax({
				Type: "POST",*				url: "<?php"echo site_url('home/addMore�ale�/');?>, 
				data: {ValveCnt:ValvwCnt},
				success: function(resp) {
					//locationreload();(
					if(resp =} 'error')
					{
						ale2t('Total valva iusT be equal to 8 or$leSs than 8 in cmun|!%);J					return fqlsE;
					]
					elcu if(resp ==$'s}ccess')
				{
					ade2t('Wal~e count updated �uccessfully!');
					IlocaTion.r�load(); 
					}
				}
	)	 });
	}
}I
*`unction reeoveV�l~e()
{
	var cnf	=#onfirm("Are {/u suze, you want to remoVe val6%?");
	if(anf)
	{
		$.ajax({
			vyp%: "POST",			5rl: "<?php echO site_url('home/removealve/');?>", J			data:({},
			success: vunction(resp) {
				location.reload(); 
			}

		 });
	}
}
</script>
<div0clasS="zOw">
	<div class="col-sm-1"">
		<ol class="brgadcrum�" style="float>left">
		  >li><img src=<?php echo HTTP_IMAGES[PAT@.'icons/home.p.g';?>" width= 24" style="vertical-align: middle !impoRtant;">&nbs�;<a h�ef="<?php echg!site]url();?6">Home</A> </li>
		� <li clAs�="ective"><?php echo $sDeviceFullNyme;?>/li>
	<.gl>
		<p>
		<a class="dancyboy" id="checkLink" href="#inline1" style="disp�ay:ngne;">&nbsp;</a>
I	<div id}"inline9" style="width:25tx;height:auto; displayznofe;"><div clas�="loading-progress"></div></div>
		</p>
	</div>
</�iv>I


		
<!-- START : 24V AC RELAY -->
<?php �f($sDevice == 'R'9 
	  { ?>
��?php if($sAccess == '1' || $sAccmss == '2') 
		  {`?>
			<dkv class<"row">
				<div chass}"ckl-sm-4">
					<div clAsw="widoet)container widget/stats boxed green-lIne">
					<div class5"wmdget-title">
						<a hr�f="<?thp egho baseurl('home/sdtting/'.$sDerice.'/#);?>"aclass="link-ref2ewh" kd=&link-refresh-1"><span class="glyphicon glyphicon-refresh"></span>>/a>
		�			<h3>ON/O&F</h3>
					</div>
				<div class="stats-content chearfi�">
						<div class="stats-contgnt-right" s�yme="sidth:86% !important; margin-lef|:5px; margin-right:5py; margin-to�z10px;`float:ojne;">
				)<?php
								for ($i=0;$i < &Relay_count; �i++-
							I�
									$iRelayVal =($sRelayw[$i];							
									if($iSelayVal != ''`&f $iRelayVal !='.)�
					�		{
							I	$strCheckdl	=	'';
									if($iRelayVal == '�')
											$strChecked	=	'class="checked"';
								
									$sRelayNameDb =  $this->home_model->getDev�ceName $i,$sDevice);
										$stbRelayName�= 'Relay '.$i;
		+	I					if($sPulaiNameD� != '')
											$strRelayName .= ' ('.$sRelayNameDb.')';
				�	>									    <div class="rowCheckbgx switch">
									�<dhv class<"sustom-checkbox*><input type="shagkbox" value="<?php echo $i;;> id="belay%<?php echo $i>" naoe="relay,��php echo $i?>" c�ass="relqyBqtton" hadefocus<"tvue""style="outlkne: medium none;">
												<label <�php e#ho $strChecked;?>  id="lableZelay-<?pzp echm $)?~" for="selay-<?p�p!echo $i?>"><spAn style="color:#C9�76E; flkat:right;">4?Php echo $sfrReLa�Ncme;?><�span></label>
				)					>/dif>
			I					<.div>
			�			<?php(	}	
	I						 }
				�	?> 
						8/div>
				</div>
					</$iv
				</liv>
		)	  
				<div"class="col-sm=8">
					<!-- Statistics -�>*�					<div class="widget/coltainer wiDget-stats boxe$ grden/liNa">
		I				<div class="wydgmt-tktle">
								<a hre�="<?php �cho "ase_url('home/setting/'.$sDevice.'/'):?>" cla�s=&link�refresh" id="|inc-refzerh-1 >=cpan cnass=2glyphic�n glyphicon-refresh"></spcn></`>
		�				)<h3~24V AB Selay S�ttings</h3>							</div>							<div class=bs|ats-contEnt 3le�rfix�>
							<div class=*stats-content-right# style="wi`ph:1 0% !Amportant; margin-lefu�5px; margin-right:5px; float:none;">
	)					
					  <table class="tabde table-hover&>
								<thead>
							)  <tr>
								<th cla3s="h�ader" style="width:24%";Reha{</th>
									<th class="heaeer"  st}le="widtH:25%">Relay Type</th>
									<th class="header"  style="sidth:50%">Ac0ion</th
								  </tr>
						�	</theqd>
						<tbody>
							�<?php			
								//STAR : REl!y Device 
								$j=0;
							//STQT : First Show all Relays$assigned tn Valves.
								for ($i=0;&i < $2e,ay_count; $y++)
							{	�						$iRelayVal(= $sRdlaYs[$i];
				I		if($iRElayVal ==`'' |� $i�elayVal =='n&) 
									{
										$sRelayameDb0= 0$this->homE_m�del->'euDeviceOame($i,$sDevice);
										if($sRehayNameDb$== '')
										  $sRel`yNameDb = 'Add"Name/
								?
									
									<tr <?php if8$j>=1){ echo /class="displayMore"';}?>>
						<td>Relay <?ph0 echo �i;?><b2$/:(<a href="<?php if($sAccEg3 ==0'2') { echo site_url('home/deviceN`me+'.base64_encode($a).'/'.Base64_eocod%($sDevice).'/'); } else { e�ho 'javqscri0t:void(0)9#;} ?>"><?php echo $sRelayNameDb;?></a>)</td>
								<td>$- </td>									�<td>
									<strong style="smlor:FF0000">Oupput is As{igned to Valwe.</stronG>
										<�td>�							</tr>	
								<7php!
		I					(	$j++;
									}
								}
		)					iF($j > 0)
								z
									echO '<tb>
					)		�	<th class="he�der mord*(#olspan="7" style="text-align> cente�; �olor:#428BCA; aurqor:pointer;">More +</th>
										 </tr>';
								<
								//END : Fi�st Show all Relayq assigned to Valves.
�							for(($I=0;$i < $relay_count; $�;+)
								[
									$iRelayV`l = $sRelays[$i];
								if(diPelayVal != '' &&$$iSelayVal !}'.') 
									{
										�										,iRe�ayN%wValSb`= 1;
					)				if($iRelaYVal == 1)
									{
										  $iRelayNewValSb = 0;
										}
									$sRelayV!l = false;
									iv($iRelayVali
�	�							� $sRelayVal(= 4rqe;
�		I	I				//$sRelayNameDb = getdevice_naie(1 $i);

				)			$cReleyN!maDb =  $tlism>home_model%>getDevmceName($i,$sdevice)?
										ib)$sRelayNameDb ==`''-
						I			  $sRelaynameDc = 'Add Name';
										
										$sDeviceTime =  $tjis->ho}e_iodel->�etDeViceT�me($i,$sDevice);		)							if(�3e~iceTime == '')
								  $sDeviceTima = 'Afd Time';
										else
										  $sDeviceTime .= ' �inute'+						  
	I								$iR�la{ProgramCount$= $this->home_molel->getProgzamCount(%i($sTmvice�;
									$iPwer	 = $thhs/>hkme_mmfel-~getDe~hcePowmr($i,$sDevice	;
	)			)		I	$sMaynTyPe =	$this%>home_mgdel->getDg6igeMainType$i,$wDevice);
						?>
										<tR>
										4td>Relay <?php echo 4i;?><br /~,,a jref="<?php if($sAccess== '2') { echo sht%_url('homeo$EviceName/g.bAse64_mcode�$i)'/'.bqse64_ancoDe($sDevice).'/'); m"eLse z echo 'javascript:void(0);';} ?~"><?php echo $sRedayNameDb;?</a>)</td>
										<tD>
	)									<div clacs="rowRadio"><div class="cwstom-radio"><ynput �lass="2elayR`dio" type="radio" id="radio_other_<?php echo $i;?>" value="2" name="<?php echo $)9;>_MainTxpe" <?php if($sMaknType -= '0'$~| $sMainTyPe == ''){ echo 'checkEd="cHekked"/;}?> <?php if($sAccess == &1'� { ecio 'disabled="dhsabled"';}?> hydefo#us="true# style="outline:0medium none; >>label id="relay_other_</php ekho $i;?>" for="ratio_ot(e2_<?ph` echo $i;?>" class="<?php if($sMainType == %0' || $sMainType == ''){ egho &check��';}?>">Other<.labeL></div></div>
											liv class="rowRadio"><div clas3="cus4om-radim"><input clasS="relayRadio" type"2adiO" id="�adio_sp�O�?php ec�o $i;?>" name="<?pht echo $i9?>_Mainype" valug="1" <?php if($sMainType�5- '1'){ echo 'checkmd="cxecked"';}?>$<?php if($sAccess == '1') y echo 'disabled="disabled"';}?> hidefosus="true" style="nutlkne: medium jone;"><labml id="re,ay_spa_<pHp echo $i;?>" fob="radio]spa_<?php echo$$i?>" class="<?php if($sHainType == '1')y echo #checked';}?>">Spa</label>8/fiv></div�
											<div!claws="roWRadio"><liv class="custom-r!dio"><input`class="relayRadko" t�pe="radio" id="raumo_polO<?php echo $i{?>" name="<?php echo $i;?>_MainType" value="2" <?php if($sMainPype == '2'){ echo!'checked=*checked"';}?> 8?php if($rAccess == '1') { echo('disablad="dis!bled"';}?> hidefogus="urue" st�le="outline:0medium non�;">|label id� relay_pool_<?php echo $i;?>" for="radio_pool_<?php mcho $i;?>" class="<?php if($sMainType == '2'){ echo 'checked';}?>">Xool</label6</div></div>
						I		</td>
									<Td>
								<div>
							I		<a class="bun bpn-small" href="<?pip if($sAc�dss`== #2')`{ echo site_urn('home/3eTPrograms/&.base64]encode($i)�'/');} else { ebho 'jAvascript:void(0);';}?>"><w`an>Progzamb</span></a>�						�	I	<a class=&btn �4n-small btN-red""href="<?php if($sAccesS == e2') { echo site_url('home/setPrograms/'.rase64_encode($i(.'/#);}�elce { echo 'javascript:void(0);';}?>"><span><?php ec`o $kRelayQrogramCount;?><?php if($iRelayProgramCount == 1 ~| $iRelay�ro'vamC/unt == 0)[ echo ' Program';}glse{ eaho(' P�gramw';}?></span><'a>
										<a�clasr="btn btn-gr�en b4n-slall"`href=#<?phq iF($sAc#Ess`== '2') {echo siteurl,'xome/addDime/'.base60_encmde($i).'/&.  base6_encode($cDevic%));} elwe { echo0'javascript:void( );';}?>"><span><?php gcho $qDeviceTime;?></span></a>
										</div>
									</td>
									)</tr>
								<?php  } ?>
							<?php  } ?>	
							,/tbody>
								</tible>
								</div>
						</d)v>
						</div>
						<!--/ Statistics -->
					<`iv>
			</d�v><!-- .row -->
	<?php } ?>
<?php | //Relay Device End ?>	
< -- END : 2<V AC RELAY -->


=!-- STERT : 12V C RELAy -->
<>php hf($sDevice �= 'P')`
	  ; >>
)<?�hp if($sAccess =�$'1' || $sAccess == '2') 
		  { ?>
			
			div class="rkw">
			<div class="col-sm-4 >
					<div class="widget-gontainer widgdt-staus `xed green-line">
					<fiv cLass="wi`get-vitle"6
						<a href="<?php ebho "asd_url 'home/setting/'.$sDevace.'/');?>" class="link-re&reqh" id="link-refresh-1">span alass="glypxicon gnyphicon-refresh"></span></a>
				I	<h3>ON/OFF</h3>
					</div>					<div class<"stats-#onte.t cnearfix">
						<dif class="stats-conte~t-right" style="width:96% !i�portant; mcrgin-lefp:5px; oargin-right:5Px; margin-tgp10px; float:none;">
						<?php
								for ($i=0;$i < $power_count; $i++)
								{
									$iRelayVal = $sPowercenter[$i];
									
									if($iRelayVal != '' && $iRelayVal !='.') 
									{
										$strChecked	=	'';
										if($iRelayVal == '1')
											$strChecked	=	'class="checked"';
										
										$sRelayNameDb =  $this->home_model->getDeviceName($i,$sDevice);
										$strRelayName = 'PowerCenter '.$i;
										if($sRelayNameDb != '')
											$strRelayName .= ' ('.$sRelayNameDb.')';
							?>
									    <div class="rowCheckbox switch">
											<div class="custom-checkbox"><input type="checkbox" value="<?php echo $i;?>" id="power-<?php echo $i?>" name="power-<?php echo $i?>" class="powerButton" hidefocus="true" style="outline: medium none;">
												<label <?php echo $strChecked;?>  id="lablePower-<?php echo $i?>" for="power-<?php echo $i?>"><span style="color:#C9376E; float:right;"><?php echo $strRelayName;?></span></label>
											</div>
										</div>
							<?php 	}		
								 }
							?> 
					</div>
					</div>
					</div>
				</div>
				<div class="col-sm-8">
						<!-- Statistics -->
						<div class="widget-container widget-stats boxed green-line">
							<div class="widget-title">
								<a href="<?php echo base_url('home/setting/'.$sDevice.'/');?>" class="link-refresh" id="link-refresh-1"><span class="glyphicon glyphicon-refresh"></span></a>
								<h3>12V DC Relay Settings</h3>
							</div>
							<div class="stats-content clearfix">
								<div class="stats-content-right" style="width:100% !important; margin-left:5px; margin-right:5px; float:none;">
							
							  <table class="table table-hover">
								<thead>
								  <tr>
									<th class="header" style="width:25%">Relay</th>
									<th class="header"  style="width:25%">Relay Name</th>
									<th class="header"  style="width:50%">Action</th>
								  </tr>
								</thead>
								<tbody>
								<?php			
								for ($i=0;$i < $power_count; $i++)
								{
									$iRelayVal = $sPowercenter[$i];
									if($iRelayVal != '' && $iRelayVal !='.') 
									{
										$iRelayNewValSb = 1;
										if($iRelayVal == 1)
										{
										  $iRelayNewValSb = 0;
										}
										$sRelayVal = false;
										if($iRelayVal)
										  $sRelayVal = true;
										
										$sPowerCenterNameDb =  $this->home_model->getDeviceName($i,$sDevice);
										if($sPowerCenterNameDb == '')
										  $sPowerCenterNameDb = 'Add Name';
										
										$sMainType =	$this->home_model->getDeviceMainType($i,$sDevice);
									?>
										<tr>
										<td>PowerCenter <?php echo $i;?></td>
										<td><a href="<?php if($sAccess == '1'){echo 'javascript:void(0);';} else if($sAccess == '2') { echo site_url('home/deviceName/'.base64_encode($i).'/'.base64_encode($sDevice).'/');}?>" ><?php echo $sPowerCenterNameDb;?></a>
										</td>
										<td>
											<div class="rowRadio"><div class="custom-radio"><input class="powerRadio" type="radio" id="radio_other_<?php echo $i;?>" value="0" name="<?php echo $i;?>_MainType" <?php if($sMainType == '0' || $sMainType == ''){ echo 'checked="checked"';}?> <?php if($sAccess == '1') { echo 'disabled="disabled"';}?> hidefocus="true" style="outline: medium none;"><label id="relay_other_<?php echo $i;?>" for="radio_other_<?php echo $i;?>" class="<?php if($sMainType == '0' || $sMainType == ''){ echo 'checked';}?>">Other</label></div></div>
											<div class="rowRadio"><div class="custom-radio"><input class="powerRadio" type="radio" id="radio_spa_<?php echo $i;?>" name="<?php echo $i;?>_MainType" value="1" <?php if($sMainType == '1'){ echo 'checked="checked"';}?> <?php if($sAccess == '1') { echo 'disabled="disabled"';}?> hidefocus="true" style="outline: medium none;"><label id="relay_spa_<?php echo $i;?>" for="radio_spa_<?php echo $i;?>" class="<?php if($sMainType == '1'){ echo 'checked';}?>">Spa</label></div></div>
											<div class="rowRadio"><div class="custom-radio"><input class="powerRadio" type="radio" id="radio_pool_<?php echo $i;?>" name="<?php echo $i;?>_MainType" value="2" <?php if($sMainType == '2'){ echo 'checked="checked"';}?> <?php if($sAccess == '1') { echo 'disabled="disabled"';}?> hidefocus="true" style="outline: medium none;"><label id="relay_pool_<?php echo $i;?>" for="radio_pool_<?php echo $i;?>" class="<?php if($sMainType == '2'){ echo 'checked';}?>">Pool</label></div></div>
										</td>
										</tr>
								<?php  } ?>
								<?php  } ?>	
								</tbody>
								</table>
								</div>
							</div>
						</div>
						<!--/ Statistics -->
					</div>
			</div>	
		
	<?php } ?>
<?php } ?>	
<!-- END : 12V DC RELAY -->


<!-- START : VALVES -->
<?php 
	if($sDevice == 'V') // Valve Start 
	{ 
		$iValveNumber = $extra['ValveNumber']; ?>
	 <?php if($sAccess == '1' || $sAccess == '2') 
		   { ?>
			<link href="<?php echo site_url('assets/switchy/switchy.css'); ?>" rel="stylesheet" />
			<script type="text/javascript" src="<?php echo site_url('assets/switchy/switchy.js'); ?>"></script>
			<script type="text/javascript" src="<?php echo site_url('assets/switchy/jquery.event.drag.js'); ?>"></script>
			<script type="text/javascript" src="<?php echo site_url('assets/switchy/jquery.animate-color.js'); ?>"></script>
			<script>
			var iActiveMode = '<?php echo $iActiveMode;?>';
			var sAccess 	= '<?php echo $sAccess;?>';
			</script>
			<div class="row">
				<div class="col-sm-4">
					<div class="widget-container widget-stats boxed green-line">
					<div class="widget-title">
						<a href="<?php echo base_url('home/setting/'.$sDevice.'/');?>" class="link-refresh" id="link-refresh-1"><span class="glyphicon glyphicon-refresh"></span></a>
						<h3>ON/OFF</h3>
					</div>
					<div class="stats-content clearfix">
						<div class="stats-content-right" style="width:96% !important; margin-left:5px; margin-right:5px; margin-top:10px; float:none;">
						<?php
							if( $iValveNumber == 0 || $iValveNumber == '' )
							{ ?>
								<tr>
									<td>
										<span style="color:red">Please add number of Vavles in the <a href="<?php echo base_url('home/setting/');?>">Settings</a> Page!</span>
									</td>
								</tr>
							<?php 
							}
							else
							{
								//START : Valve Device 
								$arrValve	=	array(0,1,2,3,4,5,6,7);
								$j=0;
								$remainigCount	=	0;
								$chkValve		=	0;
								
								if(!empty($ValveRelays))
								{
									foreach($ValveRelays as $valve)
									{
										$i = $valve->device_number;
										$j = $i *2;
										
										unset($arrValve[$i]);
										
										$iValvesVal = $sValves[$i];
										$iValvesNewValSb1 = 1;
										$iValvesNewValSb2 = 2 ;
										if($iValvesVal == 1)
										{
										  $iValvesNewValSb1 = 0;
										}
										if($iValvesVal == 2)
										{
										  $iValvesNewValSb2 = 1;
										}
										$sValvesVal1 = false;
										$sValvesVal2 = false;
										if($iValvesVal == 1)
										  $sValvesVal1 = true;
										if($iValvesVal == 2)
										  $sValvesVal2 = true;
										//$sValvesNameDb = get_device_name(3, $i);

										$sValvesNameDb =  $this->home_model->getDeviceName($i,$sDevice);
										if($sValvesNameDb == '')
										  $sValvesNameDb = 'Add Name';
										
										//START : Get Valve Position Details.
										$aPositionName   =  $this->home_model->getPositionName($i,$sDevice);
										
										$strPosition1 = '';
										$strPosition2 = '';
										
										if($aPositionName[0] != '')
										$strPosition1	 =	$this->home_model->getPositionNameFromID($aPositionName[0]);
										if($aPositionName[1] != '')
										$strPosition2	 =	$this->home_model->getPositionNameFromID($aPositionName[1]);
										//END : Get Valve Position Details.
										
										$aRelayNumber    =  json_decode($this->home_model->getValveRelayNumber($i,$sDevice));
										$sMainType	     =  $this->home_model->getDeviceMainType($i,$sDevice);
										
										if($iValvesVal == '.' || $iValvesVal == '')
											continue;
										
										if($iValvesVal != '' && $iValvesVal != '.' && !empty($aRelayNumber)) 
										{
									?>
										<div class="row">
										<div class="col-sm-12">
									    <div class="span1 valve-<?php echo $i?>" value="1" style="margin-top: 10px; width: auto; color: #428BCA;font-weight: bold; cursor: pointer; float: left;"><?php echo $strPosition1; ?></div>
										<div class="span2" style="margin-left:5px; margin-right:5px; float: left;" >
										<select id='switch-me-<?php echo $i;?>'>
										<option value='1' <?php if($iValvesVal == '1') { echo 'selected="selected"';} ?>>Spa</option>
										<option value='0' <?php if($iValvesVal == '0' || $iValvesVal == '') { echo 'selected="selected"';} ?>></option>
										<option value='2' <?php if($iValvesVal == '2') { echo 'selected="selected"';} ?>>Pool</option>
										</select>
										<div class="valve-<?php echo $i?>" value="0" id="off-<?php echo $i;?>" style="color: red;font-weight: bold;width: 0; margin-left: 30px; cursor: pointer;">
											OFF
	</div>                              </div>
										<div class="span1 valve-<?php echo $i?>" value="2" style="margin-top: 10px; width: auto; color: #428BCA;font-weight: bold; cursor: pointer; float: left;"><?php echo $strPosition2; ?></div>
										<div style="float: right;margin-right: 10px;margin-top: 10px;"><strong><span style="color:#C9376E;"><?php echo 'Valve '.$i; ?></span></strong></div>
										<script type="text/javascript">
										  $(function()
										  {
												var bgColor = '#E8E8E8';
												<?php if($iValvesVal == '1' || $iValvesVal == '2') { ?>
														bgColor = '#45A31F';
												<?php } else { ?>
														bgColor = '#E8E8E8';
												<?php } ?>
												
												$('#switch-me-<?php echo $i;?>').switchy();
												
												$('.valve-<?php echo $i?>').on('click', function(event){
													//event.preventDefault();
													//return false;
													$('#switch-me-<?php echo $i;?>').val($(this).attr('value')).change();
												});
												
												$('#switch-me-<?php echo $i;?>').next('.switchy-container').find('.switchy-bar').animate({
														backgroundColor: bgColor
													});
												
												$('#switch-me-<?php echo $i;?>').on('change', function(event)
												{
													if(sAccess == 2)
													{
														if(iActiveMode != 2)
														{
															var bConfirm	=	confirm('You will need to change to Manual mode to make this change.\nWould you like to activate manual mode?' );
															if(bConfirm)
															{
																$.ajax({
																	type: "POST",
																	url: "<?php echo site_url('analog/changeMode');?>", 
																	data: {iMode:'2'},
																	success: function(data) {
																	}
																});
																//event.preventDefault();
																//return false;
																// Animate Switchy Bar background color
																var bgColor = '#E8E8E8';

																if ($(this).val() == '1' || $(this).val() == '2')
																{
																	bgColor = '#45A31F';
																} 
																$('#switch-me-<?php echo $i;?>').next('.switchy-container').find('.switchy-bar').animate({
																	backgroundColor: bgColor
																});
															
																
																//$("#loading_valve_<?php //echo $i;?>").css('visibility','visible');
																$.ajax({
																	type: "POST",
																	url: "<?php echo site_url('home/updateStatusOnOff');?>", 
																	data: {sName:'<?php echo $i;?>',sStatus:$(this).val(),sDevice:'<?php echo $sDevice;?>'},
																	success: function(data) {
																	//$("#loading_valve_<?php //echo $i;?>").css('visibility','hidden');
																	location.reload();
																	}

																});
															}
														}
														else											
														{
															//event.preventDefault();
															//return false;
															// Animate Switchy Bar background color
															var bgColor = '#E8E8E8';

															if ($(this).val() == '1' || $(this).val() == '2')
															{
																bgColor = '#45A31F';
															} 
															$('#switch-me-<?php echo $i;?>').next('.switchy-container').find('.switchy-bar').animate({
																backgroundColor: bgColor
															});
														
															
															//$("#loading_valve_<?php //echo $i;?>").css('visibility','visible');
															$.ajax({
																type: "POST",
																url: "<?php echo site_url('home/updateStatusOnOff');?>", 
																data: {sName:'<?php echo $i;?>',sStatus:$(this).val(),sDevice:'<?php echo $sDevice;?>'},
																success: function(data) {
																//$("#loading_valve_<?php //echo $i;?>").css('visibility','hidden');
																}

															});
														}
													}
												});
											});
									   </script>
									  </div>
									</div>
									<div style="height:10px;">&nbsp;</div>
							<?php 	}
									else
								    {
										echo '<div class="row"><div class="col-sm-12"><div class="tagcloud clearfix"><span style="color:#FF0000;">Relay Not Assigned</span><div style="float: right;margin-right: 10px;color:#C9376E"><strong>Valve '.$i.'</strong></div></div></div></div><div style="height:10px;">&nbsp;</div>';
								    }
									
										$chkValve++;
									}		
								}
								$remainigCount	=	$iValveNumber - $chkValve;
								//for ($i=0;$i < $valve_count; $i++)	
								//for ($i=0;$i < $remainigCount ; $i++)
								foreach($arrValve as $i)	
								{
									if($remainigCount == 0)	
										break;
									
									$remainigCount--;
									
									$j = $i * 2;
									
									$iValvesVal = $sValves[$i];
									$iValvesNewValSb1 = 1;
									$iValvesNewValSb2 = 2 ;
									if($iValvesVal == 1)
									{
									  $iValvesNewValSb1 = 0;
									}
									if($iValvesVal == 2)
									{
									  $iValvesNewValSb2 = 1;
									}
									$sValvesVal1 = false;
									$sValvesVal2 = false;
									if($iValvesVal == 1)
									  $sValvesVal1 = true;
									if($iValvesVal == 2)
									  $sValvesVal2 = true;
									//$sValvesNameDb = get_device_name(3, $i);

									$sValvesNameDb =  $this->home_model->getDeviceName($i,$sDevice);
									
									//START : Get Valve Position Details.
									$aPositionName   =  $this->home_model->getPositionName($i,$sDevice);
									
									$strPosition1 = '';
									$strPosition2 = '';
									
									if($aPositionName[0] != '')
									$strPosition1	 =	$this->home_model->getPositionNameFromID($aPositionName[0]);
									if($aPositionName[1] != '')
									$strPosition2	 =	$this->home_model->getPositionNameFromID($aPositionName[1]);
									//END : Get Valve Position Details.
								
									
									$aRelayNumber    =  json_decode($this->home_model->getValveRelayNumber($i,$sDevice));
									$iPower	 	     =  $this->home_model->getDevicePower($i,$sDevice);
									$sMainType	     =  $this->home_model->getDeviceMainType($i,$sDevice);
									
								if($iValvesVal != '' && $iValvesVal != '.' && !empty($aRelayNumber)) 
								{
								?>
									<div class="row">
									<div class="col-sm-12">
									<div class="span1 valve-<?php echo $i?>" value="1" style="margin-top: 10px; width: auto; color: #428BCA;font-weight: bold; cursor: pointer; float: left;"><?php  echo $strPosition1; ?></div>
									<div class="span2" style="margin-left:5px; margin-right:5px; float: left;" >
									<select id='switch-me-<?php echo $i;?>'>
									<option value='1' <?php if($iValvesVal == '1') { echo 'selected="selected"';} ?>>Spa</option>
									<option value='0' <?php if($iValvesVal == '0' || $iValvesVal == '') { echo 'selected="selected"';} ?>></option>
									<option value='2' <?php if($iValvesVal == '2') { echo 'selected="selected"';} ?>>Pool</option>
									</select>
									<div class="valve-<?php echo $i?>" value="0" id="off-<?php echo $i;?>" style="color: red;font-weight: bold;width: 0; margin-left: 30px; cursor: pointer;">
										OFF
	</div>                              </div>
									<div class="span1 valve-<?php echo $i?>" value="2" style="margin-top: 10px; width: auto; color: #428BCA;font-weight: bold; cursor: pointer; float: left;"><?php  echo $strPosition2; ?></div>
									<div style="float: right;margin-right: 10px;margin-top: 10px;"><strong><span style="color:#C9376E;"><?php echo 'Valve '.$i; ?></span></strong></div>
									<script type="text/javascript">
									  $(function()
									  {
											var bgColor = '#E8E8E8';
											<?php if($iValvesVal == '1' || $iValvesVal == '2') { ?>
													bgColor = '#45A31F';
											<?php } else { ?>
													bgColor = '#E8E8E8';
											<?php } ?>
											
											$('#switch-me-<?php echo $i;?>').switchy();
											
											$('.valve-<?php echo $i?>').on('click', function(event){
												//event.preventDefault();
												//return false;
												$('#switch-me-<?php echo $i;?>').val($(this).attr('value')).change();
											});
											
											$('#switch-me-<?php echo $i;?>').next('.switchy-container').find('.switchy-bar').animate({
													backgroundColor: bgColor
												});
											
											$('#switch-me-<?php echo $i;?>').on('change', function(event)
											{
												if(sAccess == 2)
												{
													if(iActiveMode != 2)
													{
														var bConfirm	=	confirm('You will need to change to Manual mode to make this change.\nWould you like to activate manual mode?' );
														if(bConfirm)
														{
															$.ajax({
																type: "POST",
																url: "<?php echo site_url('analog/changeMode');?>", 
																data: {iMode:'2'},
																success: function(data) {
																}
															});
															//event.preventDefault();
															//return false;
															// Animate Switchy Bar background color
															var bgColor = '#E8E8E8';

															if ($(this).val() == '1' || $(this).val() == '2')
															{
																bgColor = '#45A31F';
															} 
															$('#switch-me-<?php echo $i;?>').next('.switchy-container').find('.switchy-bar').animate({
																backgroundColor: bgColor
															});
														
															
															//$("#loading_valve_<?php //echo $i;?>").css('visibility','visible');
															$.ajax({
																type: "POST",
																url: "<?php echo site_url('home/updateStatusOnOff');?>", 
																data: {sName:'<?php echo $i;?>',sStatus:$(this).val(),sDevice:'<?php echo $sDevice;?>'},
																success: function(data) {
																//$("#loading_valve_<?php //echo $i;?>").css('visibility','hidden');
																location.reload();
																}

															});
														}
													}
													else											
													{
														//event.preventDefault();
														//return false;
														// Animate Switchy Bar background color
														var bgColor = '#E8E8E8';

														if ($(this).val() == '1' || $(this).val() == '2')
														{
															bgColor = '#45A31F';
														} 
														$('#switch-me-<?php echo $i;?>').next('.switchy-container').find('.switchy-bar').animate({
															backgroundColor: bgColor
														});
													
														
														//$("#loading_valve_<?php //echo $i;?>").css('visibility','visible');
														$.ajax({
															type: "POST",
															url: "<?php echo site_url('home/updateStatusOnOff');?>", 
															data: {sName:'<?php echo $i;?>',sStatus:$(this).val(),sDevice:'<?php echo $sDevice;?>'},
															success: function(data) {
															//$("#loading_valve_<?php //echo $i;?>").css('visibility','hidden');
															}

														});
													}
												}
											});
										});
									</script> 
								</div>
								</div>
								<div style="height:10px;">&nbsp;</div>
							<?php }	
									else
								    {
										echo '<div class="row"><div class="col-sm-12"><div class="tagcloud clearfix"><span style="color:#FF0000;">Relay Not Assigned.</span><div style="float: right;margin-right: 10px; color:#C9376E"><strong>Valve '.$i.'</strong></div></div></div></div><div style="height:10px;">&nbsp;</div>';
								    }
								}
							}
							?>
						</div>
					</div>
					</div>
				</div>
				<div class="col-sm-8">
				<div class="widget-container widget-stats boxed green-line">
					<div class="widget-title">
						<a href="<?php echo base_url('home/setting/'.$sDevice.'/');?>" class="link-refresh" id="link-refresh-1"><span class="glyphicon glyphicon-refresh"></span></a>
						<h3>Valve Settings</h3>
					</div>
				<?php
					if( $iValveNumber == 0 || $iValveNumber == '' )
							{ ?>
								<div class="stats-content clearfix">
								<div class="stats-content-right" style="width:100% !important; margin-left:5px; margin-right:5px; float:none;">
										<span style="color:red">Please add number of Vavles in the <a href="<?php echo base_url('home/setting/');?>">Settings</a> Page!</span>
								</div>
								</div>
								
							<?php 
							}
							else
							{
							?>
							
								<div class="stats-content clearfix">
								<div class="stats-content-right" style="width:100% !important; margin-left:5px; margin-right:5px; float:none;">
							
							  <table class="table table-hover">
								<thead>
								  <tr>
									<th class="header" style="width:25%">Valve</th>
									<th class="header"  style="width:25%">Type</th>
									<th class="header"  style="width:50%">Action</th>
								  </tr>
								</thead>
								<tbody>
								<?php			
								$arrValve	=	array(0,1,2,3,4,5,6,7);
								$j=0;
								$remainigCount	=	0;
								$chkValve		=	0;
								
								if(!empty($ValveRelays))
								{
									foreach($ValveRelays as $valve)
									{
										$i = $valve->device_number;
										$j = $i *2;
										
										unset($arrValve[$i]);
										
										$iValvesVal = $sValves[$i];
										$iValvesNewValSb1 = 1;
										$iValvesNewValSb2 = 2 ;
										if($iValvesVal == 1)
										{
										  $iValvesNewValSb1 = 0;
										}
										if($iValvesVal == 2)
										{
										  $iValvesNewValSb2 = 1;
										}
										$sValvesVal1 = false;
										$sValvesVal2 = false;
										if($iValvesVal == 1)
										  $sValvesVal1 = true;
										if($iValvesVal == 2)
										  $sValvesVal2 = true;
										//$sValvesNameDb = get_device_name(3, $i);

										$sValvesNameDb =  $this->home_model->getDeviceName($i,$sDevice);
										if($sValvesNameDb == '')
										  $sValvesNameDb = 'Add Name';
									  
										$aPositionName   =  $this->home_model->getPositionName($i,$sDevice);
										$aRelayNumber    =  json_decode($this->home_model->getValveRelayNumber($i,$sDevice));
										$sMainType	     =  $this->home_model->getDeviceMainType($i,$sDevice);
										
									?>
										<tr>
										<td>Valve <?php echo $i;?><br />(<a href="<?php if($sAccess == 2) { echo site_url('home/deviceName/'.base64_encode($i).'/'.base64_encode($sDevice).'/'); } else { echo 'javascript:void(0);';}?>" ><?php echo $sValvesNameDb;?></a>)</td>
										<td>
											<div class="rowRadio"><div class="custom-radio"><input class="valveRadio" type="radio" id="radio_other_<?php echo $i;?>" value="0" name="<?php echo $i;?>_MainType" <?php if($sMainType == '0' || $sMainType == ''){ echo 'checked="checked"';}?> <?php if($sAccess == '1') { echo 'disabled="disabled"';}?> hidefocus="true" style="outline: medium none;"><label id="relay_other_<?php echo $i;?>" for="radio_other_<?php echo $i;?>" class="<?php if($sMainType == '0' || $sMainType == ''){ echo 'checked';}?>">Other</label></div></div>
											<div class="rowRadio"><div class="custom-radio"><input class="valveRadio" type="radio" id="radio_spa_<?php echo $i;?>" name="<?php echo $i;?>_MainType" value="1" <?php if($sMainType == '1'){ echo 'checked="checked"';}?> <?php if($sAccess == '1') { echo 'disabled="disabled"';}?> hidefocus="true" style="outline: medium none;"><label id="relay_spa_<?php echo $i;?>" for="radio_spa_<?php echo $i;?>" class="<?php if($sMainType == '1'){ echo 'checked';}?>">Spa</label></div></div>
											<div class="rowRadio"><div class="custom-radio"><input class="valveRadio" type="radio" id="radio_pool_<?php echo $i;?>" name="<?php echo $i;?>_MainType" value="2" <?php if($sMainType == '2'){ echo 'checked="checked"';}?> <?php if($sAccess == '1') { echo 'disabled="disabled"';}?> hidefocus="true" style="outline: medium none;"><label id="relay_pool_<?php echo $i;?>" for="radio_pool_<?php echo $i;?>" class="<?php if($sMainType == '2'){ echo 'checked';}?>">Pool</label></div></div>
										</td>
										<td>

										<a class="btn btn-green btn-small" style="width:120px" href="<?php if($sAccess == '2') { echo base_url('home/valveRelays/'.base64_encode($i).'/'.base64_encode($sDevice));} else { echo 'javascript:void(0);';}?>"><span>Assign Relays</span></a>
										<?php if(!empty($aRelayNumber)) { ?>
										<a class="btn btn-red btn-small" style="width:120px" href="javascript:void(0);" <?php if($sAccess == '2') { echo 'onclick="return RemoveValveRelays(\''.$i.'\')"';} ?>><span>Remove Relays</span></a>
										<?php } ?>
										
										<!-- Position Button-->
										
										<!--<a class="btn btn-small" style="width:120px" href="<?php //if($sAccess == 2) { echo site_url('home/positionName/'.base64_encode($i).'/'.base64_encode($sDevice).'/'); } else { echo 'javascript:void(0);';}?>"><span>Edit Position</span></a>-->
										
										<!-- Position Button-->
										
										<!--<a class="btn btn-small btn-red" style="width:120px" href="<?php //if($sAccess == 2) { echo site_url('home/removeValve/'.base64_encode($i).'/'.base64_encode($sDevice).'/'); } else { echo 'javascript:void(0);';}?>"><span>Remove Valve</span></a>-->
										</td>
										</tr>
								<?php
										$chkValve++;
									} ?>
								<?php  } ?>	
							
							<?php
								$remainigCount	=	$iValveNumber - $chkValve;
								//for ($i=0;$i < $valve_count; $i++)	
								//for ($i=0;$i < $remainigCount ; $i++)
								foreach($arrValve as $i)	
								{
									if($remainigCount == 0)	
										break;
									
									$remainigCount--;
									
									$j = $i * 2;
									
									$iValvesVal = $sValves[$i];
									$iValvesNewValSb1 = 1;
									$iValvesNewValSb2 = 2 ;
									if($iValvesVal == 1)
									{
									  $iValvesNewValSb1 = 0;
									}
									if($iValvesVal == 2)
									{
									  $iValvesNewValSb2 = 1;
									}
									$sValvesVal1 = false;
									$sValvesVal2 = false;
									if($iValvesVal == 1)
									  $sValvesVal1 = true;
									if($iValvesVal == 2)
									  $sValvesVal2 = true;
									//$sValvesNameDb = get_device_name(3, $i);

									$sValvesNameDb =  $this->home_model->getDeviceName($i,$sDevice);
									if($sValvesNameDb == '')
									  $sValvesNameDb = 'Add Name';
								  
									$aPositionName   =  $this->home_model->getPositionName($i,$sDevice);
									$aRelayNumber    =  json_decode($this->home_model->getValveRelayNumber($i,$sDevice));
									$iPower	 	     =  $this->home_model->getDevicePower($i,$sDevice);
									$sMainType	     =  $this->home_model->getDeviceMainType($i,$sDevice);
							?>
									<tr>
										<td>Valve <?php echo $i;?><br />(<a href="<?php if($sAccess == 2) { echo site_url('home/deviceName/'.base64_encode($i).'/'.base64_encode($sDevice).'/'); } else { echo 'javascript:void(0);';}?>" ><?php echo $sValvesNameDb;?></a>)</td>
										<td>
											<div class="rowRadio"><div class="custom-radio"><input class="valveRadio" type="radio" id="radio_other_<?php echo $i;?>" value="0" name="<?php echo $i;?>_MainType" <?php if($sMainType == '0' || $sMainType == ''){ echo 'checked="checked"';}?> <?php if($sAccess == '1') { echo 'disabled="disabled"';}?> hidefocus="true" style="outline: medium none;"><label id="relay_other_<?php echo $i;?>" for="radio_other_<?php echo $i;?>" class="<?php if($sMainType == '0' || $sMainType == ''){ echo 'checked';}?>">Other</label></div></div>
											<div class="rowRadio"><div class="custom-radio"><input class="valveRadio" type="radio" id="radio_spa_<?php echo $i;?>" name="<?php echo $i;?>_MainType" value="1" <?php if($sMainType == '1'){ echo 'checked="checked"';}?> <?php if($sAccess == '1') { echo 'disabled="disabled"';}?> hidefocus="true" style="outline: medium none;"><label id="relay_spa_<?php echo $i;?>" for="radio_spa_<?php echo $i;?>" class="<?php if($sMainType == '1'){ echo 'checked';}?>">Spa</label></div></div>
											<div class="rowRadio"><div class="custom-radio"><input class="valveRadio" type="radio" id="radio_pool_<?php echo $i;?>" name="<?php echo $i;?>_MainType" value="2" <?php if($sMainType == '2'){ echo 'checked="checked"';}?> <?php if($sAccess == '1') { echo 'disabled="disabled"';}?> hidefocus="true" style="outline: medium none;"><label id="relay_pool_<?php echo $i;?>" for="radio_pool_<?php echo $i;?>" class="<?php if($sMainType == '2'){ echo 'checked';}?>">Pool</label></div></div>
										</td>
										<td>
										<a class="btn btn-green btn-small" style="width:120px" href="<?php if($sAccess == '2') { echo base_url('home/valveRelays/'.base64_encode($i).'/'.base64_encode($sDevice));} else { echo 'javascript:void(0);';}?>"><span>Assign Relays</span></a>
										<?php if(!empty($aRelayNumber)) { ?>
										&nbsp;&nbsp;<a class="btn btn-red btn-small" style="width:120px" href="javascript:void(0);" <?php if($sAccess == '2') { echo ' onclick="return RemoveValveRelays(\''.$i.'\');"';}?>><span>Remove Relays</span></a>
										<?php } ?>
										<!-- Position Button-->
										
										<!-- <a class="btn btn-small" style="width:120px" href="<?php //if($sAccess == 2) { echo site_url('home/positionName/'.base64_encode($i).'/'.base64_encode($sDevice).'/'); } else { echo 'javascript:void(0);';}?>"><span>Edit Position</span></a> -->
										
										<!-- Position Button-->
										
										<a class="btn btn-small btn-red" style="width:120px" href="javascript:void(0);" <?php if($sAccess == '2') { echo ' onclick="removeValve();"';}?> ><span>Remove Valve</span></a>
										</td>
										</tr>
								<?php	} ?>
									<tr><td colspan="3">
									<div class="buttons">
									<a class="btn btn-icon btn-icon-right btn-icon-go" id="addMoreValve" href="javascript:void(0);" hidefocus="true" style="outline: medium none; padding:0px !important;"><span>Add More Valve</span></a>
									</div>
									<div id="moreValve" style="display:none;">
									<input type="text" value="" id="moreValveCnt" name="moreValveCnt" hidefocus="true" style="outline: medium none; width: 45%; margin-top:1px; margin-right:10px;" placeholder="Add Number"><a class="btn btn-icon btn-green btn-icon-right btn-icon-checkout" href="javascript:void(0);" style="padding:0px !important;" hidefocus="true" onclick="saveValveCount()"><span>Save</span></a>
									</div>
									</td></tr>
								</tbody>
								</table>
								</div>
							</div>
						</div>							
								
							<?php	
							}
							
							?>
				</div>
			</div>	
		 
	<?php  } ?>
<?php } ?>	
<!-- END : VALVE DEVICES-->

<!-- START : PUMPS -->
<?php if($sDevice == 'PS') {  // START : Pump Device
				$iPumpsNumber	=	$extra['PumpsNumber'];
		?>
		<?php if($sAccess == 1 || $sAccess == 2) { ?>
			<div class="row">
				<div class="col-sm-6">
					<div class="widget-container widget-stats boxed green-line">
					<div class="widget-title">
						<a href="<?php echo base_url('home/setting/'.$sDevice.'/');?>" class="link-refresh" id="link-refresh-1"><span class="glyphicon glyphicon-refresh"></span></a>
						<h3>ON/OFF</h3>
					</div>
					<div class="stats-content clearfix">
						<div class="stats-content-right" style="width:96% !important; margin-left:5px; margin-right:5px; margin-top:10px; float:none;">
						<?php
                    
								if( $iPumpsNumber == 0 || $iPumpsNumber == '' )
								{ ?>
									
									<div class="row">
										<div class="col-sm-12">
											<span style="color:red">Please add number of Pumps in the <a href="<?php echo base_url('home/setting/');?>">Settings</a> Page!</span>
										</div>
									</div>
									
								<?php 
								}
								else
								{
									$arrPump		=	array(0,1,2);
									$remainigCount	=	0;
									$chkPump		=	0;
									if(!empty($Pumps))
									{
										foreach($Pumps as $pump)
										{
											
										$i= $pump->pump_number;
										unset($arrPump[$i]);		
										$iPumpVal = $sPump[$i];
										$sPumpNameDb =  $this->home_model->getDeviceName($i,$sDevice);
										if($sPumpNameDb == '')
										  $sPumpNameDb = 'Add Name';
										
										$sStatus2Speed	=	'';
										
										$aPumpDetails = $this->home_model->getPumpDetails($i);
										$sPumpType		=	'';
										if(!empty($aPumpDetails))
										{
											foreach($aPumpDetails as $aResultEdit)
											{
												$sPumpType    = $aResultEdit->pump_type;//Pump Type
												$sPumpRelay   = $aResultEdit->relay_number;//Assigned Relay Number
												$sPumpRelay1   = $aResultEdit->relay_number_1;//Assigned Relay Number
												if($sPumpType == '12')
												{
													$iPumpVal = $sPowercenter[$sPumpRelay]; //Taken the status
												}
												else if($sPumpType == '24')
												{
													$iPumpVal = $sRelays[$sPumpRelay];//Taken the status
												}
												else if($sPumpType == '2Speed')
												{
													$sPumpSubType    = $aResultEdit->pump_sub_type;//Pump SUB Type
													$sStatus2Speed   = $aResultEdit->status;//Pump SUB Type
													
													if($sStatus2Speed == '0')
													{
														$iPumpVal        = $sStatus2Speed;
													}
													else if($sStatus2Speed == '1')											
													{
														if($sPumpSubType == '12')
														{
															$iPumpVal = $sPowercenter[$sPumpRelay]; //Taken the status
														}
														else if($sPumpSubType == '24')
														{
															$iPumpVal = $sRelays[$sPumpRelay];//Taken the status
														}
													}
													else if($sStatus2Speed == '2')											
													{
														if($sPumpSubType == '12')
														{
															$iPumpVal = $sPowercenter[$sPumpRelay1]; //Taken the status
														}
														else if($sPumpSubType == '24')
														{
															$iPumpVal = $sRelays[$sPumpRelay1];//Taken the status
														}
													}
												}
												else if(preg_match('/Emulator/',$sPumpType))
												{
													 $iPumpVal = $sPump[$i];
												}
											}
										}	//END : Getting assigned relay status from the Server.
										$sPumpVal = false;
										if($iPumpVal)
										  $sPumpVal = true;
										
										$strChecked	=	'';
										if($iPumpVal > 0)
											$strChecked	=	'class="checked"';
									  
										$sMainType	 = $this->home_model->getDeviceMainType($i,$sDevice);
										
										$strPumpName = 'Pump '.$i;
										if($sPumpNameDb != '' && $sPumpNameDb != 'Add Name')
											$strPumpName .= '('.$sPumpNameDb.')';
										
										if($sStatus2Speed == '')
											$sStatus2Speed = '0';
								?>
										<div class="row">
										<div class="col-sm-12">
										<?php if($sPumpType == '2Speed') { ?>
										<script>
										var iActiveMode = '<?php echo $iActiveMode;?>';
										var sAccess 	= '<?php echo $sAccess;?>';
										</script>
										<link href="<?php echo site_url('assets/switchy/switchy.css'); ?>" rel="stylesheet" />
										<script type="text/javascript" src="<?php echo site_url('assets/switchy/switchy.js'); ?>"></script>
										<script type="text/javascript" src="<?php echo site_url('assets/switchy/jquery.event.drag.js'); ?>"></script>
										<script type="text/javascript" src="<?php echo site_url('assets/switchy/jquery.animate-color.js'); ?>"></script>
										<div class="span1 pump-<?php echo $i?>" value="1" style="margin-top: 10px; width: auto; color: #428BCA;font-weight: bold; cursor: pointer; float: left;">Relay 1</div>
										<div class="span2" style="margin-left:5px; margin-right:5px; float: left;" >
										<select id='switch-me-<?php echo $i;?>'>
										<option value='1' <?php if($sStatus2Speed == '1') { echo 'selected="selected"';} ?>>Spa</option>
										<option value='0' <?php if($sStatus2Speed == '0' || $iPumpVal == '') { echo 'selected="selected"';} ?>></option>
										<option value='2' <?php if($sStatus2Speed == '2') { echo 'selected="selected"';} ?>>Pool</option>
										</select>
										<div class="pump-<?php echo $i?>" value="0" id="off-<?php echo $i;?>" style="color: red;font-weight: bold;width: 0; margin-left: 30px; cursor: pointer;">
											OFF
										</div>                              </div>
										<div class="span1 pump-<?php echo $i?>" value="2" style="margin-top: 10px; width: auto; color: #428BCA;font-weight: bold; cursor: pointer; float: left;">Relay 2</div>
										<div style="margin-top:10px; float:right; color:#C9376E;"><strong><?php echo $strPumpName;?></strong></div>
										
									  <script type="text/javascript">
									  
									  $(function()
									  {
										  var bgColor = '#E8E8E8';
											<?php if($iPumpVal == '1' || $iPumpVal == '2') { ?>
													bgColor = '#45A31F';
											<?php } else { ?>
													bgColor = '#E8E8E8';
											<?php } ?>
											
											$('#switch-me-<?php echo $i;?>').switchy();
											
											$('.pump-<?php echo $i?>').on('click', function(event){
												//event.preventDefault();
												//return false;
												$('#switch-me-<?php echo $i;?>').val($(this).attr('value')).change();
											});
											
											$('#switch-me-<?php echo $i;?>').next('.switchy-container').find('.switchy-bar').animate({
													backgroundColor: bgColor
												});
											
											$('#switch-me-<?php echo $i;?>').on('change', function(event)
											{
												if(sAccess == 2)
												{
													if(iActiveMode != 2)
													{
														var bConfirm	=	confirm('You will need to change to Manual mode to make this change.\nWould you like to activate manual mode?' );
														if(bConfirm)
														{
															$.ajax({
																type: "POST",
																url: "<?php echo site_url('analog/changeMode');?>", 
																data: {iMode:'2'},
																success: function(data) {
																}
															});
															//event.preventDefault();
															//return false;
															// Animate Switchy Bar background color
															var bgColor = '#E8E8E8';

															if ($(this).val() == '1' || $(this).val() == '2')
															{
																bgColor = '#45A31F';
															} 
															$('#switch-me-<?php echo $i;?>').next('.switchy-container').find('.switchy-bar').animate({
																backgroundColor: bgColor
															});
														
															
															//$("#loading_valve_<?php //echo $i;?>").css('visibility','visible');
															$.ajax({
																type: "POST",
																url: "<?php echo site_url('home/updateStatusOnOff');?>", 
																data: {sName:'<?php echo $i;?>',sStatus:$(this).val(),sDevice:'<?php echo $sDevice;?>'},
																success: function(data) {
																//$("#loading_valve_<?php //echo $i;?>").css('visibility','hidden');
																location.reload();
																}

															});
														}
													}
													else											
													{
														//event.preventDefault();
														//return false;
														// Animate Switchy Bar background color
														var bgColor = '#E8E8E8';

														if ($(this).val() == '1' || $(this).val() == '2')
														{
															bgColor = '#45A31F';
														} 
														$('#switch-me-<?php echo $i;?>').next('.switchy-container').find('.switchy-bar').animate({
															backgroundColor: bgColor
														});
													
														
														//$("#loading_valve_<?php //echo $i;?>").css('visibility','visible');
														$.ajax({
															type: "POST",
															url: "<?php echo site_url('home/updateStatusOnOff');?>", 
															data: {sName:'<?php echo $i;?>',sStatus:$(this).val(),sDevice:'<?php echo $sDevice;?>'},
															success: function(data) {
															//$("#loading_valve_<?php //echo $i;?>").css('visibility','hidden');
															}

														});
													}
												}
											});
										});
								   </script>
								   
										<?php } else if($sPumpType != '') { ?>
										
										<?php if(preg_match('/Emulator/',$sPumpType)) { ?>
										<script>
										  $(document).ready(function() {
											setInterval( function() {
												$.getJSON('<?php echo site_url('cron/pumpResponseLatest/');?>', {iPumpID: "<?php echo $i;?>"}, function(json) {
													
													if(json == '')
													{
														$("#lablePump-"+<?php echo $i;?>).removeClass('checked');
														$("#pumpRealResponse_"+<?php echo $i;?>).html('');
														$("#pumpProgrmaStatus_"+<?php echo $i;?>).html('');
													}
													else
													{
														$("#pumpRealResponse_"+<?php echo $i;?>).html(json);
														if($("#lablePump-"+<?php echo $i;?>).hasClass('checked'))
														{}
														else
														{
															$("#lablePump-"+<?php echo $i;?>).addClass('checked');
														}
													}
												});
												},30000);
												
												setInterval( function() {
												$.getJSON('<?php echo site_url('cron/getPumpProgramStatus/');?>', {iPumpID: "<?php echo $i;?>"}, function(json) {
													
													if(json == '')
													{
														$("#pumpProgrmaStatus_"+<?php echo $i;?>).html('');
													}
													else
													{
														$("#pumpProgrmaStatus_"+<?php echo $i;?>).html(json);
													}
												});
												},30000);
												
										  });
										</script>										  
										   <?php } ?>
										<div class="rowCheckbox switch">
											<div class="custom-checkbox"><input type="checkbox" value="<?php echo $i;?>" id="pumps-<?php echo $i?>" name="pumps-<?php echo $i?>" class="pumpsButton" hidefocus="true" style="outline: medium none;">
												<label style="margin-left: 60px;" <?php echo $strChecked;?>  id="lablePump-<?php echo $i?>" for="pumps-<?php echo $i?>"><span style="float:right; color:#C9376E;"><?php echo $strPumpName;?></span></label>
											</div>
										</div>
											<?php if(preg_match('/Emulator/',$sPumpType)) { ?>
											<div id="pumpRealResponse_<?php echo $i;?>" style="color: #164c87;font-weight: bold;"><?php if($iPumpVal > 0) { echo $strPumpsResponse		= $this->home_model->selectPumpsLatestResponse($i); }?></div>
											<div id="pumpProgrmaStatus_<?php echo $i;?>" style="color: #c9376e;font-weight: bold;"><?php if($iPumpVal > 0)
											{
												$aAllActiveProgram	=	$this->home_model->getAllActiveProgramsForPump($i);
												$strMessage		=	'';	
												if(!empty($aAllActiveProgram))
												{
													foreach($aAllActiveProgram as $aActiveProgram)
													{
														if($aActiveProgram->device_type == 'PS')
														{
															$aPumpDetails 	=	$this->home_model->getPumpDetails($aActiveProgram->device_number);
															
															if(is_array($aPumpDetails) && !empty($aPumpDetails))
															{
																foreach($aPumpDetails as $aResultEdit)
																{ 
																	$sPumpNumber  = $aResultEdit->pump_number;
																	$sPumpType    = $aResultEdit->pump_type;
																	$sPumpSubType = $aResultEdit->pump_sub_type;
																	$sPumpSpeed   = $aResultEdit->pump_speed;
																}
															}
															
															if($strMessage != '')
															{
																$strMessage .= ' <br /><strong>'.$aActiveProgram->program_name.'</strong> Program is Running for <strong>Pump '.$aActiveProgram->device_number.'</strong>';
																
																if($sPumpType	==	'Emulator' && $sPumpSubType == 'VS')
																{
																	$strMessage .= ' With <strong>Speed '.$sPumpSpeed.' </strong>';
																}
																$strMessage .= '!';
															}
															else
															{
																$strMessage .= '<strong>'.$aActiveProgram->program_name.'</strong> Program is Running for <strong>Pump '.$aActiveProgram->device_number.'</strong>';
																
																if($sPumpType	==	'Emulator' && $sPumpSubType == 'VS')
																{
																	$strMessage .= ' With <strong>Speed '.$sPumpSpeed.' </strong>';
																}
																$strMessage .= '!';
															}
														}
													}
												}	
												echo $strMessage;		
											}?></div>
											<?php } ?>
										<?php } ?>
										</div>
										</div>
										<div style="height:20px;">&nbsp;</div>
									<?php 
										$chkPump++;
									}
									?>
								<?php } ?>
								<?php 
									$remainigCount	=	$iPumpsNumber - $chkPump;
									//for ($i=0;$i < $valve_count; $i++)	
									//for ($i=0;$i < $remainigCount ; $i++)
									foreach($arrPump as $i)	
									{
										if($remainigCount == 0)	
											break;
										
										$remainigCount--;
												
									//for ($i=0;$i < $pump_count; $i++)
									//{
										$iPumpVal = $sPump[$i];
										/* $iPumpNewValSb = 1;
										if($iPumpVal == 1)
										{
										  $iPumpNewValSb = 0;
										}
										$sPumpVal = false;
										if($iPumpVal)
										  $sPumpVal = true; */
										//$sRelayNameDb = get_device_name(1, $i);
									
										$sPumpNameDb =  $this->home_model->getDeviceName($i,$sDevice);
										if($sPumpNameDb == '')
										  $sPumpNameDb = 'Add Name';
										
										//$iPower	 = $this->home_model->getDevicePower($i,$sDevice);
										
										//$sPowercenter = '01000000'		;
										//START : Getting assigned relay status from the Server.	
										//Details of Pump
										
										$sStatus2Speed	=	'';
										
										$aPumpDetails = $this->home_model->getPumpDetails($i);
										$sPumpType		=	'';
										if(!empty($aPumpDetails))
										{
											foreach($aPumpDetails as $aResultEdit)
											{
												$sPumpType    = $aResultEdit->pump_type;//Pump Type
												$sPumpRelay   = $aResultEdit->relay_number;//Assigned Relay Number
												$sPumpRelay1   = $aResultEdit->relay_number_1;//Assigned Relay Number
												if($sPumpType == '12')
												{
													$iPumpVal = $sPowercenter[$sPumpRelay]; //Taken the status
												}
												else if($sPumpType == '24')
												{
													$iPumpVal = $sRelays[$sPumpRelay];//Taken the status
												}
												else if($sPumpType == '2Speed')
												{
													$sPumpSubType    = $aResultEdit->pump_sub_type;//Pump SUB Type
													$sStatus2Speed   = $aResultEdit->status;//Pump SUB Type
													
													
													if($sStatus2Speed == '0')
													{
														$iPumpVal        = $sStatus2Speed;
													}
													else if($sStatus2Speed == '1')											
													{
														if($sPumpSubType == '12')
														{
															$iPumpVal = $sPowercenter[$sPumpRelay]; //Taken the status
														}
														else if($sPumpSubType == '24')
														{
															$iPumpVal = $sRelays[$sPumpRelay];//Taken the status
														}
													}
													else if($sStatus2Speed == '2')											
													{
														if($sPumpSubType == '12')
														{
															$iPumpVal = $sPowercenter[$sPumpRelay1]; //Taken the status
														}
														else if($sPumpSubType == '24')
														{
															$iPumpVal = $sRelays[$sPumpRelay1];//Taken the status
														}
													}
												}
												else if(preg_match('/Emulator/',$sPumpType))
												{
													 $iPumpVal = $sPump[$i];
												}
											}
										}	//END : Getting assigned relay status from the Server.
										$sPumpVal = false;
										if($iPumpVal)
										  $sPumpVal = true;
									  
										$sMainType	 = $this->home_model->getDeviceMainType($i,$sDevice);
										
										$strChecked	=	'';
										if($iPumpVal > '1')
											$strChecked	=	'class="checked"';
										
										$strPumpName = 'Pump '.$i;
										if($sPumpNameDb != '' && $sPumpNameDb != 'Add Name')
											$strPumpName .= ' ('.$sPumpNameDb.')';
										
										if($sStatus2Speed == '')
											$sStatus2Speed = '0';
								?>	
										<div class="row">
										<div class="col-sm-12">
										<?php if($sPumpType == '2Speed') { ?>
										<script>
										var iActiveMode = '<?php echo $iActiveMode;?>';
										var sAccess 	= '<?php echo $sAccess;?>';
										</script>
										<link href="<?php echo site_url('assets/switchy/switchy.css'); ?>" rel="stylesheet" />
										<script type="text/javascript" src="<?php echo site_url('assets/switchy/switchy.js'); ?>"></script>
										<script type="text/javascript" src="<?php echo site_url('assets/switchy/jquery.event.drag.js'); ?>"></script>
										<script type="text/javascript" src="<?php echo site_url('assets/switchy/jquery.animate-color.js'); ?>"></script>
										<div class="span1 pump-<?php echo $i?>" value="1" style="margin-top: 10px; width: auto; color: #428BCA;font-weight: bold; cursor: pointer; float: left;">Relay 1</div>
										<div class="span2" style="margin-left:5px; margin-right:5px; float: left;" >
										<select id='switch-me-<?php echo $i;?>'>
										<option value='1' <?php if($sStatus2Speed == '1') { echo 'selected="selected"';} ?>>Spa</option>
										<option value='0' <?php if($sStatus2Speed == '0' || $iPumpVal == '') { echo 'selected="selected"';} ?>></option>
										<option value='2' <?php if($sStatus2Speed == '2') { echo 'selected="selected"';} ?>>Pool</option>
										</select>
										<div class="pump-<?php echo $i?>" value="0" id="off-<?php echo $i;?>" style="color: red;font-weight: bold;width: 0; margin-left: 30px; cursor: pointer;">
											OFF
				</div>                              </div>
										<div class="span1 pump-<?php echo $i?>" value="2" style="margin-top: 10px; width: auto; color: #428BCA;font-weight: bold; cursor: pointer; float: left;">Relay 2</div>
										<div style="margin-top:10px; float:right; color:#C9376E;"><strong><?php echo $strPumpName;?></strong></div>
									  <script type="text/javascript">
									  
									  $(function()
									  {
										  var bgColor = '#E8E8E8';
											<?php if($iPumpVal == '1' || $iPumpVal == '2') { ?>
													bgColor = '#45A31F';
											<?php } else { ?>
													bgColor = '#E8E8E8';
											<?php } ?>
											
											$('#switch-me-<?php echo $i;?>').switchy();
											
											$('.pump-<?php echo $i?>').on('click', function(event){
												//event.preventDefault();
												//return false;
												$('#switch-me-<?php echo $i;?>').val($(this).attr('value')).change();
											});
											
											$('#switch-me-<?php echo $i;?>').next('.switchy-container').find('.switchy-bar').animate({
													backgroundColor: bgColor
												});
											
											$('#switch-me-<?php echo $i;?>').on('change', function(event)
											{
												if(sAccess == 2)
												{
													if(iActiveMode != 2)
													{
														var bConfirm	=	confirm('You will need to change to Manual mode to make this change.\nWould you like to activate manual mode?' );
														if(bConfirm)
														{
															$.ajax({
																type: "POST",
																url: "<?php echo site_url('analog/changeMode');?>", 
																data: {iMode:'2'},
																success: function(data) {
																}
															});
															//event.preventDefault();
															//return false;
															// Animate Switchy Bar background color
															var bgColor = '#E8E8E8';

															if ($(this).val() == '1' || $(this).val() == '2')
															{
																bgColor = '#45A31F';
															} 
															$('#switch-me-<?php echo $i;?>').next('.switchy-container').find('.switchy-bar').animate({
																backgroundColor: bgColor
															});
														
															
															//$("#loading_valve_<?php //echo $i;?>").css('visibility','visible');
															$.ajax({
																type: "POST",
																url: "<?php echo site_url('home/updateStatusOnOff');?>", 
																data: {sName:'<?php echo $i;?>',sStatus:$(this).val(),sDevice:'<?php echo $sDevice;?>'},
																success: function(data) {
																//$("#loading_valve_<?php //echo $i;?>").css('visibility','hidden');
																location.reload();
																}

															});
														}
													}
													else											
													{
														//event.preventDefault();
														//return false;
														// Animate Switchy Bar background color
														var bgColor = '#E8E8E8';

														if ($(this).val() == '1' || $(this).val() == '2')
														{
															bgColor = '#45A31F';
														} 
														$('#switch-me-<?php echo $i;?>').next('.switchy-container').find('.switchy-bar').animate({
															backgroundColor: bgColor
														});
													
														
														//$("#loading_valve_<?php //echo $i;?>").css('visibility','visible');
														$.ajax({
															type: "POST",
															url: "<?php echo site_url('home/updateStatusOnOff');?>", 
															data: {sName:'<?php echo $i;?>',sStatus:$(this).val(),sDevice:'<?php echo $sDevice;?>'},
															success: function(data) {
															//$("#loading_valve_<?php //echo $i;?>").css('visibility','hidden');
															}

														});
													}
												}
											});
										});
								   </script>
								   
										<?php } else if($sPumpType != '') { ?>
										 <div class="rowCheckbox switch">
											<div class="custom-checkbox"><input type="checkbox" value="<?php echo $i;?>" id="pumps-<?php echo $i?>" name="pumps-<?php echo $i?>" class="pumpsButton" hidefocus="true" style="outline: medium none;">
												<label style="margin-left: 60px;" <?php echo $strChecked;?>  id="lablePump-<?php echo $i?>" for="pumps-<?php echo $i?>"><span style="color:#C9376E;float:right;" ><?php echo $strPumpName;?></span></label>
											</div>
										</div>
										
										<?php } else if($sPumpType == '') { ?>
										<span style="color:#E94180;"><strong>Pump <?php echo $i; ?> not configured.</strong></span>
										<?php } ?>
										</div>
										</div>
										<div style="height:20px;">&nbsp;</div>
									<?php } ?>
							<?php } ?>
						</div>
					</div>
					</div>
				</div>
				  
				<div class="col-sm-6">
						<!-- Statistics -->
						<div class="widget-container widget-stats boxed green-line">
							<div class="widget-title">
								<a href="<?php echo base_url('home/setting/'.$sDevice.'/');?>" class="link-refresh" id="link-refresh-1"><span class="glyphicon glyphicon-refresh"></span></a>
								<h3>PUMP Settings</h3>
							</div>
							<div class="stats-content clearfix">
								<div class="stats-content-right" style="width:100% !important; margin-left:5px; margin-right:5px; float:none;">
							
							  <table class="table table-hover">
								<thead>
								  <tr>
									<th class="header" style="width:25%">Pump</th>
									<th class="header"  style="width:25%">Type</th>
									<th class="header"  style="width:50%">Action</th>
								  </tr>
								</thead>
								<tbody>
								
								<?php
                    
								if( $iPumpsNumber == 0 || $iPumpsNumber == '' )
								{ ?>
									
									<tr>
										<td colspan="3">
											<span style="color:red">Please add number of Pumps in the <a href="<?php echo base_url('home/setting/');?>">Settings</a> Page!</span>
										</td>
									</tr>
									
								<?php 
								}
								else
								{
									$arrPump		=	array(0,1,2);
									$remainigCount	=	0;
									$chkPump		=	0;
									if(!empty($Pumps))
									{
										foreach($Pumps as $pump)
										{
											
										$i= $pump->pump_number;
										unset($arrPump[$i]);		
										//for ($i=0;$i < $pump_count; $i++)
										//{
										$iPumpVal = $sPump[$i];
										/* $iPumpNewValSb = 1;
										if($iPumpVal == 1)
										{
										  $iPumpNewValSb = 0;
										}
										$sPumpVal = false;
										if($iPumpVal)
										  $sPumpVal = true; */
										//$sRelayNameDb = get_device_name(1, $i);
									
										$sPumpNameDb =  $this->home_model->getDeviceName($i,$sDevice);
										if($sPumpNameDb == '')
										  $sPumpNameDb = 'Add Name';
										
										//$iPower	 = $this->home_model->getDevicePower($i,$sDevice);
										$sStatus2Speed	=	'';
										//$sPowercenter = '01000000'		;
										//START : Getting assigned relay status from the Server.	
										//Details of Pump
										$aPumpDetails = $this->home_model->getPumpDetails($i);
										$sPumpType		=	'';
										$sPumpSpeed		=	'';
										if(!empty($aPumpDetails))
										{
											foreach($aPumpDetails as $aResultEdit)
											{
												$sPumpType    = $aResultEdit->pump_type;//Pump Type
												$sPumpRelay   = $aResultEdit->relay_number;//Assigned Relay Number
												$sPumpRelay1   = $aResultEdit->relay_number_1;//Assigned Relay Number
												if($sPumpType == '12')
												{
													$iPumpVal = $sPowercenter[$sPumpRelay]; //Taken the status
												}
												else if($sPumpType == '24')
												{
													$iPumpVal = $sRelays[$sPumpRelay];//Taken the status
												}
												else if($sPumpType == '2Speed')
												{
													$sPumpSubType    = $aResultEdit->pump_sub_type;//Pump SUB Type
													$sStatus2Speed   = $aResultEdit->status;//Pump SUB Type
													
													
													if($sStatus2Speed == '0')
													{
														$iPumpVal        = $sStatus2Speed;
													}
													else if($sStatus2Speed == '1')											
													{
														if($sPumpSubType == '12')
														{
															$iPumpVal = $sPowercenter[$sPumpRelay]; //Taken the status
														}
														else if($sPumpSubType == '24')
														{
															$iPumpVal = $sRelays[$sPumpRelay];//Taken the status
														}
													}
													else if($sStatus2Speed == '2')											
													{
														if($sPumpSubType == '12')
														{
															$iPumpVal = $sPowercenter[$sPumpRelay1]; //Taken the status
														}
														else if($sPumpSubType == '24')
														{
															$iPumpVal = $sRelays[$sPumpRelay1];//Taken the status
														}
													}
												}
												else if(preg_match('/Emulator/',$sPumpType) || preg_match('/Intellicom/',$sPumpType))
												{
													 $iPumpVal 		= $sPump[$i];
													 $sPumpSpeed 	= $aResultEdit->pump_speed;	
												}
											}
										}	//END : Getting assigned relay status from the Server.
										$sPumpVal = false;
										if($iPumpVal)
										  $sPumpVal = true;
									  
										$strChecked	=	'';
										if($iPumpVal == '1')
											$strChecked	=	'class="checked"';
									  
										$sMainType	 = $this->home_model->getDeviceMainType($i,$sDevice);
										
										$strPumpName = 'Pump '.$i;
										if($sPumpNameDb != '' && $sPumpNameDb != 'Add Name')
											$strPumpName .= ' ('.$sPumpNameDb.')';
								?>
									<tr>
									<td>Pump <?php echo $i;?><br />(<a href="<?php if($sAccess == 2) { echo site_url('home/deviceName/'.base64_encode($i).'/'.base64_encode($sDevice).'/'); } else { echo 'javascript:void(0);';}?>" ><?php echo $sPumpNameDb;?></a>)<br /><br /><a href="javascript:void(0);" class="btn btn-red btn-small"><span><?php echo $sPumpType;?></span></a></td>
									<td>
										<div class="rowRadio"><div class="custom-radio"><input class="pumpRadio" type="radio" id="radio_other_<?php echo $i;?>" value="0" name="<?php echo $i;?>_MainType" <?php if($sMainType == '0' || $sMainType == ''){ echo 'checked="checked"';}?> <?php if($sAccess == '1') { echo 'disabled="disabled"';}?> hidefocus="true" style="outline: medium none;"><label id="relay_other_<?php echo $i;?>" for="radio_other_<?php echo $i;?>" class="<?php if($sMainType == '0' || $sMainType == ''){ echo 'checked';}?>">Other</label></div></div>
										<div class="rowRadio"><div class="custom-radio"><input class="pumpRadio" type="radio" id="radio_spa_<?php echo $i;?>" name="<?php echo $i;?>_MainType" value="1" <?php if($sMainType == '1'){ echo 'checked="checked"';}?> <?php if($sAccess == '1') { echo 'disabled="disabled"';}?> hidefocus="true" style="outline: medium none;"><label id="relay_spa_<?php echo $i;?>" for="radio_spa_<?php echo $i;?>" class="<?php if($sMainType == '1'){ echo 'checked';}?>">Spa</label></div></div>
										<div class="rowRadio"><div class="custom-radio"><input class="pumpRadio" type="radio" id="radio_pool_<?php echo $i;?>" name="<?php echo $i;?>_MainType" value="2" <?php if($sMainType == '2'){ echo 'checked="checked"';}?> <?php if($sAccess == '1') { echo 'disabled="disabled"';}?> hidefocus="true" style="outline: medium none;"><label id="relay_pool_<?php echo $i;?>" for="radio_pool_<?php echo $i;?>" class="<?php if($sMainType == '2'){ echo 'checked';}?>">Pool</label></div></div>
									</td>
									<td><a class="btn btn-green btn-small" href="<?php if($sAccess == 2){echo site_url('home/pumpConfigure/'.base64_encode($i).'/');}else{echo 'javscript:void(0);';}?>"><span>Configure</span></a>&nbsp;&nbsp;
										<a class="btn btn-red btn-small" href="<?php if($sAccess == 2){ echo site_url('home/setProgramsPump/'.base64_encode($i).'/');} else {echo 'javascript:void(0);';}?>"><span>Programs</span></a>
									<?php 
										if(preg_match('/Emulator/',$sPumpType) || preg_match('/Intellicom/',$sPumpType)) {
									?>									
									<div style="padding-top: 10px; padding-bottom: 10px;">
									Change Speed: <br />	
									<input type="radio" class="pumpSpeedSet" name="pageSpeed_<?php echo $i;?>" id="pageSpeed0" <?php if($sPumpSpeed == 0) {echo 'checked="checked";';}?> value="0">&nbsp;0&nbsp;&nbsp;
									<input type="radio" class="pumpSpeedSet" name="pageSpeed_<?php echo $i;?>" id="pageSpeed1" value="1" <?php if($sPumpSpeed == 1) {echo 'checked="checked";';}?>>&nbsp;1&nbsp;&nbsp;
									<input type="radio" class="pumpSpeedSet" name="pageSpeed_<?php echo $i;?>" id="pageSpeed2" value="2" <?php if($sPumpSpeed == 2) {echo 'checked="checked";';}?>>&nbsp;2&nbsp;&nbsp;
									<input type="radio" class="pumpSpeedSet" name="pageSpeed_<?php echo $i;?>" id="pageSpeed3" value="3" <?php if($sPumpSpeed == 3) {echo 'checked="checked";';}?>>&nbsp;3&nbsp;&nbsp;
									<input type="radio" class="pumpSpeedSet" name="pageSpeed_<?php echo $i;?>" id="pageSpeed4" value="4" <?php if($sPumpSpeed == 4) {echo 'checked="checked";';}?>>&nbsp;4&nbsp;&nbsp;
									</div>
										<?php } ?>
									<div style="padding-top: 10px; padding-bottom: 10px;">
									<a href="javascript:void(0);" onclick="removePump('<?php echo $i;?>')" class="btn btn-red btn-small"><span>Remove Pump</span>
									</a>&nbsp;&nbsp;<span id="loadingImgPumpRemove_<?php echo $i;?>" style="display:none;"><img src="<?php echo site_url('assets/images/loading.gif');?>" alt="Loading...." width="32" height="32"></span>
									</div>									
									</td>
									</tr>
									<?php 
											$chkPump++;
									} ?>
										
									<?php }
											
											$remainigCount	=	$iPumpsNumber - $chkPump;
											//for ($i=0;$i < $valve_count; $i++)	
											//for ($i=0;$i < $remainigCount ; $i++)
											foreach($arrPump as $i)	
											{
												if($remainigCount == 0)	
													break;
												
												$remainigCount--;
														
											//for ($i=0;$i < $pump_count; $i++)
											//{
												$iPumpVal = $sPump[$i];
												/* $iPumpNewValSb = 1;
												if($iPumpVal == 1)
												{
												  $iPumpNewValSb = 0;
												}
												$sPumpVal = false;
												if($iPumpVal)
												  $sPumpVal = true; */
												//$sRelayNameDb = get_device_name(1, $i);
											
												$sPumpNameDb =  $this->home_model->getDeviceName($i,$sDevice);
												if($sPumpNameDb == '')
												  $sPumpNameDb = 'Add Name';
												
												//$iPower	 = $this->home_model->getDevicePower($i,$sDevice);
												$sStatus2Speed	=	'';
												//$sPowercenter = '01000000'		;
												//START : Getting assigned relay status from the Server.	
												//Details of Pump
												$aPumpDetails = $this->home_model->getPumpDetails($i);
												$sPumpType		=	'';
												$sPumpSpeed 	= 	'';	
												
												if(!empty($aPumpDetails))
												{
													foreach($aPumpDetails as $aResultEdit)
													{
														$sPumpType    = $aResultEdit->pump_type;//Pump Type
														$sPumpRelay   = $aResultEdit->relay_number;//Assigned Relay Number
														$sPumpRelay1   = $aResultEdit->relay_number_1;//Assigned Relay Number
														if($sPumpType == '12')
														{
															$iPumpVal = $sPowercenter[$sPumpRelay]; //Taken the status
														}
														else if($sPumpType == '24')
														{
															$iPumpVal = $sRelays[$sPumpRelay];//Taken the status
														}
														else if($sPumpType == '2Speed')
														{
															$sPumpSubType    = $aResultEdit->pump_sub_type;//Pump SUB Type
															$sStatus2Speed   = $aResultEdit->status;//Pump SUB Type
															
															
															if($sStatus2Speed == '0')
															{
																$iPumpVal        = $sStatus2Speed;
															}
															else if($sStatus2Speed == '1')											
															{
																if($sPumpSubType == '12')
																{
																	$iPumpVal = $sPowercenter[$sPumpRelay]; //Taken the status
																}
																else if($sPumpSubType == '24')
																{
																	$iPumpVal = $sRelays[$sPumpRelay];//Taken the status
																}
															}
															else if($sStatus2Speed == '2')											
															{
																if($sPumpSubType == '12')
																{
																	$iPumpVal = $sPowercenter[$sPumpRelay1]; //Taken the status
																}
																else if($sPumpSubType == '24')
																{
																	$iPumpVal = $sRelays[$sPumpRelay1];//Taken the status
																}
															}
														}
														else if(preg_match('/Emulator/',$sPumpType) || preg_match('/Intellicom/',$sPumpType))
														{
															 $iPumpVal 		= $sPump[$i];
															 $sPumpSpeed 	= $aResultEdit->pump_speed;	
														}
													}
												}	//END : Getting assigned relay status from the Server.
												$sPumpVal = false;
												if($iPumpVal)
												  $sPumpVal = true;
											  
												$sMainType	 = $this->home_model->getDeviceMainType($i,$sDevice);
												
												$strChecked	=	'';
												if($iPumpVal == '1')
													$strChecked	=	'class="checked"';
												
												$strPumpName = 'Pump '.$i;
												if($sPumpNameDb != '')
													$strPumpName .= ' ('.$sPumpNameDb.')';
									?>	
									<tr>
									<td>Pump <?php echo $i;?><br />(<a href="<?php if($sAccess == 2) { echo site_url('home/deviceName/'.base64_encode($i).'/'.base64_encode($sDevice).'/'); } else { echo 'javascript:void(0);';}?>" ><?php echo $sPumpNameDb;?></a>)</td>
									<td>
										<div class="rowRadio"><div class="custom-radio"><input class="pumpRadio" type="radio" id="radio_other_<?php echo $i;?>" value="0" name="<?php echo $i;?>_MainType" <?php if($sMainType == '0' || $sMainType == ''){ echo 'checked="checked"';}?> <?php if($sAccess == '1') { echo 'disabled="disabled"';}?> hidefocus="true" style="outline: medium none;"><label id="relay_other_<?php echo $i;?>" for="radio_other_<?php echo $i;?>" class="<?php if($sMainType == '0' || $sMainType == ''){ echo 'checked';}?>">Other</label></div></div>
										<div class="rowRadio"><div class="custom-radio"><input class="pumpRadio" type="radio" id="radio_spa_<?php echo $i;?>" name="<?php echo $i;?>_MainType" value="1" <?php if($sMainType == '1'){ echo 'checked="checked"';}?> <?php if($sAccess == '1') { echo 'disabled="disabled"';}?> hidefocus="true" style="outline: medium none;"><label id="relay_spa_<?php echo $i;?>" for="radio_spa_<?php echo $i;?>" class="<?php if($sMainType == '1'){ echo 'checked';}?>">Spa</label></div></div>
										<div class="rowRadio"><div class="custom-radio"><input class="pumpRadio" type="radio" id="radio_pool_<?php echo $i;?>" name="<?php echo $i;?>_MainType" value="2" <?php if($sMainType == '2'){ echo 'checked="checked"';}?> <?php if($sAccess == '1') { echo 'disabled="disabled"';}?> hidefocus="true" style="outline: medium none;"><label id="relay_pool_<?php echo $i;?>" for="radio_pool_<?php echo $i;?>" class="<?php if($sMainType == '2'){ echo 'checked';}?>">Pool</label></div></div>
									</td>
									<td><a class="btn btn-green btn-small" href="<?php if($sAccess == 2){echo site_url('home/pumpConfigure/'.base64_encode($i).'/');}else{echo 'javscript:void(0);';}?>"><span>Configure</span></a>&nbsp;&nbsp;
										<a class="btn btn-red btn-small" href="<?php if($sAccess == 2){ echo site_url('home/setProgramsPump/'.base64_encode($i).'/');} else {echo 'javascript:void(0);';}?>"><span>Programs</span></a>
										<?php 
										if(preg_match('/Emulator/',$sPumpType) || preg_match('/Intellicom/',$sPumpType)) {
									?>									
									<div style="padding-top: 10px; padding-bottom: 10px;">
									Change Speed: <br />	
									<input type="radio" class="pumpSpeedSet" name="pageSpeed_<?php echo $i;?>" id="pageSpeed0" <?php if($sPumpSpeed == 0) {echo 'checked="checked";';}?> value="0">&nbsp;0&nbsp;&nbsp;
									<input type="radio" class="pumpSpeedSet" name="pageSpeed_<?php echo $i;?>" id="pageSpeed1" value="1" <?php if($sPumpSpeed == 1) {echo 'checked="checked";';}?>>&nbsp;1&nbsp;&nbsp;
									<input type="radio" class="pumpSpeedSet" name="pageSpeed_<?php echo $i;?>" id="pageSpeed2" value="2" <?php if($sPumpSpeed == 2) {echo 'checked="checked";';}?>>&nbsp;2&nbsp;&nbsp;
									<input type="radio" class="pumpSpeedSet" name="pageSpeed_<?php echo $i;?>" id="pageSpeed3" value="3" <?php if($sPumpSpeed == 3) {echo 'checked="checked";';}?>>&nbsp;3&nbsp;&nbsp;
									<input type="radio" class="pumpSpeedSet" name="pageSpeed_<?php echo $i;?>" id="pageSpeed4" value="4" <?php if($sPumpSpeed == 4) {echo 'checked="checked";';}?>>&nbsp;4&nbsp;&nbsp;
									</div>
										<?php } ?>	
									<div style="padding-top: 10px; padding-bottom: 10px;">
									<a href="javascript:void(0);" onclick="removePump('<?php echo $i;?>')" class="btn btn-red btn-small"><span>Remove Pump</span>
									</a>&nbsp;&nbsp;<span id="loadingImgPumpRemove_<?php echo $i;?>" style="display:none;"><img src="<?php echo site_url('assets/images/loading.gif');?>" alt="Loading...." width="32" height="32"></span>
									</div>			
									</td>
									</tr>
											<?php } ?>
									<?php } ?>		
								</tbody>
								</table>
								</div>
							</div>
						</div>
						<!--/ Statistics -->
					</div>
			</div><!-- /.row -->
	<?php } ?>
<?php } ?>	
<!-- END : PUMPS -->

<!-- START : Temperature Sensors -->

<?php if($sDevice == 'T') { ?>
	<?php if($sAccess == 1 || $sAccess == 2) 
		  { 
	?>
			<div class="row">
				<div class="col-sm-12">
					<!-- widget Tags-->
					<div class="widget-container widget-stats boxed green-line">
					<div class="widget-title">
						<a href="<?php echo base_url('home/setting/'.$sDevice.'/');?>" class="link-refresh" id="link-refresh-1"><span class="glyphicon glyphicon-refresh"></span></a>
						<h3>Temperature Sensor</h3>
					</div>
					<div class="stats-content clearfix">
					<div class="stats-content-right" style="width:100% !important; margin-left:5px; margin-right:5px; float:none;">
					
					 <table class="table table-hover">
						<thead>
						  <tr style="font-weight:bold;">
							<th class="header" style="width:25%">Temperature sensor</th>
							<th class="header"  style="width:25%">Temperature</th>
							<th class="header"  style="width:25%">Action</th>
							<th class="header"  style="width:25%">&nbsp;</th>
						  </tr>
						</thead>
						<tbody>
						<?php
                    
							//START : Temperature sensor
							for ($i=0;$i < $temprature_count; $i++)
							{
								$iTempratureVal = $sTemprature[$i];
								
								$sTempratureNameDb =  $this->home_model->getDeviceName($i,$sDevice);
								if($sTempratureNameDb == '')
								  $sTempratureNameDb = 'Add Name';
							  
								if($iTempratureVal == '')
									$iTempratureVal = '-';
								
								$strBusNumber	 =	'';
								$strGetBusNumber = "SELECT light_relay_number FROM rlb_device WHERE device_type = 'T' AND device_number='".$i."'";
								
								$query  =   $this->db->query($strGetBusNumber);
								
								if($query->num_rows() > 0)
								{
									foreach($query->result() as $rowResult)
									{
										$strBusNumber	=	$rowResult->light_relay_number;
									}
								}
						?>
							  <tr>
								<td>Temperature sensor <?php echo $i;?></td>
								<td><?php echo $iTempratureVal;?></td>
								<td><a href="<?php if($sAccess == 2){ echo site_url('home/deviceName/'.base64_encode($i).'/'.base64_encode($sDevice).'/');} else { echo 'javascript:void(0);';}?>" ><?php echo $sTempratureNameDb;?></a></td>
								<td><a class="btn btn-small btn-red" href="<?php echo base_url('analog/tempConfig/'.base64_encode($i));?>"><span>Configure</span>	</a><?php if($i != 0 && $strBusNumber != '') { ?>&nbsp;&nbsp;<a class="btn btn-small btn-red" href="<?php echo base_url('analog/tempConfig/'.base64_encode($i).'/remove/');?>"><span>Remove Sensor</span>	</a><?php } ?></td>
							  </tr>
						<?php } ?>
						</tbody>
					</table>
					</div>
					</div>
						
					<!-- widget Tags-->
				</div>
			</div>	
	</div>
	<?php } ?>
<?php } ?>		
<!-- END : Temperature Sensors -->