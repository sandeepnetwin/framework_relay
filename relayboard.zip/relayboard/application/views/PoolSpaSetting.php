<?php


$sAccess 		 = '';
$sModule	    = 2;

//Get Permission Details
$userID = $this->session->userdata('id');
$aPermissions = json_decode(getPermissionOfModule($userID));

$aModules 		= $aPermissions->sPermissionModule;	
$aAllActiveModule = $aPermissions->sActiveModule;

$sAccessKey	= 'access_'.$sModule;

if(!empty($aModules))
{
  if(in_array($sModule,$aModules->ids))
  {
	 $sAccess 		= $aModules->$sAccessKey;
  }
  else if(!in_array($sModule,$aModules->ids)) 
  {
	$sAccess 		= '0'; 
  }
}

if($sAccess == '')
$sAccess = '2' ;

$arrGeneral = '';
$arrDevice 	= '';
$arrHeater 	= '';
$arrMore	= '';

if(!empty($arrDetails))
{
	if(isset($arrDetails['General']))
		$arrGeneral = unserialize($arrDetails['General']);
	if(isset($arrDetails['Device']))
		$arrDevice = unserialize($arrDetails['Device']);
	if(isset($arrDetails['Heater']))
		$arrHeater = unserialize($arrDetails['Heater']);
	if(isset($arrDetails['More']))
		$arrMore = unserialize($arrDetails['More']);
}

$iValveCnt = count($ValveRelays);
$iPumpCnt  = count($Pumps);
$iLightCnt = $extra['LightNumber'];

$iRelayCnt = count($sRelays);
$iPowerCnt = count($sPowercenter);

/*
	[PumpsNumber] => 2
	[ValveNumber] => 2
	[Remote_Spa] => 1
	[LightNumber] => 4
	[HeaterNumber] => 3
	[BlowerNumber] => 4
*/

?>
<style>
.requiredMark
{
	color: #ff0000;
}



.questionText
{
	line-height:15px;
}
.trClass
{
	vertical-align:top !important;
}
.inputText
{
	height:35px !important;
}
.wizard > .content
{
	padding:0px !important;
	overflow-y: scroll;
}

.wizard > .content > .body
{
	height : 100% !important;
}
.changeLink
{
	color: blue; text-decoration: underline; font-size: 10px; cursor:pointer;	
}
.relayText
{
	color: rgb(255, 0, 0); font-size: 10px;
}
.confHeader
{
	color: #4fc4fe;
    font-style: italic;
    font-weight: 400;
    margin: 0;
}

.removeBorder > tbody > tr > td
{
	border-top:0 none !important;
}


</style>
<link rel="stylesheet" href="<?php echo HTTP_ASSETS_PATH.'steps/css/jquery.steps.css';?>">

<script src="<?php echo HTTP_ASSETS_PATH.'steps/lib/modernizr-2.6.2.min.js';?>"></script>
<script src="<?php echo HTTP_ASSETS_PATH.'steps/lib/jquery.cookie-1.3.1.js';?>"></script>
<script src="<?php echo HTTP_ASSETS_PATH.'steps/build/jquery.steps.js';?>"></script>
<script src="<?php echo HTTP_ASSETS_PATH.'steps/main.js';?>"></script>

<script type="text/javascript" src="<?php echo HTTP_ASSETS_PATH.'fancybox/source/jquery.fancybox.js?v=2.1.5';?>"></script>
<link rel="stylesheet" type="text/css" href="<?php echo HTTP_ASSETS_PATH.'fancybox/source/jquery.fancybox.css?v=2.1.5';?>" media="screen" />

<script type="text/javascript">
	$(function ()
	{
		$('.fancybox').fancybox({
			autoSize : false,
			width:	'600',
			height: 'auto',
		});
		$('.fancyboxPump').fancybox({
			autoSize : false,
			height: 'auto',
		});
		
		$('#wizard-t-3').click();
		
	});
	
	function showReason(val)
	{
		if( val == 0 )
		{
			$("#reasonValveBlk").show();
			$("#reasonValvelbl").show();
			$("#reasonValve").show();
			$("#reasonValve").addClass('required');
		}
		else
		{
			$("#reasonValveBlk").hide();
			$("#reasonValve").hide();
			$("#reasonValvelbl").hide();
			$("#reasonValve").removeClass('required');
		}
	}
	
	function valveChange()
	{
		var valveNumber	=	$('#strValve').val();
		
		for (i = 0; i <= valveNumber; i++) 
		{
			if(i == 0)
			{
				$("#valve_actuated").html('<option value="">Select Valve Quantity</option><option value="'+i+'">Valve '+i+' is actuated</option>');
				$(".valveShow").hide();
			}
			else
			{
				$("#valve_actuated").append('<option value="'+i+'">Valve '+i+' is actuated</option>');
				$("#valveShow"+i).show();
			}
		}
	}
	
	function pumpChange()
	{
		var pumpNumber	=	$('#automatic_pumps').val();
		
		for (i = 1; i <= pumpNumber; i++) 
		{
			$("#trPump"+i).show();
			$("#trPumpShow"+i).show();
		}
		
		for (i = (parseInt(pumpNumber)+1); i <= 3; i++) 
		{
			$("#trPump"+i).hide();
			$("#trPumpShow"+i).hide();
		}
		//if(pumpNumber == 1 || pumpNumber == 2)
			//$(".content").css('height','auto');
		//if(pumpNumber == 3)
			//$(".content").css('height','530px');
	}
	
	function showHeater()
	{
		var heaterNumber	=	$('#automatic_heaters_question1').val();
		
		for (i = 1; i <= heaterNumber; i++) 
		{
			$("#trHeater"+i).show();
			$("#trHeaterWork"+i).show();
			$("#trHeaterPump"+i).show();
		}		
		
		for (i = (parseInt(heaterNumber)+1); i <= 3; i++) 
		{
			$("#trHeater"+i).hide();
			$("#trHeaterWork"+i).hide();
			$("#trHeaterPump"+i).hide();
			
			$('[id^="trHeaterSub'+i+'_"]').hide();
		}
		
		for (i = 1; i <= heaterNumber; i++) 
		{
			for(j = 1; j <= heaterNumber; j++)
			{
				if(j == 1)
					$("#HeaterPump"+i).html('<option value="'+j+'">Pump '+j+'</option>');
				else 
					$("#HeaterPump"+i).append('<option value="'+j+'">Pump '+j+'</option>');	
			}
		}
	}
	
	function checkType(type)
	{
		if(type == '')
		{
			$("#pool_maximum_temperature").attr('readonly','readonly');
			$("#pool_temperature").attr('readonly','readonly');
			$("#pool_manual").attr('readonly','readonly');
			$("#display_pool_temp").attr('disabled','disabled');
			$("#display_spa_temp").attr('disabled','disabled');
			$("#spa_maximum_temperature").attr('readonly','readonly');
			$("#spa_temperature").attr('readonly','readonly');
			$("#spa_manual").attr('readonly','readonly');
		}
		else if(type == 'spa')
		{
			$("#spa_maximum_temperature").removeAttr('readonly').addClass('required');
			$("#spa_temperature").removeAttr('readonly').addClass('required');
			$("#spa_manual").removeAttr('readonly').addClass('required');
			$("#display_spa_temp").removeAttr('disabled').addClass('required');
			
			$("#pool_maximum_temperature").attr('readonly','readonly').removeClass('required');
			$("#pool_temperature").attr('readonly','readonly').removeClass('required');
			$("#pool_manual").attr('readonly','readonly').removeClass('required');
			$("#display_pool_temp").attr('disabled','disabled').removeClass('required');
		}
		else if(type == 'pool')
		{
			$("#pool_maximum_temperature").removeAttr('readonly').addClass('required');
			$("#pool_temperature").removeAttr('readonly').addClass('required');
			$("#pool_manual").removeAttr('readonly').addClass('required');
			$("#display_pool_temp").removeAttr('disabled').addClass('required');
			
			$("#spa_maximum_temperature").attr('readonly','readonly').removeClass('required');
			$("#spa_temperature").attr('readonly','readonly').removeClass('required');
			$("#spa_manual").attr('readonly','readonly').removeClass('required');
			$("#display_spa_temp").attr('disabled','disabled').removeClass('required');
		}
		else if(type == 'both')
		{
			$("#pool_maximum_temperature").removeAttr('readonly').addClass('required');
			$("#pool_temperature").removeAttr('readonly').addClass('required');
			$("#pool_manual").removeAttr('readonly').addClass('required');
			$("#display_pool_temp").removeAttr('disabled').addClass('required');
			$("#spa_maximum_temperature").removeAttr('readonly').addClass('required');
			$("#spa_temperature").removeAttr('readonly').addClass('required');
			$("#spa_manual").removeAttr('readonly').addClass('required');
			$("#display_spa_temp").removeAttr('disabled').addClass('required');
		}
		
	}
	
	function showRelays(val,cnt)
	{
		if(val == '')
			$('[id^="trHeaterSub'+cnt+'_"]').hide();
		else
		{
			$('[id^="trHeaterSub'+cnt+'_"]').hide();
			$('#trHeaterSub'+cnt+'_'+val).show();
		}
	}
	
	function showRelaysLight(val,cnt)
	{
		if(val == '')
			$('[id^="trLightSub'+cnt+'_"]').hide();
		else
		{
			$('[id^="trLightSub'+cnt+'_"]').hide();
			$('#trLightSub'+cnt+'_'+val).show();
		}
	}
	
	function showRelaysBlower(val,cnt)
	{
		if(val == '')
			$('[id^="trBlowerSub'+cnt+'_"]').hide();
		else
		{
			$('[id^="trBlowerSub'+cnt+'_"]').hide();
			$('#trBlowerSub'+cnt+'_'+val).show();
		}
	}
	
	function showValveDetails()
	{
		var valveNumber	=	$("#valveNumber").val();
		
		if(isNaN(valveNumber))
		{
			$("#valveNumber").css('border','1px solid #FF0000');
			alert("Please enter valid valve numbers!");
			return false;
		}
		else if(valveNumber > 8)
		{
			$("#valveNumber").css('border','1px solid #FF0000');
			alert("Please enter valve numbers less than or equal to 8!");
			return false;
		}
		else
		{
			$("#valveNumber").css('border','');
		}
		
		$("#valveTable").find("tr:gt(0)").remove();
		for(j = 0; j < valveNumber; j++)
		{
			$("#valveTable").append('<tr><td><strong>Valve '+j+'</strong>&nbsp;<span class="relayText">(Enter relays in sequence)</span></td><td>&nbsp;</td><td><input type="text" style="width:100px;" class=" inputText" id="sRelay'+j+'_1">&nbsp;&nbsp;<input type="text" style="width:100px;" class=" inputText" id="sRelay'+j+'_2">&nbsp;<a class="changeLink" href="javascript:void(0);" onclick="removeRow(\'valveTable\')">Remove</a><div style="height: 5px;"> </div><select class="form-control" style="width:100px !important; display:inline;" name="valveDirection_'+j+'_1"><option value="">Select Directions</option><option value="0">Other</option><option value="1">Spa</option><option value="2">Pool</option></select>&nbsp;&nbsp;<select class="form-control" style="width:100px !important; display:inline;" name="valveDirection_'+j+'_2"><option value="">Select Directions</option><option value="0">Other</option><option value="1">Spa</option><option value="2">Pool</option></select></td></tr>');
		}
		
		var rowCount = $('#valveTable tr').length;
		
		if(rowCount > 1)
		{
			$("#valveTable").append('<tr><td colspan="3"><a href="javascript:void(0);" onclick="checkAndSaveRelays();" class="btn btn-middle"><span>Save</span></a>&nbsp;&nbsp;<span id="loadingImg" style="display:none; vertical-align: middle;"><img src="<?php echo site_url('assets/images/loading.gif');?>" alt="Loading...." width="32" height="32"></span></td></tr>');
		}
	}
	
	function removeRow(table)
	{
		$("#"+table).find("tr:gt(0)").remove();
		
		$("#valveNumber").val($("#valveNumber").val() - 1);
		
		var valveNumber = $("#valveNumber").val();
		
		for(j = 0; j < valveNumber; j++)
		{
			$("#"+table).append('<tr><td><strong>Valve '+j+'</strong>&nbsp;<span class="relayText">(Enter relays in sequence)</span></td><td>&nbsp;</td><td><input type="text" style="width:100px;" class=" inputText" id="sRelay'+j+'_1">&nbsp;&nbsp;<input type="text" style="width:100px;" class=" inputText" id="sRelay'+j+'_2">&nbsp;<a class="changeLink" href="javascript:void(0);" onclick="removeRow(\'valveTable\')">Remove</a><div style="height: 5px;"> </div><select class="form-control" style="width:100px !important; display:inline;" name="valveDirection_'+j+'_1"><option value="pool">Pool</option><option value="spa">Spa</option></select>&nbsp;&nbsp;<select class="form-control" style="width:100px !important; display:inline;" name="valveDirection_'+j+'_2"><option value="pool">Pool</option><option value="spa">Spa</option></select></td></tr>');
		}
		
		var rowCount = $('#'+table+' tr').length;
		
		if(rowCount > 1)
		{
			$("#"+table).append('<tr><td colspan="3"><a href="javascript:void(0);" class="btn btn-middle"><span>Save</span></a>&nbsp;&nbsp;<span id="loadingImg" style="display:none; vertical-align: middle;"><img src="<?php echo site_url('assets/images/loading.gif');?>" alt="Loading...." width="32" height="32"></span></td></tr>');
		}
	}
	
	function checkAndSaveRelays()
	{
		$("#loadingImg").show();
		var rowCount 		=	$('#valveTable').find("tr:gt(0)").length;
		var arrRelayStart 	=	['0','2','4','6','8','10','12','14'];
		var arrRelayEnd   	=	['1','3','5','7','9','11','13','15'];
		
		var arrValve	= Array();
		
		for(i = 0; i < (rowCount-1); i++)
		{
			var relay1 = $("#sRelay"+i+"_1").val();
			var relay2 = $("#sRelay"+i+"_2").val();
			var relay1Position = arrRelayStart.indexOf(relay1);
			var relay2Position = arrRelayEnd.indexOf(relay2);
			if(relay1Position != -1){
				$("#sRelay"+i+"_1").css('border','');
				arrValve[i]	= Array();
				arrValve[i].push(relay1);
			}
			else
			{
				$("#sRelay"+i+"_1").css('border','1px solid red');
				alert("Please select valid relay number for relay 1 for valve "+i);
				return false;
			}
			
			if(relay2Position != -1){
				$("#sRelay"+i+"_2").css('border','');
				
			}
			else
			{
				$("#sRelay"+i+"_2").css('border','1px solid red');
				alert("Please select valid relay number for relay for valve "+i);
				return false;
			}
				
			if(arrRelayEnd[relay1Position] != relay2)
			{
				$("#sRelay"+i+"_2").css('border','1px solid red');
				alert("Relay Number must be in sequence!");
				return false;
			}
			else
			{	
				$("#sRelay"+i+"_2").css('border','');
				arrValve[i].push(relay2);
			}
			
			//arrValve[i].push($("valveDirection_"+i+"_1"));
			//arrValve[i].push($("valveDirection_"+i+"_2"));
		}
		
		$.ajax({
		type: "POST",
		url: "<?php echo site_url('home/saveValveRelayConf/');?>", 
		data: {valve:JSON.stringify(arrValve),sDevice:'V'},
		success: function(data) {
				var response	=	$.parseJSON(data);
				
				var numValve	=	response.length;
				//$("#strValveNum").val(numValve);
				
				$('#strValve').find('option:gt(1)').remove();
				$('#valve_actuated').find('option:gt(1)').remove();
				
				for(i = 1; i <= numValve; i++ )
				{
					$('#valve_assign'+i).find('option:gt(0)').remove();
					
					$("#strValve").append('<option value="'+i+'">'+i+' Valve</option>');
					$("#valve_actuated").append('<option value="'+i+'">Valve '+i+' is actuated</option>');
					
					$.each(response, function(key,valueObj){
						$("#valve_assign"+i).append('<option value="'+valueObj.device_number+'">Valve '+valueObj.device_number+'</option>')
					});
					$("#valveShow"+i).show(); 
				}
				
				for($i=(numValve+1); i <= 8; i++)
				{
					$("#valveShow"+i).hide(); 
				}
				$("#loadingImg").hide();
				alert("Valves configured Successfully!");
				parent.$.fancybox.close();
			}
		});
		
	}
	
	function showPumpDetails()
	{
		var pumpNumber	=	$("#pumpNumber").val();
		
		if(isNaN(pumpNumber))
		{
			$("#pumpNumber").css('border','1px solid #FF0000');
			alert("Please enter valid pump numbers!");
			return false;
		}
		else if(pumpNumber > 3)
		{
			$("#pumpNumber").css('border','1px solid #FF0000');
			alert("Please enter pump numbers less than or equal to 3!");
			return false;
		}
		else
		{
			$("#pumpNumber").css('border','');
		}
		
		//$("#pumpTable").find("tbody > tr:gt(0)").hide();
		$('#pumpTable > tbody > tr:gt(0)').hide();
		
		for(j = 0; j < pumpNumber; j++)
		{
			//alert("#trPumpDetails"+j);
			$("#trPumpDetails"+j).show();
		}
		
		var rowCount = $('#pumpTable > tbody > tr').length;
		
		if(pumpNumber > 0)
		{
			$("#pumpSaveConf").show();
		}
		else
			$("#pumpSaveConf").hide();
	}
	
	function showHeaterDetails()
	{
		var heaterNumber	=	$("#heaterNumber").val();
		
		if(isNaN(heaterNumber))
		{
			$("#heaterNumber").css('border','1px solid #FF0000');
			alert("Please enter valid Heater numbers!");
			return false;
		}
		else if(heaterNumber > 3)
		{
			$("#heaterNumber").css('border','1px solid #FF0000');
			alert("Please enter Heater numbers less than or equal to 3!");
			return false;
		}
		else
		{
			$("#heaterNumber").css('border','');
		}
		
		//$("#pumpTable").find("tbody > tr:gt(0)").hide();
		$('#heaterTable > tbody > tr:gt(0)').hide();
		
		for(j = 1; j <= heaterNumber; j++)
		{
			//alert("#trPumpDetails"+j);
			$("#heaterDetails_"+j).show();
		}
		
		var rowCount = $('#heaterTable > tbody > tr').length;
		
		if(heaterNumber > 0)
		{
			$("#heaterSaveConf").show();
		}
		else
			$("#heaterSaveConf").hide();
	}
	
	function showLightDetails()
	{
		var lightNumber	=	$("#lightNumber").val();
		
		if(isNaN(lightNumber))
		{
			$("#lightNumber").css('border','1px solid #FF0000');
			alert("Please enter valid Light numbers!");
			return false;
		}
		else
		{
			$("#lightNumber").css('border','');
		}
		
		//$("#pumpTable").find("tbody > tr:gt(0)").hide();
		$('#lightTable > tbody > tr:gt(0)').hide();
		
		for(j = 1; j <= lightNumber; j++)
		{
			//alert("#trPumpDetails"+j);
			$("#lightDetails_"+j).show();
		}
		
		var rowCount = $('#lightTable > tbody > tr').length;
		
		if(lightNumber > 0)
		{
			$("#lightSaveConf").show();
		}
		else
			$("#lightSaveConf").hide();
	}
	
	function showBlowerDetails()
	{
		var blowerNumber	=	$("#blowerNumber").val();
		
		if(isNaN(blowerNumber))
		{
			$("#blowerNumber").css('border','1px solid #FF0000');
			alert("Please enter valid Blower numbers!");
			return false;
		}
		else
		{
			$("#blowerNumber").css('border','');
		}
		
		//$("#pumpTable").find("tbody > tr:gt(0)").hide();
		$('#blowerTable > tbody > tr:gt(0)').hide();
		
		for(j = 1; j <= blowerNumber; j++)
		{
			//alert("#trPumpDetails"+j);
			$("#blowerDetails_"+j).show();
		}
		
		var rowCount = $('#blowerTable > tbody > tr').length;
		
		if(blowerNumber > 0)
		{
			$("#blowerSaveConf").show();
		}
		else
			$("#blowerSaveConf").hide();
	}
	
	
	
	function checkAndSavePumps()
	{
		
		var pumpNumber	=	$("#pumpNumber").val();
		
		if(isNaN(pumpNumber))
		{
			$("#pumpNumber").css('border','1px solid #FF0000');
			alert("Please enter valid pump numbers!");
			return false;
		}
		else if(pumpNumber > 3)
		{
			$("#pumpNumber").css('border','1px solid #FF0000');
			alert("Please enter pump numbers less than or equal to 3!");
			return false;
		}
		else
		{
			$("#pumpNumber").css('border','');
		}
		$("#loadingImgPump").show();
		var arrPumpSaveDetails	=	{};
		var errMsg				=	"";
		for(j = 0; j < pumpNumber; j++)
		{
			var pumpNumberConf	=	$("#sPumpNumber_"+j).val();
			var pumpClosure		=	$("[name='sPumpClosure_"+j+"']:checked").val();
			var pumpType		=	$("#sPumpType_"+j).val();
			
			var relayNumber1	=	'';
			var relayNumber2	=	'';
			var pumpAddress		=	'';
			var pumpSpeed		=	'';
			var pumpFlow		=	'';
			var pumpSubType		=	'';
			var pumpSubType1	=	'';
			var pumpSpeedIn		=	'';
			
			if (pumpType.indexOf("12") >= 0 || pumpType.indexOf("24") >= 0 || pumpType == '2Speed')
				relayNumber1	=	$("#sRelayNumber_"+j).val();
			
			if(pumpType == '2Speed')
			{
				pumpSubType1	=	$("#sPumpSubType1_"+j).val();
				relayNumber2	=	$("#sRelayNumber1_"+j).val();
			}
			
			if(pumpType.indexOf("Intellicom") >= 0 || pumpType.indexOf("Emulator") >= 0)
			{
				pumpSubType		=	$("#sPumpSubType_"+j).val();
				pumpAddress		=	$("#sPumpAddress_"+j).val();
			}
			
			if(pumpSubType != '')
			{
				if(pumpSubType == 'VS')
				{
					if(pumpType.indexOf("Intellicom") >= 0)
						pumpSpeedIn	=	$("[name='sPumpSpeedIn_"+j+"']:checked").val();
					else
						pumpSpeed	=	$("[name='sPumpSpeed_"+j+"']:checked").val();
				}
				if(pumpSubType == 'VF')
					pumpFlow	=	$("#sPumpFlow_"+j).val();
			}
			
			if(typeof(pumpClosure)  === "undefined")
			{
				errMsg	+=	"- Please select Closure for Pump "+pumpNumberConf+"!\n";
			}
			if ((pumpType.indexOf("12") >= 0 || pumpType.indexOf("24") >= 0 || pumpType == '2Speed') && relayNumber1 == '')
			{
				errMsg	+=	"- Please enter Relay Number for Pump "+pumpNumberConf+"!\n";
			}
			if(pumpType == '2Speed' && relayNumber2 == '')
			{
				errMsg	+=	"- Please enter Relay Number2 for Pump "+pumpNumberConf+"!\n";
			}
			if((pumpType.indexOf("Intellicom") >= 0 || pumpType.indexOf("Emulator") >= 0) && pumpAddress == '')
			{
				if(pumpSubType == 'VS' && typeof(pumpSpeed)  === "undefined")
					errMsg	+=	"- Please select speed for Pump "+pumpNumberConf+"!\n";
				if(pumpSubType == 'VF' && pumpFlow == '')
					errMsg	+=	"- Please enter flow for Pump "+pumpNumberConf+"!\n";
				
				errMsg	+=	"- Please enter Address for Pump "+pumpNumberConf+"!\n";
			}
			
			arrPumpSaveDetails[pumpNumberConf]		=	[];
			arrPumpSaveDetails[pumpNumberConf] 		=	{'closure': pumpClosure, 'type' : pumpType, 'relayNumber1':relayNumber1,'relayNumber2':relayNumber2,'pumpAddress':pumpAddress,'pumpSubType':pumpSubType,'pumpSpeed':pumpSpeed,'pumpFlow':pumpFlow,'pumpSubType1':pumpSubType1,'pumpSpeedIn':pumpSpeedIn};

		}
		//console.log(JSON.stringify(arrPumpSaveDetails));
		if(errMsg != '')
		{
			alert("Following are the errors : \n\n"+errMsg);
			$("#loadingImgPump").hide();
			return false;
		}
		//console.log(arrPumpSaveDetails);
		
		$.ajax({
		type: "POST",
		url: "<?php echo site_url('home/savePumpRelayConf/');?>", 
		data: {pump:JSON.stringify(arrPumpSaveDetails),sDevice:'P'},
		success: function(data) {
				alert(data);
				if(data.indexOf("successfully") >= 0)
				{
					for (var i = 1; i <= pumpNumber; i++) 
					{
						if(i == 1)
						{
							$("#automatic_pumps").html('<option value="'+(i - 1)+'">'+(i - 1)+' Pump</option><option value="'+i+'">'+i+' Pump</option>');
							$("#PumpAssign"+i).html('<option value="">--Select Pump--</option><option value="'+(i-1)+'">Pump '+(i-1)+'</option>');
							
						}
						else
						{
							$("#automatic_pumps").append('<option value="'+i+'" selected="selected">'+i+' Pump</option>');
							$("#PumpAssign"+i).append('<option value="'+(i-1)+'">Pump '+(i-1)+'</option>');
						}
						
						$("#trPump"+i).show();
						$("#trPumpShow"+i).show();
					}
					
					for (i = (parseInt(pumpNumber)+1); i <= 3; i++) 
					{
						$("#trPump"+i).hide();
						$("#trPumpShow"+i).hide();
					}
				}
				$("#loadingImgPump").hide();
				parent.$.fancybox.close();
		}
		});
		
	}
	
	function checkAndSaveHeater()
	{
		var heaterNumber	=	$("#heaterNumber").val();
		
		if(isNaN(heaterNumber))
		{
			$("#heaterNumber").css('border','1px solid #FF0000');
			alert("Please enter valid heater numbers!");
			return false;
		}
		else if(heaterNumber > 3)
		{
			$("#heaterNumber").css('border','1px solid #FF0000');
			alert("Please enter heater numbers less than or equal to 3!");
			return false;
		}
		else
		{
			$("#heaterNumber").css('border','');
		}
		
		$("#loadingImgHeater").show();
		
		var arrHeaterSaveDetails	=	{};
		var errMsg					=	"";
		for(j = 1; j <= heaterNumber; j++)
		{
			var relayType 	=	$("#heater"+j+"_equiment").val();
			var relayNumber =	$("#heater"+j+"_sub_equiment_"+relayType).val();
			
			if(relayNumber == '')
			{
				errMsg	+=	"- Please select Relay Number for Heater "+j+"!\n";
			}
			
			arrHeaterSaveDetails[j]		=	[];
			arrHeaterSaveDetails[j] 	=	{'relayType': relayType, 'relayNumber' : relayNumber} 
		}
		
		if(errMsg != '')
		{
			alert("Following are the errors : \n\n"+errMsg);
			$("#loadingImgHeater").hide();
			return false;
		}
		
		//Check if entered address already exists.
		$.ajax({
		type: "POST",
		url: "<?php echo site_url('home/saveHeaterRelayConf/');?>", 
		data: {heater:JSON.stringify(arrHeaterSaveDetails),sDevice:'H'},
		success: function(data) {
					alert(data);
					if(data.indexOf("successfully") >= 0)
					{
						for (var i = 1; i <= heaterNumber; i++) 
						{
							if(i == 1)
							{
								$("#automatic_heaters_question1").html('<option value="'+(i - 1)+'">'+(i - 1)+' Heater</option><option value="'+i+'">'+i+' Heater</option>');
							}
							else
							{
								$("#automatic_heaters_question1").append('<option value="'+i+'">'+i+' Heater</option>');
							}
							
							$("#trHeater"+i).show();
							$("#trHeaterWork"+i).show();
							$("#trHeaterPump"+i).show();
						}
						for (i = (parseInt(heaterNumber)+1); i <= 3; i++) 
						{
							$("#trHeater"+i).hide();
							$("#trHeaterWork"+i).hide();
							$("#trHeaterPump"+i).hide();
							
							$('[id^="trHeaterSub'+i+'_"]').hide();
						}
						
						var pumpNumber	=	$("#pumpNumber").val();
						
						for (i = 1; i <= pumpNumber; i++) 
						{
							for(j = 1; j <= pumpNumber; j++)
							{
								if(j == 1)
									$("#HeaterPump"+i).html('<option value="'+j+'">Pump '+j+'</option>');
								else 
									$("#HeaterPump"+i).append('<option value="'+j+'">Pump '+j+'</option>');	
							}
						}
						
						
					}
					$("#loadingImgHeater").hide();
					parent.$.fancybox.close();
		}
		});
		
	}
	
	
	function checkAndSaveLight()
	{
		var lightNumber	=	$("#lightNumber").val();
		
		if(isNaN(lightNumber))
		{
			$("#lightNumber").css('border','1px solid #FF0000');
			alert("Please enter valid light numbers!");
			return false;
		}
		else
		{
			$("#lightNumber").css('border','');
		}
		
		$("#loadingImgLight").show();
		
		var arrLightSaveDetails	=	{};
		var errMsg					=	"";
		for(j = 1; j <= lightNumber; j++)
		{
			var relayType 	=	$("#light"+j+"_equiment").val();
			var relayNumber =	$("#light"+j+"_sub_equiment_"+relayType).val();
			
			if(relayNumber == '')
			{
				errMsg	+=	"- Please select Relay Number for Light "+j+"!\n";
			}
			
			arrLightSaveDetails[j]		=	[];
			arrLightSaveDetails[j] 	=	{'relayType': relayType, 'relayNumber' : relayNumber} 
		}
		
		if(errMsg != '')
		{
			alert("Following are the errors : \n\n"+errMsg);
			$("#loadingImgLight").hide();
			return false;
		}
		
		//Check if entered address already exists.
		$.ajax({
		type: "POST",
		url: "<?php echo site_url('home/saveLightRelayConf/');?>", 
		data: {light:JSON.stringify(arrLightSaveDetails),sDevice:'L'},
		success: function(data) {
					alert(data);
					if(data.indexOf("successfully") >= 0)
					{
						for (var i = 1; i <= lightNumber; i++) 
						{
							if(i == 1)
							{
								$("#no_light").html('<option value="'+(i - 1)+'">'+(i - 1)+' Light</option><option value="'+i+'">'+i+' Light</option>');
							}
							else
							{
								$("#no_light").append('<option value="'+i+'">'+i+' Light</option>');
							}
						}
					}
					$("#loadingImgLight").hide();
					parent.$.fancybox.close();
		}
		});
	}
	
	
	function checkAndSaveBlower()
	{
		var blowerNumber	=	$("#blowerNumber").val();
		
		if(isNaN(blowerNumber))
		{
			$("#blowerNumber").css('border','1px solid #FF0000');
			alert("Please enter valid Blower numbers!");
			return false;
		}
		else
		{
			$("#blowerNumber").css('border','');
		}
		
		$("#loadingImgBlower").show();
		
		var arrBlowerSaveDetails	=	{};
		var errMsg					=	"";
		for(j = 1; j <= blowerNumber; j++)
		{
			var relayType 	=	$("#blower"+j+"_equiment").val();
			var relayNumber =	$("#blower"+j+"_sub_equiment_"+relayType).val();
			
			if(relayNumber == '')
			{
				errMsg	+=	"- Please select Relay Number for Blower "+j+"!\n";
			}
			
			arrBlowerSaveDetails[j]		=	[];
			arrBlowerSaveDetails[j] 	=	{'relayType': relayType, 'relayNumber' : relayNumber} 
		}
		
		if(errMsg != '')
		{
			alert("Following are the errors : \n\n"+errMsg);
			$("#loadingImgBlower").hide();
			return false;
		}
		
		//Check if entered address already exists.
		$.ajax({
		type: "POST",
		url: "<?php echo site_url('home/saveBlowerRelayConf/');?>", 
		data: {blower:JSON.stringify(arrBlowerSaveDetails),sDevice:'B'},
		success: function(data) {
					alert(data);
					if(data.indexOf("successfully") >= 0)
					{
						for (var i = 1; i <= blowerNumber; i++) 
						{
							if(i == 1)
							{
								$("#no_blower").html('<option value="'+(i - 1)+'">'+(i - 1)+' Blower</option><option value="'+i+'">'+i+' Blower</option>');
							}
							else
							{
								$("#no_blower").append('<option value="'+i+'">'+i+' Blower</option>');
							}
						}
					}
					$("#loadingImgBlower").hide();
					parent.$.fancybox.close();
		}
		});
	}
	
</script>
<div class="row">
	<div class="col-lg-12">
		<ol class="breadcrumb">
		  <li><img src="<?php echo HTTP_IMAGES_PATH.'icons/home.png';?>" width="24" style="vertical-align: middle !important;">&nbsp;<a href="<?php echo site_url();?>">Home</a> </li>
		  <li class="active">Pool & Spa Setting</li>
		</ol>
	</div>
</div>

<div class="row">
	<div class="col-lg-12">
		<div><span style="color:#FFF;"><strong>Edit Pool & Spa Automation Question To Set Up Their Equipment Properly<strong></span><span style="color:#FF0000; float:right;"><strong>* indicates required field</strong></span></div>
	</div>
</div>
<div class="row">
<div class="col-lg-12">&nbsp;</div>
</div>
<div class="row">
<div class="col-lg-12">
	<!-- Tabs -->
    <script type="text/javascript">

$(function ()
 {
    var form = $("#formPoolSpa");
     form.validate({
        errorPlacement: function errorPlacement(error, element) { element.before(error); },
        rules: {
            confirm: {
                equalTo: "#password"
            }
        }
    }); 
    form.children("div").steps({
        headerTag: "h3",
        bodyTag: "section",
        transitionEffect: "slideLeft",
		setStep: "2",
        onStepChanging: function (event, currentIndex, newIndex)
        {
            form.validate().settings.ignore = ":disabled,:hidden";
            return form.valid();
        },
        onFinishing: function (event, currentIndex)
        {
            form.validate().settings.ignore = ":disabled";
            return form.valid();
        },
        onFinished: function (event, currentIndex)
        {
            //alert("Submitted!");
			//document.formPoolSpa.submit();
			$("#formPoolSpa").submit();
        }
    });
	
	//wizard.steps("setStep", 2);
 });

</script>  
    <form id="formPoolSpa" name="formPoolSpa" action="<?php echo base_url('home/PoolSpaSetting/');?>" method="post">
	<input type="hidden" name="command" id="command" value="save">
        <div>
            <h3>General</h3>
			<section>
			<div class="col-sm-6">
                <label for="strType">Do you have a pool only, spa only and or a pool and spa?:<span class="requiredMark">*</span></label>
                <select name="strType" id="strType" class="form-control required" onchange="checkType(this.value)">
					<option <?php if(isset($arrGeneral['type']) && $arrGeneral['type'] == ''){ echo 'selected="selected"';} ?> value="">Select Type</option>
					<option <?php if(isset($arrGeneral['type']) && $arrGeneral['type'] == 'pool'){ echo 'selected="selected"';} ?> value="pool">Pool only</option>
					<option <?php if(isset($arrGeneral['type']) && $arrGeneral['type'] == 'spa'){ echo 'selected="selected"';} ?> value="spa">Spa only</option>
					<option <?php if(isset($arrGeneral['type']) && $arrGeneral['type'] == 'both'){ echo 'selected="selected"';} ?> value="both">Pool and Spa</option>
				</select>
				<div style="height:10px">&nbsp;</div>
                <label for="pool_maximum_temperature">What is the maximum temperature expressed in Fahrenheit that you would like to be able to set the pool temperature to ?<span class="requiredMark">*</span></label>
               <input type="text" name="pool_maximum_temperature" value="<?php if(isset($arrGeneral['pool_max_temp']) && $arrGeneral['pool_max_temp'] != '') { echo $arrGeneral['pool_max_temp'];}?>" id="pool_maximum_temperature" class="form-control inputText <?php if($strPoolRequired == 'Yes') { echo 'required';} ?>" <?php if($strPoolRequired == '') { echo 'readonly="readonly"';} ?>>
			   <div style="height:10px">&nbsp;</div>
                <label for="pool_temperature">Desire pool temperature when user is in Pool Mode?<span class="requiredMark">*</span></label>
               <input type="text" name="pool_temperature" value="<?php if(isset($arrGeneral['pool_temp']) && $arrGeneral['pool_temp'] != '') { echo $arrGeneral['pool_temp'];}?>" id="pool_temperature" class="form-control inputText <?php if($strPoolRequired == 'Yes') { echo 'required';} ?>" <?php if($strPoolRequired == '') { echo 'readonly="readonly"';} ?>>
			   <div style="height:10px">&nbsp;</div>
                <label for="pool_manual">The maximum allotted time for Pool Manual Mode expressed in minutes?<span class="requiredMark">*</span></label>
               <input type="text" name="pool_manual" value="<?php if(isset($arrGeneral['pool_manual']) && $arrGeneral['pool_manual'] != '') { echo $arrGeneral['pool_manual'];}?>" id="pool_manual" class="form-control inputText <?php if($strPoolRequired == 'Yes') { echo 'required';} ?>" <?php if($strPoolRequired == '') { echo 'readonly="readonly"';} ?>>
				
			</div>
			<div class="col-sm-6">
			    <!--<label for="strEquipment">How do you control your equipment?<span class="requiredMark">*</span></label>
                <select name="strEquipment" id="strEquipment" class="form-control required">
					<option <?php if(isset($arrGeneral['equip']) && $arrGeneral['equip'] == ''){ echo 'selected="selected"';} ?> value="">Select Equipment</option>
					<option <?php if(isset($arrGeneral['equip']) && $arrGeneral['equip'] == '1'){ echo 'selected="selected"';} ?> value="1">RLB Board</option>
					<option <?php if(isset($arrGeneral['equip']) && $arrGeneral['equip'] == '2'){ echo 'selected="selected"';} ?> value="2">Other or Manually Operated</option>
					<option <?php if(isset($arrGeneral['equip']) && $arrGeneral['equip'] == '3'){ echo 'selected="selected"';} ?> value="3">Both</option>
				</select>-->
				<div style="height:68px">&nbsp;</div>
				<?php
					$strPoolRequired	=	'';
					$strSpaRequired		=	'';
					if(isset($arrGeneral['type']) && $arrGeneral['type'] == 'pool')
					{
						$strPoolRequired		=	'Yes';
					}
					if(isset($arrGeneral['type']) && $arrGeneral['type'] == 'spa')
					{
						$strSpaRequired			=	'Yes';
					}
					if(isset($arrGeneral['type']) && $arrGeneral['type'] == 'both')
					{
						$strPoolRequired		=	'Yes';
						$strSpaRequired			=	'Yes';
					}
				?>
                
                <label for="pool_temperature">What is the maximum temperature expressed in Fahrenheit that you would like to be able to set the spa temperature to?<span class="requiredMark">*</span></label>
               <input type="text" name="spa_maximum_temperature" value="<?php if(isset($arrGeneral['spa_max_temp']) && $arrGeneral['spa_max_temp'] != '') { echo $arrGeneral['spa_max_temp'];}?>" id="spa_maximum_temperature" class="form-control inputText <?php if($strSpaRequired == 'Yes') { echo 'required';} ?>" <?php if($strSpaRequired == '') { echo 'readonly="readonly"';} ?>>
			   <div style="height:10px">&nbsp;</div>
                <label for="spa_temperature">Desire spa temperature when user is in Spa Mode?<span class="requiredMark">*</span></label>
               <input type="text" name="spa_temperature" value="<?php if(isset($arrGeneral['spa_temperature']) && $arrGeneral['spa_temperature'] != '') { echo $arrGeneral['spa_temperature'];}?>" id="spa_temperature" class="form-control inputText <?php if($strSpaRequired == 'Yes') { echo 'required';} ?>" <?php if($strSpaRequired == '') { echo 'readonly="readonly"';} ?>>
			   <div style="height:10px">&nbsp;</div>
                <label for="spa_manual">The maximum allotted time for Spa Mode expressed in minutes?<span class="requiredMark">*</span><br><br></label>
               <input type="text" name="spa_manual" value="<?php if(isset($arrGeneral['spa_manual']) && $arrGeneral['spa_manual'] != '') { echo $arrGeneral['spa_manual'];}?>" id="spa_manual" class="form-control inputText <?php if($strSpaRequired == 'Yes') { echo 'required';} ?>" <?php if($strSpaRequired == '') { echo 'readonly="readonly"';} ?>>
			</div>
			</section>
            <h3>Device</h3>
            <section>
			<div class="col-sm-6">
				<label for="strValve">How many AUTOMATIC valves do you have on your pool and or pool/spa system?<span class="requiredMark">*</span>&nbsp;&nbsp;<a class="fancybox changeLink" id="changeLinkValve" href="#valveForm">Change</a></label>
				<?php //if(isset($arrDevice['valve_actuated'])  && in_array(2,$arrDevice['valve_actuated'])){ echo 'selected="selected"';}?>
                <select name="strValve" id="strValve" class="form-control required" onchange="valveChange();">
				<option <?php if(isset($arrDevice['valve']) && $arrDevice['valve'] == ''){ echo 'selected="selected"';} ?> value="">Select valves</option>
				<option <?php if(isset($arrDevice['valve']) && $arrDevice['valve'] == '0'){ echo 'selected="selected"';} ?> value="0">0 Valves</option>
					<?php
						for($i=0;$i<$iValveCnt;$i++)
						{
					?>
						<option <?php if(isset($arrDevice['valve']) && $arrDevice['valve'] == ($i+1)){ echo 'selected="selected"';} ?> value="<?php echo ($i+1);?>"><?php echo ($i+1);?> Valves</option>
					<?php } ?>
				</select>
				<?php for($i=0;$i<8;$i++){?>
				<div class="valveShow" id="valveShow<?php echo ($i+1);?>" style="display:<?php if($iValveCnt >= ($i+1)) { echo '';} else { echo 'none';}?>" >
					<div style="height:10px">&nbsp;</div>
					<label for="valve_assign<?php echo ($i+1);?>">Assign Valve<?php echo ($i+1);?>?<span class="requiredMark">*</span></label>
					<select name="valve_assign<?php echo ($i+1);?>" id="valve_assign<?php echo ($i+1);?>" class="form-control">
					<option value="">Select Valve to Assign</option>
					<?php foreach($ValveRelays as $valve)
						  {
							  echo '<option value="'.$valve->device_number.'">Valve '.$valve->device_number.'</option>';
						  }
					?>	  
					</select>
				</div>	
				<?php } ?>
				
				<div style="height:10px">&nbsp;</div>
				<label for="valve_actuated">If necessary, Which valve(s) is actuated when you switch from Pool to Spa Mode?<span class="requiredMark">*</span></label>
                <select name="valve_actuated[]" id="valve_actuated" class="form-control required" multiple="" onchange="showReason(this.value);">
					<option <?php if(isset($arrDevice['valve_actuated']) && in_array('',$arrDevice['valve_actuated'])){ echo 'selected="selected"';} ?> value="">Select Valve Quantity</option>
					<option <?php if(isset($arrDevice['valve_actuated'])  && in_array(0,$arrDevice['valve_actuated'])){ echo 'selected="selected"';} ?> value="0">Valve 0 is actuated</option>
					<?php
						for($i=0;$i<$iValveCnt;$i++)
						{
					?>
					<option <?php if(isset($arrDevice['valve_actuated'])  && in_array(1,$arrDevice['valve_actuated'])){ echo 'selected="selected"';} ?> value="<?php echo ($i+1);?>">Valve <?php echo ($i+1);?> is actuated</option>
					<?php } ?>
				</select>
				<div style="height:10px; display:none;" id="reasonValveBlk">&nbsp;</div>
				<label id="reasonValvelbl" for="reasonValve" style="display:none;">Reason for No valves are actuated?<span class="requiredMark">*</span></label>
                <input type="text" name="reasonValve" value="<?php if(isset($arrDevice['reasonValve']) && $arrDevice['reasonValve'] != '') { echo $arrDevice['reasonValve'];}?>" id="reasonValve" class="form-control inputText" style="display:none;">
				
				<div style="height:10px">&nbsp;</div>
				<label for="valveRunTime">Valve Run Time expressed in minutes?<span class="requiredMark">*</span></label>
                <input type="text" name="valveRunTime" value="<?php if(isset($arrDevice['valveRunTime']) && $arrDevice['valveRunTime'] != '') { echo $arrDevice['valveRunTime'];}?>" id="valveRunTime" class="form-control inputText required">
				
				<div style="height:10px">&nbsp;</div>
			</div>	
			<div class="col-sm-6">
			<label for="automatic_pumps">How many Pumps do you have?<span class="requiredMark">*</span></label>&nbsp;&nbsp;<a class="fancyboxPump changeLink" id="changeLinkPump" href="#pumpForm">Change</a>
                <select name="automatic_pumps" id="automatic_pumps" class="form-control required" onchange="pumpChange();">
					<option <?php if(isset($arrDevice['pump']) && $arrDevice['pump'] == '0'){ echo 'selected="selected"';} ?>  value="0">0 Pump</option>
					<?php for($i=1;$i<=$iPumpCnt;$i++){?>
					<option <?php if(isset($arrDevice['pump']) && $arrDevice['pump'] == $i){ echo 'selected="selected"';} ?>  value="<?php echo $i;?>"><?php echo $i;?> Pump</option>
					<?php } ?>
					
				</select>
				
				<div style="height:10px">&nbsp;</div>
				<table width="100%;">
				<?php for($i=1;$i<=$iPumpCnt;$i++){?>
				<tr id="trPump<?php echo $i;?>" style="display:<?php if(isset($arrDevice['pump']) && $arrDevice['pump'] >= $i){ echo '';} else {echo 'none;';} ?>">
					<td>
						<label for="strValve">Pump<?php echo $i;?><span class="requiredMark">*</span></label>
						<select name="Pump<?php echo $i;?>" id="Pump<?php echo $i;?>" class="form-control required">
						<option <?php if(isset($arrDevice['pump'.$i]) && $arrDevice['pump'.$i] == ''){ echo 'selected="selected"';} ?> value="">--Select pump function--</option>
						<option <?php if(isset($arrDevice['pump'.$i]) && $arrDevice['pump'.$i] == 'Filtering Pool and Spa'){ echo 'selected="selected"';} ?> value="Filtering Pool and Spa">Filtering Pool and Spa</option>
						<option <?php if(isset($arrDevice['pump'.$i]) && $arrDevice['pump'.$i] == 'Filtering Spa Only'){ echo 'selected="selected"';} ?> value="Filtering Spa Only">Filtering Spa Only</option>
						<option <?php if(isset($arrDevice['pump'.$i]) && $arrDevice['pump'.$i] == 'Filtering Pool Only'){ echo 'selected="selected"';} ?> value="Filtering Pool Only">Filtering Pool Only</option>
						<option <?php if(isset($arrDevice['pump'.$i]) && $arrDevice['pump'.$i] == 'Spa Jets Only'){ echo 'selected="selected"';} ?> value="Spa Jets Only">Spa Jets Only</option>
						<option <?php if(isset($arrDevice['pump'.$i]) && $arrDevice['pump'.$i] == 'Spa Circulation and Heating'){ echo 'selected="selected"';} ?> value="Spa Circulation and Heating">Spa Circulation and Heating</option>
						<option <?php if(isset($arrDevice['pump'.$i]) && $arrDevice['pump'.$i] == 'Pool Circulation and Heating'){ echo 'selected="selected"';} ?> value="Pool Circulation and Heating">Pool Circulation and Heating</option>
						<option <?php if(isset($arrDevice['pump'.$i]) && $arrDevice['pump'.$i] == 'Pool and Spa Circulation and Heating'){ echo 'selected="selected"';} ?> value="Pool and Spa Circulation and Heating">Pool and Spa Circulation and Heating</option>
						<option <?php if(isset($arrDevice['pump'.$i]) && $arrDevice['pump'.$i] == 'waterfall'){ echo 'selected="selected"';} ?> value="waterfall">waterfall</option>
						<option <?php if(isset($arrDevice['pump'.$i]) && $arrDevice['pump'.$i] == 'solar heater'){ echo 'selected="selected"';} ?> value="solar heater">solar heater</option>
						<option <?php if(isset($arrDevice['pump'.$i]) && $arrDevice['pump'.$i] == 'waterslide'){ echo 'selected="selected"';} ?> value="waterslide">waterslide</option>
						<option <?php if(isset($arrDevice['pump'.$i]) && $arrDevice['pump'.$i] == 'water feature 1'){ echo 'selected="selected"';} ?> value="water feature 1">water feature 1</option>
						<option <?php if(isset($arrDevice['pump'.$i]) && $arrDevice['pump'.$i] == 'water feature 2'){ echo 'selected="selected"';} ?> value="water feature 2">water feature 2</option>
						</select>
					</td>
				</tr>
				<tr style="height:10px;"><td>&nbsp;</td></tr>
				<tr class="trPumpShow" id="trPumpShow<?php echo $i;?>" style="display:<?php if(isset($arrDevice['pump']) && $arrDevice['pump'] >= $i){ echo '';} else {echo 'none;';} ?>">
					<td>
					<label for="strValve">Assign Pump<?php echo $i;?><span class="requiredMark">*</span></label>
					<select name="PumpAssign<?php echo $i;?>" id="PumpAssign<?php echo $i;?>" class="form-control">
					<option value="">--Select Pump--</option>
					<?php foreach($Pumps as $pump) { ?>
					<option value="<?php echo $pump->pump_number;?>">Pump <?php echo $pump->pump_number;?></option>
					<?php } ?>
					</select>	
					</td>
				</tr>
				<?php } ?>
				</table>
			</div>
            </section>
            <h3>Heater</h3>
            <section style="float: none;padding: 2.5%;position: relative;">
                <div class="col-sm-6">
					<label for="automatic_heaters_question1">How many heaters do you have?<span class="requiredMark">*</span></label>&nbsp;&nbsp;<a class="fancybox changeLink" id="changeLinkHeater" href="#heaterForm">Change</a>
					<select name="automatic_heaters_question1" id="automatic_heaters_question1" class="form-control required" onchange="showHeater();">
					<option <?php if(isset($arrHeater['heater']) &&  $arrHeater['heater'] == '0'){echo 'selected="selected"';}?> value="0">0 Heater</option>
						<option <?php if(isset($arrHeater['heater']) &&  $arrHeater['heater'] == '1'){echo 'selected="selected"';}?> value="1">1 Heater</option>
						<option <?php if(isset($arrHeater['heater']) &&  $arrHeater['heater'] == '2'){echo 'selected="selected"';}?> value="2">2 Heater</option>
						<option <?php if(isset($arrHeater['heater']) &&  $arrHeater['heater'] == '3'){echo 'selected="selected"';}?> value="3">3 Heater</option>
					</select>
					<div style="height:10px">&nbsp;</div>
					<table width="100%">
				<tr id="trHeaterWork1" style="display:<?php if(isset($arrHeater['heater']) &&  $arrHeater['heater'] >= 1){echo '';}else{echo 'none';}?>;"><td>
				<label for="Heater1">Heater 1?<span class="requiredMark">*</span></label>
                <select name="Heater1" id="Heater1" class="form-control">
					<option <?php if(isset($arrHeater['Heater1']) &&  $arrHeater['Heater1'] == 'Pool spa Combo'){echo 'selected="selected"';}?> value="Pool spa Combo">Heat pool and spa</option>
					<option <?php if(isset($arrHeater['Heater1']) &&  $arrHeater['Heater1'] == 'Pool Only'){echo 'selected="selected"';}?> value="Pool Only">Heat pool</option>
					<option <?php if(isset($arrHeater['Heater1']) &&  $arrHeater['Heater1'] == 'Spa Only'){echo 'selected="selected"';}?> value="Spa Only">Heat spa</option>
					<option <?php if(isset($arrHeater['Heater1']) &&  $arrHeater['Heater1'] == 'Heat off'){echo 'selected="selected"';}?> value="Heat off">Heat off</option>
				</select>
				</td></tr>
				<tr id="trHeaterWork2" style="display:<?php if(isset($arrHeater['heater']) &&  $arrHeater['heater'] >= 2){echo '';}else{echo 'none';}?>;"><td>
				<div style="height:10px">&nbsp;</div>
				<label for="Heater2">Heater 2?<span class="requiredMark">*</span></label>
                <select name="Heater2" id="Heater2" class="form-control">
					<option <?php if(isset($arrHeater['Heater2']) &&  $arrHeater['Heater2'] == 'Pool spa Combo'){echo 'selected="selected"';}?> value="Pool spa Combo">Heat pool and spa</option>
					<option <?php if(isset($arrHeater['Heater2']) &&  $arrHeater['Heater2'] == 'Pool Only'){echo 'selected="selected"';}?> value="Pool Only">Heat pool</option>
					<option <?php if(isset($arrHeater['Heater2']) &&  $arrHeater['Heater2'] == 'Spa Only'){echo 'selected="selected"';}?> value="Spa Only">Heat spa</option>
					<option <?php if(isset($arrHeater['Heater2']) &&  $arrHeater['Heater2'] == 'Heat off'){echo 'selected="selected"';}?> value="Heat off">Heat off</option>
				</select>
				</td></tr>
				<tr id="trHeaterWork3" style="display:<?php if(isset($arrHeater['heater']) &&  $arrHeater['heater'] >= 3){echo '';}else{echo 'none';}?>;"><td>
				<div style="height:10px">&nbsp;</div>
				<label for="Heater3">Heater 3?<span class="requiredMark">*</span></label>
                <select name="Heater3" id="Heater3" class="form-control">
					<option <?php if(isset($arrHeater['Heater3']) &&  $arrHeater['Heater3'] == 'Pool spa Combo'){echo 'selected="selected"';}?> value="Pool spa Combo">Heat pool and spa</option>
					<option <?php if(isset($arrHeater['Heater3']) &&  $arrHeater['Heater3'] == 'Pool Only'){echo 'selected="selected"';}?> value="Pool Only">Heat pool</option>
					<option <?php if(isset($arrHeater['Heater3']) &&  $arrHeater['Heater3'] == 'Spa Only'){echo 'selected="selected"';}?> value="Spa Only">Heat spa</option>
					<option <?php if(isset($arrHeater['Heater3']) &&  $arrHeater['Heater3'] == 'Heat off'){echo 'selected="selected"';}?> value="Heat off">Heat off</option>
				</select>
				</td></tr>
				</table>
				</table>
				</div>
				<div class="col-sm-6">
				<table width="100%">
				<tr><td style="height:70px;">&nbsp;</td></tr>
				<tr id="trHeaterPump1" style="display:<?php if(isset($arrHeater['heater']) &&  $arrHeater['heater'] >= 1){echo '';}else{echo 'none';}?>;"><td>
				<label for="HeaterPump1">Which Pump has to be on in order to operate Heater 1?<span class="requiredMark">*</span></label>
                <select name="HeaterPump1" id="HeaterPump1" class="form-control">
					<option <?php if(isset($arrHeater['HeaterPump1']) &&  $arrHeater['HeaterPump1'] == '1'){echo 'selected="selected"';}?> value="1">Pump1</option>
					<?php if(isset($arrHeater['heater']) &&  $arrHeater['heater'] >= 2) {?>
					<option <?php if(isset($arrHeater['HeaterPump1']) &&  $arrHeater['HeaterPump1'] == '2'){echo 'selected="selected"';}?> value="2">Pump2</option>
					<?php } if(isset($arrHeater['heater']) &&  $arrHeater['heater'] >= 3) {?>
					<option <?php if(isset($arrHeater['HeaterPump1']) &&  $arrHeater['HeaterPump1'] == '3'){echo 'selected="selected"';}?> value="3">Pump3</option>
					<?php } ?>
				</select>
				</td></tr>
				<tr id="trHeaterPump2" style="display:<?php if(isset($arrHeater['heater']) &&  $arrHeater['heater'] >= 2){echo '';}else{echo 'none';}?>;"><td>
				<div style="height:10px">&nbsp;</div>
				<label for="HeaterPump2">Which Pump has to be on in order to operate Heater 2?<span class="requiredMark">*</span></label>
                <select name="HeaterPump2" id="HeaterPump2" class="form-control">
					<option <?php if(isset($arrHeater['HeaterPump2']) &&  $arrHeater['HeaterPump2'] == '1'){echo 'selected="selected"';}?> value="1">Pump1</option>
					<?php if(isset($arrHeater['heater']) &&  $arrHeater['heater'] >= 2) {?>
					<option <?php if(isset($arrHeater['HeaterPump2']) &&  $arrHeater['HeaterPump2'] == '2'){echo 'selected="selected"';}?> value="2">Pump2</option>
					<?php } if(isset($arrHeater['heater']) &&  $arrHeater['heater'] >= 3) {?>
					<option <?php if(isset($arrHeater['HeaterPump2']) &&  $arrHeater['HeaterPump2'] == '3'){echo 'selected="selected"';}?> value="3">Pump3</option>
					<?php } ?>
				</select>
				</td></tr>
				<tr id="trHeaterPump3" style="display:<?php if(isset($arrHeater['heater']) &&  $arrHeater['heater'] >= 3){echo '';}else{echo 'none';}?>;"><td>
				<div style="height:10px">&nbsp;</div>
				<label for="HeaterPump3">Which Pump has to be on in order to operate Heater 3?<span class="requiredMark">*</span></label>
                <select name="HeaterPump3" id="HeaterPump3" class="form-control">
					<option <?php if(isset($arrHeater['HeaterPump3']) &&  $arrHeater['HeaterPump3'] == '1'){echo 'selected="selected"';}?> value="1">Pump1</option>
					<?php if(isset($arrHeater['heater']) &&  $arrHeater['heater'] >= 2) {?>
					<option <?php if(isset($arrHeater['HeaterPump3']) &&  $arrHeater['HeaterPump3'] == '2'){echo 'selected="selected"';}?> value="2">Pump2</option>
					<?php } if(isset($arrHeater['heater']) &&  $arrHeater['heater'] >= 3) {?>
					<option <?php if(isset($arrHeater['HeaterPump3']) &&  $arrHeater['HeaterPump3'] == '3'){echo 'selected="selected"';}?> value="3">Pump3</option>
					<?php } ?>
				</select>
				</td></tr>
				</table>
				<div style="height:10px">&nbsp;</div>
				</div>
            </section>
			<h3>More Device</h3>
            <section>
			<div class="col-sm-6">
               <label for="no_light">How many Spa/Pool lights do you have?<span class="requiredMark">*</span></label>&nbsp;&nbsp;<a class="fancybox changeLink" id="changeLinkLight" href="#LightForm">Change</a>
                <select name="no_light" id="no_light" class="form-control">
						<option <?php if(isset($arrMore['light']) &&  $arrMore['light'] == ''){echo 'selected="selected"';}?> value="">Select number of lights</option>
						<option <?php if(isset($arrMore['light']) &&  $arrMore['light'] == '1'){echo 'selected="selected"';}?> value="1">1 Light</option>
						<option <?php if(isset($arrMore['light']) &&  $arrMore['light'] == '2'){echo 'selected="selected"';}?> value="2">2 Light</option>
						<option <?php if(isset($arrMore['light']) &&  $arrMore['light'] == '3'){echo 'selected="selected"';}?> value="3">3 Light</option>
						<option <?php if(isset($arrMore['light']) &&  $arrMore['light'] == '4'){echo 'selected="selected"';}?> value="4">4 Light</option>
				</select>
				<div style="height:10px">&nbsp;</div>
				<label for="lightRunTime">After how many minutes, would you like to automatically turn the pool/spa lights OFF?<span class="requiredMark">*</span></label>
                <input type="text" name="lightRunTime" value="<?php if(isset($arrMore['lightRunTime']) && $arrMore['lightRunTime'] != '') { echo $arrMore['lightRunTime'];}?>" id="lightRunTime" class="form-control inputText">
				<div style="height:10px">&nbsp;</div>
				<label for="temperature1">Temperature Sensor 1<span class="requiredMark">*</span></label>
                <select name="temperature1" id="temperature1" class="form-control">
					<option <?php if(isset($arrMore['temperature1']) &&  $arrMore['temperature1'] == '1'){echo 'selected="selected"';}?> value="1">TS1</option>
					<option <?php if(isset($arrMore['temperature1']) &&  $arrMore['temperature1'] == '2'){echo 'selected="selected"';}?> value="2">TS2</option>
					<option <?php if(isset($arrMore['temperature1']) &&  $arrMore['temperature1'] == '3'){echo 'selected="selected"';}?> value="3">TS3</option>
					<option <?php if(isset($arrMore['temperature1']) &&  $arrMore['temperature1'] == '4'){echo 'selected="selected"';}?> value="4">TS4</option>
					<option <?php if(isset($arrMore['temperature1']) &&  $arrMore['temperature1'] == '5'){echo 'selected="selected"';}?> value="5">TS5</option>
				</select>
				<div style="height:10px">&nbsp;</div>
				<label for="display_pool_temp">Display Pool Temp on mode Page yes or no?<span class="requiredMark">*</span></label>
                <select name="display_pool_temp" id="display_pool_temp" class="form-control <?php if($strPoolRequired == 'Yes') { echo '';} ?>" <?php if($strPoolRequired == '') { echo 'disabled="disabled"';} ?>>
						<option <?php if(isset($arrGeneral['display_pool_temp']) && $arrGeneral['display_pool_temp'] == 'Yes'){ echo 'selected="selected"';} ?> value="Yes">Yes</option>
						<option <?php if(isset($arrGeneral['display_pool_temp']) && $arrGeneral['display_pool_temp'] == 'No'){ echo 'selected="selected"';} ?> value="No">No</option>
					</select>
				<div style="height:10px">&nbsp;</div>
                
			</div>
			<div class="col-sm-6">
			<label for="no_blower">How many Spa devices do you have?<span class="requiredMark">*</span></label>&nbsp;&nbsp;<a class="fancybox changeLink" id="changeLinkLight" href="#BlowerForm">Change</a>
                <select name="no_blower" id="no_blower" class="form-control">
						<option <?php if(isset($arrMore['blower']) &&  $arrMore['blower'] == ''){echo 'selected="selected"';}?> value="">Select number of blowers</option>
						<option <?php if(isset($arrMore['blower']) &&  $arrMore['blower'] == '0'){echo 'selected="selected"';}?> value="0">0 Blower</option>
						<option <?php if(isset($arrMore['blower']) &&  $arrMore['blower'] == '1'){echo 'selected="selected"';}?> value="1">1 Blower</option>
						<option <?php if(isset($arrMore['blower']) &&  $arrMore['blower'] == '2'){echo 'selected="selected"';}?> value="2">2 Blower</option>
						<option <?php if(isset($arrMore['blower']) &&  $arrMore['blower'] == '3'){echo 'selected="selected"';}?> value="3">3 Blower</option>
						<option <?php if(isset($arrMore['blower']) &&  $arrMore['blower'] == '4'){echo 'selected="selected"';}?> value="4">4 Blower</option>
					</select>
				<div style="height:10px">&nbsp;</div>
				<label for="blowerRunTime">After how many minutes, would you like to automatically turn the pool/spa blower OFF?<span class="requiredMark">*</span></label>
                <input type="text" name="blowerRunTime" value="<?php if(isset($arrMore['blowerRunTime']) && $arrMore['blowerRunTime'] != '') { echo $arrMore['blowerRunTime'];}?>" id="blowerRunTime" class="form-control inputText required">
				<div style="height:10px">&nbsp;</div>
				<label for="temperature2">Temperature Sensor 2<span class="requiredMark">*</span></label>
                <select name="temperature2" id="temperature2" class="form-control">
					<option <?php if(isset($arrMore['temperature2']) &&  $arrMore['temperature2'] == '1'){echo 'selected="selected"';}?> value="1">TS1</option>
					<option <?php if(isset($arrMore['temperature2']) &&  $arrMore['temperature2'] == '2'){echo 'selected="selected"';}?> value="2">TS2</option>
					<option <?php if(isset($arrMore['temperature2']) &&  $arrMore['temperature2'] == '3'){echo 'selected="selected"';}?> value="3">TS3</option>
					<option <?php if(isset($arrMore['temperature2']) &&  $arrMore['temperature2'] == '4'){echo 'selected="selected"';}?> value="4">TS4</option>
					<option <?php if(isset($arrMore['temperature2']) &&  $arrMore['temperature2'] == '5'){echo 'selected="selected"';}?> value="5">TS5</option>
				</select>
				<div style="height:10px">&nbsp;</div>
				<label for="display_spa_temp">Display Spa Temp on mode Page yes or no?<span class="requiredMark">*</span></label>
                <select name="display_spa_temp" id="display_spa_temp" class="form-control <?php if($strSpaRequired == 'Yes') { echo '';} ?>" <?php if($strSpaRequired == '') { echo 'disabled="disabled"';} ?>>
						<option <?php if(isset($arrGeneral['display_spa_temp']) && $arrGeneral['display_spa_temp'] == 'Yes'){ echo 'selected="selected"';} ?> value="Yes">Yes</option>
						<option <?php if(isset($arrGeneral['display_spa_temp']) && $arrGeneral['display_spa_temp'] == 'No'){ echo 'selected="selected"';} ?> value="No">No</option>
				</select>
				<div style="height:10px">&nbsp;</div>
			</div>	
            </section>
		</div>
	</form>
	
	<div id="valveForm" style="width:auto;height:auto;display:none;" >	
	<div style="margin-bottom:10px;"><h3 class="confHeader">Valve Configuration</h3></div>
	<table class="table removeBorder" id="valveTable" width="100%" cellspacing="0" cellpadding="0">
	 <tbody>
		<tr>
			<td style="width:48%;">Enter Number of Valves to Use in system:</td>
			<td style="width:2%;">&nbsp;</td>
			<td style="width:50%;"><input type="text" name="valveNumber" id="valveNumber" onkeyup="showValveDetails();" value="<?php if(isset($extra['ValveNumber']) && $extra['ValveNumber'] != 0) { echo $extra['ValveNumber'];}?>" class="form-control inputText"></td>
		</tr>
		<?php if(!empty($ValveRelays))
			  {
				
				$i = 0;
				foreach($ValveRelays as $valve) 
				{
					$valve_relay_number	=	unserialize($valve->valve_relay_number);
					
		?>
					<tr><td><strong>Valve <?php echo $valve->device_number;?></strong>&nbsp;<span class="relayText">(Enter relays in sequence)</span></td><td>&nbsp;</td><td><input type="text" style="width:100px;" class="inputText" id="sRelay<?php echo $i;?>_1" value="<?php echo $valve_relay_number['Relay1'];?>">&nbsp;&nbsp;<input type="text" style="width:100px;" class=" inputText" id="sRelay<?php echo $i;?>_2" value="<?php echo $valve_relay_number['Relay2'];?>">&nbsp;<a class="changeLink" href="javascript:void(0);" onclick="removeRow('valveTable')">Remove</a><div style="height: 5px;"> </div><select class="form-control" style="width:100px !important; display:inline;" name="valveDirection_<?php echo $i;?>_1"><option value="">Select Directions</option><option value="pool">Pool</option><option value="spa">Spa</option></select>&nbsp;&nbsp;<select class="form-control" style="width:100px !important; display:inline;" name="valveDirection_<?php echo $i;?>_2"><option value="">Select Directions</option><option value="pool">Pool</option><option value="spa">Spa</option></select></td></tr>
		<?php
					$i++;
				}
				
				echo '<tr><td colspan="3"><a href="javascript:void(0);" onclick="checkAndSaveRelays();" class="btn btn-middle"><span>Save</span></a>&nbsp;&nbsp;<span id="loadingImg" style="display:none; vertical-align: middle;"><img src="'.site_url('assets/images/loading.gif').'" alt="Loading...." width="32" height="32"></span></td></tr>';
			  }
		?>
	 </tbody>		
	</table>
	
	</div>
	
	<div id="heaterForm" style="display:none;">	
		<div style="margin-bottom:10px;"><h3 class="confHeader">Heater Configuration</h3></div>
		<table class="table removeBorder" id="heaterTable" width="100%" cellspacing="0" cellpadding="0">
			<tbody>
				<tr>
					<td style="width:48%;">Enter Number of Heater to Use in system:</td>
					<td style="width:2%;">&nbsp;</td>
					<td style="width:50%;"><input type="text" name="heaterNumber" id="heaterNumber" onkeyup="showHeaterDetails();" value="<?php if(isset($extra['HeaterNumber']) && $extra['HeaterNumber'] != 0) { echo $extra['HeaterNumber'];}?>" class="form-control inputText"></td>
				</tr>
				<?php for($i=1;$i<4;$i++)
					  {
				?>
						<tr id="heaterDetails_<?php echo $i;?>">
							<td colspan="3">
								<table border="0" cellspacing="0" cellpadding="0" width="100%">
									<tr><td colspan="3"><strong>Heater <?php echo $i;?></strong></td></tr>
									<tr>
									<td width="48%">How do you turn on your Heater <?php echo $i;?>?</td>
									<td width="2%">&nbsp;</td>
									<td width="50%">
										<select onchange="showRelays(this.value,'<?php echo $i;?>');" class="form-control valid" id="heater<?php echo $i;?>_equiment" name="heater<?php echo $i;?>_equiment">
											<option value="24">24V AC Relays</option>
											<option value="12">12V DC Relays</option>
										</select>
									</td>
									</tr>
									<tr><td colspan="3">&nbsp;</td></tr>
									<tr id="trHeaterSub<?php echo $i;?>_24">
									<td width="48%"><label for="heater<?php echo $i;?>_sub_equiment_24">Select 24V Relay<span class="requiredMark">*</span></label></td>
									<td width="2%">&nbsp;</td>
									<td width="50%">
									<select name="heater<?php echo $i;?>_sub_equiment_24" id="heater<?php echo $i;?>_sub_equiment_24" class="form-control">
										<option value="">Select Relay</option>
										<?php foreach($sRelays as $relay) {
										?>
											<option value="<?php echo $relay;?>">Relay <?php echo $relay;?></option>
										<?php } ?>
									</select>
									</td>
									</tr>
				
									<tr id="trHeaterSub<?php echo $i;?>_12" style="display:none;">
									<td width="48%"><label for="heater<?php echo $i;?>_sub_equiment_12">Select 12V Relay<span class="requiredMark">*</span></label></td>
									<td width="2%">&nbsp;</td>
									<td width="50%">
										<select name="heater<?php echo $i;?>_sub_equiment_12" id="heater<?php echo $i;?>_sub_equiment_12" class="form-control">
											<option value="">Select Relay</option>
											<?php foreach($sPowercenter as $relay) { ?>
											<option value="<?php echo $relay;?>">Relay <?php echo $relay;?></option>
											<?php } ?>
										</select>
									</td></tr>
									
									<tr><td colspan="3"><hr style="border-color:#000;" /></td></tr>
								</table>
							</td>
						</tr>
				<?php 
					  }
				?>	
				<tr id="heaterSaveConf" style="display:<?php if($extra['HeaterNumber'] == 0){ echo 'none;';}?>"><td colspan="3"><a href="javascript:void(0);" onclick="checkAndSaveHeater();" class="btn btn-middle"><span>Save</span></a>&nbsp;&nbsp;<span id="loadingImgHeater" style="display:none; vertical-align: middle;"><img src="<?php echo site_url('assets/images/loading.gif');?>" alt="Loading...." width="32" height="32"></span></td></tr>
			</tbody>
		</table>
	</div>
	
	
	<div id="LightForm" style="display:none;">	
		<div style="margin-bottom:10px;"><h3 class="confHeader">Light Configuration</h3></div>
		<table class="table removeBorder" id="lightTable" width="100%" cellspacing="0" cellpadding="0">
			<tbody>
				<tr>
					<td style="width:48%;">Enter Number of Lights to Use in system:</td>
					<td style="width:2%;">&nbsp;</td>
					<td style="width:50%;"><input type="text" name="lightNumber" id="lightNumber" onkeyup="showLightDetails();" value="<?php if(isset($extra['LightNumber']) && $extra['LightNumber'] != 0) { echo $extra['LightNumber'];}?>" class="form-control inputText"></td>
				</tr>
				<?php 
					  for($i=1;$i<4;$i++)
					  {
				?>
						<tr id="lightDetails_<?php echo $i;?>">
							<td colspan="3">
								<table border="0" cellspacing="0" cellpadding="0" width="100%">
									<tr><td colspan="3"><strong>Light <?php echo $i;?></strong></td></tr>
									<tr>
									<td width="48%">How do you turn on your Light <?php echo $i;?>?</td>
									<td width="2%">&nbsp;</td>
									<td width="50%">
										<select onchange="showRelaysLight(this.value,'<?php echo $i;?>');" class="form-control valid" id="light<?php echo $i;?>_equiment" name="light<?php echo $i;?>_equiment">
											<option value="24">24V AC Relays</option>
											<option value="12">12V DC Relays</option>
										</select>
									</td>
									</tr>
									<tr><td colspan="3">&nbsp;</td></tr>
									<tr id="trLightSub<?php echo $i;?>_24">
									<td width="48%"><label for="light<?php echo $i;?>_sub_equiment_24">Select 24V Relay<span class="requiredMark">*</span></label></td>
									<td width="2%">&nbsp;</td>
									<td width="50%">
									<select name="light<?php echo $i;?>_sub_equiment_24" id="light<?php echo $i;?>_sub_equiment_24" class="form-control">
										<option value="">Select Relay</option>
										<?php foreach($sRelays as $relay) {
										?>
											<option value="<?php echo $relay;?>">Relay <?php echo $relay;?></option>
										<?php } ?>
									</select>
									</td>
									</tr>
				
									<tr id="trLightSub<?php echo $i;?>_12" style="display:none;">
									<td width="48%"><label for="light<?php echo $i;?>_sub_equiment_12">Select 12V Relay<span class="requiredMark">*</span></label></td>
									<td width="2%">&nbsp;</td>
									<td width="50%">
										<select name="light<?php echo $i;?>_sub_equiment_12" id="light<?php echo $i;?>_sub_equiment_12" class="form-control">
											<option value="">Select Relay</option>
											<?php foreach($sPowercenter as $relay) { ?>
											<option value="<?php echo $relay;?>">Relay <?php echo $relay;?></option>
											<?php } ?>
										</select>
									</td></tr>
									
									<tr><td colspan="3"><hr style="border-color:#000;" /></td></tr>
								</table>
							</td>
						</tr>
				<?php 
					}
				?>	
				<tr id="lightSaveConf" style="display:<?php if($extra['LightNumber'] == 0){ echo 'none;';}?>"><td colspan="3"><a href="javascript:void(0);" onclick="checkAndSaveLight();" class="btn btn-middle"><span>Save</span></a>&nbsp;&nbsp;<span id="loadingImgLight" style="display:none; vertical-align: middle;"><img src="<?php echo site_url('assets/images/loading.gif');?>" alt="Loading...." width="32" height="32"></span></td></tr>
			</tbody>
		</table>
	</div>
	
	<div id="BlowerForm" style="display:none;">	
		<div style="margin-bottom:10px;"><h3 class="confHeader">Blower Configuration</h3></div>
		<table class="table removeBorder" id="blowerTable" width="100%" cellspacing="0" cellpadding="0">
			<tbody>
				<tr>
					<td style="width:48%;">Enter Number of Blowers to Use in system:</td>
					<td style="width:2%;">&nbsp;</td>
					<td style="width:50%;"><input type="text" name="blowerNumber" id="blowerNumber" onkeyup="showBlowerDetails();" value="<?php if(isset($extra['BlowerNumber']) && $extra['BlowerNumber'] != 0) { echo $extra['BlowerNumber'];}?>" class="form-control inputText"></td>
				</tr>
				<?php 
					  for($i=1;$i<4;$i++)
					  {
				?>
						<tr id="blowerDetails_<?php echo $i;?>">
							<td colspan="3">
								<table border="0" cellspacing="0" cellpadding="0" width="100%">
									<tr><td colspan="3"><strong>Blower <?php echo $i;?></strong></td></tr>
									<tr>
									<td width="48%">How do you turn on your Blower <?php echo $i;?>?</td>
									<td width="2%">&nbsp;</td>
									<td width="50%">
										<select onchange="showRelaysBlower(this.value,'<?php echo $i;?>');" class="form-control valid" id="blower<?php echo $i;?>_equiment" name="blower<?php echo $i;?>_equiment">
											<option value="24">24V AC Relays</option>
											<option value="12">12V DC Relays</option>
										</select>
									</td>
									</tr>
									<tr><td colspan="3">&nbsp;</td></tr>
									<tr id="trBlowerSub<?php echo $i;?>_24">
									<td width="48%"><label for="blower<?php echo $i;?>_sub_equiment_24">Select 24V Relay<span class="requiredMark">*</span></label></td>
									<td width="2%">&nbsp;</td>
									<td width="50%">
									<select name="blower<?php echo $i;?>_sub_equiment_24" id="blower<?php echo $i;?>_sub_equiment_24" class="form-control">
										<option value="">Select Relay</option>
										<?php foreach($sRelays as $relay) {
										?>
											<option value="<?php echo $relay;?>">Relay <?php echo $relay;?></option>
										<?php } ?>
									</select>
									</td>
									</tr>
				
									<tr id="trBlowerSub<?php echo $i;?>_12" style="display:none;">
									<td width="48%"><label for="blower<?php echo $i;?>_sub_equiment_12">Select 12V Relay<span class="requiredMark">*</span></label></td>
									<td width="2%">&nbsp;</td>
									<td width="50%">
										<select name="blower<?php echo $i;?>_sub_equiment_12" id="blower<?php echo $i;?>_sub_equiment_12" class="form-control">
											<option value="">Select Relay</option>
											<?php foreach($sPowercenter as $relay) { ?>
											<option value="<?php echo $relay;?>">Relay <?php echo $relay;?></option>
											<?php } ?>
										</select>
									</td></tr>
									
									<tr><td colspan="3"><hr style="border-color:#000;" /></td></tr>
								</table>
							</td>
						</tr>
				<?php 
					}
				?>	
				<tr id="blowerSaveConf" style="display:<?php if($extra['BlowerNumber'] == 0){ echo 'none;';}?>"><td colspan="3"><a href="javascript:void(0);" onclick="checkAndSaveBlower();" class="btn btn-middle"><span>Save</span></a>&nbsp;&nbsp;<span id="loadingImgBlower" style="display:none; vertical-align: middle;"><img src="<?php echo site_url('assets/images/loading.gif');?>" alt="Loading...." width="32" height="32"></span></td></tr>
			</tbody>
		</table>
	</div>
	
	<div id="pumpForm" style="display:none;">	
		<div style="margin-bottom:10px;"><h3 class="confHeader">Pump Configuration</h3></div>
		<table class="table removeBorder" id="pumpTable" width="100%" cellspacing="0" cellpadding="0">
			<tbody>
				<tr>
					<td style="width:48%;">Enter Number of Pumps to Use in system:</td>
					<td style="width:2%;">&nbsp;</td>
					<td style="width:50%;"><input type="text" name="pumpNumber" id="pumpNumber" onkeyup="showPumpDetails();" value="<?php if(isset($extra['PumpsNumber']) && $extra['PumpsNumber'] != 0) { echo $extra['PumpsNumber'];}?>" class="form-control inputText"></td>
				</tr>
				<?php for($i=0;$i<3;$i++)
				{
					$sPumpDetails = $this->home_model->getPumpDetails($i);
					//Variable Initialization to blank.
					$sPumpNumber  	= '';
					$sPumpType  	= '';
					$sPumpSubType  	= '';
					$sPumpSpeed  	= '';
					$sPumpFlow 		= '';
					$sPumpClosure   = '';
					$sRelayNumber  	= '';
					$sPumpAddress	= '';
					$sRelayNumber1	= '';
					if(is_array($sPumpDetails) && !empty($sPumpDetails))
					{
					  foreach($sPumpDetails as $aResultEdit)
					  { 
						$sPumpNumber  = $aResultEdit->pump_number;
						$sPumpType    = $aResultEdit->pump_type;
						$sPumpSubType = $aResultEdit->pump_sub_type;
						$sPumpSpeed   = $aResultEdit->pump_speed;
						$sPumpFlow    = $aResultEdit->pump_flow;
						$sPumpClosure = $aResultEdit->pump_closure;
						$sRelayNumber = $aResultEdit->relay_number;
						$sPumpAddress = $aResultEdit->pump_address;
						$sRelayNumber1= $aResultEdit->relay_number_1;		
					  }
					}
				?>
				<tr id="trPumpDetails<?php echo $i;?>" style="display:<?php if($sPumpNumber == ''){ echo 'none;';}?>">
				<td colspan="3">
				  <table border="0" cellspacing="0" cellpadding="0" width="100%">
					  <tr id="trVSClosure">
						<td width="10%"><strong>Pump Closure:</strong></td>
						<td width="1%">&nbsp;</td>
						<td width="89%">
							<div class="rowCustom">
							<div class="colCustom" style="padding-left:0;">
							  <input type="radio" name="sPumpClosure_<?php echo $i;?>" id="sPumpClosure0_<?php echo $i;?>" value="0" <?php if($sPumpClosure == '0') { echo 'checked="checked"'; } ?> required <?php if($sAccess == 1){ echo 'disabled="disabled";';}	?>><lable style="margin-left: 5px;">No contact closure</lable>
							  <input type="radio" name="sPumpClosure_<?php echo $i;?>" id="sPumpClosure1_<?php echo $i;?>" value="1" <?php if($sPumpClosure == '1') { echo 'checked="checked"'; } ?> required <?php if($sAccess == 1){ echo 'disabled="disabled";';}?>><lable style="margin-left: 5px;">Contact closure 1</lable>
						   </div>
							</div>
						</td>
					  </tr>
					  <tr><td colspan="3">&nbsp;</td></tr>
					  <tr>
						<td width="10%"><strong>Pump Number:</strong></td>
						<td width="1%">&nbsp;</td>
						<td width="89%"><input type="text" placeholder="Enter Pump Number" name="sPumpNumber_<?php echo $i;?>" class="inputText" value="<?php echo $i;?>" id="sPumpNumber_<?php echo $i;?>" required <?php if($sAccess == 1){ echo 'disabled="disabled";';}?>></td>
					  </tr>
					  <tr><td colspan="3">&nbsp;</td></tr>

					  <tr>
						<td width="10%"><strong>Pump Type:</strong></td>
						<td width="1%">&nbsp;</td>
						<td width="89%">
						<select name="sPumpType_<?php echo $i;?>" id="sPumpType_<?php echo $i;?>" <?php if($sAccess == 1){ echo 'disabled="disabled";';}?> onchange="showDetailsPump(this.value,'<?php echo $i;?>');" class="form-control" style="width:50%">
						<option value="12" <?php if($sPumpType == '12'){echo 'selected="selected";';}?> >12V DC</option>
						<option value="24" <?php if($sPumpType == '24'){echo 'selected="selected";';}?>>24V AC</option>
						<option value="2Speed" <?php if($sPumpType == '2Speed'){echo 'selected="selected";';}?>>2 Speed</option>
						<option value="Intellicom" <?php if($sPumpType == 'Intellicom'){echo 'selected="selected";';}?>>Intellicom for a Pentair VS or VF Pump</option>
						<option value="Intellicom12" <?php if($sPumpType == 'Intellicom12'){echo 'selected="selected";';}?>>Intellicom for a Pentair VS or VF Pump 12V DC</option>
						<option value="Intellicom24" <?php if($sPumpType == 'Intellicom24'){echo 'selected="selected";';}?>>Intellicom for a Pentair VS or VF Pump 24V AC</option>
						<option value="Emulator" <?php if($sPumpType == 'Emulator'){echo 'selected="selected";';}?>>Emulator Pentair VS or VF Pump</option>
						<option value="Emulator12" <?php if($sPumpType == 'Emulator12'){echo 'selected="selected";';}?>>Emulator Pentair VS or VF Pump 12V DC</option>
						<option value="Emulator24" <?php if($sPumpType == 'Emulator24'){echo 'selected="selected";';}?>>Emulator Pentair VS or VF Pump 24V AC</option>
						</select>
						</td>
					  </tr>
					  
					  <tr id="pumpSubType2SpeedTrBlk_<?php echo $i;?>" style="display:<?php if($sPumpType == '2Speed'){echo '';}else{echo 'none;';} ?>"><td colspan="3">&nbsp;</td></tr>
					  <tr id="pumpSubType2SpeedTr_<?php echo $i;?>" style="display:<?php if($sPumpType == '2Speed'){echo '';}else{echo 'none;';} ?>">
						<td width="10%"><strong>Select Relay:</strong></td>
						<td width="1%">&nbsp;</td>
						<td width="89%">
							<select name="sPumpSubType1_<?php echo $i;?>" id="sPumpSubType1_<?php echo $i;?>" <?php if($sAccess == 1){ echo 'disabled="disabled";';}?> class="form-control" style="width:50%">
							<option value="12" <?php if($sPumpSubType == '12'){echo 'selected="selected";';}?>>12V DC</option>
							<option value="24" <?php if($sPumpSubType == '24'){echo 'selected="selected";';}?>>24V AC</option>
							</select>
						</td>
					  </tr>
					  
					  <tr id="pumpSubTypeTrBlk_<?php echo $i;?>" style="display:<?php if(preg_match('/Emulator/',$sPumpType)){echo '';}else{echo 'none;';} ?>"><td colspan="3">&nbsp;</td></tr>
					  <tr id="pumpSubTypeTr_<?php echo $i;?>" style="display:<?php if(preg_match('/Emulator/',$sPumpType)){echo '';}else{ echo'none;';} ?>;">
						<td width="10%"><strong>Pump Sub Type:</strong></td>
						<td width="1%">&nbsp;</td>
						<td width="89%">
							<select name="sPumpSubType_<?php echo $i;?>" id="sPumpSubType_<?php echo $i;?>" <?php if($sAccess == 1){ echo 'disabled="disabled";';}?> class="form-control" style="width:50%" onchange="subTypeDetails(this.value,'<?php  echo $i;?>')">
							<option value="VS" <?php if($sPumpSubType == 'VS'){echo 'selected="selected";';}?>>VS Pump (Variable Speed)</option>
							<option value="VF" <?php if($sPumpSubType == 'VF'){echo 'selected="selected";';}?>>VF Pump (Variable Flow)</option>
							</select>
						</td>
					  </tr>
					  
					  <tr id="trVSSpaceIntellicom_<?php echo $i;?>" style="display:<?php if(preg_match('/Intellicom/',$sPumpType)) { echo ''; } else { echo 'none';} ?>;"><td colspan="3">&nbsp;</td></tr>
					  <tr id="trVSIntellicom_<?php echo $i;?>" style="display:<?php if(preg_match('/Intellicom/',$sPumpType)) { echo ''; } else { echo 'none';} ?>;">
						<td width="10%"><strong>Pump Speed:</strong></td>
						<td width="1%">&nbsp;</td>
						<td width="89%">
							<div class="rowCustom">
							  <input type="radio" name="sPumpSpeedIn_<?php echo $i;?>" id="sPumpSpeedIn0_<?php echo $i;?>" value="0" <?php if($sPumpSpeed == '0') { echo 'checked=""checked';} ?> <?php if($sAccess == 1){ echo 'disabled="disabled";';}?>><lable style="margin-left: 5px;">0</lable>
							  <input type="radio" name="sPumpSpeedIn_<?php echo $i;?>" id="sPumpSpeedIn1_<?php echo $i;?>" value="1" <?php if($sPumpSpeed == '1') { echo 'checked=""checked';} ?> <?php if($sAccess == 1){ echo 'disabled="disabled";';}?>><lable style="margin-left: 5px;">1</lable>
							  <input type="radio" name="sPumpSpeedIn_<?php echo $i;?>" id="sPumpSpeedIn2_<?php echo $i;?>" value="2" <?php if($sPumpSpeed == '2') { echo 'checked=""checked';} ?> <?php if($sAccess == 1){ echo 'disabled="disabled";';}?>><lable style="margin-left: 5px;">2</lable>
							  <input type="radio" name="sPumpSpeedIn_<?php echo $i;?>" id="sPumpSpeedIn3_<?php echo $i;?>" value="3" <?php if($sPumpSpeed == '3') { echo 'checked=""checked';} ?> <?php if($sAccess == 1){ echo 'disabled="disabled";';}?>><lable style="margin-left: 5px;">3</lable>
							  <input type="radio" name="sPumpSpeedIn_<?php echo $i;?>" id="sPumpSpeedIn4_<?php echo $i;?>" value="4" <?php if($sPumpSpeed == '4') { echo 'checked=""checked';} ?> <?php if($sAccess == 1){ echo 'disabled="disabled";';}?>><lable style="margin-left: 5px;">4</lable>
						   </div>
						</td>
					  </tr>
					  
					  <tr id="trVSSpace_<?php echo $i;?>" style="display:<?php if($sPumpSubType =='VS' && preg_match('/Emulator/',$sPumpType)) { echo ''; } else { echo 'none';} ?>;"><td colspan="3">&nbsp;</td></tr>
					  <tr id="trVS_<?php echo $i;?>" style="display:<?php if($sPumpSubType =='VS' && preg_match('/Emulator/',$sPumpType)) { echo ''; } else { echo 'none';} ?>;">
						<td width="10%"><strong>Pump Speed:</strong></td>
						<td width="1%">&nbsp;</td>
						<td width="89%">
							<div class="rowCustom">
							<div class="colCustom" style="padding-left:0;">
							  <input type="radio" name="sPumpSpeed_<?php echo $i;?>" id="sPumpSpeed0_<?php echo $i;?>" value="0" <?php if($sPumpSpeed == '0') { echo 'checked=""checked';} ?> <?php if($sAccess == 1){ echo 'disabled="disabled";';}?>><lable style="margin-left: 5px;">0</lable>
							  <input type="radio" name="sPumpSpeed_<?php echo $i;?>" id="sPumpSpeed1_<?php echo $i;?>" value="1" <?php if($sPumpSpeed == '1') { echo 'checked=""checked';} ?> <?php if($sAccess == 1){ echo 'disabled="disabled";';}?>><lable style="margin-left: 5px;">1</lable>
							  <input type="radio" name="sPumpSpeed_<?php echo $i;?>" id="sPumpSpeed2_<?php echo $i;?>" value="2" <?php if($sPumpSpeed == '2') { echo 'checked=""checked';} ?> <?php if($sAccess == 1){ echo 'disabled="disabled";';}?>><lable style="margin-left: 5px;">2</lable>
							  <input type="radio" name="sPumpSpeed_<?php echo $i;?>" id="sPumpSpeed3_<?php echo $i;?>" value="3" <?php if($sPumpSpeed == '3') { echo 'checked=""checked';} ?> <?php if($sAccess == 1){ echo 'disabled="disabled";';}?>><lable style="margin-left: 5px;">3</lable>
							  <input type="radio" name="sPumpSpeed_<?php echo $i;?>" id="sPumpSpeed4_<?php echo $i;?>" value="4" <?php if($sPumpSpeed == '4') { echo 'checked=""checked';} ?> <?php if($sAccess == 1){ echo 'disabled="disabled";';}?>><lable style="margin-left: 5px;">4</lable>
						   </div>
						 </div>
						</td>
					  </tr>
					  <tr id="trVFSpace_<?php echo $i;?>" style="display:<?php if($sPumpSubType =='VF' && $sPumpType == 'Emulator') { echo ''; } else { echo 'none';} ?>;"><td colspan="3">&nbsp;</td></tr>
					  <tr id="trVF_<?php echo $i;?>" style="display:<?php if($sPumpSubType =='VF' && $sPumpType == 'Emulator') { echo ''; } else { echo 'none';} ?>;">
						<td width="10%"><strong>Pump Flow:</strong></td>
						<td width="1%">&nbsp;</td>
						<td width="89%"><input type="text" name="sPumpFlow_<?php echo $i;?>" id="sPumpFlow_<?php echo $i;?>" value="<?php echo $sPumpFlow;?>" class="inputText" <?php if($sAccess == 1){ echo 'disabled="disabled";';}?>>
						</td>
					  </tr>
					  <tr id="trRelayNumberSpace_<?php echo $i;?>" <?php if($sPumpType == 'Intellicom' || $sPumpType == 'Emulator') { echo 'style="display:none;"';} ?>><td colspan="3">&nbsp;</td></tr>
					  <tr id="trRelayNumber_<?php echo $i;?>" <?php if($sPumpType == 'Intellicom' || $sPumpType == 'Emulator') { echo 'style="display:none;"';} ?>>
						<td width="10%"><strong>Relay Number:</strong></td>
						<td width="1%">&nbsp;</td>
						<td width="89%"><input type="text" class="inputText" name="sRelayNumber_<?php echo $i;?>" id="sRelayNumber_<?php echo $i;?>" value="<?php echo $sRelayNumber;?>" <?php if($sPumpType != 'Intellicom' && $sPumpType != 'Emulator'  ) { echo 'required';} ?> <?php if($sAccess == 1){ echo 'disabled="disabled";';}?>>
						</td>
					  </tr>
					  <tr id="trRelayNumber1Space_<?php echo $i;?>" <?php if($sPumpType == '2Speed') { echo '';} else { echo 'style="display:none;"';}?>><td colspan="3">&nbsp;</td></tr>
					  <tr id="trRelayNumber1_<?php echo $i;?>" <?php if($sPumpType == '2Speed') { echo '';} else { echo 'style="display:none;"';}?>>
						<td width="10%"><strong>Relay Number 2:</strong></td>
						<td width="1%">&nbsp;</td>
						<td width="89%"><input type="text" class="inputText" name="sRelayNumber1_<?php echo $i;?>" id="sRelayNumber1_<?php echo $i;?>" value="<?php echo $sRelayNumber1;?>" <?php if($sPumpType == '2Speed') { echo 'required';} ?> <?php if($sAccess == 1){ echo 'disabled="disabled";';}?>>
						</td>
					  </tr>
					  
					  <tr id="trAddressNumberSpace_<?php echo $i;?>" <?php if($sPumpType == '12' || $sPumpType == '24' || $sPumpType == '2Speed' || $sPumpType == '') { echo 'style="display:none;"';} ?>><td colspan="3">&nbsp;</td></tr>
					  <tr id="trAddressNumber_<?php echo $i;?>" <?php if($sPumpType == '12' || $sPumpType == '24' || $sPumpType == '2Speed' || $sPumpType == '') { echo 'style="display:none;"';} ?>>
						<td width="10%"><strong>Pump Address:</strong></td>
						<td width="1%">&nbsp;</td>
						<td width="89%"><input type="text" class="inputText" name="sPumpAddress_<?php echo $i;?>" id="sPumpAddress_<?php echo $i;?>" value="<?php echo $sPumpAddress;?>" <?php if($sPumpType != '12' && $sPumpType != '24' && $sPumpType != '2Speed') { echo 'required';} ?> <?php if($sAccess == 1){ echo 'disabled="disabled";';}?>>
						</td>
					  </tr>
					  <tr><td colspan="3"><hr style="border-color:#000;" /></td></tr>
					 </table>
					</td>
				</tr>
				
			<?php } ?>
			<tr id="pumpSaveConf" style="display:<?php if($extra['PumpsNumber'] == 0){ echo 'none;';}?>"><td colspan="3"><a href="javascript:void(0);" onclick="checkAndSavePumps();" class="btn btn-middle"><span>Save</span></a>&nbsp;&nbsp;<span id="loadingImgPump" style="display:none; vertical-align: middle;"><img src="<?php echo site_url('assets/images/loading.gif');?>" alt="Loading...." width="32" height="32"></span></td></tr>
			</tbody>
		</table>	
	</div>

</div>
</div>
<script type="text/javascript">

	//$("#sPumpType").change(function(){
	function showDetailsPump(sSelectedVal,i)
	{	
		//var sSelectedVal	=	$(this).val();
		if(sSelectedVal == 'Emulator' || sSelectedVal == 'Emulator12' || sSelectedVal == 'Emulator24')
		{
			$("#pumpSubTypeTr_"+i).show();
			$("#pumpSubTypeTrBlk_"+i).show();
			
			$("input:radio[name='sPumpSpeed_"+i+"']").attr('required','required');
		    $("#sPumpFlow_"+i).removeAttr('required');
		    $("#trVF_"+i).hide();
		    $("#trVFSpace_"+i).hide();
		  
		    $("#trVS_"+i).show(); 
		    $("#trVSSpace_"+i).show();
		}
		else
		{
			$("#pumpSubTypeTr_"+i).hide();
			$("#pumpSubTypeTrBlk_"+i).hide();
			
			$("#trVS_"+i).hide(); 
		    $("#trVSSpace_"+i).hide();
			$("input:radio[name='sPumpSpeed_"+i+"']").removeAttr('required');
			$("#sPumpFlow_"+i).removeAttr('required');
			$("#trVF_"+i).hide();
		    $("#trVFSpace_"+i).hide();
		}
		
		if(sSelectedVal == 'Emulator' || sSelectedVal == 'Intellicom')
		{
			$("#trRelayNumberSpace_"+i).hide();
			$("#trRelayNumber_"+i).hide();
			$("#sRelayNumber_"+i).removeAttr('required');
		}
		else
		{
			$("#trRelayNumberSpace_"+i).show();
			$("#trRelayNumber_"+i).show();
			$("#sRelayNumber_"+i).attr('required','required');
		}
		
		if(sSelectedVal == '12' || sSelectedVal == '24' || sSelectedVal == '2Speed')
		{
			$("#trAddressNumberSpace_"+i).hide();
			$("#trAddressNumber_"+i).hide();
			$("#sPumpAddress_"+i).removeAttr('required');
		}
		else
		{
			$("#trAddressNumberSpace_"+i).show();
			$("#trAddressNumber_"+i).show();
			$("#sPumpAddress_"+i).attr('required','required');
		}
		
		if(sSelectedVal == 'Intellicom' || sSelectedVal == 'Intellicom12' || sSelectedVal == 'Intellicom24')
		{
			$("input:radio[name='sPumpSpeedIn_"+i+"']").attr('required','required');
		    
		    $("#trVSIntellicom_"+i).show(); 
		    $("#trVSSpaceIntellicom_"+i).show();
		}
		else
		{
			$("input:radio[name='sPumpSpeedIn_"+i+"']").removeAttr('required');
			$("#trVSIntellicom_"+i).hide();
		    $("#trVSSpaceIntellicom_"+i).hide();
		}
		
		if(sSelectedVal == '2Speed')
		{
			$("input:radio[name='sRelayNumber1_"+i+"']").attr('required','required');
		    
		    $("#trRelayNumber1Space_"+i).show(); 
		    $("#trRelayNumber1_"+i).show();
			$("#pumpSubType2SpeedTrBlk_"+i).show(); 
		    $("#pumpSubType2SpeedTr_"+i).show();
			$("#trAddressNumberSpace_"+i).hide();
			$("#trAddressNumber_"+i).hide();
			$("input:radio[name='sPumpAddress_"+i+"']").removeAttr('required');
		}
		else
		{
			$("input:radio[name='sRelayNumber1_"+i+"']").removeAttr('required');
		    
		    $("#trRelayNumber1Space_"+i).hide(); 
		    $("#trRelayNumber1_"+i).hide();
			$("#pumpSubType2SpeedTrBlk_"+i).hide(); 
		    $("#pumpSubType2SpeedTr_"+i).hide();
		}
	}
	function subTypeDetails(sSelectedVal,i)
	{
	//$("#sPumpSubType").change(function() {
		
    //var sSelectedVal	=	$(this).val();
    if(sSelectedVal == 'VF' && $("#sPumpType_"+i).val() == 'Emulator')
    {
	  $("#sPumpFlow_"+i).attr('required','required');
      $("input:radio[name='sPumpSpeed_"+i+"']").removeAttr('required');
	  $("input:radio[name='sPumpClosure_"+i+"']").removeAttr('required');

      $("#trVF_"+i).show();
      $("#trVFSpace_"+i).show();
      
      $("#trVS_"+i).hide();
      $("#trVSSpace_"+i).hide();
	  
    }
    else if(sSelectedVal == 'VS' && $("#sPumpType_"+i).val() == 'Emulator')
    {
      $("input:radio[name='sPumpSpeed_"+i+"']").attr('required','required');
	  $("input:radio[name='sPumpClosure_"+i+"']").attr('required','required');
      $("#sPumpFlow_"+i).removeAttr('required');
      $("#trVF_"+i).hide();
      $("#trVFSpace_"+i).hide();
      
      $("#trVS_"+i).show(); 
      $("#trVSSpace_"+i).show();
	  
    }
  }
</script>
	