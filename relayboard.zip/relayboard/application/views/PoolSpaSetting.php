<?php


$sAccess 		 = '';
$sModule	    = 2;

//Get Permission Details
$userID = $this->session->userdata('id');
$aPermissions = json_decode(getPermissionOfModule($userID));

$aModules 		= $aPermissions->sPermissionModule;	
$aAllActiveModule = $aPermissions->sActiveModule;

$sAccessKey	= 'access_'.$sModule;

if(!empty($aModules))
{
  if(in_array($sModule,$aModules->ids))
  {
	 $sAccess 		= $aModules->$sAccessKey;
  }
}

if($sAccess == '')
$sAccess = '2' ;

?>
<style>
.requiredMark
{
	color: #ff0000;
}
.questionText
{
	line-height:15px;
}
.trClass
{
	vertical-align:top !important;
}
.inputText
{
	height:35px !important;
}
</style>
<div class="row">
	<div class="col-lg-12">
		<ol class="breadcrumb">
		  <li><img src="<?php echo HTTP_IMAGES_PATH.'icons/home.png';?>" width="24" style="vertical-align: middle !important;">&nbsp;<a href="<?php echo site_url();?>">Home</a> </li>
		  <li class="active">Pool & Spa Setting</li>
		</ol>
	</div>
</div>
<form>
<div class="row">
	<div class="col-lg-12">
		<div><span style="color:#FFF;"><strong>Edit Pool & Spa Automation Question To Set Up Their Equipment Properly<strong></span><span style="color:#FF0000; float:right;"><strong>* indicates required field</strong></span></div>
	</div>
</div>

<div class="row">
<div class="col-lg-12">&nbsp;</div>
</div>

<div class="row">
	<div class="col-sm-6">
		<div class="widget-container widget-tags styled boxed">
			<div class="inner" style="padding-left:15px; padding-right:15px;">
				<div class="tagcloud clearfix">
				<table>
				<thead>
				<tr><th style="width:60%">&nbsp;</th><th style="width:2%">&nbsp;</th><th style="width:38%">&nbsp;</th></tr>
				</thead>
				<tbody>
				<tr>
				<td class="trClass"><span class="questionText">Do you have a pool only, spa only and or a pool and spa?:<span class="requiredMark">*</span></span></td>
				<td>&nbsp;</td>
				<td>
					<select name="strType" id="strType" class="form-control">
						<option value="">Select Type</option>
						<option value="pool">Pool only</option>
						<option value="spa">Spa only</option>
						<option selected="" value="both">Pool and Spa</option>
					</select>
				</td>
				</tr>
				<tr><td colspan="3">&nbsp;</td></tr>
				<tr>
				<td class="trClass"><span class="questionText">How do you control your equipment?:<span class="requiredMark">*</span></span></td>
				<td>&nbsp;</td>
				<td>
					<select name="strEquipment" id="strEquipment" class="form-control">
						<option value="">Select Equipment</option>
						<option value="1">Intermatic z wave Controller PE 653</option>
						<option value="2">Raspberry PI Purchased</option>
						<option value="3">Other or Manually Operated</option>
						<option selected="" value="4">Both</option>
					</select>
				</td>
				</tr>
				<tr><td colspan="3">&nbsp;</td></tr>
				<tr>
				<td class="trClass"><span class="questionText">How many AUTOMATIC valves do you have on your pool and or pool/spa system?:<span class="requiredMark">*</span></span></td>
				<td>&nbsp;</td>
				<td>
					<select name="strValve" id="strValve" class="form-control">
					<option value="">Select valves</option>
						<option value="0">0 Valves</option>
						<option value="1">1 Valves</option>
						<option selected="" value="2">2 Valves</option>
						<option value="3">3 Valves</option>
						<option value="4">4 Valves</option>
						<option value="5">5 Valves</option>
					</select>
				</td>
				</tr>
				<tr><td colspan="3">&nbsp;</td></tr>
				<tr>
				<td class="trClass"><span class="questionText">If necessary, Which valve(s) is actuated when you switch from Pool to Spa Mode?:<span class="requiredMark">*</span></span></td>
				<td>&nbsp;</td>
				<td>
					<select name="valve_actuated[]" id="valve_actuated" class="form-control" multiple="">
					<option value="">Select Valve Quantity</option>
					<option value="0">Valve 0 is actuated</option>
					<option value="1" selected="selected">Valve 1 is actuated</option>
					<option value="2" selected="selected">Valve 2 is actuated</option>
					</select>
				</td>
				</tr>
				<tr><td colspan="3">&nbsp;</td></tr>
				<tr>
				<td class="trClass"><span class="questionText">How many Pumps do you have?:<span class="requiredMark">*</span></span></td>
				<td>&nbsp;</td>
				<td>
					<select name="automatic_pumps" id="automatic_pumps" class="form-control">
					<option value="">Total Pumps</option>
					<option value="1">1 Pump</option>
					<option selected="" value="2">2 Pump</option>
					<option value="3">3 Pump</option>
					<option value="4">4 Pump</option>
					<option value="5">5 Pump</option>
					</select>
				</td>
				</tr>
				<tr><td colspan="3">&nbsp;</td></tr>
				<tr>
				<td class="trClass"><span class="questionText">How many heaters do you have?:<span class="requiredMark">*</span></span></td>
				<td>&nbsp;</td>
				<td>
					<select name="automatic_heaters_question1" id="automatic_heaters_question1" class="form-control">
					<option value="">Number of Heating Devices</option>
					<option selected="" value="1">1 Heater</option>
					<option value="2">2 Heater</option>
					<option value="3">3 Heater</option>
					</select>
				</td>
				</tr>
				
				<tr><td colspan="3">&nbsp;</td></tr>
				<tr>
				<td class="trClass"><span class="questionText">How do you turn on your Heater 1:<span class="requiredMark">*</span></span></td>
				<td>&nbsp;</td>
				<td>
					<select name="heater1_equiment" id="heater1_equiment" class="form-control">
					<option value="">Select Equipment</option>
					<option value="1">Intermatic z wave Controller PE 653</option>
					<option selected="" value="2">Raspberry PI Purchased</option>
					<option value="3">Other or Manually Operated</option>
					</select>
				</td>
				</tr>
				
				<tr><td colspan="3">&nbsp;</td></tr>
				<tr>
				<td class="trClass"><span class="questionText">Which Pump has to be on in order to operate Heater 1:<span class="requiredMark">*</span></span></td>
				<td>&nbsp;</td>
				<td>
					<select name="heater1_equiment_pump" id="heater1_equiment_pump" class="form-control">
					<option value="">Select Pump </option>
					<option value="1" selected="selected"> Pump 1</option>
					<option value="2"> Pump 2</option>
					</select>
				</td>
				</tr>
				
				<tr><td colspan="3">&nbsp;</td></tr>
				<tr>
				<td class="trClass"><span class="questionText">How many Spa/Pool lights do you have?:<span class="requiredMark">*</span></span></td>
				<td>&nbsp;</td>
				<td>
					<select name="no_light" id="no_light" class="form-control">
						<option value="">Select number of lights</option>
						<option value="1">1 Light</option>
						<option selected="" value="2">2 Light</option>
						<option value="3">3 Light</option>
						<option value="4">4 Light</option>
					</select>
				</td>
				</tr>
				
				<tr><td colspan="3">&nbsp;</td></tr>
				<tr>
				<td class="trClass"><span class="questionText">How many Spa devices do you have?:<span class="requiredMark">*</span></span></td>
				<td>&nbsp;</td>
				<td>
					<select name="no_blower" id="no_blower" class="form-control">
						<option value="">Select number of blowers</option>
						<option value="1">1 Blower</option>
						<option selected="" value="2">2 Blower</option>
						<option value="3">3 Blower</option>
						<option value="4">4 Blower</option>
					</select>
				</td>
				</tr>
				
				<tr><td colspan="3">&nbsp;</td></tr>
				<tr>
				<td class="trClass"><span class="questionText">How do you read the temperature of the pool water?:<span class="requiredMark">*</span></span></td>
				<td>&nbsp;</td>
				<td>
					<select name="read_temp_pool" id="read_temp_pool" class="form-control">
						<option value="">Select Equipment</option>
						<option value="1">Intermatic z wave Controller PE 653</option>
						<option selected="" value="2">Raspberry PI Purchased</option>
						<option value="3">Other or Manually Operated</option>
						
					</select>
				</td>
				</tr>
				
				<tr><td colspan="3">&nbsp;</td></tr>
				<tr>
				<td class="trClass"><span class="questionText">How do you read the temperature of the spa water water?:<span class="requiredMark">*</span></span></td>
				<td>&nbsp;</td>
				<td>
					<select name="read_temp_spa" id="read_temp_spa" class="form-control">
						<option value="">Select Equipment</option>
						<option value="1">Intermatic z wave Controller PE 653</option>
						<option selected="" value="2">Raspberry PI Purchased</option>
						<option value="3">Other or Manually Operated</option>
					
					</select>
				</td>
				</tr>
				
				<tr><td colspan="3">&nbsp;</td></tr>
				<tr>
				<td class="trClass"><span class="questionText">How do you read the temperature of the air temperature?:<span class="requiredMark">*</span></span></td>
				<td>&nbsp;</td>
				<td>
					<select name="read_temp_air" id="read_temp_air" class="form-control">
						<option value="">Select Equipment</option>
						<option value="1">Intermatic z wave Controller PE 653</option>
						<option selected="" value="2">Raspberry PI Purchased</option>
						<option value="3">Other or Manually Operated</option>
					
					</select>
				</td>
				</tr>
				
				</tbody>
				</table>
				</div>
			</div>
		</div>						
	</div>
	
	<div class="col-sm-6">
		<div class="widget-container widget-tags styled boxed">
			<div class="inner" style="padding-left:15px; padding-right:15px;">
				<div class="tagcloud clearfix">
				<table>
				<thead>
				<tr><th style="width:60%">&nbsp;</th><th style="width:2%">&nbsp;</th><th style="width:38%">&nbsp;</th></tr>
				</thead>
				<tbody>
				<tr>
				<td class="trClass"><span class="questionText">What is the maximum temperature expressed in Fahrenheit that you would like to be able to set the pool temperature to ?<span class="requiredMark">*</span></span></td>
				<td>&nbsp;</td>
				<td>
					<input type="text" name="pool_maximum_temperature" value="86" id="pool_maximum_temperature" class="form-control inputText">
				</td>
				</tr>
				<tr><td colspan="3">&nbsp;</td></tr>
				<tr>
				<td class="trClass"><span class="questionText">Desire pool temperature when user is in Pool Mode?<span class="requiredMark">*</span></span></td>
				<td>&nbsp;</td>
				<td>
					<input type="text" name="pool_temperature" value="85" id="pool_temperature" class="form-control inputText">
				</td>
				</tr>
				<tr><td colspan="3">&nbsp;</td></tr>
				<tr>
				<td class="trClass"><span class="questionText">Desire spa temperature when user is in Spa Mode?<span class="requiredMark">*</span></span></td>
				<td>&nbsp;</td>
				<td>
					<input type="text" name="spa_temperature" value="104" id="spa_temperature" class="form-control inputText">
				</td>
				</tr>
				<tr><td colspan="3">&nbsp;</td></tr>
				<tr>
				<td class="trClass"><span class="questionText">Display Pool Temp on mode Page yes or no?<span class="requiredMark">*</span></span></td>
				<td>&nbsp;</td>
				<td>
					<select name="display_pool_temp" id="display_pool_temp" class="form-control">
						<option selected="" value="Yes">Yes</option>
						<option value="No">No</option>
					</select>
				</td>
				</tr>
				<tr><td colspan="3">&nbsp;</td></tr>
				<tr>
				<td class="trClass"><span class="questionText">Display Spa Temp on mode Page yes or no?<span class="requiredMark">*</span></span></td>
				<td>&nbsp;</td>
				<td>
					<select name="display_spa_temp" id="display_spa_temp" class="form-control">
						<option selected="" value="Yes">Yes</option>
						<option value="No">No</option>
					</select>
				</td>
				</tr>
				<tr><td colspan="3">&nbsp;</td></tr>
				<tr>
				<td class="trClass"><span class="questionText">The maximum allotted time for Spa Mode expressed in minutes?<span class="requiredMark">*</span></span></td>
				<td>&nbsp;</td>
				<td>
					<input type="text" name="spa_allotted_time" value="200" id="spa_allotted_time" class="form-control inputText">
				</td>
				</tr>
				<tr><td colspan="3">&nbsp;</td></tr>
				<tr>
				<td class="trClass"><span class="questionText">The maximum allotted time for Pool Manual Mode expressed in minutes?<span class="requiredMark">*</span></span></td>
				<td>&nbsp;</td>
				<td>
					<input type="text" name="pool_allotted_time" value="120" id="pool_allotted_time" class="form-control inputText">
				</td>
				</tr>
				<tr><td colspan="3">&nbsp;</td></tr>
				<tr>
				<td class="trClass"><span class="questionText">After how many minutes, would you like to automatically turn the pool/spa lights OFF?<span class="requiredMark">*</span></span></td>
				<td>&nbsp;</td>
				<td>
					<input type="text" name="lights_off_time" value="90" id="lights_off_time" class="form-control inputText">
				</td>
				</tr>
				<tr><td colspan="3">&nbsp;</td></tr>
				<tr>
				<td class="trClass"><span class="questionText">After how many minutes, would you like to automatically turn the pool/spa blower OFF?<span class="requiredMark">*</span></span></td>
				<td>&nbsp;</td>
				<td>
					<input type="text" name="blowers_off_time" value="60" id="blowers_off_time" class="form-control inputText">
				</td>
				</tr>
				<tr><td colspan="3">&nbsp;</td></tr>
				<tr>
				<td class="trClass"><span class="questionText">Ip address for sensor ?<span class="requiredMark">*</span></span></td>
				<td>&nbsp;</td>
				<td>
					<input type="text" name="ip_address_sensor" value="172.250.133.144:82" id="ip_address_sensor" class="form-control inputText">
				</td>
				</tr>
				<tr><td colspan="3">&nbsp;</td></tr>
				<tr>
				<td class="trClass"><span class="questionText">Temperature Sensor 0:<span class="requiredMark">*</span></span></td>
				<td>&nbsp;</td>
				<td>
					<select name="temp_sensor_0" id="temp_sensor_0" class="form-control">
					<option value="">Select Temperature</option>
					<option selected="" value="Air Temperature">Air Temperature</option>
					<option value="Motor Temperature">Motor Temperature</option>
					<option value="Pool Water Temperature">Pool Water Temperature</option>
					<option value="Spa Water Temperature">Spa Water Temperature</option>
					<option value="Not Applicable">Not Applicable</option>
					</select>
				</td>
				</tr>
				
				<tr><td colspan="3">&nbsp;</td></tr>
				<tr>
				<td class="trClass"><span class="questionText">Temperature Sensor 1:<span class="requiredMark">*</span></span></td>
				<td>&nbsp;</td>
				<td>
					<select class="form-control" name="temp_sensor_1" id="temp_sensor_1">
						<option value="">Select Temperature</option>
						<option value="Air Temperature" disabled="disabled">Air Temperature</option>
						<option selected="" value="Motor Temperature">Motor Temperature</option>
						<option value="Pool Water Temperature" disabled="disabled">Pool Water Temperature</option>
						<option value="Spa Water Temperature" disabled="disabled">Spa Water Temperature</option>
						<option value="Not Applicable" disabled="disabled">Not Applicable</option>
					</select>
				</td>
				</tr>
				
				<tr><td colspan="3">&nbsp;</td></tr>
				<tr>
				<td class="trClass"><span class="questionText">Temperature Sensor 2:<span class="requiredMark">*</span></span></td>
				<td>&nbsp;</td>
				<td>
					<select class="form-control" name="temp_sensor_2" id="temp_sensor_2">
						<option value="">Select Temperature</option>
						<option value="Air Temperature" disabled="disabled">Air Temperature</option>
						<option selected="" value="Motor Temperature">Motor Temperature</option>
						<option value="Pool Water Temperature" disabled="disabled">Pool Water Temperature</option>
						<option value="Spa Water Temperature" disabled="disabled">Spa Water Temperature</option>
						<option value="Not Applicable" disabled="disabled">Not Applicable</option>
					</select>
				</td>
				</tr>
				
				<tr><td colspan="3">&nbsp;</td></tr>
				<tr>
				<td class="trClass"><span class="questionText">Temperature Sensor 3:<span class="requiredMark">*</span></span></td>
				<td>&nbsp;</td>
				<td>
					<select class="form-control" name="temp_sensor_3" id="temp_sensor_3">
						<option value="">Select Temperature</option>
						<option value="Air Temperature" disabled="disabled">Air Temperature</option>
						<option selected="" value="Motor Temperature">Motor Temperature</option>
						<option value="Pool Water Temperature" disabled="disabled">Pool Water Temperature</option>
						<option value="Spa Water Temperature" disabled="disabled">Spa Water Temperature</option>
						<option value="Not Applicable" disabled="disabled">Not Applicable</option>
					</select>
				</td>
				</tr>
				
				<tr><td colspan="3">&nbsp;</td></tr>
				<tr>
				<td class="trClass"><span class="questionText">Temperature Sensor 4:<span class="requiredMark">*</span></span></td>
				<td>&nbsp;</td>
				<td>
					<select class="form-control" name="temp_sensor_4" id="temp_sensor_4">
						<option value="">Select Temperature</option>
						<option value="Air Temperature" disabled="disabled">Air Temperature</option>
						<option selected="" value="Motor Temperature">Motor Temperature</option>
						<option value="Pool Water Temperature" disabled="disabled">Pool Water Temperature</option>
						<option value="Spa Water Temperature" disabled="disabled">Spa Water Temperature</option>
						<option value="Not Applicable" disabled="disabled">Not Applicable</option>
					</select>
				</td>
				</tr>
				
				<tr><td colspan="3">&nbsp;</td></tr>
				<tr>
				<td class="trClass"><span class="questionText">Temperature Sensor 5:<span class="requiredMark">*</span></span></td>
				<td>&nbsp;</td>
				<td>
					<select class="form-control" name="temp_sensor_5" id="temp_sensor_5">
						<option value="">Select Temperature</option>
						<option value="Air Temperature" disabled="disabled">Air Temperature</option>
						<option selected="" value="Motor Temperature">Motor Temperature</option>
						<option value="Pool Water Temperature" disabled="disabled">Pool Water Temperature</option>
						<option value="Spa Water Temperature" disabled="disabled">Spa Water Temperature</option>
						<option value="Not Applicable" disabled="disabled">Not Applicable</option>
					</select>
				</td>
				</tr>
				
				</tbody>
				</table>
				</div>
			</div>
		</div>						
	</div>
	</div>
	
	<div class="row">
	<div class="col-lg-12">&nbsp;</div>
	</div>
	
	<div class="row">
	<div class="col-lg-12" style="text-align:center;">
		<div>
			<div class="tagcloud clearfix">
				<span class="btn btn-middle"><input type="submit" name="command" value="Save Details"></span>
			</div>
		</div>	
	</div>
	</div>
	
</form>	
	