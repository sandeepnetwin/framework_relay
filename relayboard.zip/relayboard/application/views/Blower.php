<?php
$this->load->model('home_model');
$sAccess 		= '';
$sModule	    = '19';
$sDeviceFullName = '';
if($sDevice == 'B')
{
  $sDeviceFullName 	= 'Blower';
}

$sAccessKey	= 'access_'.$sModule;
			  
if(!empty($aModules))
{
    if(in_array($sModule,$aModules->ids))
    {
	 $sAccess 		= $aModules->$sAccessKey;
    }
	else if(!in_array($sModule,$aModules->ids)) 
    {
		$sAccess 		= '0'; 
    }
}
  
  if($sAccess == '')
	$sAccess = '2' ; 
  
  if($sAccess == '0') {redirect(site_url('home/'));} 
?>
<script type="text/javascript" src="<?php echo HTTP_ASSETS_PATH.'fancybox/source/jquery.fancybox.js?v=2.1.5';?>"></script>
<link rel="stylesheet" type="text/css" href="<?php echo HTTP_ASSETS_PATH.'fancybox/source/jquery.fancybox.css?v=2.1.5';?>" media="screen" />
<script type="text/javascript">
var $a = $.noConflict();
$a(document).ready(function() {
    $a('.fancybox').fancybox({'closeBtn' : false,
                              'helpers': {'overlay' : {'closeClick': false}}
                             });
});
</script>	
<link href="<?php echo HTTP_ASSETS_PATH.'progressbar/css/static.css';?>" rel="stylesheet"/>
<script src="<?php echo HTTP_ASSETS_PATH.'progressbar/js/static.min.js';?>"></script>
<script src="<?php echo HTTP_ASSETS_PATH.'progressbar/dist/js/jquery.progresstimer.js';?>"></script>
<script>
jQuery(document).ready(function($) 
{
    
    $(".relayRadio").click(function()
    {
        var chkVal 		= $(this).val();
        var relayNumber	= $(this).attr('name').split("_");	

        $.ajax({
                type: "POST",
                url: "<?php echo site_url('home/saveDeviceMainType');?>", 
                data: {sDeviceID:relayNumber[0],sDevice:'B',sType:chkVal},
                success: function(data) {
                        if(chkVal == 0)
                        {
                                $("#relay_other_"+relayNumber[0]).addClass('checked');
                                $("#relay_spa_"+relayNumber[0]).removeClass('checked');
                                $("#relay_pool_"+relayNumber[0]).removeClass('checked');
                        }
                        else if(chkVal == 1)
                        {
                                $("#relay_other_"+relayNumber[0]).removeClass('checked');
                                $("#relay_spa_"+relayNumber[0]).addClass('checked');
                                $("#relay_pool_"+relayNumber[0]).removeClass('checked');
                        }
                        else if(chkVal == 2)
                        {
                                $("#relay_other_"+relayNumber[0]).removeClass('checked');
                                $("#relay_spa_"+relayNumber[0]).removeClass('checked');
                                $("#relay_pool_"+relayNumber[0]).addClass('checked');
                        }

                }

            });
    });
    
    $(".lightButton").click(function(){
        var chkVal      = $(this).val();
        var arrDetails	= chkVal.split("|||");	
        
        var lightNumber = arrDetails[0];
        var relayNumber = arrDetails[2];
        var sDevice     = '';
        
        if(arrDetails[1] == '24')
            sDevice     =   'R';    
        else if(arrDetails[1] == '12')
            sDevice     =   'P';
        
        <?php if($iActiveMode == '2') { ?>
        $(".loading-progress").show();
        var progress = $(".loading-progress").progressTimer({
                timeLimit: 10,
                onFinish: function () {
                    //$(".loading-progress").hide();
                    parent.$a.fancybox.close();
                }
        });
        
        
        $a("#checkLink").trigger('click');

        var status		= '';
        if($("#lableRelay-"+lightNumber).hasClass('checked'))
        {	
                status	=	0;
        }
        else
        {
                status = 1;
        }


            $.ajax({
                type: "POST",
                url: "<?php echo site_url('home/updateStatusOnOff/');?>", 
                data: {sName:relayNumber,sStatus:status,sDevice:sDevice},
                success: function(data) {
                        if($("#lableRelay-"+lightNumber).hasClass('checked'))
                        {	
                                $("#lableRelay-"+lightNumber).removeClass('checked');
                                $("#lightImage_"+lightNumber).attr('src','<?php echo HTTP_IMAGES_PATH."icons/light_off.png";?>');
                                
                        }
                        else
                        {
                                $("#lableRelay-"+lightNumber).addClass('checked');
                                $("#lightImage_"+lightNumber).attr('src','<?php echo HTTP_IMAGES_PATH."icons/light_on.png";?>');
                        }

                }
        }).error(function(){
            progress.progressTimer('error', {
                errorText:'ERROR!',
                onFinish:function(){
                    alert('There was an error processing your information!');
                }
            });
        }).done(function(){
                progress.progressTimer('complete');
        });
            <?php } else {  ?>
            alert('You can perform this operation in manual mode only.');
            <?php } ?> 
    });
    
    
    $(".lightRadio").click(function()
    {
            var chkVal 		= $(this).val();
            var lightNumber	= $(this).attr('name').split("_");	

            if(chkVal == 24)
            {
                    $("#24VRelay_"+lightNumber[1]).show();
                    $("#12VRelay_"+lightNumber[1]).hide();
            }
            else if(chkVal == 12)
            {
                    $("#12VRelay_"+lightNumber[1]).show();
                    $("#24VRelay_"+lightNumber[1]).hide();
            }

    });
});
function cancel(lightNumber)
{
	$("#24VRelay_"+lightNumber).hide();
	$("#12VRelay_"+lightNumber).hide();
	
	$("#lightRelay24_"+lightNumber).prop('checked',false);
	$("#lightRelay12_"+lightNumber).prop('checked',false);
}

function save(lightNumber,relayType)
{
    $("#loadingImg"+relayType+"_"+lightNumber).show();
    var relayNumber	=	$("#select"+relayType+"VRelays_"+lightNumber).val();

    //Check if entered address already exists.
    var checkRelay = 0;
    $.ajax({
            type: "POST",
            url: "<?php echo site_url('home/checkRelayNumberAlreadyAssigned/');?>", 
            data: {sRelayNumber:relayNumber,type:relayType,sDeviceId:lightNumber},
            async: false,
            success: function(data) {
                    var obj = jQuery.parseJSON( data );
                    if(obj.iPumpCheck == '1')
                    {
                            checkRelay = 1;
                            $("#sRelayNumber").css('border','1px Solid Red');
                            alert('Relay number is already used by other Device or not available!');
                            //return false;
                    }
                    else
                    {
                        if(checkRelay == 0)
                        {
                                $.ajax({
                                        type: "POST",
                                        url: "<?php echo site_url('home/saveLightRelay/');?>", 
                                        async: false,
                                        data: {sRelayNumber:relayNumber,sDevice:'B',sDeviceId:lightNumber,sRelayType:relayType},
                                        async: false,
                                        success: function() {
                                            alert('Relay is assigned to Blower successfully!')
                                            location.reload();
                                        }
                                });
                        }
                    }
                    
                    $("#loadingImg"+relayType+"_"+lightNumber).hide();
            }
    });
}
</script>
<div class="row">
	<div class="col-sm-12">
		<ol class="breadcrumb" style="float:left">
		  <li><img src="<?php echo HTTP_IMAGES_PATH.'icons/home.png';?>" width="24" style="vertical-align: middle !important;">&nbsp;<a href="<?php echo site_url();?>">Home</a> </li>
		  <li class="active"><?php echo $sDeviceFullName;?></li>
		</ol>
	</div>
</div>	

<!-- START : Heater -->
<?php if($sDevice == 'B') 
	  { ?>
	<?php //if($sAccess == '1' || $sAccess == '2') 
		  { ?>
			<div class="row">
				<div class="col-sm-4">
					<div class="widget-container widget-stats boxed green-line">
							<div class="widget-title">
								<a href="<?php echo base_url('analog/showBlower');?>" class="link-refresh" id="link-refresh-1"><span class="glyphicon glyphicon-refresh"></span></a>
								<h3>ON/OFF</h3>
							</div>
							<div class="stats-content clearfix">
								<div class="stats-content-right" style="width:96% !important; margin-left:5px; margin-right:5px; float:none; margin-top:10px;">
								<?php
								for ($i=0;$i<$numHeater; $i++)
								{	
									$strLightName	=   'Blower '.$i;
                                                                        
									$sRelayType     =   '';
									$sRelayNumber   =   '';
									$strBlower	=   'blower.png';
									
									$aBlowerDetails  =   $this->home_model->getBlowerDeviceDetails($i);
									if(!empty($aBlowerDetails))
									{
										foreach($aBlowerDetails as $aBlower)
										$sRelayDetails  =   unserialize($aBlower->light_relay_number);
										
										$sRelayType     =   $sRelayDetails['sRelayType'];
										$sRelayNumber   =   $sRelayDetails['sRelayNumber'];
										
										if($sRelayType == '24')
										{
											$sLightStatus   =   $sRelays[$sRelayNumber];
										}
										if($sRelayType == '12')
										{
											$sLightStatus   =   $sPowercenter[$sRelayNumber];
										}
									}
									
									if($sRelayNumber != '')
									{
							?>
							
							<div class="rowCheckbox switch">
							<img id="lightImage_<?php echo $i;?>" src="<?php echo HTTP_IMAGES_PATH.'icons/'.$strBlower;?>" style="width:64px;">
								<div class="custom-checkbox" style="float:right; margin-right:10px; margin-top:20px;"><input type="checkbox" value="<?php echo $i.'|||'.$sRelayType.'|||'.$sRelayNumber;?>" id="relay-<?php echo $i?>" name="relay-<?php echo $i?>" class="lightButton" hidefocus="true" style="outline: medium none;">
									<label <?php echo $strChecked;?>  id="lableRelay-<?php echo $i?>" for="relay-<?php echo $i?>"><span style="color:#C9376E;"><?php echo $strLightName;?></span></label>
								</div>
							</div>
							<?php           } else { ?>
                                                        <div class="rowCheckbox switch">
							<span style="color:#C9376E; font-weight: bold;">Relay not assinged to <?php echo $strLightName;?></span>
							</div>
                                                        <?php } ?>
                                                        <div style="height:30px;">&nbsp;</div>
							<?php 			
								 }
							?> 
								</div>
							</div>
					</div>
				</div>
				  
				<div class="col-sm-8">
						<!-- Statistics -->
						<div class="widget-container widget-stats boxed green-line">
							<div class="widget-title">
								<a href="<?php echo base_url('analog/showBlower');?>" class="link-refresh" id="link-refresh-1"><span class="glyphicon glyphicon-refresh"></span></a>
								<h3>Light Settings</h3>
							</div>
							<div class="stats-content clearfix">
								<div class="stats-content-right" style="width:100% !important; margin-left:5px; margin-right:5px; float:none;">
							
							  <table class="table table-hover">
								<thead>
								  <tr>
									<th class="header" style="width:25%">Blower</th>
									<th class="header"  style="width:25%">Type</th>
									<th class="header"  style="width:50%">Action</th>
								  </tr>
								</thead>
								<tbody>
								<?php	

								for ($i=0;$i < $numHeater; $i++)
								{
									
									$sMainType =	$this->home_model->getDeviceMainType($i,$sDevice);
																			
									$sRelayType     =   '';
									$sRelayNumber   =   '';
									
									$aBlowerDetails  =   $this->home_model->getBlowerDeviceDetails($i);
									if(!empty($aBlowerDetails))
									{
										foreach($aBlowerDetails as $aBlower)
										$sRelayDetails  =   unserialize($aBlower->light_relay_number);

										$sRelayType     =   $sRelayDetails['sRelayType'];
										$sRelayNumber   =   $sRelayDetails['sRelayNumber'];
									}
									$sRelayNameDb =  $this->home_model->getDeviceName($i,$sDevice);
									if($sRelayNameDb == '')
									$sRelayNameDb = 'Add Name';
									?>
										<tr>
										<td>Blower <?php echo $i;?><br />(<a href="<?php if($sAccess == '2') { echo site_url('home/deviceName/'.base64_encode($i).'/'.base64_encode($sDevice).'/'); } else { echo 'javascript:void(0);';} ?>"><?php echo $sRelayNameDb;?></a>)</td>
										<td>
											<div class="rowRadio"><div class="custom-radio"><input class="relayRadio" type="radio" id="radio_other_<?php echo $i;?>" value="0" name="<?php echo $i;?>_MainType" <?php if($sMainType == '0' || $sMainType == ''){ echo 'checked="checked"';}?> <?php if($sAccess == '1') { echo 'disabled="disabled"';}?> hidefocus="true" style="outline: medium none;"><label id="relay_other_<?php echo $i;?>" for="radio_other_<?php echo $i;?>" class="<?php if($sMainType == '0' || $sMainType == ''){ echo 'checked';}?>">Other</label></div></div>
											<div class="rowRadio"><div class="custom-radio"><input class="relayRadio" type="radio" id="radio_spa_<?php echo $i;?>" name="<?php echo $i;?>_MainType" value="1" <?php if($sMainType == '1'){ echo 'checked="checked"';}?> <?php if($sAccess == '1') { echo 'disabled="disabled"';}?> hidefocus="true" style="outline: medium none;"><label id="relay_spa_<?php echo $i;?>" for="radio_spa_<?php echo $i;?>" class="<?php if($sMainType == '1'){ echo 'checked';}?>">Spa</label></div></div>
											<div class="rowRadio"><div class="custom-radio"><input class="relayRadio" type="radio" id="radio_pool_<?php echo $i;?>" name="<?php echo $i;?>_MainType" value="2" <?php if($sMainType == '2'){ echo 'checked="checked"';}?> <?php if($sAccess == '1') { echo 'disabled="disabled"';}?> hidefocus="true" style="outline: medium none;"><label id="relay_pool_<?php echo $i;?>" for="radio_pool_<?php echo $i;?>" class="<?php if($sMainType == '2'){ echo 'checked';}?>">Pool</label></div></div>
										</td>
										<td>
										<div>
										<input type="radio" <?php if($sRelayType == '24'){ echo 'checked="checked"';}?> class="lightRadio" name="lightRelay_<?php echo $i;?>" id="lightRelay24_<?php echo $i;?>" value="24">&nbsp;24V AC Relay&nbsp;&nbsp;<input type="radio" class="lightRadio" name="lightRelay_<?php echo $i;?>" id="lightRelay12_<?php echo $i;?>" <?php if($sRelayType == '12'){ echo 'checked="checked"';}?> value="12">&nbsp;12V DC Relay
										</div>
										<div id="24VRelay_<?php echo $i;?>" style="display:<?php if($sRelayType == '24'){ echo '';} else {echo 'none';}?>; padding-top:10px;">
										<select name="select24VRelays_<?php echo $i;?>" id="select24VRelays_<?php echo $i;?>" class="form-control" style="width:80%">
										<?php
												for ($j=0;$j < $relay_count; $j++)
												{
													$strSelect= "";
													$iRelayVal = $sRelays[$j];
													
													if($j == $sRelayNumber)
														$strSelect= "selected='selected'";
													
													if($iRelayVal != '' && $iRelayVal !='.') 
													{
														echo '<option value="'.$j.'" '.$strSelect.'>Relay '.$j.'</option>';
													}
												}
										?>
										</select>
										<a href="javascript:void(0);" class="btn btn-small btn-green" style="padding:6px 0 !important;" onclick="save('<?php echo $i;?>','24');"><span>Save</span></a>&nbsp;&nbsp;<a href="javascript:void(0);" class="btn btn-small btn-red" style="padding:6px 0 !important;"onclick="cancel('<?php echo $i;?>')"><span>Cancel</span></a>&nbsp;&nbsp;<span id="loadingImg24_<?php echo $i;?>" style="display:none;"><img src="<?php echo site_url('assets/images/loading.gif');?>" alt="Loading...." width="32" height="32"></span>
										</div>
										<div id="12VRelay_<?php echo $i;?>" style="display:<?php if($sRelayType == '12'){ echo '';} else {echo 'none';}?>;padding-top:10px;">
										<select name="select12VRelays_<?php echo $i;?>" id="select12VRelays_<?php echo $i;?>" class="form-control" style="width:80%">
										<?php
											for ($j=0;$j < $power_count; $j++)
											{
												$strSelect  =   '';
												$iRelayVal = $sPowercenter[$j];
												
												if($j == $sRelayNumber)
													 $strSelect= "selected='selected'";
												
												if($iRelayVal != '' && $iRelayVal !='.') 
												{
														echo '<option value="'.$j.'" '.$strSelect.'>PowerCenter '.$j.'</option>';
												}
											}
										?>
										</select>
										<a href="javascript:void(0);" class="btn btn-small btn-green" style="padding:6px 0 !important;" onclick="save('<?php echo $i;?>','12');"><span>Save</span></a>&nbsp;&nbsp;<a href="javascript:void(0);" class="btn btn-small btn-red" style="padding:6px 0 !important;" onclick="cancel('<?php echo $i;?>')"><span>Cancel</span></a>&nbsp;&nbsp;<span id="loadingImg12_<?php echo $i;?>" style="display:none;"><img src="<?php echo site_url('assets/images/loading.gif');?>" alt="Loading...." width="32" height="32"></span>
										</div>
										</td>
										</tr>
								
								<?php  } ?>	
								</tbody>
								</table>
								</div>
							</div>
						</div>
						<!--/ Statistics -->
					</div>
					<p>
					<a class="fancybox" id="checkLink" href="#inline1" style="display:none;">&nbsp;</a>
					<div id="inline1" style="width:250px;height:40px; display:none;"><div class="loading-progress"></div></div>
					</p>
			</div><!-- /.row -->
	<?php } ?>
<?php } //Relay Device End ?>	
<!-- END : 24V AC RELAY -->