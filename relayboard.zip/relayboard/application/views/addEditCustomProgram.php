<?php
/**
 *	Project : LVN 
 *	Program/Module Name : Add/Edit Custom Program 
 *	Author : Dhiraj S. 
 *	Creation Date : 27/06/2016 
 *	Description : Add/Edit Custom Program Details.
 *	Modification History : 
 *	Change Date: Name: 
**/
$customProgramName = '';
$customProgramTime = '';

$isSchedule		   	= '';	
$sProgrameTypeEdit	= '';	
$sProgrameDaysEdit	= '';
$program_type_start = '';
$program_type_end 	= '';		

$aStart = array();
$aEnd	= array();

if(!empty($customProgram))
{
	foreach($customProgram as $Program)
	{
		$arrProgramDetails = json_decode($Program->program_details);
	
		$customProgramName = str_replace("_"," ",$arrProgramDetails->g_custom_mode_name);
		$customProgramTime = $arrProgramDetails->g_custom_max_time;
		
		$arrPumpsList	   = explode(",",$arrProgramDetails->g_rlb_pump_list);
		$arrPumpsSeq	   = explode(",",$arrProgramDetails->g_pump_sq);
		$arrPumpsTime	   = explode(",",$arrProgramDetails->g_pump_time);
		
		$arrValvesList	   = explode(",",$arrProgramDetails->g_rlb_valve_list);
		$arrValvesSeq	   = explode(",",$arrProgramDetails->g_valve_sq);
		$arrValvesTime	   = explode(",",$arrProgramDetails->g_valve_time);
		
		$arrRelaysList	   = explode(",",$arrProgramDetails->g_rlb_relay_list);
		$arrRelaysSeq	   = explode(",",$arrProgramDetails->g_relay_sq);
		$arrRelaysTime	   = explode(",",$arrProgramDetails->g_relay_time);
		
		$arrPowersList	   = explode(",",$arrProgramDetails->g_rlb_powercenter_list);
		$arrPowersSeq	   = explode(",",$arrProgramDetails->g_powercenter_sq);
		$arrPowersTime	   = explode(",",$arrProgramDetails->g_powercenter_time);
		
		$isSchedule		   = $Program->is_schedule;	
		$sProgrameTypeEdit = $Program->program_type;	
		$sProgrameDaysEdit  = explode(',',$Program->program_days);
		$program_type_start = $Program->program_type_start;
		$program_type_end = $Program->program_type_end;	
	}
}

//echo $isSchedule.'>>'.$program_type.'>>'.$program_days;

if(empty($aStart))
  $aStart = array(0=>0,1=>0);
if(empty($aEnd))
  $aEnd   = array(0=>23,1=>59);

$sButtonText	=	'';
if($customProgramID == '')
{
	$sButtonText = 'Save Custom Program Details';
	$ActionUrl	 = site_url('device/addeditCustomProgram');
}
else if($customProgramID != '')
{
	$sButtonText = 'Update Custom Program Details';
	$ActionUrl	 = site_url('device/addeditCustomProgram/'.base64_encode($customProgramID));
}

$arrPumps  = array();
$arrValves = array();
$arrRelays = array();
$arrPowers = array();

if($_SERVER['REMOTE_ADDR'] == '14.142.41.62')
echo $sProgrameTypeEdit;

foreach($deviceDetails as $IP => $IPDevice)
{
	foreach($IPDevice as $deviceType => $devices)
	{
		foreach($devices as $deviceNumber => $device)	
		{
			if($deviceType == 'R')
			{
				$TempDetails = explode("|||",$device);
				if($TempDetails[0] != '.')
				{
					$arrRelays[$IP."_".$deviceNumber]['name'] = $TempDetails[0];
					$arrRelays[$IP."_".$deviceNumber]['Pump'] = $TempDetails[1];
				}
				else
				{
					$arrRelays[$IP."_".$deviceNumber]['Pump'] = $TempDetails[1];
					$arrRelays[$IP."_".$deviceNumber]['name'] = '.';
				}
				
			}
			
			if($deviceType == 'P')
			{
				$TempDetails = explode("|||",$device);
				$arrPowers[$IP."_".$deviceNumber]['name'] = $TempDetails[0];
				$arrPowers[$IP."_".$deviceNumber]['Pump'] 	 = $TempDetails[1];
			}
			
			if($deviceType == 'PS')
			{
				$arrPumps[$IP."_".$deviceNumber] = $device;
			}
			
			if($deviceType == "V")
			{
				if($device != '.')
				{
					$arrValves[$IP."_".$deviceNumber] = $device[0].'|||'.$device[1].'|||'.$device[2];
				}
			}
		}
	} 
}



?>
<style>
.col {
    float: left;
    margin-right: 5px;
    padding: 5px;
}
.navbar-toggle {
		background-color: transparent !important;
		background-image: none !important;
		border: 1px solid transparent !important;
		border-radius: 4px !important;
		float: left !important;
		margin-bottom: 8px !important;
		margin-right: 15px !important;
		margin-top: 8px !important;
		padding: 9px 10px !important;
		position: relative !important;
	}
	
	.navbar-toggle .icon-bar {
		border-radius: 1px !important;
		display: block !important;
		height: 2px !important;
		width: 22px !important;
	}
</style>
<link href="<?php echo site_url('assets/js/jquery-ui-timepicker-0.3.3/ui-1.10.0/ui-lightness/jquery-ui-1.10.0.custom.min.css');?>" rel="stylesheet" type="text/css" />  
<link href="<?php echo site_url('assets/js/jquery-ui-timepicker-0.3.3/jquery.ui.timepicker.css?v=0.3.3');?>" rel="stylesheet" type="text/css" />

<script type="text/javascript" src="<?php echo site_url('assets/js/jquery-ui-timepicker-0.3.3/ui-1.10.0/jquery.ui.core.min.js');?>"></script>
<script type="text/javascript" src="<?php echo site_url('assets/js/jquery-ui-timepicker-0.3.3/ui-1.10.0/jquery.ui.position.min.js');?>"></script>
<script type="text/javascript" src="<?php echo site_url('assets/js/jquery-ui-timepicker-0.3.3/jquery.ui.timepicker.js?v=0.3.3');?>"></script>
    <div id="page-wrapper">
        <div class="row">
          <div class="col-lg-12">
            <ol class="breadcrumb">
						  <li><img src="<?php echo HTTP_IMAGES_PATH.'icons/home.png';?>" width="24" style="vertical-align: middle !important;">&nbsp;<a href="<?php echo site_url();?>">Home</a> </li>
						  <li><a href="<?php echo base_url('device/customProgram');?>">All Custom Programs</a></li>
						  <li class="active">Add/Edit Custom Program</li>
				</ol>
          </div>
        </div><!-- /.row -->
        <div class="row">
          <div class="col-lg-12">
            <div class="panel panel-primary">
              <div class="panel-heading" style="border-top-left-radius: 0px;border-top-right-radius: 0px;">
                <h3 class="panel-title" style="color:#FFF;">Add/Edit Custom Program</h3>
              </div>
              <div class="panel-body">
                <div id="morris-chart-area">
                  <form action="<?php echo $ActionUrl;?>" method="post">
				  <input type="hidden" name="userID" value="<?php echo $sUserID;?>">
                    <table border="0" cellspacing="0" cellpadding="0" width="100%">
					<tr>
                        <td colspan="3"><span style="color:#FF0000;">* indicates required field</span></td>
                    </tr>
					 <tr><td colspan="3">&nbsp;</td></tr>
						  <tr>
							<td width="24%"><strong>Name: <span class="mandetory">*</span></strong></td>
							<td width="1%">&nbsp;</td>
							<td width="75%"><input type="text" class="form-control" placeholder="Enter Name" name="customProgramName" value="<?php echo $customProgramName;?>" id="customProgramName" required></td>
						  </tr>
						  <tr><td colspan="3">&nbsp;</td></tr>
						  <tr>
							<td width="10%"><strong>Maximum Time: <span class="mandetory">*</span></strong></td>
							<td width="1%">&nbsp;</td>
							<td width="89%"><input type="text" class="form-control" placeholder="Enter Maximum Time" name="customProgramTime" value="<?php echo $customProgramTime;?>" id="customProgramTime" required></td>
						  </tr>
						  <tr><td colspan="3">&nbsp;</td></tr>
					  
						<tr><td colspan="3" align="center" style="font-size: 22px; text-decoration: underline;">Select Device</td></tr>
						 <tr><td colspan="3">&nbsp;</td></tr>
						 
						 <tr>
							<td width="10%">&nbsp;</td>
							<td width="1%">&nbsp;</td>
							<td width="89%"><strong style="color:#FF0000;font-size:14px;">Note : If you want to Select Multiple devices then press Ctrl button and select the devices from the dropdown.</strong></td></tr>
						  <tr><td colspan="3">&nbsp;</td></tr>
						 
						<tr>
                        <td width="10%"><strong>Pumps: </strong></td>
                        <td width="1%">&nbsp;</td>
                        <td width="89%">
							<select name="customPumps[]" id="customPumps" class="form-control" onchange="showDeviceDetails(this.value,'PS','customPumps','customPumpsTable');" multiple>
							<option value="">----Select Pumps----</option>
							<?php if(!empty($arrPumps))
								  {
									  foreach($arrPumps as $device => $Pumps)
									  {
										  $strSelect = '';
										  if(in_array($device,$arrPumpsList))
											  $strSelect = 'selected="selected"';
							?>	
											<option value="<?php echo $device;?>" <?php echo $strSelect;?>><?php echo $Pumps;?></option>	
							<?php 	  }
								
								  }
							?>
							</select>
							<table class="table table-hover" id="customPumpsTable" style="display:<?php if($arrPumpsList[0] != '' && $arrPumpsList[0] != 'null'){ echo '';} else {echo 'none';}?>;">
							<thead>
							<tr>
								<th width="50%">Device Name</th>
								<th width="25%">Device Sequence</th>
								<th width="25%">Device Run Time</th>
							</tr>
							</thead>
							<?php
								if($arrPumpsList[0] != '' && $arrPumpsList[0] != 'null')
								{
									foreach($arrPumpsList as $key => $Pump)
									{
										echo '<tr id="tr_PS_'.$Pump.'"><td>'.$arrPumps[$Pump].'</td><td><input type="text" name="sequence_'.$Pump.'_PS" class="form-control checkDeviceDetails" id="sequence_'.$Pump.'_PS" value="'.$arrPumpsSeq[$key].'"></td>	<td><input type="text" class="form-control checkDeviceDetails checkDeviceTime" name="time_'.$Pump.'_PS" id="time_'.$Pump.'_PS" value="'.$arrPumpsTime[$key].'"></td></tr>';
									}
								}
							?>
							</table>	
						</td>
                      </tr>	
					  <tr><td colspan="3">&nbsp;</td></tr>
					  <tr>
                        <td width="10%"><strong>Valves: </strong></td>
                        <td width="1%">&nbsp;</td>
                        <td width="89%">
							<select name="customValves[]" id="customValves" class="form-control" multiple onchange="showDeviceDetails(this.value,'V','customValves','customValvesTable');">
							<option value="">----Select Valves----</option>
							<?php if(!empty($arrValves))
								  {
									  foreach($arrValves as $device => $Valve)
									  {
											$arrValve = explode("_",$device);
										    $aValveDetails = explode('|||',$Valve);
											for($i=1;$i<=2;$i++)
											{
												 $strSelect = '';
												  if(in_array($arrValve[0]."_".$i."_".$arrValve[1],$arrValvesList))
													  $strSelect = 'selected="selected"';
							?>	
											<option value="<?php echo $arrValve[0]."_".$i."_".$arrValve[1];?>" <?php echo $strSelect;?>> <?php echo $aValveDetails[0].' ( '.$aValveDetails[$i].' )';?></option>	
											
							<?php 	  
											}
									  }
								  }
							?>
							</select>
							<table class="table table-hover" id="customValvesTable" style="display:<?php if($arrValvesList[0] != '' && $arrValvesList[0] != 'null'){ echo '';} else {echo 'none';}?>;">
							<thead>
							<tr>
								<th width="50%">Device Name</th>
								<th width="25%">Device Sequence</th>
								<th width="25%">Device Run Time</th>
							</tr>
							</thead>
							<?php
								if($arrValvesList[0] != '' && $arrValvesList[0] != 'null')
								{
									foreach($arrValvesList as $key => $Valve)
									{
										$aValveDetails = explode('_',$Valve);
										$tempValve	   = $arrValves[$aValveDetails[0].'_'.$aValveDetails[2]];
										
										$arrTemp	   = explode('|||',$tempValve);
										
										echo '<tr id="tr_V_'.$Valve.'"><td>'.$arrTemp[0].' ('.$arrTemp[$aValveDetails[1]].' )</td><td><input type="text" name="sequence_'.$Valve.'_V" class="form-control checkDeviceDetails" id="sequence_'.$Valve.'_V" value="'.$arrValvesSeq[$key].'"></td>	<td><input type="text" class="form-control checkDeviceDetails checkDeviceTime" name="time_'.$Valve.'_V" id="time_'.$Valve.'_V" value="'.$arrValvesTime[$key].'"></td></tr>';
									}
								}
							?>	
							</table>								
						</td>
                      </tr>	
					  <tr><td colspan="3"><hr /></td></tr>
					   <tr>
						<td width="10%">&nbsp;</td>
						<td width="1%">&nbsp;</td>
						<td width="89%"><strong style="color:#FF0000;font-size:14px;">Note : If you Select the Heater from below there is no need of selecting associated Pump.</strong></td></tr>
					  <tr><td colspan="3">&nbsp;</td></tr>
					  <tr>
						<td width="10%">&nbsp;</td>
						<td width="1%">&nbsp;</td>
						<td width="89%"><strong style="color:#FF0000;font-size:14px;" id="PumpMessage"></strong></td></tr>
					  <tr><td colspan="3">&nbsp;</td></tr>
					  <tr>
                        <td width="10%"><strong>Relays: </strong></td>
                        <td width="1%">&nbsp;</td>
                        <td width="89%">
							<select name="customRelays[]" id="customRelays" class="form-control" multiple onchange="showDeviceDetails(this.value,'R','customRelays','customRelaysTable');">
							<option value="">----Select Relays----</option>
							<?php if(!empty($arrRelays))
								  {
									  foreach($arrRelays as $device => $Relays)
									  {
										  if($Relays['name'] == '.')
										  	continue;
										  $strSelect = '';
										  if(in_array($device,$arrRelaysList))
											  $strSelect = 'selected="selected"';
										  
										  $tempIP =explode("_",$device);
							?>	
											<option <?php echo $strSelect;?> value="<?php echo $device;?>" data-Pump="<?php echo $tempIP[0].'_'.$Relays['Pump'];?>"><?php echo $Relays['name'];?></option>	
											
							<?php 	  
									  }
								  }
							?>	
							</select>
							<table class="table table-hover" id="customRelaysTable" style="display:<?php if($arrRelaysList[0] != '' && $arrRelaysList[0] != 'null'){ echo '';} else {echo 'none';}?>;">
							<thead>
							<tr>
								<th width="50%">Device Name</th>
								<th width="25%">Device Sequence</th>
								<th width="25%">Device Run Time</th>
							</tr>
							</thead>
							<?php
								if($arrRelaysList[0] != '' && $arrRelaysList[0] != 'null')
								{
									foreach($arrRelaysList as $key => $Relay)
									{
										echo '<tr id="tr_R_'.$Relay.'"><td>'.$arrRelays[$Relay]['name'].'</td><td><input type="text" name="sequence_'.$Relay.'_R" class="form-control checkDeviceDetails" id="sequence_'.$Relay.'_R" value="'.$arrRelaysSeq[$key].'"></td>	<td><input type="text" class="form-control checkDeviceDetails checkDeviceTime" name="time_'.$Relay.'_R" id="time_'.$Relay.'_R" value="'.$arrRelaysTime[$key].'"></td></tr>';
									}
								}
							?>	
							</table>							
						</td>
                      </tr>
					   <tr><td colspan="3">&nbsp;</td></tr>
					  <tr>
                        <td width="10%"><strong>Power Centers: </strong></td>
                        <td width="1%">&nbsp;</td>
                        <td width="89%">
							<select name="customPowers[]" id="customPowers" class="form-control" multiple onchange="showDeviceDetails(this.value,'P','customPowers','customPowersTable');">
							<option value="">----Select Power Centers----</option>
							<?php if(!empty($arrPowers))
								  {
									  foreach($arrPowers as $device => $Powers)
									  {
										  $strSelect = '';
										  if(in_array($device,$arrPowersList))
											  $strSelect = 'selected="selected"';
										  
										   $tempIP =explode("_",$device);
										    
							?>	
											<option <?php echo $strSelect;?> value="<?php echo $device;?>" data-Pump="<?php echo $tempIP[0].'_'.$Powers['Pump'];?>"><?php echo $Powers['name'];?></option>	
							
							<?php 	  
									  }
								  }
							?>
							</select>
							<table class="table table-hover" id="customPowersTable" style="display:<?php if($arrPowersList[0] != '' && $arrPowersList[0] != 'null'){ echo '';} else {echo 'none';}?>">
							<thead>
							<tr>
								<th width="50%">Device Name</th>
								<th width="25%">Device Sequence</th>
								<th width="25%">Device Run Time</th>
							</tr>
							<?php
								if($arrPowersList[0] != '' && $arrPowersList[0] != 'null')
								{
									foreach($arrPowersList as $key => $Powers)
									{
										echo '<tr id="tr_P_'.$Powers.'"><td>'.$arrPowers[$Powers]['name'].'</td><td><input type="text" name="sequence_'.$Powers.'_P" class="form-control checkDeviceDetails" id="sequence_'.$Powers.'_P" value="'.$arrPowersSeq[$key].'"></td>	<td><input type="text" class="form-control checkDeviceDetails checkDeviceTime" name="time_'.$Powers.'_P" id="time_'.$Powers.'_P" value="'.$arrPowersTime[$key].'"></td></tr>';
									}
								}
							?>
							</thead>
								
							</table>	
						</td>
                      </tr>
					  <tr><td colspan="3">&nbsp;</td></tr>
					 
					  <tr>
						<td width="10%"><strong>Is Schedule? </strong></td>
						<td width="1%">&nbsp;</td>
						<td width="89%"><input type="radio" class="scheduleRadio" name="isSchedule" <?php if($isSchedule == '1') { echo 'checked="checked"'; }?> value="1" id="isScheduleYes">&nbsp;Yes&nbsp;&nbsp;<input type="radio" class="scheduleRadio" name="isSchedule" value="0" id="isScheduleNo" <?php if($isSchedule == '0' || $isSchedule == '') { echo 'checked="checked"'; }?>>&nbsp;No</td>
					  </tr>			 
					   <tr><td colspan="3">&nbsp;</td></tr>
					   <tr class="scheduleDetails" style="display:<?php if($isSchedule == '1')  { echo ''; } else { echo 'none';} ?>">
                        <td width="10%"><strong>Program Type:</strong></td>
                        <td width="1%">&nbsp;</td>
                        <td width="89%"><input type="radio" name="sProgramType" <?php if($sProgrameTypeEdit =='1' || $sProgrameTypeEdit == '') { echo 'checked="checked"'; } ?> value="1" id="sProgramTypeDaily" <?php if($sAccess == 1) { echo 'disabled="disabled";';} ?>>&nbsp;Daily &nbsp;&nbsp;<input type="radio" name="sProgramType" <?php if($sProgrameTypeEdit =='2') { echo 'checked="checked"'; } ?> value="2" id="sProgramTypeWeekly" <?php if($sAccess == 1) { echo 'disabled="disabled";';} ?>>&nbsp;Weekly
                        </td>
                      </tr>
					  <tr id="tr_week" style="display:<?php if(($sProgrameTypeEdit =='1' || $sProgrameTypeEdit == '' || $sProgrameTypeEdit == '0')) { echo 'none'; } ?>;">
                        <td width="10%"><strong>&nbsp;</strong></td>
                        <td width="1%">&nbsp;</td>
                        <td width="89%">
						<div class="row"><div class="col-md-12">&nbsp;</div></div>	
							<div class="row">
								<div class="col-md-2">
								  <input type="checkbox" <?php if(!empty($sProgrameDaysEdit) && in_array(1,$sProgrameDaysEdit)){ echo 'checked="checked"';} ?> name="sProgramDays[]" value="1" style="margin:1px;" /><label style="margin-left: 5px;">Monday</label>
							   </div>
								<div class="col-md-2">
								  <input type="checkbox" <?php if(!empty($sProgrameDaysEdit) && in_array(2,$sProgrameDaysEdit)){ echo 'checked="checked"';} ?> name="sProgramDays[]" value="2" style="margin:1px;" /><label style="margin-left: 5px;">Tuesday</label>
							   </div>
								<div class="col-md-2">
								  <input type="checkbox" <?php if(!empty($sProgrameDaysEdit) && in_array(3,$sProgrameDaysEdit)){ echo 'checked="checked"';} ?> name="sProgramDays[]" value="3" style="margin:1px;" /><label style="margin-left: 5px;">Wednesday</label>
							   </div>
								<div class="col-md-2">
								  <input type="checkbox" <?php if(!empty($sProgrameDaysEdit) && in_array(4,$sProgrameDaysEdit)){ echo 'checked="checked"';} ?> name="sProgramDays[]" value="4" style="margin:1px;" /><label style="margin-left: 5px;">Thursday</label>
							   </div>
                            </div>
							<div class="row">
								<div class="col-md-2">
								  <input type="checkbox" <?php if(!empty($sProgrameDaysEdit) && in_array(5,$sProgrameDaysEdit)){ echo 'checked="checked"';} ?> name="sProgramDays[]" value="5" style="margin:1px;" /><label style="margin-left: 5px;">Friday</label>
								</div>
								<div class="col-md-2">
								  <input type="checkbox" <?php if(!empty($sProgrameDaysEdit) && in_array(6,$sProgrameDaysEdit)){ echo 'checked="checked"';} ?> name="sProgramDays[]" value="6" style="margin:1px;" /><label style="margin-left: 5px;">Saturday</label>
								</div>
								<div class="col-md-2">
								  <input type="checkbox" <?php if(!empty($sProgrameDaysEdit) && in_array(7,$sProgrameDaysEdit)){ echo 'checked="checked"';} ?> name="sProgramDays[]" value="7" style="margin:1px;" /><label style="margin-left: 5px;">Sunday</label>
							   </div>
							</div>
                        </td>
                      </tr>
                      <tr id="tr_week_blank" style="display:<?php if($sProgrameTypeEdit =='1'  || $sProgrameTypeEdit == '') { echo 'none'; } ?>;"><td colspan="3">&nbsp;</td></tr>

					  <tr class="scheduleDetails" style="display:<?php if($isSchedule == '1')  { echo ''; } else { echo 'none';} ?>"><td colspan="3">&nbsp;</td></tr>
					  <tr class="scheduleDetails" style="display:<?php if($isSchedule == '1')  { echo ''; } else { echo 'none';} ?>">
						<td width="10%"><strong>Program Start Time: </strong></td>
						<td width="1%">&nbsp;</td>
						<td width="89%"><input type="text" class="form-control" placeholder="Select Start Time" required name="ProgramTypeStartTime" value="<?php echo $program_type_start;?>" id="ProgramTypeStartTime" <?php if($sAccess == 1) { echo 'disabled="disabled";';} ?> readonly></td>
					  </tr>
					  <tr class="scheduleDetails" style="display:<?php if($isSchedule == '1')  { echo ''; } else { echo 'none';} ?>"><td colspan="3">&nbsp;</td></tr>
					  <tr class="scheduleDetails" style="display:<?php if($isSchedule == '1')  { echo ''; } else { echo 'none';} ?>">
						<td width="10%"><strong>Program End Time: </strong></td>
						<td width="1%">&nbsp;</td>
						<td width="89%"><input type="text" class="form-control" placeholder="Select End Time" name="ProgramTypeEndTime" value="<?php echo $program_type_end;?>" id="ProgramTypeEndTime" required <?php if($sAccess == 1) { echo 'disabled="disabled";';} ?> readonly ></td>
					  </tr>
                       <tr><td colspan="3">&nbsp;</td></tr>	
					  <tr><td colspan="3"><span class="btn btn-green"><input type="submit" name="command" value="<?php echo $sButtonText;?>" id="command"></span>&nbsp;&nbsp;<span class="btn btn-red"><input type="button" name="back" value="Back" class="btn btn-success" onclick="javascript:location.href='<?php echo base_url('device/customProgram');?>';"></span></td></tr>
                      
                    </table>
                  </form>
                </div>
              </div>
            </div>
          </div>
        </div><!-- /.row -->
      </div><!-- /#page-wrapper -->
<script type="text/javascript">
$(document).ready(function (){
	$('#timepicker_start').timepicker({
		showLeadingZero: true,
		showMinutesLeadingZero: true,
		onSelect: tpStartSelect,
		maxTime: {
			hour: <?php echo $aEnd[0];?>, minute: <?php echo $aEnd[1];?>
		}
	});
	$('#timepicker_end').timepicker({
		showLeadingZero: true,
		showMinutesLeadingZero: true,
		onSelect: tpEndSelect,
		minTime: {
			hour: <?php echo $aStart[0];?>, minute: <?php echo $aStart[1];?>
		}
	});
	
	$('#ProgramTypeStartTime').timepicker({
		showLeadingZero: true,
		showMinutesLeadingZero: true,
		onSelect: tpStartSelect,
		maxTime: {
			hour: <?php echo $aEnd[0];?>, minute: <?php echo $aEnd[1];?>
		}
	});
	$('#ProgramTypeEndTime').timepicker({
		showLeadingZero: true,
		showMinutesLeadingZero: true,
		onSelect: tpEndSelect,
		minTime: {
			hour: <?php echo $aStart[0];?>, minute: <?php echo $aStart[1];?>
		}
	});
 	
	$("input:radio[name='sProgramType']").click(function() {
    var chkVal  = $("input:radio[name='sProgramType']:checked").val();
    if(chkVal == '2')
    {
      $("#tr_week").show();
      $("#tr_week_blank").show();
    }
    else
    {
      $("#tr_week").hide();
      $("#tr_week_blank").hide(); 
    }
  });
	
  $("#command").click(function()
  {
	  var errMessage = '';
	  var customProgramName = $("#customProgramName").val();
	  if(customProgramName == '')
	  {
		  alert('Please Enter Program Name!');
		  $("#customProgramName").focus();
		  return false;
	  }
	  
	  var customProgramTime = $("#customProgramTime").val();
	  if(customProgramTime == '')
	  {
		  alert('Please Enter Program Maximum Time!');
		  $("#customProgramTime").focus();
		  return false;
	  }
	  else if(isNaN(customProgramTime))
	  {
		  alert('Please Enter valid Program Maximum Time, Only number is allowed!');
		  $("#customProgramTime").focus();
		  return false;
	  }
	  
	  if($('.checkDeviceDetails').length)
	  {
		  $('.checkDeviceDetails').each(function(index,value){
			  var value = $(this).val();
			  var id 	= $(this).attr('id');
			  var arrDetails = id.split("_");
			  var deviceType = '';
			  var detailType = '';
			 
			  if(arrDetails[3] == 'PS')
				  deviceType = 'Pump';
			  if(arrDetails[3] == 'P')
			  {
				  deviceType = 'PowerCenter';
				  deviceType = $("#customPowers option[value='"+arrDetails[1]+"_"+arrDetails[2]+"']").text();
			  }
			  if(arrDetails[3] == 'R')
				  deviceType = 'Relay';
			  if(arrDetails[3] == 'V')
				  deviceType = 'Valve';
			  
			  if(arrDetails[0] == 'sequence')	
					detailType = 'Sequence';
			  else 	
					detailType = 'Time';
			
			  if(value == '')
			  {
				  errMessage += 'Please Enter '+detailType+' For '+deviceType+'\n';
			  }
			  else if(value == '0')
			  {
				  errMessage += detailType+' For '+deviceType+' should not be 0\n';
			  }
		  });
		  if(errMessage != '')
		  {
			  alert("Below are the errors:\n\n"+errMessage);
			  return false;
		  }
		var TotalTime = 0; 
		var ArrTempDevice = [];
		
		$('.checkDeviceTime').each(function(index,value){
			var TempCurrentDeviceID = $(this).attr('id');
			var TempSequence = $("#"+TempCurrentDeviceID.replace('time','sequence')).val();
			ArrTempDevice[TempSequence] = [];
			ArrTempDevice[TempSequence].push($(this).val());
			
		});	
		$(ArrTempDevice).each(function(index,value){
			
			if(value === undefined)
			{
				TotalTime+= 0;
			}
			else
			{
				TotalTime+= parseInt(value);
			}
		});	
		
		if(TotalTime > customProgramTime)
		{
			alert("Maximum Program Time is less than all Devices total run time!");
			$("#customProgramTime").focus();
			return false;
		}
	  }
	  else
	  {
		  alert("Please select Device for Custom Program!");
		  return false;
	  }
	  
	var isSchedule = $(".scheduleRadio:checked").val();
	if(isSchedule == "1")
	{
		var startTime = $("#ProgramTypeStartTime").val();
		var endTime = $("#ProgramTypeEndTime").val();
		
		var sProgramType = $("input[name='sProgramType']:checked").val();
		
		if(sProgramType == '2')
		{
			if($("input[name='sProgramDays[]']:checked").length == 0)
			{
				alert("Please select Days to Schedule Program!");
				return false;
			}
		}
		
		if(startTime == '')
		{
			alert("Please select Program Start Time!");
			$("#ProgramTypeStartTime").focus();
			return false;
		}
		
		if(endTime == '')
		{
			alert("Please select Program End Time!");
			$("#ProgramTypeEndTime").focus();
			return false;
		}
		
		var hr		= 0;
		var remMin	= 0;
		
		var totalMinutes = parseInt(TotalTime);
		
		var hours = Math.floor( totalMinutes / 60);          
		var minutes = totalMinutes % 60;
		
		var arrStartTime = startTime.split(":");
		
		var FinalEndTimeMinute = parseFloat(arrStartTime[1])+ minutes;
		
		if(FinalEndTimeMinute > 59)
		{
			minutes = FinalEndTimeMinute - 60;
			hours   += 1;
			if(minutes <= 9)
			{
				minutes = '0'+minutes;
			}
		}
		else
		{
			minutes = FinalEndTimeMinute;
		}
		
		var FinalEndTime = parseFloat(arrStartTime[0]) + parseFloat(hours+'.'+minutes);
		var arrEndTime = endTime.split(":");
		
		if(FinalEndTime > parseFloat(arrEndTime[0]+'.'+arrEndTime[1])) 
		{
			alert("End Time should be greater than or Equal to "+FinalEndTime);
			$("#ProgramTypeEndTime").focus();
			return false;
		}
	}
	
	return true;
  });
  
  $(".scheduleRadio").click(function(){
	 var isChecked = $(this).val() ;
	 if(isChecked == '1')
	 {
		 $(".scheduleDetails").show();
	 }
	 else if(isChecked == '0')
	 {
		 $(".scheduleDetails").hide();
		 $("#tr_week").hide();
		 $("#tr_week_blank").hide(); 
	 }
	 $("#sProgramTypeDaily").prop('checked',true);
  });
  
});
  //function checkForm()
  
  // when start time change, update minimum for end timepicker
	function tpStartSelect( time, endTimePickerInst ) {
		$('#timepicker_end').timepicker('option', {
			minTime: {
				hour: endTimePickerInst.hours,
				minute: endTimePickerInst.minutes
			}
		});
	}

	// when end time change, update maximum for start timepicker
	function tpEndSelect( time, startTimePickerInst ) {
		$('#timepicker_start').timepicker('option', {
			maxTime: {
				hour: startTimePickerInst.hours,
				minute: startTimePickerInst.minutes
			}
		});
	}
  
  function showDeviceDetails(selected,deviceType,selectID,tableID)
  {
	  var PumpMessage = [];
	  if(selected != '')
	  {
		var SelectedPumps 	 = [];
		var SelectedRelays12 = [];
		var SelectedRelays24 = [];
		if(deviceType == 'P' || deviceType == 'R')
		{
			if($("#customPumps option:selected").length > 0)
			{
				$("#customPumps option:selected").each(function (){
					SelectedPumps.push($(this).val());
				});	
			}
		}
		
		if(deviceType == 'PS')
		{
			if($("#customRelays option:selected").length > 0)
			{
				$("#customRelays option:selected").each(function (){
					SelectedRelays24.push($(this).attr('data-Pump'));
				});	
			}
			if($("#customPowers option:selected").length > 0)
			{
				$("#customPowers option:selected").each(function (){
					SelectedRelays12.push($(this).attr('data-Pump'));
				});	
			}
			
		}
			
		var tempArray   =   {};
		var trContent	=	'';
		$("#"+selectID+" option:selected").each(function (){
			var deviceNumber = $(this).val();
			var deviceName	 = $(this).text();
			var deviceIndex  = $(this).index();
			var sequence	 = 0;
			var time	 	 = 0;
			if($("#sequence_"+deviceNumber+"_"+deviceType).length)
			{
				sequence	 = $("#sequence_"+deviceNumber+"_"+deviceType).val();
				time	 	 = $("#time_"+deviceNumber+"_"+deviceType).val();
			}
			tempArray[deviceIndex] = deviceNumber+'|||'+deviceName+'|||'+sequence+'|||'+time;
			
			if(deviceType == 'P' || deviceType == 'R')
			{
				var Pump = $(this).attr("data-Pump");
				if(Pump != '')
				{
					var tempPump = $("#customPumps option[value='"+Pump+"']").text();
					if($.inArray( Pump, SelectedPumps) != -1)
					{
						if($.inArray( tempPump, PumpMessage) != -1){}
						else
						PumpMessage.push(tempPump);
					}
				}
			}
			
			if(deviceType == 'PS')
			{
				var Pump = deviceNumber;
				if(Pump != '')
				{
					var tempPump = $("#customPumps option[value='"+Pump+"']").text();
					if($.inArray( Pump, SelectedRelays12) != -1)
					{
						if($.inArray( tempPump, PumpMessage) != -1){}
						else
						PumpMessage.push(tempPump);
					}
					else if($.inArray( Pump, SelectedRelays24) != -1)
					{
						if($.inArray( tempPump, PumpMessage) != -1){}
						else
						PumpMessage.push(tempPump);
					}
					
				}
			}
		});
		
		if(deviceType == 'P' || deviceType == 'R' || deviceType == 'PS')
		{
			if(PumpMessage.length > 0)
			{
				$("#PumpMessage").html('Warning : When you select a heater, the pump assigned to the heater will automatically simultaneously be turned on. So you don\'t Need to select <span style="font-size:16px;">'+PumpMessage.join(", ")+'</span> Again above!');
			}
			else
			{
				$("#PumpMessage").html('');
			}
		}

		$.each(tempArray, function(i, device) {
			var aDeviceDetails = device.split('|||');
			trContent += '<tr id="tr_'+deviceType+'_'+aDeviceDetails[0]+'"><td>'+aDeviceDetails[1]+'</td><td><input type="text" name="sequence_'+aDeviceDetails[0]+'_'+deviceType+'" class="form-control checkDeviceDetails" id="sequence_'+aDeviceDetails[0]+'_'+deviceType+'" value="'+aDeviceDetails[2]+'"></td>	<td><input type="text" class="form-control checkDeviceDetails checkDeviceTime" name="time_'+aDeviceDetails[0]+'_'+deviceType+'" id="time_'+aDeviceDetails[0]+'_'+deviceType+'" value="'+aDeviceDetails[3]+'"></td></tr>'; 
		})

		$("#"+tableID).find("tr:gt(0)").remove();

		$("#"+tableID).append(trContent);

		$("#"+selectID+" option").each(function (){
			var deviceNumber = $(this).val();
			if($(this).is(':selected')){}
				else
				{
					$("#tr_"+deviceType+"_"+deviceNumber).remove();
				}
		});

		var cntRows = parseInt($("#"+tableID+" tr").length);
		if((cntRows-1) <= 0)
		{
			$("#"+tableID).hide();
		}
		else
		{
			if($("#"+tableID).css('display') == 'none')
			$("#"+tableID).show();
		}
	  }
	  else
	  {
		 $("#"+tableID).find("tr:gt(0)").remove(); 
		 $("#"+tableID).hide();
		 
		 if(deviceType == 'P' || deviceType == 'R' || deviceType == 'PS')
			$("#PumpMessage").html('');
	  }
  }
</script>

<?php

?>