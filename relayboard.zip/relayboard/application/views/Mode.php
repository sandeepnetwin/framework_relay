<?php
$sAccess 		= '';
$sModule	    = 4;

  //Get Permission Details
  $userID = $this->session->userdata('id');
  $aPermissions = json_decode(getPermissionOfModule($userID));
 
  $aModules 		= $aPermissions->sPermissionModule;	
  $aAllActiveModule = $aPermissions->sActiveModule;
  
  $sAccessKey	= 'access_'.$sModule;
			  
  if(!empty($aModules))
  {
	  if(in_array($sModule,$aModules->ids))
	  {
		 $sAccess 		= $aModules->$sAccessKey;
	  }
  }
  
  if($sAccess == '')
	$sAccess = '2' ; 
  
  if($sAccess == '0') {redirect(site_url('home/'));}
  
  $sBorderColorOFF 	= 'blue-line';
  $sStatusOFF 		= 'OFF';
  $sColorOFF 		= '#FF0000';
  $sImageOFF		= HTTP_IMAGES_PATH.'/icons/remove.png';
  
 
  $sBorderColorON 	= 'green-line';
  $sColorON 		= '#006400';
  $sStatusON 		= 'ON';
  $sImageON			= HTTP_IMAGES_PATH.'/icons/tick.png';
?>

<style>
.swichLink
{
	font-size: 14px !important;
    margin-right: -22px;
    margin-top: 25px !important;
}
</style>

	<form action="<?php if($sAccess == 2) { echo site_url('analog/changeMode'); }?>" method="post" id="formChangeMode">
    <input type="hidden" name="iMode" value="" id="iMode">
	<div class="row">
	  <div class="col-lg-12">
		<ol class="breadcrumb">
		  <li><img src="<?php echo HTTP_IMAGES_PATH.'icons/home.png';?>" width="24" style="vertical-align: middle !important;">&nbsp;<a href="<?php echo site_url();?>">Home</a> </li>
		  <li class="active">Mode Change</li>
		</ol>
		<?php if($sucess == '1') { ?>
		  <div class="alert alert-success alert-dismissable">
			<button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
			Details saved successfully! 
		  </div>
		<?php } ?>
		<?php if($err_sucess == '1') { ?>
		  <div class="alert alert-success alert-dismissable" style="background-color: #FFC0CB;border: 1px solid #FFC0CB; color:red;">
			<button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
			IP and Port details required! 
		  </div>
		<?php } ?>
		
	  </div>
	</div><!-- /.row -->
	<div class="row">
		<div class="col-sm-6">
			<!-- Statistics -->
			<div class="widget-container widget-stats boxed <?php if($iMode == '1') { echo $sBorderColorON;} else {echo $sBorderColorOFF;}?>">
				<div class="widget-title">
					<a class="link-refresh swichLink" href="javascript:void(0);" <?php if($sAccess == 2) {echo 'onclick="submitForm(\'1\');"';} ?> hidefocus="true" style="outline: medium none;">Swich Auto</a>
					<h3>Auto</h3>
				</div>
				<div class="stats-content clearfix">
					<div class="stats-content-right" style="text-align:center; margin-top:35px;">
						<h1 style="font-size:40px;  color:<?php if($iMode == '1') { echo $sColorON;} else {echo $sColorOFF;}?>"><?php if($iMode == '1') { echo $sStatusON;} else {echo $sStatusOFF;}?><h1>
					</div>
					<div class="stats-content-left">
						<div class="inner">
							<div class="progressBar">
								<div class="progress-text clearfix" style="margin-top: 10px;text-align: center;">
									<span><img src="<?php if($iMode == '1') { echo $sImageON;} else {echo $sImageOFF;}?>" alt="<?php if($iMode == '1') { echo $sStatusON;} else {echo $sStatusOFF;}?>" width="64"></span>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
			<!--/ Statistics -->
		</div>
		<div class="col-sm-6">
			<!-- Statistics -->
			<div class="widget-container widget-stats boxed <?php if($iMode == '2') { echo $sBorderColorON;} else {echo $sBorderColorOFF;}?>">
				<div class="widget-title">
					<a class="link-refresh swichLink" href="javascript:void(0);" <?php if($sAccess == 2) {echo 'onclick="submitForm(\'2\');"';} ?> hidefocus="true" style="outline: medium none;">Swich Manual</a>
					<h3>Manual</h3>
				</div>
				<div class="stats-content clearfix">
					<div class="stats-content-right" style="text-align:center; margin-top:35px;">
						<h1 style="font-size:40px; color:<?php if($iMode == '2') { echo $sColorON;} else {echo $sColorOFF;}?>"><?php if($iMode == '2') { echo $sStatusON;} else {echo $sStatusOFF;}?><h1>
					</div>
					<div class="stats-content-left">
						<div class="inner">
							<div class="progressBar">
								<div class="progress-text clearfix" style="margin-top: 10px;text-align: center;">
									<span><img src="<?php if($iMode == '2') { echo $sImageON;} else {echo $sImageOFF;}?>" alt="<?php if($iMode == '2') { echo $sStatusON;} else {echo $sStatusOFF;}?>" width="64"></span>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
			<!--/ Statistics -->
		</div>
		<div class="col-sm-6">
			<!-- Statistics -->
			<div class="widget-container widget-stats boxed <?php if($iMode == '3') { echo $sBorderColorON;} else {echo $sBorderColorOFF;}?>">
				<div class="widget-title">
					<a class="link-refresh swichLink" href="javascript:void(0);" <?php if($sAccess == 2) {echo 'onclick="submitForm(\'3\');"';} ?> hidefocus="true" style="outline: medium none;">Swich Time-Out</a>
					<h3>Time-Out</h3>
				</div>
				<div class="stats-content clearfix">
					<div class="stats-content-right" style="text-align:center; margin-top:35px;">
						<h1 style="font-size:40px; color:<?php if($iMode == '3') { echo $sColorON;} else {echo $sColorOFF;}?>"><?php if($iMode == '3') { echo $sStatusON;} else {echo $sStatusOFF;}?><h1>
					</div>
					<div class="stats-content-left">
						<div class="inner">
							<div class="progressBar">
								<div class="progress-text clearfix" style="margin-top: 10px;text-align: center;">
									<span><img src="<?php if($iMode == '3') { echo $sImageON;} else {echo $sImageOFF;}?>" alt="<?php if($iMode == '3') { echo $sStatusON;} else {echo $sStatusOFF;}?>" width="64"></span>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
			<!--/ Statistics -->
		</div>
		<div class="col-sm-6">
			<!-- Statistics -->
			<div class="widget-container widget-stats boxed <?php if($iMode == '4') { echo $sBorderColorON;} else {echo $sBorderColorOFF;}?>">
				<div class="widget-title">
					<a class="link-refresh swichLink" href="javascript:void(0);" <?php if($sAccess == 2) {echo 'onclick="submitForm(\'4\');"';} ?> hidefocus="true" style="outline: medium none;">Swich Emergency</a>
					<h3>Emergency Stop</h3>
				</div>
				<div class="stats-content clearfix">
					<div class="stats-content-right" style="text-align:center; margin-top:35px;">
						<h1 style="font-size:40px; color:<?php if($iMode == '4') { echo $sColorON;} else {echo $sColorOFF;}?>"><?php if($iMode == '4') { echo $sStatusON;} else {echo $sStatusOFF;}?><h1>
					</div>
					<div class="stats-content-left">
						<div class="inner">
							<div class="progressBar">
								<div class="progress-text clearfix" style="margin-top: 10px;text-align: center;">
									<span><img src="<?php if($iMode == '4') { echo $sImageON;} else {echo $sImageOFF;}?>" alt="<?php if($iMode == '4') { echo $sStatusON;} else {echo $sStatusOFF;}?>" width="64"></span>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
			<!--/ Statistics -->
		</div>
	</div><!-- /.row -->
	</form>
      
<script type="text/javascript">
  function submitForm(iMode)
  {
    $("#iMode").val(iMode);
    $("#formChangeMode").submit();
  }
</script>
