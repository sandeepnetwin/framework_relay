<?php

$sAccess 		= '';
$sModule	    = '16';
$sDeviceFullName = '';
if($sDevice == 'L')
{
  $sDeviceFullName 	= 'Light';
}

$sAccessKey	= 'access_'.$sModule;
			  
if(!empty($aModules))
{
    if(in_array($sModule,$aModules->ids))
    {
	 $sAccess 		= $aModules->$sAccessKey;
    }
	else if(!in_array($sModule,$aModules->ids)) 
    {
		$sAccess 		= '0'; 
    }
}
  
  if($sAccess == '')
	$sAccess = '2' ; 
  
  if($sAccess == '0') {redirect(site_url('home/'));} 
  
  $iTotalIP	=	count($aIPDetails);
	  
	$sIPOptions	=	'';
	$iFirstIPId	=	'';	
	
	if($BackToIP != '')
		$iFirstIPId	= $BackToIP;
	
	if(!empty($aIPDetails))
	{
		foreach($aIPDetails as $aIP)
		{
			//First IP ID to show selected.
			if($iFirstIPId == '')
				$iFirstIPId = $aIP->id;
							
			$sDetails	=	$aIP->ip;
			if($aIP->name != '')
			{
				$sDetails .= ' ('.$aIP->name.')';
			}
			
			$sShow		=	'display:none';
			$sSelected	=	'';
			if($iFirstIPId == $aIP->id)
			{ 
				$sShow		=	'';
				$sSelected	=	'selected="selected"';
			} 
			
			$sIPOptions.='<option value="'.$aIP->id.'" '.$sSelected.'>'.$sDetails.'</option>';
		}
	}
?>
<style>
/*.fancybox-inner 
{
	height:40px !important;
}*/
@media (max-width:835px)
{
	.customType
	{
		padding-top: 10px;
		position: absolute;
	}
}
</style>
<script type="text/javascript" src="<?php echo HTTP_ASSETS_PATH.'fancybox/source/jquery.fancybox.js?v=2.1.5';?>"></script>
<link rel="stylesheet" type="text/css" href="<?php echo HTTP_ASSETS_PATH.'fancybox/source/jquery.fancybox.css?v=2.1.5';?>" media="screen" />
<script type="text/javascript">
var $a = $.noConflict();
$a(document).ready(function() {
    $a('.fancybox').fancybox({'closeBtn' : false,
    							autoSize : false,
								height: '40',
							  'helpers': {'overlay' : {'closeClick': false}}
                             });
    $a(".fancyboxVera").fancybox({
    	autoSize : false,
		height: '400',
		width:	'400',
    });                         
});
</script>	
<link href="<?php echo HTTP_ASSETS_PATH.'progressbar/css/static.css';?>" rel="stylesheet"/>
<script src="<?php echo HTTP_ASSETS_PATH.'progressbar/js/static.min.js';?>"></script>
<script src="<?php echo HTTP_ASSETS_PATH.'progressbar/dist/js/jquery.progresstimer.js';?>"></script>
<script>
	var cntOnPrograms 	= '<?php echo $cntOnPrograms;?>';
</script>
<script>
var confirmMessage = '';
var Base64 = {


    _keyStr: "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=",


    encode: function(input) {
        var output = "";
        var chr1, chr2, chr3, enc1, enc2, enc3, enc4;
        var i = 0;

        input = Base64._utf8_encode(input);

        while (i < input.length) {

            chr1 = input.charCodeAt(i++);
            chr2 = input.charCodeAt(i++);
            chr3 = input.charCodeAt(i++);

            enc1 = chr1 >> 2;
            enc2 = ((chr1 & 3) << 4) | (chr2 >> 4);
            enc3 = ((chr2 & 15) << 2) | (chr3 >> 6);
            enc4 = chr3 & 63;

            if (isNaN(chr2)) {
                enc3 = enc4 = 64;
            } else if (isNaN(chr3)) {
                enc4 = 64;
            }

            output = output + this._keyStr.charAt(enc1) + this._keyStr.charAt(enc2) + this._keyStr.charAt(enc3) + this._keyStr.charAt(enc4);

        }

        return output;
    },


    decode: function(input) {
        var output = "";
        var chr1, chr2, chr3;
        var enc1, enc2, enc3, enc4;
        var i = 0;

        input = input.replace(/[^A-Za-z0-9\+\/\=]/g, "");

        while (i < input.length) {

            enc1 = this._keyStr.indexOf(input.charAt(i++));
            enc2 = this._keyStr.indexOf(input.charAt(i++));
            enc3 = this._keyStr.indexOf(input.charAt(i++));
            enc4 = this._keyStr.indexOf(input.charAt(i++));

            chr1 = (enc1 << 2) | (enc2 >> 4);
            chr2 = ((enc2 & 15) << 4) | (enc3 >> 2);
            chr3 = ((enc3 & 3) << 6) | enc4;

            output = output + String.fromCharCode(chr1);

            if (enc3 != 64) {
                output = output + String.fromCharCode(chr2);
            }
            if (enc4 != 64) {
                output = output + String.fromCharCode(chr3);
            }

        }

        output = Base64._utf8_decode(output);

        return output;

    },

    _utf8_encode: function(string) {
        string = string.replace(/\r\n/g, "\n");
        var utftext = "";

        for (var n = 0; n < string.length; n++) {

            var c = string.charCodeAt(n);

            if (c < 128) {
                utftext += String.fromCharCode(c);
            }
            else if ((c > 127) && (c < 2048)) {
                utftext += String.fromCharCode((c >> 6) | 192);
                utftext += String.fromCharCode((c & 63) | 128);
            }
            else {
                utftext += String.fromCharCode((c >> 12) | 224);
                utftext += String.fromCharCode(((c >> 6) & 63) | 128);
                utftext += String.fromCharCode((c & 63) | 128);
            }

        }

        return utftext;
    },

    _utf8_decode: function(utftext) {
        var string = "";
        var i = 0;
        var c = c1 = c2 = 0;

        while (i < utftext.length) {

            c = utftext.charCodeAt(i);

            if (c < 128) {
                string += String.fromCharCode(c);
                i++;
            }
            else if ((c > 191) && (c < 224)) {
                c2 = utftext.charCodeAt(i + 1);
                string += String.fromCharCode(((c & 31) << 6) | (c2 & 63));
                i += 2;
            }
            else {
                c2 = utftext.charCodeAt(i + 1);
                c3 = utftext.charCodeAt(i + 2);
                string += String.fromCharCode(((c & 15) << 12) | ((c2 & 63) << 6) | (c3 & 63));
                i += 3;
            }

        }

        return string;
    }

}
jQuery(document).ready(function($) 
{
    setInterval( function() {
		var sDevice	= '<?php echo $sDevice;?>';
		var IpId	= $("#IpId").val();	
		$.ajax({
				type: "POST",
				url: "<?php echo site_url('home/getStatus/');?>", 
				data: {sDevice:sDevice,IpId:IpId},
				success: function(data) {
					var deviceStatus = jQuery.parseJSON(data);
					var lableText   = 'lableRelay-';
					
					$.each( deviceStatus, function( iDevice, sStatus ) 
					{
						if(iDevice != 'iActiveMode')
						{
							if(sStatus >= '1')
							{
								if(!$("#"+lableText+iDevice+"-"+IpId).hasClass('checked'))
								{
									$("#"+lableText+iDevice+"-"+IpId).addClass('checked');
									$("#lightImage_"+iDevice+"_"+IpId).attr('src','<?php echo HTTP_IMAGES_PATH."icons/light_on.png";?>');
								}
							}
							else if(sStatus == '0')
							{
								if($("#"+lableText+iDevice+"-"+IpId).hasClass('checked'))
								{
									$("#"+lableText+iDevice+"-"+IpId).removeClass('checked');
									$("#lightImage_"+iDevice+"_"+IpId).attr('src','<?php echo HTTP_IMAGES_PATH."icons/light_off.png";?>');
								}
							}
						}
						else if(iDevice == 'iActiveMode')
						{
							var strMode = '';
							if(sStatus == '1') 
							{
								strMode = 'Pool Mode Auto';
							}
							else if(sStatus == '2') 
							{
								strMode = 'Pool Mode Manual';
							}
							else if(sStatus == '3') 
							{
								strMode = 'Time-out';
							}
							
							$(".activeModeMini").html(strMode);
						}
					});
				}
		});
	},30000);
	
    $(".relayRadio").click(function()
    {
        var chkVal 		= $(this).val();
        var relayNumber	= $(this).attr('name').split("_");
		var sIdIP		= $("#IpId").val();			

        $.ajax({
                type: "POST",
                url: "<?php echo site_url('home/saveDeviceMainType');?>", 
                data: {sDeviceID:relayNumber[0],sDevice:'L',sType:chkVal,sIdIP:sIdIP},
                success: function(data) {
                        if(chkVal == 0)
                        {
							$("#relay_other_"+relayNumber[0]+"_"+sIdIP).addClass('checked');
							$("#relay_spa_"+relayNumber[0]+"_"+sIdIP).removeClass('checked');
							$("#relay_pool_"+relayNumber[0]+"_"+sIdIP).removeClass('checked');
                        }
                        else if(chkVal == 1)
                        {
							$("#relay_other_"+relayNumber[0]+"_"+sIdIP).removeClass('checked');
							$("#relay_spa_"+relayNumber[0]+"_"+sIdIP).addClass('checked');
							$("#relay_pool_"+relayNumber[0]+"_"+sIdIP).removeClass('checked');
                        }
                        else if(chkVal == 2)
                        {
							$("#relay_other_"+relayNumber[0]+"_"+sIdIP).removeClass('checked');
							$("#relay_spa_"+relayNumber[0]+"_"+sIdIP).removeClass('checked');
							$("#relay_pool_"+relayNumber[0]+"_"+sIdIP).addClass('checked');
                        }

                }

            });
    });
    
    $(".lightButton").click(function()
	{
		var chkVal      = $(this).val();
		var arrDetails	= chkVal.split("|||");	
		
		var sIdIP		= $("#IpId").val();
		
		var BlowerNumber = arrDetails[0];
			
		var element = 	$("#lableRelay-"+BlowerNumber+"-"+sIdIP).prev('input');
		var Exclude = 	element.attr('data-exclude');
		
		var iActiveMode = $("#hidActiveMode").val();
		var chkConfirm = true;
		if((cntOnPrograms >= 1 || iActiveMode == 1) && Exclude == 0)
		{
			if(confirmMessage != '1')
			{
				chkConfirm = confirm("Are you sure you want to make this device ON/OFF?\nThis will stop all Custom Programs/Programs running in background!");
				confirmMessage	=	'1';
			}
		}
		
		if(chkConfirm)
		{
			var chkVal      = $(this).val();
			var arrDetails	= chkVal.split("|||");	
			var sIdIP		= $("#IpId").val();
			
			var lightNumber = arrDetails[0];
			var relayNumber = arrDetails[2];
			var sDevice     = '';
			
			if(arrDetails[1] == '24')
				sDevice     =   'R';    
			else if(arrDetails[1] == '12')
				sDevice     =   'P';
			
			if(iActiveMode != 3)
			{
				if(iActiveMode != 2 && Exclude == 0)
				{
					changeModeToManual();
				}
				$(".loading-progress").show();
				var progress = $(".loading-progress").progressTimer({
						timeLimit: 10,
						onFinish: function () {
							parent.$a.fancybox.close();
						}
				});
				
				
				$a("#checkLink").trigger('click');

				var status		= '';
				if($("#lableRelay-"+lightNumber+"-"+sIdIP).hasClass('checked'))
				{	
						status	=	0;
				}
				else
				{
						status = 1;
				}


					$.ajax({
						type: "POST",
						url: "<?php echo site_url('home/updateStatusOnOff/');?>", 
						data: {sName:relayNumber,sStatus:status,sDevice:sDevice,sIdIP:sIdIP},
						success: function(data) {
								if($("#lableRelay-"+lightNumber+"-"+sIdIP).hasClass('checked'))
								{	
										$("#lableRelay-"+lightNumber+"-"+sIdIP).removeClass('checked');
										$("#lightImage_"+lightNumber+"_"+sIdIP).attr('src','<?php echo HTTP_IMAGES_PATH."icons/light_off.png";?>');
										
								}
								else
								{
										$("#lableRelay-"+lightNumber+"-"+sIdIP).addClass('checked');
										$("#lightImage_"+lightNumber+"_"+sIdIP).attr('src','<?php echo HTTP_IMAGES_PATH."icons/light_on.png";?>');
								}
								$("#hidActiveMode").val(iActiveMode);

						}
				}).error(function(){
					progress.progressTimer('error', {
						errorText:'ERROR!',
						onFinish:function(){
							alert('There was an error processing your information!');
						}
					});
				}).done(function(){
						progress.progressTimer('complete');
						location.reload();
				});
			}
			else
			{
				alert('You can not perform this operation in Time-out Mode.');
			}
		}			
    });
    
    
    $(".lightRadio").click(function()
    {
		var chkVal 		= $(this).val();
		var lightNumber	= $(this).attr('name').split("_");	
		
		var IpId		= $("#IpId").val();
		
		if(chkVal == 24)
		{
				$("#24VRelay_"+lightNumber[1]+"_"+IpId).show();
				$("#12VRelay_"+lightNumber[1]+"_"+IpId).hide();
		}
		else if(chkVal == 12)
		{
				$("#12VRelay_"+lightNumber[1]+"_"+IpId).show();
				$("#24VRelay_"+lightNumber[1]+"_"+IpId).hide();
		}

    });
    
    $(".DeviceTypeRadio").click(function()
    {
    	var DeviceType 	=	$(this).val();
    	var Name		=	$(this).attr('name');
    	var ArrName		=	Name.split("_");
    	var DeviceNumber=	ArrName[1];
    	var DeviceIPID  =	ArrName[2];
    	if(DeviceType == 'Relayboard')
    	{
			$("#Vera_"+DeviceNumber+"_"+DeviceIPID).hide();
			$("#Relayboard_"+DeviceNumber+"_"+DeviceIPID).show();
		}
		else if(DeviceType == 'Vera')
		{
			$("#Relayboard_"+DeviceNumber+"_"+DeviceIPID).hide();
			$("#Vera_"+DeviceNumber+"_"+DeviceIPID).show();
		}
    });
    
});

function refreshDeviceStatus(sDevice)
{
	if(sDevice == '')
	{
		alert("Not Valid Device Type!");
		return false;
	}
	else
	{
		$("#refreshLoading_"+IpId).css('display','flex').show();
		var IpId	= $("#IpId").val();	
		setTimeout( function(){
		$.ajax({
					type: "POST",
					url: "<?php echo site_url('home/refreshDeviceStatus/');?>", 
					data: {sDevice:sDevice,IpId:IpId},
					success: function(data) 
					{
						var deviceStatus = jQuery.parseJSON(data);
						var lableText   = 'lableRelay-';
					
						$.each( deviceStatus, function( iDevice, sStatus ) 
						{
							if(iDevice != 'iActiveMode')
							{
								if(sStatus >= '1')
								{
									if(!$("#"+lableText+iDevice+"-"+IpId).hasClass('checked'))
									{
										$("#"+lableText+iDevice+"-"+IpId).addClass('checked');
									}
								}
								else if(sStatus == '0')
								{
									if($("#"+lableText+iDevice+"-"+IpId).hasClass('checked'))
									{
										$("#"+lableText+iDevice+"-"+IpId).removeClass('checked');
									}
								}
							}
							else if(iDevice == 'iActiveMode')
							{
								var strMode = '';
								if(sStatus == '1') 
								{
									strMode = 'Pool Mode Auto';
								}
								else if(sStatus == '2') 
								{
									strMode = 'Pool Mode Manual';
								}
								else if(sStatus == '3') 
								{
									strMode = 'Time-out';
								}
								
								$(".activeModeMini").html(strMode);
							}
						});
						
						$("#refreshLoading_"+IpId).css('display','none');
					}
				});
		},500);
	}
	
}

function changeModeToManual()
{
	$.ajax({
				type: "POST",
				url: "<?php echo site_url('analog/changeMode');?>", 
				data: {iMode:'2'},
				success: function(data) {
					$("#hidActiveMode").val('2');
				}
		   });
}


function saveDevicePort(iDeviceNum,sDeviceType,sPort)
{
	if(sPort == '')
	{
		alert("Please select Port number!");
		return false;
	}
	else
	{
		$("#selPort_L_"+iDeviceNum).css('border','');
		$(".loading-progress").show();
		var progress = $(".loading-progress").progressTimer({
			timeLimit: 10,
			onFinish: function () {
			  setTimeout(function(){location.reload();parent.$a.fancybox.close();},1000);
			}
		});
				
		$a("#checkLink").trigger('click');
		
		$.ajax({
			type: "POST",
			url: "<?php echo site_url('home/saveDevicePort/');?>", 
			data: {iDeviceNum:iDeviceNum,sDeviceType:sDeviceType,sPort:sPort},
			success: function(data) 
			{
				
			}
		}).error(function(){
			progress.progressTimer('error', {
				errorText:'ERROR!',
				onFinish:function(){
					alert('There was an error processing your information!');
				}
			});
		}).done(function(){
			progress.progressTimer('complete');
		});
	}
}
function cancel(lightNumber,ipID)
{
	$("#24VRelay_"+lightNumber+"_"+ipID).hide();
	$("#12VRelay_"+lightNumber+"_"+ipID).hide();
	
	$("#lightRelay24_"+lightNumber+"_"+ipID).prop('checked',false);
	$("#lightRelay12_"+lightNumber+"_"+ipID).prop('checked',false);
}

function removeLight(lightNumber,ipID)
{
	var check	=	confirm("Are you sure you want to remove this light?");
	if(check)
	{
		$.ajax({
            type: "POST",
            url: "<?php echo site_url('analog/removeLight/');?>", 
            data: {lightNumber:lightNumber,ipID:ipID},
            async: false,
            success: function(data) {
                    alert("Light removed successfully!");
                    //location.reload();
					location.href='<?php echo base_url('analog/showLight');?>'+'/'+Base64.encode(ipID);
            }
		});
	}
}

function save(lightNumber,relayType,ipID)
{
    $("#loadingImg"+relayType+"_"+lightNumber+"_"+ipID).show();
    var relayNumber	=	$("#select"+relayType+"VRelays_"+lightNumber+"_"+ipID).val();

    //Check if entered address already exists.
    var checkRelay = 0;
    $.ajax({
            type: "POST",
            url: "<?php echo site_url('home/checkRelayNumberAlreadyAssigned/');?>", 
            data: {sRelayNumber:relayNumber,type:relayType,sDeviceId:lightNumber,ipID:ipID},
            async: false,
            success: function(data) {
                    var obj = jQuery.parseJSON( data );
                    if(obj.iPumpCheck == '1')
                    {
                            checkRelay = 1;
                            $("#sRelayNumber").css('border','1px Solid Red');
                            alert('Relay number is already used by other Device or not available!');
                            //return false;
                    }
                    else
                    {
                        if(checkRelay == 0)
                        {
							$.ajax({
									type: "POST",
									url: "<?php echo site_url('home/saveLightRelay/');?>", 
									async: false,
									data: {sRelayNumber:relayNumber,sDevice:'L',sDeviceId:lightNumber,sRelayType:relayType,ipID:ipID},
									async: false,
									success: function() {
										alert('Relay is assigned to light successfully!')
										//location.reload();
										location.href='<?php echo base_url('analog/showLight');?>'+'/'+Base64.encode(ipID);
									}
							});
                        }
                    }
                    
                    $("#loadingImg"+relayType+"_"+lightNumber+"_"+ipID).hide();
            }
    });
}
function showBoardDetails(board)
{
	if(board == '')
	{
		alert("Please select IP first!");
		return false;
	}
	/* $("[id^='onoffbuttons_']").hide();
	$("[id^='relayConfigure_']").hide();
	
	$("#onoffbuttons_"+board).show();
	$("#relayConfigure_"+board).show(); */
	
	
	$("#IpId").val(board);
	var IpId = $("#IpId").val();
	location.href='<?php echo base_url('analog/showLight');?>'+'/'+Base64.encode(IpId);
}

function showVeraLightSetting(DeviceNumber,DeviceIPID)
{
	$a("#deviceID").val(DeviceNumber);
	$a("#deviceIPID").val(DeviceIPID);
	$a("#fancyboxVera").trigger('click');
}
</script>
<div class="row">
	<div class="col-sm-12">
		<ol class="breadcrumb" style="float:left">
		  <li><img src="<?php echo HTTP_IMAGES_PATH.'icons/home.png';?>" width="24" style="vertical-align: middle !important;">&nbsp;<a href="<?php echo site_url();?>">Home</a> </li>
		  <li class="active"><?php echo $sDeviceFullName;?></li>
		</ol>
		
	</div>
</div>	

<div class="row">
	<div class="col-sm-12">
	<span style="color:#FFF; font-weight:bold;">Select Board : </span>
	<select name="selPort" id="selPort" onchange="showBoardDetails(this.value)">
		<option value="">--IP(Name)--</option>
		<?php echo $sIPOptions;?>
	</select>	
	</div>
</div>
<div class="row">
	<div class="col-sm-12">&nbsp;</div>
</div>
		
<!-- START : 24V AC RELAY -->
<?php if($sDevice == 'L') 
	  { ?>
	<?php if($sAccess == '1' || $sAccess == '2') 
		  { ?>
			<div class="row">
				<?php
					if(!empty($aIPDetails))
					{
						foreach($aIPDetails as $aIP)
						{ 
							if(${"numLight".$aIP->id} == 0 || ${"numLight".$aIP->id} == '')
							{
								echo '<div class="col-sm-12">';
								echo '<span style="color:#FFF;">Add number of Lights from the Basic Setting Page!</span>';
								echo '</div>';
							} 
							else
							{
							
				?>
				<div class="col-sm-4" id="onoffbuttons_<?php echo $aIP->id;?>" style="display:<?php if($aIP->id != $iFirstIPId){ echo 'none';} ?>">
					<div class="widget-container widget-stats boxed green-line">
					<div class="refreshLoading" id="refreshLoading_<?php echo $aIP->id;?>"><img src="<?php echo base_url("assets/images/loading.gif");?>" alt="loading">&nbsp;Refreshing Devices....</div>
							<div class="widget-title">
								<a href="javascript:void(0);" class="link-refresh" id="link-refresh-1" onclick="refreshDeviceStatus('L');"><span class="glyphicon glyphicon-refresh"></span></a>
								<h3>ON/OFF</h3>
							</div>
							<div class="stats-content clearfix">
								<div class="stats-content-right" style="width:96% !important; margin-left:5px; margin-right:5px; float:none; margin-top:10px;">
								<?php
								for ($i=0;$i<${"numLight".$aIP->id}; $i++)
								{	
									$strLightName	=   'Light '.($i+1);
                                                                        
									$sRelayType     =   '';
									$sRelayNumber   =   '';
									$strLight		=   'light_off.png';
									$sLightStatus	=	0;
									
									$aLightDetails  =   $this->home_model->getLightDeviceDetails($i,$aIP->id);
									if(!empty($aLightDetails))
									{
										foreach($aLightDetails as $aLight)
										$sRelayDetails  =   unserialize($aLight->light_relay_number);
										
										$sRelayType     =   $sRelayDetails['sRelayType'];
										$sRelayNumber   =   $sRelayDetails['sRelayNumber'];
										
										if($sRelayType == '24')
										{
											$sLightStatus   =   ${"sRelays".$aIP->id}[$sRelayNumber];
											if($sLightStatus)
												$strLight   =   'light_on.png';
										}
										if($sRelayType == '12')
										{
											
											$sLightStatus   =   ${"sPowercenter".$aIP->id}[$sRelayNumber];
											if($sLightStatus)
												$strLight   =   'light_on.png';
										}
									}
									$strChecked	=	'';
									if($sLightStatus)
									{
										$strChecked	=	'class="checked"';
									}
									
							if($sRelayNumber != '')
							{
								$IsExcluded = $this->home_model->getDeviceExcluded($i,'L',$aIP->id);
							?>
							
							<div class="rowCheckbox switch">
								<img id="lightImage_<?php echo $i;?>_<?php echo $aIP->id;?>" src="<?php echo HTTP_IMAGES_PATH.'icons/'.$strLight;?>" style="width:64px;">
								<div class="custom-checkbox" style="float:right; margin-right:10px; margin-top:20px;"><input type="checkbox" value="<?php echo $i.'|||'.$sRelayType.'|||'.$sRelayNumber;?>" id="relay_<?php echo $i?>_<?php echo $aIP->id;?>" name="relay-<?php echo $i?>" class="lightButton" hidefocus="true" style="outline: medium none;" data-exclude ="<?php echo $IsExcluded;?>">
									<label <?php echo $strChecked;?>  id="lableRelay-<?php echo $i?>-<?php echo $aIP->id;?>" for="relay_<?php echo $i?>_<?php echo $aIP->id;?>"><span style="color:#C9376E;"><?php echo $strLightName;?></span></label>
								</div>
							</div>
							<?php           } else { ?>
                            <div class="rowCheckbox switch">
							<span style="color:#C9376E; font-weight: bold;">Relay not assinged to <?php echo $strLightName;?></span>
							</div>
                                                        <?php } ?>
                                                        <div style="height:30px;">&nbsp;</div>
							<?php 			
								 }
							?> 
								</div>
							</div>
					</div>
				</div>
				  
				<div class="col-sm-8" id="relayConfigure_<?php echo $aIP->id;?>" style="display:<?php if($aIP->id != $iFirstIPId){ echo 'none';} ?>">
						<!-- Statistics -->
						<div class="widget-container widget-stats boxed green-line">
							<div class="widget-title">
								<a href="<?php echo base_url('analog/showLight');?>" class="link-refresh" id="link-refresh-1"><span class="glyphicon glyphicon-refresh"></span></a>
								<h3>Light Settings</h3>
							</div>
							<div class="stats-content clearfix">
								<div class="stats-content-right" style="width:100% !important; margin-left:5px; margin-right:5px; float:none;">
							
							  <table class="table table-hover">
								<thead>
								  <tr>
									<th class="header">Light</th>
									<!--<th class="header"  style="width:25%">Type</th>
									<th class="header"  style="width:50%">Action</th>-->
								  </tr>
								</thead>
								<tbody>
								<?php	

								for ($i=0;$i < ${"numLight".$aIP->id}; $i++)
								{
										$sRelayNameDb = 'Add Name';
										$sMainType =	$this->home_model->getDeviceMainType($i,$sDevice,$aIP->id);
                                                                                
										$sRelayType     =   '';
										$sRelayNumber   =   '';
										
										$aLightDetails  =   $this->home_model->getLightDeviceDetails($i,$aIP->id);
										if(!empty($aLightDetails))
										{
											foreach($aLightDetails as $aLight)
											{
												$sRelayDetails  =   unserialize($aLight->light_relay_number);
												$DeviceType		=	$aLight->DeviceType;
											}
											

											$sRelayType     =   $sRelayDetails['sRelayType'];
											$sRelayNumber   =   $sRelayDetails['sRelayNumber'];
										}
										
										$sRelayNameDb =  $this->home_model->getDeviceName($i,$sDevice,$aIP->id);
										if($sRelayNameDb == '')
										$sRelayNameDb = 'Add Name';
										
									?>
										<tr>
										<td>
										<div class="row">
										<?php if(in_array($i.'_'.$aIP->id, $excludeDevices['L'])) { ?>
											<div class="col-sm-12">
													<div style="position:relative;top:0;margin-bottom:10px;" class="ribbon ribbon-green"><span style="line-height:0px; font-size:14px;"><?php echo EXCLUDE_DEVICE;?></span></div>
											</div>		
										<?php } ?>
										<div class="col-sm-3">
											Light <?php echo ($i+1);?><br />(<a href="<?php if($sAccess == '2') { echo site_url('home/deviceName/'.base64_encode($i).'/'.base64_encode($sDevice).'/'.base64_encode($aIP->id)); } else { echo 'javascript:void(0);';} ?>"><?php echo $sRelayNameDb;?></a>)
										</div>
										<div class="col-sm-3">
											<div class="rowRadio">
											<div class="custom-radio">
											<strong class="customType">Type</strong><br><br>
											<input class="relayRadio" type="radio" id="radio-other-<?php echo $i;?>-<?php echo $aIP->id;?>" value="0" name="<?php echo $i;?>_MainType" <?php if($sMainType == '0' || $sMainType == ''){ echo 'checked="checked"';}?> <?php if($sAccess == '1') { echo 'disabled="disabled"';}?> hidefocus="true" style="outline: medium none;">
											<label style="display:inline-block;" id="relay_other_<?php echo $i;?>_<?php echo $aIP->id;?>" for="radio-other-<?php echo $i;?>-<?php echo $aIP->id;?>" class="<?php if($sMainType == '0' || $sMainType == ''){ echo 'checked';}?>">Other</label>
											
											<input class="relayRadio" type="radio" id="radio-spa-<?php echo $i;?>-<?php echo $aIP->id;?>" name="<?php echo $i;?>_MainType" value="1" <?php if($sMainType == '1'){ echo 'checked="checked"';}?> <?php if($sAccess == '1') { echo 'disabled="disabled"';}?> hidefocus="true" style="outline: medium none;">
											<label style="display:inline-block;" id="relay_spa_<?php echo $i;?>_<?php echo $aIP->id;?>" for="radio-spa-<?php echo $i;?>-<?php echo $aIP->id;?>" class="<?php if($sMainType == '1'){ echo 'checked';}?>">Spa</label>
											
											<input class="relayRadio" type="radio" id="radio-pool-<?php echo $i;?>-<?php echo $aIP->id;?>" name="<?php echo $i;?>_MainType" value="2" <?php if($sMainType == '2'){ echo 'checked="checked"';}?> <?php if($sAccess == '1') { echo 'disabled="disabled"';}?> hidefocus="true" style="outline: medium none;">
											<label style="display:inline-block;" id="relay_pool_<?php echo $i;?>_<?php echo $aIP->id;?>" for="radio-pool-<?php echo $i;?>-<?php echo $aIP->id;?>" class="<?php if($sMainType == '2'){ echo 'checked';}?>">Pool</label>
											</div>
											</div>
										</div>
										<div class="col-sm-6">
											<strong>Action</strong><br><br>
											
											<input type="radio" <?php if($DeviceType == 'Relayboard'){ echo 'checked="checked"';}?> class="DeviceTypeRadio" name="DeviceType_<?php echo $i;?>_<?php echo $aIP->id;?>" value="Relayboard">&nbsp;Relayboard Light
											&nbsp;&nbsp;
											<input type="radio" <?php if($sRelayType == 'Vera'){ echo 'checked="checked"';}?> class="DeviceTypeRadio" name="DeviceType_<?php echo $i;?>_<?php echo $aIP->id;?>" value="Vera">&nbsp;Vera Light
											<br><br>
											<div id="Relayboard_<?php echo $i;?>_<?php echo $aIP->id;?>" style="display: <?php if($DeviceType != 'Relayboard'){ echo 'none';}?>;">
												<input type="radio" <?php if($sRelayType == '24'){ echo 'checked="checked"';}?> class="lightRadio" name="lightRelay_<?php echo $i;?>_<?php echo $aIP->id;?>" id="lightRelay24_<?php echo $i;?>_<?php echo $aIP->id;?>" value="24">&nbsp;24V AC Relay
												&nbsp;&nbsp;
												<input type="radio" class="lightRadio" name="lightRelay_<?php echo $i;?>_<?php echo $aIP->id;?>" id="lightRelay12_<?php echo $i;?>_<?php echo $aIP->id;?>" <?php if($sRelayType == '12'){ echo 'checked="checked"';}?> value="12">&nbsp;12V DC Relay
												<div id="24VRelay_<?php echo $i;?>_<?php echo $aIP->id;?>" style="display:<?php if($sRelayType == '24'){ echo '';} else {echo 'none';}?>; padding-top:10px;">
												<select name="select24VRelays_<?php echo $i;?>_<?php echo $aIP->id;?>" id="select24VRelays_<?php echo $i;?>_<?php echo $aIP->id;?>" class="form-control" style="width:80%">
												<?php
														for ($j=0;$j < ${"relay_count".$aIP->id}; $j++)
														{
															$strSelect= "";
															$iRelayVal = ${"sRelays".$aIP->id}[$j];
															
															if($j == $sRelayNumber)
																$strSelect= "selected='selected'";
															
															if($iRelayVal != '' && $iRelayVal !='.') 
															{
																echo '<option value="'.$j.'" '.$strSelect.'>Relay '.$j.'</option>';
															}
														}
												?>
												</select>
												<a href="javascript:void(0);" class="btn btn-small btn-green" style="padding:6px 0 !important;" <?php if($sAccess == '2') {echo 'onclick="save(\''.$i.'\',\'24\',\''.$aIP->id.'\');"';} ?>><span>Save</span></a>
												&nbsp;&nbsp;
												<a href="javascript:void(0);" class="btn btn-small btn-gray" style="padding:6px 0 !important;" <?php if($sAccess == '2') {echo 'onclick="cancel(\''.$i.'\',\''.$aIP->id.'\');"';} ?>><span>Cancel</span></a>
												&nbsp;&nbsp;
												<a href="javascript:void(0);" class="btn btn-small " style="padding:6px 0 !important;" <?php if($sAccess == '2') {echo 'onclick="removeLight(\''.$i.'\',\''.$aIP->id.'\');"';} ?>><span>Remove</span></a>
												&nbsp;&nbsp;
												<span id="loadingImg24_<?php echo $i;?>_<?php echo $aIP->id;?>" style="display:none;"><img src="<?php echo site_url('assets/images/loading.gif');?>" alt="Loading...." width="32" height="32"></span>
												</div>
												<div id="12VRelay_<?php echo $i;?>_<?php echo $aIP->id;?>" style="display:<?php if($sRelayType == '12'){ echo '';} else {echo 'none';}?>;padding-top:10px;">
												<select name="select12VRelays_<?php echo $i;?>_<?php echo $aIP->id;?>" id="select12VRelays_<?php echo $i;?>_<?php echo $aIP->id;?>" class="form-control" style="width:80%">
												<?php
													for ($j=0;$j < ${"power_count".$aIP->id}; $j++)
													{
														$strSelect  =   '';
														$iRelayVal = ${"sPowercenter".$aIP->id}[$j];
														
														if($j == $sRelayNumber)
															 $strSelect= "selected='selected'";
														
														if($iRelayVal != '' && $iRelayVal !='.') 
														{
																echo '<option value="'.$j.'" '.$strSelect.'>PowerCenter '.$j.'</option>';
														}
													}
												?>
												</select>
												<a href="javascript:void(0);" class="btn btn-small btn-green" style="padding:6px 0 !important;" <?php if($sAccess == '2') {echo 'onclick="save(\''.$i.'\',\'12\',\''.$aIP->id.'\');"';} ?>><span>Save</span></a>
												&nbsp;&nbsp;
												<a href="javascript:void(0);" class="btn btn-small btn-gray" style="padding:6px 0 !important;" <?php if($sAccess == '2') {echo 'onclick="cancel(\''.$i.'\',\''.$aIP->id.'\');"';} ?>><span>Cancel</span></a>
												&nbsp;&nbsp;
												<a href="javascript:void(0);" class="btn btn-small " style="padding:6px 0 !important;" <?php if($sAccess == '2') {echo 'onclick="removeLight(\''.$i.'\',\''.$aIP->id.'\');"';} ?>><span>Remove</span></a>
												&nbsp;&nbsp;
												<span id="loadingImg12_<?php echo $i;?>_<?php echo $aIP->id;?>" style="display:none;"><img src="<?php echo site_url('assets/images/loading.gif');?>" alt="Loading...." width="32" height="32"></span>
												</div>
											</div>
											<div id="Vera_<?php echo $i;?>_<?php echo $aIP->id;?>" style="display: <?php if($DeviceType != 'Vera'){ echo 'none';}?>;">
											<a href="javascript:void(0);" class="btn btn-small " style="padding:6px 0 !important;" <?php if($sAccess == '2') {echo 'onclick="showVeraLightSetting(\''.$i.'\',\''.$aIP->id.'\');"';} ?>><span>Vera Light Setting</span></a>
											</div>
										</div>
										</div>
										</td>
										</tr>
								
								<?php  } ?>	
								</tbody>
								</table>
								</div>
							</div>
						</div>
						<!--/ Statistics -->
					</div>
				</div><!-- /.row -->
			<?php } ?>
		<?php } ?>
		<input type="hidden" id="IpId" value="<?php echo $iFirstIPId;?>">
		<input type="hidden" id="hidActiveMode" value="<?php echo $iActiveMode;?>">	
	<?php } ?>
	
	<?php } ?>
<?php } //Relay Device End ?>	
<!-- END : 24V AC RELAY -->
<p>
<a class="fancybox" id="checkLink" href="#inline1" style="display:none;">&nbsp;</a>
<div id="inline1" style="width:250px;height:40px; display:none;"><div class="loading-progress"></div></div>
</p>

<p>
<a class="fancyboxVera" id="fancyboxVera" href="#VeraSettingForm" style="display:none;">&nbsp;</a>
<div id="VeraSettingForm" style="width:auto;height:auto;display:none;">
	<h3>Vera Light Setting</h3>
	<input type="hidden" name="deviceID" id="deviceID" value="">
	<input type="hidden" name="deviceIPID" id="deviceIPID" value="">
	<table>
	<tr>
		<td width="39%">Device Number</td>
		<td width="1%">&nbsp;</td>
		<td width="50%"><input type="text" name="DeviceNumber" id="DeviceNumber" value=""></td>
	</tr>
	<tr><td colspan="3">&nbsp;</td></tr>
	<tr>
		<td>Device Manufacturer</td>
		<td>&nbsp;</td>
		<td><input type="text" name="DeviceManufacturer" id="DeviceManufacturer" value=""></td>
	</tr>
	<tr><td colspan="3">&nbsp;</td></tr>
	<tr>
		<td>Device Model</td>
		<td>&nbsp;</td>
		<td><input type="text" name="DeviceModel" id="DeviceModel" value=""></td>
	</tr>
	<tr><td colspan="3">&nbsp;</td></tr>
	<tr>
		<td>Is Slider Light?</td>
		<td>&nbsp;</td>
		<td><input type="radio" name="isSlider" value="1" id="SliderYes">Yes&nbsp;&nbsp;<input type="radio" name="isSlider" value="0" id="SliderNo" checked="checked">No</td>
	</tr>
	<tr><td colspan="3">&nbsp;</td></tr>
	<tr><td colspan="3" align="center"><a href="javascript:void(0);" class="btn" style="padding:6px 0 !important;" onclick="validateDetails();"><span>Save</span></a>&nbsp;&nbsp;<a href="javascript:void(0);" class="btn" style="padding:6px 0 !important;" onclick="javascript:parent.$a.fancybox.close();"><span>Cancel</span></a>
	&nbsp;<span id="loadingImgVera" style="display:none;"><img src="<?php echo site_url('assets/images/loading.gif');?>" alt="Loading...." width="32" height="32"></span>
	</td></tr>
</table>
</div>
</p>
<script>
function validateDetails()
{
	var DeviceNumber 		= $("#DeviceNumber").val();
	var DeviceManufacturer 	= $("#DeviceManufacturer").val();
	var DeviceModel  		= $("#DeviceModel").val();
	var deviceIPID			= $("#deviceIPID").val();	
	var deviceID			= $("#deviceID").val();	
	var IsSlider			= $("input[name='isSlider']:checked").val();
	var errorMsg			=	'';
	
	if(DeviceNumber == '')
	{
		errorMsg += 'Please Enter Device Number!\n';
	}
	if(DeviceManufacturer == '')
	{
		errorMsg += 'Please Enter Device Manufacturer!\n';
	}
	if(DeviceModel == '')
	{
		errorMsg += 'Please Enter Device Model!\n';
	}
	
	if(errorMsg != '')
	{
		alert("Below are the errors:\n\n"+errorMsg);
		return false;
	}
	else
	{
		$("#loadingImgVera").show();
		$.ajax({
				type: "POST",
				url: "<?php echo site_url('device/saveVeraLightSetting/');?>", 
				data: {deviceID:deviceID,deviceIPID:deviceIPID,DeviceNumber:DeviceNumber,DeviceManufacturer:DeviceManufacturer,DeviceModel:DeviceModel,IsSlider:IsSlider},
				success: function(data) {
					$("#loadingImgVera").hide();
					alert("Vera Light Device Setting is Saved Successfully!");
					parent.$a.fancybox.close();
				}
			})
	}
	
}	
</script>
