<?php
$this->load->model('home_model');
$sAccess 		= '';
$sModule	    = '';
$sDeviceFullName = '';
if($sDevice == 'L')
{
  $sDeviceFullName 	= 'Light';
}

  /* $sAccessKey	= 'access_'.$sModule;
			  
  if(!empty($aModules))
  {
	  if(in_array($sModule,$aModules->ids))
	  {
		 $sAccess 		= $aModules->$sAccessKey;
	  }
  }
  
  if($sAccess == '')
	$sAccess = '2' ; 
  
  if($sAccess == '0') {redirect(site_url('home/'));} */
?>
<script type="text/javascript" src="<?php echo HTTP_ASSETS_PATH.'fancybox/source/jquery.fancybox.js?v=2.1.5';?>"></script>
<link rel="stylesheet" type="text/css" href="<?php echo HTTP_ASSETS_PATH.'fancybox/source/jquery.fancybox.css?v=2.1.5';?>" media="screen" />
<script type="text/javascript">
var $a = $.noConflict();
$a(document).ready(function() {
	$a('.fancybox').fancybox({'closeBtn' : false,'helpers': {'overlay' : {'closeClick': false}}
	});
});
</script>	
<link href="<?php echo HTTP_ASSETS_PATH.'progressbar/css/static.css';?>" rel="stylesheet"/>
<script src="<?php echo HTTP_ASSETS_PATH.'progressbar/js/static.min.js';?>"></script>
<script src="<?php echo HTTP_ASSETS_PATH.'progressbar/dist/js/jquery.progresstimer.js';?>"></script>
<script>
jQuery(document).ready(function($) {
	
	$(".displayMore").hide();
	$(".more").click(function() {
		var txt	=	$(this).html();
		if(txt == 'More +')
			txt = 'More -';
		else
			txt = 'More +';
		
		$(".displayMore").toggle('slow',function() {	
			$(".more").html(txt);
		});
		
	});
	
	$("#addMoreValve").click(function() {
		$("#moreValve").slideToggle('slow');
	});
	
	$(".relayButton").click(function()
	{
	});
	
	
	$(".lightRadio").click(function()
	{
		var chkVal 		= $(this).val();
		var relayNumber	= $(this).attr('name').split("_");	
		//console.log(relayNumber+'>>>'+chkVal);
		if(chkVal == 24)
		{
			$("#24VRelay_"+relayNumber[1]).show();
			$("#12VRelay_"+relayNumber[1]).hide();
		}
		else if(chkVal == 12)
		{
			$("#12VRelay_"+relayNumber[1]).show();
			$("#24VRelay_"+relayNumber[1]).hide();
		}
			
	});
});
</script>
<div class="row">
	<div class="col-sm-12">
		<ol class="breadcrumb" style="float:left">
		  <li><img src="<?php echo HTTP_IMAGES_PATH.'icons/home.png';?>" width="24" style="vertical-align: middle !important;">&nbsp;<a href="<?php echo site_url();?>">Home</a> </li>
		  <li class="active"><?php echo $sDeviceFullName;?></li>
		</ol>
		<ol class="breadcrumb" style="float:right;">
		  <li><a href="<?php echo base_url('home/setting/R/');?>">24V AC Relays</a></li>
		  <li><a href="<?php echo base_url('home/setting/P/');?>">12V DC Relays</a></li>
		  <li><a href="<?php echo base_url('home/setting/V/');?>">Valve</a></li>
		  <li><a href="<?php echo base_url('home/setting/PS/');?>">Pump</a></li>
		  <li><a href="<?php echo base_url('home/setting/T/');?>">Temperature Sensors</a></li>
		</ol>
	</div>
</div>	

<p>
		<a class="fancybox" id="checkLink" href="#inline1" style="display:none;">&nbsp;</a>
		<div id="inline1" style="width:250px;height:40px; display:none;"><div class="loading-progress"></div></div>
</p>
		
<!-- START : 24V AC RELAY -->
<?php if($sDevice == 'L') 
	  { ?>
	<?php //if($sAccess == '1' || $sAccess == '2') 
		  { ?>
			<div class="row">
				<div class="col-sm-4">
					<!-- widget Tags-->
					<div class="widget-container widget-tags styled boxed">
						<div class="inner" style="padding-left:15px; padding-right:15px;">
							<h3 class="widget-title">Light ON/OFF</h3>
							<!--<div class="loading-progress"></div>-->
							<div class="tagcloud clearfix">
							<?php
								for ($i=0;$i < 5; $i++)
								{
									$iRelayVal = $sRelays[$i];
									
									if($iRelayVal != '' && $iRelayVal !='.') 
									{
										$strChecked	=	'';
										if($iRelayVal == '1')
											$strChecked	=	'class="checked"';
										
										$sRelayNameDb =  $this->home_model->getDeviceName($i,$sDevice);
										$strRelayName = 'Light '.$i;
										if($sRelayNameDb != '')
											$strRelayName .= ' ('.$sRelayNameDb.')';
										
										$strLight	=	'light_off.png';
										if($i%2 == 0)
											$strLight	=	'light_on.png';
										
							?>
							
							<div class="rowCheckbox switch">
							<img src="<?php echo HTTP_IMAGES_PATH.'icons/'.$strLight;?>" style="width:64px;">
								<div class="custom-checkbox" style="float:right; margin-right:10px; margin-top:20px;"><input type="checkbox" value="<?php echo $i;?>" id="relay-<?php echo $i?>" name="relay-<?php echo $i?>" class="relayButton" hidefocus="true" style="outline: medium none;">
									<label <?php echo $strChecked;?>  id="lableRelay-<?php echo $i?>" for="relay-<?php echo $i?>"><span style="color:#C9376E;"><?php echo $strRelayName;?></span></label>
								</div>
							</div>
							<div style="height:30px;">&nbsp;</div>
							<?php 	}		
								 }
							?> 
							</div>
						</div>
					</div>
					<!--/ widget Tags-->
				</div>
				  
				<div class="col-sm-8">
						<!-- Statistics -->
						<div class="widget-container widget-stats boxed green-line">
							<div class="widget-title">
								<a href="<?php echo base_url('analog/showLight');?>" class="link-refresh" id="link-refresh-1"><span class="glyphicon glyphicon-refresh"></span></a>
								<h3>Light Settings</h3>
							</div>
							<div class="stats-content clearfix">
								<div class="stats-content-right" style="width:100% !important; margin-left:5px; margin-right:5px; float:none;">
							
							  <table class="table table-hover">
								<thead>
								  <tr>
									<th class="header" style="width:25%">Light</th>
									<th class="header"  style="width:25%">Type</th>
									<th class="header"  style="width:50%">Action</th>
								  </tr>
								</thead>
								<tbody>
								<?php			
								for ($i=0;$i < 5; $i++)
								{
									$iRelayVal = $sRelays[$i];
									if($iRelayVal != '' && $iRelayVal !='.') 
									{
										
										$iRelayNewValSb = 1;
										if($iRelayVal == 1)
										{
										  $iRelayNewValSb = 0;
										}
										$sRelayVal = false;
										if($iRelayVal)
										  $sRelayVal = true;
										//$sRelayNameDb = get_device_name(1, $i);

										$sRelayNameDb =  $this->home_model->getDeviceName($i,$sDevice);
										if($sRelayNameDb == '')
										  $sRelayNameDb = 'Add Name';
										
										$sDeviceTime =  $this->home_model->getDeviceTime($i,$sDevice);
										if($sDeviceTime == '')
										  $sDeviceTime = 'Add Time';
										else
										  $sDeviceTime .= ' Minute';
									  
										$iRelayProgramCount = $this->home_model->getProgramCount($i,$sDevice);
										$iPower	 = $this->home_model->getDevicePower($i,$sDevice);
										$sMainType =	$this->home_model->getDeviceMainType($i,$sDevice);
									?>
										<tr>
										<td>Light <?php echo $i;?><br />(<a href="<?php if($sAccess == '2') { echo site_url('home/deviceName/'.base64_encode($i).'/'.base64_encode($sDevice).'/'); } else { echo 'javascript:void(0);';} ?>"><?php echo $sRelayNameDb;?></a>)</td>
										<td>
											<div class="rowRadio"><div class="custom-radio"><input class="relayRadio" type="radio" id="radio_other_<?php echo $i;?>" value="0" name="<?php echo $i;?>_MainType" <?php if($sMainType == '0' || $sMainType == ''){ echo 'checked="checked"';}?> <?php if($sAccess == '1') { echo 'disabled="disabled"';}?> hidefocus="true" style="outline: medium none;"><label id="relay_other_<?php echo $i;?>" for="radio_other_<?php echo $i;?>" class="<?php if($sMainType == '0' || $sMainType == ''){ echo 'checked';}?>">Other</label></div></div>
											<div class="rowRadio"><div class="custom-radio"><input class="relayRadio" type="radio" id="radio_spa_<?php echo $i;?>" name="<?php echo $i;?>_MainType" value="1" <?php if($sMainType == '1'){ echo 'checked="checked"';}?> <?php if($sAccess == '1') { echo 'disabled="disabled"';}?> hidefocus="true" style="outline: medium none;"><label id="relay_spa_<?php echo $i;?>" for="radio_spa_<?php echo $i;?>" class="<?php if($sMainType == '1'){ echo 'checked';}?>">Spa</label></div></div>
											<div class="rowRadio"><div class="custom-radio"><input class="relayRadio" type="radio" id="radio_pool_<?php echo $i;?>" name="<?php echo $i;?>_MainType" value="2" <?php if($sMainType == '2'){ echo 'checked="checked"';}?> <?php if($sAccess == '1') { echo 'disabled="disabled"';}?> hidefocus="true" style="outline: medium none;"><label id="relay_pool_<?php echo $i;?>" for="radio_pool_<?php echo $i;?>" class="<?php if($sMainType == '2'){ echo 'checked';}?>">Pool</label></div></div>
										</td>
										<td>
										<div>
										<input type="radio" class="lightRadio" name="lightRelay_<?php echo $i;?>" id="lightRelay24" value="24">&nbsp;24V AC Relay&nbsp;&nbsp;<input type="radio" class="lightRadio" name="lightRelay_<?php echo $i;?>" id="lightRelay12" value="12">&nbsp;12V DC Relay
										</div>
										<div id="24VRelay_<?php echo $i;?>" style="display:none; padding-top:10px;">
										<select name="select24VRelays" class="form-control" style="width:80%">
											<option value="0">Relay0</option>
											<option value="1">Relay1</option>
											<option value="2">Relay2</option>
											<option value="3">Relay3</option>
										</select>
										</div>
										<div id="12VRelay_<?php echo $i;?>" style="display:none;padding-top:10px;">
										<select name="select12VRelays" class="form-control" style="width:80%">
											<option value="0">PowerCenter0</option>
											<option value="1">PowerCenter1</option>
											<option value="2">PowerCenter2</option>
											<option value="3">PowerCenter3</option>
										</select>
										</div>
										</td>
										</tr>
								<?php  } ?>
								<?php  } ?>	
								</tbody>
								</table>
								</div>
							</div>
						</div>
						<!--/ Statistics -->
					</div>
			</div><!-- /.row -->
	<?php } ?>
<?php } //Relay Device End ?>	
<!-- END : 24V AC RELAY -->