<?php
    /**
    * @Programmer: Dhiraj S.
    * @Created: 06 Mar 2017
    * @Modified: 
    * @Description: Change Password for Admin.
    **/
?>
    <div id="page-wrapper">

        <div class="row">
			<div class="col-lg-12">
				<ol class="breadcrumb">
						  <li><img src="<?php echo HTTP_IMAGES_PATH.'icons/home.png';?>" width="24" style="vertical-align: middle !important;">&nbsp;<a href="<?php echo site_url();?>">Home</a> </li>
						  <li class="active">Change Password</li>
				</ol>
			  <div class="alert alert-success alert-dismissable" style="display: none;">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                Password changed successfully! 
              </div>
            
			</div>
		</div>
        <!-- /.row -->
        <div class="row">
          <div class="col-lg-12">
            <div class="panel panel-primary">
              <div class="panel-heading" style="border-top-left-radius: 0px;border-top-right-radius: 0px;">
                <h3 class="panel-title" style="color:#FFF;">Change Password</h3>
              </div>
              <div class="panel-body">
                <div id="morris-chart-area">
                    <form action="<?php echo site_url('dashboard/ChangePassword/');?>" method="post" name="changePassword" id="changePassword">
                    <table border="0" cellspacing="0" cellpadding="0" width="100%">
                      <tr>
                        <td width="10%"><strong>Old Password:</strong></td>
                        <td width="1%">&nbsp;</td>
                        <td width="89%"><input type="password" class="form-control" placeholder="Enter Old Password" name="oldPassword" value="" autocomplete="off" id="oldPassword" maxlength="20">&nbsp;<span id="oldPasswordError" style="display: none;color: #FF0000;"></span></td>
                      </tr>
                      <tr><td colspan="3">&nbsp;</td></tr>
                       <tr>
                        <td width="10%"><strong>New Password:</strong></td>
                        <td width="1%">&nbsp;</td>
                        <td width="89%"><input type="password" class="form-control" placeholder="Enter New Password" name="newPassword" autocomplete="off" value="" id="newPassword" maxlength="20">&nbsp;<span id="newPasswordError" style="display: none;color: #FF0000;"></span></td>
                      </tr>
                      <tr><td colspan="3">&nbsp;</td></tr>
                      <tr>
                        <td width="10%"><strong>Confirm Password:</strong></td>
                        <td width="1%">&nbsp;</td>
                        <td width="89%"><input type="password" class="form-control" placeholder="Enter Confirm Password" name="confirmPassword" autocomplete="off" value="" id="confirmPassword" maxlength="20">&nbsp;<span id="confirmPasswordError" style="display: none;color: #FF0000;"></span></td>
                      </tr>
                      <tr><td colspan="3">&nbsp;</td></tr>
                      <tr><td colspan="3">
					  <a class="btn btn-green" href="javascript:void(0)" onclick="return ValidateForm();"><span>Save</span></a>
					  &nbsp;&nbsp;
					  <a class="btn btn-gray" href="<?php echo site_url('home');?>"><span>Back</span></a>&nbsp;<img src="<?php echo HTTP_IMAGES_PATH.'loading.gif';?>" width="32" id="Loading" style="display: none;"></td></tr>
                      
                    </table>
                  </form>
                </div>
              </div>
            </div>
          </div>
        </div><!-- /.row -->
      </div><!-- /#page-wrapper -->

<script type="text/javascript">
    jQuery(document).ready(function($) {
    });
	function ValidateForm()
	{
		var oldPassword 	= $("#oldPassword").val();
		var newPassword 	= $("#newPassword").val();
		var confirmPassword = $("#confirmPassword").val();
		var ChkError		= 0;
		
		if(oldPassword == "")
		{
			$("#oldPassword").css('border','1px solid #FF0000');
			$("#oldPasswordError").html("Please enter Old Password!").show();
			ChkError	= 1;
		}
		else
		{
			$("#oldPassword").css('border','');
			$("#oldPasswordError").html("").hide();
		}
		
		if(newPassword == "")
		{
			$("#newPassword").css('border','1px solid #FF0000');
			$("#newPasswordError").html("Please enter New Password!").show();
			ChkError	= 1;
		}
		else
		{
			$("#newPassword").css('border','');
			$("#newPasswordError").html("").hide();
		}
		
		if(confirmPassword == "")
		{
			$("#confirmPassword").css('border','1px solid #FF0000');
			$("#confirmPasswordError").html("Please enter Confirm Password!").show();
			ChkError	= 1;
		}
		else
		{
			if(confirmPassword != newPassword)
			{
				$("#confirmPassword").css('border','1px solid #FF0000');
				$("#confirmPasswordError").html("Please enter Same Password as New Password!").show();
				ChkError = 1;
			}
			else
			{
				$("#confirmPassword").css('border','');
				$("#confirmPasswordError").html("").hide();
			}
			
		}
		
		if(ChkError	== 1)
		{
			return false;
		}
		else
		{
			$("#Loading").show();
			//START : First Check if Old Password is correct or not.
			var checkPasswordUrl = '<?php echo base_url();?>dashboard/checkPassword';
			$.ajax({
			  type: "POST",
			  url: checkPasswordUrl,
			  data: {oldPassword:oldPassword},
			}).done(function( response ) {
				if(response == '0')
				{
					$("#oldPassword").css('border','1px solid #FF0000');
					$("#oldPasswordError").html("Please enter correct Old Password!").show();
					$("#Loading").hide(); 	
				}
				else
				{
					var changePasswordUrl = '<?php echo base_url();?>dashboard/ChangePassword';
					$.ajax({
					  type: "POST",
					  url: changePasswordUrl,
					  data: {newPassword:newPassword,confirmPassword:confirmPassword},
					}).done(function( response ) {
						$("#oldPassword").val('');
						$("#newPassword").val('');
						$("#confirmPassword").val('');
						$(".alert-success").show();
						$("#Loading").hide();
					});
				}
			  	
			});
		}
		
	}
</script>
