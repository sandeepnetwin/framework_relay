<!--START : VALVES Devices-->
<link href="<?php echo site_url('assets/switchy/switchy.css'); ?>" rel="stylesheet" />
<script type="text/javascript" src="<?php echo site_url('assets/switchy/switchy.js'); ?>"></script>
<script type="text/javascript" src="<?php echo site_url('assets/switchy/jquery.event.drag.js'); ?>"></script>
<script type="text/javascript" src="<?php echo site_url('assets/switchy/jquery.animate-color.js'); ?>"></script>

<script>
    var iActiveMode = '<?php echo $iActiveMode;?>';
    var sAccess 	= '<?php echo $sAccess;?>';
    var cntOnPrograms 	= '<?php echo $cntOnPrograms;?>';
</script>
<?php
				
	foreach($aIPDetails as $aIP)
	{
		if($aIP->id <= 1)
			$iPumpCount = $extra['PumpsNumber'];
		else if($aIP->id > 1)
			$iPumpCount = $extra['PumpsNumber2'];
	
?>	
	<div class="tabs-framed tabs-small boxed green-line" id="PumpTabs_<?php echo $aIP->id;?>" style="display:<?php if($aIP->id != $iFirstIPId){ echo 'none';} ?>">
		<ul class="tabs clearfix">
			<li class="valveTabs" id="allValve_<?php echo $aIP->id;?>"><a href="#All_<?php echo $aIP->id;?>" data-toggle="tab">All Boards</a></li>
			<?php for($i=1;$i<=$iPumpCount;$i++){?>
				<li class="valveTabs"><a href="#PUMP<?php echo $i.'_'.$aIP->id;?>" data-toggle="tab">Pump<?php echo $i;?></a></li>
			<?php } ?>
		</ul>
		<div class="tab-content" id="tabsContents_<?php echo $aIP->id;?>">
			<div class="tab-pane fade in" id="All_<?php echo $aIP->id;?>">
			</div>
			<?php for($i=1;$i<=$iPumpCount;$i++){?>
			<div class="tab-pane fade in" id="PUMP<?php echo $i.'_'.$aIP->id;?>">
			<?php
					echo showPumpValve(${"PumpValve".$i.'_'.$aIP->id},$i);
					
				?>
			</div>
			<?php } ?>
		</div>
	</div>
	
	<div id="pumpSettingForm_<?php echo $aIP->id;?>" style="width:250px;height:auto; display:none;">
		<table border="0" cellspacing="0" cellpadding="0" width="100%">
		<input type="hidden" id="valve_number_<?php echo $aIP->id;?>" value="">
			<tr>
				<td colspan="3"><span style="font-weight:bold;">Pump Association :</span></td>
			</tr>
			<tr>
				<td colspan="3">&nbsp;</td>
			</tr>
			<tr>
				<td colspan="3"><span style="color:#FF0000;">* indicates required field</span></td>
			</tr>
			 <tr><td colspan="3">&nbsp;</td></tr>
			  <tr>
				<td width="24%"><strong>Select Pump: <span class="mandetory">*</span></strong></td>
				<td width="1%">&nbsp;</td>
				<td width="75%">
					<select name="pump" id="pump_<?php echo $aIP->id;?>">
						<?php for($i=1;$i<=$iPumpCount;$i++){?>
						<option value="<?php echo $i;?>">Pump <?php echo $i;?></option>
						<?php } ?>
					</select>	
				</td>
			  </tr>
			  <tr><td colspan="3">&nbsp;</td></tr>
			  <tr>
				<td width="10%"><strong>Valve Type:</strong></td>
				<td width="1%">&nbsp;</td>
				<td width="89%"><input type="radio" name="sValveType_<?php echo $aIP->id;?>" id="sValveType0" value="0" checked="checked">&nbsp;Suction&nbsp;&nbsp;&nbsp;&nbsp;<input type="radio" name="sValveType_<?php echo $aIP->id;?>" id="sValveType1" value="1">&nbsp;Pressure</td>
			  </tr>
			  <tr><td colspan="3">&nbsp;</td></tr>
			  <tr><td colspan="3"><span class="btn btn-green"><input type="button" name="command" value="Save" class="btn btn-success" onclick="return checkForm('<?php echo $aIP->id;?>');"></span>&nbsp;&nbsp;<span class="btn"><input type="button" name="back" value="Back" class="btn btn-success" onclick="javascript:parent.$a.fancybox.close();"></span>&nbsp;&nbsp;
			  <span id="loadingImg_<?php echo $aIP->id;?>" style="display:none;"><img src="<?php echo site_url('assets/images/loading.gif');?>" alt="Loading...." width="32" height="32"></span></td></tr>
			  
			</table>
	</div>
	
<?php } ?>
<script>
$(".valveTabs").click(function(){
	$("[id^='onoffbuttons_']").hide();
	$("[id^='relayConfigure_']").hide();
	$("[id^='graphbuttons_']").hide();
	$("[id^='tabsContents_']").show();
	$("#allValves").hide();
});

$("[id^='allValve_']").click(function(){
	$("#selPort").val('all');
	$("#allValves").show();
});


</script>
<style>

.valveGraph{
	visibility: hidden;
}

.td-custom{
	text-align: center !important;
	border-right: 1px solid #CCC;
}

.checkboxFour {
	width: 25px;
	height: 25px;
	background: #ddd;
	border-radius: 100%;
	position: relative;
	-webkit-box-shadow: 0px 1px 3px rgba(0,0,0,0.5);
	-moz-box-shadow: 0px 1px 3px rgba(0,0,0,0.5);
	box-shadow: 0px 1px 3px rgba(0,0,0,0.5);
	display: inline-block;
}

/**
 * Create the checkbox button
 */
.checkboxFour label {
	display: block;
	width: 15px;
	height: 15px;
	border-radius: 100px;

	-webkit-transition: all .5s ease;
	-moz-transition: all .5s ease;
	-o-transition: all .5s ease;
	-ms-transition: all .5s ease;
	transition: all .5s ease;
	cursor: pointer;
	position: absolute;
	top: 5px;
	left: 5px;
	z-index: 1;

	background: #FF0000;
	font-size: 10px;
    font-weight: bold;
	
	-webkit-box-shadow:inset 0px 1px 3px rgba(0,0,0,0.5);
	-moz-box-shadow:inset 0px 1px 3px rgba(0,0,0,0.5);
	box-shadow:inset 0px 1px 3px rgba(0,0,0,0.5);
}

/**
 * Create the checked state
 */
.checkboxFour input[type=checkbox]:checked + label {
	background: #26ca28;
}

@media screen and (max-width:590px)
	{
		.checkboxFour {
			width: 25px !important;
			height: 25px !important;
		}
		
		.checkboxFour label {
			width: 15px !important;
			height: 15px !important;
		}
	}
	
@media screen and (min-width : 591px) and (max-width:990px)
	{
		.checkboxFour {
			width: 50px !important;
			height: 50px !important;
		}
		
		.checkboxFour label {
			width: 40px !important;
			height: 40px !important;
			font-size: 28px !important;
		}
	}
	

</style>
<div>
<!--<a href="<?php //echo site_url('dashboard/position');?>" class="fancyboxiframe fancybox.iframe">Click</a>-->
</div>
<div class="row">
    <?php
			
			if(!empty($aIPDetails))
            {
                foreach($aIPDetails as $aIP)
                {
                    if($aIP->id <= 1)
                        $iValveNumber = $extra['ValveNumber'];
                    else if($aIP->id > 1)
                        $iValveNumber = $extra['ValveNumber2'];
					
	?>
	
    <div class="col-sm-12" id="graphbuttons_<?php echo $aIP->id;?>" style="display:<?php if($aIP->id != $iFirstIPId){ echo 'none';} ?>">
		<div class="widget-container widget-stats boxed green-line">
		<div class="widget-title">
                    <h3>Valve Graphical Representation</h3>
		</div>
		<div class="stats-content clearfix" style="background: #fff none repeat scroll 0 0; overflow-x:auto;">
			<table class="table">
				<thead>
					<tr>
						<th style="border-right: 1px solid #CCC;"><strong>Valve Number</strong></th>
						<th class="td-custom">0</th>
						<th class="td-custom">1</th>
						<th class="td-custom">2</th>
						<th class="td-custom">3</th>
						<th class="td-custom">4</th>
						<th class="td-custom">5</th>
						<th class="td-custom">6</th>
						<th class="td-custom">7</th>
					</tr>
				</thead>
				<tbody>
					<tr>
						<td style="border-right: 1px solid #CCC;"><strong>Output Relays</strong></td>
						<?php
							$k=0;
							for($i=0;$i<8;$i++) 
							{
								$arrRelays =	json_decode($this->home_model->getValveRelayNumber($i,'V',$aIP->id));
								
								$iValveExists = ${"sValves".$aIP->id}[$i];
								
						?>
						<td class="td-custom">
						<?php 	for($j=1;$j<=2;$j++) 
								{
									$strChecked = '';
									if(!empty($arrRelays))
										$strChecked = 'checked="checked"';	
									
									$strUrl = '';
									if($sAccess == '2') 
									{	
										$strUrl = base_url('home/valveRelays/'.base64_encode($i).'/'.base64_encode('V').'/'.base64_encode($aIP->id));
									} 
									else
									{ 
										$strUrl = 'javascript:void(0);';
									}
									
									if($iValveExists == '.')
									{
										$k++;
										$k++;
										echo '<strong style="color:#1C5E83">.<br><a href="'.$strUrl.'">(Add)</a></strong>';
										break;
									}
									else
									{		
						?>
							
							<div class="checkboxFour">
								<input type="checkbox" <?php echo $strChecked;?> class="valveGraph" value="1" id="checkboxFourInput<?php echo $i.'-'.$j.'-'.$aIP->id;?>" name="" />
								<label for="checkboxFourInput<?php echo $i.'-'.$j;?>" style="color:#FFF;"><?php echo $k;?></label>
							</div>
						<?php 
								$k++;
								if($j==1)
									echo '&nbsp;&nbsp;&nbsp;&nbsp;';
								
									}
								}	
								if($strChecked == '' && $iValveExists != '.')
									echo '<strong style="color:#1C5E83"><br><a href="'.$strUrl.'">(Assign Relay)</a></strong>';
						?>	
						</td>
						<?php 
							}
						?>	
					</tr>
					<tr><td colspan="9"><strong>Note:</strong></td></tr>
					<tr>
						<td colspan="3" style="border-top: medium none;">
							<div class="checkboxFour">
								<input type="checkbox" checked="checked" class="valveGraph" value="On" id="checkboxFourInputExmOn<?php echo $aIP->id;?>" name="" />
								<label for="checkboxFourInputExmOn<?php echo $aIP->id;?>"></label>
							</div> - Relays Assigned.
						</td>
						<td colspan="3" style="border-top: medium none;">
							<div class="checkboxFour">
								<input type="checkbox" class="valveGraph" value="Off" id="checkboxFourInputExmOff<?php echo $aIP->id;?>" name="" />
								<label for="checkboxFourInputExmOff<?php echo $aIP->id;?>"></label>
							</div> - Relays not Assigned.
						</td>
						<td colspan="3" style="border-top: medium none;">
							<strong>.</strong> - Output is Assigned to 24V AC.
						</td>
					</tr>
					<tr>
						<td colspan="3" style="border-top: medium none;">
							<strong>(Assign Relay)</strong> - Valve Exists, relay not assigned.
						</td>
						<td colspan="3" style="border-top: medium none;">
							<strong>(Add)</strong> - Assigns two 24v relays to function together as a valve.
						</td>
						<td colspan="3" style="border-top: medium none;">
							&nbsp;
						</td>
					</tr>
				</tbody>				
			</table>
		</div>	
		</div>
	</div>
	<div class="col-sm-4" id="onoffbuttons_<?php echo $aIP->id;?>" style="display:<?php if($aIP->id != $iFirstIPId){ echo 'none';} ?>">
		
		<div class="widget-container widget-stats boxed green-line">
		<div class="refreshLoading" id="refreshLoading_<?php echo $aIP->id;?>"><img src="<?php echo base_url("assets/images/loading.gif");?>" alt="loading">&nbsp;Refreshing Devices....</div>
		<div class="widget-title">
			
			<a href="javascript:void(0);" class="link-refresh" id="link-refresh-1" onclick="refreshDeviceStatus('V');"><span class="glyphicon glyphicon-refresh"></span></a>
			<h3>ON/OFF</h3>
		</div>
		<div class="stats-content clearfix">
			<div class="stats-content-right" style="width:96% !important; margin-left:5px; margin-right:5px; margin-top:10px; float:none;">
			<table class="table table-hover">
			<?php
				
				if( $iValveNumber == 0 || $iValveNumber == '' )
				{ ?>
					<tr>
						<td>
							<span style="color:red">Please add number of Vavles in the <a href="<?php echo base_url('home/setting/');?>">Settings</a> Page!</span>
						</td>
					</tr>
				<?php 
				}
				else
				{
					//START : Valve Device 
					$arrValve	=	array(0,1,2,3,4,5,6,7);
					$j=0;
					$remainigCount	=	0;
					$chkValve		=	0;
					
					if(!empty(${"ValveRelays".$aIP->id}))
					{
						foreach(${"ValveRelays".$aIP->id} as $valve)
						{
							$i = $valve->device_number;
							$j = $i *2;
							
							unset($arrValve[$i]);
							
							$iValvesVal = ${"sValves".$aIP->id}[$i];
							$iValvesNewValSb1 = 1;
							$iValvesNewValSb2 = 2 ;
							if($iValvesVal == 1)
							{
							  $iValvesNewValSb1 = 0;
							}
							if($iValvesVal == 2)
							{
							  $iValvesNewValSb2 = 1;
							}
							$sValvesVal1 = false;
							$sValvesVal2 = false;
							if($iValvesVal == 1)
							  $sValvesVal1 = true;
							if($iValvesVal == 2)
							  $sValvesVal2 = true;
							//$sValvesNameDb = get_device_name(3, $i);

							$sValvesNameDb =  $this->home_model->getDeviceName($i,$sDevice,$aIP->id);
							if($sValvesNameDb == '')
							  $sValvesNameDb = 'Valve '.$i;
							
							//START : Get Valve Position Details.
							$aPositionName   =  $this->home_model->getPositionName($i,$sDevice,$aIP->id);
							
							$strPosition1 = '';
							$strPosition2 = '';
							
							if($aPositionName[0] != '')
							$strPosition1	 =	$this->home_model->getPositionNameFromID($aPositionName[0]);
							if($aPositionName[1] != '')
							$strPosition2	 =	$this->home_model->getPositionNameFromID($aPositionName[1]);
							//END : Get Valve Position Details.
							
							$aRelayNumber    =  json_decode($this->home_model->getValveRelayNumber($i,$sDevice,$aIP->id));
							$sMainType	     =  $this->home_model->getDeviceMainType($i,$sDevice,$aIP->id);
							
							//Get Last Run Details.
							$lastRun = $this->home_model->getDeviceLastRun($i,$sDevice,$aIP->id);
							
							$strLastRunPosition = '';
							if($lastRun == '1')
							{
								$strLastRunPosition = $strPosition1;
							}
							else if($lastRun == '2')
							{
								$strLastRunPosition = $strPosition2;
							}
							
							//echo 'iValvesVal : '.$iValvesVal;
							
							if($iValvesVal == '.' || $iValvesVal == '')
								continue;
							
							if($iValvesVal != '' && $iValvesVal != '.' && !empty($aRelayNumber)) 
							{
						?>
							<!--<div class="row">-->
							<tr>
								<td colspan="3" style="border-top:none;">
									<div style="margin-top: 10px;margin-bottom: 10px;"><strong><span style="color:#C9376E;"><?php echo $sValvesNameDb; ?></span></strong></div>
									<?php if($lastRun != '') {?>
										<div><span style="font-weight:bold;">Device Last Run For Position <span style="color:#FE0000;" id="lastRun_<?php echo $i?>_<?php echo $aIP->id;?>"><?php echo $strLastRunPosition;?> !</span></span></div>
								<?php } ?>
								</td>
							</tr>
							<!--<div class="col-sm-12">-->
							
							<tr style="border-bottom: 1px solid #ccc;">
							<td width="33%" style="border-top:none;">
								<div class="span1 valve-<?php echo $i?>-<?php echo $aIP->id;?>" value="1" style="margin-top: 10px; color: #428BCA;font-weight: bold; cursor: pointer; float: left;"><?php echo $strPosition1; ?></div>
							</td>
							<td width="34%" style="border-top:none;">
								<div class="span2" style="margin-left:5px; margin-right:5px; float: left;" >
								<select id='switch-me-<?php echo $i;?>-<?php echo $aIP->id;?>'>
								<option value='1' <?php if($iValvesVal == '1') { echo 'selected="selected"';} ?>>Spa</option>
								<option value='0' <?php if($iValvesVal == '0' || $iValvesVal == '') { echo 'selected="selected"';} ?>></option>
								<option value='2' <?php if($iValvesVal == '2') { echo 'selected="selected"';} ?>>Pool</option>
								</select>
								<input type="hidden" name="hidIsManual_<?php echo $i;?>_<?php echo $aIP->id;?>" value="" id="hidIsManual_<?php echo $i;?>_<?php echo $aIP->id;?>">
									<div class="valve-<?php echo $i?>-<?php echo $aIP->id;?>" value="0" id="off-<?php echo $i;?>-<?php echo $aIP->id;?>" style="color: red;font-weight: bold;width: 0; margin-left: 30px; cursor: pointer; margin-top:5px;">
										OFF
									</div>
								</div>
							</td>
							<td width="33%" style="border-top:none;">
								<div class="span1 valve-<?php echo $i?>-<?php echo $aIP->id;?>" value="2" style="margin-top: 10px; color: #428BCA;font-weight: bold; cursor: pointer; float: right; text-align:right;"><?php echo $strPosition2; ?></div>
							</td>
							</tr>
							
							<script type="text/javascript">
							  $(function()
							  {
									var bgColor = '#E8E8E8';
									<?php if($iValvesVal == '1' || $iValvesVal == '2') { ?>
											bgColor = '#45A31F';
									<?php } else { ?>
											bgColor = '#E8E8E8';
									<?php } ?>
									
									$('#switch-me-<?php echo $i;?>-<?php echo $aIP->id;?>').switchy();
									
									$('.valve-<?php echo $i?>-<?php echo $aIP->id;?>').on('click', function(event){
										var iActiveMode = $("#hidActiveMode").val();
										if(iActiveMode != 3)
										{
											if(iActiveMode != 2)
											{
												$('#hidIsManual_<?php echo $i;?>_<?php echo $aIP->id;?>').val('1');
											}
											$('#switch-me-<?php echo $i;?>-<?php echo $aIP->id;?>').val($(this).attr('value')).change();
										}
										else
										{
											alert('You can perform this operation in Time-out Mode.');
										}
										
									});
									
									$('#switch-me-<?php echo $i;?>-<?php echo $aIP->id;?>').next('.switchy-container').find('.switchy-bar').animate({
											backgroundColor: bgColor
										});
									
									$('#switch-me-<?php echo $i;?>-<?php echo $aIP->id;?>').on('change', function(event)
									{
										var iActiveMode = $("#hidActiveMode").val();
										if(sAccess == 2)
										{
											var idDetails = $(this).attr('id');
											
											var aDetails  = idDetails.split("-");
											var hidIsManual = $('#hidIsManual_'+aDetails[2]+'_'+aDetails[3]).val();
											
											var chkConfirm = true;
											
											if(hidIsManual == '1')
											{
												if(iActiveMode != 2)
												{
													
													if(cntOnPrograms >= 1)
													{
														chkConfirm = confirm("Are you sure you want to make this device ON/OFF?\nThis will stop all Custom Programs/Programs running in background!");
													}
													
													if(chkConfirm)
													{
														$.ajax({
																type: "POST",
																url: "<?php echo site_url('analog/changeModeToManual');?>", 
																data: {iMode:'2'},
																success: function(data) {
																	$("#hidActiveMode").val('2');
																}
														   });
													}
													
												}
												$('#hidIsManual_'+aDetails[2]+'_'+aDetails[3]).val('');
											}
											
											if(chkConfirm)
											{	
												var bgColor = '#E8E8E8';
												if ($(this).val() == '1' || $(this).val() == '2')
												{
													bgColor = '#45A31F';
												} 
												$('#switch-me-<?php echo $i;?>-<?php echo $aIP->id;?>').next('.switchy-container').find('.switchy-bar').animate({
													backgroundColor: bgColor
												});
												
												
												if($(this).val() == '0')
												{
													$('#switch-me-<?php echo $i;?>-<?php echo $aIP->id;?>').next('.switchy-container').find('.switchy-slider').animate({
														'left': '20px'
													},"fast");
												}
												else if($(this).val() == '1')
												{
													$('#switch-me-<?php echo $i;?>-<?php echo $aIP->id;?>').next('.switchy-container').find('.switchy-slider').animate({
														'left': '0px'
													},"fast");
												}
												else if($(this).val() == '2')
												{
													$('#switch-me-<?php echo $i;?>-<?php echo $aIP->id;?>').next('.switchy-container').find('.switchy-slider').animate({
														'left': '40px'
													},"fast");
												}		
												
												$.ajax({
													type: "POST",
													url: "<?php echo site_url('home/updateStatusOnOff');?>", 
													data: {sName:'<?php echo $i;?>',sStatus:$(this).val(),sDevice:'<?php echo $sDevice;?>',sIdIP:'<?php echo $aIP->id;?>'},
													success: function(data) {
														//location.reload();
														//$("#hidActiveMode").val(iActiveMode);
													}
												});
											}
										}
									});
								});
						   </script>
						  <!--</div>-->
						<!--</div>-->
						<!--<div style="height:10px;">&nbsp;</div>-->
				<?php 	}
						/* else
						{
							echo '<div class="row"><div class="col-sm-12"><div class="tagcloud clearfix"><span style="color:#FF0000;">Relay Not Assigned</span><div style="float: right;margin-right: 10px;color:#C9376E"><strong>Valve '.$i.'</strong></div></div></div></div><div style="height:10px;">&nbsp;</div>';
						} */
						
							$chkValve++;
						}		
					}
					$remainigCount	=	$iValveNumber - $chkValve;
					//for ($i=0;$i < $valve_count; $i++)	
					//for ($i=0;$i < $remainigCount ; $i++)
					foreach($arrValve as $i)	
					{
						if($remainigCount == 0)	
							break;
						
						$remainigCount--;
						
						$j = $i * 2;
						
						$iValvesVal = ${"sValves".$aIP->id}[$i];
						$iValvesNewValSb1 = 1;
						$iValvesNewValSb2 = 2 ;
						if($iValvesVal == 1)
						{
						  $iValvesNewValSb1 = 0;
						}
						if($iValvesVal == 2)
						{
						  $iValvesNewValSb2 = 1;
						}
						$sValvesVal1 = false;
						$sValvesVal2 = false;
						if($iValvesVal == 1)
						  $sValvesVal1 = true;
						if($iValvesVal == 2)
						  $sValvesVal2 = true;
						//$sValvesNameDb = get_device_name(3, $i);

						$sValvesNameDb =  $this->home_model->getDeviceName($i,$sDevice,$aIP->id);
						
						if($sValvesNameDb == '')
							$sValvesNameDb = 'Valve '.$i;
						
						//START : Get Valve Position Details.
						$aPositionName   =  $this->home_model->getPositionName($i,$sDevice,$aIP->id);
						
						$strPosition1 = '';
						$strPosition2 = '';
						
						if($aPositionName[0] != '')
						$strPosition1	 =	$this->home_model->getPositionNameFromID($aPositionName[0]);
						if($aPositionName[1] != '')
						$strPosition2	 =	$this->home_model->getPositionNameFromID($aPositionName[1]);
						//END : Get Valve Position Details.
					
						
						$aRelayNumber    =  json_decode($this->home_model->getValveRelayNumber($i,$sDevice,$aIP->id));
						$iPower	 	     =  $this->home_model->getDevicePower($i,$sDevice);
						$sMainType	     =  $this->home_model->getDeviceMainType($i,$sDevice,$aIP->id);
						
						//Get Last Run Details.
						$lastRun = $this->home_model->getDeviceLastRun($i,$sDevice,$aIP->id);
						
						$strLastRunPosition = '';
						if($lastRun == '1')
						{
							$strLastRunPosition = $strPosition1;
						}
						else if($lastRun == '2')
						{
							$strLastRunPosition = $strPosition2;
						}
						
						//echo 'iValvesVal : '.$iValvesVal;
						
					if($iValvesVal != '' && $iValvesVal != '.' && !empty($aRelayNumber)) 
					{
					?>
						<tr>
							<td colspan="3" style="border-top:none;">
								<div style="float: right;margin-right: 10px;margin-top: 10px;"><strong><span style="color:#C9376E;"><?php echo $sValvesNameDb; ?></span></strong></div>
								<?php if($lastRun != '') {?>
									<div><span style="font-weight:bold;">Device Last Run For Position <span style="color:#FE0000;" id="lastRun_<?php echo $i?>_<?php echo $aIP->id;?>"><?php echo $strLastRunPosition;?> !</span></span></div>
								<?php } ?>
							</td>
						</tr>	
						<!--<div class="row">
						<div class="col-sm-12">-->
						
						<tr style="border-bottom: 1px solid #ccc;">
							<td width="33%" style="border-top:none;">
								<div class="span1 valve-<?php echo $i?>-<?php echo $aIP->id;?>" value="1" style="margin-top: 10px; width: auto; color: #428BCA;font-weight: bold; cursor: pointer; float: left;"><?php  echo $strPosition1; ?></div>
							</td>
									
						
							<td width="34%" style="border-top:none;">
								<div class="span2" style="margin-left:5px; margin-right:5px; float: left;" >
									<select id='switch-me-<?php echo $i;?>-<?php echo $aIP->id;?>'>
									<option value='1' <?php if($iValvesVal == '1') { echo 'selected="selected"';} ?>>Spa</option>
									<option value='0' <?php if($iValvesVal == '0' || $iValvesVal == '') { echo 'selected="selected"';} ?>></option>
									<option value='2' <?php if($iValvesVal == '2') { echo 'selected="selected"';} ?>>Pool</option>
									</select>
									<input type="hidden" name="hidIsManual_<?php echo $i;?>_<?php echo $aIP->id;?>" value="" id="hidIsManual_<?php echo $i;?>_<?php echo $aIP->id;?>">
									<div class="valve-<?php echo $i?>-<?php echo $aIP->id;?>" value="0" id="off-<?php echo $i;?>-<?php echo $aIP->id;?>" style="color: red;font-weight: bold;width: 0; margin-left: 30px; cursor: pointer;">
										OFF
									</div>
								</div>
							</td>
							
							<td width="33%" style="border-top:none;">
								<div class="span1 valve-<?php echo $i?>-<?php echo $aIP->id;?>" value="2" style="margin-top: 10px; width: auto; color: #428BCA;font-weight: bold; cursor: pointer; float: left;"><?php  echo $strPosition2; ?></div>
							</td>
						</tr>	
						
						<script type="text/javascript">
						  $(function()
						  {
								var bgColor = '#E8E8E8';
								<?php if($iValvesVal == '1' || $iValvesVal == '2') { ?>
										bgColor = '#45A31F';
								<?php } else { ?>
										bgColor = '#E8E8E8';
								<?php } ?>
								
								$('#switch-me-<?php echo $i;?>-<?php echo $aIP->id;?>').switchy();
								
								$('.valve-<?php echo $i?>-<?php echo $aIP->id;?>').on('click', function(event){
									var iActiveMode = $("#hidActiveMode").val();
									if(iActiveMode != 3)
									{
										if(iActiveMode != 2)
										{
											$('#hidIsManual_<?php echo $i;?>_<?php echo $aIP->id;?>').val('1');
										}
										$('#switch-me-<?php echo $i;?>-<?php echo $aIP->id;?>').val($(this).attr('value')).change();
									}
									else
									{
										alert('You can perform this operation in Time-out Mode.');
									}
									
								});
								
								$('#switch-me-<?php echo $i;?>-<?php echo $aIP->id;?>').next('.switchy-container').find('.switchy-bar').animate({
										backgroundColor: bgColor
									});
								
								$('#switch-me-<?php echo $i;?>-<?php echo $aIP->id;?>').on('change', function(event)
								{
									var iActiveMode = $("#hidActiveMode").val();
									
									if(sAccess == 2)
									{
										var idDetails = $(this).attr('id');
											
										var aDetails  = idDetails.split("-");
										var hidIsManual = $('#hidIsManual_'+aDetails[2]+'_'+aDetails[3]).val();
										
										var chkConfirm = true;
										
										if(hidIsManual == '1')
										{
											if(iActiveMode != 2)
											{
												if(cntOnPrograms >= 1)
												{
													chkConfirm = confirm("Are you sure you want to make this device ON/OFF?\nThis will stop all Custom Programs/Programs running in background!");
												}
												if(chkConfirm)
												{
													$.ajax({
														type: "POST",
														url: "<?php echo site_url('analog/changeModeToManual');?>", 
														data: {iMode:'2'},
														success: function(data) {
															$("#hidActiveMode").val('2');
														}
												   });
												}
											}
											$('#hidIsManual_'+aDetails[2]+'_'+aDetails[3]).val('');
											
										}
										
										if(chkConfirm)
										{
											var bgColor = '#E8E8E8';

											if ($(this).val() == '1' || $(this).val() == '2')
											{
												bgColor = '#45A31F';
											} 
											$('#switch-me-<?php echo $i;?>-<?php echo $aIP->id;?>').next('.switchy-container').find('.switchy-bar').animate({
												backgroundColor: bgColor
											});
											
											if($(this).val() == '0')
											{
												$('#switch-me-<?php echo $i;?>-<?php echo $aIP->id;?>').next('.switchy-container').find('.switchy-slider').animate({
													'left': '20px'
												},"fast");
											}
											else if($(this).val() == '1')
											{
												$('#switch-me-<?php echo $i;?>-<?php echo $aIP->id;?>').next('.switchy-container').find('.switchy-slider').animate({
													'left': '0px'
												},"fast");
											}
											else if($(this).val() == '2')
											{
												$('#switch-me-<?php echo $i;?>-<?php echo $aIP->id;?>').next('.switchy-container').find('.switchy-slider').animate({
													'left': '40px'
												},"fast");
											}
																			
											$.ajax({
												type: "POST",
												url: "<?php echo site_url('home/updateStatusOnOff');?>", 
												data: {sName:'<?php echo $i;?>',sStatus:$(this).val(),sDevice:'<?php echo $sDevice;?>',sIdIP:'<?php echo $aIP->id;?>'},
												success: function(data) {
													//location.reload();
													//$("#hidActiveMode").val(iActiveMode);
												}
											});
										}
									}
								});
							});
						</script> 
					<!--</div>
					</div>
					<div style="height:10px;">&nbsp;</div>-->
				<?php }	
						/* else
						{
							echo '<div class="row"><div class="col-sm-12"><div class="tagcloud clearfix"><span style="color:#FF0000;">Relay Not Assigned.</span><div style="float: right;margin-right: 10px; color:#C9376E"><strong>Valve '.$i.'</strong></div></div></div></div><div style="height:10px;">&nbsp;</div>';
						} */
					}
				}
				?>
				</table>
			</div>
		</div>
		</div>
	</div>
	<div class="col-sm-8" id="relayConfigure_<?php echo $aIP->id;?>" style="display:<?php if($aIP->id != $iFirstIPId){ echo 'none';} ?>">
	<div class="widget-container widget-stats boxed green-line">
		<div class="widget-title">
			<a href="<?php echo base_url('home/setting/'.$sDevice.'/');?>" class="link-refresh" id="link-refresh-1"><span class="glyphicon glyphicon-refresh"></span></a>
			<h3>Valve Settings</h3>
			<h5><a href="<?php echo site_url('dashboard/positionIframe/');?>" class="fancyboxmanage fancybox.iframe" style="color: #26c928;font-size: 14px;font-style: normal; float:left;">(Manage Position)</a></h5>
		</div>
	<?php
		if( $iValveNumber == 0 || $iValveNumber == '' )
		{ ?>
			<div class="stats-content clearfix">
			<div class="stats-content-right" style="width:100% !important; margin-left:5px; margin-right:5px; float:none;">
					<span style="color:red">Please add number of Vavles in the <a href="<?php echo base_url('home/setting/');?>">Settings</a> Page!</span>
			</div>
			</div>
			
		<?php 
		}
		else
		{
		?>
				
					<div class="stats-content clearfix">
					<div class="stats-content-right" style="width:100% !important; margin-left:5px; margin-right:5px; float:none;">
				
				  <table class="table table-hover">
					<thead>
					  <tr>
						<th class="header" style="width:25%">Valve</th>
						<th class="header"  style="width:25%">Type</th>
						<th class="header"  style="width:50%">Action</th>
					  </tr>
					</thead>
					<tbody>
					<?php			
					$arrValve	=	array(0,1,2,3,4,5,6,7);
					$j=0;
					$remainigCount	=	0;
					$chkValve		=	0;
					
					if(!empty(${"ValveRelays".$aIP->id}))
					{
						foreach(${"ValveRelays".$aIP->id} as $valve)
						{
							$i = $valve->device_number;
							$j = $i *2;
							
							unset($arrValve[$i]);
							
							$iValvesVal = ${"sValves".$aIP->id}[$i];
							$iValvesNewValSb1 = 1;
							$iValvesNewValSb2 = 2 ;
							if($iValvesVal == 1)
							{
							  $iValvesNewValSb1 = 0;
							}
							if($iValvesVal == 2)
							{
							  $iValvesNewValSb2 = 1;
							}
							$sValvesVal1 = false;
							$sValvesVal2 = false;
							if($iValvesVal == 1)
							  $sValvesVal1 = true;
							if($iValvesVal == 2)
							  $sValvesVal2 = true;
							//$sValvesNameDb = get_device_name(3, $i);

							$sValvesNameDb =  $this->home_model->getDeviceName($i,$sDevice,$aIP->id);
							if($sValvesNameDb == '')
							  $sValvesNameDb = 'Add Name';
						  
							$aPositionName   =  $this->home_model->getPositionName($i,$sDevice,$aIP->id);
							$aRelayNumber    =  json_decode($this->home_model->getValveRelayNumber($i,$sDevice,$aIP->id));
							$sMainType	     =  $this->home_model->getDeviceMainType($i,$sDevice,$aIP->id);
							
							if(!empty($aRelayNumber)){
							
						?>
							<tr class="">
								<td colspan="3">
								<?php if(in_array($i.'_'.$aIP->id, $excludeDevices['V'])) { ?>
									<div class="col-sm-12">
									<div style="top: 0px;margin-bottom: 10px;position: relative;right:-18px;" class="ribbon ribbon-green"><span style="line-height:0px; font-size:14px;"><?php echo EXCLUDE_DEVICE;?></span></div>
									</div>
								<?php } ?>
								<strong>Name:</strong> (<a href="<?php if($sAccess == 2) { echo site_url('home/deviceName/'.base64_encode($i).'/'.base64_encode($sDevice).'/'.base64_encode($aIP->id)); } else { echo 'javascript:void(0);';}?>" ><?php echo $sValvesNameDb;?></a>)
									
								</td>
							</tr>
							<tr class="">
							<td style="border-top:none;">Valve <?php echo $i;?></td>
							<td style="border-top:none;">
								<div class="rowRadio">
									<div class="custom-radio">
										
										<input class="valveRadio" type="radio" id="radio-other-<?php echo $i;?>-<?php echo $aIP->id;?>" value="0" name="<?php echo $i;?>_MainType" <?php if($sMainType == '0' || $sMainType == ''){ echo 'checked="checked"';}?> <?php if($sAccess == '1') { echo 'disabled="disabled"';}?> hidefocus="true" style="outline: medium none;">
										<label id="relay_other_<?php echo $i;?>_<?php echo $aIP->id;?>" for="radio-other-<?php echo $i;?>-<?php echo $aIP->id;?>" class="<?php if($sMainType == '0' || $sMainType == ''){ echo 'checked';}?>">Other</label>
								
										<input class="valveRadio" type="radio" id="radio-spa-<?php echo $i;?>-<?php echo $aIP->id;?>" name="<?php echo $i;?>_MainType" value="1" <?php if($sMainType == '1'){ echo 'checked="checked"';}?> <?php if($sAccess == '1') { echo 'disabled="disabled"';}?> hidefocus="true" style="outline: medium none;">
										<label id="relay_spa_<?php echo $i;?>_<?php echo $aIP->id;?>" for="radio-spa-<?php echo $i;?>-<?php echo $aIP->id;?>" class="<?php if($sMainType == '1'){ echo 'checked';}?>">Spa</label>
								
										<input class="valveRadio" type="radio" id="radio-pool-<?php echo $i;?>-<?php echo $aIP->id;?>" name="<?php echo $i;?>_MainType" value="2" <?php if($sMainType == '2'){ echo 'checked="checked"';}?> <?php if($sAccess == '1') { echo 'disabled="disabled"';}?> hidefocus="true" style="outline: medium none;">
										
										<label id="relay_pool_<?php echo $i;?>_<?php echo $aIP->id;?>" for="radio-pool-<?php echo $i;?>-<?php echo $aIP->id;?>" class="<?php if($sMainType == '2'){ echo 'checked';}?>">Pool</label>
									</div>
								</div>
							</td>
							<td style="border-top:none;">

							<a class="btn btn-green btn-small" style="width:120px" href="<?php if($sAccess == '2') { echo base_url('home/valveRelays/'.base64_encode($i).'/'.base64_encode($sDevice).'/'.base64_encode($aIP->id));} else { echo 'javascript:void(0);';}?>"><?php if(!empty($aRelayNumber)) { ?><span>Edit Relays</span><?php } else { ?><span>Assign Relays</span><?php } ?></a>
							
							<?php if(!empty($aRelayNumber)) { ?>
							<!--<a class="btn btn-small" style="width:120px" href="javascript:void(0);" <?php if($sAccess == '2') { echo 'onclick="return RemoveValveRelays(\''.$i.'\',\''.$aIP->id.'\')"';} ?>><span>Remove Relays</span></a>-->
							<?php } ?>
							
							<!--Remove Valve Button-->
							<a class="btn btn-small" style="width:120px" href="javascript:void(0);" <?php if($sAccess == '2') { echo ' onclick="removeValve(\''.$i.'\',\''.$aIP->id.'\');"';}?> ><span>Remove Valve</span></a>
							<!--Remove Valve Button-->
							
							<!--Pump Setting Button-->
							<a class="btn btn-small <?php if($sAccess == '2') { echo 'fancyboxPump';}?>" id="<?php echo $i.'_'.$aIP->id;?>" onclick="setID('<?php echo $i.'_'.$aIP->id;?>')" style="width:120px" href="#pumpSettingForm_<?php echo $aIP->id;?>"><span>Pump Setting</span></a>
							<!--Pump Setting Button-->
							<?php
								//Get Device Program Count
								$iRelayProgramCount = $this->home_model->getProgramCount($i,$sDevice,$aIP->id);
							?>
							<!--Pump Program Button-->
							<a class="btn btn-small btn-green" onclick="setID('<?php echo $i.'_'.$aIP->id;?>')" style="width:120px" href="<?php if($sAccess == '2') { echo site_url('valve/Programs/'.base64_encode($i).'/'.base64_encode('ip='.$aIP->id));} else { echo 'javascript:void(0);';}?>"><span>Programs (<?php echo $iRelayProgramCount;?>)</span></a>
							<!--Pump Program Button-->
							
							<!--Default Position Pool Auto Mode -->
							<a class="btn btn-small btn-green" style="width:120px" href="<?php if($sAccess == '2') { echo site_url('valve/defaultPosition/'.base64_encode($i).'/'.base64_encode($aIP->id));} else { echo 'javascript:void(0);';}?>"><span>Default Position</span></a>
							<!--Default Position Pool Auto Mode -->

							</td>
							</tr>
							
					<?php
							}
							$chkValve++;
						} ?>
					<?php  } ?>	
				
				<?php
					$remainigCount	=	$iValveNumber - $chkValve;
					//for ($i=0;$i < $valve_count; $i++)	
					//for ($i=0;$i < $remainigCount ; $i++)
					foreach($arrValve as $i)	
					{
						if($remainigCount == 0)	
							break;
						
						$remainigCount--;
						
						$j = $i * 2;
						
						$iValvesVal = ${"sValves".$aIP->id}[$i];
						$iValvesNewValSb1 = 1;
						$iValvesNewValSb2 = 2 ;
						if($iValvesVal == 1)
						{
						  $iValvesNewValSb1 = 0;
						}
						if($iValvesVal == 2)
						{
						  $iValvesNewValSb2 = 1;
						}
						$sValvesVal1 = false;
						$sValvesVal2 = false;
						if($iValvesVal == 1)
						  $sValvesVal1 = true;
						if($iValvesVal == 2)
						  $sValvesVal2 = true;
						//$sValvesNameDb = get_device_name(3, $i);

						$sValvesNameDb =  $this->home_model->getDeviceName($i,$sDevice,$aIP->id);
						if($sValvesNameDb == '')
						  $sValvesNameDb = 'Add Name';
					  
						$aPositionName   =  $this->home_model->getPositionName($i,$sDevice,$aIP->id);
						$aRelayNumber    =  json_decode($this->home_model->getValveRelayNumber($i,$sDevice,$aIP->id));
						$iPower	 	     =  $this->home_model->getDevicePower($i,$sDevice);
						$sMainType	     =  $this->home_model->getDeviceMainType($i,$sDevice,$aIP->id);
						if(!empty($aRelayNumber)){
				?>
						<tr class="">
							<td>Valve <?php echo $i;?><br />(<a href="<?php if($sAccess == 2) { echo site_url('home/deviceName/'.base64_encode($i).'/'.base64_encode($sDevice).'/'.base64_encode($aIP->id)); } else { echo 'javascript:void(0);';}?>" ><?php echo $sValvesNameDb;?></a>)</td>
							<td>
								<div class="rowRadio">
									<div class="custom-radio">
										
										<input class="valveRadio" type="radio" id="radio-other-<?php echo $i;?>-<?php echo $aIP->id;?>" value="0" name="<?php echo $i;?>_MainType" <?php if($sMainType == '0' || $sMainType == ''){ echo 'checked="checked"';}?> <?php if($sAccess == '1') { echo 'disabled="disabled"';}?> hidefocus="true" style="outline: medium none;">
										<label id="relay_other_<?php echo $i;?>_<?php echo $aIP->id;?>" for="radio-other-<?php echo $i;?>-<?php echo $aIP->id;?>" class="<?php if($sMainType == '0' || $sMainType == ''){ echo 'checked';}?>">Other</label>
										
										<input class="valveRadio" type="radio" id="radio-spa-<?php echo $i;?>-<?php echo $aIP->id;?>" name="<?php echo $i;?>_MainType" value="1" <?php if($sMainType == '1'){ echo 'checked="checked"';}?> <?php if($sAccess == '1') { echo 'disabled="disabled"';}?> hidefocus="true" style="outline: medium none;">
										<label id="relay_spa_<?php echo $i;?>_<?php echo $aIP->id;?>" for="radio-spa-<?php echo $i;?>-<?php echo $aIP->id;?>" class="<?php if($sMainType == '1'){ echo 'checked';}?>">Spa</label>
										
										<input class="valveRadio" type="radio" id="radio-pool-<?php echo $i;?>-<?php echo $aIP->id;?>" name="<?php echo $i;?>_MainType" value="2" <?php if($sMainType == '2'){ echo 'checked="checked"';}?> <?php if($sAccess == '1') { echo 'disabled="disabled"';}?> hidefocus="true" style="outline: medium none;">
										<label id="relay_pool_<?php echo $i;?>_<?php echo $aIP->id;?>" for="radio-pool-<?php echo $i;?>-<?php echo $aIP->id;?>" class="<?php if($sMainType == '2'){ echo 'checked';}?>">Pool</label>
									</div>
								</div>
							</td>
							<td>
							<a class="btn btn-green btn-small" style="width:120px" href="<?php if($sAccess == '2') { echo base_url('home/valveRelays/'.base64_encode($i).'/'.base64_encode($sDevice).'/'.base64_encode($aIP->id));} else { echo 'javascript:void(0);';}?>"><?php if(!empty($aRelayNumber)) { ?><span>Edit Relays</span><?php } else { ?><span>Assign Relays</span><?php } ?></a>
							<?php if(!empty($aRelayNumber)) { ?>
							<!--&nbsp;&nbsp;<a class="btn btn-small" style="width:120px" href="javascript:void(0);" <?php if($sAccess == '2') { echo ' onclick="return RemoveValveRelays(\''.$i.'\',\''.$aIP->id.'\');"';}?>><span>Remove Relays</span></a>-->
							<?php } ?>
							
							<!--Remove Valve Button-->
							<a class="btn btn-small" style="width:120px" href="javascript:void(0);" <?php if($sAccess == '2') { echo ' onclick="removeValve(\''.$i.'\',\''.$aIP->id.'\');"';}?> ><span>Remove Valve</span></a>
							<!--Remove Valve Button-->
							
							<!--Pump Setting Button-->
							<a class="btn btn-small <?php if($sAccess == '2') { echo 'fancyboxmanage';}?>" style="width:120px" id="<?php echo $i.'_'.$aIP->id;?>" onclick="setID('<?php echo $i.'_'.$aIP->id;?>')" href="#pumpSettingForm_<?php echo $aIP->id;?>"><span>Pump Setting</span></a>
							<!--Pump Setting Button-->
							<?php
								//Get Device Program Count
								$iRelayProgramCount = $this->home_model->getProgramCount($i,$sDevice,$aIP->id);
							?>
							<!--Pump Program Button-->
							<a class="btn btn-small btn-green" onclick="setID('<?php echo $i.'_'.$aIP->id;?>')" style="width:120px" href="<?php if($sAccess == '2') { echo site_url('valve/Programs/'.base64_encode($i).'/'.base64_encode('ip='.$aIP->id));} else { echo 'javascript:void(0);';}?>"><span>Programs (<?php echo $iRelayProgramCount;?>)</span></a>
							<!--Pump Program Button-->
							
							<!--Default Position Pool Auto Mode -->
							<a class="btn btn-small btn-green" style="width:120px" href="<?php if($sAccess == '2') { echo site_url('valve/defaultPosition/'.base64_encode($i).'/'.base64_encode($aIP->id));} else { echo 'javascript:void(0);';}?>"><span>Default Position</span></a>
							<!--Default Position Pool Auto Mode -->

							</td>
							</tr>
						<?php	}
					} ?>
						<!--<tr><td colspan="3">
						<div class="buttons">
						<a class="btn btn-icon btn-icon-right btn-icon-go addMoreValve" id="addMoreValve-<?php echo $aIP->id;?>" href="javascript:void(0);" hidefocus="true" style="outline: medium none; padding:0px !important;"><span>Add More Valve</span></a>
						</div>
						<div id="moreValve-<?php echo $aIP->id;?>" style="display:none;">
							<input type="text" value="" id="moreValveCnt-<?php echo $aIP->id;?>" name="moreValveCnt-<?php echo $aIP->id;?>" hidefocus="true" style="outline: medium none; width: 45%; margin-top:1px; margin-right:10px;" placeholder="Add Number"><a class="btn btn-icon btn-green btn-icon-right btn-icon-checkout" href="javascript:void(0);" style="padding:0px !important;" hidefocus="true" onclick="saveValveCount('<?php echo $aIP->id;?>')"><span>Save</span></a>
						</div>
						</td></tr>-->
					</tbody>
					</table>
					</div>
				</div>
			</div>							
					
				<?php	
				}
				
				?>
	</div>
	<?php } 
		}
	?>	
</div>
<div class="row" id="allValves" style="display:<?php if('all' != $iFirstIPId){ echo 'none';} ?>;"> <!-- -->
	
	<?php 
			$aParamTemp	=	array('sDevice'=>$sDevice,'sAccess'=>$sAccess,'extra'=>$extra,'iActiveMode'=>$iActiveMode,'aIPDetails'=>$aIPDetails,'iTotalIP'=>$iTotalIP,'iFirstIPId'=>$iFirstIPId);
			
			$this->load->view('allValve',$aParamTemp);
	?>
	
	
	
</div>

<script type="text/javascript">
function checkForm(ipID)
  {
	var pump 	  = $("#pump_"+ipID).val();
	var sValveType = $("input[name='sValveType_"+ipID+"']:checked").val();
	var valve	  =  $("#valve_number_"+ipID).val();
	
	$("#loadingImg").show();
	
	$.ajax({
			type: "POST",
			async:false,
			url: "<?php echo site_url('home/saveValveSetting/');?>", 
			data: {pump:pump,sValveType:sValveType,valve:valve},
			success: function(data) 
			{
				alert("Valve is successfully associated to Pump!");
				$("#loadingImg").hide();
				parent.$a.fancybox.close();
				location.reload();
			}
		})
	
  }
  function setID(id)
  {
	  var arrValveDetails = id.split("_");
	  $("#valve_number_"+arrValveDetails[1]).val(id);
	  $.ajax({
			type: "POST",
			async:false,
			url: "<?php echo site_url('home/getValveSetting/');?>", 
			data: {valve:id},
			success: function(res) 
			{
				if(res != '')
				{
					var data = res.split('|||');
					if(data[0] != '')
					{
						var obj = $.parseJSON(data[0]);
						$("#pump_"+data[1]).val(obj.pump);
						$("#sValveType"+obj.valve_type).prop('checked',true);
					}
				}
			}
		})
	  
  }
</script>		
<!-- END : VALVE DEVICES-->