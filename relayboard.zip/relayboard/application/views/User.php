<?php


$sUserID		= '';
$sUserName 		= '';
$sUserEmail 	= '';
$sUserUsername 	= '';
$sUserPassword 	= '';
$sUserActive 	= '';

if(!empty($userDetails))
{
	foreach($userDetails as $User)
	{
		$sUserID		= $User->id;
		$sUserName 		= $User->name;
		$sUserEmail 	= $User->email;
		$sUserUsername 	= $User->username;
		$sUserPassword 	= base64_decode($User->password);
		$sUserActive 	= $User->block;
	}
}

$sButtonText	=	'';
if($sUserID == '')
	$sButtonText = 'Save User';
else if($sUserID != '')
	$sButtonText = 'Update User';

?>
<style>
.navbar-toggle {
		background-color: transparent !important;
		background-image: none !important;
		border: 1px solid transparent !important;
		border-radius: 4px !important;
		float: left !important;
		margin-bottom: 8px !important;
		margin-right: 15px !important;
		margin-top: 8px !important;
		padding: 9px 10px !important;
		position: relative !important;
	}
	
	.navbar-toggle .icon-bar {
		border-radius: 1px !important;
		display: block !important;
		height: 2px !important;
		width: 22px !important;
	}
</style>
    <div id="page-wrapper">
        <div class="row">
          <div class="col-lg-12">
            <ol class="breadcrumb">
						  <li><img src="<?php echo HTTP_IMAGES_PATH.'icons/home.png';?>" width="24" style="vertical-align: middle !important;">&nbsp;<a href="<?php echo site_url();?>">Home</a> </li>
						  <li><a href="<?php echo base_url('dashboard/users');?>">All Users</a></li>
						  <li class="active">Add/Edit User</li>
				</ol>
          </div>
        </div><!-- /.row -->
        <div class="row">
          <div class="col-lg-12">
            <div class="panel panel-primary">
              <div class="panel-heading" style="border-top-left-radius: 0px;border-top-right-radius: 0px;">
                <h3 class="panel-title" style="color:#FFF;">Add/Edit Page</h3>
              </div>
              <div class="panel-body">
                <div id="morris-chart-area">
                  <form action="<?php echo site_url('dashboard/userAddEdit');?>" method="post">
				  <input type="hidden" name="userID" value="<?php echo $sUserID;?>">
                    <table border="0" cellspacing="0" cellpadding="0" width="100%">
					<tr>
                        <td colspan="3"><span style="color:#FF0000;">* indicates required field</span></td>
                    </tr>
					 <tr><td colspan="3">&nbsp;</td></tr>
                      <tr>
                        <td width="24%"><strong>Name: <span class="mandetory">*</span></strong></td>
                        <td width="1%">&nbsp;</td>
                        <td width="75%"><input type="text" class="form-control" placeholder="Enter Name" name="sUserName" value="<?php echo $sUserName;?>" id="sUserName" required></td>
                      </tr>
                      <tr><td colspan="3">&nbsp;</td></tr>
                      <tr>
                        <td width="10%"><strong>Email: <span class="mandetory">*</span></strong></td>
                        <td width="1%">&nbsp;</td>
                        <td width="89%"><input type="text" class="form-control" placeholder="Enter Email" name="sUserEmail" value="<?php echo $sUserEmail;?>" id="sUserEmail" required></td>
                      </tr>
					  <tr><td colspan="3">&nbsp;</td></tr>
                      <tr>
                        <td width="10%"><strong>Username: <span class="mandetory">*</span></strong></td>
                        <td width="1%">&nbsp;</td>
                        <td width="89%"><input type="text" class="form-control" placeholder="Enter Username" name="sUserUsername" value="<?php echo $sUserUsername;?>" id="sUserUsername" required></td>
                      </tr>
					  <tr><td colspan="3">&nbsp;</td></tr>
                      <tr>
                        <td width="10%"><strong>Password: <span class="mandetory">*</span></strong></td>
                        <td width="1%">&nbsp;</td>
                        <td width="89%"><input type="password" class="form-control" placeholder="Enter Password" name="sUserPassword" value="<?php echo $sUserPassword;?>" id="sUserPassword" required></td>
                      </tr>
					  <tr><td colspan="3">&nbsp;</td></tr>
                      <tr>
                        <td width="10%"><strong>Block:</strong></td>
                        <td width="1%">&nbsp;</td>
                        <td width="89%"><input type="radio" name="sUserActive" value="0" <?php if($sUserActive == '0'|| $sUserActive == ''){echo 'checked="checked"';} ?> checked="checked">&nbsp;No&nbsp;&nbsp;&nbsp;&nbsp;<input type="radio" <?php if($sUserActive == '1'){echo 'checked="checked"';} ?> name="sUserActive" value="1">&nbsp;Yes</td>
                      </tr>
                      <tr><td colspan="3">&nbsp;</td></tr>
                      <tr><td colspan="3"><span class="btn btn-green"><input type="submit" name="command" value="<?php echo $sButtonText;?>" class="btn btn-success" onclick="return checkForm();"></span>&nbsp;&nbsp;<span class="btn btn-red"><input type="button" name="back" value="Back" class="btn btn-success" onclick="javascript:location.href='<?php echo base_url('dashboard/users');?>';"></span></td></tr>
                      
                    </table>
                  </form>
                </div>
              </div>
            </div>
          </div>
        </div><!-- /.row -->
      </div><!-- /#page-wrapper -->
<script type="text/javascript">
$(document).ready(function (){
	
});
  function checkForm()
  {
	  var sEmail	=	$("#sUserEmail").val();
	  if( !validateEmail(sEmail)) 
	  {
		  alert("Please enter Valid Email ID!");
		  $("#sUserEmail").css('border','1px solid Red');
		  return false;
	  }
	  else
		  $("#sUserEmail").css('border','');
	  
    return true;
  }
  
  function validateEmail($email) 
  {
	var emailReg = /^([\w-\.]+@([\w-]+\.)+[\w-]{2,4})?$/;
	return emailReg.test( $email );
  }
</script>

<?php

?>