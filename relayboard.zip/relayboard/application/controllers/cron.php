<?php
/**
* @Programmer: Dhiraj S.
* @Created: 10 Aug 2015
* @Modified: 
* @Description: All cron related functionalities for the Devices.
**/

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Cron extends CI_Controller 
{
    public function __construct() 
    {
        parent::__construct();
        $this->load->helper('common_functions');
    }
    
    public function index()
    {
		
	//$seconds = 2; 
        //$micro = $seconds * 1000000;
        $this->load->model('analog_model');
        $this->load->model('home_model');
        //while(true)
        {    
            list($sIpAddress, $sPortNo, $extra) = $this->home_model->getSettings();
            $sResponse =   response_input_switch($sIpAddress,$sPortNo);
			//$sResponse =   'S,181,0,4,05:44:07,5,04,00......,....000000000000,00000000,0,0,0,0,12578,42.1F,,,,,,0.00,000000,0.00,00,00,00';
			//echo $sResponse;
			if($sResponse != '')
			{
				$aResponse = explode(',',$sResponse);
				$aReturn['remote_spa_ctrl_st'] = (isset($aResponse['22'])) ? $aResponse['22'] : '';
				$sRemote			=	substr($aReturn['remote_spa_ctrl_st'], 0, 4);
				
				$sValves 			= (isset($aResponse['7'])) ? $aResponse['7'] : '';
				$sRelays 			= (isset($aResponse['8'])) ? $aResponse['8'] : '';
				$sPowercenter 		= (isset($aResponse['9'])) ? $aResponse['9'] : '';
				
				$aResult            =   $this->analog_model->getAllAnalogDevice();
				$aResultDirection   =   $this->analog_model->getAllAnalogDeviceDirection();
				$iResultCnt 		=   count($aResult);
				
				for($i=0; $i<$iResultCnt; $i++)
				{
					if($aResult[$i] != '')
					{
						$aDevice = explode('_',$aResult[$i]);
						if($aDevice[1] != '')
						{
							if($aDevice[1] == 'R')
							{
								if($sRelays[$aDevice[0]] != '' && $sRelays[$aDevice[0]] != '.')
								{
									$sNewResp = replace_return($sRelays, $sRemote[$i], $aDevice[0] );
									onoff_rlb_relay($sNewResp);
								}
							}
							if($aDevice[1] == 'P')
							{
								$sNewResp = replace_return($sPowercenter, $sRemote[$i], $aDevice[0] );
								onoff_rlb_powercenter($sNewResp);
							}
							if($aDevice[1] == 'V')
							{
								if($sValves[$aDevice[0]] != '' && $sValves[$aDevice[0]] != '.')
								{
									$sStatusChnage = $aResultDirection[$i];

									if($sRemote[$i] == '0')
									$sNewResp = replace_return($sValves, $sRemote[$i], $aDevice[0] );
									else if($sRemote[$i] == '1')
									$sNewResp = replace_return($sValves, $sStatusChnage, $aDevice[0] ); 

									onoff_rlb_valve($sNewResp);
								}
							}
							if($aDevice[1] == 'PS')
							{
								$this->cronMakePumpOnOFF($aDevice[0],$sRemote[$i]);
							}
							if($aDevice[1] == 'L')
							{
								$aLightDetails  =   $this->home_model->getLightDeviceDetails($aDevice[0]);
								if(!empty($aLightDetails))
								{
									foreach($aLightDetails as $aDeviceDetails)
									{
										$sHeaterStatus	=	'';
										$sRelayDetails  =   unserialize($aDeviceDetails->light_relay_number);
										
										//Light Operated Type and Relay
										$sRelayType     =   $sRelayDetails['sRelayType'];
										$sRelayNumber   =   $sRelayDetails['sRelayNumber'];
										
										if($sRelayType == '24')
										{
											$sNewResp = replace_return($sRelays, $sRemote[$i], $sRelayNumber );
											onoff_rlb_relay($sNewResp);
											$this->home_model->updateDeviceRunTime($sRelayNumber,$sDevice,$sStatus);
										}
										if($sRelayType == '12')
										{
											$sNewResp = replace_return($sPowercenter, $sRemote[$i], $sRelayNumber );
											onoff_rlb_powercenter($sNewResp);
										}
									}
								}		
							}
							if($aDevice[1] == 'H')
							{
								$aHeaterDetails  =   $this->home_model->getHeaterDeviceDetails($aDevice[0]);
								if(!empty($aHeaterDetails))
								{
									foreach($aHeaterDetails as $aDeviceDetails)
									{
										$sHeaterStatus	=	'';
										$sRelayDetails  =   unserialize($aDeviceDetails->light_relay_number);
										
										//Heater Operated Type and Relay
										$sRelayType     =   $sRelayDetails['sRelayType'];
										$sRelayNumber   =   $sRelayDetails['sRelayNumber'];
										
										if($sRelayType == '24')
										{
											$sNewResp = replace_return($sRelays, $sRemote[$i], $sRelayNumber );
											onoff_rlb_relay($sNewResp);
											$this->home_model->updateDeviceRunTime($sRelayNumber,$sDevice,$sStatus);
										}
										if($sRelayType == '12')
										{
											$sNewResp = replace_return($sPowercenter, $sRemote[$i], $sRelayNumber );
											onoff_rlb_powercenter($sNewResp);
										}
									}
								}		
							}
							if($aDevice[1] == 'B')
							{
								$aBlowerDetails  =   $this->home_model->getBlowerDeviceDetails($aDevice[0]);
								if(!empty($aBlowerDetails))
								{
									foreach($aBlowerDetails as $aDeviceDetails)
									{
										$sHeaterStatus	=	'';
										$sRelayDetails  =   unserialize($aDeviceDetails->light_relay_number);
										
										//Heater Operated Type and Relay
										$sRelayType     =   $sRelayDetails['sRelayType'];
										$sRelayNumber   =   $sRelayDetails['sRelayNumber'];
										
										if($sRelayType == '24')
										{
											$sNewResp = replace_return($sRelays, $sRemote[$i], $sRelayNumber );
											onoff_rlb_relay($sNewResp);
											$this->home_model->updateDeviceRunTime($sRelayNumber,$sDevice,$sStatus);
										}
										if($sRelayType == '12')
										{
											$sNewResp = replace_return($sPowercenter, $sRemote[$i], $sRelayNumber );
											onoff_rlb_powercenter($sNewResp);
										}
									}
								}		
							}
							if($aDevice[1] == 'M')
							{
								$aMiscDetails  =   $this->home_model->getMiscDeviceDetails($aDevice[0]);
								if(!empty($aMiscDetails))
								{
									foreach($aMiscDetails as $aDeviceDetails)
									{
										$sHeaterStatus	=	'';
										$sRelayDetails  =   unserialize($aDeviceDetails->light_relay_number);
										
										//Heater Operated Type and Relay
										$sRelayType     =   $sRelayDetails['sRelayType'];
										$sRelayNumber   =   $sRelayDetails['sRelayNumber'];
										
										if($sRelayType == '24')
										{
											$sNewResp = replace_return($sRelays, $sRemote[$i], $sRelayNumber );
											onoff_rlb_relay($sNewResp);
											$this->home_model->updateDeviceRunTime($sRelayNumber,$sDevice,$sStatus);
										}
										if($sRelayType == '12')
										{
											$sNewResp = replace_return($sPowercenter, $sRemote[$i], $sRelayNumber );
											onoff_rlb_powercenter($sNewResp);
										}
									}
								}		
							}
						}
					}
				} 
			} 
							

            /*$myFile = "/var/www/relay_framework/daemontest1.txt";
            $fh = fopen($myFile, 'a') or die("Can't open file");
            $stringData = "File updated at: " . $sResponse. "\n";
            fwrite($fh, $stringData);
            fclose($fh); 
            usleep($micro); */    
        }      
    }
	
    public function pumpResponse()
    { 	
		$this->load->model('home_model');
		$aViewParameter['aIPDetails'] = $this->home_model->getBoardIP();
		
		list($sIpAddress, $sPortNo, $extra) = $this->home_model->getSettings();
		
		foreach($aViewParameter['aIPDetails'] as $IP)
		{
			$ipID   =   $IP->id;
        
        	//GET IP of Device
			$sDeviceIP  =   $IP->ip;
			$aPumps     =   $this->home_model->selectEmulatorOnPumps($ipID);	
			
			$aPumpsChk	= json_decode($aPumps);
		   
			if(!empty($aPumpsChk))	
			{
		
				//while(true)
				{
					$sResponse =   send_command_udp_new($sDeviceIP,$sPortNo,$aPumps);

					if($sResponse != '')
					{
						//$aResponse['message'] =$sResponse;
						//echo $sResponse;
						//exit;
						$aResponse	=	explode("|||",$sResponse);
						foreach($aResponse as $strResponse)
						{
								$aCheckResponse	=	explode(',',$strResponse);
								//$iPump			=   str_replace('M','',$aCheckResponse[0]);
								//if($aCheckResponse[1] == '0')
								//	$strResponse .= ',STOP';

								//$iPump	=	$aCheckResponse[1];
								$iPump	=	str_replace('M','',$aCheckResponse[0]);
								
								if($aCheckResponse[2] == '0')
										$strResponse .= ',STOP';

								if(preg_match('/^M/',$strResponse))
									$this->home_model->savePumpResponse($strResponse,$iPump,$ipID);
								
								//echo $strResponse.'<br>';
						}

						//echo json_encode($aResponse);
					}

					/* $myFile = "/var/www/relay_framework/daemontest1.txt";
					$fh = fopen($myFile, 'a') or die("Can't open file");
					$stringData = "File updated at: " . time(). "\n";
					fwrite($fh, $stringData);
					fclose($fh); */
					//usleep($micro); 
				}
			}
		}


        //$aresponse['message'] = $sResponse;
        //echo json_encode($aresponse);
    }
	
	public function resPump()
	{
		$this->load->model('home_model');
		$sIdIP	=	1;
		//GET IP of Device
		$sDeviceIP		= 	$this->home_model->getBoardIPFromID($sIdIP);
		
		//Get saved IP and PORT 
		list($sIP,$sPortNo,$extra) = $this->home_model->getSettings();
		
		$shhPort	=	'';
		if(IS_LOCAL == '1')
		{
			//Get SSH port of the RLB board using IP.
			$shhPort = $this->home_model->getSSHPortFromID($sIdIP);
		}
		
		//$sResponse =   send_command_udp_new_test(1,$sDeviceIP,$sPortNo,$shhPort);
		$sResponse =   send_command_udp_new_test(1,$sDeviceIP,$sPortNo,$shhPort);
		
		echo 'Response : '.$sResponse;
	}
	
    public function pumpResponseLatest()
    {
            $iPumpID	=	$_GET['iPumpID'];
			$sIpID		=	$_GET['sIpId'];
			
            $this->load->model('home_model');
            $strPumpsResponse = $this->home_model->selectPumpsLatestResponse($iPumpID,$sIpID);	
			
			//GET IP of Device
			$sDeviceIP		= 	$this->home_model->getBoardIPFromID($sIpID);
			
			//Get saved IP and PORT 
			list($sIP,$sPort,$extra) = $this->home_model->getSettings();
			
			$shhPort	=	'';
			if(IS_LOCAL == '1')
			{
				//Get SSH port of the RLB board using IP.
				$shhPort = $this->home_model->getSSHPortFromID($sIpID);
			}
			
            $sResponse      		=   get_rlb_status($sDeviceIP,$sPort,$shhPort);
            //Pump device Status
            //$sPump  =   array($sResponse['pump_seq_0_st'],$sResponse['pump_seq_1_st'],$sResponse['pump_seq_2_st']);
			$arrAllPumpsStatus	=	$this->home_model->getAllPumpsStatus($sIpID);
			
			foreach($arrAllPumpsStatus as $pumpStatus)
			{
				$sPump[$pumpStatus->pump_number] = $pumpStatus->status;
			}
            $arrPumpsResponse   =   $this->home_model->selectPumpsStatus($iPumpID,$sIpID);

            /* if($sPump[$iPumpID] > 0 && $arrPumpsResponse == 0)
            {
                    $arrPumpsResponse		= 1;		
                    $this->home_model->updateDeviceStauts($iPumpID,'PS',$arrPumpsResponse,$sIpID);
            }
            else if($sPump[$iPumpID] == 0  && $arrPumpsResponse == 1)	
            {
                    $arrPumpsResponse		= 0;		
                    $this->home_model->updateDeviceStauts($iPumpID,'PS',$arrPumpsResponse,$sIpID);
            } */

            $aResult    =   array();
            if($arrPumpsResponse == 0)
                    $aResult['message'] = '';
            else
                    $aResult['message'] = $strPumpsResponse;

            echo json_encode($aResult['message']);
    }
	
	
    public function program()
    {
		//echo date('Y-m-d H:i:s');
		//exit;
		
		$this->load->model('home_model');
		
		list($sIP,$sPort,$extra) = $this->home_model->getSettings();
		
		$iMode          =   $this->home_model->getActiveMode();
        //$iMode          =   1;
        $sTime          =   date('H:i:s',time());
		
		//$sTime			=	'10:00:01';
        $aAllProgram    =   $this->home_model->getAllProgramsDetails();
        
		//echo '<pre>';print_r($aAllProgram);echo '</pre>';
	    //die('STOP');

        if(is_array($aAllProgram) && !empty($aAllProgram))
        {
            foreach($aAllProgram as $aResultProgram)
            {
				$sResponse		=	array();
				$sValves        =   ''; 
				$sRelays        =   '';  
				$sPowercenter   =   ''; 
				$sTime          =   '';
				$sPump			=	'';	
				$sDayret		=	'';

				$sRelayName     = $aResultProgram->device_number;
				$sDevice     	= $aResultProgram->device_type;
                $iProgId        = $aResultProgram->program_id;
                $sProgramType   = $aResultProgram->program_type;
                $sProgramStart  = $aResultProgram->start_time;
                $sProgramEnd    = $aResultProgram->end_time;
                $sProgramActive = $aResultProgram->program_active;
                $sProgramDays   = $aResultProgram->program_days;
				$sProgramIPID   = $aResultProgram->ip_id;
				$valvePosition  = $aResultProgram->valvePosition;
			
				$sDeviceIP	= 	$this->home_model->getBoardIPFromID($sProgramIPID);
				//$shhPort	=	'22';
				$shhPort	=	'';
				
				$sResponse      =   get_rlb_status($sDeviceIP,$sPort,$shhPort);
				
				$sRelays        =   $sResponse['relay'];
				$sValves        =   $sResponse['valves'];
				$sPowercenter   =   $sResponse['powercenter'];
				//$sTime        =   $sResponse['time'];
				$sTime          =   date('H:i:s',time());
				$sDayret        =   $sResponse['day'];
				
                $sProgramAbs            = $aResultProgram->program_absolute;
                $sProgramAbsStart       = $aResultProgram->program_absolute_start_time;
                $sProgramAbsEnd         = $aResultProgram->program_absolute_end_time;
                $sProgramAbsTotal       = $aResultProgram->program_absolute_total_time;
                $sProgramAbsAlreadyRun  = $aResultProgram->program_absolute_run_time;

                $sProgramAbsStartDay    = $aResultProgram->program_absolute_start_date;
                $sProgramAbsRun         = $aResultProgram->program_absolute_run;
                $sReboot                = $aResultProgram->is_on_after_reboot;  
				$sProgramWork           = $aResultProgram->program_work_in_mode;

                $sDays          =   '';
                $aDays          =   array();
				
				if($sProgramType == 2)
                {
                    $sDays = str_replace('7','0', $sProgramDays);
                    $aDays = explode(',',$sDays);
                }
				//$sProgramWork	=	'1';
				
				if($sProgramWork == '1')
				{					
					//$iMode = 1;
					if($sRelays[$sRelayName] != '' && $sRelays[$sRelayName] != '.' && $sDevice == 'R')
					{
						if($sProgramType == 1 || ($sProgramType == 2 && in_array($sDayret, $aDays)))
						{
							$aAbsoluteDetails       = array('absolute_s'  => $sProgramAbsStart,
															'absolute_e'  => $sProgramAbsEnd,
															'absolute_t'  => $sProgramAbsTotal,
															'absolute_ar' => $sProgramAbsAlreadyRun,
															'absolute_sd' => $sProgramAbsStartDay,
															'absolute_st' => $sProgramAbsRun
															); 

							if($sProgramAbs == '1' && $iMode == 1)
							{
								if($sProgramActive == 0)
									$this->home_model->updateProgramAbsDetails($iProgId, $aAbsoluteDetails);

								if($sTime >= $sProgramStart && ($sProgramActive == 0 || ($sProgramActive == 1 && $sReboot == '1')) && $sProgramAbsRun == 0)
								{
									$iRelayStatus = 1;
									$sRelayNewResp = replace_return($sRelays, $iRelayStatus, $sRelayName );
									onoff_rlb_relay($sRelayNewResp,$sDeviceIP,$sPort,$shhPort);
									$this->home_model->updateProgramStatus($iProgId, 1);
								}
								else if($sTime >= $sProgramAbsEnd && $sProgramActive == 1)
								{
									$iRelayStatus = 0;
									$sRelayNewResp = replace_return($sRelays, $iRelayStatus, $sRelayName );
									onoff_rlb_relay($sRelayNewResp,$sDeviceIP,$sPort,$shhPort);
									$this->home_model->updateProgramStatus($iProgId, 0);
									$this->home_model->updateAbsProgramRun($iProgId, '1');
								}
								
								if($sReboot == '1')
								{
									$this->home_model->updateRebootStatus($iProgId, '0');
								}
							}
							else if($sProgramAbs == '1' && $iMode == 2)
							{
								if($sProgramActive == 1)
								{
									$iRelayStatus = 0;
									$sRelayNewResp = replace_return($sRelays, $iRelayStatus, $sRelayName );
									onoff_rlb_relay($sRelayNewResp,$sDeviceIP,$sPort,$shhPort);
									$this->home_model->updateProgramStatus($iProgId, 0);
									$this->home_model->updateAlreadyRunTime($iProgId, $aAbsoluteDetails);
								}
							}
							else
							{
								//on relay
								if($sTime >= $sProgramStart && $sTime < $sProgramEnd && ($sProgramActive == 0 || ($sReboot == '1' && $sProgramActive == 1)))
								{
									if($iMode == 1)
									{
										$iRelayStatus = 1;
										$sRelayNewResp = replace_return($sRelays, $iRelayStatus, $sRelayName );
										onoff_rlb_relay($sRelayNewResp,$sDeviceIP,$sPort,$shhPort);
										$this->home_model->updateProgramStatus($iProgId, 1);
									}
								}//off relay
								else if($sTime >= $sProgramEnd && $sProgramActive == 1)
								{
									$iRelayStatus = 0;
									$sRelayNewResp = replace_return($sRelays, $iRelayStatus, $sRelayName );
									onoff_rlb_relay($sRelayNewResp,$sDeviceIP,$sPort,$shhPort);
									$this->home_model->updateProgramStatus($iProgId, 0);
								}
								
								if($sReboot == '1')
								{
									$this->home_model->updateRebootStatus($iProgId, '0');
								}
							} 
						}
					}
					else if($sDevice == 'PS')
					{	
						if($sProgramType == 1 || ($sProgramType == 2 && in_array($sDayret, $aDays)))
						{
							$aAbsoluteDetails       = array('absolute_s'  => $sProgramAbsStart,
															'absolute_e'  => $sProgramAbsEnd,
															'absolute_t'  => $sProgramAbsTotal,
															'absolute_ar' => $sProgramAbsAlreadyRun,
															'absolute_sd' => $sProgramAbsStartDay,
															'absolute_st' => $sProgramAbsRun
															); 
							
							
							
							/* $aPumpDetails = $this->home_model->getPumpDetails($sRelayName,$sProgramIPID);						
							//Variable Initialization to blank.
							$sPumpNumber  	= '';
							$sPumpType  	= '';
							$sPumpSubType  	= '';
							$sPumpSpeed  	= '';
							$sPumpFlow 	= '';
							$sPumpClosure   = '';
							$sRelayNumber  	= '';

							if(is_array($aPumpDetails) && !empty($aPumpDetails))
							{
								foreach($aPumpDetails as $aResultEdit)
								{ 
									$sPumpNumber  = $aResultEdit->pump_number;
									$sPumpType    = $aResultEdit->pump_type;
									$sPumpSubType = $aResultEdit->pump_sub_type;
									$sPumpSpeed   = $aResultEdit->pump_speed;
									$sPumpFlow    = $aResultEdit->pump_flow;
									$sPumpClosure = $aResultEdit->pump_closure;
									$sRelayNumber = $aResultEdit->relay_number;
								}
							} */

							//$iMode = '1';
							if($sProgramAbs == '1' && $iMode == 1)
							{
								if($sTime >= $sProgramStart && ($sProgramActive == 0 || ($sReboot == '1' && $sProgramActive == 1)) && $sProgramAbsRun == 0)
								{
									$this->home_model->updateProgramAbsDetails($iProgId, $aAbsoluteDetails);
									$iPumpStatus = 1;

									$this->cronMakePumpOnOFF($sRelayName,$iPumpStatus,$sDeviceIP,$sPort,$shhPort,$sProgramIPID);
									
									$this->home_model->updateProgramStatus($iProgId, $iPumpStatus);
								}
								else if($sTime >= $sProgramAbsEnd && $sProgramActive == 1)
								{
									$iPumpStatus = 0;
									
									$this->cronMakePumpOnOFF($sRelayName,$iPumpStatus,$sDeviceIP,$sPort,$shhPort,$sProgramIPID);
									
									$this->home_model->updateProgramStatus($iProgId, $iPumpStatus);
									$this->home_model->updateAbsProgramRun($iProgId, '1');
									$this->home_model->updateAbsProgramRunDetails($iProgId, '1');
								}
								if($sReboot == '1')
								{
									$this->home_model->updateRebootStatus($iProgId, '0');
								}
							}
							else if($sProgramAbs == '1' && $iMode == 2 )
							{
								if($sProgramActive == 1)
								{
									$iPumpStatus = 0;
									
									$this->cronMakePumpOnOFF($sRelayName,$iPumpStatus,$sDeviceIP,$sPort,$shhPort,$sProgramIPID);
									
									$this->home_model->updateProgramStatus($iProgId, $iPumpStatus);
									$this->home_model->updateAlreadyRunTime($iProgId, $aAbsoluteDetails);
								}
							}
							else
							{
								//echo $sProgramStart.'>>'.$sTime.'>>'.$sProgramEnd;
								//die('STOP');
								//on Pump
								if($sTime >= $sProgramStart && $sTime < $sProgramEnd && ($sProgramActive == 0 || ($sReboot == '1' && $sProgramActive == 1) ) )
								{
									//echo $aResultProgram->program_name.'<br>';
									if($iMode == 1)
									{
										$iPumpStatus = 1;
										
										$this->cronMakePumpOnOFF($sRelayName,$iPumpStatus,$sDeviceIP,$sPort,$shhPort,$sProgramIPID);
										
										$this->home_model->updateProgramStatus($iProgId, $iPumpStatus);
									}
								}//off Pump
								else if($sTime >= $sProgramEnd && $sProgramActive == 1)
								{
									$iPumpStatus = 0;
									
									$checkPumpOnInCustom = $this->home_model->checkPumpOnInCustom($sRelayName,$sProgramIPID,$sDevice);
									
									if($checkPumpOnInCustom == '0')
									{
										$this->cronMakePumpOnOFF($sRelayName,$iPumpStatus,$sDeviceIP,$sPort,$shhPort,$sProgramIPID);
									}
									
									$this->home_model->updateProgramStatus($iProgId, 0);
								}
				
								if($sReboot == '1')
								{
									$this->home_model->updateRebootStatus($iProgId, '0');
								}
							} 
						}
					}
					else if($sValves[$sRelayName] != '' && $sValves[$sRelayName] != '.' && $sDevice == 'V')
					{
						if($sProgramType == 1 || ($sProgramType == 2 && in_array($sDayret, $aDays)))
						{
							/* $aAbsoluteDetails       = array('absolute_s'  => $sProgramAbsStart,
															'absolute_e'  => $sProgramAbsEnd,
															'absolute_t'  => $sProgramAbsTotal,
															'absolute_ar' => $sProgramAbsAlreadyRun,
															'absolute_sd' => $sProgramAbsStartDay,
															'absolute_st' => $sProgramAbsRun
															); 

							if($sProgramAbs == '1' && $iMode == 1)
							{
								if($sProgramActive == 0)
									$this->home_model->updateProgramAbsDetails($iProgId, $aAbsoluteDetails);

								if($sTime >= $sProgramStart && ($sProgramActive == 0 || ($sProgramActive == 1 && $sReboot == '1')) && $sProgramAbsRun == 0)
								{
									$iRelayStatus = 1;
									$sRelayNewResp = replace_return($sValves, $iRelayStatus, $sRelayName );
									//First Get the Current Status.
									$currentOnPosition = $sValves[$sRelayName];
									
									if($currentOnPosition  != 0)
									{
										$this->home_model->saveLastRun($sRelayName,'V',$currentOnPosition,$sProgramIPID);
									}
									onoff_rlb_valve($sRelayNewResp,$sDeviceIP,$sPort,$shhPort);
									$this->home_model->updateProgramStatus($iProgId, 1);
								}
								else if($sTime >= $sProgramAbsEnd && $sProgramActive == 1)
								{
									$iRelayStatus = 0;
									$sRelayNewResp = replace_return($sValves, $iRelayStatus, $sRelayName );
									//First Get the Current Status.
									$currentOnPosition = $sValves[$sRelayName];
									
									if($currentOnPosition  != 0)
									{
										$this->home_model->saveLastRun($sRelayName,'V',$currentOnPosition,$sProgramIPID);
									}
									onoff_rlb_valve($sRelayNewResp,$sDeviceIP,$sPort,$shhPort);
									$this->home_model->updateProgramStatus($iProgId, 0);
									$this->home_model->updateAbsProgramRun($iProgId, '1');
								}
								
								if($sReboot == '1')
								{
									$this->home_model->updateRebootStatus($iProgId, '0');
								}
							}
							else if($sProgramAbs == '1' && $iMode == 2)
							{
								if($sProgramActive == 1)
								{
									$iRelayStatus = 0;
									$sRelayNewResp = replace_return($sValves, $iRelayStatus, $sRelayName );
									//First Get the Current Status.
									$currentOnPosition = $sValves[$sRelayName];
									
									if($currentOnPosition  != 0)
									{
										$this->home_model->saveLastRun($sRelayName,'V',$currentOnPosition,$sProgramIPID);
									}
									onoff_rlb_valve($sRelayNewResp,$sDeviceIP,$sPort,$shhPort);
									$this->home_model->updateProgramStatus($iProgId, 0);
									$this->home_model->updateAlreadyRunTime($iProgId, $aAbsoluteDetails);
								}
							}
							else */
							/* { */
								//on relay
								if($sTime >= $sProgramStart && $sTime < $sProgramEnd && ($sProgramActive == 0 || ($sReboot == '1' && $sProgramActive == 1)))
								{
									if($iMode == 1)
									{
										$iRelayStatus = $valvePosition;
										$sRelayNewResp = replace_return($sValves, $iRelayStatus, $sRelayName );
										//First Get the Current Status.
										$currentOnPosition = $sValves[$sRelayName];
										
										if($currentOnPosition  != 0)
										{
											$this->home_model->saveLastRun($sRelayName,'V',$currentOnPosition,$sProgramIPID);
										}
										/* else if($currentOnPosition  == 0)
										{
											$this->home_model->removeLastRun($sRelayName,'V',$sProgramIPID);
										} */
											
										onoff_rlb_valve($sRelayNewResp,$sDeviceIP,$sPort,$shhPort);
										
										$this->home_model->updateProgramStatus($iProgId, 1);
									}
								}//off relay
								else if($sTime >= $sProgramEnd && $sProgramActive == 1)
								{
									$iRelayStatus = 0;
									$sRelayNewResp = replace_return($sValves, $iRelayStatus, $sRelayName );
									//First Get the Current Status.
									$currentOnPosition = $sValves[$sRelayName];
									
									if($currentOnPosition  != 0)
									{
										$this->home_model->saveLastRun($sRelayName,'V',$currentOnPosition,$sProgramIPID);
									}
									/* else if($currentOnPosition  == 0)
									{
										$this->home_model->removeLastRun($sRelayName,'V',$sProgramIPID);
									} */
									onoff_rlb_valve($sRelayNewResp,$sDeviceIP,$sPort,$shhPort);
									$this->home_model->updateProgramStatus($iProgId, 0);
								}
								
								if($sReboot == '1')
								{
									$this->home_model->updateRebootStatus($iProgId, '0');
								}
							/* } */
						}
					}
				}
				else if($sProgramWork == '0')
				{
					if($sDevice == 'R' && $sProgramActive == 1)
					{
						$iRelayStatus = 0;
						$sRelayNewResp = replace_return($sRelays, $iRelayStatus, $sRelayName );
						onoff_rlb_relay($sRelayNewResp,$sDeviceIP,$sPort,$shhPort);	
						$this->home_model->updateProgramStatus($iProgId, 0);
					}
					else if($sDevice == 'PS' && $sProgramActive == 1)
					{
						$iPumpStatus = 0;
						$checkPumpOnInCustom = $this->home_model->checkPumpOnInCustom($sRelayName,$sProgramIPID,$sDevice);
									
						if($checkPumpOnInCustom == '0')
						{
							$this->cronMakePumpOnOFF($sRelayName,$iPumpStatus,$sDeviceIP,$sPort,$shhPort,$sProgramIPID);
						}
						
						$this->home_model->updateProgramStatus($iProgId, $iPumpStatus);
					}
					else if($sDevice == 'V' && $sProgramActive == 1)
					{
						$iRelayStatus = 0;
						//First Get the Current Status.
						$currentOnPosition = $sValves[$sRelayName];
						
						if($currentOnPosition  != 0)
						{
							$this->home_model->saveLastRun($sRelayName,'V',$currentOnPosition,$sProgramIPID);
						}
						/* else if($currentOnPosition  == 0)
						{
							$this->home_model->removeLastRun($sRelayName,'V',$sProgramIPID);
						} */
						
						$sRelayNewResp = replace_return($sValves, $iRelayStatus, $sRelayName );
						onoff_rlb_valve($sRelayNewResp,$sDeviceIP,$sPort,$shhPort);
						$this->home_model->updateProgramStatus($iProgId, 0);
					}
					
					if($sReboot == '1')
					{
						$this->home_model->updateRebootStatus($iProgId, '0');
					}
				}
            }
        }
    }
    
    public function checkDeviceManualTime() //START : Function to make the Device OFF if Time is set in Manual Mode.
    {
        $this->load->model('home_model');
		
		//Get All IP Details.
		$aIPDetails = $this->home_model->getBoardIP();
		
		list($sIP,$sPort,$extra) = $this->home_model->getSettings();
		
		//Get Current Mode of the System.
		$iMode          =   $this->home_model->getActiveMode();
		
		foreach($aViewParameter['aIPDetails'] as $IP)
		{
			$shhPort	=	'';
			if(IS_LOCAL == '1')
			{
				//Get SSH port of the RLB board using IP.
				$shhPort = $this->home_model->getSSHPortFromID($IP->id);
			}
			$sResponse		=	'';
			$sRelays        =   '';  
			$sTime          =   '';
			
			//Get the status response of devices from relay board.
			$sResponse      =   get_rlb_status($IP->ip,$sPort,$shhPort);
			$sRelays        =   $sResponse['relay'];
			$sTime          =   $sResponse['time'];
			
			//Get All device with Time 
			$aAllTime       =   $this->home_model->getAllDeviceTimeDetails($IP->id);
			
			//START : If atleast 1 device has Time and Mode is Manual.
			if(is_array($aAllTime) && !empty($aAllTime) && $iMode == 2)
			{
				foreach($aAllTime as $aResultTime)
				{
					$sDeviceName     = $aResultTime->device_number;
					$sDevice         = $aResultTime->device_type;
					$sDeviceEnd      = $aResultTime->device_end_time;

					if($sTime >= $sDeviceEnd)//If Device End time is passed then switch OFF the DEVICE.
					{
						$iRelayStatus = 0;
						$sRelayNewResp = replace_return($sRelays, $iRelayStatus, $sDeviceName );
						
						//Update the start time and end time of the Device.
						$this->home_model->updateDeviceRunTime($sDeviceName, $sDevice, $iRelayStatus,$IP->id);
						onoff_rlb_relay($sRelayNewResp,$IP->ip,$sPort,$shhPort);
					}
				}
			}
			//END : If atleast 1 device has Time and Mode is Manual.
		}
    }
	
	public function changeManualTimeMode() //START : Function for Manual Mode to auto after specified Time.
    {
        $this->load->model('home_model');
        
		//Get the timer start and end time.
        $aTimer			=	$this->home_model->getManualModeTimer();
		$sTime			=	date('Y-m-d H:i:s',time());
		//Get Current Mode of the System.
        $iActiveMode    =   $this->home_model->getActiveMode();
		$iMode = '1';
		
		
		/* echo '<pre>';print_r($aTimer);echo '</pre>';
		echo $sTime.'>>'.$iActiveMode.'>>'.$iMode;
		die('STOP'); */
		if($aTimer['END'] != '')
		{
			if(strtotime($sTime) >= strtotime($aTimer['END']))//If Device End time is passed then switch OFF the DEVICE.
			{
				if($iActiveMode != $iMode)
				{
					$this->home_model->updateMode($iMode);
					
					//Get All IP Details.
					$aIPDetails = $this->home_model->getBoardIP();
					
					list($sIP,$sPort,$extra) = $this->home_model->getSettings();
					
					foreach($aViewParameter['aIPDetails'] as $IP)
					{
						$shhPort	=	'';
						if(IS_LOCAL == '1')
						{
							//Get SSH port of the RLB board using IP.
							$shhPort = $this->home_model->getSSHPortFromID($IP->id);
						}
						$sResponse		=	array();
						$sRelays        =   '';  
						$sValves		=	'';
						$sPowercenter   =   '';
						$sTime          =   '';
						
						//Get the status response of devices from relay board.
						$sResponse      =   get_rlb_status($IP->ip,$sPort,$shhPort);
						
						$sValves        =   $sResponse['valves'];
						$sRelays        =   $sResponse['relay'];
						$sPowercenter   =   $sResponse['powercenter'];
						$sPump          =   array($sResponse['pump_seq_0_st'],$sResponse['pump_seq_1_st'],$sResponse['pump_seq_2_st']);
						
						$relay_count   	=   strlen($sRelays);
						$valve_count    =   strlen($sValves);
						$power_count    =   strlen($sPowercenter);
						
						//off all relays
						if($sRelays != '')
						{
							//$sRelayNewResp = str_replace('1','0',$sRelays);
							//onoff_rlb_relay($sRelayNewResp,$IP->ip,$sPort,$shhPort);
							for($i=0; $i<$relay_count; $i++)	
							{
								if($sRelays[$i] != '.')
								{
									if(!in_array($i.'_'.$IP->id,$excludeDevices['R']))
									{
										$sNewResp = replace_return($sRelays, 0, $i);
										onoff_rlb_relay($sNewResp,$IP->ip,$sPort,$shhPort);
									}
									
									//Start : Check if relay is assigned to Heater.
									$HeaterNumber = $this->home_model->chkHeater($i,'24',$IP->id);
									if($HeaterNumber != '')
									{
										$this->heaterDetailsUpdateC($HeaterNumber,$IP->id,0);
									}
								}		
								//$sRelayNewResp = str_replace('1','0',$sRelays);
								//onoff_rlb_relay($sRelayNewResp,$IP->ip,$sPort,$shhPort);
							}
						}
						//off all valves
						if($sValves != '')
						{
							//$sValveNewResp = str_replace(array('1','2'), '0', $sValves);
							//onoff_rlb_valve($sValveNewResp,$IP->ip,$sPort,$shhPort);  
							
							for($i=0; $i<$valve_count; $i++)	
							{
								if($sValves[$i] != '.')
								{
									if(!in_array($i.'_'.$IP->id,$excludeDevices['V']))
									{
										$sNewResp = replace_return($sValves, 0, $i);
										onoff_rlb_valve($sNewResp,$IP->ip,$sPort,$shhPort);
									}
									
									//START : Change Valve to the default Pool Auto Mode Position.
									$DefaultPosition = $this->home_model->getValveDefaultPosition($i,$IP->id);
									$sNewResp = replace_return($sValves, $DefaultPosition, $i);
									onoff_rlb_valve($sNewResp,$IP->ip,$sPort,$shhPort);
									//END : Change Valve to the default Pool Auto Mode Position.
									
								}
							}
							
							
							
						}
						//off all power center
						if($sPowercenter != '')
						{
							for($i=0; $i<$power_count; $i++)	
							{
								if(!in_array($i.'_'.$IP->id,$excludeDevices['P']))
								{
									$sNewResp = replace_return($sPowercenter, 0, $i);
									onoff_rlb_powercenter($sNewResp,$IP->ip,$sPort,$shhPort);
								}
								//Start : Check if relay is assigned to Heater.
								$HeaterNumber = $this->home_model->chkHeater($i,'12',$IP->id);
								if($HeaterNumber != '')
								{
									$this->heaterDetailsUpdateC($HeaterNumber,$IP->id,0);
								}
							}
							//$sPowerNewResp = str_replace('1','0',$sPowercenter);  
							//onoff_rlb_powercenter($sPowerNewResp,$IP->ip,$sPort,$shhPort); 
						} 
						//off all Pumps
						$aPumpDetails	=	$this->home_model->getAllPumpDetails($IP->id);
						if(!empty($aPumpDetails))
						{
							foreach($aPumpDetails as $aPump)
							{
								if($aPump->status > 0 || $aPump->status == '00')
								{
									if(!in_array($aPump->pump_number.'_'.$IP->id,$excludeDevices['PS']))
									{
										$this->cronMakePumpOnOFF($aPump->pump_number,0,$IP->ip,$sPort,$shhPort,$IP->id); 
									}
								}
							}
						}
						
					}
				}
			}
		}	
    }//END : Function for Manual Mode to auto after specified Time.
	
	public function checkIP()
	{
		$apache_port_number =	'8097'; 
		$sDeviceIP			=	'';
		$sSql   =   "SELECT ip_external FROM rlb_setting WHERE id = '1'";
        $query  =   $this->db->query($sSql);

        if ($query->num_rows() > 0)
        {
            foreach($query->result() as $rowResult)
            {
                $sDeviceIP = $rowResult->ip_external; 
            }
        }
		
	   if($sDeviceIP != '')
	   {
		   $url = 'http://www.lvnvacationhomerentals.com/checkRaspberryIP.php';
		   $fields_string = '';
		   $fields = array(
						'IP' => urlencode($sDeviceIP),
						'PORT' => urlencode($apache_port_number)
				);
			foreach($fields as $key=>$value) 
			{ 
				$fields_string .= $key.'='.$value.'&'; 
			}
			rtrim($fields_string, '&');	
			$url .= '?'.$fields_string;
			
			$windowsUrl = 'http://24.120.134.66/Securedshowing_api/raspberry_api.php';
			$response = file_get_contents($windowsUrl.'?url='.urlencode($url));
			echo $response;
			
			/* $myFile = "/var/www/relayboard/test.txt";
			$fh = fopen($myFile, 'a') or die("Can't open file");
			$stringData = "File updated at: " . $response. "\n";
			fwrite($fh, $stringData);
			fclose($fh);
			die('STOP'); */
			if($response != '')
			{
				$result = json_decode($response);
			
			   /* $url = 'http://www.lvnvacationhomerentals.com/checkRaspberryIP.php';
			   $fields = array(
							'IP' => urlencode($sDeviceIP),
							'PORT' => urlencode($apache_port_number)
					);
				
				$fields_string = '';
				foreach($fields as $key=>$value) 
				{ 
					$fields_string .= $key.'='.$value.'&'; 
				}
				rtrim($fields_string, '&');	
				
				//open connection
				$ch = curl_init();

				//set the url, number of POST vars, POST data
				curl_setopt($ch,CURLOPT_URL, $url);
				curl_setopt($ch,CURLOPT_POST, count($fields));
				curl_setopt($ch,CURLOPT_POSTFIELDS, $fields_string);
				curl_setopt($ch,CURLOPT_RETURNTRANSFER, true);
				
				//execute post
				//$result = json_decode(curl_exec($ch));
				$result = curl_exec($ch);
				//close connection
				curl_close($ch); */
			
				if($result->Status == '0')
				{
					$strIPToChange	=	$result->IP;
					if($strIPToChange != '')
					{
						$sSqlUpdate   =   "UPDATE rlb_setting SET ip_external = '".$strIPToChange."', old_ip='".$sDeviceIP."',is_updated='1' WHERE id = '1'";
						$query  =   $this->db->query($sSqlUpdate);
						
					}
					
					$this->updateSecuredShowingDB($sDeviceIP,$strIPToChange);
				}
			}
	    }
	}
	
	//START : Function for resetting all absolute programs flag.	
	function resetAllAbsolutePrograms()
	{
		$this->load->model('home_model');
		
		//Get All IP Details.
		$aIPDetails = $this->home_model->getBoardIP();
		
		list($sIP,$sPort,$extra) = $this->home_model->getSettings();
		
		foreach($aViewParameter['aIPDetails'] as $IP)
		{
			$shhPort	=	'';
			if(IS_LOCAL == '1')
			{
				//Get SSH port of the RLB board using IP.
				$shhPort = $this->home_model->getSSHPortFromID($IP->id);
			}
			$sResponse		=	array();
			$sRelays        =   '';  
			$sValves		=	'';
			$sPowercenter   =   '';
			$sTime          =   '';
			
			//Get the status response of devices from relay board.
			$sResponse      =   get_rlb_status($IP->ip,$sPort,$shhPort);
		
			//Assign Device Response Seperatly.
			$sValves        =   $sResponse['valves'];
			$sRelays        =   $sResponse['relay'];
			$sPowercenter   =   $sResponse['powercenter'];
			
			//Get all the absolute programs details.
			$arrAbsDetails	=	$this->home_model->getAllAbsoluteProgramDetails($IP->id);
			//$aAllProgram  =   $this->home_model->getAllProgramsDetails();
			
			if(!empty($arrAbsDetails))
			{
				foreach($arrAbsDetails as $arrProgramDetails)
				{
					$iProgramID	=	$arrProgramDetails->program_id;
					$iDeviceNum	=	$arrProgramDetails->device_number;
					//First Check if the program is running.
					$iCheck	=	$this->home_model->chkAbsoluteProgramRunning($iProgramID);
					if($iCheck != '')
					{
						if($iCheck == '1') // IF program is running then first stop that device.
						{
							if($arrProgramDetails->device_type == 'PS')
							{
								$iPumpStatus = 0;
								$this->cronMakePumpOnOFF($arrProgramDetails->device_number,$iPumpStatus,$IP->ip,$sPort,$shhPort,$IP->id);
							}
							else if($arrProgramDetails->device_type == 'R')
							{
								$iRelayStatus = 0;
								$sRelayNewResp = replace_return($sRelays, $iRelayStatus, $iDeviceNum );
								onoff_rlb_relay($sRelayNewResp,$IP->ip,$sPort,$shhPort); // OFF Relay Device;
							}
						}
						
						//Reset the run status.
						//$this->home_model->chkAbsoluteProgramRunning($iProgramID);
					}
					if($arrProgramDetails->device_type == 'PS')
					{
						$this->home_model->updateDeviceStauts($iDeviceNum,'PS','0',$IP->id);
					}
					
					if($iProgramID)
					{
						$data = array('program_absolute_start_time' => '','program_absolute_end_time'=>'','program_absolute_run_time'=>'','program_absolute_start_date'=>'');
						$this->db->where('program_id', $iProgramID);
						$this->db->update('rlb_program', $data);
					}
					
					$this->home_model->updateProgramStatus($iProgramID, 0);
					$this->home_model->updateAbsProgramRun($iProgramID, '0');
				}
			}
		}
	}
	//END : Function for resetting all absolute programs flag.
	
	public function getPumpProgramStatus()
	{
		$iPumpID    =   $_GET['iPumpID'];
		$sIpId    	=   $_GET['sIpId'];
		
		$this->load->model('home_model');
		$aAllActiveProgram	=	$this->home_model->getAllActiveProgramsForPump($iPumpID,$sIpId);
		
		$strMessage		=	'';	
		if(!empty($aAllActiveProgram))
		{
			foreach($aAllActiveProgram as $aActiveProgram)
			{
				if($aActiveProgram->device_type == 'PS')
				{
					$aPumpDetails 	=	$this->home_model->getPumpDetails($aActiveProgram->device_number,$sIpId);

					if(is_array($aPumpDetails) && !empty($aPumpDetails))
					{
							foreach($aPumpDetails as $aResultEdit)
							{ 
									$sPumpNumber  = $aResultEdit->pump_number;
									$sPumpType    = $aResultEdit->pump_type;
									$sPumpSubType = $aResultEdit->pump_sub_type;
									$sPumpSpeed   = $aResultEdit->pump_speed;
							}
					}

					if($strMessage != '')
					{
						$strMessage .= ' <br /><strong>'.$aActiveProgram->program_name.'</strong> Program is Running for <strong>Pump '.$aActiveProgram->device_number.'</strong>';

						if($sPumpType	==	'Emulator' && $sPumpSubType == 'VS')
						{
								$strMessage .= ' With <strong>Speed '.$sPumpSpeed.' </strong>';
						}
						else if($sPumpType	==	'12')
						{
							$strMessage .= ' With <strong> 12V DC Relays</strong>';
						}
						else if($sPumpType	==	'24')
						{
							$strMessage .= ' With <strong> 24V AC Relays</strong>';
						}
						else if($sPumpType	==	'2Speed')
						{
							if($sPumpSubType == '12')
							{
								$strMessage .= ' With <strong> 2 Speed 12V DC Relays</strong>';
							}
							else if($sPumpSubType == '24')
							{
								$strMessage .= ' With <strong> 2 Speed 24V AC Relays</strong>';
							}
						}
						$strMessage .= '!';
					}
					else
					{
						$strMessage .= '<strong>'.$aActiveProgram->program_name.'</strong> Program is Running for <strong>Pump '.$aActiveProgram->device_number.'</strong>';

						if($sPumpType	==	'Emulator' && $sPumpSubType == 'VS')
						{
							$strMessage .= ' With <strong>Speed '.$sPumpSpeed.' </strong>';
						}
						else if($sPumpType	==	'12')
						{
							$strMessage .= ' With <strong> 12V DC Relays</strong>';
						}
						else if($sPumpType	==	'24')
						{
							$strMessage .= ' With <strong> 24V AC Relays</strong>';
						}
						else if($sPumpType	==	'2Speed')
						{
							if($sPumpSubType == '12')
							{
								$strMessage .= ' With <strong> 2 Speed 12V DC Relays</strong>';
							}
							else if($sPumpSubType == '24')
							{
								$strMessage .= ' With <strong> 2 Speed 24V AC Relays</strong>';
							}
						}
						$strMessage .= '!';
					}
				}
			}
		}
		else //Check if Pump is ON manually then take the details and show.
		{
			//First Check if the pump is ON.
			$iCheck = $this->home_model->selectPumpsStatus($iPumpID,$sIpId);
			
			//If Pump is ON.
			if($iCheck)
			{
				$aPumpDetails 	=	$this->home_model->getPumpDetails($iPumpID,$sIpId);

				if(is_array($aPumpDetails) && !empty($aPumpDetails))
				{
					foreach($aPumpDetails as $aResultEdit)
					{ 
						$sPumpNumber  = $aResultEdit->pump_number;
						$sPumpType    = $aResultEdit->pump_type;
						$sPumpSubType = $aResultEdit->pump_sub_type;
						$sPumpSpeed   = $aResultEdit->pump_speed;
					}
				}
				//Start Generating the status message.
				if($strMessage != '')
				{
					$strMessage .= ' <br /><strong>Pump '.$aActiveProgram->device_number.'</strong> is Running';

					if($sPumpType	==	'Emulator' && $sPumpSubType == 'VS')
					{
						$strMessage .= ' With <strong>Speed '.$sPumpSpeed.' </strong>';
					}
					else if($sPumpType	==	'12')
					{
						$strMessage .= ' With <strong> 12V DC Relays</strong>';
					}
					else if($sPumpType	==	'24')
					{
						$strMessage .= ' With <strong> 24V AC Relays</strong>';
					}
					else if($sPumpType	==	'2Speed')
					{
						if($sPumpSubType == '12')
						{
							$strMessage .= ' With <strong> 2 Speed 12V DC Relays</strong>';
						}
						else if($sPumpSubType == '24')
						{
							$strMessage .= ' With <strong> 2 Speed 24V AC Relays</strong>';
						}
					}
					$strMessage .= '!';
				}
				else
				{
					$strMessage .= '<strong>Pump '.$aActiveProgram->device_number.'</strong> is Running';

					if($sPumpType	==	'Emulator' && $sPumpSubType == 'VS')
					{
							$strMessage .= ' With <strong>Speed '.$sPumpSpeed.' </strong>';
					}
					else if($sPumpType	==	'12')
					{
						$strMessage .= ' With <strong> 12V DC Relays</strong>';
					}
					else if($sPumpType	==	'24')
					{
						$strMessage .= ' With <strong> 24V AC Relays</strong>';
					}
					else if($sPumpType	==	'2Speed')
					{
						if($sPumpSubType == '12')
						{
							$strMessage .= ' With <strong> 2 Speed 12V DC Relays</strong>';
						}
						else if($sPumpSubType == '24')
						{
							$strMessage .= ' With <strong> 2 Speed 24V AC Relays</strong>';
						}
					}
					$strMessage .= '!';
				}//End Generating the status message.
			}//If pump is ON.
		}

		$aResult['message']	=	$strMessage;
		echo json_encode($aResult['message']);
	}
	
	public function beforeReboot()
	{
		$this->load->model('home_model');
		//First Take all active programs.
		$aAllActiveProgram	=	$this->home_model->getAllActiveProgramsNew();

		if(!empty($aAllActiveProgram))
		{
			foreach($aAllActiveProgram as $aActive)
			{
				//Update all active programs status to inactive.
				$this->home_model->updateProgramStatus($aActive->program_id, 0);

				$strChkProgram  =   "UPDATE rlb_program SET is_on_after_reboot = '1' WHERE program_id = '".$aActive->program_id."'";
				$query  =   $this->db->query($strChkProgram);
			}
		}
	}
	
	public function cronMakePumpOnOFF($sName,$sStatus,$sIP,$sDevicePort,$sShh,$sIdIP)
	{
		//echo $sName.">>".$sStatus.">>".$sIP.">>".$sDevicePort.">>".$sShh.">>".$sIdIP;
		//die('STOP');
		
		$sResponse      =   get_rlb_status($sIP,$sDevicePort,$sShh);
        
        $sRelays        =   $sResponse['relay'];    // Relay Device Status
        $sPowercenter   =   $sResponse['powercenter']; // Power Center Device Status
		
		$sDevice = 'PS';
		
		if($sDevice == 'PS') // If Device type is Pump
        {
			$aPumpDetails = $this->home_model->getPumpDetails($sName,$sIdIP);
			//Variable Initialization to blank.
			$sPumpNumber  	= '';
			$sPumpType  	= '';
			$sPumpSubType  	= '';
			$sPumpSpeed  	= '';
			$sPumpFlow 		= '';
			$sPumpClosure   = '';
			$sRelayNumber  	= '';
			$sRelayNumber1  = '';
			
			if(is_array($aPumpDetails) && !empty($aPumpDetails))
			{
			  foreach($aPumpDetails as $aResultEdit)
			  { 
				$sPumpNumber  = $aResultEdit->pump_number;
				$sPumpType    = $aResultEdit->pump_type;
				$sPumpSubType = $aResultEdit->pump_sub_type;
				$sPumpSpeed   = $aResultEdit->pump_speed;
				$sPumpFlow    = $aResultEdit->pump_flow;
				$sPumpClosure = $aResultEdit->pump_closure;
				$sRelayNumber = $aResultEdit->relay_number;
				$sRelayNumber1 = $aResultEdit->relay_number_1;
				$sPumpStatus  = $aResultEdit->status;
			  }
			}
			
			if(($sPumpStatus == $sStatus) && $sPumpStatus != 0)
			{
			}
			else
			{
				if($sPumpType != '')
				{
					if($sPumpType == '12' || $sPumpType == '24' || $sPumpType == '2Speed')
					{
						if($sPumpType == '24')
						{
							$sNewResp = replace_return($sRelays, $sStatus, $sRelayNumber );
							onoff_rlb_relay($sNewResp,$sIP,$sDevicePort,$sShh);
							$this->home_model->updateDeviceRunTime($sName,$sDevice,$sStatus,$sIdIP);
							
							$this->home_model->updateDeviceStauts($sName,$sDevice,$sStatus,$sIdIP);
						}
						else if($sPumpType == '12')
						{
							$sNewResp = replace_return($sPowercenter, $sStatus, $sRelayNumber );
							onoff_rlb_powercenter($sNewResp,$sIP,$sDevicePort,$sShh);
							
							$this->home_model->updateDeviceStauts($sName,$sDevice,$sStatus,$sIdIP);
						}
						if($sPumpType == '2Speed')
						{
							if($sPumpSubType == '24')
							{
								if($sStatus == '0')
								{
									$sNewResp = replace_return($sRelays, 0, $sRelayNumber );
									onoff_rlb_relay($sNewResp,$sIP,$sDevicePort,$sShh);
									$this->home_model->updateDeviceRunTime($sName,$sDevice,$sStatus,$sIdIP);
									
									$sNewResp = replace_return($sNewResp, '0', $sRelayNumber1 );
									onoff_rlb_relay($sNewResp,$sIP,$sDevicePort,$sShh);
									$this->home_model->updateDeviceRunTime($sName,$sDevice,$sStatus,$sIdIP);
								}
								if($sStatus == '1')
								{
									$sNewResp = replace_return($sRelays, $sStatus, $sRelayNumber );
									onoff_rlb_relay($sNewResp,$sIP,$sDevicePort,$sShh);
									$this->home_model->updateDeviceRunTime($sName,$sDevice,$sStatus,$sIdIP);
									
									$sNewResp = replace_return($sNewResp, '0', $sRelayNumber1 );
									onoff_rlb_relay($sNewResp,$sIP,$sDevicePort,$sShh);
									$this->home_model->updateDeviceRunTime($sName,$sDevice,$sStatus,$sIdIP);
								}
								if($sStatus == '2')
								{	
									$sStatus = '1';
									$sNewResp = replace_return($sRelays, $sStatus, $sRelayNumber1 );
									onoff_rlb_relay($sNewResp,$sIP,$sDevicePort,$sShh);
									$this->home_model->updateDeviceRunTime($sName,$sDevice,$sStatus,$sIdIP);
									
									$sNewResp = replace_return($sNewResp, '0', $sRelayNumber );
									onoff_rlb_relay($sNewResp,$sIP,$sDevicePort,$sShh);
									$this->home_model->updateDeviceRunTime($sName,$sDevice,$sStatus,$sIdIP);
								}
								
								$this->home_model->updateDeviceStauts($sName,$sDevice,$sStatus,$sIdIP);
								
							}
							else if($sPumpSubType == '12')
							{
								
								if($sStatus == '0')
								{
									$sNewResp = replace_return($sPowercenter, '0', $sRelayNumber );
									onoff_rlb_powercenter($sNewResp,$sIP,$sDevicePort,$sShh);
									
									$sNewResp = replace_return($sNewResp, '0', $sRelayNumber1 );
									onoff_rlb_powercenter($sNewResp,$sIP,$sDevicePort,$sShh);
								}
								if($sStatus == '1')
								{
									$sNewResp = replace_return($sPowercenter, $sStatus, $sRelayNumber );
									onoff_rlb_powercenter($sNewResp,$sIP,$sDevicePort,$sShh);
									
									$sNewResp = replace_return($sNewResp, '0', $sRelayNumber1 );
									onoff_rlb_powercenter($sNewResp,$sIP,$sDevicePort,$sShh);
								}
								if($sStatus == '2')
								{	
									$sStatus = '1';
									$sNewResp = replace_return($sPowercenter, $sStatus, $sRelayNumber1 );
									onoff_rlb_powercenter($sNewResp,$sIP,$sDevicePort,$sShh);
									
									$sNewResp = replace_return($sNewResp, '0', $sRelayNumber );
									onoff_rlb_powercenter($sNewResp,$sIP,$sDevicePort,$sShh);
									
									$sStatus = '2';
								}
								
								$this->home_model->updateDeviceStauts($sName,$sDevice,$sStatus,$sIdIP);
								
							}
								
							
						}
					}
					else
					{
						if(preg_match('/Emulator/',$sPumpType))
						{
							$sNewResp = '';

							if($sStatus == '0')
								$sNewResp =  $sName.' '.$sStatus;
							else if($sStatus == '1')
							{
								/* $sType          =   '';
								if($sPumpSubType == 'VS')
									$sType  =   '2'.' '.$sPumpSpeed;
								elseif ($sPumpSubType == 'VF')
									$sType  =   '3'.' '.$sPumpFlow; */
									
								if($sPumpSubType == 'VS')
									$sType  =   $sPumpSpeed;
								elseif ($sPumpSubType == 'VF')
									$sType  =   $sPumpFlow;	

								$sNewResp =  $sName.' '.$sType;    
							}
							
							onoff_rlb_pump($sNewResp,$sIP,$sDevicePort,$sShh);
							
							if($sPumpType == 'Emulator12')
							{
								$sNewResp12 = replace_return($sPowercenter, $sStatus, $sRelayNumber );
								onoff_rlb_powercenter($sNewResp12,$sIP,$sDevicePort,$sShh);
							}
							if($sPumpType == 'Emulator24')
							{
								$sNewResp24 = replace_return($sRelays, $sStatus, $sRelayNumber );
								onoff_rlb_relay($sNewResp24,$sIP,$sDevicePort,$sShh);
								$this->home_model->updateDeviceRunTime($sRelayNumber,'R',$sStatus,$sIdIP);
							}
							$this->home_model->updateDeviceStauts($sName,$sDevice,$sStatus,$sIdIP);
							
						}
						else if(preg_match('/Intellicom/',$sPumpType))
						{
							$sNewResp = '';

							if($sStatus == '0')
								$sNewResp =  $sName.' '.$sStatus;
							else if($sStatus == '1')
							{
								//$sType  =   '2'.' '.$sPumpSpeed;
								$sType    =   $sPumpSpeed;
								$sNewResp =  $sName.' '.$sType;    
							}
							
							onoff_rlb_pump($sNewResp,$sIP,$sDevicePort,$sShh);
							
							if($sPumpType == 'Intellicom12')
							{
								$sNewResp12 = replace_return($sPowercenter, $sStatus, $sRelayNumber );
								onoff_rlb_powercenter($sNewResp12,$sIP,$sDevicePort,$sShh);
							}
							if($sPumpType == 'Intellicom24')
							{
								$sNewResp24 = replace_return($sRelays, $sStatus, $sRelayNumber );
								onoff_rlb_relay($sNewResp24,$sIP,$sDevicePort,$sShh);
								$this->home_model->updateDeviceRunTime($sRelayNumber,'R',$sStatus,$sIdIP);
							}
							
							$this->home_model->updateDeviceStauts($sName,$sDevice,$sStatus,$sIdIP);
						}
					}
					
					//Update details of program to which pump is related.
					if($sStatus == 0)
					{
						$aProgramDetails	=	$this->home_model->getProgramDetailsForDevice($sName,$sDevice,$sIdIP);
						
						foreach($aProgramDetails as $Program)
						{
							if($Program->program_active == '1')
							{
								$this->home_model->updateProgramStatus($Program->program_id, 0);
								if($Program->program_absolute == '1')
								{
									$aAbsoluteDetails   = array(
									'absolute_s'  => $Program->program_absolute_start_time,             'absolute_e'  => $Program->program_absolute_end_time,
									'absolute_t'  => $Program->program_absolute_total_time,
									'absolute_ar' => $Program->program_absolute_run_time,
									'absolute_sd' => $Program->program_absolute_start_date,
									'absolute_st' => $Program->program_absolute_run);
																
									$this->home_model->updateAlreadyRunTime($Program->program_id, $aAbsoluteDetails);
									
								}
							}
						}
					}
					//$this->home_model->updateDeviceStauts($sName,$sDevice,$sStatus);
				}
			}
           
        }
		
	}
	
	public function rebootSystem()
	{
		$this->load->model('home_model');
		//Get All IP Details.
		$aViewParameter['aIPDetails'] = $this->home_model->getBoardIP();
		//Get saved IP and PORT 
		list($sIP,$sPort,$extra) = $this->home_model->getSettings();
		$arrDetails = array();
		foreach($aViewParameter['aIPDetails'] as $IP)
		{
			$shhPort	=	'';
			if(IS_LOCAL == '1')
			{
				//Get SSH port of the RLB board using IP.
				$shhPort = $this->home_model->getSSHPortFromID($IP->id);
			}
			$sResponse		=	array();
			$sValves        =   ''; 
			$sRelays        =   '';  
			$sPowercenter   =   ''; 
			$sTime          =   '';
			$sPump			=	'';	
			$sTemprature	=	'';
			
			//Get the status response of devices from relay board.
			$sResponse      =   get_rlb_status($IP->ip,$sPort,$shhPort);
		
			$arrDetails['sResponse']	= $sResponse['response'];
			
			$sValves        =   $sResponse['valves']; // Valve Device Status
			$arrDetails['sValves']	= $sValves;
			
			$sRelays        =   $sResponse['relay'];  // Relay Device Status
			$arrDetails['sRelays']	= $sRelays;
			
			$sPowercenter   =   $sResponse['powercenter']; // Power Center Device Status
			$arrDetails['sPowercenter']	= $sPowercenter;
			
			//Pump device Status
			$sPump          =   json_decode($this->home_model->getOnPumps($IP->id));
			$arrDetails['sPump'] = $sPump;
			
			//INSERT Details in History Table.
			$this->home_model->insertHistory($arrDetails,$IP->id);
		}

		//Get All Active Program Before Reboot.
		$aAllActiveProgram	=	$this->home_model->getAllActiveProgramsNew();

		if(!empty($aAllActiveProgram))
		{
			foreach($aAllActiveProgram as $aActive)
			{
				//Update all active programs status to inactive.
				$this->home_model->updateProgramStatus($aActive->program_id, 0);

				$strChkProgram  =   "UPDATE rlb_program SET is_on_after_reboot = '1' WHERE program_id = '".$aActive->program_id."'";
				$query  =   $this->db->query($strChkProgram);
			}
		}	
		
		exec("sudo /sbin/reboot");
	}
	
	public function startDeviceAfterReboot()
	{
		$this->load->model('home_model');
		//Get All IP Details.
		$aViewParameter['aIPDetails'] = $this->home_model->getBoardIP();
		//Get saved IP and PORT 
		list($sIP,$sPort,$extra) = $this->home_model->getSettings();
		$arrDetails = array();
		foreach($aViewParameter['aIPDetails'] as $IP)
		{
			$arrDetails = unserialize($this->home_model->getHistoryDetails($IP->id));
			$shhPort	= '';
			if(IS_LOCAL == '1')
			{
				//Get SSH port of the RLB board using IP.
				$shhPort = $this->home_model->getSSHPortFromID($IP->id);
			}
			$sResponse		=	array();
			$sValves        =   ''; 
			$sRelays        =   '';  
			$sPowercenter   =   ''; 
			$sTime          =   '';
			$sPump			=	'';	
			$sTemprature	=	'';
			
			//Get the status response of devices from relay board.
			$sResponse      =   get_rlb_status($IP->ip,$sPort,$shhPort);
		
			$sValves        =   $sResponse['valves']; // Valve Device Status
			$sRelays        =   $sResponse['relay'];  // Relay Device Status
			$sPowercenter   =   $sResponse['powercenter']; // Power Center Device Status
			
			//Relays
			onoff_rlb_relay($arrDetails['sRelays'],$IP->ip,$sPort,$shhPort);
			//PowerCenter
			onoff_rlb_powercenter($arrDetails['sPowercenter'],$IP->ip,$sPort,$shhPort);
			//Valves
			onoff_rlb_valve($arrDetails['sValves'],$IP->ip,$sPort,$shhPort);
            //Pumps
			foreach($arrDetails['sPump'] as $pumpNumber)
			{
				$this->cronMakePumpOnOFF($pumpNumber,'1',$IP->ip,$sPort,$shhPort,$IP->id);
			}
		}
		
	}
	
	
	
	/* function testShell()
	{
		$myFile = "/var/www/relayboard/testshell.txt";
		$fh = fopen($myFile, 'a') or die("Can't open file");
		$stringData = "File updated at: " . time(). "\n";
		fwrite($fh, $stringData);
		fclose($fh);
	} */
	
	/* function tp()
	{
		$this->template->build('welcome_message');
	} */
	
	function command()
	{
		echo shell_exec('rlb s');
	}
	
	function testing()
	{
		/* $aData['ip_address'] = '70.189.208.35';
		$aData['port_no']	 = '13330';
		$aData['data']		 = 's';
		
		$s	=	send_command_udp($aData);
		//$s	=	response_input_switch('192.168.0.103','13330');
		echo 'Response : '.$s; */
		/*echo '<br>---------------------------------<br>';
		 $aData1['ip_address'] = '192.168.0.115';
		$aData1['port_no']	 = '13330';
		$aData1['data']		 = 's';
		
		//echo send_command_udp($aData1); 
		$s	=	response_input_switch('192.168.0.115','13330');
		echo 'Response : '.$s; */
		
		
		$connection = ssh2_connect('70.189.208.35', 22);
		ssh2_auth_password($connection, 'pi', 'lucky777');

		$stream = ssh2_exec($connection, 'rlb s');
		
		stream_set_blocking($stream, true);
		
		echo "Output: " . stream_get_contents($stream);
	
	}
	
	public function customProgramRun()
	{
		#echo date('Y-m-d H:i:s').'<br>';
		$this->load->model('custom_model');
		$this->load->model('home_model');
		
		//Get Current Active Mode
		$iMode	=   $this->home_model->getActiveMode();
		
		//Get All On Program and Details.
		$aAllOnPrograms = $this->home_model->getOnCustomProgram();
		
		if(!empty($aAllOnPrograms))
		{
			//Get All IP Details.
			$aIPDetails = $this->home_model->getBoardIP();
			
			list($sIP,$sPort,$extra) = $this->home_model->getSettings();
			
			foreach($aIPDetails as $IP)
			{
				${'shhPort'.$IP->id}	=	'';
				if(IS_LOCAL == '1')
				{
					//Get SSH port of the RLB board using IP.
					${'shhPort'.$IP->id} = $this->home_model->getSSHPortFromID($IP->id);
				}
				$sResponse		=	array();
				$sValves        =   ''; 
				$sRelays        =   '';  
				$sPump			=	'';	
				
				//Get the status response of devices from relay board.
				$sResponse      =   get_rlb_status($IP->ip,$sPort,$shhPort);
			
				$sValves        =   $sResponse['valves']; // Valve Device Status
				$sRelays        =   $sResponse['relay'];  // Relay Device Status
				$sPowerCenter   =   $sResponse['powercenter']; // Power Center Device Status
				
				${'sRelays'.$IP->id} 		=	$sRelays;
				${'sValves'.$IP->id} 		=	$sValves;
				${'sPowerCenter'.$IP->id} 	=	$sPowerCenter;  
				
				${'sPump'.$IP->id}	=	array($sResponse['pump_seq_0_st'],$sResponse['pump_seq_1_st'],$sResponse['pump_seq_2_st']);
				${'board'.$IP->id} 	=	$IP->ip;
				
				$arrExtraDetails[$IP->id] = array('sValves'=>${'sValves'.$IP->id},'board'=>${'board'.$IP->id},'shhPort'=>${'shhPort'.$IP->id});
			}
			
			foreach($aAllOnPrograms as $customProgram)
			{
				$unique_id	=	$customProgram->unique_id;
				$programID	=	$customProgram->id;
				
				$arrSequnceDevice	=	array();
				//First Make the Program Running Status to 1.
				$this->home_model->updateRunningStatusCustomProgram($programID,'1');
				
				$aProgramDetails =	json_decode($customProgram->program_details);
				
				$maxRunTime		 =	$aProgramDetails->g_custom_max_time;
				$programStart	 =	$customProgram->program_start;	
				$programEnd		 =	$customProgram->program_end;

				$afterProgram	 =	$customProgram->afterProgram;
				$previousState	 = 	unserialize($customProgram->previousState);		
				
				if(isset($aProgramDetails->g_rlb_pump_list) && $aProgramDetails->g_rlb_pump_list != '')
				{
					//Pump Device Details.
					$pumpDevice		=	explode(",",$aProgramDetails->g_rlb_pump_list);
					$pumpSequence	=	explode(",",$aProgramDetails->g_pump_sq);
					$pumpTime		=	explode(",",$aProgramDetails->g_pump_time);
				}
				
				if(isset($aProgramDetails->g_rlb_valve_list) && $aProgramDetails->g_rlb_valve_list != '')
				{
					//Valve Device Details
					$valveDevice	=	explode(",",$aProgramDetails->g_rlb_valve_list);	
					$valveSequence	=	explode(",",$aProgramDetails->g_valve_sq);	
					$valveTime		=	explode(",",$aProgramDetails->g_valve_time);
				}

				if(isset($aProgramDetails->g_rlb_relay_list) && $aProgramDetails->g_rlb_relay_list != '')
				{
					//Relay Device Details
					$relayDevice	=	explode(",",$aProgramDetails->g_rlb_relay_list);	
					$relaySequence	=	explode(",",$aProgramDetails->g_relay_sq);	
					$relayTime		=	explode(",",$aProgramDetails->g_relay_time);				
				}
				
				if(isset($aProgramDetails->g_rlb_powercenter_list) && $aProgramDetails->g_rlb_powercenter_list != '')
				{
					//Relay Device Details
					$powerCenterDevice	=	explode(",",$aProgramDetails->g_rlb_powercenter_list);	
					$powerCenterSequence	=	explode(",",$aProgramDetails->g_powercenter_sq);	
					$powerCenterTime		=	explode(",",$aProgramDetails->g_powercenter_time);				
				}

				$arrPumpKeepOn		   = array();					
				
				if(!empty($pumpSequence))
				{
					foreach($pumpSequence as $seq => $key)
					{
						if($key != '')
						{
							if(!array_key_exists($key,$arrSequnceDevice))
							$arrSequnceDevice[$key] = array();
							
							array_push($arrSequnceDevice[$key],$pumpDevice[$seq].'|||'.$pumpTime[$seq].'|||PS');
							
						}
						
						$arrTemp 			=	explode("_",$pumpDevice[$seq]);
						$ipIDTemp			=	$arrTemp[0];
						$deviceNumberTemp	=	$arrTemp[1];
						
						//START : Check if its running in program.
						$chk = $this->home_model->checkAlreadyRunning($deviceNumberTemp,$ipIDTemp,'PS');
						
						if($chk == '1')
						{
							$arrPumpKeepOn[] = $pumpDevice[$seq];
						}
						
						//$arrSequnceDevice[$seq] = $pumpDevice[$key].'|||'.$pumpTime[$key].'|||PS';
					}
				}
				
				//$valveSequence	=	array_flip($valveSequence);
				
				$arrAfterProgramDevice = array();
				$arrValveKeepOn		   = array();
				//sort($valveSequence);
				
				$arrProgramValve = array();
				
				if(!empty($valveSequence))
				{
					$k = 1;
					foreach($valveSequence as $seq => $key)
					{
						if($key != '')
						{
							if(!array_key_exists($key,$arrSequnceDevice))
							$arrSequnceDevice[$key] = array();
						
							array_push($arrSequnceDevice[$key],$valveDevice[$seq].'|||'.$valveTime[$seq].'|||V');
							
							array_push($arrProgramValve,$valveDevice[$seq]);
							
							//Valve to run after program end.
							$arr	=	explode('_',$valveDevice[$seq]);
							$strPosition = '';
							if($arr[1] == 1)
							{
								$strPosition = 2;
							}
							else if($arr[1] == 2)
							{
								$strPosition = 1;
							}
							
							$arrTemp 			=	explode("_",$valveDevice[$seq]);
							$ipIDTemp			=	$arrTemp[0];
							$sStatusTemp		=	$arrTemp[1];
							$deviceNumberTemp	=	$arrTemp[2];
							
							$existingStatus 	=	${'sValves'.$ipIDTemp}[$deviceNumberTemp];
							
							//$tempDevice			=	$ipIDTemp.'_'.$existingStatus.'_'.$deviceNumberTemp;
							
							$valveAfterProgram = $arr[0].'_'.$strPosition.'_'.$arr[2];
							
							//if($existingStatus != $sStatusTemp)
							if(!in_array($valveDevice[$seq],$previousState))	
							{
								$lastRun = $this->home_model->getDeviceLastRun($deviceNumberTemp,'V',$ipIDTemp);
								
								if($lastRun != $sStatusTemp)
								{
									$arrAfterProgramDevice[$key] = $valveAfterProgram.'|||'.$valveTime[$seq].'|||V';
								
									$k++;
								}
							}
							/* else
							{
								$arrValveKeepOn[] = $ipIDTemp.'_'.$deviceNumberTemp;
							} */
							
						}
						//array_push($arrAfterProgramDevice,$valveAfterProgram.'|||'.$valveTime[$seq].'|||V');
						
					}
				}
				
				if(!empty($relaySequence))
				{
					foreach($relaySequence as $seq => $key)
					{
						if($key != '')
						{
							if(!array_key_exists($key,$arrSequnceDevice))
							$arrSequnceDevice[$key] = array();
							
							array_push($arrSequnceDevice[$key],$relayDevice[$seq].'|||'.$relayTime[$seq].'|||R');
						}
					}
				}
				
				if(!empty($powerCenterSequence))
				{
					foreach($powerCenterSequence as $seq => $key)
					{
						if($key != '')
						{
							if(!array_key_exists($key,$arrSequnceDevice))
							$arrSequnceDevice[$key] = array();
							
							array_push($arrSequnceDevice[$key],$powerCenterDevice[$seq].'|||'.$powerCenterTime[$seq].'|||P');
						}
					}
				}
				ksort($arrSequnceDevice);
				ksort($arrAfterProgramDevice);
				
				#echo '<pre>Valve:';print_r($arrSequnceDevice);echo '</pre>';
				#echo '<pre>KeepON:';print_r($arrValveKeepOn);echo '</pre>';
				//die('STOP');
				
				//Check Program End Time, if it is passed make that program OFF.
				if((strtotime(date("Y-m-d H:i:s")) > strtotime($programEnd)) && $afterProgram  == '0')
				{
					$this->home_model->updateRunningStatusCustomProgram($programID,'0');
					$this->custom_model->offCustomProgram($programID,'0');
					
					foreach($arrProgramValve as $valveDevice)
					{
						$arrTemp 			=	explode("_",$valveDevice);
						$ipIDTemp			=	$arrTemp[0];
						$sStatusTemp		=	$arrTemp[1];
						$deviceNumberTemp	=	$arrTemp[2];
						
						#START : GET Default Pool auto Position.
						$defaultPosition 	=	$this->home_model->getValveDefaultPosition($deviceNumberTemp,$ipIDTemp);
						
						$sNewResp = replace_return(${'sValves'.$ipIDTemp}, $defaultPosition, $deviceNumberTemp);
						${'sValves'.$ipIDTemp} = $sNewResp;
						onoff_rlb_valve($sNewResp,${'board'.$ipIDTemp},$sPort,${'shhPort'.$ipIDTemp});
						#END : GET Default Pool auto Position.
						
						//START : INSERT THE VALVE DETAILS TO RUN VALVE FOR GIVEN TIME IN POOL MODE AUTO. IF TIME IS NOT SPECIFIED THEN IT WILL RUN FOR 1 MIN DEFAULT.

						$runTime = $this->home_model->getValveDefaultPositionTime($deviceNumberTemp,$ipIDTemp);
						if($runTime == 0)
						{
							$runTime = 1;
						}
						if($runTime == '')
						{
							$runTime = 1;
						}	
						
						$arrValveDefaultRunDetails	=	array('program_id'=>$programID,'valve'=>$deviceNumberTemp,'ip_id'=>$ipIDTemp,'runTime'=>$runTime);
						$this->home_model->insertValveDefaultRunDetails($arrValveDefaultRunDetails);
						
						//END : INSERT THE VALVE DETAILS TO RUN VALVE FOR GIVEN TIME IN POOL MODE AUTO. IF TIME IS NOT SPECIFIED THEN IT WILL RUN FOR 1 MIN DEFAULT.
						
					}
					$this->home_model->removePreviousPositions($programID);
					continue;
					/* if(!empty($arrAfterProgramDevice))
					{
						$this->home_model->updateAfterProgram($programID,'1');
						$this->customProgramRunAfter($programID,$arrAfterProgramDevice,$unique_id,$arrExtraDetails);
					}
					else
					{
						$this->custom_model->offCustomProgram($programID,'0');
					} */
					
				}
				
				//Check if Progrma is running, if running then get which device is running for Programs.
				$currentDevice = $this->custom_model->getCustomProgrmaCurrentDevice($programID);
				
				
				/* else if($afterProgram == '1')
				{
					$this->customProgramRunAfter($programID,$arrAfterProgramDevice,$unique_id,$arrExtraDetails);
					continue;
				} */
				if($iMode != 1)
				{
					$this->home_model->updateRunningStatusCustomProgram($programID,'0');
					$this->custom_model->offCustomProgram($programID,'0');
					$this->home_model->updateAfterProgram($programID,'0');
					
					//Insert Entry in the Log Table for future Reference.
					$this->custom_model->saveCustomEntryInLog($programID,$deviceType);
					
					//Delete Entry From the current details Table.
					$this->custom_model->deleteCustomEntryFromCurrent($programID);
					
					foreach($currentDevice as $deviceDetails)
					{
						//If Device is Running Then Check if its Time is Complete.
						$currentSeq		=	$deviceDetails->current_sequence;
						$deviceType 	=   $deviceDetails->device_type;
						$ipID			=	$deviceDetails->ip_id;
						$sStatus		=	0;
						$deviceNumber	=	$deviceDetails->device_number;
						
						if($deviceType == 'V')
						{
							$sNewResp = replace_return(${'sValves'.$ipID}, $sStatus, $deviceNumber);
							${'sValves'.$ipID} = $sNewResp;
							onoff_rlb_valve($sNewResp,${'board'.$ipID},$sPort,${'shhPort'.$ipID});
						}
						else if($deviceType == 'PS')
						{	
							$this->cronMakePumpOnOFF($deviceNumber,$sStatus,${'board'.$ipID},$sPort,${'shhPort'.$ipID},$ipID);
						}
						else if($deviceType	== 'R')
						{
							$sNewResp = replace_return(${'sRelays'.$ipID}, $sStatus, $deviceNumber);
							${'sRelays'.$ipID} = $sNewResp;
							onoff_rlb_relay($sNewResp,${'board'.$ipID},$sPort,${'shhPort'.$ipID});
							//Start : Check if relay is assigned to Heater.
							$HeaterNumber = $this->home_model->chkHeater($deviceNumber,'24',$ipID);
							if($HeaterNumber != '')
							{
								$this->heaterDetailsUpdatePump($HeaterNumber,$ipID,0);
							}
						}
						else if($deviceType	== 'P')
						{
							$sNewResp = replace_return(${'sPowerCenter'.$ipID}, $sStatus, $deviceNumber);
							${'sPowerCenter'.$ipID} = $sNewResp;
							onoff_rlb_powercenter($sNewResp,${'board'.$ipID},$sPort,${'shhPort'.$ipID});
							//Start : Check if relay is assigned to Heater.
							$HeaterNumber = $this->home_model->chkHeater($deviceNumber,'12',$ipID);
							if($HeaterNumber != '')
							{
								$this->heaterDetailsUpdatePump($HeaterNumber,$ipID,0);
							}
						}
					}
					
					$currentDeviceAfter = $this->custom_model->getCustomProgrmaAfterDevice($programID);
					
					if($currentDeviceAfter != '')
					{
						foreach($currentDeviceAfter as $deviceDetails)
						{
							$currentSeq		=	$deviceDetails->current_sequence;
							$deviceType 	=   $deviceDetails->device_type;
							$ipID			=	$deviceDetails->ip_id;
							$sStatus		=	0;
							$deviceNumber	=	$deviceDetails->device_number;
							
							$sNewResp = replace_return(${'sValves'.$ipID}, $sStatus, $deviceNumber);
							${'sValves'.$ipID} = $sNewResp;
							onoff_rlb_valve($sNewResp,${'board'.$ipID},$sPort,${'shhPort'.$ipID});
							
							
							//Insert Entry in the Log Table for future Reference.
							$this->custom_model->saveCustomAfterEntryInLog($programID,$deviceType);
							
							//Delete Entry From the current details Table.
							$this->custom_model->deleteCustomEntryFromAfter($programID,$deviceType,$deviceNumber);
						}
					}
					
				}
				else
				{
					if(!empty($arrSequnceDevice))
					{
						if($currentDevice == '')
						{
							foreach($arrSequnceDevice[1] as $devices)
							{
								//$aCurrentDevice	=	explode('|||',$arrSequnceDevice[1]);
								$aCurrentDevice	=	explode('|||',$devices);
								//START: First make valve device ON in the sequence.
								$sStatus		=	'1';
								$sRunTime		=	$aCurrentDevice[1];
								$deviceType 	=   $aCurrentDevice[2];
								$aDevice		=	explode("_",$aCurrentDevice[0]);
								if($deviceType == 'V')
								{
									$ipID			=	$aDevice[0];
									$sStatus		=	$aDevice[1];
									$deviceNumber	=	$aDevice[2];
								}
								else if($deviceType == 'PS' || $deviceType == 'R' || $deviceType == 'P')
								{
									$ipID			=	$aDevice[0];
									$deviceNumber	=	$aDevice[1];
								}
								
								if($deviceType	==	'PS')
								{
									$this->cronMakePumpOnOFF($deviceNumber,$sStatus,${'board'.$ipID},$sPort,${'shhPort'.$ipID},$ipID);
											
									$strDevice		=	'Pump '.$deviceNumber;
								}
								else if($deviceType	== 'V')
								{
									$existingStatus 	=	${'sValves'.$ipID}[$deviceNumber];
									if($sStatus != $existingStatus)
									{
										$sNewResp = replace_return(${'sValves'.$ipID}, $sStatus, $deviceNumber);
										${'sValves'.$ipID} = $sNewResp;
										onoff_rlb_valve($sNewResp,${'board'.$ipID},$sPort,${'shhPort'.$ipID});
									}
									
									$strDevice	=	'Valve '.$deviceNumber;	
								}
								else if($deviceType	== 'R')
								{
									$existingStatus 	=	${'sRelays'.$ipID}[$deviceNumber];
									if($sStatus != $existingStatus)
									{
										$sNewResp = replace_return(${'sRelays'.$ipID}, $sStatus, $deviceNumber);
										${'sRelays'.$ipID} = $sNewResp;
										onoff_rlb_relay($sNewResp,${'board'.$ipID},$sPort,${'shhPort'.$ipID});
									}
									
									//START : Check if heater is assigned to that relay.
									$heaterNum = $this->home_model->chkHeater($deviceNumber,'24',$ipID);
									
									if($heaterNum != '')
									{
										$aHeaterDetails  =   $this->home_model->getHeaterDeviceDetails($heaterNum,$ipID);
										if(!empty($aHeaterDetails))
										{
											foreach($aHeaterDetails as $aHeater)
											$sHeaterDetails  =   unserialize($aHeater->light_relay_number);
											
											$PumpNumber   	=   $sHeaterDetails['Pump'];
											$maxRun   		=   $sHeaterDetails['maxRun'];
											
											$sHeaterStart 	=   date("Y-m-d H:i:s", time());
											$arrStart		=	explode(" ",$sHeaterStart);
											$aStartDate    	=   explode("-",$arrStart[0]);
											$aStartTime    	=   explode(":",$arrStart[1]);
											
											$sProgramAbsEnd   =   mktime($aStartTime[0],($aStartTime[1]+$maxRun),$aStartTime[2],$aStartDate[1],$aStartDate[2],$aStartDate[0]);
											$sHeaterEnd     =   date("Y-m-d H:i:s", $sProgramAbsEnd);
											
											$this->home_model->insertHeaterRunDetails($heaterNum,$ipID,$sHeaterStart,$sHeaterEnd);
											
											
										}
										if($PumpNumber != '')
										{
											$aPumpDetails =	$this->home_model->getPumpDetails($PumpNumber,$ipID);
											if(!empty($aPumpDetails))
											{
												foreach($aPumpDetails as $sPump)
												{
													
													
													$this->cronMakePumpOnOFF($sPump->pump_number,'1',${'board'.$ipID},$sPort,${'shhPort'.$ipID},$ipID);
												}
											}
										}
									}
									//END : Check if heater is assigned to that relay.
									
									$strDevice	=	'Relay '.$deviceNumber;	
								}
								else if($deviceType	== 'P')
								{
									$existingStatus 	=	${'sPowerCenter'.$ipID}[$deviceNumber];
									if($sStatus != $existingStatus)
									{
										$sNewResp = replace_return(${'sPowerCenter'.$ipID}, $sStatus, $deviceNumber);
										${'sPowerCenter'.$ipID} = $sNewResp;
										onoff_rlb_powercenter($sNewResp,${'board'.$ipID},$sPort,${'shhPort'.$ipID});
									}
									
									//START : Check if heater is assigned to that relay.
									$heaterNum = $this->home_model->chkHeater($deviceNumber,'12',$ipID);
									
									if($heaterNum != '')
									{
										
										$aHeaterDetails  =   $this->home_model->getHeaterDeviceDetails($heaterNum,$ipID);
										if(!empty($aHeaterDetails))
										{
											foreach($aHeaterDetails as $aHeater)
											{
												$sHeaterDetails  =   unserialize($aHeater->light_relay_number);
											}
											
											$PumpNumber   	=   $sHeaterDetails['Pump'];
											$maxRun   		=   $sHeaterDetails['maxRun'];
											
											$sHeaterStart 	=   date("Y-m-d H:i:s", time());
											$arrStart		=	explode(" ",$sHeaterStart);
											$aStartDate    	=   explode("-",$arrStart[0]);
											$aStartTime    	=   explode(":",$arrStart[1]);
											
											$sProgramAbsEnd   =   mktime($aStartTime[0],($aStartTime[1]+$maxRun),$aStartTime[2],$aStartDate[1],$aStartDate[2],$aStartDate[0]);
											$sHeaterEnd     =   date("Y-m-d H:i:s", $sProgramAbsEnd);
											
											$this->home_model->insertHeaterRunDetails($heaterNum,$ipID,$sHeaterStart,$sHeaterEnd);
										}
										if($PumpNumber != '')
										{
											$aPumpDetails =	$this->home_model->getPumpDetails($PumpNumber,$ipID);
											if(!empty($aPumpDetails))
											{
												foreach($aPumpDetails as $sPump)
												{
													$this->cronMakePumpOnOFF($sPump->pump_number,'1',${'board'.$ipID},$sPort,${'shhPort'.$ipID},$ipID);
												}
											}
										}
									}
									//END : Check if heater is assigned to that relay.  
									
									$strDevice	=	'Power Center '.$deviceNumber;
								}
								
								$arrDetails		=	array('program_id'=>$programID,
														  'current_on_device'=>$strDevice,
														  'device_type'=>$deviceType,
														  'device_number'=>$deviceNumber,
														  'current_on_time'=>$sRunTime,
														  'current_sequence'=>1,
														  'ip_id'=>$ipID,
														  'unique_id'=>$unique_id);
								
								$this->custom_model->saveCustomCurrentRunningDevice($arrDetails);
							}
						}
						else if($currentDevice != '')
						{
							#echo '<pre>Current:';print_r($currentDevice);echo '</pre>';
							
							$lastElement = end($currentDevice);
							
							#echo '<pre>Last:';print_r($lastElement);echo '</pre>';

							foreach($currentDevice as $deviceDetails)
							{
								//If Device is Running Then Check if its Time is Complete.
								$OffTime			=	$deviceDetails->current_off_time;
								$currentServerTime	=	date('Y-m-d H:i:s');
								
								if($currentServerTime >= $OffTime)
								{
									
									$currentSeq		=	$deviceDetails->current_sequence;
									$deviceType 	=   $deviceDetails->device_type;
									$ipID			=	$deviceDetails->ip_id;
									$sStatus		=	0;
									$deviceNumber	=	$deviceDetails->device_number;
									
									#echo '<pre>OFF:';print_r($deviceNumber.'>>'.$deviceType);echo '</pre>';
									
									if($deviceType == 'V')
									{
										if(!in_array($ipID.'_'.$deviceNumber,$arrValveKeepOn))
										{
											#echo '<pre>ValveOFF:';print_r($deviceNumber.'>>'.$deviceType);echo '</pre>';
											$sNewResp = replace_return(${'sValves'.$ipID}, $sStatus, $deviceNumber);
											${'sValves'.$ipID} = $sNewResp;
											onoff_rlb_valve($sNewResp,${'board'.$ipID},$sPort,${'shhPort'.$ipID});
										}
									}
									else if($deviceType == 'PS')
									{
										if(!in_array($ipID.'_'.$deviceNumber,$arrPumpKeepOn))
										{
											$this->cronMakePumpOnOFF($deviceNumber,$sStatus,${'board'.$ipID},$sPort,${'shhPort'.$ipID},$ipID);
										}
									}
									else if($deviceType	== 'R')
									{
										$sNewResp = replace_return(${'sRelays'.$ipID}, $sStatus, $deviceNumber);
										${'sRelays'.$ipID} = $sNewResp;
										onoff_rlb_relay($sNewResp,${'board'.$ipID},$sPort,${'shhPort'.$ipID});
										
										//START : Check if heater is assigned to that relay.
										$heaterNum = $this->home_model->chkHeater($deviceNumber,'24',$ipID);
										
										if($heaterNum != '')
										{
											$this->home_model->updateHeaterRunDetails($heaterNum,$ipID);
											$aHeaterDetails  =   $this->home_model->getHeaterDeviceDetails($heaterNum,$ipID);
											if(!empty($aHeaterDetails))
											{
												foreach($aHeaterDetails as $aHeater)
												$sHeaterDetails  =   unserialize($aHeater->light_relay_number);
												
												$PumpNumber   		=   $sHeaterDetails['Pump'];
											}
											if($PumpNumber != '')
											{
												$aPumpDetails =	$this->home_model->getPumpDetails($PumpNumber,$ipID);
												if(!empty($aPumpDetails))
												{
													foreach($aPumpDetails as $sPump)
													{
														$heaterStopTime =	date('Y-m-d H:i:s');
														$arrStopTime	=	explode(" ",$heaterStopTime);
														$aDate     		=   explode("-",$arrStopTime[0]);
														$aTime     		=   explode(":",$arrStopTime[1]);
														
														$sProgramAbsEnd =   mktime(($aTime[0]),($aTime[1]+5),($aTime[2]),$aDate[1],$aDate[2],$aDate[0]);
														$pumpStopTime   =   date("Y-m-d H:i:s", $sProgramAbsEnd);
														
														$this->home_model->updateRunAfterHeaterDetails($heaterNum,$sPump->pump_number,$heaterStopTime,$pumpStopTime,$ipID,$programID);
													}
												}
											}
										} 
									}
									else if($deviceType	== 'P')
									{
										$sNewResp = replace_return(${'sPowerCenter'.$ipID}, $sStatus, $deviceNumber);
										${'sPowerCenter'.$ipID} = $sNewResp;
										onoff_rlb_powercenter($sNewResp,${'board'.$ipID},$sPort,${'shhPort'.$ipID});
										
										//START : Check if heater is assigned to that relay.
										$heaterNum = $this->home_model->chkHeater($deviceNumber,'12',$ipID);
										
										if($heaterNum != '')
										{
											$this->home_model->updateHeaterRunDetails($heaterNum,$ipID);
											$aHeaterDetails  =   $this->home_model->getHeaterDeviceDetails($heaterNum,$ipID);
											if(!empty($aHeaterDetails))
											{
												foreach($aHeaterDetails as $aHeater)
												$sHeaterDetails  =   unserialize($aHeater->light_relay_number);
												
												$PumpNumber   		=   $sHeaterDetails['Pump'];
											}
											if($PumpNumber != '')
											{
												$aPumpDetails =	$this->home_model->getPumpDetails($PumpNumber,$ipID);
												if(!empty($aPumpDetails))
												{
													foreach($aPumpDetails as $sPump)
													{
														$heaterStopTime =	date('Y-m-d H:i:s');
														$arrStopTime	=	explode(" ",$heaterStopTime);
														$aDate     		=   explode("-",$arrStopTime[0]);
														$aTime     		=   explode(":",$arrStopTime[1]);
														
														$sProgramAbsEnd =   mktime(($aTime[0]),($aTime[1]+5),($aTime[2]),$aDate[1],$aDate[2],$aDate[0]);
														$pumpStopTime   =   date("Y-m-d H:i:s", $sProgramAbsEnd);
														
														$this->home_model->updateRunAfterHeaterDetails($heaterNum,$sPump->pump_number,$heaterStopTime,$pumpStopTime,$ipID,$programID);
													}
												}
											}
										} 
									}
									
									//Insert Entry in the Log Table for future Reference.
									$this->custom_model->saveCustomEntryInLog($programID,$deviceType);
									
									//Delete Entry From the current details Table.
									$this->custom_model->deleteCustomEntryFromCurrent($programID,$deviceType,$deviceNumber);
									
									
									if($lastElement->device_type  == $deviceDetails->device_type && $lastElement->device_number == $deviceDetails->device_number)
									{
										$keys 	 = array_keys($arrSequnceDevice);
										$nextSeq = $keys[array_search($currentSeq,$keys)+1];
										//$nextSeq		=	$currentSeq + 1;
										
										if(isset($arrSequnceDevice[$nextSeq]) && $arrSequnceDevice[$nextSeq] != '')
										{
											//echo '<pre>';print_r($arrSequnceDevice[$nextSeq]);echo '</pre>';
											
											foreach($arrSequnceDevice[$nextSeq] as $nextDevice)
											{
												$aCurrentDevice	=	explode('|||',$nextDevice);
												//START: First make valve device ON in the sequence.
												$sStatus		=	'1';
												$sRunTime		=	$aCurrentDevice[1];
												$deviceType 	=   $aCurrentDevice[2];
												$aDevice		=	explode("_",$aCurrentDevice[0]);
												
												if($deviceType == 'V')
												{
													$ipID			=	$aDevice[0];
													$sStatus		=	$aDevice[1];
													$deviceNumber	=	$aDevice[2];
												}
												else if($deviceType == 'PS' || $deviceType == 'R' || $deviceType == 'P')
												{
													$ipID			=	$aDevice[0];
													$deviceNumber	=	$aDevice[1];
												}
												
												$checkLog = $this->home_model->getDeviceRunLog($deviceNumber,$deviceType,$ipID,$programID,$unique_id);
												
												if($checkLog != '')
												{
													$this->home_model->updateRunningStatusCustomProgram($programID,'0');
													$this->custom_model->offCustomProgram($programID,'0');
													
													foreach($arrProgramValve as $valveDevice)
													{
														$arrTemp 			=	explode("_",$valveDevice);
														$ipIDTemp			=	$arrTemp[0];
														$sStatusTemp		=	$arrTemp[1];
														$deviceNumberTemp	=	$arrTemp[2];
														
														#START : GET Default Pool auto Position.
														$defaultPosition 	=	$this->home_model->getValveDefaultPosition($deviceNumberTemp,$ipIDTemp);
														
														$sNewResp = replace_return(${'sValves'.$ipIDTemp}, $defaultPosition, $deviceNumberTemp);
														${'sValves'.$ipIDTemp} = $sNewResp;
														onoff_rlb_valve($sNewResp,${'board'.$ipIDTemp},$sPort,${'shhPort'.$ipIDTemp});						
														#END : GET Default Pool auto Position.
														
														//START : INSERT THE VALVE DETAILS TO RUN VALVE FOR GIVEN TIME IN POOL MODE AUTO. IF TIME IS NOT SPECIFIED THEN IT WILL RUN FOR 1 MIN DEFAULT.
														
														$runTime = $this->home_model->getValveDefaultPositionTime($deviceNumberTemp,$ipIDTemp);
														if($runTime == 0)
														{
															$runTime = 1;
														}
														if($runTime == '')
														{
															$runTime = 1;
														}	
														
														$arrValveDefaultRunDetails	=	array('program_id'=>$programID,'valve'=>$deviceNumberTemp,'ip_id'=>$ipIDTemp,'runTime'=>$runTime);
														$this->home_model->insertValveDefaultRunDetails($arrValveDefaultRunDetails);
														
														//END : INSERT THE VALVE DETAILS TO RUN VALVE FOR GIVEN TIME IN POOL MODE AUTO. IF TIME IS NOT SPECIFIED THEN IT WILL RUN FOR 1 MIN DEFAULT.
													}
													$this->home_model->removePreviousPositions($programID);			
													continue;
													
													/* if(!empty($arrAfterProgramDevice))
													{
														$this->home_model->updateAfterProgram($programID,'1');
														
														$this->customProgramRunAfter($programID,$arrAfterProgramDevice,$unique_id,$arrExtraDetails);
													}
													else
													{
														$this->custom_model->offCustomProgram($programID,'0');
													}
													continue; */
												}
																								
												if($deviceType	==	'PS')
												{
													$this->cronMakePumpOnOFF($deviceNumber,$sStatus,${'board'.$ipID},$sPort,${'shhPort'.$ipID},$ipID);
														
													$strDevice		=	'Pump '.$deviceNumber;
												}
												else if($deviceType	== 'V')
												{
													$existingStatus 	=	${'sValves'.$ipID}[$deviceNumber];
													if($sStatus != $existingStatus)
													{
														$sNewResp = replace_return(${'sValves'.$ipID}, $sStatus, $deviceNumber);
														${'sValves'.$ipID} = $sNewResp;
														onoff_rlb_valve($sNewResp,${'board'.$ipID},$sPort,${'shhPort'.$ipID});
													}
													
													$strDevice	=	'Valve '.$deviceNumber;	
												}
												else if($deviceType	== 'R')
												{
													$existingStatus 	=	${'sRelays'.$ipID}[$deviceNumber];
													if($sStatus != $existingStatus)
													{
														$sNewResp = replace_return(${'sRelays'.$ipID}, $sStatus, $deviceNumber);
														${'sRelays'.$ipID} = $sNewResp;
														onoff_rlb_relay($sNewResp,${'board'.$ipID},$sPort,${'shhPort'.$ipID});
													}
													
													//START : Check if heater is assigned to that relay.
													$heaterNum = $this->home_model->chkHeater($deviceNumber,'24',$ipID);
													
													if($heaterNum != '')
													{
														
														$aHeaterDetails  =   $this->home_model->getHeaterDeviceDetails($heaterNum,$ipID);
														if(!empty($aHeaterDetails))
														{
															foreach($aHeaterDetails as $aHeater)
															$sHeaterDetails  =   unserialize($aHeater->light_relay_number);
															
															$PumpNumber   		=   $sHeaterDetails['Pump'];
															
															$maxRun   		=   $sHeaterDetails['maxRun'];
											
															$sHeaterStart 	=   date("Y-m-d H:i:s", time());
															$arrStart		=	explode(" ",$sHeaterStart);
															$aStartDate    	=   explode("-",$arrStart[0]);
															$aStartTime    	=   explode(":",$arrStart[1]);
															
															$sProgramAbsEnd   =   mktime($aStartTime[0],($aStartTime[1]+$maxRun),$aStartTime[2],$aStartDate[1],$aStartDate[2],$aStartDate[0]);
															$sHeaterEnd     =   date("Y-m-d H:i:s", $sProgramAbsEnd);
															
															$this->home_model->insertHeaterRunDetails($heaterNum,$ipID,$sHeaterStart,$sHeaterEnd);
															
														}
														if($PumpNumber != '')
														{
															$aPumpDetails =	$this->home_model->getPumpDetails($PumpNumber,$ipID);
															if(!empty($aPumpDetails))
															{
																foreach($aPumpDetails as $sPump)
																{
																	$this->cronMakePumpOnOFF($sPump->pump_number,'1',${'board'.$ipID},$sPort,${'shhPort'.$ipID},$ipID);
																}
															}
														}
													}
													//END : Check if heater is assigned to that relay. 
													
													$strDevice	=	'Relay '.$deviceNumber;
												}
												else if($deviceType	== 'P')
												{
													$existingStatus 	=	${'sPowerCenter'.$ipID}[$deviceNumber];
													if($sStatus != $existingStatus)
													{
														$sNewResp = replace_return(${'sPowerCenter'.$ipID}, $sStatus, $deviceNumber);
														${'sPowerCenter'.$ipID} = $sNewResp;
														onoff_rlb_powercenter($sNewResp,${'board'.$ipID},$sPort,${'shhPort'.$ipID});
													}
													
													//START : Check if heater is assigned to that relay.
													$heaterNum = $this->home_model->chkHeater($deviceNumber,'12',$ipID);
													
													if($heaterNum != '')
													{
														
														$aHeaterDetails  =   $this->home_model->getHeaterDeviceDetails($heaterNum,$ipID);
														if(!empty($aHeaterDetails))
														{
															foreach($aHeaterDetails as $aHeater)
															$sHeaterDetails  =   unserialize($aHeater->light_relay_number);
															
															$PumpNumber   		=   $sHeaterDetails['Pump'];
															$maxRun   		=   $sHeaterDetails['maxRun'];
											
															$sHeaterStart 	=   date("Y-m-d H:i:s", time());
															$arrStart		=	explode(" ",$sHeaterStart);
															$aStartDate    	=   explode("-",$arrStart[0]);
															$aStartTime    	=   explode(":",$arrStart[1]);
															
															$sProgramAbsEnd   =   mktime($aStartTime[0],($aStartTime[1]+$maxRun),$aStartTime[2],$aStartDate[1],$aStartDate[2],$aStartDate[0]);
															$sHeaterEnd     =   date("Y-m-d H:i:s", $sProgramAbsEnd);
															
															$this->home_model->insertHeaterRunDetails($heaterNum,$ipID,$sHeaterStart,$sHeaterEnd);
															
														}
														if($PumpNumber != '')
														{
															$aPumpDetails =	$this->home_model->getPumpDetails($PumpNumber,$ipID);
															if(!empty($aPumpDetails))
															{
																foreach($aPumpDetails as $sPump)
																{
																	$this->cronMakePumpOnOFF($sPump->pump_number,'1',${'board'.$ipID},$sPort,${'shhPort'.$ipID},$ipID);
																}
															}
														}
													}
													//END : Check if heater is assigned to that relay. 
													
													$strDevice	=	'Power Center '.$deviceNumber;
												}
												
												
												$arrDetails		=	array('program_id'=>$programID,		  'current_on_device'=>$strDevice,'device_type'=>$deviceType,  'device_number'=>$deviceNumber, 'current_on_time'=>$sRunTime,  'current_sequence'=>$nextSeq,	  'ip_id'=>$ipID,			  'unique_id'=>$unique_id);
												
												$this->custom_model->saveCustomCurrentRunningDevice($arrDetails);
											}
										}
										else
										{
											$currentDevice = $this->custom_model->getCustomProgrmaCurrentDevice($programID);
											if($currentDevice == '')
											{
												$this->home_model->updateRunningStatusCustomProgram($programID,'0');
												$this->custom_model->offCustomProgram($programID,'0');
												
												foreach($arrProgramValve as $valveDevice)
												{
													$arrTemp 			=	explode("_",$valveDevice);
													$ipIDTemp			=	$arrTemp[0];
													$sStatusTemp		=	$arrTemp[1];
													$deviceNumberTemp	=	$arrTemp[2];
													
													#START : GET Default Pool auto Position.
													$defaultPosition 	=	$this->home_model->getValveDefaultPosition($deviceNumberTemp,$ipIDTemp);
													
													$sNewResp = replace_return(${'sValves'.$ipIDTemp}, $defaultPosition, $deviceNumberTemp);
													${'sValves'.$ipIDTemp} = $sNewResp;
													onoff_rlb_valve($sNewResp,${'board'.$ipIDTemp},$sPort,${'shhPort'.$ipIDTemp});						
													#END : GET Default Pool auto Position.
													
													//START : INSERT THE VALVE DETAILS TO RUN VALVE FOR GIVEN TIME IN POOL MODE AUTO. IF TIME IS NOT SPECIFIED THEN IT WILL RUN FOR 1 MIN DEFAULT.
													$runTime = $this->home_model->getValveDefaultPositionTime($deviceNumberTemp,$ipIDTemp);
													if($runTime == 0)
													{
														$runTime = 1;
													}
													if($runTime == '')
													{
														$runTime = 1;
													}	
													
													$arrValveDefaultRunDetails	=	array('program_id'=>$programID,'valve'=>$deviceNumberTemp,'ip_id'=>$ipIDTemp,'runTime'=>$runTime);
													$this->home_model->insertValveDefaultRunDetails($arrValveDefaultRunDetails);
													
													//END : INSERT THE VALVE DETAILS TO RUN VALVE FOR GIVEN TIME IN POOL MODE AUTO. IF TIME IS NOT SPECIFIED THEN IT WILL RUN FOR 1 MIN DEFAULT.
													
												}
												
												$this->home_model->removePreviousPositions($programID);
												
												/* if(!empty($arrAfterProgramDevice))
												{
													
													$this->home_model->updateAfterProgram($programID,'1');
													$this->customProgramRunAfter($programID,$arrAfterProgramDevice,$unique_id,$arrExtraDetails);
												}
												else
												{
													$this->custom_model->offCustomProgram($programID,'0');
												} */
											}
										}
									}
								}
							}
						}
					}
				}
			}
		}
	}
	
	public function customProgramRunAfter($programID,$arrSequnceDevice,$unique_id,$arrExtraDetails)
	{
		$this->load->model('custom_model');
		$this->load->model('home_model');
		
		list($sIP,$sPort,$extra) = $this->home_model->getSettings();
		
		$currentDevice = $this->custom_model->getCustomProgrmaAfterDevice($programID);
		/* echo '<pre>';print_r($arrExtraDetails);echo '</pre>';
		die('STOP'); */
		if($currentDevice == '')
		{
			//foreach($arrSequnceDevice[1] as $devices)
			{
				$first_value = reset($arrSequnceDevice); // First Element's Value
				$first_key = key($arrSequnceDevice); // First Element's Key
			
				$aCurrentDevice	=	explode('|||',$arrSequnceDevice[$first_key]);
				//$aCurrentDevice	=	explode('|||',$devices);
				//START: First make valve device ON in the sequence.
				$sStatus		=	'1';
				$sRunTime		=	$aCurrentDevice[1];
				$deviceType 	=   $aCurrentDevice[2];
				$aDevice		=	explode("_",$aCurrentDevice[0]);
				if($deviceType == 'V')
				{
					$ipID			=	$aDevice[0];
					$sStatus		=	$aDevice[1];
					$deviceNumber	=	$aDevice[2];
				}
				
				$existingStatus 	=	$arrExtraDetails[$ipID]['sValves'][$deviceNumber];
				if($sStatus != $existingStatus)
				{
					$sNewResp = replace_return($arrExtraDetails[$ipID]['sValves'], $sStatus, $deviceNumber);
				
					$arrExtraDetails[$ipID]['sValves'] = $sNewResp;
					onoff_rlb_valve($sNewResp,$arrExtraDetails[$ipID]['board'],$sPort,$arrExtraDetails[$ipID]['shhPort']);
				}
				
				$strDevice	=	'Valve '.$deviceNumber;	
				
				$arrDetails		=	array('program_id'=>$programID,
										  'current_on_device'=>$strDevice,
										  'device_type'=>$deviceType,
										  'device_number'=>$deviceNumber,
										  'current_on_time'=>$sRunTime,
										  'current_sequence'=>1,
										  'ip_id'=>$ipID,
										  'unique_id'=>$unique_id);
				
				$this->custom_model->saveCustomAfterRunningDevice($arrDetails);
			}
		}
		else if($currentDevice != '')
		{
			$lastElement = end($currentDevice);
			
			foreach($currentDevice as $deviceDetails)
			{
				//If Device is Running Then Check if its Time is Complete.
				$OffTime			=	$deviceDetails->current_off_time;
				$currentServerTime	=	date('Y-m-d H:i:s');
				
				if($currentServerTime >= $OffTime)
				{
					$currentSeq		=	$deviceDetails->current_sequence;
					$deviceType 	=   $deviceDetails->device_type;
					$ipID			=	$deviceDetails->ip_id;
					$sStatus		=	0;
					$deviceNumber	=	$deviceDetails->device_number;
					
					$sNewResp = replace_return($arrExtraDetails[$ipID]['sValves'], $sStatus, $deviceNumber);
					$arrExtraDetails[$ipID]['sValves'] = $sNewResp;
					onoff_rlb_valve($sNewResp,$arrExtraDetails[$ipID]['board'],$sPort,$arrExtraDetails[$ipID]['shhPort']);
					
					
					//Insert Entry in the Log Table for future Reference.
					$this->custom_model->saveCustomAfterEntryInLog($programID,$deviceType);
					
					//Delete Entry From the current details Table.
					$this->custom_model->deleteCustomEntryFromAfter($programID,$deviceType,$deviceNumber);
					
					//if($lastElement->device_type  == $deviceDetails->device_type && $lastElement->device_number == $deviceDetails->device_number)
					{
						//$nextSeq		=	$currentSeq + 1;
						$keys 	 = array_keys($arrSequnceDevice);
						$nextSeq = $keys[array_search($currentSeq,$keys)+1];
						
						if(isset($arrSequnceDevice[$nextSeq]) && $arrSequnceDevice[$nextSeq] != '')
						{
							//foreach($arrSequnceDevice[$nextSeq] as $nextDevice)
							{
								//$aCurrentDevice	=	explode('|||',$nextDevice);
								
								$aCurrentDevice	=	explode('|||',$arrSequnceDevice[$nextSeq]);
								//START: First make valve device ON in the sequence.
								$sStatus		=	'1';
								$sRunTime		=	$aCurrentDevice[1];
								$deviceType 	=   $aCurrentDevice[2];
								$aDevice		=	explode("_",$aCurrentDevice[0]);
																
								$ipID			=	$aDevice[0];
								$sStatus		=	$aDevice[1];
								$deviceNumber	=	$aDevice[2];
								
								//$checkLog = $this->home_model->getDeviceRunLogAfter($deviceNumber,$deviceType,$ipID,$programID,$unique_id);
								$checkLog	= 1;
								if($checkLog == '')
								{
									$this->home_model->updateAfterProgram($programID,'0');
									$this->custom_model->offCustomProgram($programID,'0');
									$this->home_model->updateRunningStatusCustomProgram($programID,'0');
								}
								else
								{
									$existingStatus 	=	$arrExtraDetails[$ipID]['sValves'][$deviceNumber];
									if($sStatus != $existingStatus)
									{		
										$sNewResp = replace_return($arrExtraDetails[$ipID]['sValves'], $sStatus, $deviceNumber);
										$arrExtraDetails[$ipID]['sValves'] = $sNewResp;
										onoff_rlb_valve($sNewResp,$arrExtraDetails[$ipID]['board'],$sPort,$arrExtraDetails[$ipID]['shhPort']);
									}
									
									$strDevice	=	'Valve '.$deviceNumber;	
									
									$arrDetails		=	array('program_id'=>$programID,		  'current_on_device'=>$strDevice,'device_type'=>$deviceType,  'device_number'=>$deviceNumber, 'current_on_time'=>$sRunTime,  'current_sequence'=>$nextSeq,	  'ip_id'=>$ipID,			  'unique_id'=>$unique_id);
									
									$this->custom_model->saveCustomAfterRunningDevice($arrDetails);
								}
							}
						}
						else
						{
							$this->home_model->updateAfterProgram($programID,'0');
							$this->custom_model->offCustomProgram($programID,'0');
							$this->home_model->updateRunningStatusCustomProgram($programID,'0');
						}
					}
				}
			}
		}
	}
	
	function updateSecuredShowingDB($sDeviceIP,$strIPToChange)
	{
		$otherdb = $this->load->database('otherDB',TRUE);
		$query1 = $otherdb->where('g_poolspa_ip',$sDeviceIP)->get('ss_guest_poolspa');
		if($query1->num_rows() > 0)
		{
			foreach($query1->result() as $row)
			{
				$arrUpdate = array('g_poolspa_ip'=>$strIPToChange);
				$otherdb->where('g_poolspa_id',$row->g_poolspa_id);
				$otherdb->update('ss_guest_poolspa',$arrUpdate);
				
			}
		}
		$otherdb->close();
	}
	
	public function customProgramRunTest()
	{
		$this->load->model('custom_model');
		$this->load->model('home_model');
		
		//Get Current Active Mode
		$iMode	=   $this->home_model->getActiveMode();
		
		//Get All On Program and Details.
		$aAllOnPrograms = $this->home_model->getOnCustomProgramTest();
		
		
		if(!empty($aAllOnPrograms) && $iMode == 1)
		{
			//Get All IP Details.
			$aIPDetails = $this->home_model->getBoardIP();
			
			list($sIP,$sPort,$extra) = $this->home_model->getSettings();
			
			foreach($aIPDetails as $IP)
			{
				${'shhPort'.$IP->id}	=	'';
				if(IS_LOCAL == '1')
				{
					//Get SSH port of the RLB board using IP.
					${'shhPort'.$IP->id} = $this->home_model->getSSHPortFromID($IP->id);
				}
				$sResponse		=	array();
				$sValves        =   ''; 
				$sRelays        =   '';  
				$sPump			=	'';	
				
				//Get the status response of devices from relay board.
				$sResponse      =   get_rlb_status($IP->ip,$sPort,$shhPort);
			
				$sValves        =   $sResponse['valves']; // Valve Device Status
				$sRelays        =   $sResponse['relay'];  // Relay Device Status
				$sPowerCenter   =   $sResponse['powercenter']; // Power Center Device Status
				
				${'sRelays'.$IP->id} 		=	$sRelays;
				${'sValves'.$IP->id} 		=	$sValves;
				${'sPowerCenter'.$IP->id} 	=	$sPowerCenter;  
				
				${'sPump'.$IP->id}	=	array($sResponse['pump_seq_0_st'],$sResponse['pump_seq_1_st'],$sResponse['pump_seq_2_st']);
				${'board'.$IP->id} 	=	$IP->ip;
				
				$arrExtraDetails[$IP->id] = array('sValves'=>${'sValves'.$IP->id},'board'=>${'board'.$IP->id},'shhPort'=>${'shhPort'.$IP->id});
			}
			
			foreach($aAllOnPrograms as $customProgram)
			{
				$unique_id	=	$customProgram->unique_id;
				$programID	=	$customProgram->id;
				
				$arrSequnceDevice	=	array();
				//First Make the Program Running Status to 1.
				$this->home_model->updateRunningStatusCustomProgram($programID,'1');
				
				$aProgramDetails =	json_decode($customProgram->program_details);
				
				$maxRunTime		 =	$aProgramDetails->g_custom_max_time;
				$programStart	 =	$customProgram->program_start;	
				$programEnd		 =	$customProgram->program_end;

				$afterProgram	 =	$customProgram->afterProgram;
				$previousState	 = 	unserialize($customProgram->previousState);		
				
				if(isset($aProgramDetails->g_rlb_pump_list) && $aProgramDetails->g_rlb_pump_list != '')
				{
					//Pump Device Details.
					$pumpDevice		=	explode(",",$aProgramDetails->g_rlb_pump_list);
					$pumpSequence	=	explode(",",$aProgramDetails->g_pump_sq);
					$pumpTime		=	explode(",",$aProgramDetails->g_pump_time);
				}
				
				if(isset($aProgramDetails->g_rlb_valve_list) && $aProgramDetails->g_rlb_valve_list != '')
				{
					//Valve Device Details
					$valveDevice	=	explode(",",$aProgramDetails->g_rlb_valve_list);	
					$valveSequence	=	explode(",",$aProgramDetails->g_valve_sq);	
					$valveTime		=	explode(",",$aProgramDetails->g_valve_time);
				}

				if(isset($aProgramDetails->g_rlb_relay_list) && $aProgramDetails->g_rlb_relay_list != '')
				{
					//Relay Device Details
					$relayDevice	=	explode(",",$aProgramDetails->g_rlb_relay_list);	
					$relaySequence	=	explode(",",$aProgramDetails->g_relay_sq);	
					$relayTime		=	explode(",",$aProgramDetails->g_relay_time);				
				}
				
				if(isset($aProgramDetails->g_rlb_powercenter_list) && $aProgramDetails->g_rlb_powercenter_list != '')
				{
					//Relay Device Details
					$powerCenterDevice	=	explode(",",$aProgramDetails->g_rlb_powercenter_list);	
					$powerCenterSequence	=	explode(",",$aProgramDetails->g_powercenter_sq);	
					$powerCenterTime		=	explode(",",$aProgramDetails->g_powercenter_time);				
				}
								
				if(!empty($pumpSequence))
				{
					foreach($pumpSequence as $seq => $key)
					{
						if($key != '')
						{
							if(!array_key_exists($key,$arrSequnceDevice))
							$arrSequnceDevice[$key] = array();
							
							array_push($arrSequnceDevice[$key],$pumpDevice[$seq].'|||'.$pumpTime[$seq].'|||PS');
						}
						//$arrSequnceDevice[$seq] = $pumpDevice[$key].'|||'.$pumpTime[$key].'|||PS';
					}
				}
				
				//$valveSequence	=	array_flip($valveSequence);
				
				$arrAfterProgramDevice = array();
				$arrValveKeepOn		   = array();
				//sort($valveSequence);
				
				if(!empty($valveSequence))
				{
					$k = 1;
					foreach($valveSequence as $seq => $key)
					{
						if($key != '')
						{
							if(!array_key_exists($key,$arrSequnceDevice))
							$arrSequnceDevice[$key] = array();
						
							array_push($arrSequnceDevice[$key],$valveDevice[$seq].'|||'.$valveTime[$seq].'|||V');
							
							//Valve to run after program end.
							$arr	=	explode('_',$valveDevice[$seq]);
							$strPosition = '';
							if($arr[1] == 1)
							{
								$strPosition = 2;
							}
							else if($arr[1] == 2)
							{
								$strPosition = 1;
							}
							
							$arrTemp 			=	explode("_",$valveDevice[$seq]);
							$ipIDTemp			=	$arrTemp[0];
							$sStatusTemp		=	$arrTemp[1];
							$deviceNumberTemp	=	$arrTemp[2];
							
							$existingStatus 	=	${'sValves'.$ipIDTemp}[$deviceNumberTemp];
							
							//$tempDevice			=	$ipIDTemp.'_'.$existingStatus.'_'.$deviceNumberTemp;
							
							$valveAfterProgram = $arr[0].'_'.$strPosition.'_'.$arr[2];
							
							//if($existingStatus != $sStatusTemp)
							if(!in_array($valveDevice[$seq],$previousState))	
							{
								$arrAfterProgramDevice[$key] = $valveAfterProgram.'|||'.$valveTime[$seq].'|||V';
								
								$k++;
							}
							else
							{
								$arrValveKeepOn[] = $ipIDTemp.'_'.$deviceNumberTemp;
							}
							
						}
						//array_push($arrAfterProgramDevice,$valveAfterProgram.'|||'.$valveTime[$seq].'|||V');
						
					}
				}
				
				if(!empty($relaySequence))
				{
					foreach($relaySequence as $seq => $key)
					{
						if($key != '')
						{
							if(!array_key_exists($key,$arrSequnceDevice))
							$arrSequnceDevice[$key] = array();
							
							array_push($arrSequnceDevice[$key],$relayDevice[$seq].'|||'.$relayTime[$seq].'|||R');
						}
					}
				}
				
				if(!empty($powerCenterSequence))
				{
					foreach($powerCenterSequence as $seq => $key)
					{
						if($key != '')
						{
							if(!array_key_exists($key,$arrSequnceDevice))
							$arrSequnceDevice[$key] = array();
							
							array_push($arrSequnceDevice[$key],$powerCenterDevice[$seq].'|||'.$powerCenterTime[$seq].'|||P');
						}
					}
				}
				ksort($arrSequnceDevice);
				ksort($arrAfterProgramDevice);
				
				//Check Program End Time, if it is passed make that program OFF.
				if((strtotime(date("Y-m-d H:i:s")) > strtotime($programEnd)) && $afterProgram  == '0')
				{
					$this->home_model->updateRunningStatusCustomProgram($programID,'0');
					
					if(!empty($arrAfterProgramDevice))
					{
						$this->home_model->updateAfterProgram($programID,'1');
						$this->customProgramRunAfterTest($programID,$arrAfterProgramDevice,$unique_id,$arrExtraDetails);
					}
					else
					{
						$this->custom_model->offCustomProgram($programID,'0');
					}
					continue;
				}
				
				//Check if Progrma is running, if running then get which device is running for Programs.
				$currentDevice = $this->custom_model->getCustomProgrmaCurrentDevice($programID);
				
				if($iMode != 1)
				{
					$this->home_model->updateRunningStatusCustomProgram($programID,'0');
					$this->custom_model->offCustomProgram($programID,'0');
					$this->home_model->updateAfterProgram($programID,'0');
					
					//Insert Entry in the Log Table for future Reference.
					$this->custom_model->saveCustomEntryInLog($programID,$deviceType);
					
					//Delete Entry From the current details Table.
					$this->custom_model->deleteCustomEntryFromCurrent($programID);
					
					foreach($currentDevice as $deviceDetails)
					{
						//If Device is Running Then Check if its Time is Complete.
						$currentSeq		=	$deviceDetails->current_sequence;
						$deviceType 	=   $deviceDetails->device_type;
						$ipID			=	$deviceDetails->ip_id;
						$sStatus		=	0;
						$deviceNumber	=	$deviceDetails->device_number;
						
						if($deviceType == 'V')
						{
							$sNewResp = replace_return(${'sValves'.$ipID}, $sStatus, $deviceNumber);
							${'sValves'.$ipID} = $sNewResp;
							#onoff_rlb_valve($sNewResp,${'board'.$ipID},$sPort,${'shhPort'.$ipID});
						}
						else if($deviceType == 'PS')
						{	
							#$this->cronMakePumpOnOFF($deviceNumber,$sStatus,${'board'.$ipID},$sPort,${'shhPort'.$ipID},$ipID);
						}
						else if($deviceType	== 'R')
						{
							$sNewResp = replace_return(${'sRelays'.$ipID}, $sStatus, $deviceNumber);
							${'sRelays'.$ipID} = $sNewResp;
							#onoff_rlb_relay($sNewResp,${'board'.$ipID},$sPort,${'shhPort'.$ipID});
						}
						else if($deviceType	== 'P')
						{
							$sNewResp = replace_return(${'sPowerCenter'.$ipID}, $sStatus, $deviceNumber);
							${'sPowerCenter'.$ipID} = $sNewResp;
							#onoff_rlb_powercenter($sNewResp,${'board'.$ipID},$sPort,${'shhPort'.$ipID});
						}
					}
				}
				else if($afterProgram == '1')
				{
					$this->customProgramRunAfterTest($programID,$arrAfterProgramDevice,$unique_id,$arrExtraDetails);
					continue;
				}
				else
				{
					if(!empty($arrSequnceDevice))
					{
						if($currentDevice == '')
						{
							foreach($arrSequnceDevice[1] as $devices)
							{
								//$aCurrentDevice	=	explode('|||',$arrSequnceDevice[1]);
								$aCurrentDevice	=	explode('|||',$devices);
								//START: First make valve device ON in the sequence.
								$sStatus		=	'1';
								$sRunTime		=	$aCurrentDevice[1];
								$deviceType 	=   $aCurrentDevice[2];
								$aDevice		=	explode("_",$aCurrentDevice[0]);
								if($deviceType == 'V')
								{
									$ipID			=	$aDevice[0];
									$sStatus		=	$aDevice[1];
									$deviceNumber	=	$aDevice[2];
								}
								else if($deviceType == 'PS' || $deviceType == 'R' || $deviceType == 'P')
								{
									$ipID			=	$aDevice[0];
									$deviceNumber	=	$aDevice[1];
								}
								
								if($deviceType	==	'PS')
								{
									#$this->cronMakePumpOnOFF($deviceNumber,$sStatus,${'board'.$ipID},$sPort,${'shhPort'.$ipID},$ipID);
											
									$strDevice		=	'Pump '.$deviceNumber;
								}
								else if($deviceType	== 'V')
								{
									$existingStatus 	=	${'sValves'.$ipID}[$deviceNumber];
									if($sStatus != $existingStatus)
									{
										$sNewResp = replace_return(${'sValves'.$ipID}, $sStatus, $deviceNumber);
										${'sValves'.$ipID} = $sNewResp;
										#onoff_rlb_valve($sNewResp,${'board'.$ipID},$sPort,${'shhPort'.$ipID});
									}
									
									$strDevice	=	'Valve '.$deviceNumber;	
								}
								else if($deviceType	== 'R')
								{
									$existingStatus 	=	${'sRelays'.$ipID}[$deviceNumber];
									if($sStatus != $existingStatus)
									{
										$sNewResp = replace_return(${'sRelays'.$ipID}, $sStatus, $deviceNumber);
										${'sRelays'.$ipID} = $sNewResp;
										#onoff_rlb_relay($sNewResp,${'board'.$ipID},$sPort,${'shhPort'.$ipID});
									}
									
									$strDevice	=	'Relay '.$deviceNumber;	
								}
								else if($deviceType	== 'P')
								{
									$existingStatus 	=	${'sPowerCenter'.$ipID}[$deviceNumber];
									if($sStatus != $existingStatus)
									{
										$sNewResp = replace_return(${'sPowerCenter'.$ipID}, $sStatus, $deviceNumber);
										${'sPowerCenter'.$ipID} = $sNewResp;
										#onoff_rlb_powercenter($sNewResp,${'board'.$ipID},$sPort,${'shhPort'.$ipID});
									}
									
									$strDevice	=	'Power Center '.$deviceNumber;
								}
								
								$arrDetails		=	array('program_id'=>$programID,
														  'current_on_device'=>$strDevice,
														  'device_type'=>$deviceType,
														  'device_number'=>$deviceNumber,
														  'current_on_time'=>$sRunTime,
														  'current_sequence'=>1,
														  'ip_id'=>$ipID,
														  'unique_id'=>$unique_id);
								
								$this->custom_model->saveCustomCurrentRunningDevice($arrDetails);
							}
						}
						else if($currentDevice != '')
						{
							$lastElement = end($currentDevice);
							foreach($currentDevice as $deviceDetails)
							{
								//If Device is Running Then Check if its Time is Complete.
								$OffTime			=	$deviceDetails->current_off_time;
								$currentServerTime	=	date('Y-m-d H:i:s');
								
								if($currentServerTime >= $OffTime)
								{
									$currentSeq		=	$deviceDetails->current_sequence;
									$deviceType 	=   $deviceDetails->device_type;
									$ipID			=	$deviceDetails->ip_id;
									$sStatus		=	0;
									$deviceNumber	=	$deviceDetails->device_number;
									
									if($deviceType == 'V')
									{
										if(!in_array($ipID.'_'.$deviceNumber,$arrValveKeepOn))
										{
											$sNewResp = replace_return(${'sValves'.$ipID}, $sStatus, $deviceNumber);
											${'sValves'.$ipID} = $sNewResp;
											#onoff_rlb_valve($sNewResp,${'board'.$ipID},$sPort,${'shhPort'.$ipID});
										}
									}
									else if($deviceType == 'PS')
									{	
										#$this->cronMakePumpOnOFF($deviceNumber,$sStatus,${'board'.$ipID},$sPort,${'shhPort'.$ipID},$ipID);
									}
									else if($deviceType	== 'R')
									{
										$sNewResp = replace_return(${'sRelays'.$ipID}, $sStatus, $deviceNumber);
										${'sRelays'.$ipID} = $sNewResp;
										#onoff_rlb_relay($sNewResp,${'board'.$ipID},$sPort,${'shhPort'.$ipID});
									}
									else if($deviceType	== 'P')
									{
										$sNewResp = replace_return(${'sPowerCenter'.$ipID}, $sStatus, $deviceNumber);
										${'sPowerCenter'.$ipID} = $sNewResp;
										#onoff_rlb_powercenter($sNewResp,${'board'.$ipID},$sPort,${'shhPort'.$ipID});
									}
									
									//Insert Entry in the Log Table for future Reference.
									$this->custom_model->saveCustomEntryInLog($programID,$deviceType);
									
									//Delete Entry From the current details Table.
									$this->custom_model->deleteCustomEntryFromCurrent($programID,$deviceType,$deviceNumber);
									
									
									if($lastElement->device_type  == $deviceDetails->device_type && $lastElement->device_number == $deviceDetails->device_number)
									{
										$keys 	 = array_keys($arrSequnceDevice);
										$nextSeq = $keys[array_search($currentSeq,$keys)+1];
										//$nextSeq		=	$currentSeq + 1;
										
										if(isset($arrSequnceDevice[$nextSeq]) && $arrSequnceDevice[$nextSeq] != '')
										{
											foreach($arrSequnceDevice[$nextSeq] as $nextDevice)
											{
												$aCurrentDevice	=	explode('|||',$nextDevice);
												//START: First make valve device ON in the sequence.
												$sStatus		=	'1';
												$sRunTime		=	$aCurrentDevice[1];
												$deviceType 	=   $aCurrentDevice[2];
												$aDevice		=	explode("_",$aCurrentDevice[0]);
												
												if($deviceType == 'V')
												{
													$ipID			=	$aDevice[0];
													$sStatus		=	$aDevice[1];
													$deviceNumber	=	$aDevice[2];
												}
												else if($deviceType == 'PS' || $deviceType == 'R' || $deviceType == 'P')
												{
													$ipID			=	$aDevice[0];
													$deviceNumber	=	$aDevice[1];
												}
												
												$checkLog = $this->home_model->getDeviceRunLog($deviceNumber,$deviceType,$ipID,$programID,$unique_id);
												if($checkLog != '')
												{
													$this->home_model->updateRunningStatusCustomProgram($programID,'0');
												
													if(!empty($arrAfterProgramDevice))
													{
														$this->home_model->updateAfterProgram($programID,'1');
														
														$this->customProgramRunAfterTest($programID,$arrAfterProgramDevice,$unique_id,$arrExtraDetails);
													}
													else
													{
														$this->custom_model->offCustomProgram($programID,'0');
													}
													continue;
												}
																								
												if($deviceType	==	'PS')
												{
													#$this->cronMakePumpOnOFF($deviceNumber,$sStatus,${'board'.$ipID},$sPort,${'shhPort'.$ipID},$ipID);
															
													$strDevice		=	'Pump '.$deviceNumber;
												}
												else if($deviceType	== 'V')
												{
													$existingStatus 	=	${'sValves'.$ipID}[$deviceNumber];
													if($sStatus != $existingStatus)
													{
														$sNewResp = replace_return(${'sValves'.$ipID}, $sStatus, $deviceNumber);
														${'sValves'.$ipID} = $sNewResp;
														#onoff_rlb_valve($sNewResp,${'board'.$ipID},$sPort,${'shhPort'.$ipID});
													}
													
													$strDevice	=	'Valve '.$deviceNumber;	
												}
												else if($deviceType	== 'R')
												{
													$existingStatus 	=	${'sRelays'.$ipID}[$deviceNumber];
													if($sStatus != $existingStatus)
													{
														$sNewResp = replace_return(${'sRelays'.$ipID}, $sStatus, $deviceNumber);
														${'sRelays'.$ipID} = $sNewResp;
														#onoff_rlb_relay($sNewResp,${'board'.$ipID},$sPort,${'shhPort'.$ipID});
													}
													
													$strDevice	=	'Relay '.$deviceNumber;
												}
												else if($deviceType	== 'P')
												{
													$existingStatus 	=	${'sPowerCenter'.$ipID}[$deviceNumber];
													if($sStatus != $existingStatus)
													{
														$sNewResp = replace_return(${'sPowerCenter'.$ipID}, $sStatus, $deviceNumber);
														${'sPowerCenter'.$ipID} = $sNewResp;
														#onoff_rlb_powercenter($sNewResp,${'board'.$ipID},$sPort,${'shhPort'.$ipID});
													}
													
													$strDevice	=	'Power Center '.$deviceNumber;
												}
												
												
												$arrDetails		=	array('program_id'=>$programID,		  'current_on_device'=>$strDevice,'device_type'=>$deviceType,  'device_number'=>$deviceNumber, 'current_on_time'=>$sRunTime,  'current_sequence'=>$nextSeq,	  'ip_id'=>$ipID,			  'unique_id'=>$unique_id);
												
												$this->custom_model->saveCustomCurrentRunningDevice($arrDetails);
											}
										}
										else
										{
											$currentDevice = $this->custom_model->getCustomProgrmaCurrentDevice($programID);
											if($currentDevice == '')
											{
												$this->home_model->updateRunningStatusCustomProgram($programID,'0');
												
												if(!empty($arrAfterProgramDevice))
												{
													
													$this->home_model->updateAfterProgram($programID,'1');
													$this->customProgramRunAfterTest($programID,$arrAfterProgramDevice,$unique_id,$arrExtraDetails);
												}
												else
												{
													$this->custom_model->offCustomProgram($programID,'0');
												}
											}
										}
									}
								}
							}
						}
					}
				}
			}
		}
	}
	
	public function customProgramRunAfterTest($programID,$arrSequnceDevice,$unique_id,$arrExtraDetails)
	{
		$this->load->model('custom_model');
		$this->load->model('home_model');
		
		list($sIP,$sPort,$extra) = $this->home_model->getSettings();
		
		$currentDevice = $this->custom_model->getCustomProgrmaAfterDevice($programID);
		/* echo '<pre>';print_r($arrExtraDetails);echo '</pre>';
		die('STOP'); */
		if($currentDevice == '')
		{
			$first_value = reset($arrSequnceDevice); // First Element's Value
			$first_key = key($arrSequnceDevice); // First Element's Key
			
			//foreach($arrSequnceDevice[1] as $devices)
			{
				$aCurrentDevice	=	explode('|||',$arrSequnceDevice[$first_key]);
				
				//$aCurrentDevice	=	explode('|||',$devices);
				//START: First make valve device ON in the sequence.
				$sStatus		=	'1';
				$sRunTime		=	$aCurrentDevice[1];
				$deviceType 	=   $aCurrentDevice[2];
				
				$aDevice		=	explode("_",$aCurrentDevice[0]);
				if($deviceType == 'V')
				{
					$ipID			=	$aDevice[0];
					$sStatus		=	$aDevice[1];
					$deviceNumber	=	$aDevice[2];
				}
				
				$existingStatus 	=	$arrExtraDetails[$ipID]['sValves'][$deviceNumber];
				if($sStatus != $existingStatus)
				{
					$sNewResp = replace_return($arrExtraDetails[$ipID]['sValves'], $sStatus, $deviceNumber);
				
					$arrExtraDetails[$ipID]['sValves'] = $sNewResp;
					#onoff_rlb_valve($sNewResp,$arrExtraDetails[$ipID]['board'],$sPort,$arrExtraDetails[$ipID]['shhPort']);
				}
				
				$strDevice	=	'Valve '.$deviceNumber;	
				
				$arrDetails		=	array('program_id'=>$programID,
										  'current_on_device'=>$strDevice,
										  'device_type'=>$deviceType,
										  'device_number'=>$deviceNumber,
										  'current_on_time'=>$sRunTime,
										  'current_sequence'=>1,
										  'ip_id'=>$ipID,
										  'unique_id'=>$unique_id);
				
				$this->custom_model->saveCustomAfterRunningDevice($arrDetails);
			}
		}
		else if($currentDevice != '')
		{
			$lastElement = end($currentDevice);
			
			foreach($currentDevice as $deviceDetails)
			{
				//If Device is Running Then Check if its Time is Complete.
				$OffTime			=	$deviceDetails->current_off_time;
				$currentServerTime	=	date('Y-m-d H:i:s');
				
				if($currentServerTime >= $OffTime)
				{
					$currentSeq		=	$deviceDetails->current_sequence;
					$deviceType 	=   $deviceDetails->device_type;
					$ipID			=	$deviceDetails->ip_id;
					$sStatus		=	0;
					$deviceNumber	=	$deviceDetails->device_number;
					
					$sNewResp = replace_return($arrExtraDetails[$ipID]['sValves'], $sStatus, $deviceNumber);
					$arrExtraDetails[$ipID]['sValves'] = $sNewResp;
					#onoff_rlb_valve($sNewResp,$arrExtraDetails[$ipID]['board'],$sPort,$arrExtraDetails[$ipID]['shhPort']);
					
					
					//Insert Entry in the Log Table for future Reference.
					$this->custom_model->saveCustomAfterEntryInLog($programID,$deviceType);
					
					//Delete Entry From the current details Table.
					$this->custom_model->deleteCustomEntryFromAfter($programID,$deviceType,$deviceNumber);
					
					//if($lastElement->device_type  == $deviceDetails->device_type && $lastElement->device_number == $deviceDetails->device_number)
					{
						//$nextSeq		=	$currentSeq + 1;
						$keys 	 = array_keys($arrSequnceDevice);
						$nextSeq = $keys[array_search($currentSeq,$keys)+1];
						
						if(isset($arrSequnceDevice[$nextSeq]) && $arrSequnceDevice[$nextSeq] != '')
						{
							//foreach($arrSequnceDevice[$nextSeq] as $nextDevice)
							{
								//$aCurrentDevice	=	explode('|||',$nextDevice);
								
								$aCurrentDevice	=	explode('|||',$arrSequnceDevice[$nextSeq]);
								//START: First make valve device ON in the sequence.
								$sStatus		=	'1';
								$sRunTime		=	$aCurrentDevice[1];
								$deviceType 	=   $aCurrentDevice[2];
								$aDevice		=	explode("_",$aCurrentDevice[0]);
																
								$ipID			=	$aDevice[0];
								$sStatus		=	$aDevice[1];
								$deviceNumber	=	$aDevice[2];
								
								$existingStatus 	=	$arrExtraDetails[$ipID]['sValves'][$deviceNumber];
								if($sStatus != $existingStatus)
								{		
									$sNewResp = replace_return($arrExtraDetails[$ipID]['sValves'], $sStatus, $deviceNumber);
									$arrExtraDetails[$ipID]['sValves'] = $sNewResp;
									#onoff_rlb_valve($sNewResp,$arrExtraDetails[$ipID]['board'],$sPort,$arrExtraDetails[$ipID]['shhPort']);
								}
								
								$strDevice	=	'Valve '.$deviceNumber;	
								
								$arrDetails		=	array('program_id'=>$programID,		  'current_on_device'=>$strDevice,'device_type'=>$deviceType,  'device_number'=>$deviceNumber, 'current_on_time'=>$sRunTime,  'current_sequence'=>$nextSeq,	  'ip_id'=>$ipID,			  'unique_id'=>$unique_id);
								
								$this->custom_model->saveCustomAfterRunningDevice($arrDetails);
							}
						}
						else
						{
							$this->home_model->updateAfterProgram($programID,'0');
							$this->custom_model->offCustomProgram($programID,'0');
							$this->home_model->updateRunningStatusCustomProgram($programID,'0');
						}
					}
				}
			}
		}
	}
	
	/**
	  * Function to Keep running the heater till 5 min after the Heater.
	  * @param 
	  * @return
	**/
	public function runPumpAfterHeater()
	{
		$this->load->model('home_model');
		
		$allOnPumps = $this->home_model->getOnPumpOfHeaters();
		if(!empty($allOnPumps))
		{
			foreach($allOnPumps as $pumpDetails)
			{
				$currentTime  = date('Y-m-d H:i:s');
				$id			  = $pumpDetails->id;
				$pumpStopTime = $pumpDetails->PumpStopTime;
				$ipID		  = $pumpDetails->ip_id;	
				$pumpNumber	  = $pumpDetails->pumpNumber;
				
				if(strtotime($currentTime) >= strtotime($pumpStopTime))
				{
					list($sIP,$sPort,$extra) = $this->home_model->getSettings();
					
					$shhPort	=	'';
					if(IS_LOCAL == '1')
					{
						//Get SSH port of the RLB board using IP.
						$shhPort = $this->home_model->getSSHPortFromID($ipID);
					}
					
					$this->cronMakePumpOnOFF($pumpNumber,'0',$sIP,$sPort,$shhPort,$ipID);
					$this->home_model->updateRunCompletePump($id,'1');
					
				}
			}
		}
	}
	
	public function backupFiles()
	{
            set_time_limit(0);
            @file_get_contents('http://www.lvnvacationhomerentals.com/deleteRelayboardBackupFiles.php');

            //START : Create Zip of the all Relayboard Files.
                    $zipFilename = 'relayboard.zip';
                    $zipFilePath = '/var/www/html/'.$zipFilename;
                    $zipCommand = 'zip -r '.$zipFilePath.' /var/www/html/relayboard';
                    shell_exec($zipCommand);

                    $fp = fopen($zipFilePath, 'r');
                    $ch = curl_init();
                    curl_setopt($ch, CURLOPT_USERPWD, "lvnv3098:V@cationH0mes");
                    curl_setopt($ch, CURLOPT_URL, 'ftp://@lvnvacationhomerentals.com/relayboard/' . $zipFilename);
                    curl_setopt($ch, CURLOPT_UPLOAD, 1);
                    curl_setopt($ch, CURLOPT_TIMEOUT, 86400); // 1 Day Timeout
                    curl_setopt($ch, CURLOPT_INFILE, $fp);
                    curl_setopt($ch, CURLOPT_NOPROGRESS, false);
                    curl_setopt($ch, CURLOPT_PROGRESSFUNCTION, 'CURL_callback');
                    curl_setopt($ch, CURLOPT_BUFFERSIZE, 128);
                    curl_setopt($ch, CURLOPT_INFILESIZE, filesize($zipFilePath));
                    curl_exec($ch);
                    curl_close($ch);
                    fclose($fp);

                    //unlink($zipFilePath);

            //END : Create Zip of the all Relayboard Files.
		
            //START : Create SQL file of the complete Database.    
                    $contents = $this->backupDatabaseDetails();
                    $sqlFileName = 'db-backup.sql';
                    $sqlFilePath = 'backup/'.$sqlFileName;	
                    $handle = fopen($sqlFilePath,'w+');
                    fwrite($handle,$contents);
                    fclose($handle);

                    $fp = fopen($sqlFilePath, 'r');
                    $ch = curl_init();
                    curl_setopt($ch, CURLOPT_USERPWD, "lvnv3098:V@cationH0mes");
                    curl_setopt($ch, CURLOPT_URL, 'ftp://@lvnvacationhomerentals.com/relayboard/' . $sqlFileName);
                    curl_setopt($ch, CURLOPT_UPLOAD, 1);
                    curl_setopt($ch, CURLOPT_TIMEOUT, 86400); // 1 Day Timeout
                    curl_setopt($ch, CURLOPT_INFILE, $fp);
                    curl_setopt($ch, CURLOPT_NOPROGRESS, false);
                    curl_setopt($ch, CURLOPT_PROGRESSFUNCTION, 'CURL_callback');
                    curl_setopt($ch, CURLOPT_BUFFERSIZE, 128);
                    curl_setopt($ch, CURLOPT_INFILESIZE, filesize($sqlFilePath));
                    curl_exec($ch);
                    curl_close($ch);
                    fclose($fp);

                    //unlink($sqlFilePath);

            //END : Create SQL file of the complete Database.
            exit;
	}
	
	public function backupDatabase()
	{
		$contents = $this->backupDatabaseDetails();
		//Save backup database file
		$filename = 'backup/db/db-backup-'.date('Y-m-d_H-i-s').'.sql';	
		$handle = fopen($filename,'w+');
		fwrite($handle,$contents);
		fclose($handle);
		exit;
	}
	
	function &backupDatabaseDetails($tables = '*')
	{
	  $data = "\n/*---------------------------------------------------------------".
			  "\n  SQL DB BACKUP ".date("d.m.Y H:i")." ".
			  "\n  TABLES: {$tables}".
			  "\n  ---------------------------------------------------------------*/\n";
	  
	  $this->db->query( "SET NAMES `utf8` COLLATE `utf8_general_ci`"); 

	  if($tables == '*')
	  { //get all of the tables
		$tables = array();
		$result = $this->db->query("SHOW TABLES");
		
		if ($result->num_rows() > 0)
		{
		   foreach($result->result_array() as $row)
		   {		   
			$tables[] = $row['Tables_in_relay_db'];
			}
		}
	  }else{
		$tables = is_array($tables) ? $tables : explode(',',$tables);
	  }

		foreach($tables as $table)
		{
			$data.= "\n/*---------------------------------------------------------------".
					"\n  TABLE: `{$table}`".
					"\n  ---------------------------------------------------------------*/\n";           
			$data.= "DROP TABLE IF EXISTS `{$table}`;\n";
			$res = $this->db->query("SHOW CREATE TABLE `{$table}`");
		
			if ($res->num_rows() > 0)
			{
				foreach($res->result_array() as $row)
				{
					$data.= $row['Create Table'].";\n";
				}
			}

			$result = $this->db->query("SELECT * FROM `{$table}`");
			$num_rows = $result->num_rows();    

			if($num_rows>0)
			{
			  $vals = Array(); $z=0;
			  foreach($result->result_array() as $items)
			  {
				  $vals[$z]="(";
				  $numItems = count($items);
				  $i = 0;
				  foreach($items as $column => $value)
				  {
					  if (isset($value)) 
					  {	
						$vals[$z].= "'".mysql_real_escape_string($value)."'"; 
					  }	
					  else 
					  { 
						$vals[$z].= "NULL"; 
					  }
					  
					  if(++$i === $numItems) {}
					  else
					  {
						$vals[$z].= ","; 
					  }
				  }
				  
				$vals[$z].= ")"; $z++;
			  }
			  $data.= "INSERT INTO `{$table}` VALUES ";      
			  $data .= "  ".implode(";\nINSERT INTO `{$table}` VALUES ", $vals).";\n";
			}
		  }
		 return $data;
	 }
	 
	 /**
	  * Function to Start Scheduled custom Program by checking the current Time.
	  * @param 
	  * @return 
	 **/
	 public function startScheduleCustomProgram()
	 {
		$this->load->model('device_model');
		$this->load->model('home_model');
		
		list($sIP,$sPort,$extra) = $this->home_model->getSettings();

		$iActiveMode 	=  $this->home_model->getActiveMode();
		$sTime          =   date('H:i:s',time());
		
		//Get All Schedule Custom Programs.
		$aAllScheduledProgram = $this->device_model->getScheduleProgram(); 
		
		if(!empty($aAllScheduledProgram))
		{
			//Get All IP Details.
			$aIPDetails = $this->home_model->getBoardIP();
			
			list($sIP,$sPort,$extra) = $this->home_model->getSettings();
			
			//Get IP Details
			foreach($aIPDetails as $IP)
			{
				${'shhPort'.$IP->id}	=	'';
				if(IS_LOCAL == '1')
				{
					//Get SSH port of the RLB board using IP.
					${'shhPort'.$IP->id} = $this->home_model->getSSHPortFromID($IP->id);
				}
				$sResponse		=	array();
				$sValves        =   ''; 
				$sRelays        =   '';  
				$sPump			=	'';	
				
				//Get the status response of devices from relay board.
				$sResponse      =   get_rlb_status($IP->ip,$sPort,$shhPort);
			
				$sValves        =   $sResponse['valves']; // Valve Device Status
				$sRelays        =   $sResponse['relay'];  // Relay Device Status
				$sPowerCenter   =   $sResponse['powercenter']; // Power Center Device Status
				$sDayret        =   $sResponse['day'];
				
				${'sRelays'.$IP->id} 		=	$sRelays;
				${'sValves'.$IP->id} 		=	$sValves;
				${'sPowerCenter'.$IP->id} 	=	$sPowerCenter;  
				
				${'sPump'.$IP->id}	=	array($sResponse['pump_seq_0_st'],$sResponse['pump_seq_1_st'],$sResponse['pump_seq_2_st']);
				${'board'.$IP->id} 	=	$IP->ip;
				
				$arrExtraDetails[$IP->id] = array('sValves'=>${'sValves'.$IP->id},'board'=>${'board'.$IP->id},'shhPort'=>${'shhPort'.$IP->id});
			}//END : Get IP Details.
			
			foreach($aAllScheduledProgram as $customProgram)
			{
				$ProgramID			  	= $customProgram->id;
				$ProgramScheduleStart 	= $customProgram->program_schedule_start;
				$ProgramScheduleEnd 	= $customProgram->program_schedule_end;
				$sProgramType   		= $customProgram->program_type;
                $sProgramDays   		= $customProgram->program_days;
				$uniqueID				= rand(1000000,9999999).time();
				
				$sDays          =   '';
                $aDays          =   array();
				
				if($sProgramType == 2)
                {
                    $sDays = str_replace('7','0', $sProgramDays);
                    $aDays = explode(',',$sDays);
                }
				
				if($sProgramType == 1 || ($sProgramType == 2 && in_array($sDayret, $aDays)))
				{
					if($sTime >= $ProgramScheduleStart && $sTime < $ProgramScheduleEnd)
					{
						//Check the Mode, if not manual then ON manual mode.
						if($iActiveMode != 1)
						{
							$iMode	= 1;
							$this->home_model->updateMode($iMode);
						}
						
						$aCurrentDetails 	=	json_decode($customProgram->program_details);
						$CurrentValveDevice	=	explode(",",$aCurrentDetails->g_rlb_valve_list);
						$afterProgram	 	=	$customProgram->afterProgram;
						
						//START : Get the first device of the custom program from all Devices.
						if(isset($aCurrentDetails->g_rlb_pump_list) && $aCurrentDetails->g_rlb_pump_list != '')
						{
							//Pump Device Details.
							$pumpDevice		=	explode(",",$aCurrentDetails->g_rlb_pump_list);
							$pumpSequence	=	explode(",",$aCurrentDetails->g_pump_sq);
							$pumpTime		=	explode(",",$aCurrentDetails->g_pump_time);
						}
						
						if(isset($aCurrentDetails->g_rlb_valve_list) && $aCurrentDetails->g_rlb_valve_list != '')
						{
							//Valve Device Details
							$valveDevice	=	explode(",",$aCurrentDetails->g_rlb_valve_list);	
							$valveSequence	=	explode(",",$aCurrentDetails->g_valve_sq);	
							$valveTime		=	explode(",",$aCurrentDetails->g_valve_time);
						}

						if(isset($aCurrentDetails->g_rlb_relay_list) && $aCurrentDetails->g_rlb_relay_list != '')
						{
							//Relay Device Details
							$relayDevice	=	explode(",",$aCurrentDetails->g_rlb_relay_list);	
							$relaySequence	=	explode(",",$aCurrentDetails->g_relay_sq);	
							$relayTime		=	explode(",",$aCurrentDetails->g_relay_time);				
						}
						
						if(isset($aCurrentDetails->g_rlb_powercenter_list) && $aCurrentDetails->g_rlb_powercenter_list != '')
						{
							//Relay Device Details
							$powerCenterDevice	=	explode(",",$aCurrentDetails->g_rlb_powercenter_list);	
							$powerCenterSequence	=	explode(",",$aCurrentDetails->g_powercenter_sq);	
							$powerCenterTime		=	explode(",",$aCurrentDetails->g_powercenter_time);				
						}
										
						if(!empty($pumpSequence))
						{
							foreach($pumpSequence as $seq => $key)
							{
								if($key != '')
								{
									if(!array_key_exists($key,$arrSequnceDevice))
									$arrSequnceDevice[$key] = array();
									
									array_push($arrSequnceDevice[$key],$pumpDevice[$seq].'|||'.$pumpTime[$seq].'|||PS');
								}
							}
						}
						
						//$valveSequence	=	array_flip($valveSequence);
						
						$arrAfterProgramDevice = array();
						if(!empty($valveSequence))
						{
							$k = 1;
							foreach($valveSequence as $seq => $key)
							{
								if($key != '')
								{
									if(!array_key_exists($key,$arrSequnceDevice))
									$arrSequnceDevice[$key] = array();
								
									array_push($arrSequnceDevice[$key],$valveDevice[$seq].'|||'.$valveTime[$seq].'|||V');
									
									//Valve to run after program end.
									$arr	=	explode('_',$valveDevice[$seq]);
									$strPosition = '';
									if($arr[1] == 1)
									{
										$strPosition = 2;
									}
									else if($arr[1] == 2)
									{
										$strPosition = 1;
									}
									
									$valveAfterProgram = $arr[0].'_'.$strPosition.'_'.$arr[2];
									
									$arrAfterProgramDevice[$k] = $valveAfterProgram.'|||'.$valveTime[$seq].'|||V';
									
									$k++;
								}
							}
						}
						
						if(!empty($relaySequence))
						{
							foreach($relaySequence as $seq => $key)
							{
								if($key != '')
								{
									if(!array_key_exists($key,$arrSequnceDevice))
									$arrSequnceDevice[$key] = array();
									
									array_push($arrSequnceDevice[$key],$relayDevice[$seq].'|||'.$relayTime[$seq].'|||R');
								}
							}
						}
						
						if(!empty($powerCenterSequence))
						{
							foreach($powerCenterSequence as $seq => $key)
							{
								if($key != '')
								{
									if(!array_key_exists($key,$arrSequnceDevice))
									$arrSequnceDevice[$key] = array();
									
									array_push($arrSequnceDevice[$key],$powerCenterDevice[$seq].'|||'.$powerCenterTime[$seq].'|||P');
								}
							}
						}
						ksort($arrSequnceDevice);
						
						//START : First Device ON.
						foreach($arrSequnceDevice[1] as $devices)
						{
							//START :STOP ALL Devices Running in after program for the same program which is going to start.
							if($afterProgram == '1')	
							{
								$currentDeviceAfter = $this->custom_model->getCustomProgrmaAfterDevice($ProgramID);
								if($currentDeviceAfter != '')
								{
									$lastElement = end($currentDeviceAfter);
									
									foreach($currentDeviceAfter as $deviceDetails)
									{
										$currentSeq		=	$deviceDetails->current_sequence;
										$deviceType 	=   $deviceDetails->device_type;
										$ipID			=	$deviceDetails->ip_id;
										$sStatus		=	0;
										$deviceNumber	=	$deviceDetails->device_number;
										
										$sNewResp = replace_return($arrExtraDetails[$ipID]['sValves'], $sStatus, $deviceNumber);
										$arrExtraDetails[$ipID]['sValves'] = $sNewResp;
										onoff_rlb_valve($sNewResp,$arrExtraDetails[$ipID]['board'],$sPort,$arrExtraDetails[$ipID]['shhPort']);
										
										
										//Insert Entry in the Log Table for future Reference.
										$this->custom_model->saveCustomAfterEntryInLog($ProgramID,$deviceType);
										
										//Delete Entry From the current details Table.
										$this->custom_model->deleteCustomEntryFromAfter($ProgramID,$deviceType,$deviceNumber);
										
									}
								}
								
								$this->home_model->updateAfterProgram($ProgramID,'0');
							}
							//STOP : STOP ALL Devices Running in after program for the same program which is going to start.
							
							//Start Custom Program.
							$this->home_model->startCustomProgram($ProgramID,$uniqueID);
							
							//START : To store the current position of Valve before starting first Device of Program.
							$arrValveKeepOn		   = array();
							if(!empty($valveSequence))
							{
								$k = 1;
								foreach($valveSequence as $seq => $key)
								{
									if($key != '')
									{
										if(!array_key_exists($key,$arrSequnceDevice))
										$arrSequnceDevice[$key] = array();
									
										array_push($arrSequnceDevice[$key],$valveDevice[$seq].'|||'.$valveTime[$seq].'|||V');
										
										//Valve to run after program end.
										$arr	=	explode('_',$valveDevice[$seq]);
										$strPosition = '';
										if($arr[1] == 1)
										{
											$strPosition = 2;
										}
										else if($arr[1] == 2)
										{
											$strPosition = 1;
										}
										
										$arrTemp 			=	explode("_",$valveDevice[$seq]);
										$ipIDTemp			=	$arrTemp[0];
										$sStatusTemp		=	$arrTemp[1];
										$deviceNumberTemp	=	$arrTemp[2];
										
										$existingStatus 	=	${'sValves'.$ipIDTemp}[$deviceNumberTemp];
										
										$arrValveKeepOn[]	= $ipIDTemp.'_'.$existingStatus.'_'.$deviceNumberTemp;
									}
								}
								
								$this->home_model->updateExistingStatusValveForProgram($ProgramID,$arrValveKeepOn);
								
							}
							//END : To store the current position of Valve before starting first Device of Program.
							
							 $aCurrentDevice	=	explode('|||',$devices);
							//START: First make valve device ON in the sequence.
							$sStatus		=	'1';
							$sRunTime		=	$aCurrentDevice[1];
							$deviceType 	=   $aCurrentDevice[2];
							$aDevice		=	explode("_",$aCurrentDevice[0]);
							if($deviceType == 'V')
							{
								$ipID			=	$aDevice[0];
								$sStatus		=	$aDevice[1];
								$deviceNumber	=	$aDevice[2];
							}
							else if($deviceType == 'PS' || $deviceType == 'R' || $deviceType == 'P')
							{
								$ipID			=	$aDevice[0];
								$deviceNumber	=	$aDevice[1];
							}
							
							if($deviceType	==	'PS')
							{
								require_once(APPPATH.'controllers/cron.php');
								$aObjCron = new Cron();   
								$aObjCron->cronMakePumpOnOFF($deviceNumber,$sStatus,${'board'.$ipID},$sPort,${'shhPort'.$ipID},$ipID);
								$strDevice		=	'Pump '.$deviceNumber;
							}
							else if($deviceType	== 'V')
							{
								$sNewResp = replace_return(${'sValves'.$ipID}, $sStatus, $deviceNumber);
								${'sValves'.$ipID} = $sNewResp;
								onoff_rlb_valve($sNewResp,${'board'.$ipID},$sPort,${'shhPort'.$ipID});
								
								$strDevice	=	'Valve '.$deviceNumber;	
							}
							else if($deviceType	== 'R')
							{
								$sNewResp = replace_return(${'sRelays'.$ipID}, $sStatus, $deviceNumber);
								${'sRelays'.$ipID} = $sNewResp;
								onoff_rlb_relay($sNewResp,${'board'.$ipID},$sPort,${'shhPort'.$ipID});
								
								$heaterNum = $this->home_model->chkHeater($deviceNumber,'24',$ipID);
											
								if($heaterNum != '')
								{
									$aHeaterDetails  =   $this->home_model->getHeaterDeviceDetails($heaterNum,$ipID);
									if(!empty($aHeaterDetails))
									{
										foreach($aHeaterDetails as $aHeater)
										{
											$sHeaterDetails  =   unserialize($aHeater->light_relay_number);
										}
										
										$PumpNumber   		=   $sHeaterDetails['Pump'];
									}
									if($PumpNumber != '')
									{
										$aPumpDetails =	$this->home_model->getPumpDetails($PumpNumber,$ipID);
										if(!empty($aPumpDetails))
										{
											foreach($aPumpDetails as $sPump)
											{
												//$this->cronMakePumpOnOFF($PumpNumber,'1',${'board'.$ipID},$sPort,${'shhPort'.$ipID},$ipID);
												
												require_once(APPPATH.'controllers/cron.php');
												$aObjCron = new Cron();   
												$aObjCron->cronMakePumpOnOFF($PumpNumber,'1',${'board'.$ipID},$sPort,${'shhPort'.$ipID},$ipID);
											}
										}
									}
								}
								
								$strDevice	=	'Relay '.$deviceNumber;	
							}
							else if($deviceType	== 'P')
							{
								$sNewResp = replace_return(${'sPowerCenter'.$ipID}, $sStatus, $deviceNumber);
								${'sPowerCenter'.$ipID} = $sNewResp;
								onoff_rlb_powercenter($sNewResp,${'board'.$ipID},$sPort,${'shhPort'.$ipID});
								
								$heaterNum = $this->home_model->chkHeater($deviceNumber,'12',$ipID);
														
								if($heaterNum != '')
								{
									$aHeaterDetails  =   $this->home_model->getHeaterDeviceDetails($heaterNum,$ipID);
									if(!empty($aHeaterDetails))
									{
										foreach($aHeaterDetails as $aHeater)
										{
											$sHeaterDetails  =   unserialize($aHeater->light_relay_number);
										}
										
										$PumpNumber   		=   $sHeaterDetails['Pump'];
									}
									if($PumpNumber != '')
									{
										$aPumpDetails =	$this->home_model->getPumpDetails($PumpNumber,$ipID);
										if(!empty($aPumpDetails))
										{
											foreach($aPumpDetails as $sPump)
											{
												//$this->cronMakePumpOnOFF($PumpNumber,'1',${'board'.$ipID},$sPort,${'shhPort'.$ipID},$ipID);
												
												require_once(APPPATH.'controllers/cron.php');
												$aObjCron = new Cron();   
												$aObjCron->cronMakePumpOnOFF($sPump->pump_number,'1',${'board'.$ipID},$sPort,${'shhPort'.$ipID},$ipID);
											}
										}
									}
								}
								
								$strDevice	=	'Power Center '.$deviceNumber;
							}
							
							$arrDetails		=	array('program_id'=>$ProgramID,
													  'current_on_device'=>$strDevice,
													  'device_type'=>$deviceType,
													  'device_number'=>$deviceNumber,
													  'current_on_time'=>$sRunTime,
													  'current_sequence'=>1,
													  'ip_id'=>$ipID,
													  'unique_id'=>$uniqueID);
							
							$this->custom_model->saveCustomCurrentRunningDevice($arrDetails);
						}
						//END : First Device ON. 
					}
					else if($sTime >= $ProgramScheduleEnd)
					{
						$afterProgram = 0;
						$programDetails = $this->home_model->getCustomProgramDetails($ProgramID);
						foreach($programDetails as $customProgram)
						{
							$aProgramDetails =	json_decode($customProgram->program_details);
							$previousState	 = 	unserialize($customProgram->previousState);
							
							if(isset($aProgramDetails->g_rlb_valve_list) && $aProgramDetails->g_rlb_valve_list != '')
							{
								//Valve Device Details
								$valveDevice	=	explode(",",$aProgramDetails->g_rlb_valve_list);	
								$valveSequence	=	explode(",",$aProgramDetails->g_valve_sq);	
								$valveTime		=	explode(",",$aProgramDetails->g_valve_time);
							}

							$arrAfterProgramDevice = array();
							if(!empty($valveSequence))
							{
								$k = 1;
								foreach($valveSequence as $seq => $key)
								{
									if(!array_key_exists($key,$arrSequnceDevice))
									$arrSequnceDevice[$key] = array();
								
									//Valve to run after program end.
									$arr	=	explode('_',$valveDevice[$seq]);
									$strPosition = '';
									if($arr[1] == 1)
									{
										$strPosition = 2;
									}
									else if($arr[1] == 2)
									{
										$strPosition = 1;
									}
									
									$arrTemp 			=	explode("_",$valveDevice[$seq]);
									$ipIDTemp			=	$arrTemp[0];
									$sStatusTemp		=	$arrTemp[1];
									$deviceNumberTemp	=	$arrTemp[2];
									
									//$tempDevice			=	$ipIDTemp.'_'.$existingStatus.'_'.$deviceNumberTemp;
									
									$valveAfterProgram = $arr[0].'_'.$strPosition.'_'.$arr[2];
									
									//if($existingStatus != $sStatusTemp)
									if(!in_array($valveDevice[$seq],$previousState))	
									{
										$lastRun = $this->home_model->getDeviceLastRun($deviceNumberTemp,'V',$ipIDTemp);
										
										if($lastRun != $sStatusTemp)
										{
											$arrAfterProgramDevice[$key] = $valveAfterProgram.'|||'.$valveTime[$seq].'|||V';
										
											$k++;
										}
									}
									else
									{
										$arrValveKeepOn[] = $ipIDTemp.'_'.$deviceNumberTemp;
									}
									
									//$valveAfterProgram = $arr[0].'_'.$strPosition.'_'.$arr[2];
									
									//$arrAfterProgramDevice[$k] = $valveAfterProgram.'|||'.$valveTime[$seq].'|||V';
									
									//$k++;
								}
							}
							
							if(!empty($arrAfterProgramDevice))
							{
								$afterProgram	=	1;
							}
						}
						
						//Stop Custom Program.
						$this->home_model->stopCustomProgram($ProgramID,$afterProgram);
						
						$currentDevice = $this->custom_model->getCustomProgrmaCurrentDevice($ProgramID);
						
						if($currentDevice != '')
						{
							foreach($currentDevice as $deviceDetails)
							{
								$currentSeq		=	$deviceDetails->current_sequence;
								$deviceType 	=   $deviceDetails->device_type;
								$ipID			=	$deviceDetails->ip_id;
								$sStatus		=	0;
								$deviceNumber	=	$deviceDetails->device_number;
								
								$sDeviceIP		= 	$this->home_model->getBoardIPFromID($ipID);
								list($sIP,$sPort,$extra) = $this->home_model->getSettings();
					
								
								$shhPort	=	'';
								if(IS_LOCAL == '1')
								{
									//Get SSH port of the RLB board using IP.
									$shhPort = $this->home_model->getSSHPortFromID(ipID);
								}
								$sResponse		=	array();
								$sValves        =   ''; 
								$sRelays        =   '';  
								$sPump			=	'';	
								
								//Get the status response of devices from relay board.
								$sResponse      =   get_rlb_status($sDeviceIP,$sPort,$shhPort);
							
								$sValves        =   $sResponse['valves']; // Valve Device Status
								$sRelays        =   $sResponse['relay'];  // Relay Device Status
								$sPowerCenter   =   $sResponse['powercenter']; // Power Center Device Status
								
								${'sPump'.$IP->id}	=	array($sResponse['pump_seq_0_st'],$sResponse['pump_seq_1_st'],$sResponse['pump_seq_2_st']);
								
								if($deviceType == 'V')
								{
									$sNewResp = replace_return($sValves, $sStatus, $deviceNumber);
									$sValves = $sNewResp;
									onoff_rlb_valve($sNewResp,$sDeviceIP,$sPort,$shhPort);
								}
								else if($deviceType == 'PS')
								{	
									$this->cronMakePumpOnOFF($deviceNumber,$sStatus,$sDeviceIP,$sPort,$shhPort,$ipID);
								}
								else if($deviceType	== 'R')
								{
									$sNewResp = replace_return($sRelays, $sStatus, $deviceNumber);
									$sRelays = $sNewResp;
									onoff_rlb_relay($sNewResp,$sDeviceIP,$sPort,$shhPort);
									
									//START : Check if heater is assigned to that relay.
									$heaterNum = $this->home_model->chkHeater($deviceNumber,'24',$ipID);
									
									if($heaterNum != '')
									{
										$aHeaterDetails  =   $this->home_model->getHeaterDeviceDetails($heaterNum,$ipID);
										if(!empty($aHeaterDetails))
										{
											foreach($aHeaterDetails as $aHeater)
											$sHeaterDetails  =   unserialize($aHeater->light_relay_number);
											
											$PumpNumber   		=   $sHeaterDetails['Pump'];
										}
										if($PumpNumber != '')
										{
											$aPumpDetails =	$this->home_model->getPumpDetails($PumpNumber,$ipID);
											if(!empty($aPumpDetails))
											{
												foreach($aPumpDetails as $sPump)
												{
													$heaterStopTime =	date('Y-m-d H:i:s');
													$arrStopTime	=	explode(" ",$heaterStopTime);
													$aDate     		=   explode("-",$arrStopTime[0]);
													$aTime     		=   explode(":",$arrStopTime[1]);
													
													$sProgramAbsEnd =   mktime(($aTime[0]),($aTime[1]+5),($aTime[2]),$aDate[1],$aDate[2],$aDate[0]);
													$pumpStopTime   =   date("Y-m-d H:i:s", $sProgramAbsEnd);
													
													$this->home_model->updateRunAfterHeaterDetails($heaterNum,$sPump->pump_number,$heaterStopTime,$pumpStopTime,$ipID,$ProgramID);
												}
											}
										}
									}
								}
								else if($deviceType	== 'P')
								{
									$sNewResp = replace_return($sPowerCenter, $sStatus, $deviceNumber);
									$sPowerCenter = $sNewResp;
									onoff_rlb_powercenter($sNewResp,$sDeviceIP,$sPort,$shhPort);
									//START : Check if heater is assigned to that relay.
									$heaterNum = $this->home_model->chkHeater($deviceNumber,'12',$ipID);
									
									if($heaterNum != '')
									{
										$aHeaterDetails  =   $this->home_model->getHeaterDeviceDetails($heaterNum,$ipID);
										if(!empty($aHeaterDetails))
										{
											foreach($aHeaterDetails as $aHeater)
											$sHeaterDetails  =   unserialize($aHeater->light_relay_number);
											
											$PumpNumber   		=   $sHeaterDetails['Pump'];
										}
										if($PumpNumber != '')
										{
											$aPumpDetails =	$this->home_model->getPumpDetails($PumpNumber,$ipID);
											if(!empty($aPumpDetails))
											{
												foreach($aPumpDetails as $sPump)
												{
													$heaterStopTime =	date('Y-m-d H:i:s');
													$arrStopTime	=	explode(" ",$heaterStopTime);
													$aDate     		=   explode("-",$arrStopTime[0]);
													$aTime     		=   explode(":",$arrStopTime[1]);
													
													$sProgramAbsEnd =   mktime(($aTime[0]),($aTime[1]+5),($aTime[2]),$aDate[1],$aDate[2],$aDate[0]);
													$pumpStopTime   =   date("Y-m-d H:i:s", $sProgramAbsEnd);
													
													$this->home_model->updateRunAfterHeaterDetails($heaterNum,$sPump->pump_number,$heaterStopTime,$pumpStopTime,$ipID,$ProgramID);
												}
											}
										}
									}
								}
								
								//Insert Entry in the Log Table for future Reference.
								$this->custom_model->saveCustomEntryInLog($ProgramID,$deviceType);
							
								//Delete Entry From the current details Table.
								$this->custom_model->deleteCustomEntryFromCurrent($ProgramID,$deviceType,$deviceNumber);
							}
						}
					}
				}
			}//END : foreach($aAllScheduledProgram as $customProgram) 
		}//END: if(!empty($aAllScheduledProgram))
	 }//END : startScheduleCustomProgram
	
	 /**
	  * Function to Keep heater ON for getting the desired Temperature.
	  * @param 
	  * @return 
	 **/
	 public function keepHeaterOnForTemperature()
	 {
		$this->load->model('home_model');
		$this->load->model('device_model');
		list($sIP,$sPort,$extra)	=	$this->home_model->getSettings();
		$iMode          			=	$this->home_model->getActiveMode();
		
		$arrAllRunningHeaters = $this->device_model->getAllRunningHeaters();
		
		if(!empty($arrAllRunningHeaters))
		{
			//Get All IP Details.
			$aIPDetails = $this->home_model->getBoardIP();
			foreach($aIPDetails as $IP)
			{
				${'shhPort'.$IP->id}	=	'';
				if(IS_LOCAL == '1')
				{
					//Get SSH port of the RLB board using IP.
					${'shhPort'.$IP->id} = $this->home_model->getSSHPortFromID($IP->id);
				}
				$sResponse		=	array();
				$sValves        =   ''; 
				$sRelays        =   '';  
				$sPump			=	'';	
				
				//Get the status response of devices from relay board.
				$sResponse      =   get_rlb_status($IP->ip,$sPort,$shhPort);
				$sRelays        =   $sResponse['relay'];  // Relay Device Status
				$sPowerCenter   =   $sResponse['powercenter']; // Power Center Device Status
				// Temperature Sensor Device 
				$sTemprature    =   array($sResponse['TS0'],$sResponse['TS1'],$sResponse['TS2'],$sResponse['TS3'],$sResponse['TS4'],$sResponse['TS5']);
				
				
				${'sRelays'.$IP->id} 		=	$sRelays;
				${'sPowerCenter'.$IP->id} 	=	$sPowerCenter;  
				${'board'.$IP->id} 			=	$IP->ip;
				${'tempe'.$IP->id} 			=	$sTemprature;
			}
			
			foreach($arrAllRunningHeaters as $Heater)
			{
				$HeaterNumber 	=	$Heater->heaterNumber;
				$IpID 			=	$Heater->ip_id;
				$HeaterStart	=	$Heater->heaterStart;
				$HeaterEnd		=	$Heater->heaterEnd;
				
				//Get Heater Details.
				$aHeaterDetails  =   $this->home_model->getHeaterDeviceDetails($HeaterNumber,$IpID);
				
				if(!empty($aHeaterDetails))
				{
					foreach($aHeaterDetails as $aHeater)
					$arrHeaterDetails  	=	unserialize($aHeater->light_relay_number);
					$sRelayType			=	$arrHeaterDetails['sRelayType'];
					$sRelayNumber		=	$arrHeaterDetails['sRelayNumber'];
					
					$TemperatureSensor 	=	$arrHeaterDetails['Temeprature'];
					$MaxTemp 			=	$arrHeaterDetails['maxTemp'];
					$DesireTemp 	   	=	$arrHeaterDetails['desireTemp'];
					$Pump 	   	=	$arrHeaterDetails['Pump'];
					
					
					
					//GET IP of Device
					$sDeviceIP		= 	$this->home_model->getBoardIPFromID($IpID);
					$shhPort	=	'';
					if(IS_LOCAL == '1')
					{
						//Get SSH port of the RLB board using IP.
						$shhPort = $this->home_model->getSSHPortFromID($IpID);
					}
					
					if(strtotime($HeaterEnd) > strtotime(date('Y-m-d H:i:s')))
					{
						if($MaxTemp > ${'tempe'.$IpID}[$TemperatureSensor])
						{
							if(${'tempe'.$IpID}[$TemperatureSensor] >= $DesireTemp)
							{
								$sStatus	=	0;
								if($sRelayType == 24)	
								{
									$sNewResp = replace_return(${'sRelays'.$IpID}, $sStatus, $sRelayNumber);
									onoff_rlb_relay($sNewResp,$sDeviceIP,$sPort,$shhPort);
									$this->home_model->updateDeviceRunTime($sRelayNumber,'R',$sStatus);
								}
								else
								{
									$sNewResp = replace_return(${'sPowerCenter'.$IpID}, $sStatus, $sRelayNumber);
									onoff_rlb_powercenter($sNewResp,$sDeviceIP,$sPort,$shhPort);	
								}
							}
							else if(${'tempe'.$IpID}[$TemperatureSensor] < $DesireTemp)
							{
								$sStatus	 = 1;
								if($sRelayType == 24)	
								{
									$existStatus = ${'sRelays'.$IpID}[$sRelayNumber];
									if($existStatus == '0')
									{
										$sNewResp = replace_return(${'sRelays'.$IpID}, $sStatus, $sRelayNumber);
										onoff_rlb_relay($sNewResp,$sDeviceIP,$sPort,$shhPort);
										$this->home_model->updateDeviceRunTime($sRelayNumber,'R',$sStatus);
									}
								}
								else							
								{
									if($sRelayType == 12)	
									{
										$existStatus = ${'sPowerCenter'.$IpID}[$sRelayNumber];
										if($existStatus == '0')
										{
											$sNewResp = replace_return(${'sPowerCenter'.$IpID}, $sStatus, $sRelayNumber);
											onoff_rlb_powercenter($sNewResp,$sDeviceIP,$sPort,$shhPort);
										}
									}
								}
							}
								
						}
					}
					else
					{
						$sStatus	=	0;
						if($sRelayType == 24)	
						{
							$sNewResp = replace_return(${'sRelays'.$IpID}, $sStatus, $sRelayNumber);
							onoff_rlb_relay($sNewResp,$sDeviceIP,$sPort,$shhPort);
							$this->home_model->updateDeviceRunTime($sRelayNumber,'R',$sStatus);
						}
						else
						{
							$sNewResp = replace_return(${'sPowerCenter'.$IpID}, $sStatus, $sRelayNumber);
							onoff_rlb_powercenter($sNewResp,$sDeviceIP,$sPort,$shhPort);	
						}
						
						$this->home_model->updateHeaterRunDetails($HeaterNumber,$IpID);
						
						$heaterStopTime =	date('Y-m-d H:i:s');
						$arrStopTime	=	explode(" ",$heaterStopTime);
						$aDate     		=   explode("-",$arrStopTime[0]);
						$aTime     		=   explode(":",$arrStopTime[1]);
						
						$sProgramAbsEnd =   mktime(($aTime[0]),($aTime[1]+5),($aTime[2]),$aDate[1],$aDate[2],$aDate[0]);
						$pumpStopTime   =   date("Y-m-d H:i:s", $sProgramAbsEnd);
						
						$this->home_model->updateRunAfterHeaterDetails($HeaterNumber,$Pump,$heaterStopTime,$pumpStopTime,$IpID);
					}
					
				}
			}
		}
		
	 }

	public function heaterDetailsUpdateC($heaterNumber,$sIdIP,$sStatus)
	{
		$this->load->model('home_model');
		//GET IP of Device
		$sDeviceIP		= 	$this->home_model->getBoardIPFromID($sIdIP);
		
		//Get saved IP and PORT 
		list($sIP,$sPort,$extra) = $this->home_model->getSettings();
		
		$shhPort	=	'';
		if(IS_LOCAL == '1')
		{
			//Get SSH port of the RLB board using IP.
			$shhPort = $this->home_model->getSSHPortFromID($sIdIP);
		}
		
		$aHeaterDetails  =   $this->home_model->getHeaterDeviceDetails($heaterNumber,$sIdIP);
		if(!empty($aHeaterDetails))
		{
			foreach($aHeaterDetails as $aHeater)
			$sHeaterDetails  =   unserialize($aHeater->light_relay_number);
			
			$PumpNumber   		=   $sHeaterDetails['Pump'];
		}
		
		$this->home_model->updateHeaterRunDetails($heaterNumber,$sIdIP);
		$allOnPumps = $this->home_model->getOnPumpOfHeaters();
		if(!empty($allOnPumps))
		{
			foreach($allOnPumps as $pumpDetails)
			{
				$id			  = $pumpDetails->id;
				$this->home_model->updateRunCompletePump($id,'1');
			}
		}
	}
	
	public function heaterDetailsUpdatePump($heaterNumber,$sIdIP,$sStatus)
	{
		$this->load->model('home_model');
		//GET IP of Device
		$sDeviceIP		= 	$this->home_model->getBoardIPFromID($sIdIP);
		
		//Get saved IP and PORT 
		list($sIP,$sPort,$extra) = $this->home_model->getSettings();
		
		$shhPort	=	'';
		if(IS_LOCAL == '1')
		{
			//Get SSH port of the RLB board using IP.
			$shhPort = $this->home_model->getSSHPortFromID($sIdIP);
		}
		
		$aHeaterDetails  =   $this->home_model->getHeaterDeviceDetails($heaterNumber,$sIdIP);
		if(!empty($aHeaterDetails))
		{
			foreach($aHeaterDetails as $aHeater)
			$sHeaterDetails  =   unserialize($aHeater->light_relay_number);
			
			$PumpNumber   		=   $sHeaterDetails['Pump'];
		}
		
		if($PumpNumber != '')
		{
			$this->cronMakePumpOnOFF($PumpNumber,$sStatus,$sDeviceIP,$sPort,$shhPort,$sIdIP);
		}
		$this->home_model->updateHeaterRunDetails($heaterNumber,$sIdIP);
		
		$allOnPumps = $this->home_model->getOnPumpOfHeater($heaterNumber);
		if(!empty($allOnPumps))
		{
			foreach($allOnPumps as $pumpDetails)
			{
				$id			  = $pumpDetails->id;
				$this->home_model->updateRunCompletePump($id,'1');
			}
		}
	}
	
	/**
	* Function to Check if the Valve Default Position Run time is over if yes the stop that valve.
	* @param : 
	* @return :
	**/
	public function stopValveDefaultPosition()
	{
		$this->load->model('home_model');
		
		$arrValveDetails = $this->home_model->getAllValveDefaultPositionRunnig();
		if($arrValveDetails)
		{
			list($sIP,$sPort,$extra) = $this->home_model->getSettings();
			$currentTime = 	date('Y-m-d H:i:s');
			
			foreach($arrValveDetails as $valveDetails)
			{
				$valveEndTime	=	$valveDetails->end_time;
				$IpId			=	$valveDetails->ip_id;
				$Valve			=	$valveDetails->valve;
				
				if(strtotime($currentTime) >= strtotime($valveEndTime))
				{
					$Status		=	0;
					$sDeviceIP	= 	$this->home_model->getBoardIPFromID($IpId);
					$shhPort	=	'';
					if(IS_LOCAL == '1')
					{
						//Get SSH port of the RLB board using IP.
						$shhPort = $this->home_model->getSSHPortFromID($IpId);
					}
					$sResponse		=	array();
					$sValves        =   ''; 
					
					//Get the status response of devices from relay board.
					$sResponse      =   get_rlb_status($sDeviceIP,$sPort,$shhPort);
					$sValves        =   $sResponse['valves']; // Valve Device Status
				
					$sNewResp = replace_return($sValves, $Status, $Valve);
					$sValves = $sNewResp;
					onoff_rlb_valve($sNewResp,$sDeviceIP,$sPort,$shhPort);
					
					$this->home_model->removeDefaultRunDetails($valveDetails->id);
				}
			}			
		}
	}
	
	/**
	* Function to Delete the custom programs logs those are 30 days old.
	* @param : 
	* @return :
	**/
	public function deleteCustomProgramLogs()
	{
		$this->load->model('log_model');
		$this->log_model->deleteCustomProgramLog();
	}
	
	/**
	* Function to Delete the web services logs those are 30 days old.
	* @param : 
	* @return :
	**/
	public function deleteWebServiceLogs()
	{
		$this->load->model('log_model');
		$this->log_model->deleteWebServiceLog();
	}
	
	/**
	* Function to Check Water Level in POOL/SPA and keep maintaining the level for the desired measurement.
	* @param : 
	* @return :
	**/
	public function KeepDesiredWaterLevel()
	{
		$this->load->model('device_model');
		$this->load->model('home_model');
		
		list($sIP,$sPort,$extra)	=	$this->home_model->getSettings();
		//Get All IP Details.
		$aIPDetails = $this->home_model->getBoardIP();
		foreach($aIPDetails as $IP)
		{
			${'shhPort'.$IP->id}	=	'';
			if(IS_LOCAL == '1')
			{
				//Get SSH port of the RLB board using IP.
				${'shhPort'.$IP->id} = $this->home_model->getSSHPortFromID($IP->id);
			}
			
			$sResponse		=	array();
			$sValves        =   ''; 
			$sRelays        =   '';  
			$sPump			=	'';	
			
			//Get the status response of devices from relay board.
			$sResponse      =   get_rlb_status($IP->ip,$sPort,${'shhPort'.$IP->id});
			$sRelays        =   $sResponse['relay'];  // Relay Device Status
			$sPowerCenters        =   $sResponse['powercenter'];  // Relay Device Status
			$sValves        =   $sResponse['valves'];  // Relay Device Status
			$fltLevel		=	$sResponse['level_sensor_avg'];  // Avg Level Sensor.
			${'sRelays'.$IP->id} 		=	$sRelays;
			${'sPowerCenters'.$IP->id} 	=	$sPowerCenters;
			${'sValves'.$IP->id} 		=	$sValves;
			${'board'.$IP->id} 			=	$IP->ip;
			
			${'level_sensor_avg'.$IP->id} =	$fltLevel;
		}
		
		##Check if water is filling Already.
		$WaterFillingDeviceDetails = $this->device_model->getWaterLevelFillingDeviceDetails();
		if(!empty($WaterFillingDeviceDetails))
		{
			$DeviceNumber  	= $WaterFillingDeviceDetails->DeviceNumber;
			$DeviceType  	= $WaterFillingDeviceDetails->DeviceType;
			$DeviceIPID	  	= $WaterFillingDeviceDetails->DeviceIPID;
			$sStatus		= '0';
			//Check if Stop TIme is Passes or Not.
			$currentTime = date("Y-m-d H:i:s");
			if(strtotime($currentTime) > strtotime($WaterFillingDeviceDetails->StopTime) && $WaterFillingDeviceDetails->runComplete == '0')
			{
				//STOP Running Device.
				if($DeviceType == 'R') //IF assigned Device is 24V Relay.
				{
					$sNewResp = replace_return(${'sRelays'.$DeviceIPID}, $sStatus, $DeviceNumber );
		            #onoff_rlb_relay($sNewResp,${'board'.$DeviceIPID},$sPort,${'shhPort'.$DeviceIPID});
		            $this->home_model->updateDeviceRunTime($DeviceNumber,$DeviceType,$sStatus);
					
					//Start : Check if relay is assigned to Heater.
					$HeaterNumber = $this->home_model->chkHeater($DeviceNumber,'24',$DeviceIPID);
					if($HeaterNumber != '')
					{
						$this->heaterDetailsUpdate($HeaterNumber,$DeviceIPID,$sStatus);
					}
					else
					{
						list($pumpNumber,$relay1,$relay2)	=	$this->home_model->getPumpNumberFromRelayNumber($DeviceNumber,'24');
						if($pumpNumber != '')
						{
							//Check if the relay is assigned to pump or not.
							$aPumpDetails =	$this->home_model->getPumpDetails($pumpNumber,$DeviceIPID);
							if(!empty($aPumpDetails))
							{
								foreach($aPumpDetails as $sPump)
								{
									if($sStatus != '0')
									{
										if($relay1 == $DeviceNumber)
											$sStatus = '1';
										if($relay2 == $DeviceNumber)
											$sStatus = '2';
									}
									#$this->cronMakePumpOnOFF($sPump->pump_number,$sStatus,${'board'.$DeviceIPID},$sPort,${'shhPort'.$DeviceIPID},$DeviceIPID);
								}
							}
						}
					}
					//End : Check if relay is assigned to Heater.
				} //IF assigned Device is 24V Relay.
				if($DeviceType == 'P') //IF assigned Device is 12V Relay.
		        {
		            $sNewResp = replace_return(${'sPowerCenters'.$DeviceIPID}, $sStatus, $DeviceNumber);
		            #onoff_rlb_powercenter($sNewResp,${'board'.$DeviceIPID},$sPort,${'shhPort'.$DeviceIPID});
					
					//Start : Check if relay is assigned to Heater.
					$HeaterNumber = $this->home_model->chkHeater($DeviceNumber,'12',$DeviceIPID);
					if($HeaterNumber != '')
					{
						$this->heaterDetailsUpdate($HeaterNumber,$DeviceIPID,$sStatus);
					}
					else
					{
						list($pumpNumber,$relay1,$relay2)	=	$this->home_model->getPumpNumberFromRelayNumber($DeviceNumber,'12');
						
						if($pumpNumber != '')
						{
							//Check if the relay is assigned to pump or not.
							$aPumpDetails =	$this->home_model->getPumpDetails($pumpNumber,$DeviceIPID);
							if(!empty($aPumpDetails))
							{
								foreach($aPumpDetails as $sPump)
								{
									if($sStatus != '0')
									{
										if($relay1 == $DeviceNumber)
											$sStatus = '1';
										if($relay2 == $DeviceNumber)
											$sStatus = '2';
									}
									#$this->cronMakePumpOnOFF($sPump->pump_number,$sStatus,${'board'.$DeviceIPID},$sPort,${'shhPort'.$DeviceIPID},$DeviceIPID);
								}
							}
						}
					}
		        }//IF assigned Device is 12V Relay.
		        if($DeviceType == 'V') //IF assigned Device is Valve.
		        {
					//First Get the Current Status.
					$currentOnPosition = ${'sValves'.$DeviceIPID}[$DeviceNumber];
					
					if($currentOnPosition  != 0)
					{
						$this->home_model->saveLastRun($DeviceNumber,$DeviceType,$currentOnPosition,$DeviceIPID);
					}
					$sNewResp = replace_return(${'sValves'.$DeviceIPID}, $sStatus, $DeviceNumber);
					#onoff_rlb_valve($sNewResp,${'board'.$DeviceIPID},$sPort,${'shhPort'.$DeviceIPID});
				}//IF assigned Device is Valve.
		        if($DeviceType == 'PS') //IF assigned Device is Pump.
		        {
					#$this->cronMakePumpOnOFF($DeviceNumber,$sStatus,${'board'.$DeviceIPID},$sPort,${'shhPort'.$DeviceIPID},$DeviceIPID);
				}//IF assigned Device is Pump.

				$this->device_model->updateRunCompleteForWaterFillingDevice($WaterFillingDeviceDetails->id);
			}
			else if($WaterFillingDeviceDetails->runComplete == '1')
			{
				$StopTime 		= 	$WaterFillingDeviceDetails->StopTime;
				$arrStopTime	=	explode(" ",$StopTime);
				$aDate     		=   explode("-",$arrStopTime[0]);
				$aTime     		=   explode(":",$arrStopTime[1]);
				$sAbsEnd 		=   mktime(($aTime[0]),($aTime[1]+5),($aTime[2]),$aDate[1],$aDate[2],$aDate[0]);
				$chkStopTime   =   date("Y-m-d H:i:s", $sAbsEnd);
				if(strtotime($currentTime) > strtotime($chkStopTime))
				{
					list($DesireLevel,$fillingDevice) = $this->device_model->getWaterDesiredMeasurement();
					$ipID		 = 1;
					//If Current level is less than Desired Level then Start the device to fill the Pool/Spa.
					if(${'level_sensor_avg'.$ipID} < $DesireLevel)
					{
						if($fillingDevice != '')
						{
							$arrDevice 		= explode("_",$fillingDevice);
							$DeviceNumber  	= $arrDeviceType[0];
							$DeviceType  	= $arrDeviceType[1];
							$DeviceIPID	  	= $arrDeviceType[2];
							$sStatus		= '1';
							
							
							if($DeviceType == 'R') //IF assigned Device is 24V Relay.
							{
								$sNewResp = replace_return(${'sRelays'.$DeviceIPID}, $sStatus, $DeviceNumber );
					            #onoff_rlb_relay($sNewResp,${'board'.$DeviceIPID},$sPort,${'shhPort'.$DeviceIPID});
					            $this->home_model->updateDeviceRunTime($DeviceNumber,$DeviceType,$sStatus);
								
								//Start : Check if relay is assigned to Heater.
								$HeaterNumber = $this->home_model->chkHeater($DeviceNumber,'24',$DeviceIPID);
								if($HeaterNumber != '')
								{
									$this->heaterDetailsUpdate($HeaterNumber,$DeviceIPID,$sStatus);
								}
								else
								{
									list($pumpNumber,$relay1,$relay2)	=	$this->home_model->getPumpNumberFromRelayNumber($DeviceNumber,'24');
									if($pumpNumber != '')
									{
										//Check if the relay is assigned to pump or not.
										$aPumpDetails =	$this->home_model->getPumpDetails($pumpNumber,$DeviceIPID);
										if(!empty($aPumpDetails))
										{
											foreach($aPumpDetails as $sPump)
											{
												if($sStatus != '0')
												{
													if($relay1 == $DeviceNumber)
														$sStatus = '1';
													if($relay2 == $DeviceNumber)
														$sStatus = '2';
												}
												#$this->cronMakePumpOnOFF($sPump->pump_number,$sStatus,${'board'.$DeviceIPID},$sPort,${'shhPort'.$DeviceIPID},$DeviceIPID);
											}
										}
									}
								}
								//End : Check if relay is assigned to Heater.
							} //IF assigned Device is 24V Relay.
							if($DeviceType == 'P') //IF assigned Device is 12V Relay.
					        {
					            $sNewResp = replace_return(${'sPowerCenters'.$DeviceIPID}, $sStatus, $DeviceNumber);
					            #onoff_rlb_powercenter($sNewResp,${'board'.$DeviceIPID},$sPort,${'shhPort'.$DeviceIPID});
								
								//Start : Check if relay is assigned to Heater.
								$HeaterNumber = $this->home_model->chkHeater($DeviceNumber,'12',$DeviceIPID);
								if($HeaterNumber != '')
								{
									$this->heaterDetailsUpdate($HeaterNumber,$DeviceIPID,$sStatus);
								}
								else
								{
									list($pumpNumber,$relay1,$relay2)	=	$this->home_model->getPumpNumberFromRelayNumber($DeviceNumber,'12');
									
									if($pumpNumber != '')
									{
										//Check if the relay is assigned to pump or not.
										$aPumpDetails =	$this->home_model->getPumpDetails($pumpNumber,$DeviceIPID);
										if(!empty($aPumpDetails))
										{
											foreach($aPumpDetails as $sPump)
											{
												if($sStatus != '0')
												{
													if($relay1 == $DeviceNumber)
														$sStatus = '1';
													if($relay2 == $DeviceNumber)
														$sStatus = '2';
												}
												#$this->cronMakePumpOnOFF($sPump->pump_number,$sStatus,${'board'.$DeviceIPID},$sPort,${'shhPort'.$DeviceIPID},$DeviceIPID);
											}
										}
									}
								}
					        }//IF assigned Device is 12V Relay.
					        if($DeviceType == 'V') //IF assigned Device is Valve.
					        {
								//First Get the Current Status.
								$currentOnPosition = ${'sValves'.$DeviceIPID}[$DeviceNumber];
								
								if($currentOnPosition  != 0)
								{
									$this->home_model->saveLastRun($DeviceNumber,$DeviceType,$currentOnPosition,$DeviceIPID);
								}
								$sNewResp = replace_return(${'sValves'.$DeviceIPID}, $sStatus, $DeviceNumber);
								#onoff_rlb_valve($sNewResp,${'board'.$DeviceIPID},$sPort,${'shhPort'.$DeviceIPID});
							}//IF assigned Device is Valve.
					        if($DeviceType == 'PS') //IF assigned Device is Pump.
					        {
								#$this->cronMakePumpOnOFF($DeviceNumber,$sStatus,${'board'.$DeviceIPID},$sPort,${'shhPort'.$DeviceIPID},$DeviceIPID);
							}//IF assigned Device is Pump.
							
							//Save Start and End Time of the Device.
							$StartTime = date("Y-m-d H:i:s");
							$arrStartTime	=	explode(" ",$StartTime);
							$aDate     		=   explode("-",$arrStartTime[0]);
							$aTime     		=   explode(":",$arrStartTime[1]);
							
							$sAbsEnd =   mktime(($aTime[0]),($aTime[1]+5),($aTime[2]),$aDate[1],$aDate[2],$aDate[0]);
							$StopTime   =   date("Y-m-d H:i:s", $sAbsEnd);
							
							$arrDeviceDetails = array("DeviceNumber"=>$DeviceNumber,
													  "DeviceType"=>$DeviceType,
													  "DeviceIPID"=>$DeviceIPID,
													  "StartTime"=>$StartTime,
													  "StopTime"=>$StopTime);
							$this->device_model->saveWaterLevelFillingDeviceDetails($arrDeviceDetails);
						}
					}
				}
			}
		}
		else
		{
			##START : First Check the water Level.
			//Get the Desire Measurement and Device for filling Water Stored in Database.
			list($DesireLevel,$fillingDevice) = $this->device_model->getWaterDesiredMeasurement();
			$ipID		 = 1;
			//If Current level is less than Desired Level then Start the device to fill the Pool/Spa.
			if(${'level_sensor_avg'.$ipID} < $DesireLevel)
			{
				if($fillingDevice != '')
				{
					$arrDevice 		= explode("_",$fillingDevice);
					$DeviceNumber  	= $arrDeviceType[0];
					$DeviceType  	= $arrDeviceType[1];
					$DeviceIPID	  	= $arrDeviceType[2];
					$sStatus		= '1';
					
					
					if($DeviceType == 'R') //IF assigned Device is 24V Relay.
					{
						$sNewResp = replace_return(${'sRelays'.$DeviceIPID}, $sStatus, $DeviceNumber );
			            #onoff_rlb_relay($sNewResp,${'board'.$DeviceIPID},$sPort,${'shhPort'.$DeviceIPID});
			            $this->home_model->updateDeviceRunTime($DeviceNumber,$DeviceType,$sStatus);
						
						//Start : Check if relay is assigned to Heater.
						$HeaterNumber = $this->home_model->chkHeater($DeviceNumber,'24',$DeviceIPID);
						if($HeaterNumber != '')
						{
							$this->heaterDetailsUpdate($HeaterNumber,$DeviceIPID,$sStatus);
						}
						else
						{
							list($pumpNumber,$relay1,$relay2)	=	$this->home_model->getPumpNumberFromRelayNumber($DeviceNumber,'24');
							if($pumpNumber != '')
							{
								//Check if the relay is assigned to pump or not.
								$aPumpDetails =	$this->home_model->getPumpDetails($pumpNumber,$DeviceIPID);
								if(!empty($aPumpDetails))
								{
									foreach($aPumpDetails as $sPump)
									{
										if($sStatus != '0')
										{
											if($relay1 == $DeviceNumber)
												$sStatus = '1';
											if($relay2 == $DeviceNumber)
												$sStatus = '2';
										}
										#$this->cronMakePumpOnOFF($sPump->pump_number,$sStatus,${'board'.$DeviceIPID},$sPort,${'shhPort'.$DeviceIPID},$DeviceIPID);
									}
								}
							}
						}
						//End : Check if relay is assigned to Heater.
					} //IF assigned Device is 24V Relay.
					if($DeviceType == 'P') //IF assigned Device is 12V Relay.
			        {
			            $sNewResp = replace_return(${'sPowerCenters'.$DeviceIPID}, $sStatus, $DeviceNumber);
			            #onoff_rlb_powercenter($sNewResp,${'board'.$DeviceIPID},$sPort,${'shhPort'.$DeviceIPID});
						
						//Start : Check if relay is assigned to Heater.
						$HeaterNumber = $this->home_model->chkHeater($DeviceNumber,'12',$DeviceIPID);
						if($HeaterNumber != '')
						{
							$this->heaterDetailsUpdate($HeaterNumber,$DeviceIPID,$sStatus);
						}
						else
						{
							list($pumpNumber,$relay1,$relay2)	=	$this->home_model->getPumpNumberFromRelayNumber($DeviceNumber,'12');
							
							if($pumpNumber != '')
							{
								//Check if the relay is assigned to pump or not.
								$aPumpDetails =	$this->home_model->getPumpDetails($pumpNumber,$DeviceIPID);
								if(!empty($aPumpDetails))
								{
									foreach($aPumpDetails as $sPump)
									{
										if($sStatus != '0')
										{
											if($relay1 == $DeviceNumber)
												$sStatus = '1';
											if($relay2 == $DeviceNumber)
												$sStatus = '2';
										}
										#$this->cronMakePumpOnOFF($sPump->pump_number,$sStatus,${'board'.$DeviceIPID},$sPort,${'shhPort'.$DeviceIPID},$DeviceIPID);
									}
								}
							}
						}
			        }//IF assigned Device is 12V Relay.
			        if($DeviceType == 'V') //IF assigned Device is Valve.
			        {
						//First Get the Current Status.
						$currentOnPosition = ${'sValves'.$DeviceIPID}[$DeviceNumber];
						
						if($currentOnPosition  != 0)
						{
							$this->home_model->saveLastRun($DeviceNumber,$DeviceType,$currentOnPosition,$DeviceIPID);
						}
						$sNewResp = replace_return(${'sValves'.$DeviceIPID}, $sStatus, $DeviceNumber);
						#onoff_rlb_valve($sNewResp,${'board'.$DeviceIPID},$sPort,${'shhPort'.$DeviceIPID});
					}//IF assigned Device is Valve.
			        if($DeviceType == 'PS') //IF assigned Device is Pump.
			        {
						#$this->cronMakePumpOnOFF($DeviceNumber,$sStatus,${'board'.$DeviceIPID},$sPort,${'shhPort'.$DeviceIPID},$DeviceIPID);
					}//IF assigned Device is Pump.
					
					//Save Start and End Time of the Device.
					$StartTime = date("Y-m-d H:i:s");
					$arrStartTime	=	explode(" ",$StartTime);
					$aDate     		=   explode("-",$arrStartTime[0]);
					$aTime     		=   explode(":",$arrStartTime[1]);
					
					$sAbsEnd =   mktime(($aTime[0]),($aTime[1]+5),($aTime[2]),$aDate[1],$aDate[2],$aDate[0]);
					$StopTime   =   date("Y-m-d H:i:s", $sAbsEnd);
					
					$arrDeviceDetails = array("DeviceNumber"=>$DeviceNumber,
											  "DeviceType"=>$DeviceType,
											  "DeviceIPID"=>$DeviceIPID,
											  "StartTime"=>$StartTime,
											  "StopTime"=>$StopTime);
					$this->device_model->saveWaterLevelFillingDeviceDetails($arrDeviceDetails);
				}
			}
			##END : First Check the water Level.
		}
		
		
	}
	
	
	
	###################################################################
	public function customProgramRunCheck()
	{
		echo date('Y-m-d H:i:s').'<br>';
		$this->load->model('custom_model');
		$this->load->model('home_model');
		
		//Get Current Active Mode
		$iMode	=   $this->home_model->getActiveMode();
		
		//Get All On Program and Details.
		$aAllOnPrograms = $this->home_model->getOnCustomProgram();
		
		if(!empty($aAllOnPrograms))
		{
			//Get All IP Details.
			$aIPDetails = $this->home_model->getBoardIP();
			
			list($sIP,$sPort,$extra) = $this->home_model->getSettings();
			
			foreach($aIPDetails as $IP)
			{
				${'shhPort'.$IP->id}	=	'';
				if(IS_LOCAL == '1')
				{
					//Get SSH port of the RLB board using IP.
					${'shhPort'.$IP->id} = $this->home_model->getSSHPortFromID($IP->id);
				}
				$sResponse		=	array();
				$sValves        =   ''; 
				$sRelays        =   '';  
				$sPump			=	'';	
				
				//Get the status response of devices from relay board.
				$sResponse      =   get_rlb_status($IP->ip,$sPort,$shhPort);
			
				$sValves        =   $sResponse['valves']; // Valve Device Status
				$sRelays        =   $sResponse['relay'];  // Relay Device Status
				$sPowerCenter   =   $sResponse['powercenter']; // Power Center Device Status
				
				${'sRelays'.$IP->id} 		=	$sRelays;
				${'sValves'.$IP->id} 		=	$sValves;
				${'sPowerCenter'.$IP->id} 	=	$sPowerCenter;  
				
				${'sPump'.$IP->id}	=	array($sResponse['pump_seq_0_st'],$sResponse['pump_seq_1_st'],$sResponse['pump_seq_2_st']);
				${'board'.$IP->id} 	=	$IP->ip;
				
				$arrExtraDetails[$IP->id] = array('sValves'=>${'sValves'.$IP->id},'board'=>${'board'.$IP->id},'shhPort'=>${'shhPort'.$IP->id});
			}
			
			foreach($aAllOnPrograms as $customProgram)
			{
				$unique_id	=	$customProgram->unique_id;
				$programID	=	$customProgram->id;
				
				if($programID != 1)
					continue;
				
				$arrSequnceDevice	=	array();
				//First Make the Program Running Status to 1.
				$this->home_model->updateRunningStatusCustomProgram($programID,'1');
				
				$aProgramDetails =	json_decode($customProgram->program_details);
				
				$maxRunTime		 =	$aProgramDetails->g_custom_max_time;
				$programStart	 =	$customProgram->program_start;	
				$programEnd		 =	$customProgram->program_end;

				$afterProgram	 =	$customProgram->afterProgram;
				$previousState	 = 	unserialize($customProgram->previousState);		
				
				if(isset($aProgramDetails->g_rlb_pump_list) && $aProgramDetails->g_rlb_pump_list != '')
				{
					//Pump Device Details.
					$pumpDevice		=	explode(",",$aProgramDetails->g_rlb_pump_list);
					$pumpSequence	=	explode(",",$aProgramDetails->g_pump_sq);
					$pumpTime		=	explode(",",$aProgramDetails->g_pump_time);
				}
				
				if(isset($aProgramDetails->g_rlb_valve_list) && $aProgramDetails->g_rlb_valve_list != '')
				{
					//Valve Device Details
					$valveDevice	=	explode(",",$aProgramDetails->g_rlb_valve_list);	
					$valveSequence	=	explode(",",$aProgramDetails->g_valve_sq);	
					$valveTime		=	explode(",",$aProgramDetails->g_valve_time);
				}

				if(isset($aProgramDetails->g_rlb_relay_list) && $aProgramDetails->g_rlb_relay_list != '')
				{
					//Relay Device Details
					$relayDevice	=	explode(",",$aProgramDetails->g_rlb_relay_list);	
					$relaySequence	=	explode(",",$aProgramDetails->g_relay_sq);	
					$relayTime		=	explode(",",$aProgramDetails->g_relay_time);				
				}
				
				if(isset($aProgramDetails->g_rlb_powercenter_list) && $aProgramDetails->g_rlb_powercenter_list != '')
				{
					//Relay Device Details
					$powerCenterDevice	=	explode(",",$aProgramDetails->g_rlb_powercenter_list);	
					$powerCenterSequence	=	explode(",",$aProgramDetails->g_powercenter_sq);	
					$powerCenterTime		=	explode(",",$aProgramDetails->g_powercenter_time);				
				}

				$arrPumpKeepOn		   = array();					
				
				if(!empty($pumpSequence))
				{
					foreach($pumpSequence as $seq => $key)
					{
						if($key != '')
						{
							if(!array_key_exists($key,$arrSequnceDevice))
							$arrSequnceDevice[$key] = array();
							
							array_push($arrSequnceDevice[$key],$pumpDevice[$seq].'|||'.$pumpTime[$seq].'|||PS');
							
						}
						
						$arrTemp 			=	explode("_",$pumpDevice[$seq]);
						$ipIDTemp			=	$arrTemp[0];
						$deviceNumberTemp	=	$arrTemp[1];
						
						//START : Check if its running in program.
						$chk = $this->home_model->checkAlreadyRunning($deviceNumberTemp,$ipIDTemp,'PS');
						
						if($chk == '1')
						{
							$arrPumpKeepOn[] = $pumpDevice[$seq];
						}
						
						//$arrSequnceDevice[$seq] = $pumpDevice[$key].'|||'.$pumpTime[$key].'|||PS';
					}
				}
				
				//$valveSequence	=	array_flip($valveSequence);
				
				$arrAfterProgramDevice = array();
				$arrValveKeepOn		   = array();
				//sort($valveSequence);
				
				$arrProgramValve = array();
				
				if(!empty($valveSequence))
				{
					$k = 1;
					foreach($valveSequence as $seq => $key)
					{
						if($key != '')
						{
							if(!array_key_exists($key,$arrSequnceDevice))
							$arrSequnceDevice[$key] = array();
						
							array_push($arrSequnceDevice[$key],$valveDevice[$seq].'|||'.$valveTime[$seq].'|||V');
							
							array_push($arrProgramValve,$valveDevice[$seq]);
							
							//Valve to run after program end.
							$arr	=	explode('_',$valveDevice[$seq]);
							$strPosition = '';
							if($arr[1] == 1)
							{
								$strPosition = 2;
							}
							else if($arr[1] == 2)
							{
								$strPosition = 1;
							}
							
							$arrTemp 			=	explode("_",$valveDevice[$seq]);
							$ipIDTemp			=	$arrTemp[0];
							$sStatusTemp		=	$arrTemp[1];
							$deviceNumberTemp	=	$arrTemp[2];
							
							$existingStatus 	=	${'sValves'.$ipIDTemp}[$deviceNumberTemp];
							
							//$tempDevice			=	$ipIDTemp.'_'.$existingStatus.'_'.$deviceNumberTemp;
							
							$valveAfterProgram = $arr[0].'_'.$strPosition.'_'.$arr[2];
							
							//if($existingStatus != $sStatusTemp)
							if(!in_array($valveDevice[$seq],$previousState))	
							{
								$lastRun = $this->home_model->getDeviceLastRun($deviceNumberTemp,'V',$ipIDTemp);
								
								if($lastRun != $sStatusTemp)
								{
									$arrAfterProgramDevice[$key] = $valveAfterProgram.'|||'.$valveTime[$seq].'|||V';
								
									$k++;
								}
							}
							/* else
							{
								$arrValveKeepOn[] = $ipIDTemp.'_'.$deviceNumberTemp;
							} */
							
						}
						//array_push($arrAfterProgramDevice,$valveAfterProgram.'|||'.$valveTime[$seq].'|||V');
						
					}
				}
				
				if(!empty($relaySequence))
				{
					foreach($relaySequence as $seq => $key)
					{
						if($key != '')
						{
							if(!array_key_exists($key,$arrSequnceDevice))
							$arrSequnceDevice[$key] = array();
							
							array_push($arrSequnceDevice[$key],$relayDevice[$seq].'|||'.$relayTime[$seq].'|||R');
						}
					}
				}
				
				if(!empty($powerCenterSequence))
				{
					foreach($powerCenterSequence as $seq => $key)
					{
						if($key != '')
						{
							if(!array_key_exists($key,$arrSequnceDevice))
							$arrSequnceDevice[$key] = array();
							
							array_push($arrSequnceDevice[$key],$powerCenterDevice[$seq].'|||'.$powerCenterTime[$seq].'|||P');
						}
					}
				}
				ksort($arrSequnceDevice);
				ksort($arrAfterProgramDevice);
				
				echo '<pre>Valve:';print_r($arrSequnceDevice);echo '</pre>';
				echo '<pre>KeepON:';print_r($arrValveKeepOn);echo '</pre>';
				
				//die('STOP');
				
				//Check Program End Time, if it is passed make that program OFF.
				if((strtotime(date("Y-m-d H:i:s")) > strtotime($programEnd)) && $afterProgram  == '0')
				{
					$this->home_model->updateRunningStatusCustomProgram($programID,'0');
					$this->custom_model->offCustomProgram($programID,'0');
					
					foreach($arrProgramValve as $valveDevice)
					{
						$arrTemp 			=	explode("_",$valveDevice);
						$ipIDTemp			=	$arrTemp[0];
						$sStatusTemp		=	$arrTemp[1];
						$deviceNumberTemp	=	$arrTemp[2];
						
						#START : GET Default Pool auto Position.
						$defaultPosition 	=	$this->home_model->getValveDefaultPosition($deviceNumberTemp,$ipIDTemp);
						
						$sNewResp = replace_return(${'sValves'.$ipIDTemp}, $defaultPosition, $deviceNumberTemp);
						${'sValves'.$ipIDTemp} = $sNewResp;
						##onoff_rlb_valve($sNewResp,${'board'.$ipIDTemp},$sPort,${'shhPort'.$ipIDTemp});
						#END : GET Default Pool auto Position.
						
						//START : INSERT THE VALVE DETAILS TO RUN VALVE FOR GIVEN TIME IN POOL MODE AUTO. IF TIME IS NOT SPECIFIED THEN IT WILL RUN FOR 1 MIN DEFAULT.

						$runTime = $this->home_model->getValveDefaultPositionTime($deviceNumberTemp,$ipIDTemp);
						if($runTime == 0)
						{
							$runTime = 1;
						}
						if($runTime == '')
						{
							$runTime = 1;
						}	
						
						$arrValveDefaultRunDetails	=	array('program_id'=>$programID,'valve'=>$deviceNumberTemp,'ip_id'=>$ipIDTemp,'runTime'=>$runTime);
						$this->home_model->insertValveDefaultRunDetails($arrValveDefaultRunDetails);
						
						//END : INSERT THE VALVE DETAILS TO RUN VALVE FOR GIVEN TIME IN POOL MODE AUTO. IF TIME IS NOT SPECIFIED THEN IT WILL RUN FOR 1 MIN DEFAULT.
						
					}
					$this->home_model->removePreviousPositions($programID);
					
					echo '<pre>';print_r('Program OFF');echo '</pre>';
					continue;
					/* if(!empty($arrAfterProgramDevice))
					{
						$this->home_model->updateAfterProgram($programID,'1');
						$this->customProgramRunAfter($programID,$arrAfterProgramDevice,$unique_id,$arrExtraDetails);
					}
					else
					{
						$this->custom_model->offCustomProgram($programID,'0');
					} */
					
				}
				
				//Check if Progrma is running, if running then get which device is running for Programs.
				$currentDevice = $this->custom_model->getCustomProgrmaCurrentDevice($programID);
				
				
				/* else if($afterProgram == '1')
				{
					$this->customProgramRunAfter($programID,$arrAfterProgramDevice,$unique_id,$arrExtraDetails);
					continue;
				} */
				if($iMode != 1)
				{
					$this->home_model->updateRunningStatusCustomProgram($programID,'0');
					$this->custom_model->offCustomProgram($programID,'0');
					$this->home_model->updateAfterProgram($programID,'0');
					
					//Insert Entry in the Log Table for future Reference.
					$this->custom_model->saveCustomEntryInLog($programID,$deviceType);
					
					//Delete Entry From the current details Table.
					$this->custom_model->deleteCustomEntryFromCurrent($programID);
					
					foreach($currentDevice as $deviceDetails)
					{
						//If Device is Running Then Check if its Time is Complete.
						$currentSeq		=	$deviceDetails->current_sequence;
						$deviceType 	=   $deviceDetails->device_type;
						$ipID			=	$deviceDetails->ip_id;
						$sStatus		=	0;
						$deviceNumber	=	$deviceDetails->device_number;
						
						if($deviceType == 'V')
						{
							$sNewResp = replace_return(${'sValves'.$ipID}, $sStatus, $deviceNumber);
							${'sValves'.$ipID} = $sNewResp;
							##onoff_rlb_valve($sNewResp,${'board'.$ipID},$sPort,${'shhPort'.$ipID});
						}
						else if($deviceType == 'PS')
						{	
							##$this->cronMakePumpOnOFF($deviceNumber,$sStatus,${'board'.$ipID},$sPort,${'shhPort'.$ipID},$ipID);
						}
						else if($deviceType	== 'R')
						{
							$sNewResp = replace_return(${'sRelays'.$ipID}, $sStatus, $deviceNumber);
							${'sRelays'.$ipID} = $sNewResp;
							##onoff_rlb_relay($sNewResp,${'board'.$ipID},$sPort,${'shhPort'.$ipID});
							//Start : Check if relay is assigned to Heater.
							$HeaterNumber = $this->home_model->chkHeater($deviceNumber,'24',$ipID);
							if($HeaterNumber != '')
							{
								$this->heaterDetailsUpdatePump($HeaterNumber,$ipID,0);
							}
						}
						else if($deviceType	== 'P')
						{
							$sNewResp = replace_return(${'sPowerCenter'.$ipID}, $sStatus, $deviceNumber);
							${'sPowerCenter'.$ipID} = $sNewResp;
							##onoff_rlb_powercenter($sNewResp,${'board'.$ipID},$sPort,${'shhPort'.$ipID});
							//Start : Check if relay is assigned to Heater.
							$HeaterNumber = $this->home_model->chkHeater($deviceNumber,'12',$ipID);
							if($HeaterNumber != '')
							{
								$this->heaterDetailsUpdatePump($HeaterNumber,$ipID,0);
							}
						}
					}
					
					$currentDeviceAfter = $this->custom_model->getCustomProgrmaAfterDevice($programID);
					
					if($currentDeviceAfter != '')
					{
						foreach($currentDeviceAfter as $deviceDetails)
						{
							$currentSeq		=	$deviceDetails->current_sequence;
							$deviceType 	=   $deviceDetails->device_type;
							$ipID			=	$deviceDetails->ip_id;
							$sStatus		=	0;
							$deviceNumber	=	$deviceDetails->device_number;
							
							$sNewResp = replace_return(${'sValves'.$ipID}, $sStatus, $deviceNumber);
							${'sValves'.$ipID} = $sNewResp;
							##onoff_rlb_valve($sNewResp,${'board'.$ipID},$sPort,${'shhPort'.$ipID});
							
							
							//Insert Entry in the Log Table for future Reference.
							$this->custom_model->saveCustomAfterEntryInLog($programID,$deviceType);
							
							//Delete Entry From the current details Table.
							$this->custom_model->deleteCustomEntryFromAfter($programID,$deviceType,$deviceNumber);
						}
					}
					
				}
				else
				{
					if(!empty($arrSequnceDevice))
					{
						if($currentDevice == '')
						{
							echo '<pre>FirstDevices :';print_r($arrSequnceDevice);echo '</pre>';
							foreach($arrSequnceDevice[1] as $devices)
							{
								//$aCurrentDevice	=	explode('|||',$arrSequnceDevice[1]);
								$aCurrentDevice	=	explode('|||',$devices);
								//START: First make valve device ON in the sequence.
								$sStatus		=	'1';
								$sRunTime		=	$aCurrentDevice[1];
								$deviceType 	=   $aCurrentDevice[2];
								$aDevice		=	explode("_",$aCurrentDevice[0]);
								if($deviceType == 'V')
								{
									$ipID			=	$aDevice[0];
									$sStatus		=	$aDevice[1];
									$deviceNumber	=	$aDevice[2];
								}
								else if($deviceType == 'PS' || $deviceType == 'R' || $deviceType == 'P')
								{
									$ipID			=	$aDevice[0];
									$deviceNumber	=	$aDevice[1];
								}
								
								if($deviceType	==	'PS')
								{
									echo '<pre>PUMP ON :';print_r($deviceNumber.'>>'.$sStatus.'>>'.$ipID);echo '</pre>';
									##$this->cronMakePumpOnOFF($deviceNumber,$sStatus,${'board'.$ipID},$sPort,${'shhPort'.$ipID},$ipID);
											
									$strDevice		=	'Pump '.$deviceNumber;
								}
								else if($deviceType	== 'V')
								{
									$existingStatus 	=	${'sValves'.$ipID}[$deviceNumber];
									if($sStatus != $existingStatus)
									{
										$sNewResp = replace_return(${'sValves'.$ipID}, $sStatus, $deviceNumber);
										${'sValves'.$ipID} = $sNewResp;
										
										echo '<pre>VALVE ON :';print_r($deviceNumber.'>>'.$sStatus.'>>'.$ipID.'>>'.${'sValves'.$ipID});echo '</pre>';
										##onoff_rlb_valve($sNewResp,${'board'.$ipID},$sPort,${'shhPort'.$ipID});
									}
									
									$strDevice	=	'Valve '.$deviceNumber;	
								}
								else if($deviceType	== 'R')
								{
									$existingStatus 	=	${'sRelays'.$ipID}[$deviceNumber];
									if($sStatus != $existingStatus)
									{
										$sNewResp = replace_return(${'sRelays'.$ipID}, $sStatus, $deviceNumber);
										${'sRelays'.$ipID} = $sNewResp;
										
										echo '<pre>Relay ON :';print_r($deviceNumber.'>>'.$sStatus.'>>'.$ipID.'>>'.${'sRelays'.$ipID});echo '</pre>';
										##onoff_rlb_relay($sNewResp,${'board'.$ipID},$sPort,${'shhPort'.$ipID});
									}
									
									//START : Check if heater is assigned to that relay.
									$heaterNum = $this->home_model->chkHeater($deviceNumber,'24',$ipID);
									
									if($heaterNum != '')
									{
										$aHeaterDetails  =   $this->home_model->getHeaterDeviceDetails($heaterNum,$ipID);
										if(!empty($aHeaterDetails))
										{
											foreach($aHeaterDetails as $aHeater)
											$sHeaterDetails  =   unserialize($aHeater->light_relay_number);
											
											$PumpNumber   	=   $sHeaterDetails['Pump'];
											$maxRun   		=   $sHeaterDetails['maxRun'];
											
											$sHeaterStart 	=   date("Y-m-d H:i:s", time());
											$arrStart		=	explode(" ",$sHeaterStart);
											$aStartDate    	=   explode("-",$arrStart[0]);
											$aStartTime    	=   explode(":",$arrStart[1]);
											
											$sProgramAbsEnd   =   mktime($aStartTime[0],($aStartTime[1]+$maxRun),$aStartTime[2],$aStartDate[1],$aStartDate[2],$aStartDate[0]);
											$sHeaterEnd     =   date("Y-m-d H:i:s", $sProgramAbsEnd);
											
											$this->home_model->insertHeaterRunDetails($heaterNum,$ipID,$sHeaterStart,$sHeaterEnd);
											
											
										}
										if($PumpNumber != '')
										{
											$aPumpDetails =	$this->home_model->getPumpDetails($PumpNumber,$ipID);
											if(!empty($aPumpDetails))
											{
												foreach($aPumpDetails as $sPump)
												{
													
													
													##$this->cronMakePumpOnOFF($sPump->pump_number,'1',${'board'.$ipID},$sPort,${'shhPort'.$ipID},$ipID);
												}
											}
										}
									}
									//END : Check if heater is assigned to that relay.
									
									$strDevice	=	'Relay '.$deviceNumber;	
								}
								else if($deviceType	== 'P')
								{
									$existingStatus 	=	${'sPowerCenter'.$ipID}[$deviceNumber];
									if($sStatus != $existingStatus)
									{
										$sNewResp = replace_return(${'sPowerCenter'.$ipID}, $sStatus, $deviceNumber);
										${'sPowerCenter'.$ipID} = $sNewResp;
										echo '<pre>PowerCenter ON :';print_r($deviceNumber.'>>'.$sStatus.'>>'.$ipID.'>>'.${'sPowerCenter'.$ipID});echo '</pre>';
										##onoff_rlb_powercenter($sNewResp,${'board'.$ipID},$sPort,${'shhPort'.$ipID});
									}
									
									//START : Check if heater is assigned to that relay.
									$heaterNum = $this->home_model->chkHeater($deviceNumber,'12',$ipID);
									
									if($heaterNum != '')
									{
										$aHeaterDetails  =   $this->home_model->getHeaterDeviceDetails($heaterNum,$ipID);
										if(!empty($aHeaterDetails))
										{
											foreach($aHeaterDetails as $aHeater)
											{
												$sHeaterDetails  =   unserialize($aHeater->light_relay_number);
											}
											
											$PumpNumber   	=   $sHeaterDetails['Pump'];
											$maxRun   		=   $sHeaterDetails['maxRun'];
											
											$sHeaterStart 	=   date("Y-m-d H:i:s", time());
											$arrStart		=	explode(" ",$sHeaterStart);
											$aStartDate    	=   explode("-",$arrStart[0]);
											$aStartTime    	=   explode(":",$arrStart[1]);
											
											$sProgramAbsEnd   =   mktime($aStartTime[0],($aStartTime[1]+$maxRun),$aStartTime[2],$aStartDate[1],$aStartDate[2],$aStartDate[0]);
											$sHeaterEnd     =   date("Y-m-d H:i:s", $sProgramAbsEnd);
											
											$this->home_model->insertHeaterRunDetails($heaterNum,$ipID,$sHeaterStart,$sHeaterEnd);
										}
										if($PumpNumber != '')
										{
											$aPumpDetails =	$this->home_model->getPumpDetails($PumpNumber,$ipID);
											if(!empty($aPumpDetails))
											{
												foreach($aPumpDetails as $sPump)
												{
													##$this->cronMakePumpOnOFF($sPump->pump_number,'1',${'board'.$ipID},$sPort,${'shhPort'.$ipID},$ipID);
												}
											}
										}
									}
									//END : Check if heater is assigned to that relay.  
									
									$strDevice	=	'Power Center '.$deviceNumber;
								}
								
								$arrDetails		=	array('program_id'=>$programID,
														  'current_on_device'=>$strDevice,
														  'device_type'=>$deviceType,
														  'device_number'=>$deviceNumber,
														  'current_on_time'=>$sRunTime,
														  'current_sequence'=>1,
														  'ip_id'=>$ipID,
														  'unique_id'=>$unique_id);
								
								$this->custom_model->saveCustomCurrentRunningDevice($arrDetails);
							}
						}
						else if($currentDevice != '')
						{
							echo '<pre>Current:';print_r($currentDevice);echo '</pre>';
							
							$lastElement = end($currentDevice);
							
							echo '<pre>Last:';print_r($lastElement);echo '</pre>';

							foreach($currentDevice as $deviceDetails)
							{
								//If Device is Running Then Check if its Time is Complete.
								$OffTime			=	$deviceDetails->current_off_time;
								$currentServerTime	=	date('Y-m-d H:i:s');
								
								if($currentServerTime >= $OffTime)
								{
									$currentSeq		=	$deviceDetails->current_sequence;
									$deviceType 	=   $deviceDetails->device_type;
									$ipID			=	$deviceDetails->ip_id;
									$sStatus		=	0;
									$deviceNumber	=	$deviceDetails->device_number;
									
									echo '<pre>OFF:';print_r($deviceNumber.'>>'.$deviceType);echo '</pre>';
									
									if($deviceType == 'V')
									{
										if(!in_array($ipID.'_'.$deviceNumber,$arrValveKeepOn))
										{
											$sNewResp = replace_return(${'sValves'.$ipID}, $sStatus, $deviceNumber);
											${'sValves'.$ipID} = $sNewResp;
											
											echo '<pre>Valve OFF :';print_r($deviceNumber.'>>'.$sStatus.'>>'.$ipID.'>>'.${'sValves'.$ipID});echo '</pre>';
											##onoff_rlb_valve($sNewResp,${'board'.$ipID},$sPort,${'shhPort'.$ipID});
										}
									}
									else if($deviceType == 'PS')
									{
										if(!in_array($ipID.'_'.$deviceNumber,$arrPumpKeepOn))
										{
											echo '<pre>PUMP OFF :';print_r($deviceNumber.'>>'.$sStatus.'>>'.$ipID);echo '</pre>';
											##$this->cronMakePumpOnOFF($deviceNumber,$sStatus,${'board'.$ipID},$sPort,${'shhPort'.$ipID},$ipID);
										}
									}
									else if($deviceType	== 'R')
									{
										$sNewResp = replace_return(${'sRelays'.$ipID}, $sStatus, $deviceNumber);
										${'sRelays'.$ipID} = $sNewResp;
										
										echo '<pre>Relay OFF :';print_r($deviceNumber.'>>'.$sStatus.'>>'.$ipID.'>>'.${'sRelays'.$ipID});echo '</pre>';
										##onoff_rlb_relay($sNewResp,${'board'.$ipID},$sPort,${'shhPort'.$ipID});
										
										//START : Check if heater is assigned to that relay.
										$heaterNum = $this->home_model->chkHeater($deviceNumber,'24',$ipID);
										
										if($heaterNum != '')
										{
											$this->home_model->updateHeaterRunDetails($heaterNum,$ipID);
											$aHeaterDetails  =   $this->home_model->getHeaterDeviceDetails($heaterNum,$ipID);
											if(!empty($aHeaterDetails))
											{
												foreach($aHeaterDetails as $aHeater)
												$sHeaterDetails  =   unserialize($aHeater->light_relay_number);
												
												$PumpNumber   		=   $sHeaterDetails['Pump'];
											}
											if($PumpNumber != '')
											{
												$aPumpDetails =	$this->home_model->getPumpDetails($PumpNumber,$ipID);
												if(!empty($aPumpDetails))
												{
													foreach($aPumpDetails as $sPump)
													{
														$heaterStopTime =	date('Y-m-d H:i:s');
														$arrStopTime	=	explode(" ",$heaterStopTime);
														$aDate     		=   explode("-",$arrStopTime[0]);
														$aTime     		=   explode(":",$arrStopTime[1]);
														
														$sProgramAbsEnd =   mktime(($aTime[0]),($aTime[1]+5),($aTime[2]),$aDate[1],$aDate[2],$aDate[0]);
														$pumpStopTime   =   date("Y-m-d H:i:s", $sProgramAbsEnd);
														
														$this->home_model->updateRunAfterHeaterDetails($heaterNum,$sPump->pump_number,$heaterStopTime,$pumpStopTime,$ipID);
													}
												}
											}
										} 
									}
									else if($deviceType	== 'P')
									{
										$sNewResp = replace_return(${'sPowerCenter'.$ipID}, $sStatus, $deviceNumber);
										${'sPowerCenter'.$ipID} = $sNewResp;
										
										echo '<pre>Power OFF :';print_r($deviceNumber.'>>'.$sStatus.'>>'.$ipID.'>>'.${'sPowerCenter'.$ipID});echo '</pre>';
										##onoff_rlb_powercenter($sNewResp,${'board'.$ipID},$sPort,${'shhPort'.$ipID});
										
										//START : Check if heater is assigned to that relay.
										$heaterNum = $this->home_model->chkHeater($deviceNumber,'12',$ipID);
										
										if($heaterNum != '')
										{
											$this->home_model->updateHeaterRunDetails($heaterNum,$ipID);
											$aHeaterDetails  =   $this->home_model->getHeaterDeviceDetails($heaterNum,$ipID);
											if(!empty($aHeaterDetails))
											{
												foreach($aHeaterDetails as $aHeater)
												$sHeaterDetails  =   unserialize($aHeater->light_relay_number);
												
												$PumpNumber   		=   $sHeaterDetails['Pump'];
											}
											if($PumpNumber != '')
											{
												$aPumpDetails =	$this->home_model->getPumpDetails($PumpNumber,$ipID);
												if(!empty($aPumpDetails))
												{
													foreach($aPumpDetails as $sPump)
													{
														$heaterStopTime =	date('Y-m-d H:i:s');
														$arrStopTime	=	explode(" ",$heaterStopTime);
														$aDate     		=   explode("-",$arrStopTime[0]);
														$aTime     		=   explode(":",$arrStopTime[1]);
														
														$sProgramAbsEnd =   mktime(($aTime[0]),($aTime[1]+5),($aTime[2]),$aDate[1],$aDate[2],$aDate[0]);
														$pumpStopTime   =   date("Y-m-d H:i:s", $sProgramAbsEnd);
														
														$this->home_model->updateRunAfterHeaterDetails($heaterNum,$sPump->pump_number,$heaterStopTime,$pumpStopTime,$ipID);
													}
												}
											}
										} 
									}
									
									//Insert Entry in the Log Table for future Reference.
									$this->custom_model->saveCustomEntryInLog($programID,$deviceType);
									
									//Delete Entry From the current details Table.
									$this->custom_model->deleteCustomEntryFromCurrent($programID,$deviceType,$deviceNumber);
									
									
									if($lastElement->device_type  == $deviceDetails->device_type && $lastElement->device_number == $deviceDetails->device_number)
									{
										$keys 	 = array_keys($arrSequnceDevice);
										$nextSeq = $keys[array_search($currentSeq,$keys)+1];
										//$nextSeq		=	$currentSeq + 1;
										
										if(isset($arrSequnceDevice[$nextSeq]) && $arrSequnceDevice[$nextSeq] != '')
										{
											//echo '<pre>';print_r($arrSequnceDevice[$nextSeq]);echo '</pre>';
											echo '<pre>NextDevices :';print_r($arrSequnceDevice[$nextSeq]);echo '</pre>';
											
											foreach($arrSequnceDevice[$nextSeq] as $nextDevice)
											{
												$aCurrentDevice	=	explode('|||',$nextDevice);
												//START: First make valve device ON in the sequence.
												$sStatus		=	'1';
												$sRunTime		=	$aCurrentDevice[1];
												$deviceType 	=   $aCurrentDevice[2];
												$aDevice		=	explode("_",$aCurrentDevice[0]);
												
												if($deviceType == 'V')
												{
													$ipID			=	$aDevice[0];
													$sStatus		=	$aDevice[1];
													$deviceNumber	=	$aDevice[2];
												}
												else if($deviceType == 'PS' || $deviceType == 'R' || $deviceType == 'P')
												{
													$ipID			=	$aDevice[0];
													$deviceNumber	=	$aDevice[1];
												}
												
												echo '<pre>Next Device :';print_r($deviceNumber.'>>'.$sStatus.'>>'.$ipID.'>>');echo '</pre>';
												
												$checkLog = $this->home_model->getDeviceRunLog($deviceNumber,$deviceType,$ipID,$programID,$unique_id);
												
												if($checkLog != '')
												{
													$this->home_model->updateRunningStatusCustomProgram($programID,'0');
													$this->custom_model->offCustomProgram($programID,'0');
													
													foreach($arrProgramValve as $valveDevice)
													{
														$arrTemp 			=	explode("_",$valveDevice);
														$ipIDTemp			=	$arrTemp[0];
														$sStatusTemp		=	$arrTemp[1];
														$deviceNumberTemp	=	$arrTemp[2];
														
														#START : GET Default Pool auto Position.
														$defaultPosition 	=	$this->home_model->getValveDefaultPosition($deviceNumberTemp,$ipIDTemp);
														
														$sNewResp = replace_return(${'sValves'.$ipIDTemp}, $defaultPosition, $deviceNumberTemp);
														${'sValves'.$ipIDTemp} = $sNewResp;
														##onoff_rlb_valve($sNewResp,${'board'.$ipIDTemp},$sPort,${'shhPort'.$ipIDTemp});						
														#END : GET Default Pool auto Position.
														
														//START : INSERT THE VALVE DETAILS TO RUN VALVE FOR GIVEN TIME IN POOL MODE AUTO. IF TIME IS NOT SPECIFIED THEN IT WILL RUN FOR 1 MIN DEFAULT.
														
														$runTime = $this->home_model->getValveDefaultPositionTime($deviceNumberTemp,$ipIDTemp);
														if($runTime == 0)
														{
															$runTime = 1;
														}
														if($runTime == '')
														{
															$runTime = 1;
														}	
														
														$arrValveDefaultRunDetails	=	array('program_id'=>$programID,'valve'=>$deviceNumberTemp,'ip_id'=>$ipIDTemp,'runTime'=>$runTime);
														$this->home_model->insertValveDefaultRunDetails($arrValveDefaultRunDetails);
														
														//END : INSERT THE VALVE DETAILS TO RUN VALVE FOR GIVEN TIME IN POOL MODE AUTO. IF TIME IS NOT SPECIFIED THEN IT WILL RUN FOR 1 MIN DEFAULT.
													}
													$this->home_model->removePreviousPositions($programID);			
													continue;
													
													/* if(!empty($arrAfterProgramDevice))
													{
														$this->home_model->updateAfterProgram($programID,'1');
														
														$this->customProgramRunAfter($programID,$arrAfterProgramDevice,$unique_id,$arrExtraDetails);
													}
													else
													{
														$this->custom_model->offCustomProgram($programID,'0');
													}
													continue; */
												}
																								
												if($deviceType	==	'PS')
												{
													echo '<pre>Next PUMP ON :';print_r($deviceNumber.'>>'.$sStatus.'>>'.$ipID.'>>');echo '</pre>';
													##$this->cronMakePumpOnOFF($deviceNumber,$sStatus,${'board'.$ipID},$sPort,${'shhPort'.$ipID},$ipID);
														
													$strDevice		=	'Pump '.$deviceNumber;
												}
												else if($deviceType	== 'V')
												{
													$existingStatus 	=	${'sValves'.$ipID}[$deviceNumber];
													if($sStatus != $existingStatus)
													{
														$sNewResp = replace_return(${'sValves'.$ipID}, $sStatus, $deviceNumber);
														${'sValves'.$ipID} = $sNewResp;
														
														echo '<pre>Next VALVE ON :';print_r($deviceNumber.'>>'.$sStatus.'>>'.$ipID.'>>'.${'sValves'.$ipID});echo '</pre>';
														##onoff_rlb_valve($sNewResp,${'board'.$ipID},$sPort,${'shhPort'.$ipID});
													}
													
													$strDevice	=	'Valve '.$deviceNumber;	
												}
												else if($deviceType	== 'R')
												{
													$existingStatus 	=	${'sRelays'.$ipID}[$deviceNumber];
													if($sStatus != $existingStatus)
													{
														$sNewResp = replace_return(${'sRelays'.$ipID}, $sStatus, $deviceNumber);
														${'sRelays'.$ipID} = $sNewResp;
														
														echo '<pre>Next RELAY ON :';print_r($deviceNumber.'>>'.$sStatus.'>>'.$ipID.'>>'.${'sRelays'.$ipID});echo '</pre>';
														##onoff_rlb_relay($sNewResp,${'board'.$ipID},$sPort,${'shhPort'.$ipID});
													}
													
													//START : Check if heater is assigned to that relay.
													$heaterNum = $this->home_model->chkHeater($deviceNumber,'24',$ipID);
													
													if($heaterNum != '')
													{
														$aHeaterDetails  =   $this->home_model->getHeaterDeviceDetails($heaterNum,$ipID);
														if(!empty($aHeaterDetails))
														{
															foreach($aHeaterDetails as $aHeater)
															$sHeaterDetails  =   unserialize($aHeater->light_relay_number);
															
															$PumpNumber   		=   $sHeaterDetails['Pump'];
															
															$maxRun   		=   $sHeaterDetails['maxRun'];
											
															$sHeaterStart 	=   date("Y-m-d H:i:s", time());
															$arrStart		=	explode(" ",$sHeaterStart);
															$aStartDate    	=   explode("-",$arrStart[0]);
															$aStartTime    	=   explode(":",$arrStart[1]);
															
															$sProgramAbsEnd   =   mktime($aStartTime[0],($aStartTime[1]+$maxRun),$aStartTime[2],$aStartDate[1],$aStartDate[2],$aStartDate[0]);
															$sHeaterEnd     =   date("Y-m-d H:i:s", $sProgramAbsEnd);
															
															$this->home_model->insertHeaterRunDetails($heaterNum,$ipID,$sHeaterStart,$sHeaterEnd);
															
														}
														if($PumpNumber != '')
														{
															$aPumpDetails =	$this->home_model->getPumpDetails($PumpNumber,$ipID);
															if(!empty($aPumpDetails))
															{
																foreach($aPumpDetails as $sPump)
																{
																	##$this->cronMakePumpOnOFF($sPump->pump_number,'1',${'board'.$ipID},$sPort,${'shhPort'.$ipID},$ipID);
																}
															}
														}
													}
													//END : Check if heater is assigned to that relay. 
													
													$strDevice	=	'Relay '.$deviceNumber;
												}
												else if($deviceType	== 'P')
												{
													$existingStatus 	=	${'sPowerCenter'.$ipID}[$deviceNumber];
													if($sStatus != $existingStatus)
													{
														$sNewResp = replace_return(${'sPowerCenter'.$ipID}, $sStatus, $deviceNumber);
														${'sPowerCenter'.$ipID} = $sNewResp;
														
														echo '<pre>Next Power ON :';print_r($deviceNumber.'>>'.$sStatus.'>>'.$ipID.'>>'.${'sPowerCenter'.$ipID});echo '</pre>';
														##onoff_rlb_powercenter($sNewResp,${'board'.$ipID},$sPort,${'shhPort'.$ipID});
													}
													
													//START : Check if heater is assigned to that relay.
													$heaterNum = $this->home_model->chkHeater($deviceNumber,'12',$ipID);
													
													if($heaterNum != '')
													{
														
														$aHeaterDetails  =   $this->home_model->getHeaterDeviceDetails($heaterNum,$ipID);
														if(!empty($aHeaterDetails))
														{
															foreach($aHeaterDetails as $aHeater)
															$sHeaterDetails  =   unserialize($aHeater->light_relay_number);
															
															$PumpNumber   		=   $sHeaterDetails['Pump'];
															$maxRun   		=   $sHeaterDetails['maxRun'];
											
															$sHeaterStart 	=   date("Y-m-d H:i:s", time());
															$arrStart		=	explode(" ",$sHeaterStart);
															$aStartDate    	=   explode("-",$arrStart[0]);
															$aStartTime    	=   explode(":",$arrStart[1]);
															
															$sProgramAbsEnd   =   mktime($aStartTime[0],($aStartTime[1]+$maxRun),$aStartTime[2],$aStartDate[1],$aStartDate[2],$aStartDate[0]);
															$sHeaterEnd     =   date("Y-m-d H:i:s", $sProgramAbsEnd);
															
															$this->home_model->insertHeaterRunDetails($heaterNum,$ipID,$sHeaterStart,$sHeaterEnd);
															
														}
														if($PumpNumber != '')
														{
															$aPumpDetails =	$this->home_model->getPumpDetails($PumpNumber,$ipID);
															if(!empty($aPumpDetails))
															{
																foreach($aPumpDetails as $sPump)
																{
																	##$this->cronMakePumpOnOFF($sPump->pump_number,'1',${'board'.$ipID},$sPort,${'shhPort'.$ipID},$ipID);
																}
															}
														}
													}
													//END : Check if heater is assigned to that relay. 
													
													$strDevice	=	'Power Center '.$deviceNumber;
												}
												
												
												$arrDetails		=	array('program_id'=>$programID,		  'current_on_device'=>$strDevice,'device_type'=>$deviceType,  'device_number'=>$deviceNumber, 'current_on_time'=>$sRunTime,  'current_sequence'=>$nextSeq,	  'ip_id'=>$ipID,			  'unique_id'=>$unique_id);
												
												$this->custom_model->saveCustomCurrentRunningDevice($arrDetails);
											}
										}
										else
										{
											$currentDevice = $this->custom_model->getCustomProgrmaCurrentDevice($programID);
											if($currentDevice == '')
											{
												$this->home_model->updateRunningStatusCustomProgram($programID,'0');
												$this->custom_model->offCustomProgram($programID,'0');
												
												foreach($arrProgramValve as $valveDevice)
												{
													$arrTemp 			=	explode("_",$valveDevice);
													$ipIDTemp			=	$arrTemp[0];
													$sStatusTemp		=	$arrTemp[1];
													$deviceNumberTemp	=	$arrTemp[2];
													
													#START : GET Default Pool auto Position.
													$defaultPosition 	=	$this->home_model->getValveDefaultPosition($deviceNumberTemp,$ipIDTemp);
													
													$sNewResp = replace_return(${'sValves'.$ipIDTemp}, $defaultPosition, $deviceNumberTemp);
													${'sValves'.$ipIDTemp} = $sNewResp;
													##onoff_rlb_valve($sNewResp,${'board'.$ipIDTemp},$sPort,${'shhPort'.$ipIDTemp});						
													#END : GET Default Pool auto Position.
													
													//START : INSERT THE VALVE DETAILS TO RUN VALVE FOR GIVEN TIME IN POOL MODE AUTO. IF TIME IS NOT SPECIFIED THEN IT WILL RUN FOR 1 MIN DEFAULT.
													$runTime = $this->home_model->getValveDefaultPositionTime($deviceNumberTemp,$ipIDTemp);
													if($runTime == 0)
													{
														$runTime = 1;
													}
													if($runTime == '')
													{
														$runTime = 1;
													}	
													
													$arrValveDefaultRunDetails	=	array('program_id'=>$programID,'valve'=>$deviceNumberTemp,'ip_id'=>$ipIDTemp,'runTime'=>$runTime);
													$this->home_model->insertValveDefaultRunDetails($arrValveDefaultRunDetails);
													
													//END : INSERT THE VALVE DETAILS TO RUN VALVE FOR GIVEN TIME IN POOL MODE AUTO. IF TIME IS NOT SPECIFIED THEN IT WILL RUN FOR 1 MIN DEFAULT.
													
												}
												
												$this->home_model->removePreviousPositions($programID);
												
												echo '<pre>';print_r('Program OFF');echo '</pre>';
												
												/* if(!empty($arrAfterProgramDevice))
												{
													
													$this->home_model->updateAfterProgram($programID,'1');
													$this->customProgramRunAfter($programID,$arrAfterProgramDevice,$unique_id,$arrExtraDetails);
												}
												else
												{
													$this->custom_model->offCustomProgram($programID,'0');
												} */
											}
										}
									}
								}
							}
						}
					}
				}
			}
		}
	}
	###################################################################
	
	 	
}
/* $connection = ssh2_connect('70.170.34.162', 22);
ssh2_auth_password($connection, 'pi', 'lucky777');

$stream = ssh2_exec($connection, 'rlb s');

var_dump($stream); */


/*
$zipFilename = 'relayboard_2016-07-06_23-47-26.zip';
$zipFilePath = '/var/www/html/'.$zipFilename;
set_time_limit(0); //Unlimited max execution time

echo $path = $zipFilePath;
echo '<br>'.$url = 'http://www.lvnvacationhomerentals.com/relayboard/'.$zipFilename;
//die('STOP');
$newfname = $path;
$file = fopen ($newfname, "rb");
if($file) {
		$newf = fopen ($url, "wb");
		if($newf)
		{
			while(!feof($file)) {
					fwrite($newf, fread($file, 1024 * 8 ), 1024 * 8 );
			}
		}
}*/

/*// initialise the curl request
$request = curl_init('http://www.lvnvacationhomerentals.com/relayboard/');

// send a file
curl_setopt($request, CURLOPT_POST, true);
curl_setopt(
	$request,
	CURLOPT_POSTFIELDS,
	array(
	'file' => '@' . $zipFilePath.';filename='.$zipFilename
	));

// output the response
curl_setopt($request, CURLOPT_RETURNTRANSFER, true);
echo curl_exec($request);

// close the session
curl_close($request);*/

/*$ftp_server 	= 'lvnvacationhomerentals.com';
$ftp_user_name 	= 'lvnv3098';
$ftp_user_pass 	= 'V@cationH0mes';
$conn_id 	= ftp_connect($ftp_server);
ftp_login($conn_id, $ftp_user_name, $ftp_user_pass);
ftp_chdir($conn_id, '/relayboard');
ftp_put($conn_id, $zipFilename, $zipFilePath, FTP_BINARY);
ftp_put($conn_id, 'relayboard/'.$zipFilename, $zipFilePath, FTP_BINARY); 
unlink($filename);
unlink($zipFilePath);
ftp_close($conn_id);*/
?>


