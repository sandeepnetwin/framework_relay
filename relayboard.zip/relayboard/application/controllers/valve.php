<?php
/**
* @Programmer: Dhiraj S.
* @Created: 16 May 2016
* @Modified: 
* @Description: Valve Controller for all valve related functionality.
**/

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Valve extends CI_Controller 
{
    public $userID,$aPermissions,$aModules,$aAllActiveModule;
	
    public function __construct()  
    {
        parent::__construct();
		$this->load->library('form_validation');
        $this->load->helper('common_functions'); //Common functions will be available for all functions in the file.
		
        if (!$this->session->userdata('is_admin_login')) //START : Check if user login or not.
        {
            redirect('dashboard/login/');
            die;
        }  //END : Check if user login or not. 
		
        //Get Permission Details
        if($this->userID == '')
        $this->userID = $this->session->userdata('id');

        if($this->aPermissions == '')
        {
            $this->aPermissions 	= json_decode(getPermissionOfModule($this->userID));
            $this->aModules 		= $this->aPermissions->sPermissionModule;	
            $this->aAllActiveModule     = $this->aPermissions->sActiveModule;
        }
   }

	public function Programs() // START : Function to save/update/delete the Programs to run valve in Auto mode.
    {
        $aViewParameter              =   array(); // Array for passing parameter to view.
        $aViewParameter['page']      =   'home';
        $aViewParameter['sucess']    =   '0';
		$aViewParameter['Title']     =   'Valve Program';
        
        //Get Values From URL.
        $sDeviceID      =   base64_decode($this->uri->segment('3')); // Get Device ID
        $sProgramID     =   base64_decode($this->uri->segment('4')); // Get Program ID 
        $sProgramDelete =   $this->uri->segment('5');// Get value for delete

        $this->load->model('home_model');

        if($sDeviceID == '') //START : Check if Device id is blank then redirect to the device list page
        {
            $sDeviceID  =   base64_decode($this->input->post('sDeviceID'));
            if($sDeviceID == '') // IF Device ID not present in POST redirect to the Device List
                redirect(site_url('home/setting/V/'));
        }
       
        //Parameter for View
        $aViewParameter['sDeviceID']    =   $sDeviceID;
        
        if($this->input->post('command') == 'Save') // START : Save program details.
        {
            if($this->input->post('sRelayNumber') != '')
                $sDeviceID   =  $this->input->post('sRelayNumber');

            $this->home_model->saveProgramDetails($this->input->post(),$sDeviceID,'V',str_replace('ip=','',$sProgramID));
            $aViewParameter['sucess']    =   '1';
        }// END : Save program details.

        if($this->input->post('command') == 'Update' && !preg_match('/ip=/',$sProgramID)) // START : Update program details.
        {
            if($sProgramID == '') //START : Check if Program id is blank then redirect
            {
                $sProgramID  =   base64_decode($this->input->post('sProgramID'));
                if($sProgramID == '') // IF Program ID not present in POST redirect
                    redirect(site_url('valve/Programs/'.base64_encode($sDeviceID)));
            }  

            if($this->input->post('sRelayNumber') != '')
                $sDeviceID   =  $this->input->post('sRelayNumber'); 
			
            $this->home_model->updateProgramDetails($this->input->post(),$sProgramID,$sDeviceID,'V');
			
			$programDetails =	 $this->home_model->getProgramDetails($sProgramID);
			$ipID			=	'';
			foreach($programDetails as $row)
			{
				$ipID	=	$row->ip_id;
			}
			
            redirect(site_url('valve/Programs/'.base64_encode($sDeviceID).'/'.base64_encode('ip='.$ipID)));
        }// END : Update program details.

        if($sProgramDelete != '' && $sProgramDelete == 'D') // START : Delete program details.
        {
            if($sProgramID == '')
            {
                $sProgramID  =   base64_decode($this->input->post('sProgramID'));
                if($sProgramID == '')
                    redirect(site_url('home/setting/V/'));
            }
			
			$programDetails =	 $this->home_model->getProgramDetails($sProgramID);
			$ipID			=	'';
			foreach($programDetails as $row)
			{
				$ipID	=	$row->ip_id;
			}
			
            $this->home_model->deleteProgramDetails($sProgramID);
            redirect(site_url('valve/Programs/'.base64_encode($sDeviceID).'/'.base64_encode('ip='.$ipID)));
        } // START : Delete program details.

        // Get saved program details     
        $aViewParameter['sProgramDetails'] = $this->home_model->getProgramDetailsForDevice($sDeviceID,'V',str_replace('ip=','',$sProgramID));

        if($sProgramID != '') //If program exists the get program details.
        {
            $aViewParameter['sProgramID'] = $sProgramID;
			if(!preg_match('/ip=/',$sProgramID))
				$aViewParameter['sProgramDetailsEdit'] = $this->home_model->getProgramDetails($sProgramID);
			else
				$aViewParameter['sProgramDetailsEdit'] = '';
        }
        else
        {
            $aViewParameter['sProgramID']          = ''; 
            $aViewParameter['sProgramDetailsEdit'] = '';
        }
        
		$aViewParameter['sDeviceTime'] =  $this->home_model->getDeviceTime($sDeviceID,'V');
		
		//Permission related parameters.
		$aViewParameter['userID'] 			= $this->userID;
		$aViewParameter['aModules'] 		= $this->aModules;
		$aViewParameter['aAllActiveModule'] = $this->aAllActiveModule;
		
        //Program View for Getting and Showing Programs
        $this->template->build('ValvePrograms',$aViewParameter); 
    } // END : Function to save/update/delete the Programs to run relay in Auto mode.
	
	// START : Function to save/update/ Default position of the Valve for the Pool Auto mode.
	public function defaultPosition() 
    {
		$aViewParameter              =   array(); // Array for passing parameter to view.
        $aViewParameter['page']      =   'home';
        $aViewParameter['sucess']    =   '0';
		$aViewParameter['Title']     =   'Valve Default Position';
		
		$sDeviceID	=   base64_decode($this->uri->segment('3')); // Get Device ID
        $sIpID		=   base64_decode($this->uri->segment('4')); // Get Device IP ID 
		
		$aViewParameter['sDeviceID'] 	= $sDeviceID;
		$aViewParameter['sIpID'] 		= $sIpID;
		
		//Load Required Models.
		$this->load->model('home_model');
		$this->load->model('user_model');
		
		if($this->input->post('command') == 'Save')
		{
			$selectedPosition	=	$this->input->post('position');
			$PositionTime		=	$this->input->post('positiontime');
			
			//Save/Update the Default Position.
			$this->home_model->saveValveDefaultPosition($sDeviceID,$sIpID,$selectedPosition,$PositionTime);
			$aViewParameter['sucess']    =   '1';
		}
		
		//START : GET SAVED Default Position.		
		$existPosition	=	$this->home_model->getValveDefaultPosition($sDeviceID,$sIpID);
		$aViewParameter['existPosition'] = $existPosition;
		
		//START : GET SAVED Default Position.		
		$existPositionTime	=	$this->home_model->getValveDefaultPositionTime($sDeviceID,$sIpID);
		if($existPositionTime == 0)
			$existPositionTime = '';
		
		$aViewParameter['existPositionTime'] = $existPositionTime;
		
		
		//Get all Positions
		$aViewParameter['aAllPositions'] 	= $this->user_model->getAllPositions();
		
		//Get Valve Relay Number
		$aViewParameter['aRelayNumber']		= json_decode($this->home_model->getValveRelayNumber($sDeviceID,'V',$sIpID));
		
		//Get Existing saved position names for Device
        list($aViewParameter['sPositionName1'],$aViewParameter['sPositionName2'])      =   $this->home_model->getPositionName($sDeviceID,'V',$sIpID);
		
		$this->template->build('ValveDefaultPosition',$aViewParameter); 
		
	}
	// END : Function to save/update/ Default position of the Valve for the Pool Auto mode.
	
    
}//END : Class Valve

/* End of file valve.php */
/* Location: ./application/controllers/valve.php */