<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

require_once(APPPATH.'controllers/home.php'); 

class Analog extends CI_Controller 
{
    public function __construct() 
    {
        parent::__construct();
        $this->load->library('form_validation');
        $this->load->helper('common_functions');
		if (!$this->session->userdata('is_admin_login')) 
        {
            redirect('dashboard/login/');
			die;
        }
        
    }
    
    public function index()
    {
        $aViewParameter =   array();
        
        $aViewParameter['page'] 	=	'home';
        $this->load->model('analog_model');
        $aViewParameter['sucess'] 	=   '0';
		$aViewParameter['Title']    =   'Inputs';

        
        $aObjHome = new Home();   
        $aObjHome->checkSettingsSaved(); 
        
        $sResponse      =   get_rlb_status();

        $sValves        =   $sResponse['valves'];
        $sRelays        =   $sResponse['relay'];
        $sPowercenter   =   $sResponse['powercenter'];
        
        $sPump          =   array($sResponse['pump_seq_0_st'],
                                  $sResponse['pump_seq_1_st'],
                                  $sResponse['pump_seq_2_st']);

        $aViewParameter['sValves']          =   $sValves;
        $aViewParameter['sRelays']          =   $sRelays;
        $aViewParameter['sPowercenter']     =   $sPowercenter; 
        $aViewParameter['sPump']            =   $sPump;

        $aViewParameter['relay_count']      =   strlen($sRelays);
        $aViewParameter['valve_count']      =   strlen($sValves);
        $aViewParameter['power_count']      =   strlen($sPowercenter);
        $aViewParameter['pump_count']       =   count($sPump);
        

        if($this->input->post('command') == 'Save')
        {
            $sDeviceName = $this->input->post('sDeviceName');
            $this->analog_model->saveAnalogDevice($sDeviceName);
            $aViewParameter['sucess'] =   '1';
        }

        $aAllAnalogDevice          = $this->analog_model->getAllAnalogDevice();
        $aAllANalogDeviceDirection = $this->analog_model->getAllAnalogDeviceDirection();
        
        $aViewParameter['aResponse']    =   array('AP0' => $sResponse['AP0'],
                                                  'AP1' => $sResponse['AP1'],
                                                  'AP2' => $sResponse['AP2'],
                                                  'AP3' => $sResponse['AP3']);

        $aViewParameter['aAllAnalogDevice']             =   $aAllAnalogDevice;
        $aViewParameter['aAllANalogDeviceDirection']    =   $aAllANalogDeviceDirection;  

        $this->template->build('Analog',$aViewParameter);
    }

    public function changeMode()
    {
        $aViewParameter['sucess']       =   '0';
        $aViewParameter['err_sucess']   =   '0';
        $aViewParameter['page']         =   'home';

        $this->load->model('home_model');
		$iActiveMode	= $this->home_model->getActiveMode();
		$sManualTime	= $this->home_model->getManualModeTime();
		
        if($this->input->post('iMode') != '')
        {
            $iMode = $this->input->post('iMode');
			if($iActiveMode != $iMode)
			{
				$this->home_model->updateMode($iMode);
				if($sManualTime != '')
				{
					if($iMode == 2)
					{
						$sProgramAbsStart =   date("H:i:s", time());
						$aStartTime       =   explode(":",$sProgramAbsStart);
						$sProgramAbsEnd   =   mktime(($aStartTime[0]),($aStartTime[1]+$sManualTime),($aStartTime[2]),0,0,0);
						$sAbsoluteEnd     =   date("H:i:s", $sProgramAbsEnd);
						$this->home_model->updateManualModeTimer($sProgramAbsStart,$sAbsoluteEnd);
					}
					else
					{
						$this->home_model->updateManualModeTimer('','');
					}	
				}
			}
			

            if($iMode == 3 || $iMode == 1)
            { //1-auto, 2-manual, 3-timeout
		
				$sResponse      =   get_rlb_status();
				$sValves        =   $sResponse['valves'];
				$sRelays        =   $sResponse['relay'];
				$sPowercenter   =   $sResponse['powercenter'];
				
                //off all relays
                if($sRelays != '')
                {
                    $sRelayNewResp = str_replace('1','0',$sRelays);
                    onoff_rlb_relay($sRelayNewResp);
                }
                
                //off all valves
                if($sValves != '')
                {
                    $sValveNewResp = str_replace(array('1','2'), '0', $sValves);
                    onoff_rlb_valve($sValveNewResp);  
                }
                
                //off all power center
                if($sPowercenter != '')
                {
                    $sPowerNewResp = str_replace('1','0',$sPowercenter);  
                    onoff_rlb_powercenter($sPowerNewResp); 
                } 

            }
             $aViewParameter['sucess']    =   '1';

        }

        $aViewParameter['iMode']  =   $this->home_model->getActiveMode();

        $this->load->view("Mode",$aViewParameter);

    }
	
	public function changeModeManual()
    {
		$aViewParameter['Title']    =   'Modes';
		$userID = $this->session->userdata('id');
		
		$aPermissions 		= json_decode(getPermissionOfModule($userID));
		$aModules 			= $aPermissions->sPermissionModule;	
		$aAllActiveModule   = $aPermissions->sActiveModule;
		
		
        $aViewParameter['sucess']       =   '0';
        $aViewParameter['err_sucess']   =   '0';
        $aViewParameter['page']         =   'home';

        $this->load->model('home_model');
		$iActiveMode	= $this->home_model->getActiveMode();
		$sManualTime	= $this->home_model->getManualModeTime();
		
        if($this->input->post('iMode') != '')
        {
            $iMode = $this->input->post('iMode');
			if($iActiveMode != $iMode)
			{
				$this->home_model->updateMode($iMode);
				if($sManualTime != '')
				{
					if($iMode == 2)
					{
						$sProgramAbsStart =   date("H:i:s", time());
						$aStartTime       =   explode(":",$sProgramAbsStart);
						$sProgramAbsEnd   =   mktime(($aStartTime[0]),($aStartTime[1]+$sManualTime),($aStartTime[2]),0,0,0);
						$sAbsoluteEnd     =   date("H:i:s", $sProgramAbsEnd);
						$this->home_model->updateManualModeTimer($sProgramAbsStart,$sAbsoluteEnd);
					}
					else
					{
						$this->home_model->updateManualModeTimer('','');
					}	
				}
			}
			

            if($iMode == 3 || $iMode == 1)
            { //1-auto, 2-manual, 3-timeout
		
				$sResponse      =   get_rlb_status();
				$sValves        =   $sResponse['valves'];
				$sRelays        =   $sResponse['relay'];
				$sPowercenter   =   $sResponse['powercenter'];
				
                //off all relays
                if($sRelays != '')
                {
                    $sRelayNewResp = str_replace('1','0',$sRelays);
                    onoff_rlb_relay($sRelayNewResp);
                }
                
                //off all valves
                if($sValves != '')
                {
                    $sValveNewResp = str_replace(array('1','2'), '0', $sValves);
                    onoff_rlb_valve($sValveNewResp);  
                }
                
                //off all power center
                if($sPowercenter != '')
                {
                    $sPowerNewResp = str_replace('1','0',$sPowercenter);  
                    onoff_rlb_powercenter($sPowerNewResp); 
                } 

            }
             $aViewParameter['sucess']    =   '1';

        }

        $aViewParameter['iMode']  =   $this->home_model->getActiveMode();
		
		//Permission related parameters.
		$aViewParameter['userID'] 			= $userID;
		$aViewParameter['aModules'] 		= $aModules;
		$aViewParameter['aAllActiveModule'] = $aAllActiveModule;
        $this->template->build("Mode",$aViewParameter);

    }
}

?>
