<?php
/**
* @Programmer: SMW
* @Created: 25 Mar 2015
* @Modified: 
* @Description: Functions for display and set the relay valve values.
**/

	/* function relayboard_command($sUrl)
	{
		return send_command_udp($sUrl);
	} */
	
	function send_command_udp($aData)
	{
		$sServer = $aData['ip_address'];
		$iPort   = $aData['port_no'];
		$sInput  = $aData['data'];
		$sShhPort= $aData['ssh_port'];
		
		if(IS_LOCAL == '1')	
		{
			$connection = ssh2_connect($sServer, $sShhPort);
			ssh2_auth_password($connection, 'pi', 'lucky777');

			$stream = ssh2_exec($connection, 'rlb '.$sInput);
			
			stream_set_blocking($stream, true);
			
			$sReply = stream_get_contents($stream);
		}
		else
		{
			$fp =  fsockopen("udp://$sServer", $iPort, $iErrorcode, $sErrormsg,3);
			if (!$fp) {
				die("Could not send data: [$iErrorcode] $sErrormsg \n");
			} else {
				fwrite($fp, "$sInput");
				$sReply = fread($fp, 1024);
				fclose($fp);
			}
        }        
        //Check for invalid response.
		$iCommaCount = substr_count($sReply, ",");
		if(stripos($sReply, '?') !== FALSE)
		{
			return "Invalid response: $sReply \n";
		}
		//if(hardware,busy)
		return $sReply;
	}
	
	function system_command($command)
	{
		//system($command);
		
		
	}
	
	function send_command_udp_new_test($sDeviceNumber,$sIP,$sPort,$sShhPort){
		/* $sCommand = 'm'.$sDeviceNumber." s";
		
		$aData	  = array();
		$aData['ip_address'] = $sIP;
		$aData['port_no']    = $sPort;
		$aData['data']  	 = $sCommand;
		$aData['ssh_port']	 = $sShhPort;
		
		$sResponse = send_command_udp($aData);		
		return $sResponse; */
		
		//$aPumpNumber	=	json_decode($aPumps);
		$sServer 		= 	$sIP;
		$iPort 			=	$sPort;
		
		$cntPump		=	count($aPumpNumber);
		
		$server = $sServer;
		$port = 13330;
		
		if(!($sSock = socket_create(AF_INET, SOCK_DGRAM, 0)))
		{
			$iErrorcode = socket_last_error();
			$sErrormsg = socket_strerror($iErrorcode);
			 
			die("Couldn't create socket: [$iErrorcode] $sErrormsg \n");
		} 
		
		socket_connect ( $sSock , $server , $port );
		//$line = socket_read ($sSock, 1024) or die("Could not read server response\n");
		//var_dump($line);
		//$package = "\x07\x00";
		//socket_send($sSock, $package, strLen($package), 0);
		//$line1 = socket_read($sSock, 255);
		
		$package = "m1 s";
		socket_send($sSock, $package, strLen($package), 0);
		$strResponse = socket_read($sSock, 255);
		echo 'Response : '.$strResponse;
		die('STOP');
		
	}
	
	function send_command_udp_new($IP,$PORT,$aPumps)
	{
		$aPumpNumber	=	json_decode($aPumps);
		$sServer 		= 	$IP;
		$iPort 			=	$PORT;
		
		$cntPump		=	count($aPumpNumber);
		
		$server = $sServer;
		$port = 13330;
		
		if(!($sSock = socket_create(AF_INET, SOCK_DGRAM, 0)))
		{
			$iErrorcode = socket_last_error();
			$sErrormsg = socket_strerror($iErrorcode);
			 
			die("Couldn't create socket: [$iErrorcode] $sErrormsg \n");
		} 
		
		socket_connect ( $sSock , $server , $port );
		//$line = socket_read ($sSock, 1024) or die("Could not read server response\n");
		//var_dump($line);
		$package = "\x07\x00";
		socket_send($sSock, $package, strLen($package), 0);
		$line1 = socket_read($sSock, 255);
		$strPumpResponse	= '';
		
		//var_dump($line1);
		//die('STOP');
		$package = "\x06\x00";
		socket_send($sSock, $package, strLen($package), 0);
		//echo $cntPump;
		
		for($i=0;$i<$cntPump; $i++)
		{
			$strResponse = socket_read($sSock, 255);
			while(preg_match('/^S/',$strResponse))
			{
                $strResponse = socket_read($sSock, 255);
			}
			
			if($strPumpResponse == '')
			{
				$strPumpResponse = $strResponse;
			}
			else
			{
				$strPumpResponse .= '|||'.$strResponse;
			}				
		}
		
		$package ="\x7f\x00";
		socket_send($sSock, $package, strLen($package), 0);
		
		//$line3 = socket_read($sSock, 255);
		//var_dump($line3); 
		
		socket_close($sSock);
		//die('STOP');
		return $strPumpResponse;
	}
	
	function response_input_switch($IP,$PORT)
	{
		if(!($sSock = socket_create(AF_INET, SOCK_DGRAM, 0))) //Create Socket to listen.
		{
			$iErrorcode = socket_last_error();
			$sErrormsg = socket_strerror($iErrorcode);
			 
			die("Couldn't create socket: [$iErrorcode] $sErrormsg \n");
		} 
		
		socket_connect ( $sSock , $IP , $PORT );
		$package = "\x07\x00\x06\x00\x7f\x00";
		socket_send($sSock, $package, strLen($package), 0);
		
		$strPumpResponse	= '';
		
		$strResponse = socket_read($sSock, 255);
		while(!preg_match('/^S/',$strResponse))
		{
			$strResponse = socket_read($sSock, 255);
		}			
		socket_close($sSock);
		return $strResponse;
		
		
		/*---------*/
		
		/* $addr = $IP;
		$port = 13330;
		$sock = socket_create(AF_INET, SOCK_DGRAM, 0);
		if(!socket_bind($sock, $addr, $port))
		{
			$iErrorcode = socket_last_error();
			$sErrormsg = socket_strerror($iErrorcode);
			die("Could not bind to address: [$iErrorcode] $sErrormsg \n");
		}	//		or die('Could not bind to address');
		//socket_connect ( $sock , $addr , $port );
		socket_listen($sock);

		$null = NULL;
		$clients = Array();
		$cc = 0; // loop counter

		//while(true)
		{

			echo $cc."<br>";
			$cc = $cc +1;

			$read[0] = $sock;

			$ready = socket_select($read,$null,$null,$null);    
			$client = socket_accept($sock);
			$input = socket_read($client, 312); 


			echo $input;
			var_dump($input);

			if($input == "exit"){
				socket_close($client);
				socket_close($sock);
				return false;
			}

			$output = '\x07\x00';
			socket_write($client,$output);
			$input = "";
		}  */
	}
	
	function checkResponse($Response,$arrCheck)
	{
		
	}
	
	function send_command_udp_new1($IP,$PORT)
	{
		$sServer = $IP;
		$iPort = $PORT;
		
		$server = $sServer;
		$port = 13330;
		
		if(!($sSock = socket_create(AF_INET, SOCK_DGRAM, 0)))
		{
			$iErrorcode = socket_last_error();
			$sErrormsg = socket_strerror($iErrorcode);
			 
			die("Couldn't create socket: [$iErrorcode] $sErrormsg \n");
		} 
		
		socket_connect ( $sSock , $server , $port );
		//$line = socket_read ($sSock, 1024) or die("Could not read server response\n");
		//var_dump($line);
		$package = "\x07\x00";
		socket_send($sSock, $package, strLen($package), 0);
		$line1 = socket_read($sSock, 255);
		//var_dump( $line1 );
		//$package = "\x06\x00";
		//socket_send($sSock, $package, strLen($package), 0);
		$line2 = socket_read($sSock, 255); 
		if(preg_match('/^S/',$line2))
		{
			$line2 = socket_read($sSock, 255);
			$line2 .= '|||'.socket_read($sSock, 255);				
		}
		
		socket_close($sSock);
		return $line2;
	}

	function send_to_rlb($sUrl,$sPort=''){
		//$sReturnUrl = get_url($sUrl);
		
		$CI = get_instance();
		$CI->load->model('home_model');
	    $aSettingDetails	=	$CI->home_model->getSettingDetails();

	   	$sReturnUrl = array();
		$sIpAddress = $aSettingDetails[0];
		
		$sReturnUrl['ip_address'] 	= $sIpAddress;
		$sReturnUrl['port_no'] 		= $sPort;
		$sReturnUrl['data'] 		= $sUrl;
		
		$sResult = send_command_udp($sReturnUrl);
		if ($sResult === false) 
		{
			return 0;
		}
		return 1;
	}

	function get_from_rlb($sUrl) {
		
		$sReturnUrl = get_url($sUrl);
		return $sResult = send_command_udp($sReturnUrl);
	}

	function get_url($sUrl)
	{
		$CI = get_instance();
		$CI->load->model('home_model');
	    $aSettingDetails	=	$CI->home_model->getSettingDetails();

	   	$sReturnUrl = array();
		$sIpAddress = $aSettingDetails[0];
		$sPortNo = $aSettingDetails[1];
		//Check for IP Address constant
		
		//Assign varible and return to udp port
		$sReturnUrl['ip_address'] = $sIpAddress;
		$sReturnUrl['port_no'] = $sPortNo;
		$sReturnUrl['data'] = $sUrl;
		
		return $sReturnUrl;
	}
	
	function get_rlb_status($sIP,$sPort,$sShhPort){
		$aReturn = array();
		$sCommand = 's';
		$aData	  = array();
			
		$aData['ip_address'] = $sIP;
		$aData['port_no']    = $sPort;
		$aData['data']  	 = $sCommand;
		$aData['ssh_port']	 = $sShhPort;
		$sResponse = send_command_udp($aData);
		
		/* if($sShhPort == '22')
		{			
			$sResponse	=	'S,232,0,7,09:42:05,3,06,000.....,......0000000000,00000000,0,0,0,0,12609,55.5F,51.9F,51.8F,,,,0.00,000000,0.00,00,00,00';
		}
		else if($sShhPort == '23')
		{
			$sResponse	=	'S,140,0,2,21:37:22,5,04,0.......,..00000000000000,00000000,0,0,0,0,12531,62.4F,,,,,,0.00,000000,0.00';
		}  */
			
		$aResponse = explode(',',$sResponse);
		
		$aReturn['response'] = $sResponse;
		//$aReturn['day'] = $aResponse['3'];
		$aReturn['day'] = (isset($aResponse['3'])) ? $aResponse['3'] : '';
		$aReturn['time'] = (isset($aResponse['4'])) ? $aResponse['4'] : '';
		$aReturn['valves'] = (isset($aResponse['7'])) ? $aResponse['7'] : '';
		$aReturn['relay'] = (isset($aResponse['8'])) ? $aResponse['8'] : '';
		$aReturn['powercenter'] = (isset($aResponse['9'])) ? $aResponse['9'] : '';
		
		$aReturn['TS0'] = (isset($aResponse['15'])) ? $aResponse['15'] : '';
		$aReturn['TS1'] = (isset($aResponse['16'])) ? $aResponse['16'] : '';
		$aReturn['TS2'] = (isset($aResponse['17'])) ? $aResponse['17'] : '';
		$aReturn['TS3'] = (isset($aResponse['18'])) ? $aResponse['18'] : '';
		$aReturn['TS4'] = (isset($aResponse['19'])) ? $aResponse['19'] : '';
		$aReturn['TS5'] = (isset($aResponse['20'])) ? $aResponse['20'] : '';
		
		$CI = get_instance();
		$CI->load->model('home_model');
		$ipID = $CI->home_model->getIdFromIP($sIP,$sShhPort);
		$arrOffset = array();
		if($ipID != '')
		{
			for($i=0;$i<6;$i++)
			{
				$arrOffset[$i] = $CI->home_model->getTemperatureOffset($i,$ipID);
				if($aReturn['TS'.$i] != '')
				{
					$temp = str_replace(array("F","C"),array("",""),$aReturn['TS'.$i]);
					$aReturn['TS'.$i] = number_format(($temp + $arrOffset[$i]),1);
				}
			}
		}

		$aReturn['AP0'] = (isset($aResponse['10'])) ? $aResponse['10'] : '';
		$aReturn['AP1'] = (isset($aResponse['11'])) ? $aResponse['11'] : '';
		$aReturn['AP2'] = (isset($aResponse['12'])) ? $aResponse['12'] : '';
		$aReturn['AP3'] = (isset($aResponse['13'])) ? $aResponse['13'] : '';		
				
		$aReturn['push'] = (isset($aResponse['22'])) ? $aResponse['22'] : '';
		$aReturn['level_sensor_instant'] = (isset($aResponse['21'])) ? $aResponse['21'] : '';
		$aReturn['remote_spa_ctrl_st'] = (isset($aResponse['22'])) ? $aResponse['22'] : '';
		$aReturn['level_sensor_avg'] = (isset($aResponse['23'])) ? $aResponse['23'] : '';
		$aReturn['pump_seq_0_st'] = (isset($aResponse['24'])) ? $aResponse['24'] : '';
		$aReturn['pump_seq_1_st'] = (isset($aResponse['25'])) ? $aResponse['25'] : '';
		$aReturn['pump_seq_2_st'] = isset($aResponse['26']) ? $aResponse['26'] : '';
		
		return $aReturn;
	}
	
	function get_rlb_status_shell(){
		$aReturn = array();
		$sUrl = 'rlb s';
		$sResponse = shell_exec($sUrl);
		$aResponse = explode(',',$sResponse);
		
		$aReturn['response'] = $sResponse;
		//$aReturn['day'] = $aResponse['3'];
		$aReturn['day'] = (isset($aResponse['3'])) ? $aResponse['3'] : '';
		$aReturn['time'] = (isset($aResponse['4'])) ? $aResponse['4'] : '';
		$aReturn['valves'] = (isset($aResponse['7'])) ? $aResponse['7'] : '';
		$aReturn['relay'] = (isset($aResponse['8'])) ? $aResponse['8'] : '';
		$aReturn['powercenter'] = (isset($aResponse['9'])) ? $aResponse['9'] : '';
		
		$aReturn['TS0'] = (isset($aResponse['15'])) ? $aResponse['15'] : '';
		$aReturn['TS1'] = (isset($aResponse['16'])) ? $aResponse['16'] : '';
		$aReturn['TS2'] = (isset($aResponse['17'])) ? $aResponse['17'] : '';
		$aReturn['TS3'] = (isset($aResponse['18'])) ? $aResponse['18'] : '';
		$aReturn['TS4'] = (isset($aResponse['19'])) ? $aResponse['19'] : '';
		$aReturn['TS5'] = (isset($aResponse['20'])) ? $aResponse['20'] : '';

		$aReturn['AP0'] = (isset($aResponse['10'])) ? $aResponse['10'] : '';
		$aReturn['AP1'] = (isset($aResponse['11'])) ? $aResponse['11'] : '';
		$aReturn['AP2'] = (isset($aResponse['12'])) ? $aResponse['12'] : '';
		$aReturn['AP3'] = (isset($aResponse['13'])) ? $aResponse['13'] : '';		
				
		$aReturn['push'] = (isset($aResponse['22'])) ? $aResponse['22'] : '';
		$aReturn['level_sensor_instant'] = (isset($aResponse['21'])) ? $aResponse['21'] : '';
		$aReturn['remote_spa_ctrl_st'] = (isset($aResponse['22'])) ? $aResponse['22'] : '';
		$aReturn['level_sensor_avg'] = (isset($aResponse['23'])) ? $aResponse['23'] : '';
		$aReturn['pump_seq_0_st'] = (isset($aResponse['24'])) ? $aResponse['24'] : '';
		$aReturn['pump_seq_1_st'] = (isset($aResponse['25'])) ? $aResponse['25'] : '';
		$aReturn['pump_seq_2_st'] = isset($aResponse['26']) ? $aResponse['26'] : '';
		
		return $aReturn;
	}

	function replace_return($sStr, $sReplace, $iReplace){
		$iStrCount = strlen($sStr);
		$sReturn = '';
		for($iStr = 0; $iStr < $iStrCount; $iStr++){
			if($iStr == $iReplace){
				$sReturn .= $sReplace;
			}else{
				$sReturn .= $sStr[$iStr];
			}
		}
		return $sReturn;
	}
	
	function onoff_rlb_relay($sRelayStatus,$sIP,$sPort,$sShhPort)
	{
		$sCommand = 'R,'.$sRelayStatus;
		
		$aData	  = array();
		
		$aData['ip_address'] = $sIP;
		$aData['port_no']    = $sPort;
		$aData['data']  	 = $sCommand;
		$aData['ssh_port']	 = $sShhPort;
		
		$sResponse = send_command_udp($aData);
		
		return $sResponse;
	}
	
	
	function onoff_rlb_powercenter($sPowercenterStatus,$sIP,$sPort,$sShhPort)
	{
		$sCommand = 'B,'.$sPowercenterStatus;
		
		$aData	  = array();
		$aData['ip_address'] = $sIP;
		$aData['port_no']    = $sPort;
		$aData['data']  	 = $sCommand;
		$aData['ssh_port']	 = $sShhPort;
		
		$sResponse = send_command_udp($aData);		
		return $sResponse;
	}
	
	function onoff_rlb_valve($sRelayStatus,$sIP,$sPort,$sShhPort){
		$sCommand = 'V,'.$sRelayStatus;
		
		$aData	  = array();
		$aData['ip_address'] = $sIP;
		$aData['port_no']    = $sPort;
		$aData['data']  	 = $sCommand;
		$aData['ssh_port']	 = $sShhPort;
		
		$sResponse = send_command_udp($aData);		
		return $sResponse;
	}

	function onoff_rlb_pump($sRelayStatus,$sIP,$sPort,$sShhPort){
		//$sCommand = 'm '.$sRelayStatus;
		$sCommand = 'm'.$sRelayStatus;
		
		$aData	  = array();
		$aData['ip_address'] = $sIP;
		$aData['port_no']    = $sPort;
		$aData['data']  	 = $sCommand;
		$aData['ssh_port']	 = $sShhPort;
		
		$sResponse = send_command_udp($aData);		
		return $sResponse;
	}
	
	function getAddressToPump($sDeviceNumber,$sIP,$sPort,$sShhPort){
		$sCommand = 'p pm'.$sDeviceNumber;
		
		$aData	  = array();
		$aData['ip_address'] = $sIP;
		$aData['port_no']    = $sPort;
		$aData['data']  	 = $sCommand;
		$aData['ssh_port']	 = $sShhPort;
		
		$sResponse = send_command_udp($aData);		
		return $sResponse;
	}
	
	function assignAddressToPump($sDeviceNumber,$sAddress,$sIP,$sPort,$sShhPort){
		$sCommand = 'p pm'.$sDeviceNumber.' '.$sAddress;
		
		$aData	  = array();
		$aData['ip_address'] = $sIP;
		$aData['port_no']    = $sPort;
		$aData['data']  	 = $sCommand;
		$aData['ssh_port']	 = $sShhPort;
		
		$sResponse = send_command_udp($aData);		
		return $sResponse;
	}
	
	function assignValvesToRelay($sHexNumber,$sIP,$sPort,$sShhPort){
		$sCommand = 'p vlm '.$sHexNumber;
		
		$aData	  = array();
		$aData['ip_address'] = $sIP;
		$aData['port_no']    = $sPort;
		$aData['data']  	 = $sCommand;
		$aData['ssh_port']	 = $sShhPort;
		
		$sResponse = send_command_udp($aData);		
		return $sResponse;
	}
	
	function getTempratureBus($sIP,$sPort,$sShhPort){
		$sCommand = 't';
		
		$aData	  = array();
		$aData['ip_address'] = $sIP;
		$aData['port_no']    = $sPort;
		$aData['data']  	 = $sCommand;
		$aData['ssh_port']	 = $sShhPort;
		
		$sResponse = send_command_udp($aData);		
		return $sResponse;
	}
	
	function configureTempratureBus($TS,$BUS,$sIP,$sPort,$sShhPort)
	{
		$sCommand = 'p '.$TS.' '.$BUS;
		
		$aData	  = array();
		$aData['ip_address'] = $sIP;
		$aData['port_no']    = $sPort;
		$aData['data']  	 = $sCommand;
		$aData['ssh_port']	 = $sShhPort;
		
		$sResponse = send_command_udp($aData);		
		return $sResponse;
	}
	
	function removePumpAddress($Pump,$sIP,$sPort,$sShhPort)
	{
		$sCommand = 'p '.$Pump.' 0';
		
		$aData	  = array();
		$aData['ip_address'] = $sIP;
		$aData['port_no']    = $sPort;
		$aData['data']  	 = $sCommand;
		$aData['ssh_port']	 = $sShhPort;
		
		$sResponse = send_command_udp($aData);		
		return $sResponse;
	}

	function switch_arrays($aOrig, $aNew){
		$aReturn = array();
		foreach($aNew as $vNew){
			$aReturn[] = $aOrig[$vNew];
		}
		return $aReturn;
	}

	function update_prog_status($iProgId, $iStatus){
		if($iProgId){
			$sSqlUpdate = "UPDATE rlb_relay_prog SET relay_prog_active='".$iStatus."' WHERE relay_prog_id='".$iProgId."'";
			$rResult = mysql_query($sSqlUpdate) or die('ERR: @sSqlUpdate=> '.mysql_error());
		}
	}
	
	function get_current_mode(){
		//get list of relay modes.
		$iMode = '';
		$sSql = "SELECT * FROM rlb_modes WHERE mode_status='1' ";
		$rResult = mysql_query($sSql) or die('ERR: @sSql=> '.mysql_error());
		$iCnt = mysql_num_rows($rResult);
		if($iCnt){
			$aRow = mysql_fetch_assoc($rResult);
			$iMode = $aRow['mode_id'];
		}
		return $iMode;
	}
	
	/*function to return device name
	* @iDeviceType => 1-Relay, 2-Valve, 3-Powercenter
	* @iDeviceNum => As per availabel device type start from 0 - n
	*/
	function get_device_name($iDeviceType, $iDeviceNum){
		$aDeviceType = array(1, 2, 3);
		$aDeviceTypeName = array( '1' => 'Relay', '2' => 'Valve' , '3' => 'Powercenter');
		$aTbl = array('1' => 'rlb_relays', '2' => 'rlb_valves', '3' => 'rlb_powercenters');
		$aFldWhere = array('1' => 'relay_number', '2' => 'valve_number', '3' => 'powercenter_number');
		$aFldSel = array('1' => 'relay_name', '2' => 'valve_name', '3' => 'powercenter_name');
		$sDeviceNameAE = $aDeviceTypeName[$iDeviceType].' '.$iDeviceNum;
		
		if(is_numeric($iDeviceNum) && in_array($iDeviceType, $aDeviceType)){
			$sSqlEdit = "SELECT * FROM ". $aTbl[$iDeviceType] ." WHERE ". $aFldWhere[$iDeviceType] ." ='".$iDeviceNum."'";
			$rResultEdit = mysql_query($sSqlEdit) or die('ERR: @sSqlEdit=> '.mysql_error());
			$iCnt = mysql_num_rows($rResultEdit);
			if($iCnt){
				$aRowEdit = mysql_fetch_assoc($rResultEdit);
				$sDeviceNameAE = stripslashes($aRowEdit[$aFldSel[$iDeviceType]]);
			}
		}
		return $sDeviceNameAE;
	}
	
	
	function getPermissionOfModule($userID)
	{
		$CI = get_instance();
		$CI->load->model('access_model');
		$aPermissions = $CI->access_model->getPermission($userID);
		$aModules	= array();
		$aReturn	= array();
		
		//var_dump($aPermissions);
		if(!empty($aPermissions))
		{
		  foreach($aPermissions as $sPermission)
		  {
			$aModules['ids'][] = $sPermission->module_id;
			$aModules['access_'.$sPermission->module_id] = $sPermission->access;
		  }
		}  
		
		
		$CI->load->model('user_model');
	    $aAllMActiveModule	=	$CI->user_model->getAllModulesActive();
		
		$aReturn['sPermissionModule']	=	$aModules;
		$aReturn['sActiveModule']		=	$aAllMActiveModule;
		
		return json_encode($aReturn);
	}
	
	function getModuleAccess($sModule)
	{
		$CI = get_instance();
		$CI->load->model('access_model');
	    $aPermissions = $CI->access_model->getPermission($userID);
	}
	
	/**
	* Function to convert from Celcius to Fahrenheit.
	* @param tempratureC : Temperature in Celcius.
	* @param tempratureF : Temperature in Fahrenheit.
	* @return
	**/
	function celciustofahrenheit($tempratureC)
	{
		$tempratureF =	0;
		$tempratureF = ($tempratureC * 1.8) + 32;
		return $tempratureF;
	}
	
	/**
	* Function to convert from Fahrenheit to Celcius.
	* @param tempratureF : Temperature in Fahrenheit.
	* @param tempratureC : Temperature in Celcius.
	* @return
	**/
	function fahrenheittocelcius($tempratureF)
	{
		$tempratureC =	0;
		$tempratureC = ($tempratureF - 32) / 1.8;
		return $tempratureC;
	}
	
	/**
	* Function to Show the Valve Related to Pumps.
	* @param pumpValve,pumpNumber
	* @return HTML of the valve.
	**/
	function showPumpValve($pumpValve,$pumpNumber)
	{
		$strResponse 	= '';
		$sDevice	 	= 'V';
		$valveNumber 	= json_decode($pumpValve);
		
		//echo '<pre>';print_r($pumpValve);echo '</pre>';
		
		if(!empty($valveNumber))
		{
			$CI = get_instance();
			$CI->load->model('home_model');
		
			$strResponse = '<div class="col-sm-4">
							<div class="widget-container widget-stats boxed green-line">
							<div class="widget-title">
								<a href="'.base_url('home/setting/'.$sDevice.'/').'" class="link-refresh" id="link-refresh-1"><span class="glyphicon glyphicon-refresh"></span></a>
								<h3>ON/OFF</h3>
							</div>
							<div class="stats-content clearfix">
								<div class="stats-content-right" style="width:96% !important; margin-left:5px; margin-right:5px; margin-top:10px; float:none;">
								<table class="table table-hover">';
								
			foreach($valveNumber as $valve)
			{
				$i 	= $valve[0];
				$iIP= $valve[1];
								
				$iValvesVal = $valve[2];
				
				if($iValvesVal == '')
					$iValvesVal = '0';
				
				$sValvesNameDb =  $CI->home_model->getDeviceName($i,$sDevice,$iIP);
				if($sValvesNameDb == '')
				  $sValvesNameDb = 'Valve '.$i;
			  
				$strBoard		= 	$CI->home_model->getBoardIPFromID($iIP);
				
				//START : Get Valve Position Details.
				$aPositionName   =  $CI->home_model->getPositionName($i,$sDevice,$iIP);
				
				$strPosition1 = '';
				$strPosition2 = '';
				
				if($aPositionName[0] != '')
				$strPosition1	 =	$CI->home_model->getPositionNameFromID($aPositionName[0]);
				if($aPositionName[1] != '')
				$strPosition2	 =	$CI->home_model->getPositionNameFromID($aPositionName[1]);
				//END : Get Valve Position Details.
				
				$aRelayNumber    =  json_decode($CI->home_model->getValveRelayNumber($i,$sDevice,$iIP));
				$sMainType	     =  $CI->home_model->getDeviceMainType($i,$sDevice,$iIP);
				
				if($iValvesVal == '.' || $iValvesVal == '')
					continue;
				$sSelect1	='';
				$sSelect0	='';
				$sSelect2	='';
				if($iValvesVal == '1') { $sSelect1 = 'selected="selected"';}
				if($iValvesVal == '0') { $sSelect0 = 'selected="selected"';}
				if($iValvesVal == '2') { $sSelect2 = 'selected="selected"';}
				
				if($iValvesVal != '' && $iValvesVal != '.' && !empty($aRelayNumber)) 
				{
					$strResponse .='<tr>
										<td colspan="3" style="border-top:none;">
											<div style="margin-top: 10px;margin-bottom: 10px;"><strong><span style="color:#C9376E;">'.$sValvesNameDb.' ('.$strBoard.')</span></strong></div>
										</td>
									</tr>';
					$strResponse .='<tr style="border-bottom: 1px solid #ccc;">
										<td width="33%" style="border-top:none;">
											<div class="span1 valve-'.$i.'-'.$iIP.'-pump'.$pumpNumber.'" value="1" style="margin-top: 10px; color: #428BCA;font-weight: bold; cursor: pointer; float: left;">'.$strPosition1.'</div>
										</td>
										<td width="34%" style="border-top:none;">
											<div class="span2" style="margin-left:5px; margin-right:5px; float: left;" >
											<select id="switch-me-'.$i.'-'.$iIP.'-pump'.$pumpNumber.'">
											<option value="1" '.$sSelect1.'>Spa</option>
											<option value="0" '.$sSelect0.'></option>
											<option value="2" '.$sSelect2.'>Pool</option>
											</select>
												<div class="valve-'.$i.'-'.$iIP.'-pump'.$pumpNumber.'" value="0" id="off-'.$i.'-'.$iIP.'" style="color: red;font-weight: bold;width: 0; margin-left: 30px; cursor: pointer; margin-top:5px;">
													OFF
												</div>
											</div>
										</td>
										<td width="33%" style="border-top:none;">
											<div class="span1 valve-'.$i.'-'.$iIP.'-pump'.$pumpNumber.'" value="2" style="margin-top: 10px; color: #428BCA;font-weight: bold; cursor: pointer; float: right; text-align:right;">'.$strPosition2.'</div>
										</td>
									</tr>';
					$strResponse .='<script type="text/javascript">
									$(function()
									{
										var bgColor = \'#E8E8E8\';';
									
									if($iValvesVal == '1' || $iValvesVal == '2') 
									{ 
										$strResponse .='bgColor = \'#45A31F\';';
									}
									else 
									{ 
										$strResponse .='bgColor = \'#E8E8E8\';';
									}
										
					$strResponse .='$("#switch-me-'.$i.'-'.$iIP.'-pump'.$pumpNumber.'").switchy();
									$(".valve-'.$i.'-'.$iIP.'-pump'.$pumpNumber.'").on("click", function(event){
										$("#switch-me-'.$i.'-'.$iIP.'-pump'.$pumpNumber.'").val($(this).attr("value")).change();
										});
										
										$("#switch-me-'.$i.'-'.$iIP.'-pump'.$pumpNumber.'").next(".switchy-container").find(".switchy-bar").animate({
											backgroundColor: bgColor
										});
											
										$("#switch-me-'.$i.'-'.$iIP.'-pump'.$pumpNumber.'").on("change", function(event)
										{
												if(sAccess == 2)
												{
													if(iActiveMode != 2)
													{
														var bConfirm	=	confirm("You will need to change to Manual mode to make this change.\nWould you like to activate manual mode?" );
														if(bConfirm)
														{
															$.ajax({
																type: "POST",
																url: "'.site_url("analog/changeMode").'", 
																data: {iMode:\'2\'},
																success: function(data) {
																}
															});
															var bgColor = \'#E8E8E8\';

															if ($(this).val() == \'1\' || $(this).val() == \'2\')
															{
																bgColor = \'#45A31F\';
															} 
															$("#switch-me-'.$i.'-'.$iIP.'-pump'.$pumpNumber.'").next(".switchy-container").find(".switchy-bar").animate({
																backgroundColor: bgColor
															});
														
															$.ajax({
																type: "POST",
																url: "'.site_url("home/updateStatusOnOff").'", 
																data: {sName:'.$i.',sStatus:$(this).val(),sDevice:\''.$sDevice.'\',sIdIP:'.$iIP.'},
																success: function(data) {
																location.reload();
																}
															});
														}
													}
													else
													{
														var bgColor = \'#E8E8E8\';

														if ($(this).val() == \'1\' || $(this).val() == \'2\')
														{
															bgColor = \'#45A31F\';
														} 
														$("#switch-me-'.$i.'-'.$iIP.'-pump'.$pumpNumber.'").next(".switchy-container").find(".switchy-bar").animate({
															backgroundColor: bgColor
														});
													
														$.ajax({
															type: "POST",
															url: "'.site_url('home/updateStatusOnOff').'", 
															data: {sName:'.$i.',sStatus:$(this).val(),sDevice:\''.$sDevice.'\',sIdIP:'.$iIP.'},
															success: function(data) {
															}
														});
													}
												}
											});
										});
								   </script>';
				}
			}
			
			$strResponse .='</table>
						</div>
					</div>
				</div>
			</div>';
			
		}
		else
		{
			$strResponse .= '<span style=" color: red;line-height: 30px;margin-left: 20px;">No Valve is associated with Pump!</span>';
		}
		
		return 	$strResponse;				
		
	}
	
?>