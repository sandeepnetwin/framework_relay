
/*---------------------------------------------------------------
  SQL DB BACKUP 31.07.2016 03:30 
  TABLES: *
  ---------------------------------------------------------------*/

/*---------------------------------------------------------------
  TABLE: `ci_sessions`
  ---------------------------------------------------------------*/
DROP TABLE IF EXISTS `ci_sessions`;
CREATE TABLE `ci_sessions` (
  `session_id` varchar(40) NOT NULL DEFAULT '0',
  `ip_address` varchar(45) NOT NULL DEFAULT '0',
  `user_agent` varchar(120) NOT NULL,
  `last_activity` int(10) unsigned NOT NULL DEFAULT '0',
  `user_data` text NOT NULL,
  PRIMARY KEY (`session_id`),
  KEY `last_activity_idx` (`last_activity`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*---------------------------------------------------------------
  TABLE: `rlb_access_permissions`
  ---------------------------------------------------------------*/
DROP TABLE IF EXISTS `rlb_access_permissions`;
CREATE TABLE `rlb_access_permissions` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `user_id` int(5) NOT NULL,
  `module_id` int(5) NOT NULL,
  `access` enum('0','1','2') NOT NULL DEFAULT '0' COMMENT '0=block,1=View,2=View and change',
  `modified_date` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=latin1;
INSERT INTO `rlb_access_permissions` VALUES   ('1','4','2','1','2015-08-24 08:14:43');
INSERT INTO `rlb_access_permissions` VALUES ('2','4','3','1','2015-08-24 08:14:43');
INSERT INTO `rlb_access_permissions` VALUES ('3','4','4','1','2015-08-24 08:14:44');
INSERT INTO `rlb_access_permissions` VALUES ('4','4','5','0','2015-08-24 08:14:44');
INSERT INTO `rlb_access_permissions` VALUES ('5','4','6','0','2015-08-24 08:14:44');
INSERT INTO `rlb_access_permissions` VALUES ('6','4','7','2','2015-08-24 08:14:44');
INSERT INTO `rlb_access_permissions` VALUES ('7','4','8','1','2015-08-24 08:14:44');
INSERT INTO `rlb_access_permissions` VALUES ('8','4','9','1','2015-08-24 08:14:44');
INSERT INTO `rlb_access_permissions` VALUES ('9','4','10','1','2015-08-24 08:14:44');
INSERT INTO `rlb_access_permissions` VALUES ('10','4','11','1','2015-08-24 08:14:44');
INSERT INTO `rlb_access_permissions` VALUES ('11','4','12','1','2015-08-24 08:14:44');
INSERT INTO `rlb_access_permissions` VALUES ('12','4','13','0','2015-08-24 08:14:44');
INSERT INTO `rlb_access_permissions` VALUES ('13','5','2','1','2015-12-28 07:28:21');
INSERT INTO `rlb_access_permissions` VALUES ('14','5','3','1','2015-12-28 07:28:21');
INSERT INTO `rlb_access_permissions` VALUES ('15','5','4','0','2015-12-28 07:28:21');
INSERT INTO `rlb_access_permissions` VALUES ('16','5','5','1','2015-12-28 07:28:21');
INSERT INTO `rlb_access_permissions` VALUES ('17','5','6','0','2015-12-28 07:28:21');
INSERT INTO `rlb_access_permissions` VALUES ('18','5','7','0','2015-12-28 07:28:21');
INSERT INTO `rlb_access_permissions` VALUES ('19','5','8','1','2015-12-28 07:28:22');
INSERT INTO `rlb_access_permissions` VALUES ('20','5','9','1','2015-12-28 07:28:22');
INSERT INTO `rlb_access_permissions` VALUES ('21','5','10','1','2015-12-28 07:28:22');
INSERT INTO `rlb_access_permissions` VALUES ('22','5','11','0','2015-12-28 07:28:22');
INSERT INTO `rlb_access_permissions` VALUES ('23','5','12','0','2015-12-28 07:28:22');
INSERT INTO `rlb_access_permissions` VALUES ('24','5','13','0','2015-12-28 07:28:22');
INSERT INTO `rlb_access_permissions` VALUES ('25','5','15','0','2015-12-28 07:28:22');
INSERT INTO `rlb_access_permissions` VALUES ('26','5','16','0','2015-12-28 07:28:22');
INSERT INTO `rlb_access_permissions` VALUES ('27','5','17','0','2015-12-28 07:28:22');
INSERT INTO `rlb_access_permissions` VALUES ('28','5','18','0','2015-12-28 07:28:22');
INSERT INTO `rlb_access_permissions` VALUES ('29','5','19','0','2015-12-28 07:28:22');
INSERT INTO `rlb_access_permissions` VALUES ('30','5','20','0','2015-12-28 07:28:23');
INSERT INTO `rlb_access_permissions` VALUES ('31','5','21','1','2015-12-28 07:28:23');

/*---------------------------------------------------------------
  TABLE: `rlb_admin_users`
  ---------------------------------------------------------------*/
DROP TABLE IF EXISTS `rlb_admin_users`;
CREATE TABLE `rlb_admin_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(150) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `block` tinyint(4) NOT NULL DEFAULT '0',
  `user_type` enum('SA','A') DEFAULT 'SA' COMMENT 'SA: Super Admin,A: Admin',
  `name` varchar(250) NOT NULL,
  `created_date` datetime NOT NULL,
  `parent_id` int(5) NOT NULL,
  `last_login` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;
INSERT INTO `rlb_admin_users` VALUES   ('1','admin','dhiraj.netwin@yahoo.com','YWRtaW4xMjM=','0','SA','Admin','0000-00-00 00:00:00','0','2016-07-29 00:03:10');
INSERT INTO `rlb_admin_users` VALUES ('5','test','test@test.com','dGVzdDEyMw==','0','A','Test','2015-10-05 08:04:18','1','2016-01-22 08:22:34');

/*---------------------------------------------------------------
  TABLE: `rlb_analog_device`
  ---------------------------------------------------------------*/
DROP TABLE IF EXISTS `rlb_analog_device`;
CREATE TABLE `rlb_analog_device` (
  `analog_id` int(10) NOT NULL AUTO_INCREMENT,
  `analog_input` int(10) NOT NULL,
  `analog_name` varchar(150) NOT NULL,
  `analog_device` varchar(100) NOT NULL,
  `analog_device_type` varchar(100) NOT NULL,
  `device_direction` int(5) NOT NULL,
  `analog_device_modified_date` datetime NOT NULL,
  `ip_id` int(5) NOT NULL,
  PRIMARY KEY (`analog_id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;
INSERT INTO `rlb_analog_device` VALUES   ('1','0','AP0','10','R','0','2016-01-22 11:19:21','1');
INSERT INTO `rlb_analog_device` VALUES ('2','1','AP1','0','V','1','2016-01-22 11:19:21','1');
INSERT INTO `rlb_analog_device` VALUES ('3','2','AP2','0','P','0','2016-01-22 11:19:21','1');
INSERT INTO `rlb_analog_device` VALUES ('4','3','AP3','0','L','0','2016-01-22 11:19:22','1');
INSERT INTO `rlb_analog_device` VALUES ('5','0','AP0','1','R','0','2016-01-22 11:19:22','2');
INSERT INTO `rlb_analog_device` VALUES ('6','1','AP1','1','P','0','2016-01-22 11:19:22','2');
INSERT INTO `rlb_analog_device` VALUES ('7','2','AP2','2','V','2','2016-01-22 11:19:22','2');
INSERT INTO `rlb_analog_device` VALUES ('8','3','AP3','1','L','0','2016-01-22 11:19:22','2');

/*---------------------------------------------------------------
  TABLE: `rlb_board_ip`
  ---------------------------------------------------------------*/
DROP TABLE IF EXISTS `rlb_board_ip`;
CREATE TABLE `rlb_board_ip` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `ip` varchar(150) NOT NULL,
  `name` text NOT NULL,
  `status` enum('0','1') NOT NULL DEFAULT '0',
  `ssh_port` varchar(10) DEFAULT NULL,
  `local_port` int(5) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
INSERT INTO `rlb_board_ip` VALUES   ('1','192.168.0.103','Device1','1','','2222');
INSERT INTO `rlb_board_ip` VALUES ('2','192.168.0.115','Device2','1','','222');

/*---------------------------------------------------------------
  TABLE: `rlb_custom_program`
  ---------------------------------------------------------------*/
DROP TABLE IF EXISTS `rlb_custom_program`;
CREATE TABLE `rlb_custom_program` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `g_id` int(10) NOT NULL,
  `program_details` text NOT NULL,
  `is_on` enum('0','1') NOT NULL,
  `isremoved` enum('0','1') NOT NULL DEFAULT '0',
  `display_access` enum('0','1') NOT NULL DEFAULT '0',
  `already_running` enum('0','1') NOT NULL DEFAULT '0',
  `unique_id` varchar(255) NOT NULL,
  `program_start` varchar(250) DEFAULT NULL,
  `program_end` varchar(250) DEFAULT NULL,
  `afterProgram` enum('0','1') NOT NULL DEFAULT '0',
  `previousState` text NOT NULL,
  `is_schedule` enum('0','1') NOT NULL DEFAULT '0',
  `program_schedule_start` varchar(100) NOT NULL,
  `program_schedule_end` varchar(100) NOT NULL,
  `schedule_run` enum('0','1') NOT NULL DEFAULT '0',
  `program_type` int(2) NOT NULL COMMENT '0 - Daily,1 - Weekly',
  `program_days` varchar(50) NOT NULL COMMENT '0 - All, 1- Mon ... 7- Sat',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=48 DEFAULT CHARSET=latin1;
INSERT INTO `rlb_custom_program` VALUES   ('1','15','{\"g_id\":\"15\",\"g_custom_mode_name\":\"Indoor_Spa_On\\/Off_\",\"g_rlb_pump_list\":\"1_2\",\"g_pump_sq\":\"7\",\"g_pump_time\":\"55\",\"g_rlb_valve_list\":\"1_2_4,1_1_5,1_2_6,2_2_0,2_2_3,2_1_4,2_2_5\",\"g_valve_sq\":\"3,6,6,1,2,4,5\",\"g_valve_time\":\"1,1,1,1,1,1,1\",\"g_custom_max_time\":\"400\",\"g_rlb_relay_list\":\"1_15\",\"g_relay_sq\":\"7\",\"g_relay_time\":\"55\",\"g_rlb_powercenter_list\":\"1_0\",\"g_powercenter_sq\":\"7\",\"g_powercenter_time\":\"55\"}','0','0','1','0','','2016-07-29 09:37:38','2016-07-29 16:17:38','0','a:7:{i:0;s:5:\"1_0_4\";i:1;s:5:\"1_0_5\";i:2;s:5:\"1_0_6\";i:3;s:5:\"2_0_0\";i:4;s:5:\"2_0_3\";i:5;s:5:\"2_0_4\";i:6;s:5:\"2_0_5\";}','0','0000-00-00 00:00:00','0000-00-00 00:00:00','0','0','');
INSERT INTO `rlb_custom_program` VALUES ('2','15','{\"g_id\":\"15\",\"g_custom_mode_name\":\"Outdoor_Spa_2\",\"g_rlb_pump_list\":\"1_2\",\"g_pump_sq\":\"10\",\"g_pump_time\":\"90\",\"g_rlb_valve_list\":\"1_2_4,1_2_5,1_1_6,2_2_0,2_1_2,2_1_3,2_2_4,2_1_5\",\"g_valve_sq\":\"1,2,3,4,5,6,7,8\",\"g_valve_time\":\"1,1,1,1,1,1,1,1\",\"g_custom_max_time\":\"500\",\"g_rlb_relay_list\":\"1_6\",\"g_relay_sq\":\"10\",\"g_relay_time\":\"90\",\"g_rlb_powercenter_list\":\"1_0\",\"g_powercenter_sq\":\"10\",\"g_powercenter_time\":\"90\"}','0','0','0','0','','2016-06-22 14:09:35','2016-06-22 20:09:35','0','a:8:{i:0;s:5:\"1_0_4\";i:1;s:5:\"1_0_5\";i:2;s:5:\"1_0_6\";i:3;s:5:\"2_0_0\";i:4;s:5:\"2_0_2\";i:5;s:5:\"2_0_3\";i:6;s:5:\"2_0_4\";i:7;s:5:\"2_0_5\";}','0','0000-00-00 00:00:00','0000-00-00 00:00:00','0','0','');
INSERT INTO `rlb_custom_program` VALUES ('3','15','{\"g_id\":\"15\",\"g_custom_mode_name\":\"Indoor_Spa_Fill_10_Minute\",\"g_rlb_pump_list\":\"1_1\",\"g_pump_sq\":\"4\",\"g_pump_time\":\"10\",\"g_rlb_valve_list\":\"1_1_0,1_1_4,2_2_0,2_1_4,2_2_5\",\"g_valve_sq\":\"1,1,2,3,3\",\"g_valve_time\":\"1,1,1,1,1\",\"g_custom_max_time\":\"20\",\"g_rlb_relay_list\":\"null\",\"g_relay_sq\":\"\",\"g_relay_time\":\"\",\"g_rlb_powercenter_list\":\"null\",\"g_powercenter_sq\":\"\",\"g_powercenter_time\":\"\"}','0','0','1','0','','2016-07-29 11:15:07','2016-07-29 11:35:07','0','a:5:{i:0;s:5:\"1_0_5\";i:1;s:5:\"1_0_6\";i:2;s:5:\"2_1_1\";i:3;s:5:\"2_2_2\";i:4;s:3:\"_0_\";}','0','0000-00-00 00:00:00','0000-00-00 00:00:00','0','0','');
INSERT INTO `rlb_custom_program` VALUES ('4','10','{\"g_id\":\"10\",\"g_custom_mode_name\":\"Custom_program_From_Local\",\"g_rlb_pump_list\":\"1_1,1_2\",\"g_pump_sq\":\"1,3\",\"g_pump_time\":\"10,1\",\"g_rlb_valve_list\":\"1_2_0,1_1_4\",\"g_valve_sq\":\"2,1\",\"g_valve_time\":\"20,5\",\"g_custom_max_time\":\"40\",\"g_rlb_relay_list\":\"null\",\"g_relay_sq\":\"\",\"g_relay_time\":\"\",\"g_rlb_powercenter_list\":\"null\",\"g_powercenter_sq\":\"\",\"g_powercenter_time\":\"\"}','0','0','1','0','','2016-07-21 06:13:48','2016-07-21 06:53:48','0','a:2:{i:0;s:5:\"1_0_4\";i:1;s:5:\"1_2_5\";}','0','0000-00-00 00:00:00','0000-00-00 00:00:00','0','0','');
INSERT INTO `rlb_custom_program` VALUES ('5','10','{\"g_id\":\"10\",\"g_custom_mode_name\":\"custom_program_local\",\"g_rlb_pump_list\":\"1_1\",\"g_pump_sq\":\"1\",\"g_pump_time\":\"10\",\"g_rlb_valve_list\":\"1_1_0,1_2_0\",\"g_valve_sq\":\"1,4\",\"g_valve_time\":\"20,1\",\"g_custom_max_time\":\"41\",\"g_rlb_relay_list\":\"1_7\",\"g_relay_sq\":\"2\",\"g_relay_time\":\"10\",\"g_rlb_powercenter_list\":\"1_1\",\"g_powercenter_sq\":\"3\",\"g_powercenter_time\":\"10\"}','0','0','1','0','','2016-07-21 05:30:00','2016-07-21 06:11:00','0','a:2:{i:0;s:5:\"1_0_0\";i:1;s:5:\"1_0_0\";}','0','0000-00-00 00:00:00','0000-00-00 00:00:00','0','0','');
INSERT INTO `rlb_custom_program` VALUES ('6','15','{\"g_id\":\"15\",\"g_custom_mode_name\":\"Waterfalls\",\"g_rlb_pump_list\":\"1_2\",\"g_pump_sq\":\"3\",\"g_pump_time\":\"60\",\"g_rlb_valve_list\":\"1_2_5,1_1_6,2_1_1,2_2_2\",\"g_valve_sq\":\"2,2,1,1\",\"g_valve_time\":\"1,1,1,1\",\"g_custom_max_time\":\"70\",\"g_rlb_relay_list\":\"null\",\"g_relay_sq\":\"\",\"g_relay_time\":\"\",\"g_rlb_powercenter_list\":\"null\",\"g_powercenter_sq\":\"\",\"g_powercenter_time\":\"\"}','0','0','1','0','','2016-07-30 20:31:24','2016-07-30 21:41:24','0','a:4:{i:0;s:5:\"1_0_5\";i:1;s:5:\"1_0_6\";i:2;s:5:\"2_1_1\";i:3;s:5:\"2_2_2\";}','0','0000-00-00 00:00:00','0000-00-00 00:00:00','0','0','');
INSERT INTO `rlb_custom_program` VALUES ('43','10','{\"g_id\":\"10\",\"g_custom_mode_name\":\"30_Jun_Local\",\"g_custom_max_time\":\"20\",\"g_rlb_pump_list\":\"1_1\",\"g_pump_sq\":\"1\",\"g_pump_time\":\"1\",\"g_rlb_valve_list\":\"2_2_0\",\"g_valve_sq\":\"2\",\"g_valve_time\":\"1\",\"g_rlb_relay_list\":\"1_7,2_15\",\"g_relay_sq\":\"3,4\",\"g_relay_time\":\"1,1\",\"g_rlb_powercenter_list\":\"1_1\",\"g_powercenter_sq\":\"5\",\"g_powercenter_time\":\"1\"}','0','0','0','0','',NULL,NULL,'0','','0','0000-00-00 00:00:00','0000-00-00 00:00:00','0','0','');
INSERT INTO `rlb_custom_program` VALUES ('44','16','{\"g_id\":\"16\",\"g_custom_mode_name\":\"Testing__Custom_program_\",\"g_custom_max_time\":\"200\",\"g_rlb_pump_list\":\"1_2\",\"g_pump_sq\":\"1\",\"g_pump_time\":\"1\",\"g_rlb_valve_list\":\"1_1_0\",\"g_valve_sq\":\"2\",\"g_valve_time\":\"1\",\"g_rlb_relay_list\":\"1_6,2_12\",\"g_relay_sq\":\"3,4\",\"g_relay_time\":\"1,1\",\"g_rlb_powercenter_list\":\"null\",\"g_powercenter_sq\":\"\",\"g_powercenter_time\":\"\"}','0','0','0','0','',NULL,NULL,'0','','0','0000-00-00 00:00:00','0000-00-00 00:00:00','0','0','');
INSERT INTO `rlb_custom_program` VALUES ('45','15','{\"g_id\":\"15\",\"g_custom_mode_name\":\"Spa_2_Clean_1_hr\",\"g_rlb_pump_list\":\"1_1\",\"g_pump_sq\":\"6\",\"g_pump_time\":\"60\",\"g_rlb_valve_list\":\"1_2_4,1_2_5,1_1_6,2_2_0,2_1_2,2_1_3,2_2_4,2_1_5\",\"g_valve_sq\":\"4,1,2,3,2,3,5,4\",\"g_valve_time\":\"1,1,1,1,1,1,1,1\",\"g_custom_max_time\":\"480\",\"g_rlb_relay_list\":\"null\",\"g_relay_sq\":\"\",\"g_relay_time\":\"\",\"g_rlb_powercenter_list\":\"null\",\"g_powercenter_sq\":\"\",\"g_powercenter_time\":\"\"}','0','0','1','0','','2016-07-28 09:59:40','2016-07-28 17:59:40','0','a:8:{i:0;s:5:\"1_0_4\";i:1;s:5:\"1_0_5\";i:2;s:5:\"1_0_6\";i:3;s:5:\"2_2_0\";i:4;s:5:\"2_0_2\";i:5;s:5:\"2_1_3\";i:6;s:5:\"2_0_4\";i:7;s:5:\"2_0_5\";}','0','0000-00-00 00:00:00','0000-00-00 00:00:00','0','0','');
INSERT INTO `rlb_custom_program` VALUES ('46','15','{\"g_id\":\"15\",\"g_custom_mode_name\":\"Spa_1_and_Waterfall_(no_jets)\",\"g_custom_max_time\":\"120\",\"g_rlb_pump_list\":\"1_2\",\"g_pump_sq\":\"8\",\"g_pump_time\":\"1\",\"g_rlb_valve_list\":\"1_2_4,1_2_5,1_1_6,2_2_0,2_1_1,2_2_2,2_2_3,2_1_4,2_2_5\",\"g_valve_sq\":\"2,6,1,1,3,5,2,3,4\",\"g_valve_time\":\"1,1,1,1,1,1,1,1,1\",\"g_rlb_relay_list\":\"1_15\",\"g_relay_sq\":\"7\",\"g_relay_time\":\"1\",\"g_rlb_powercenter_list\":\"1_0\",\"g_powercenter_sq\":\"8\",\"g_powercenter_time\":\"1\"}','0','0','1','0','','2016-07-29 11:41:34','2016-07-29 13:41:34','0','a:9:{i:0;s:5:\"1_0_4\";i:1;s:5:\"1_0_5\";i:2;s:5:\"1_1_6\";i:3;s:5:\"2_0_0\";i:4;s:5:\"2_1_1\";i:5;s:5:\"2_2_2\";i:6;s:5:\"2_0_3\";i:7;s:5:\"2_0_4\";i:8;s:5:\"2_0_5\";}','0','0000-00-00 00:00:00','0000-00-00 00:00:00','0','0','');
INSERT INTO `rlb_custom_program` VALUES ('47','10','{\"g_id\":\"15\",\"g_custom_mode_name\":\"Spa_2_Clean_1_hr\",\"g_rlb_pump_list\":\"1_1\",\"g_pump_sq\":\"6\",\"g_pump_time\":\"1\",\"g_rlb_valve_list\":\"1_2_4,1_2_5,1_1_6,2_2_0,2_1_2,2_1_3,2_2_4,2_1_5\",\"g_valve_sq\":\"4,1,2,3,2,3,5,4\",\"g_valve_time\":\"1,1,1,1,1,1,1,1\",\"g_custom_max_time\":\"480\",\"g_rlb_relay_list\":\"null\",\"g_relay_sq\":\"\",\"g_relay_time\":\"\",\"g_rlb_powercenter_list\":\"null\",\"g_powercenter_sq\":\"\",\"g_powercenter_time\":\"\"}','0','0','1','0','','2016-07-21 06:13:36','2016-07-21 14:13:36','0','a:8:{i:0;s:5:\"1_0_4\";i:1;s:5:\"1_0_5\";i:2;s:5:\"1_0_6\";i:3;s:5:\"2_0_0\";i:4;s:5:\"2_0_2\";i:5;s:5:\"2_0_3\";i:6;s:5:\"2_0_4\";i:7;s:5:\"2_0_5\";}','0','','','0','0','');

/*---------------------------------------------------------------
  TABLE: `rlb_custom_program_after`
  ---------------------------------------------------------------*/
DROP TABLE IF EXISTS `rlb_custom_program_after`;
CREATE TABLE `rlb_custom_program_after` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `program_id` int(10) NOT NULL,
  `current_on_device` varchar(150) NOT NULL,
  `device_type` varchar(10) NOT NULL,
  `device_number` int(5) NOT NULL,
  `current_on_time` datetime NOT NULL,
  `current_off_time` datetime NOT NULL,
  `current_device_complete` enum('0','1') NOT NULL DEFAULT '0',
  `current_sequence` varchar(10) NOT NULL,
  `ip_id` int(5) NOT NULL,
  `unique_id` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*---------------------------------------------------------------
  TABLE: `rlb_custom_program_current`
  ---------------------------------------------------------------*/
DROP TABLE IF EXISTS `rlb_custom_program_current`;
CREATE TABLE `rlb_custom_program_current` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `program_id` int(10) NOT NULL,
  `current_on_device` varchar(150) NOT NULL,
  `device_type` varchar(10) NOT NULL,
  `device_number` int(5) NOT NULL,
  `current_on_time` datetime NOT NULL,
  `current_off_time` datetime NOT NULL,
  `current_device_complete` enum('0','1') NOT NULL DEFAULT '0',
  `current_sequence` varchar(10) NOT NULL,
  `ip_id` int(5) NOT NULL,
  `unique_id` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*---------------------------------------------------------------
  TABLE: `rlb_custom_program_log`
  ---------------------------------------------------------------*/
DROP TABLE IF EXISTS `rlb_custom_program_log`;
CREATE TABLE `rlb_custom_program_log` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `program_id` int(10) NOT NULL,
  `device` varchar(150) NOT NULL,
  `device_type` varchar(10) NOT NULL,
  `device_number` int(5) NOT NULL,
  `device_start` datetime NOT NULL,
  `device_stop` datetime NOT NULL,
  `device_complete_run` enum('0','1') NOT NULL DEFAULT '0',
  `current_sequence` varchar(5) NOT NULL,
  `ip_id` int(5) NOT NULL,
  `unique_id` varchar(255) NOT NULL,
  `afterDevice` enum('0','1') NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2117 DEFAULT CHARSET=latin1;
INSERT INTO `rlb_custom_program_log` VALUES   ('1','1','Valve 0','V','0','2016-06-22 02:23:01','2016-06-22 02:24:01','1','1','1','89750901466587379','0');
INSERT INTO `rlb_custom_program_log` VALUES ('2','1','Valve 2','V','2','2016-06-22 02:24:04','2016-06-22 02:25:04','1','2','1','89750901466587379','0');
INSERT INTO `rlb_custom_program_log` VALUES ('3','1','Valve 6','V','6','2016-06-22 02:26:02','2016-06-22 02:27:02','1','3','1','89750901466587379','0');
INSERT INTO `rlb_custom_program_log` VALUES ('4','1','Valve 0','V','0','2016-06-22 02:27:02','2016-06-22 02:28:02','1','4','2','89750901466587379','0');
INSERT INTO `rlb_custom_program_log` VALUES ('5','1','Relay 6','R','6','2016-06-22 02:29:02','2016-06-22 02:30:02','1','5','1','89750901466587379','0');
INSERT INTO `rlb_custom_program_log` VALUES ('6','1','Valve 0','V','0','2016-06-22 02:30:04','2016-06-22 02:31:04','1','1','1','89750901466587379','1');
INSERT INTO `rlb_custom_program_log` VALUES ('7','1','Valve 2','V','2','2016-06-22 02:32:02','2016-06-22 02:33:02','1','2','1','89750901466587379','1');
INSERT INTO `rlb_custom_program_log` VALUES ('8','1','Valve 6','V','6','2016-06-22 02:33:02','2016-06-22 02:34:02','1','3','1','89750901466587379','1');
INSERT INTO `rlb_custom_program_log` VALUES ('9','1','Valve 0','V','0','2016-06-22 02:34:02','2016-06-22 02:35:02','1','4','2','89750901466587379','1');
INSERT INTO `rlb_custom_program_log` VALUES ('10','1','Valve 0','V','0','2016-06-22 02:52:02','2016-06-22 02:53:02','1','1','1','59171031466589121','0');
INSERT INTO `rlb_custom_program_log` VALUES ('11','1','Valve 2','V','2','2016-06-22 02:53:03','2016-06-22 02:54:03','1','2','1','59171031466589121','0');
INSERT INTO `rlb_custom_program_log` VALUES ('12','1','Valve 0','V','0','2016-06-22 03:10:07','2016-06-22 03:11:07','1','1','1','58799671466590207','0');
INSERT INTO `rlb_custom_program_log` VALUES ('13','1','Valve 2','V','2','2016-06-22 03:12:02','2016-06-22 03:13:02','1','2','1','58799671466590207','0');
INSERT INTO `rlb_custom_program_log` VALUES ('14','1','Valve 6','V','6','2016-06-22 03:13:02','2016-06-22 03:14:02','1','3','1','58799671466590207','0');
INSERT INTO `rlb_custom_program_log` VALUES ('15','1','Valve 0','V','0','2016-06-22 03:14:02','2016-06-22 03:15:02','1','4','2','58799671466590207','0');
INSERT INTO `rlb_custom_program_log` VALUES ('16','1','Relay 6','R','6','2016-06-22 03:15:02','2016-06-22 03:16:02','1','5','1','58799671466590207','0');
INSERT INTO `rlb_custom_program_log` VALUES ('17','1','Valve 0','V','0','2016-06-22 03:16:05','2016-06-22 03:17:05','1','1','1','58799671466590207','1');
INSERT INTO `rlb_custom_program_log` VALUES ('18','1','Valve 0','V','0','2016-06-22 03:18:00','2016-06-22 03:19:00','1','1','1','46765201466590676','0');
INSERT INTO `rlb_custom_program_log` VALUES ('19','1','Valve 2','V','2','2016-06-22 03:19:06','2016-06-22 03:20:06','1','2','1','46765201466590676','0');
INSERT INTO `rlb_custom_program_log` VALUES ('20','1','Valve 0','V','0','2016-06-22 03:20:02','2016-06-22 03:21:02','1','1','1','46765201466590676','1');
INSERT INTO `rlb_custom_program_log` VALUES ('21','1','Valve 2','V','2','2016-06-22 03:21:02','2016-06-22 03:22:02','1','2','1','46765201466590676','1');
INSERT INTO `rlb_custom_program_log` VALUES ('22','1','Valve 6','V','6','2016-06-22 03:22:02','2016-06-22 03:23:02','1','3','1','46765201466590676','1');
INSERT INTO `rlb_custom_program_log` VALUES ('23','1','Valve 0','V','0','2016-06-22 03:23:02','2016-06-22 03:24:02','1','4','2','46765201466590676','1');
INSERT INTO `rlb_custom_program_log` VALUES ('24','1','Valve 0','V','0','2016-06-22 03:30:48','2016-06-22 03:31:48','1','1','1','63120041466591447','0');
INSERT INTO `rlb_custom_program_log` VALUES ('25','1','Valve 2','V','2','2016-06-22 03:32:05','2016-06-22 03:33:05','1','2','1','63120041466591447','0');
INSERT INTO `rlb_custom_program_log` VALUES ('26','1','Valve 6','V','6','2016-06-22 03:34:05','2016-06-22 03:35:05','1','3','1','63120041466591447','0');
INSERT INTO `rlb_custom_program_log` VALUES ('27','1','Valve 0','V','0','2016-06-22 03:36:05','2016-06-22 03:37:05','1','4','2','63120041466591447','0');
INSERT INTO `rlb_custom_program_log` VALUES ('28','1','Relay 6','R','6','2016-06-22 03:38:04','2016-06-22 03:39:04','1','5','1','63120041466591447','0');
INSERT INTO `rlb_custom_program_log` VALUES ('29','1','Valve 0','V','0','2016-06-22 03:40:06','2016-06-22 03:41:06','1','1','1','63120041466591447','1');
INSERT INTO `rlb_custom_program_log` VALUES ('30','1','Valve 2','V','2','2016-06-22 03:42:02','2016-06-22 03:43:02','1','2','1','63120041466591447','1');
INSERT INTO `rlb_custom_program_log` VALUES ('31','1','Valve 6','V','6','2016-06-22 03:43:02','2016-06-22 03:44:02','1','3','1','63120041466591447','1');
INSERT INTO `rlb_custom_program_log` VALUES ('32','1','Valve 0','V','0','2016-06-22 03:44:02','2016-06-22 03:45:02','1','4','2','63120041466591447','1');
INSERT INTO `rlb_custom_program_log` VALUES ('33','1','Valve 3','V','3','2016-06-22 10:30:00','2016-06-22 10:31:00','1','1','2','14338191466616600','0');
INSERT INTO `rlb_custom_program_log` VALUES ('34','1','Valve 0','V','0','2016-06-22 10:31:02','2016-06-22 10:32:02','1','2','2','14338191466616600','0');
INSERT INTO `rlb_custom_program_log` VALUES ('35','1','Valve 4','V','4','2016-06-22 10:32:02','2016-06-22 10:33:02','1','3','1','14338191466616600','0');
INSERT INTO `rlb_custom_program_log` VALUES ('36','1','Valve 4','V','4','2016-06-22 10:33:02','2016-06-22 10:34:02','1','4','2','14338191466616600','0');
INSERT INTO `rlb_custom_program_log` VALUES ('37','1','Valve 5','V','5','2016-06-22 10:33:02','2016-06-22 10:34:02','1','4','2','14338191466616600','0');
INSERT INTO `rlb_custom_program_log` VALUES ('38','1','Valve 5','V','5','2016-06-22 10:33:02','2016-06-22 10:34:02','1','4','2','14338191466616600','0');
INSERT INTO `rlb_custom_program_log` VALUES ('39','1','Pump 1','PS','1','2016-06-22 10:34:02','2016-06-22 10:35:02','1','5','1','14338191466616600','0');
INSERT INTO `rlb_custom_program_log` VALUES ('40','1','Relay 15','R','15','2016-06-22 10:35:02','2016-06-22 10:36:02','1','6','1','14338191466616600','0');
INSERT INTO `rlb_custom_program_log` VALUES ('41','1','Valve 3','V','3','2016-06-22 10:36:02','2016-06-22 10:37:02','1','1','2','14338191466616600','1');
INSERT INTO `rlb_custom_program_log` VALUES ('42','1','Valve 0','V','0','2016-06-22 10:38:02','2016-06-22 10:39:02','1','2','2','14338191466616600','1');
INSERT INTO `rlb_custom_program_log` VALUES ('43','1','Valve 4','V','4','2016-06-22 10:39:03','2016-06-22 10:40:03','1','3','1','14338191466616600','1');
INSERT INTO `rlb_custom_program_log` VALUES ('44','1','Valve 5','V','5','2016-06-22 10:41:02','2016-06-22 10:42:02','1','4','2','14338191466616600','1');
INSERT INTO `rlb_custom_program_log` VALUES ('45','1','Valve 0','V','0','2016-06-22 10:51:39','2016-06-22 10:52:39','1','1','2','17543371466617899','0');
INSERT INTO `rlb_custom_program_log` VALUES ('46','1','Valve 3','V','3','2016-06-22 10:53:02','2016-06-22 10:54:02','1','2','2','17543371466617899','0');
INSERT INTO `rlb_custom_program_log` VALUES ('47','1','Valve 4','V','4','2016-06-22 10:54:02','2016-06-22 10:55:02','1','3','1','17543371466617899','0');
INSERT INTO `rlb_custom_program_log` VALUES ('48','1','Valve 4','V','4','2016-06-22 10:55:02','2016-06-22 10:56:02','1','4','2','17543371466617899','0');
INSERT INTO `rlb_custom_program_log` VALUES ('49','1','Pump 1','PS','1','2016-06-22 10:56:02','2016-06-22 10:57:02','1','5','1','17543371466617899','0');
INSERT INTO `rlb_custom_program_log` VALUES ('50','1','Valve 5','V','5','2016-06-22 10:56:02','2016-06-22 10:57:02','1','5','2','17543371466617899','0');
INSERT INTO `rlb_custom_program_log` VALUES ('51','1','Relay 15','R','15','2016-06-22 10:57:08','2016-06-22 10:58:08','1','6','1','17543371466617899','0');
INSERT INTO `rlb_custom_program_log` VALUES ('52','1','Valve 0','V','0','2016-06-22 10:59:06','2016-06-22 11:00:06','1','1','2','17543371466617899','1');
INSERT INTO `rlb_custom_program_log` VALUES ('53','1','Valve 3','V','3','2016-06-22 11:01:03','2016-06-22 11:02:03','1','2','2','17543371466617899','1');
INSERT INTO `rlb_custom_program_log` VALUES ('54','1','Valve 4','V','4','2016-06-22 11:03:02','2016-06-22 11:04:02','1','3','1','17543371466617899','1');
INSERT INTO `rlb_custom_program_log` VALUES ('55','1','Valve 4','V','4','2016-06-22 11:04:02','2016-06-22 11:05:02','1','4','2','17543371466617899','1');
INSERT INTO `rlb_custom_program_log` VALUES ('56','1','Valve 5','V','5','2016-06-22 11:05:02','2016-06-22 11:06:02','1','5','2','17543371466617899','1');
INSERT INTO `rlb_custom_program_log` VALUES ('57','1','Valve 0','V','0','2016-06-22 11:10:37','2016-06-22 11:11:37','1','1','2','10054521466619036','0');
INSERT INTO `rlb_custom_program_log` VALUES ('58','1','Valve 3','V','3','2016-06-22 11:12:03','2016-06-22 11:13:03','1','2','2','10054521466619036','0');
INSERT INTO `rlb_custom_program_log` VALUES ('59','1','Valve 4','V','4','2016-06-22 11:13:05','2016-06-22 11:14:05','1','3','1','10054521466619036','0');
INSERT INTO `rlb_custom_program_log` VALUES ('60','1','Valve 4','V','4','2016-06-22 11:15:07','2016-06-22 11:16:07','1','4','2','10054521466619036','0');
INSERT INTO `rlb_custom_program_log` VALUES ('61','1','Valve 5','V','5','2016-06-22 11:17:02','2016-06-22 11:18:02','1','5','2','10054521466619036','0');
INSERT INTO `rlb_custom_program_log` VALUES ('62','1','Pump 1','PS','1','2016-06-22 11:18:02','2016-06-22 12:18:02','1','6','1','10054521466619036','0');
INSERT INTO `rlb_custom_program_log` VALUES ('63','1','Relay 15','R','15','2016-06-22 11:18:02','2016-06-22 12:18:02','1','6','1','10054521466619036','0');
INSERT INTO `rlb_custom_program_log` VALUES ('64','1','Valve 0','V','0','2016-06-22 11:20:02','2016-06-22 11:21:02','1','1','2','10054521466619036','1');
INSERT INTO `rlb_custom_program_log` VALUES ('65','1','Valve 3','V','3','2016-06-22 11:21:02','2016-06-22 11:22:02','1','2','2','10054521466619036','1');
INSERT INTO `rlb_custom_program_log` VALUES ('66','1','Valve 4','V','4','2016-06-22 11:22:02','2016-06-22 11:23:02','1','3','1','10054521466619036','1');
INSERT INTO `rlb_custom_program_log` VALUES ('67','1','Valve 4','V','4','2016-06-22 11:23:02','2016-06-22 11:24:02','1','4','2','10054521466619036','1');
INSERT INTO `rlb_custom_program_log` VALUES ('68','1','Valve 5','V','5','2016-06-22 11:24:02','2016-06-22 11:25:02','1','5','2','10054521466619036','1');
INSERT INTO `rlb_custom_program_log` VALUES ('69','2','Valve 4','V','4','2016-06-22 11:27:41','2016-06-22 11:28:41','1','1','1','28135331466620061','0');
INSERT INTO `rlb_custom_program_log` VALUES ('70','2','Valve 5','V','5','2016-06-22 11:29:01','2016-06-22 11:30:01','1','2','1','28135331466620061','0');
INSERT INTO `rlb_custom_program_log` VALUES ('71','2','Valve 6','V','6','2016-06-22 11:30:01','2016-06-22 11:31:01','1','3','1','28135331466620061','0');
INSERT INTO `rlb_custom_program_log` VALUES ('72','2','Valve 0','V','0','2016-06-22 11:31:01','2016-06-22 11:32:01','1','4','2','28135331466620061','0');
INSERT INTO `rlb_custom_program_log` VALUES ('73','2','Valve 3','V','3','2016-06-22 11:32:02','2016-06-22 11:33:02','1','5','2','28135331466620061','0');
INSERT INTO `rlb_custom_program_log` VALUES ('74','2','Valve 4','V','4','2016-06-22 11:33:02','2016-06-22 11:34:02','1','6','2','28135331466620061','0');
INSERT INTO `rlb_custom_program_log` VALUES ('75','2','Valve 5','V','5','2016-06-22 11:34:02','2016-06-22 11:35:02','1','7','2','28135331466620061','0');
INSERT INTO `rlb_custom_program_log` VALUES ('76','2','Pump 1','PS','1','2016-06-22 11:35:02','2016-06-22 11:36:02','1','8','1','28135331466620061','0');
INSERT INTO `rlb_custom_program_log` VALUES ('77','2','Pump 2','PS','2','2016-06-22 11:35:02','2016-06-22 11:36:02','1','8','1','28135331466620061','0');
INSERT INTO `rlb_custom_program_log` VALUES ('78','2','Pump 2','PS','2','2016-06-22 11:35:02','2016-06-22 11:36:02','1','8','1','28135331466620061','0');
INSERT INTO `rlb_custom_program_log` VALUES ('79','2','Relay 6','R','6','2016-06-22 11:36:03','2016-06-22 11:37:03','1','9','1','28135331466620061','0');
INSERT INTO `rlb_custom_program_log` VALUES ('80','2','Valve 4','V','4','2016-06-22 11:38:02','2016-06-22 11:39:02','1','1','1','28135331466620061','1');
INSERT INTO `rlb_custom_program_log` VALUES ('81','2','Valve 4','V','4','2016-06-22 11:41:17','2016-06-22 11:42:17','1','1','1','81358431466620877','0');
INSERT INTO `rlb_custom_program_log` VALUES ('82','2','Valve 5','V','5','2016-06-22 11:43:02','2016-06-22 11:44:02','1','2','1','81358431466620877','0');
INSERT INTO `rlb_custom_program_log` VALUES ('83','2','Valve 6','V','6','2016-06-22 11:44:02','2016-06-22 11:45:02','1','3','1','81358431466620877','0');
INSERT INTO `rlb_custom_program_log` VALUES ('84','2','Valve 0','V','0','2016-06-22 11:45:02','2016-06-22 11:46:02','1','4','2','81358431466620877','0');
INSERT INTO `rlb_custom_program_log` VALUES ('85','2','Valve 3','V','3','2016-06-22 11:46:02','2016-06-22 11:47:02','1','5','2','81358431466620877','0');
INSERT INTO `rlb_custom_program_log` VALUES ('86','2','Valve 4','V','4','2016-06-22 11:47:02','2016-06-22 11:48:02','1','6','2','81358431466620877','0');
INSERT INTO `rlb_custom_program_log` VALUES ('87','2','Valve 5','V','5','2016-06-22 11:48:02','2016-06-22 11:49:02','1','7','2','81358431466620877','0');
INSERT INTO `rlb_custom_program_log` VALUES ('88','2','Pump 1','PS','1','2016-06-22 11:49:02','2016-06-22 11:50:02','1','8','1','81358431466620877','0');
INSERT INTO `rlb_custom_program_log` VALUES ('89','2','Pump 2','PS','2','2016-06-22 11:49:03','2016-06-22 11:50:03','1','8','1','81358431466620877','0');
INSERT INTO `rlb_custom_program_log` VALUES ('90','2','Pump 2','PS','2','2016-06-22 11:49:03','2016-06-22 11:50:03','1','8','1','81358431466620877','0');
INSERT INTO `rlb_custom_program_log` VALUES ('91','2','Valve 2','V','2','2016-06-22 11:49:03','2016-06-22 11:50:03','1','8','2','81358431466620877','0');
INSERT INTO `rlb_custom_program_log` VALUES ('92','2','Valve 4','V','4','2016-06-22 11:51:02','2016-06-22 11:52:02','1','1','1','81358431466620877','1');
INSERT INTO `rlb_custom_program_log` VALUES ('93','2','Valve 5','V','5','2016-06-22 11:52:02','2016-06-22 11:53:02','1','2','1','81358431466620877','1');
INSERT INTO `rlb_custom_program_log` VALUES ('94','2','Valve 6','V','6','2016-06-22 11:53:02','2016-06-22 11:54:02','1','3','1','81358431466620877','1');
INSERT INTO `rlb_custom_program_log` VALUES ('95','2','Valve 0','V','0','2016-06-22 11:54:02','2016-06-22 11:55:02','1','4','2','81358431466620877','1');
INSERT INTO `rlb_custom_program_log` VALUES ('96','2','Valve 3','V','3','2016-06-22 11:55:02','2016-06-22 11:56:02','1','5','2','81358431466620877','1');
INSERT INTO `rlb_custom_program_log` VALUES ('97','2','Valve 4','V','4','2016-06-22 11:56:02','2016-06-22 11:57:02','1','6','2','81358431466620877','1');
INSERT INTO `rlb_custom_program_log` VALUES ('98','2','Valve 5','V','5','2016-06-22 11:57:02','2016-06-22 11:58:02','1','7','2','81358431466620877','1');
INSERT INTO `rlb_custom_program_log` VALUES ('99','2','Valve 5','V','5','2016-06-22 11:58:02','2016-06-22 11:59:02','1','2','1','81358431466620877','1');
INSERT INTO `rlb_custom_program_log` VALUES ('100','2','Valve 6','V','6','2016-06-22 11:59:02','2016-06-22 12:00:02','1','3','1','81358431466620877','1');
INSERT INTO `rlb_custom_program_log` VALUES ('101','2','Valve 4','V','4','2016-06-22 12:04:09','2016-06-22 12:05:09','1','1','1','99767521466622246','0');
INSERT INTO `rlb_custom_program_log` VALUES ('102','2','Valve 5','V','5','2016-06-22 12:06:02','2016-06-22 12:07:02','1','2','1','99767521466622246','0');
INSERT INTO `rlb_custom_program_log` VALUES ('103','2','Valve 6','V','6','2016-06-22 12:08:04','2016-06-22 12:09:04','1','3','1','99767521466622246','0');
INSERT INTO `rlb_custom_program_log` VALUES ('104','2','Valve 0','V','0','2016-06-22 12:10:03','2016-06-22 12:11:03','1','4','2','99767521466622246','0');
INSERT INTO `rlb_custom_program_log` VALUES ('105','2','Valve 2','V','2','2016-06-22 12:12:02','2016-06-22 12:13:02','1','5','2','99767521466622246','0');
INSERT INTO `rlb_custom_program_log` VALUES ('106','2','Valve 3','V','3','2016-06-22 12:13:02','2016-06-22 12:14:02','1','6','2','99767521466622246','0');
INSERT INTO `rlb_custom_program_log` VALUES ('107','2','Valve 4','V','4','2016-06-22 12:14:02','2016-06-22 12:15:02','1','7','2','99767521466622246','0');
INSERT INTO `rlb_custom_program_log` VALUES ('108','2','Valve 5','V','5','2016-06-22 12:15:02','2016-06-22 12:16:02','1','8','2','99767521466622246','0');
INSERT INTO `rlb_custom_program_log` VALUES ('109','2','Pump 1','PS','1','2016-06-22 12:16:03','2016-06-22 12:17:03','1','10','1','99767521466622246','0');
INSERT INTO `rlb_custom_program_log` VALUES ('110','2','Pump 2','PS','2','2016-06-22 12:16:03','2016-06-22 12:17:03','1','10','1','99767521466622246','0');
INSERT INTO `rlb_custom_program_log` VALUES ('111','2','Pump 2','PS','2','2016-06-22 12:16:03','2016-06-22 12:17:03','1','10','1','99767521466622246','0');
INSERT INTO `rlb_custom_program_log` VALUES ('112','2','Relay 6','R','6','2016-06-22 12:18:03','2016-06-22 12:19:03','1','11','1','99767521466622246','0');
INSERT INTO `rlb_custom_program_log` VALUES ('113','2','Valve 4','V','4','2016-06-22 12:20:03','2016-06-22 12:21:03','1','1','1','99767521466622246','1');
INSERT INTO `rlb_custom_program_log` VALUES ('114','2','Valve 5','V','5','2016-06-22 12:22:02','2016-06-22 12:23:02','1','2','1','99767521466622246','1');
INSERT INTO `rlb_custom_program_log` VALUES ('115','2','Valve 6','V','6','2016-06-22 12:23:02','2016-06-22 12:24:02','1','3','1','99767521466622246','1');
INSERT INTO `rlb_custom_program_log` VALUES ('116','2','Valve 0','V','0','2016-06-22 12:24:02','2016-06-22 12:25:02','1','4','2','99767521466622246','1');
INSERT INTO `rlb_custom_program_log` VALUES ('117','2','Valve 2','V','2','2016-06-22 12:25:02','2016-06-22 12:26:02','1','5','2','99767521466622246','1');
INSERT INTO `rlb_custom_program_log` VALUES ('118','2','Valve 3','V','3','2016-06-22 12:26:02','2016-06-22 12:27:02','1','6','2','99767521466622246','1');
INSERT INTO `rlb_custom_program_log` VALUES ('119','2','Valve 4','V','4','2016-06-22 12:27:02','2016-06-22 12:28:02','1','7','2','99767521466622246','1');
INSERT INTO `rlb_custom_program_log` VALUES ('120','2','Valve 5','V','5','2016-06-22 12:28:02','2016-06-22 12:29:02','1','8','2','99767521466622246','1');
INSERT INTO `rlb_custom_program_log` VALUES ('121','2','Valve 4','V','4','2016-06-22 12:41:17','2016-06-22 12:42:17','1','1','1','66604331466624475','0');
INSERT INTO `rlb_custom_program_log` VALUES ('122','2','Valve 5','V','5','2016-06-22 12:43:05','2016-06-22 12:44:05','1','2','1','66604331466624475','0');
INSERT INTO `rlb_custom_program_log` VALUES ('123','2','Valve 6','V','6','2016-06-22 12:45:02','2016-06-22 12:46:02','1','3','1','66604331466624475','0');
INSERT INTO `rlb_custom_program_log` VALUES ('124','2','Valve 0','V','0','2016-06-22 12:47:02','2016-06-22 12:48:02','1','4','2','66604331466624475','0');
INSERT INTO `rlb_custom_program_log` VALUES ('125','2','Valve 2','V','2','2016-06-22 12:48:02','2016-06-22 12:49:02','1','5','2','66604331466624475','0');
INSERT INTO `rlb_custom_program_log` VALUES ('126','2','Valve 3','V','3','2016-06-22 12:49:02','2016-06-22 12:50:02','1','6','2','66604331466624475','0');
INSERT INTO `rlb_custom_program_log` VALUES ('127','2','Valve 4','V','4','2016-06-22 12:50:02','2016-06-22 12:51:02','1','7','2','66604331466624475','0');
INSERT INTO `rlb_custom_program_log` VALUES ('128','2','Valve 5','V','5','2016-06-22 12:52:02','2016-06-22 12:53:02','1','8','2','66604331466624475','0');
INSERT INTO `rlb_custom_program_log` VALUES ('129','2','Pump 1','PS','1','2016-06-22 12:53:02','2016-06-22 14:23:02','1','10','1','66604331466624475','0');
INSERT INTO `rlb_custom_program_log` VALUES ('130','2','Pump 2','PS','2','2016-06-22 12:53:03','2016-06-22 14:23:03','1','10','1','66604331466624475','0');
INSERT INTO `rlb_custom_program_log` VALUES ('131','2','Pump 2','PS','2','2016-06-22 12:53:03','2016-06-22 14:23:03','1','10','1','66604331466624475','0');
INSERT INTO `rlb_custom_program_log` VALUES ('132','2','Valve 4','V','4','2016-06-22 13:05:02','2016-06-22 13:06:02','1','1','1','66604331466624475','1');
INSERT INTO `rlb_custom_program_log` VALUES ('133','2','Valve 5','V','5','2016-06-22 13:06:02','2016-06-22 13:07:02','1','2','1','66604331466624475','1');
INSERT INTO `rlb_custom_program_log` VALUES ('134','2','Valve 6','V','6','2016-06-22 13:07:02','2016-06-22 13:08:02','1','3','1','66604331466624475','1');
INSERT INTO `rlb_custom_program_log` VALUES ('135','2','Valve 0','V','0','2016-06-22 13:08:02','2016-06-22 13:09:02','1','4','2','66604331466624475','1');
INSERT INTO `rlb_custom_program_log` VALUES ('136','2','Valve 2','V','2','2016-06-22 13:09:02','2016-06-22 13:10:02','1','5','2','66604331466624475','1');
INSERT INTO `rlb_custom_program_log` VALUES ('137','2','Valve 3','V','3','2016-06-22 13:10:02','2016-06-22 13:11:02','1','6','2','66604331466624475','1');
INSERT INTO `rlb_custom_program_log` VALUES ('138','2','Valve 4','V','4','2016-06-22 14:09:36','2016-06-22 14:10:36','1','1','1','25134891466629775','0');
INSERT INTO `rlb_custom_program_log` VALUES ('139','2','Valve 5','V','5','2016-06-22 14:11:02','2016-06-22 14:12:02','1','2','1','25134891466629775','0');
INSERT INTO `rlb_custom_program_log` VALUES ('140','2','Valve 6','V','6','2016-06-22 14:12:02','2016-06-22 14:13:02','1','3','1','25134891466629775','0');
INSERT INTO `rlb_custom_program_log` VALUES ('141','2','Valve 0','V','0','2016-06-22 14:13:02','2016-06-22 14:14:02','1','4','2','25134891466629775','0');
INSERT INTO `rlb_custom_program_log` VALUES ('142','2','Valve 2','V','2','2016-06-22 14:15:02','2016-06-22 14:16:02','1','5','2','25134891466629775','0');
INSERT INTO `rlb_custom_program_log` VALUES ('143','2','Valve 3','V','3','2016-06-22 14:16:02','2016-06-22 14:17:02','1','6','2','25134891466629775','0');
INSERT INTO `rlb_custom_program_log` VALUES ('144','2','Valve 4','V','4','2016-06-22 14:17:02','2016-06-22 14:18:02','1','7','2','25134891466629775','0');
INSERT INTO `rlb_custom_program_log` VALUES ('145','2','Valve 5','V','5','2016-06-22 14:18:03','2016-06-22 14:19:03','1','8','2','25134891466629775','0');
INSERT INTO `rlb_custom_program_log` VALUES ('146','2','Pump 1','PS','1','2016-06-22 14:19:05','2016-06-22 15:49:05','1','10','1','25134891466629775','0');
INSERT INTO `rlb_custom_program_log` VALUES ('147','2','Pump 2','PS','2','2016-06-22 14:19:07','2016-06-22 15:49:07','1','10','1','25134891466629775','0');
INSERT INTO `rlb_custom_program_log` VALUES ('148','2','Pump 2','PS','2','2016-06-22 14:19:07','2016-06-22 15:49:07','1','10','1','25134891466629775','0');
INSERT INTO `rlb_custom_program_log` VALUES ('149','2','Valve 4','V','4','2016-06-22 15:29:02','2016-06-22 15:30:02','1','1','1','25134891466629775','1');
INSERT INTO `rlb_custom_program_log` VALUES ('150','2','Valve 5','V','5','2016-06-22 15:30:02','2016-06-22 15:31:02','1','2','1','25134891466629775','1');
INSERT INTO `rlb_custom_program_log` VALUES ('151','2','Valve 6','V','6','2016-06-22 15:31:02','2016-06-22 15:32:02','1','3','1','25134891466629775','1');
INSERT INTO `rlb_custom_program_log` VALUES ('152','2','Valve 0','V','0','2016-06-22 15:32:02','2016-06-22 15:33:02','1','4','2','25134891466629775','1');
INSERT INTO `rlb_custom_program_log` VALUES ('153','2','Valve 2','V','2','2016-06-22 15:33:02','2016-06-22 15:34:02','1','5','2','25134891466629775','1');
INSERT INTO `rlb_custom_program_log` VALUES ('154','1','Valve 0','V','0','2016-06-22 15:37:04','2016-06-22 15:38:04','1','1','2','34382601466635023','0');
INSERT INTO `rlb_custom_program_log` VALUES ('155','1','Valve 3','V','3','2016-06-22 15:39:02','2016-06-22 15:40:02','1','2','2','34382601466635023','0');
INSERT INTO `rlb_custom_program_log` VALUES ('156','1','Valve 4','V','4','2016-06-22 15:40:02','2016-06-22 15:41:02','1','3','1','34382601466635023','0');
INSERT INTO `rlb_custom_program_log` VALUES ('157','1','Valve 4','V','4','2016-06-22 15:41:02','2016-06-22 15:42:02','1','4','2','34382601466635023','0');
INSERT INTO `rlb_custom_program_log` VALUES ('158','1','Valve 5','V','5','2016-06-22 15:42:02','2016-06-22 15:43:02','1','5','2','34382601466635023','0');
INSERT INTO `rlb_custom_program_log` VALUES ('159','1','Valve 0','V','0','2016-06-22 15:51:14','2016-06-22 15:52:14','1','1','2','81736201466635874','0');
INSERT INTO `rlb_custom_program_log` VALUES ('160','1','Valve 3','V','3','2016-06-22 15:53:01','2016-06-22 15:54:01','1','2','2','81736201466635874','0');
INSERT INTO `rlb_custom_program_log` VALUES ('161','1','Valve 0','V','0','2016-06-22 15:59:17','2016-06-22 16:00:17','1','1','2','90924281466636356','0');
INSERT INTO `rlb_custom_program_log` VALUES ('162','1','Valve 3','V','3','2016-06-22 16:01:02','2016-06-22 16:02:02','1','2','2','90924281466636356','0');
INSERT INTO `rlb_custom_program_log` VALUES ('163','1','Valve 4','V','4','2016-06-22 16:02:02','2016-06-22 16:03:02','1','3','1','90924281466636356','0');
INSERT INTO `rlb_custom_program_log` VALUES ('164','1','Valve 4','V','4','2016-06-22 16:03:02','2016-06-22 16:04:02','1','4','2','90924281466636356','0');
INSERT INTO `rlb_custom_program_log` VALUES ('165','1','Valve 5','V','5','2016-06-22 16:04:02','2016-06-22 16:05:02','1','5','2','90924281466636356','0');
INSERT INTO `rlb_custom_program_log` VALUES ('166','1','Valve 0','V','0','2016-06-22 16:12:51','2016-06-22 16:13:51','1','1','2','37059441466637170','0');
INSERT INTO `rlb_custom_program_log` VALUES ('167','1','Valve 0','V','0','2016-06-22 16:14:02','2016-06-22 16:15:02','1','1','2','37059441466637170','1');
INSERT INTO `rlb_custom_program_log` VALUES ('168','1','Valve 3','V','3','2016-06-22 16:15:02','2016-06-22 16:16:02','1','2','2','37059441466637170','1');
INSERT INTO `rlb_custom_program_log` VALUES ('169','1','Valve 4','V','4','2016-06-22 16:16:03','2016-06-22 16:17:03','1','3','1','37059441466637170','1');
INSERT INTO `rlb_custom_program_log` VALUES ('170','1','Valve 4','V','4','2016-06-22 16:18:02','2016-06-22 16:19:02','1','4','2','37059441466637170','1');
INSERT INTO `rlb_custom_program_log` VALUES ('171','1','Valve 5','V','5','2016-06-22 16:19:02','2016-06-22 16:20:02','1','5','2','37059441466637170','1');
INSERT INTO `rlb_custom_program_log` VALUES ('172','3','Pump 1','PS','1','2016-06-23 03:13:16','2016-06-23 03:14:16','1','1','1','92425531466676790','0');
INSERT INTO `rlb_custom_program_log` VALUES ('173','3','Pump 1','PS','1','2016-06-23 03:31:34','2016-06-23 03:32:34','1','1','1','92425531466676791','0');
INSERT INTO `rlb_custom_program_log` VALUES ('174','3','Valve 0','V','0','2016-06-23 03:34:21','2016-06-23 03:35:21','1','2','1','92425531466676791','0');
INSERT INTO `rlb_custom_program_log` VALUES ('175','3','Relay 6','R','6','2016-06-23 03:48:54','2016-06-23 03:53:54','1','3','1','92425531466676791','0');
INSERT INTO `rlb_custom_program_log` VALUES ('176','3','Power Center 0','P','0','2016-06-23 03:48:55','2016-06-23 03:53:55','1','3','1','92425531466676791','0');
INSERT INTO `rlb_custom_program_log` VALUES ('177','3','Pump 1','PS','1','2016-06-23 05:05:20','2016-06-23 05:06:20','1','1','1','97496391466683517','0');
INSERT INTO `rlb_custom_program_log` VALUES ('178','3','Valve 0','V','0','2016-06-23 05:08:06','2016-06-23 05:09:06','1','2','1','97496391466683517','0');
INSERT INTO `rlb_custom_program_log` VALUES ('179','3','Relay 6','R','6','2016-06-23 05:10:02','2016-06-23 05:10:02','1','3','1','97496391466683517','0');
INSERT INTO `rlb_custom_program_log` VALUES ('180','3','Power Center 0','P','0','2016-06-23 05:11:02','2016-06-23 05:11:02','1','4','1','97496391466683517','0');
INSERT INTO `rlb_custom_program_log` VALUES ('181','3','Pump 1','PS','1','2016-06-23 05:16:26','2016-06-23 05:17:26','1','1','1','38308181466684184','0');
INSERT INTO `rlb_custom_program_log` VALUES ('182','3','Pump 1','PS','1','2016-06-23 05:21:47','2016-06-23 05:22:47','1','1','1','36490781466684506','0');
INSERT INTO `rlb_custom_program_log` VALUES ('183','1','Valve 0','V','0','2016-06-23 09:37:31','2016-06-23 09:38:31','1','1','2','22995911466699850','0');
INSERT INTO `rlb_custom_program_log` VALUES ('184','1','Valve 3','V','3','2016-06-23 09:39:02','2016-06-23 09:40:02','1','2','2','22995911466699850','0');
INSERT INTO `rlb_custom_program_log` VALUES ('185','1','Valve 4','V','4','2016-06-23 09:40:03','2016-06-23 09:41:03','1','3','1','22995911466699850','0');
INSERT INTO `rlb_custom_program_log` VALUES ('186','1','Valve 4','V','4','2016-06-23 09:42:02','2016-06-23 09:43:02','1','4','2','22995911466699850','0');
INSERT INTO `rlb_custom_program_log` VALUES ('187','1','Valve 5','V','5','2016-06-23 09:43:02','2016-06-23 09:44:02','1','5','2','22995911466699850','0');
INSERT INTO `rlb_custom_program_log` VALUES ('188','1','Valve 0','V','0','2016-06-23 09:45:02','2016-06-23 09:46:02','1','1','2','22995911466699850','0');
INSERT INTO `rlb_custom_program_log` VALUES ('189','1','Valve 3','V','3','2016-06-23 09:46:02','2016-06-23 09:47:02','1','1','2','22995911466699850','1');
INSERT INTO `rlb_custom_program_log` VALUES ('190','1','Valve 5','V','5','2016-06-23 09:47:02','2016-06-23 09:48:02','1','5','2','22995911466699850','1');
INSERT INTO `rlb_custom_program_log` VALUES ('191','1','Valve 0','V','0','2016-06-23 09:49:59','2016-06-23 09:50:59','1','1','2','84483801466700598','0');
INSERT INTO `rlb_custom_program_log` VALUES ('192','1','Valve 3','V','3','2016-06-23 09:51:02','2016-06-23 09:52:02','1','2','2','84483801466700598','0');
INSERT INTO `rlb_custom_program_log` VALUES ('193','1','Valve 4','V','4','2016-06-23 09:52:02','2016-06-23 09:53:02','1','3','1','84483801466700598','0');
INSERT INTO `rlb_custom_program_log` VALUES ('194','1','Valve 4','V','4','2016-06-23 09:53:02','2016-06-23 09:54:02','1','4','2','84483801466700598','0');
INSERT INTO `rlb_custom_program_log` VALUES ('195','1','Valve 5','V','5','2016-06-23 09:54:02','2016-06-23 09:55:02','1','5','2','84483801466700598','0');
INSERT INTO `rlb_custom_program_log` VALUES ('196','1','Valve 0','V','0','2016-06-23 09:56:02','2016-06-23 09:57:02','1','1','2','84483801466700598','0');
INSERT INTO `rlb_custom_program_log` VALUES ('197','1','Valve 3','V','3','2016-06-23 09:57:02','2016-06-23 09:58:02','1','1','2','84483801466700598','1');
INSERT INTO `rlb_custom_program_log` VALUES ('198','1','Valve 5','V','5','2016-06-23 09:58:02','2016-06-23 09:59:02','1','5','2','84483801466700598','1');
INSERT INTO `rlb_custom_program_log` VALUES ('199','1','Valve 0','V','0','2016-06-23 10:17:58','2016-06-23 10:18:58','1','1','2','89742981466702278','0');
INSERT INTO `rlb_custom_program_log` VALUES ('200','1','Valve 3','V','3','2016-06-23 10:19:02','2016-06-23 10:20:02','1','2','2','89742981466702278','0');
INSERT INTO `rlb_custom_program_log` VALUES ('201','1','Valve 4','V','4','2016-06-23 10:20:02','2016-06-23 10:21:02','1','3','1','89742981466702278','0');
INSERT INTO `rlb_custom_program_log` VALUES ('202','1','Valve 4','V','4','2016-06-23 10:22:02','2016-06-23 10:23:02','1','4','2','89742981466702278','0');
INSERT INTO `rlb_custom_program_log` VALUES ('203','1','Valve 5','V','5','2016-06-23 10:23:03','2016-06-23 10:24:03','1','5','2','89742981466702278','0');
INSERT INTO `rlb_custom_program_log` VALUES ('204','1','Pump 1','PS','1','2016-06-23 10:25:02','2016-06-23 11:25:02','1','6','1','89742981466702278','0');
INSERT INTO `rlb_custom_program_log` VALUES ('205','1','Power Center 0','P','0','2016-06-23 10:25:02','2016-06-23 11:25:02','1','6','1','89742981466702278','0');
INSERT INTO `rlb_custom_program_log` VALUES ('206','1','Valve 0','V','0','2016-06-23 10:30:09','2016-06-23 10:31:09','1','1','2','55988771466703008','0');
INSERT INTO `rlb_custom_program_log` VALUES ('207','1','Valve 3','V','3','2016-06-23 10:32:02','2016-06-23 10:33:02','1','2','2','55988771466703008','0');
INSERT INTO `rlb_custom_program_log` VALUES ('208','1','Valve 4','V','4','2016-06-23 10:33:02','2016-06-23 10:34:02','1','3','1','55988771466703008','0');
INSERT INTO `rlb_custom_program_log` VALUES ('209','1','Valve 4','V','4','2016-06-23 10:34:02','2016-06-23 10:35:02','1','4','2','55988771466703008','0');
INSERT INTO `rlb_custom_program_log` VALUES ('210','1','Valve 5','V','5','2016-06-23 10:35:02','2016-06-23 10:36:02','1','5','2','55988771466703008','0');
INSERT INTO `rlb_custom_program_log` VALUES ('211','1','Valve 0','V','0','2016-06-23 10:36:10','2016-06-23 10:37:10','1','1','2','86783131466703369','0');
INSERT INTO `rlb_custom_program_log` VALUES ('212','1','Valve 3','V','3','2016-06-23 10:38:02','2016-06-23 10:39:02','1','2','2','86783131466703369','0');
INSERT INTO `rlb_custom_program_log` VALUES ('213','1','Valve 4','V','4','2016-06-23 10:39:02','2016-06-23 10:40:02','1','3','1','86783131466703369','0');
INSERT INTO `rlb_custom_program_log` VALUES ('214','1','Valve 4','V','4','2016-06-23 10:40:02','2016-06-23 10:41:02','1','4','2','86783131466703369','0');
INSERT INTO `rlb_custom_program_log` VALUES ('215','1','Valve 5','V','5','2016-06-23 10:41:02','2016-06-23 10:42:02','1','5','2','86783131466703369','0');
INSERT INTO `rlb_custom_program_log` VALUES ('216','1','Valve 0','V','0','2016-06-23 10:43:02','2016-06-23 10:44:02','1','1','2','86783131466703369','0');
INSERT INTO `rlb_custom_program_log` VALUES ('217','1','Valve 3','V','3','2016-06-23 10:44:02','2016-06-23 10:45:02','1','1','2','86783131466703369','1');
INSERT INTO `rlb_custom_program_log` VALUES ('218','1','Valve 5','V','5','2016-06-23 10:45:02','2016-06-23 10:46:02','1','5','2','86783131466703369','1');
INSERT INTO `rlb_custom_program_log` VALUES ('219','1','Valve 0','V','0','2016-06-23 10:52:20','2016-06-23 10:53:20','1','1','2','39688921466704340','0');
INSERT INTO `rlb_custom_program_log` VALUES ('220','1','Valve 3','V','3','2016-06-23 10:54:02','2016-06-23 10:55:02','1','2','2','39688921466704340','0');
INSERT INTO `rlb_custom_program_log` VALUES ('221','1','Valve 4','V','4','2016-06-23 10:55:03','2016-06-23 10:56:03','1','3','1','39688921466704340','0');
INSERT INTO `rlb_custom_program_log` VALUES ('222','1','Valve 4','V','4','2016-06-23 10:56:03','2016-06-23 10:57:03','1','4','2','39688921466704340','0');
INSERT INTO `rlb_custom_program_log` VALUES ('223','1','Valve 5','V','5','2016-06-23 10:58:02','2016-06-23 10:59:02','1','5','2','39688921466704340','0');
INSERT INTO `rlb_custom_program_log` VALUES ('224','1','Pump 1','PS','1','2016-06-23 10:59:04','2016-06-23 11:59:04','1','6','1','39688921466704340','0');
INSERT INTO `rlb_custom_program_log` VALUES ('225','1','Pump 2','PS','2','2016-06-23 10:59:04','2016-06-23 11:54:04','1','6','1','39688921466704340','0');
INSERT INTO `rlb_custom_program_log` VALUES ('226','1','Relay 15','R','15','2016-06-23 10:59:04','2016-06-23 11:54:04','1','6','1','39688921466704340','0');
INSERT INTO `rlb_custom_program_log` VALUES ('227','1','Pump 1','PS','1','2016-06-23 10:59:04','2016-06-23 11:59:04','1','6','1','39688921466704340','0');
INSERT INTO `rlb_custom_program_log` VALUES ('228','1','Power Center 0','P','0','2016-06-23 10:59:04','2016-06-23 11:59:04','1','6','1','39688921466704340','0');
INSERT INTO `rlb_custom_program_log` VALUES ('229','1','Valve 3','V','3','2016-06-23 12:00:02','2016-06-23 12:01:02','1','1','2','39688921466704340','1');
INSERT INTO `rlb_custom_program_log` VALUES ('230','1','Valve 5','V','5','2016-06-23 12:01:02','2016-06-23 12:02:02','1','5','2','39688921466704340','1');
INSERT INTO `rlb_custom_program_log` VALUES ('231','3','Power Center 1','P','1','2016-06-24 03:28:12','2016-06-24 03:29:12','1','1','1','89298801466764092','0');
INSERT INTO `rlb_custom_program_log` VALUES ('232','3','Power Center 2','P','2','2016-06-24 03:28:13','2016-06-24 03:29:13','1','1','1','89298801466764092','0');
INSERT INTO `rlb_custom_program_log` VALUES ('233','3','Power Center 2','P','2','2016-06-24 03:28:13','2016-06-24 03:29:13','1','1','1','89298801466764092','0');
INSERT INTO `rlb_custom_program_log` VALUES ('234','3','Relay 14','R','14','2016-06-24 03:30:03','2016-06-24 03:31:03','1','2','1','89298801466764092','0');
INSERT INTO `rlb_custom_program_log` VALUES ('235','3','Power Center 1','P','1','2016-06-24 03:33:02','2016-06-24 03:34:02','1','1','1','89298801466764092','0');
INSERT INTO `rlb_custom_program_log` VALUES ('236','3','Power Center 2','P','2','2016-06-24 03:33:02','2016-06-24 03:34:02','1','1','1','89298801466764092','0');
INSERT INTO `rlb_custom_program_log` VALUES ('237','3','Power Center 2','P','2','2016-06-24 03:33:02','2016-06-24 03:34:02','1','1','1','89298801466764092','0');
INSERT INTO `rlb_custom_program_log` VALUES ('238','3','Power Center 0','P','0','2016-06-24 03:47:34','2016-06-24 03:48:34','1','1','1','8929880146676409211','0');
INSERT INTO `rlb_custom_program_log` VALUES ('239','3','Power Center 0','P','0','2016-06-24 04:41:00','2016-06-24 04:42:00','1','1','1','35523011466768460','0');
INSERT INTO `rlb_custom_program_log` VALUES ('240','3','Relay 6','R','6','2016-06-24 04:42:33','2016-06-24 04:43:33','1','2','1','35523011466768460','0');
INSERT INTO `rlb_custom_program_log` VALUES ('241','3','Pump 2','PS','2','2016-06-24 05:07:49','2016-06-24 05:08:49','1','3','1','35523011466768460','0');
INSERT INTO `rlb_custom_program_log` VALUES ('242','3','Pump 1','PS','1','2016-06-24 05:09:18','2016-06-24 05:10:18','1','4','1','35523011466768460','0');
INSERT INTO `rlb_custom_program_log` VALUES ('243','3','Power Center 0','P','0','2016-06-24 05:15:09','2016-06-24 05:16:09','1','1','1','40389111466770509','0');
INSERT INTO `rlb_custom_program_log` VALUES ('244','3','Relay 6','R','6','2016-06-24 05:17:02','2016-06-24 05:18:02','1','2','1','40389111466770509','0');
INSERT INTO `rlb_custom_program_log` VALUES ('245','3','Pump 2','PS','2','2016-06-24 05:18:03','2016-06-24 05:28:03','1','3','1','40389111466770509','0');
INSERT INTO `rlb_custom_program_log` VALUES ('246','3','Pump 1','PS','1','2016-06-24 05:29:02','2016-06-24 05:39:02','1','4','1','40389111466770509','0');
INSERT INTO `rlb_custom_program_log` VALUES ('247','1','Valve 0','V','0','2016-06-27 09:29:35','2016-06-27 09:30:35','1','1','2','43834421467044975','0');
INSERT INTO `rlb_custom_program_log` VALUES ('248','1','Valve 3','V','3','2016-06-27 09:31:02','2016-06-27 09:32:02','1','2','2','43834421467044975','0');
INSERT INTO `rlb_custom_program_log` VALUES ('249','1','Valve 4','V','4','2016-06-27 09:32:02','2016-06-27 09:33:02','1','3','1','43834421467044975','0');
INSERT INTO `rlb_custom_program_log` VALUES ('250','1','Valve 4','V','4','2016-06-27 09:33:02','2016-06-27 09:34:02','1','4','2','43834421467044975','0');
INSERT INTO `rlb_custom_program_log` VALUES ('251','1','Valve 5','V','5','2016-06-27 09:34:02','2016-06-27 09:35:02','1','5','2','43834421467044975','0');
INSERT INTO `rlb_custom_program_log` VALUES ('252','1','Pump 1','PS','1','2016-06-27 09:35:03','2016-06-27 10:35:03','1','6','1','43834421467044975','0');
INSERT INTO `rlb_custom_program_log` VALUES ('253','1','Pump 2','PS','2','2016-06-27 09:35:03','2016-06-27 10:30:03','1','6','1','43834421467044975','0');
INSERT INTO `rlb_custom_program_log` VALUES ('254','1','Pump 2','PS','2','2016-06-27 09:35:03','2016-06-27 10:30:03','1','6','1','43834421467044975','0');
INSERT INTO `rlb_custom_program_log` VALUES ('255','1','Relay 15','R','15','2016-06-27 09:35:03','2016-06-27 10:30:03','1','6','1','43834421467044975','0');
INSERT INTO `rlb_custom_program_log` VALUES ('256','1','Power Center 0','P','0','2016-06-27 09:35:03','2016-06-27 10:35:03','1','6','1','43834421467044975','0');
INSERT INTO `rlb_custom_program_log` VALUES ('257','1','Valve 3','V','3','2016-06-27 09:40:02','2016-06-27 09:41:02','1','1','2','43834421467044975','1');
INSERT INTO `rlb_custom_program_log` VALUES ('258','1','Valve 4','V','4','2016-06-27 09:41:02','2016-06-27 09:42:02','1','3','1','43834421467044975','1');
INSERT INTO `rlb_custom_program_log` VALUES ('259','1','Valve 0','V','0','2016-06-27 09:49:38','2016-06-27 09:50:38','1','1','2','44708561467046176','0');
INSERT INTO `rlb_custom_program_log` VALUES ('260','1','Valve 3','V','3','2016-06-27 09:51:02','2016-06-27 09:52:02','1','2','2','44708561467046176','0');
INSERT INTO `rlb_custom_program_log` VALUES ('261','1','Valve 4','V','4','2016-06-27 09:52:03','2016-06-27 09:53:03','1','3','1','44708561467046176','0');
INSERT INTO `rlb_custom_program_log` VALUES ('262','1','Valve 4','V','4','2016-06-27 09:54:02','2016-06-27 09:55:02','1','4','2','44708561467046176','0');
INSERT INTO `rlb_custom_program_log` VALUES ('263','1','Valve 5','V','5','2016-06-27 09:55:03','2016-06-27 09:56:03','1','5','2','44708561467046176','0');
INSERT INTO `rlb_custom_program_log` VALUES ('264','1','Valve 5','V','5','2016-06-27 09:57:03','2016-06-27 09:58:03','1','6','1','44708561467046176','0');
INSERT INTO `rlb_custom_program_log` VALUES ('265','1','Valve 6','V','6','2016-06-27 09:57:03','2016-06-27 09:58:03','1','6','1','44708561467046176','0');
INSERT INTO `rlb_custom_program_log` VALUES ('266','1','Valve 6','V','6','2016-06-27 09:57:03','2016-06-27 09:58:03','1','6','1','44708561467046176','0');
INSERT INTO `rlb_custom_program_log` VALUES ('267','1','Pump 1','PS','1','2016-06-27 09:59:03','2016-06-27 10:59:03','1','7','1','44708561467046176','0');
INSERT INTO `rlb_custom_program_log` VALUES ('268','1','Pump 2','PS','2','2016-06-27 09:59:03','2016-06-27 10:54:03','1','7','1','44708561467046176','0');
INSERT INTO `rlb_custom_program_log` VALUES ('269','1','Pump 2','PS','2','2016-06-27 09:59:03','2016-06-27 10:54:03','1','7','1','44708561467046176','0');
INSERT INTO `rlb_custom_program_log` VALUES ('270','1','Relay 15','R','15','2016-06-27 09:59:03','2016-06-27 10:54:03','1','7','1','44708561467046176','0');
INSERT INTO `rlb_custom_program_log` VALUES ('271','1','Power Center 0','P','0','2016-06-27 09:59:03','2016-06-27 10:59:03','1','7','1','44708561467046176','0');
INSERT INTO `rlb_custom_program_log` VALUES ('272','1','Valve 4','V','4','2016-06-27 10:10:02','2016-06-27 10:11:02','1','1','1','44708561467046176','1');
INSERT INTO `rlb_custom_program_log` VALUES ('273','1','Valve 0','V','0','2016-06-27 10:29:45','2016-06-27 10:30:45','1','1','2','98075381467048585','0');
INSERT INTO `rlb_custom_program_log` VALUES ('274','1','Valve 3','V','3','2016-06-27 10:31:02','2016-06-27 10:32:02','1','2','2','98075381467048585','0');
INSERT INTO `rlb_custom_program_log` VALUES ('275','1','Valve 4','V','4','2016-06-27 10:32:02','2016-06-27 10:33:02','1','3','1','98075381467048585','0');
INSERT INTO `rlb_custom_program_log` VALUES ('276','1','Valve 4','V','4','2016-06-27 10:33:02','2016-06-27 10:34:02','1','4','2','98075381467048585','0');
INSERT INTO `rlb_custom_program_log` VALUES ('277','1','Valve 5','V','5','2016-06-27 10:34:02','2016-06-27 10:35:02','1','5','2','98075381467048585','0');
INSERT INTO `rlb_custom_program_log` VALUES ('278','1','Valve 5','V','5','2016-06-27 10:35:02','2016-06-27 10:36:02','1','6','1','98075381467048585','0');
INSERT INTO `rlb_custom_program_log` VALUES ('279','1','Valve 6','V','6','2016-06-27 10:35:02','2016-06-27 10:36:02','1','6','1','98075381467048585','0');
INSERT INTO `rlb_custom_program_log` VALUES ('280','1','Valve 6','V','6','2016-06-27 10:35:02','2016-06-27 10:36:02','1','6','1','98075381467048585','0');
INSERT INTO `rlb_custom_program_log` VALUES ('281','1','Pump 1','PS','1','2016-06-27 10:36:03','2016-06-27 11:36:03','1','7','1','98075381467048585','0');
INSERT INTO `rlb_custom_program_log` VALUES ('282','1','Pump 2','PS','2','2016-06-27 10:36:03','2016-06-27 11:31:03','1','7','1','98075381467048585','0');
INSERT INTO `rlb_custom_program_log` VALUES ('283','1','Pump 2','PS','2','2016-06-27 10:36:03','2016-06-27 11:31:03','1','7','1','98075381467048585','0');
INSERT INTO `rlb_custom_program_log` VALUES ('284','1','Relay 15','R','15','2016-06-27 10:36:03','2016-06-27 11:31:03','1','7','1','98075381467048585','0');
INSERT INTO `rlb_custom_program_log` VALUES ('285','1','Power Center 0','P','0','2016-06-27 10:36:03','2016-06-27 11:31:03','1','7','1','98075381467048585','0');
INSERT INTO `rlb_custom_program_log` VALUES ('286','1','Valve 0','V','0','2016-06-27 10:54:03','2016-06-27 10:55:03','1','1','2','98075381467048585','1');
INSERT INTO `rlb_custom_program_log` VALUES ('287','1','Valve 0','V','0','2016-06-27 10:54:13','2016-06-27 10:55:13','1','1','2','21632711467050052','0');
INSERT INTO `rlb_custom_program_log` VALUES ('288','1','Valve 0','V','0','2016-06-27 10:55:02','2016-06-27 10:56:02','1','1','2','21632711467050052','1');
INSERT INTO `rlb_custom_program_log` VALUES ('289','1','Valve 4','V','4','2016-06-27 10:56:02','2016-06-27 10:57:02','1','3','1','21632711467050052','1');
INSERT INTO `rlb_custom_program_log` VALUES ('290','1','Valve 0','V','0','2016-06-27 11:02:37','2016-06-27 11:03:37','1','1','2','35834431467050556','0');
INSERT INTO `rlb_custom_program_log` VALUES ('291','1','Valve 3','V','3','2016-06-27 11:04:02','2016-06-27 11:05:02','1','2','2','35834431467050556','0');
INSERT INTO `rlb_custom_program_log` VALUES ('292','1','Valve 4','V','4','2016-06-27 11:05:02','2016-06-27 11:06:02','1','3','1','35834431467050556','0');
INSERT INTO `rlb_custom_program_log` VALUES ('293','1','Valve 4','V','4','2016-06-27 11:06:03','2016-06-27 11:07:03','1','4','2','35834431467050556','0');
INSERT INTO `rlb_custom_program_log` VALUES ('294','1','Valve 5','V','5','2016-06-27 11:08:02','2016-06-27 11:09:02','1','5','2','35834431467050556','0');
INSERT INTO `rlb_custom_program_log` VALUES ('295','1','Valve 5','V','5','2016-06-27 11:09:02','2016-06-27 11:10:02','1','6','1','35834431467050556','0');
INSERT INTO `rlb_custom_program_log` VALUES ('296','1','Valve 6','V','6','2016-06-27 11:09:02','2016-06-27 11:10:02','1','6','1','35834431467050556','0');
INSERT INTO `rlb_custom_program_log` VALUES ('297','1','Valve 6','V','6','2016-06-27 11:09:02','2016-06-27 11:10:02','1','6','1','35834431467050556','0');
INSERT INTO `rlb_custom_program_log` VALUES ('298','1','Pump 1','PS','1','2016-06-27 11:10:02','2016-06-27 12:10:02','1','7','1','35834431467050556','0');
INSERT INTO `rlb_custom_program_log` VALUES ('299','1','Pump 2','PS','2','2016-06-27 11:10:03','2016-06-27 12:05:03','1','7','1','35834431467050556','0');
INSERT INTO `rlb_custom_program_log` VALUES ('300','1','Pump 2','PS','2','2016-06-27 11:10:03','2016-06-27 12:05:03','1','7','1','35834431467050556','0');
INSERT INTO `rlb_custom_program_log` VALUES ('301','1','Relay 15','R','15','2016-06-27 11:10:03','2016-06-27 12:05:03','1','7','1','35834431467050556','0');
INSERT INTO `rlb_custom_program_log` VALUES ('302','1','Power Center 0','P','0','2016-06-27 11:10:03','2016-06-27 12:05:03','1','7','1','35834431467050556','0');
INSERT INTO `rlb_custom_program_log` VALUES ('303','1','Valve 0','V','0','2016-06-27 11:12:02','2016-06-27 11:13:02','1','1','2','35834431467050556','1');
INSERT INTO `rlb_custom_program_log` VALUES ('304','1','Valve 4','V','4','2016-06-27 11:13:02','2016-06-27 11:14:02','1','3','1','35834431467050556','1');
INSERT INTO `rlb_custom_program_log` VALUES ('305','6','Valve 1','V','1','2016-06-27 11:17:57','2016-06-27 11:18:57','1','1','2','17412101467051477','0');
INSERT INTO `rlb_custom_program_log` VALUES ('306','6','Valve 5','V','5','2016-06-27 11:19:02','2016-06-27 11:20:02','1','2','1','17412101467051477','0');
INSERT INTO `rlb_custom_program_log` VALUES ('307','6','Valve 6','V','6','2016-06-27 11:19:02','2016-06-27 11:20:02','1','2','1','17412101467051477','0');
INSERT INTO `rlb_custom_program_log` VALUES ('308','6','Valve 6','V','6','2016-06-27 11:19:02','2016-06-27 11:20:02','1','2','1','17412101467051477','0');
INSERT INTO `rlb_custom_program_log` VALUES ('309','6','Pump 2','PS','2','2016-06-27 11:20:02','2016-06-27 11:45:02','1','3','1','17412101467051477','0');
INSERT INTO `rlb_custom_program_log` VALUES ('310','6','Valve 1','V','1','2016-06-27 11:21:02','2016-06-27 11:22:02','1','1','2','17412101467051477','1');
INSERT INTO `rlb_custom_program_log` VALUES ('311','1','Valve 0','V','0','2016-06-27 11:24:37','2016-06-27 11:25:37','1','1','2','99452241467051876','0');
INSERT INTO `rlb_custom_program_log` VALUES ('312','1','Valve 3','V','3','2016-06-27 11:26:02','2016-06-27 11:27:02','1','2','2','99452241467051876','0');
INSERT INTO `rlb_custom_program_log` VALUES ('313','1','Valve 4','V','4','2016-06-27 11:28:02','2016-06-27 11:29:02','1','3','1','99452241467051876','0');
INSERT INTO `rlb_custom_program_log` VALUES ('314','1','Valve 4','V','4','2016-06-27 11:29:03','2016-06-27 11:30:03','1','4','2','99452241467051876','0');
INSERT INTO `rlb_custom_program_log` VALUES ('315','1','Valve 5','V','5','2016-06-27 11:31:02','2016-06-27 11:32:02','1','5','2','99452241467051876','0');
INSERT INTO `rlb_custom_program_log` VALUES ('316','1','Valve 5','V','5','2016-06-27 11:32:02','2016-06-27 11:33:02','1','6','1','99452241467051876','0');
INSERT INTO `rlb_custom_program_log` VALUES ('317','1','Valve 6','V','6','2016-06-27 11:32:02','2016-06-27 11:33:02','1','6','1','99452241467051876','0');
INSERT INTO `rlb_custom_program_log` VALUES ('318','1','Valve 6','V','6','2016-06-27 11:32:02','2016-06-27 11:33:02','1','6','1','99452241467051876','0');
INSERT INTO `rlb_custom_program_log` VALUES ('319','1','Pump 1','PS','1','2016-06-27 11:33:02','2016-06-27 12:33:02','1','7','1','99452241467051876','0');
INSERT INTO `rlb_custom_program_log` VALUES ('320','1','Pump 2','PS','2','2016-06-27 11:33:02','2016-06-27 12:28:02','1','7','1','99452241467051876','0');
INSERT INTO `rlb_custom_program_log` VALUES ('321','1','Pump 2','PS','2','2016-06-27 11:33:02','2016-06-27 12:28:02','1','7','1','99452241467051876','0');
INSERT INTO `rlb_custom_program_log` VALUES ('322','1','Relay 15','R','15','2016-06-27 11:33:03','2016-06-27 12:28:03','1','7','1','99452241467051876','0');
INSERT INTO `rlb_custom_program_log` VALUES ('323','1','Power Center 0','P','0','2016-06-27 11:33:03','2016-06-27 12:28:03','1','7','1','99452241467051876','0');
INSERT INTO `rlb_custom_program_log` VALUES ('324','1','Valve 0','V','0','2016-06-27 11:36:02','2016-06-27 11:37:02','1','1','2','99452241467051876','1');
INSERT INTO `rlb_custom_program_log` VALUES ('325','1','Valve 4','V','4','2016-06-27 11:37:02','2016-06-27 11:38:02','1','3','1','99452241467051876','1');
INSERT INTO `rlb_custom_program_log` VALUES ('326','1','Valve 6','V','6','2016-06-27 11:38:02','2016-06-27 11:39:02','1','6','1','99452241467051876','1');
INSERT INTO `rlb_custom_program_log` VALUES ('327','1','Valve 0','V','0','2016-06-27 14:01:52','2016-06-27 14:02:52','1','1','2','43635461467061312','0');
INSERT INTO `rlb_custom_program_log` VALUES ('328','1','Valve 3','V','3','2016-06-27 14:03:02','2016-06-27 14:04:02','1','2','2','43635461467061312','0');
INSERT INTO `rlb_custom_program_log` VALUES ('329','1','Valve 4','V','4','2016-06-27 14:04:02','2016-06-27 14:05:02','1','3','1','43635461467061312','0');
INSERT INTO `rlb_custom_program_log` VALUES ('330','1','Valve 4','V','4','2016-06-27 14:05:02','2016-06-27 14:06:02','1','4','2','43635461467061312','0');
INSERT INTO `rlb_custom_program_log` VALUES ('331','1','Valve 5','V','5','2016-06-27 14:06:04','2016-06-27 14:07:04','1','5','2','43635461467061312','0');
INSERT INTO `rlb_custom_program_log` VALUES ('332','1','Valve 5','V','5','2016-06-27 14:08:04','2016-06-27 14:09:04','1','6','1','43635461467061312','0');
INSERT INTO `rlb_custom_program_log` VALUES ('333','1','Valve 6','V','6','2016-06-27 14:08:05','2016-06-27 14:09:05','1','6','1','43635461467061312','0');
INSERT INTO `rlb_custom_program_log` VALUES ('334','1','Valve 6','V','6','2016-06-27 14:08:05','2016-06-27 14:09:05','1','6','1','43635461467061312','0');
INSERT INTO `rlb_custom_program_log` VALUES ('335','1','Pump 1','PS','1','2016-06-27 14:10:05','2016-06-27 15:10:05','1','7','1','43635461467061312','0');
INSERT INTO `rlb_custom_program_log` VALUES ('336','1','Pump 2','PS','2','2016-06-27 14:10:05','2016-06-27 15:05:05','1','7','1','43635461467061312','0');
INSERT INTO `rlb_custom_program_log` VALUES ('337','1','Pump 2','PS','2','2016-06-27 14:10:05','2016-06-27 15:05:05','1','7','1','43635461467061312','0');
INSERT INTO `rlb_custom_program_log` VALUES ('338','1','Relay 15','R','15','2016-06-27 14:10:05','2016-06-27 15:05:05','1','7','1','43635461467061312','0');
INSERT INTO `rlb_custom_program_log` VALUES ('339','1','Power Center 0','P','0','2016-06-27 14:10:05','2016-06-27 15:05:05','1','7','1','43635461467061312','0');
INSERT INTO `rlb_custom_program_log` VALUES ('340','1','Valve 3','V','3','2016-06-27 14:26:04','2016-06-27 14:27:04','1','1','2','43635461467061312','1');
INSERT INTO `rlb_custom_program_log` VALUES ('341','1','Valve 4','V','4','2016-06-27 14:28:05','2016-06-27 14:29:05','1','4','2','43635461467061312','1');
INSERT INTO `rlb_custom_program_log` VALUES ('342','1','Valve 5','V','5','2016-06-27 14:30:04','2016-06-27 14:31:04','1','5','2','43635461467061312','1');
INSERT INTO `rlb_custom_program_log` VALUES ('343','1','Valve 6','V','6','2016-06-27 14:32:03','2016-06-27 14:33:03','1','6','1','43635461467061312','1');
INSERT INTO `rlb_custom_program_log` VALUES ('344','1','Valve 0','V','0','2016-06-27 21:47:26','2016-06-27 21:48:26','1','1','2','19811321467089245','0');
INSERT INTO `rlb_custom_program_log` VALUES ('345','1','Valve 3','V','3','2016-06-27 21:49:02','2016-06-27 21:50:02','1','1','2','19811321467089245','1');
INSERT INTO `rlb_custom_program_log` VALUES ('346','1','Valve 4','V','4','2016-06-27 21:50:02','2016-06-27 21:51:02','1','4','2','19811321467089245','1');
INSERT INTO `rlb_custom_program_log` VALUES ('347','1','Valve 5','V','5','2016-06-27 21:51:02','2016-06-27 21:52:02','1','5','2','19811321467089245','1');
INSERT INTO `rlb_custom_program_log` VALUES ('348','1','Valve 0','V','0','2016-06-27 21:51:21','2016-06-27 21:52:21','1','1','2','72276971467089480','0');
INSERT INTO `rlb_custom_program_log` VALUES ('349','1','Valve 3','V','3','2016-06-27 21:53:02','2016-06-27 21:54:02','1','2','2','72276971467089480','0');
INSERT INTO `rlb_custom_program_log` VALUES ('350','1','Valve 4','V','4','2016-06-27 21:54:02','2016-06-27 21:55:02','1','3','1','72276971467089480','0');
INSERT INTO `rlb_custom_program_log` VALUES ('351','1','Valve 4','V','4','2016-06-27 21:55:02','2016-06-27 21:56:02','1','4','2','72276971467089480','0');
INSERT INTO `rlb_custom_program_log` VALUES ('352','1','Valve 5','V','5','2016-06-27 21:56:02','2016-06-27 21:57:02','1','5','2','72276971467089480','0');
INSERT INTO `rlb_custom_program_log` VALUES ('353','1','Valve 5','V','5','2016-06-27 21:58:02','2016-06-27 21:59:02','1','6','1','72276971467089480','0');
INSERT INTO `rlb_custom_program_log` VALUES ('354','1','Valve 6','V','6','2016-06-27 21:58:02','2016-06-27 21:59:02','1','6','1','72276971467089480','0');
INSERT INTO `rlb_custom_program_log` VALUES ('355','1','Valve 6','V','6','2016-06-27 21:58:02','2016-06-27 21:59:02','1','6','1','72276971467089480','0');
INSERT INTO `rlb_custom_program_log` VALUES ('356','1','Pump 1','PS','1','2016-06-27 21:59:02','2016-06-27 22:59:02','1','7','1','72276971467089480','0');
INSERT INTO `rlb_custom_program_log` VALUES ('357','1','Pump 2','PS','2','2016-06-27 21:59:02','2016-06-27 22:54:02','1','7','1','72276971467089480','0');
INSERT INTO `rlb_custom_program_log` VALUES ('358','1','Pump 2','PS','2','2016-06-27 21:59:02','2016-06-27 22:54:02','1','7','1','72276971467089480','0');
INSERT INTO `rlb_custom_program_log` VALUES ('359','1','Relay 15','R','15','2016-06-27 21:59:02','2016-06-27 22:54:02','1','7','1','72276971467089480','0');
INSERT INTO `rlb_custom_program_log` VALUES ('360','1','Power Center 0','P','0','2016-06-27 21:59:02','2016-06-27 22:54:02','1','7','1','72276971467089480','0');
INSERT INTO `rlb_custom_program_log` VALUES ('361','1','Valve 3','V','3','2016-06-27 22:08:02','2016-06-27 22:09:02','1','1','2','72276971467089480','1');
INSERT INTO `rlb_custom_program_log` VALUES ('362','1','Valve 4','V','4','2016-06-27 22:10:02','2016-06-27 22:11:02','1','4','2','72276971467089480','1');
INSERT INTO `rlb_custom_program_log` VALUES ('363','1','Valve 5','V','5','2016-06-27 22:11:02','2016-06-27 22:12:02','1','5','2','72276971467089480','1');
INSERT INTO `rlb_custom_program_log` VALUES ('364','1','Valve 6','V','6','2016-06-27 22:12:02','2016-06-27 22:13:02','1','6','1','72276971467089480','1');
INSERT INTO `rlb_custom_program_log` VALUES ('365','3','Power Center 0','P','0','2016-06-28 00:08:06','2016-06-28 00:09:06','1','1','1','92212181467097686','0');
INSERT INTO `rlb_custom_program_log` VALUES ('366','3','Relay 6','R','6','2016-06-28 00:10:02','2016-06-28 00:11:02','1','2','1','92212181467097686','0');
INSERT INTO `rlb_custom_program_log` VALUES ('367','3','Pump 2','PS','2','2016-06-28 00:11:02','2016-06-28 00:21:02','1','3','1','92212181467097686','0');
INSERT INTO `rlb_custom_program_log` VALUES ('368','1','Valve 0','V','0','2016-06-28 03:55:24','2016-06-28 03:56:24','1','1','2','38750151467111324','0');
INSERT INTO `rlb_custom_program_log` VALUES ('369','1','Valve 3','V','3','2016-06-28 03:57:02','2016-06-28 03:58:02','1','2','2','38750151467111324','0');
INSERT INTO `rlb_custom_program_log` VALUES ('370','1','Valve 4','V','4','2016-06-28 03:58:03','2016-06-28 03:59:03','1','3','1','38750151467111324','0');
INSERT INTO `rlb_custom_program_log` VALUES ('371','1','Valve 4','V','4','2016-06-28 04:00:02','2016-06-28 04:01:02','1','4','2','38750151467111324','0');
INSERT INTO `rlb_custom_program_log` VALUES ('372','1','Valve 5','V','5','2016-06-28 04:01:04','2016-06-28 04:02:04','1','5','2','38750151467111324','0');
INSERT INTO `rlb_custom_program_log` VALUES ('373','1','Valve 5','V','5','2016-06-28 04:03:04','2016-06-28 04:04:04','1','6','1','38750151467111324','0');
INSERT INTO `rlb_custom_program_log` VALUES ('374','1','Valve 6','V','6','2016-06-28 04:03:05','2016-06-28 04:04:05','1','6','1','38750151467111324','0');
INSERT INTO `rlb_custom_program_log` VALUES ('375','1','Valve 6','V','6','2016-06-28 04:03:05','2016-06-28 04:04:05','1','6','1','38750151467111324','0');
INSERT INTO `rlb_custom_program_log` VALUES ('376','1','Pump 1','PS','1','2016-06-28 04:04:05','2016-06-28 05:04:05','1','7','1','38750151467111324','0');
INSERT INTO `rlb_custom_program_log` VALUES ('377','1','Pump 2','PS','2','2016-06-28 04:04:06','2016-06-28 04:59:06','1','7','1','38750151467111324','0');
INSERT INTO `rlb_custom_program_log` VALUES ('378','1','Relay 15','R','15','2016-06-28 04:04:06','2016-06-28 04:59:06','1','7','1','38750151467111324','0');
INSERT INTO `rlb_custom_program_log` VALUES ('379','1','Power Center 0','P','0','2016-06-28 04:04:06','2016-06-28 04:59:06','1','7','1','38750151467111324','0');
INSERT INTO `rlb_custom_program_log` VALUES ('380','1','Pump 1','PS','1','2016-06-28 04:04:05','2016-06-28 05:04:05','1','7','1','38750151467111324','0');
INSERT INTO `rlb_custom_program_log` VALUES ('381','1','Valve 3','V','3','2016-06-28 05:05:07','2016-06-28 05:06:07','1','1','2','38750151467111324','1');
INSERT INTO `rlb_custom_program_log` VALUES ('382','1','Valve 0','V','0','2016-06-28 05:05:45','2016-06-28 05:06:45','1','1','2','64857141467115539','0');
INSERT INTO `rlb_custom_program_log` VALUES ('383','1','Valve 3','V','3','2016-06-28 05:07:04','2016-06-28 05:08:04','1','2','2','64857141467115539','0');
INSERT INTO `rlb_custom_program_log` VALUES ('384','1','Valve 4','V','4','2016-06-28 05:09:06','2016-06-28 05:10:06','1','3','1','64857141467115539','0');
INSERT INTO `rlb_custom_program_log` VALUES ('385','1','Valve 4','V','4','2016-06-28 05:11:04','2016-06-28 05:12:04','1','4','2','64857141467115539','0');
INSERT INTO `rlb_custom_program_log` VALUES ('386','1','Valve 5','V','5','2016-06-28 05:13:04','2016-06-28 05:14:04','1','5','2','64857141467115539','0');
INSERT INTO `rlb_custom_program_log` VALUES ('387','1','Valve 5','V','5','2016-06-28 05:15:07','2016-06-28 05:16:07','1','6','1','64857141467115539','0');
INSERT INTO `rlb_custom_program_log` VALUES ('388','1','Valve 6','V','6','2016-06-28 05:15:07','2016-06-28 05:16:07','1','6','1','64857141467115539','0');
INSERT INTO `rlb_custom_program_log` VALUES ('389','1','Valve 6','V','6','2016-06-28 05:15:07','2016-06-28 05:16:07','1','6','1','64857141467115539','0');
INSERT INTO `rlb_custom_program_log` VALUES ('390','1','Pump 1','PS','1','2016-06-28 05:17:07','2016-06-28 06:17:07','1','7','1','64857141467115539','0');
INSERT INTO `rlb_custom_program_log` VALUES ('391','1','Pump 2','PS','2','2016-06-28 05:17:09','2016-06-28 06:12:09','1','7','1','64857141467115539','0');
INSERT INTO `rlb_custom_program_log` VALUES ('392','1','Pump 2','PS','2','2016-06-28 05:17:09','2016-06-28 06:12:09','1','7','1','64857141467115539','0');
INSERT INTO `rlb_custom_program_log` VALUES ('393','1','Relay 15','R','15','2016-06-28 05:17:10','2016-06-28 06:12:10','1','7','1','64857141467115539','0');
INSERT INTO `rlb_custom_program_log` VALUES ('394','1','Power Center 0','P','0','2016-06-28 05:17:11','2016-06-28 06:12:11','1','7','1','64857141467115539','0');
INSERT INTO `rlb_custom_program_log` VALUES ('395','1','Valve 3','V','3','2016-06-28 05:48:02','2016-06-28 05:49:02','1','1','2','64857141467115539','1');
INSERT INTO `rlb_custom_program_log` VALUES ('396','1','Valve 4','V','4','2016-06-28 05:50:01','2016-06-28 05:51:01','1','4','2','64857141467115539','1');
INSERT INTO `rlb_custom_program_log` VALUES ('397','1','Valve 5','V','5','2016-06-28 05:51:03','2016-06-28 05:52:03','1','5','2','64857141467115539','1');
INSERT INTO `rlb_custom_program_log` VALUES ('398','1','Valve 0','V','0','2016-06-28 05:54:32','2016-06-28 05:55:32','1','1','2','63858771467118470','0');
INSERT INTO `rlb_custom_program_log` VALUES ('399','1','Valve 3','V','3','2016-06-28 05:56:03','2016-06-28 05:57:03','1','1','2','63858771467118470','1');
INSERT INTO `rlb_custom_program_log` VALUES ('400','1','Valve 4','V','4','2016-06-28 05:57:05','2016-06-28 05:58:05','1','4','2','63858771467118470','1');
INSERT INTO `rlb_custom_program_log` VALUES ('401','1','Valve 5','V','5','2016-06-28 05:59:02','2016-06-28 06:00:02','1','5','2','63858771467118470','1');
INSERT INTO `rlb_custom_program_log` VALUES ('402','1','Valve 0','V','0','2016-06-28 23:30:22','2016-06-28 23:31:22','1','1','2','27214981467181822','0');
INSERT INTO `rlb_custom_program_log` VALUES ('403','1','Valve 3','V','3','2016-06-28 23:32:02','2016-06-28 23:33:02','1','2','2','27214981467181822','0');
INSERT INTO `rlb_custom_program_log` VALUES ('404','1','Valve 4','V','4','2016-06-28 23:33:02','2016-06-28 23:34:02','1','3','1','27214981467181822','0');
INSERT INTO `rlb_custom_program_log` VALUES ('405','1','Valve 4','V','4','2016-06-28 23:34:02','2016-06-28 23:35:02','1','4','2','27214981467181822','0');
INSERT INTO `rlb_custom_program_log` VALUES ('406','1','Valve 5','V','5','2016-06-28 23:35:02','2016-06-28 23:36:02','1','5','2','27214981467181822','0');
INSERT INTO `rlb_custom_program_log` VALUES ('407','1','Valve 5','V','5','2016-06-28 23:36:02','2016-06-28 23:37:02','1','6','1','27214981467181822','0');
INSERT INTO `rlb_custom_program_log` VALUES ('408','1','Valve 6','V','6','2016-06-28 23:36:02','2016-06-28 23:37:02','1','6','1','27214981467181822','0');
INSERT INTO `rlb_custom_program_log` VALUES ('409','1','Valve 6','V','6','2016-06-28 23:36:02','2016-06-28 23:37:02','1','6','1','27214981467181822','0');
INSERT INTO `rlb_custom_program_log` VALUES ('410','1','Pump 1','PS','1','2016-06-28 23:37:03','2016-06-29 00:37:03','1','7','1','27214981467181822','0');
INSERT INTO `rlb_custom_program_log` VALUES ('411','1','Pump 2','PS','2','2016-06-28 23:37:03','2016-06-29 00:32:03','1','7','1','27214981467181822','0');
INSERT INTO `rlb_custom_program_log` VALUES ('412','1','Pump 2','PS','2','2016-06-28 23:37:03','2016-06-29 00:32:03','1','7','1','27214981467181822','0');
INSERT INTO `rlb_custom_program_log` VALUES ('413','1','Relay 15','R','15','2016-06-28 23:37:03','2016-06-29 00:32:03','1','7','1','27214981467181822','0');
INSERT INTO `rlb_custom_program_log` VALUES ('414','1','Power Center 0','P','0','2016-06-28 23:37:03','2016-06-29 00:32:03','1','7','1','27214981467181822','0');
INSERT INTO `rlb_custom_program_log` VALUES ('415','1','Valve 0','V','0','2016-06-28 23:44:02','2016-06-28 23:45:02','1','1','2','27214981467181822','1');
INSERT INTO `rlb_custom_program_log` VALUES ('416','1','Valve 4','V','4','2016-06-28 23:45:02','2016-06-28 23:46:02','1','3','1','27214981467181822','1');
INSERT INTO `rlb_custom_program_log` VALUES ('417','1','Valve 5','V','5','2016-06-28 23:46:02','2016-06-28 23:47:02','1','5','2','27214981467181822','1');
INSERT INTO `rlb_custom_program_log` VALUES ('418','1','Valve 0','V','0','2016-06-28 23:56:03','2016-06-28 23:57:03','1','1','2','45611421467183358','0');
INSERT INTO `rlb_custom_program_log` VALUES ('419','1','Valve 0','V','0','2016-06-28 23:57:02','2016-06-28 23:58:02','1','1','2','45611421467183358','1');
INSERT INTO `rlb_custom_program_log` VALUES ('420','1','Valve 4','V','4','2016-06-28 23:58:02','2016-06-28 23:59:02','1','3','1','45611421467183358','1');
INSERT INTO `rlb_custom_program_log` VALUES ('421','1','Valve 0','V','0','2016-06-29 00:12:20','2016-06-29 00:13:20','1','1','2','99825831467184338','0');
INSERT INTO `rlb_custom_program_log` VALUES ('422','1','Valve 0','V','0','2016-06-29 00:14:03','2016-06-29 00:15:03','1','1','2','99825831467184338','1');
INSERT INTO `rlb_custom_program_log` VALUES ('423','1','Valve 4','V','4','2016-06-29 00:15:05','2016-06-29 00:16:05','1','3','1','99825831467184338','1');
INSERT INTO `rlb_custom_program_log` VALUES ('424','1','Valve 0','V','0','2016-06-29 11:35:20','2016-06-29 11:36:20','1','1','2','30920031467225320','0');
INSERT INTO `rlb_custom_program_log` VALUES ('425','1','Valve 3','V','3','2016-06-29 11:37:02','2016-06-29 11:38:02','1','2','2','30920031467225320','0');
INSERT INTO `rlb_custom_program_log` VALUES ('426','1','Valve 4','V','4','2016-06-29 11:38:02','2016-06-29 11:39:02','1','3','1','30920031467225320','0');
INSERT INTO `rlb_custom_program_log` VALUES ('427','1','Valve 4','V','4','2016-06-29 11:39:02','2016-06-29 11:40:02','1','4','2','30920031467225320','0');
INSERT INTO `rlb_custom_program_log` VALUES ('428','1','Valve 5','V','5','2016-06-29 11:40:02','2016-06-29 11:41:02','1','5','2','30920031467225320','0');
INSERT INTO `rlb_custom_program_log` VALUES ('429','1','Valve 5','V','5','2016-06-29 11:42:02','2016-06-29 11:43:02','1','6','1','30920031467225320','0');
INSERT INTO `rlb_custom_program_log` VALUES ('430','1','Valve 6','V','6','2016-06-29 11:42:02','2016-06-29 11:43:02','1','6','1','30920031467225320','0');
INSERT INTO `rlb_custom_program_log` VALUES ('431','1','Valve 6','V','6','2016-06-29 11:42:02','2016-06-29 11:43:02','1','6','1','30920031467225320','0');
INSERT INTO `rlb_custom_program_log` VALUES ('432','1','Valve 0','V','0','2016-06-29 12:19:16','2016-06-29 12:20:16','1','1','2','58825661467227955','0');
INSERT INTO `rlb_custom_program_log` VALUES ('433','1','Valve 3','V','3','2016-06-29 12:21:02','2016-06-29 12:22:02','1','2','2','58825661467227955','0');
INSERT INTO `rlb_custom_program_log` VALUES ('434','1','Valve 4','V','4','2016-06-29 12:22:02','2016-06-29 12:23:02','1','3','1','58825661467227955','0');
INSERT INTO `rlb_custom_program_log` VALUES ('435','1','Valve 4','V','4','2016-06-29 12:24:02','2016-06-29 12:25:02','1','4','2','58825661467227955','0');
INSERT INTO `rlb_custom_program_log` VALUES ('436','1','Valve 5','V','5','2016-06-29 12:25:02','2016-06-29 12:26:02','1','5','2','58825661467227955','0');
INSERT INTO `rlb_custom_program_log` VALUES ('437','1','Valve 5','V','5','2016-06-29 12:26:02','2016-06-29 12:27:02','1','6','1','58825661467227955','0');
INSERT INTO `rlb_custom_program_log` VALUES ('438','1','Valve 6','V','6','2016-06-29 12:26:02','2016-06-29 12:27:02','1','6','1','58825661467227955','0');
INSERT INTO `rlb_custom_program_log` VALUES ('439','1','Valve 6','V','6','2016-06-29 12:26:02','2016-06-29 12:27:02','1','6','1','58825661467227955','0');
INSERT INTO `rlb_custom_program_log` VALUES ('440','3','Relay 6','R','6','2016-06-30 02:56:58','2016-06-30 03:46:58','1','1','2','98660791467280618','0');
INSERT INTO `rlb_custom_program_log` VALUES ('441','3','Relay 6','R','6','2016-06-30 03:06:38','2016-06-30 03:56:38','1','1','1','57628541467281198','0');
INSERT INTO `rlb_custom_program_log` VALUES ('442','3','Relay 6','R','6','2016-06-30 03:39:51','2016-06-30 04:29:51','1','1','1','11321601467283190','0');
INSERT INTO `rlb_custom_program_log` VALUES ('443','3','Relay 6','R','6','2016-06-30 03:51:04','2016-06-30 04:41:04','1','1','1','35759981467283863','0');
INSERT INTO `rlb_custom_program_log` VALUES ('444','3','Power Center 0','P','0','2016-07-01 04:48:33','2016-07-01 04:53:33','1','1','1','23000391467373713','0');
INSERT INTO `rlb_custom_program_log` VALUES ('445','3','Power Center 0','P','0','2016-07-01 04:51:52','2016-07-01 04:56:52','1','1','1','38239441467373911','0');
INSERT INTO `rlb_custom_program_log` VALUES ('446','3','Power Center 0','P','0','2016-07-01 05:01:59','2016-07-01 05:06:59','1','1','1','51413011467374516','0');
INSERT INTO `rlb_custom_program_log` VALUES ('447','3','Power Center 0','P','0','2016-07-01 05:27:02','2016-07-01 05:32:02','1','1','1','38060461467375971','0');
INSERT INTO `rlb_custom_program_log` VALUES ('448','3','Power Center 0','P','0','2016-07-01 05:29:02','2016-07-01 05:34:02','1','1','1','13783261467376089','0');
INSERT INTO `rlb_custom_program_log` VALUES ('449','3','Power Center 0','P','0','2016-07-01 05:30:02','2016-07-01 05:35:02','1','1','1','86180371467376179','0');
INSERT INTO `rlb_custom_program_log` VALUES ('450','3','Power Center 0','P','0','2016-07-01 05:31:31','2016-07-01 05:36:31','1','1','1','59263441467376291','0');
INSERT INTO `rlb_custom_program_log` VALUES ('451','3','Power Center 0','P','0','2016-07-01 05:35:19','2016-07-01 05:40:19','1','1','1','98779241467376519','0');
INSERT INTO `rlb_custom_program_log` VALUES ('452','3','Power Center 0','P','0','2016-07-01 05:40:08','2016-07-01 05:45:08','1','1','1','51074111467376807','0');
INSERT INTO `rlb_custom_program_log` VALUES ('453','3','Relay 14','R','14','2016-07-01 05:46:04','2016-07-01 05:51:04','1','2','1','51074111467376807','0');
INSERT INTO `rlb_custom_program_log` VALUES ('454','3','Power Center 0','P','0','2016-07-01 05:54:08','2016-07-01 05:59:08','1','1','1','82163291467377647','0');
INSERT INTO `rlb_custom_program_log` VALUES ('455','3','Relay 14','R','14','2016-07-01 06:00:02','2016-07-01 06:05:02','1','2','1','82163291467377647','0');
INSERT INTO `rlb_custom_program_log` VALUES ('456','3','Power Center 0','P','0','2016-07-01 06:06:34','2016-07-01 06:11:34','1','1','1','49183781467378394','0');
INSERT INTO `rlb_custom_program_log` VALUES ('457','3','Power Center 0','P','0','2016-07-01 06:09:52','2016-07-01 06:14:52','1','1','1','93484431467378588','0');
INSERT INTO `rlb_custom_program_log` VALUES ('458','3','Power Center 0','P','0','2016-07-01 06:13:39','2016-07-01 06:18:39','1','1','1','47923751467378818','0');
INSERT INTO `rlb_custom_program_log` VALUES ('459','3','Power Center 0','P','0','2016-07-01 06:21:28','2016-07-01 06:26:28','1','1','1','60495551467379286','0');
INSERT INTO `rlb_custom_program_log` VALUES ('460','45','Valve 5','V','5','2016-07-01 08:52:24','2016-07-01 08:53:24','1','1','1','98195001467388342','0');
INSERT INTO `rlb_custom_program_log` VALUES ('461','45','Valve 6','V','6','2016-07-01 08:54:04','2016-07-01 08:55:04','1','2','1','98195001467388342','0');
INSERT INTO `rlb_custom_program_log` VALUES ('462','45','Valve 2','V','2','2016-07-01 08:54:05','2016-07-01 08:55:05','1','2','2','98195001467388342','0');
INSERT INTO `rlb_custom_program_log` VALUES ('463','45','Valve 2','V','2','2016-07-01 08:54:05','2016-07-01 08:55:05','1','2','2','98195001467388342','0');
INSERT INTO `rlb_custom_program_log` VALUES ('464','45','Valve 0','V','0','2016-07-01 08:56:02','2016-07-01 08:57:02','1','3','2','98195001467388342','0');
INSERT INTO `rlb_custom_program_log` VALUES ('465','45','Valve 3','V','3','2016-07-01 08:56:02','2016-07-01 08:57:02','1','3','2','98195001467388342','0');
INSERT INTO `rlb_custom_program_log` VALUES ('466','45','Valve 3','V','3','2016-07-01 08:56:02','2016-07-01 08:57:02','1','3','2','98195001467388342','0');
INSERT INTO `rlb_custom_program_log` VALUES ('467','45','Valve 4','V','4','2016-07-01 08:57:02','2016-07-01 08:58:02','1','4','1','98195001467388342','0');
INSERT INTO `rlb_custom_program_log` VALUES ('468','45','Valve 5','V','5','2016-07-01 08:57:02','2016-07-01 08:58:02','1','4','2','98195001467388342','0');
INSERT INTO `rlb_custom_program_log` VALUES ('469','45','Valve 5','V','5','2016-07-01 08:57:02','2016-07-01 08:58:02','1','4','2','98195001467388342','0');
INSERT INTO `rlb_custom_program_log` VALUES ('470','45','Valve 4','V','4','2016-07-01 08:59:03','2016-07-01 09:00:03','1','5','2','98195001467388342','0');
INSERT INTO `rlb_custom_program_log` VALUES ('471','45','Pump 1','PS','1','2016-07-01 09:01:02','2016-07-01 10:01:02','1','6','1','98195001467388342','0');
INSERT INTO `rlb_custom_program_log` VALUES ('472','45','Pump 2','PS','2','2016-07-01 09:01:03','2016-07-01 09:16:03','1','6','1','98195001467388342','0');
INSERT INTO `rlb_custom_program_log` VALUES ('473','45','Pump 1','PS','1','2016-07-01 09:01:02','2016-07-01 10:01:02','1','6','1','98195001467388342','0');
INSERT INTO `rlb_custom_program_log` VALUES ('474','45','Valve 5','V','5','2016-07-01 10:01:07','2016-07-01 10:02:07','1','1','1','98195001467388342','1');
INSERT INTO `rlb_custom_program_log` VALUES ('475','45','Valve 2','V','2','2016-07-01 10:03:04','2016-07-01 10:04:04','1','2','2','98195001467388342','1');
INSERT INTO `rlb_custom_program_log` VALUES ('476','45','Valve 3','V','3','2016-07-01 10:05:05','2016-07-01 10:06:05','1','3','2','98195001467388342','1');
INSERT INTO `rlb_custom_program_log` VALUES ('477','45','Valve 4','V','4','2016-07-01 10:07:04','2016-07-01 10:08:04','1','4','1','98195001467388342','1');
INSERT INTO `rlb_custom_program_log` VALUES ('478','45','Valve 4','V','4','2016-07-01 10:09:02','2016-07-01 10:10:02','1','5','2','98195001467388342','1');
INSERT INTO `rlb_custom_program_log` VALUES ('479','45','Valve 5','V','5','2016-07-01 15:49:09','2016-07-01 15:50:09','1','1','1','19204361467413349','0');
INSERT INTO `rlb_custom_program_log` VALUES ('480','45','Valve 6','V','6','2016-07-01 15:51:06','2016-07-01 15:52:06','1','2','1','19204361467413349','0');
INSERT INTO `rlb_custom_program_log` VALUES ('481','45','Valve 2','V','2','2016-07-01 15:51:06','2016-07-01 15:52:06','1','2','2','19204361467413349','0');
INSERT INTO `rlb_custom_program_log` VALUES ('482','45','Valve 2','V','2','2016-07-01 15:51:06','2016-07-01 15:52:06','1','2','2','19204361467413349','0');
INSERT INTO `rlb_custom_program_log` VALUES ('483','45','Valve 0','V','0','2016-07-01 15:53:03','2016-07-01 15:54:03','1','3','2','19204361467413349','0');
INSERT INTO `rlb_custom_program_log` VALUES ('484','45','Valve 3','V','3','2016-07-01 15:53:03','2016-07-01 15:54:03','1','3','2','19204361467413349','0');
INSERT INTO `rlb_custom_program_log` VALUES ('485','45','Valve 3','V','3','2016-07-01 15:53:03','2016-07-01 15:54:03','1','3','2','19204361467413349','0');
INSERT INTO `rlb_custom_program_log` VALUES ('486','45','Valve 4','V','4','2016-07-01 15:54:07','2016-07-01 15:55:07','1','4','1','19204361467413349','0');
INSERT INTO `rlb_custom_program_log` VALUES ('487','45','Valve 5','V','5','2016-07-01 15:54:08','2016-07-01 15:55:08','1','4','2','19204361467413349','0');
INSERT INTO `rlb_custom_program_log` VALUES ('488','45','Valve 5','V','5','2016-07-01 15:54:08','2016-07-01 15:55:08','1','4','2','19204361467413349','0');
INSERT INTO `rlb_custom_program_log` VALUES ('489','45','Valve 4','V','4','2016-07-01 15:56:06','2016-07-01 15:57:06','1','5','2','19204361467413349','0');
INSERT INTO `rlb_custom_program_log` VALUES ('490','45','Pump 1','PS','1','2016-07-01 15:58:04','2016-07-01 16:58:04','1','6','1','19204361467413349','0');
INSERT INTO `rlb_custom_program_log` VALUES ('491','45','Pump 2','PS','2','2016-07-01 15:58:06','2016-07-01 16:13:06','1','6','1','19204361467413349','0');
INSERT INTO `rlb_custom_program_log` VALUES ('492','45','Pump 1','PS','1','2016-07-01 15:58:04','2016-07-01 16:58:04','1','6','1','19204361467413349','0');
INSERT INTO `rlb_custom_program_log` VALUES ('493','45','Valve 5','V','5','2016-07-01 16:54:39','2016-07-01 16:55:39','1','1','1','61622631467417278','0');
INSERT INTO `rlb_custom_program_log` VALUES ('494','45','Valve 6','V','6','2016-07-01 16:56:05','2016-07-01 16:57:05','1','2','1','61622631467417278','0');
INSERT INTO `rlb_custom_program_log` VALUES ('495','45','Valve 2','V','2','2016-07-01 16:56:05','2016-07-01 16:57:05','1','2','2','61622631467417278','0');
INSERT INTO `rlb_custom_program_log` VALUES ('496','45','Valve 2','V','2','2016-07-01 16:56:05','2016-07-01 16:57:05','1','2','2','61622631467417278','0');
INSERT INTO `rlb_custom_program_log` VALUES ('497','45','Valve 0','V','0','2016-07-01 16:58:02','2016-07-01 16:59:02','1','3','2','61622631467417278','0');
INSERT INTO `rlb_custom_program_log` VALUES ('498','45','Valve 3','V','3','2016-07-01 16:58:03','2016-07-01 16:59:03','1','3','2','61622631467417278','0');
INSERT INTO `rlb_custom_program_log` VALUES ('499','45','Valve 3','V','3','2016-07-01 16:58:03','2016-07-01 16:59:03','1','3','2','61622631467417278','0');
INSERT INTO `rlb_custom_program_log` VALUES ('500','45','Valve 4','V','4','2016-07-01 17:00:02','2016-07-01 17:01:02','1','4','1','61622631467417278','0');
INSERT INTO `rlb_custom_program_log` VALUES ('501','45','Valve 5','V','5','2016-07-01 17:00:02','2016-07-01 17:01:02','1','4','2','61622631467417278','0');
INSERT INTO `rlb_custom_program_log` VALUES ('502','45','Valve 5','V','5','2016-07-01 17:00:02','2016-07-01 17:01:02','1','4','2','61622631467417278','0');
INSERT INTO `rlb_custom_program_log` VALUES ('503','45','Valve 4','V','4','2016-07-01 17:01:02','2016-07-01 17:02:02','1','5','2','61622631467417278','0');
INSERT INTO `rlb_custom_program_log` VALUES ('504','45','Pump 1','PS','1','2016-07-01 17:02:03','2016-07-01 18:02:03','1','6','1','61622631467417278','0');
INSERT INTO `rlb_custom_program_log` VALUES ('505','45','Pump 2','PS','2','2016-07-01 17:02:03','2016-07-01 17:17:03','1','6','1','61622631467417278','0');
INSERT INTO `rlb_custom_program_log` VALUES ('506','45','Pump 2','PS','2','2016-07-01 17:02:03','2016-07-01 17:17:03','1','6','1','61622631467417278','0');
INSERT INTO `rlb_custom_program_log` VALUES ('507','45','Valve 5','V','5','2016-07-01 17:14:03','2016-07-01 17:15:03','1','1','1','61622631467417278','1');
INSERT INTO `rlb_custom_program_log` VALUES ('508','45','Valve 6','V','6','2016-07-01 17:15:03','2016-07-01 17:16:03','1','2','1','61622631467417278','1');
INSERT INTO `rlb_custom_program_log` VALUES ('509','6','Valve 1','V','1','2016-07-01 17:16:20','2016-07-01 17:17:20','1','1','2','17307761467418575','0');
INSERT INTO `rlb_custom_program_log` VALUES ('510','6','Valve 2','V','2','2016-07-01 17:16:21','2016-07-01 17:17:21','1','1','2','17307761467418575','0');
INSERT INTO `rlb_custom_program_log` VALUES ('511','6','Valve 2','V','2','2016-07-01 17:16:21','2016-07-01 17:17:21','1','1','2','17307761467418575','0');
INSERT INTO `rlb_custom_program_log` VALUES ('512','6','Valve 5','V','5','2016-07-01 17:18:02','2016-07-01 17:19:02','1','2','1','17307761467418575','0');
INSERT INTO `rlb_custom_program_log` VALUES ('513','6','Valve 6','V','6','2016-07-01 17:18:02','2016-07-01 17:19:02','1','2','1','17307761467418575','0');
INSERT INTO `rlb_custom_program_log` VALUES ('514','6','Valve 6','V','6','2016-07-01 17:18:02','2016-07-01 17:19:02','1','2','1','17307761467418575','0');
INSERT INTO `rlb_custom_program_log` VALUES ('515','6','Pump 2','PS','2','2016-07-01 17:19:02','2016-07-01 18:19:02','1','3','1','17307761467418575','0');
INSERT INTO `rlb_custom_program_log` VALUES ('516','6','Valve 6','V','6','2016-07-01 18:19:09','2016-07-01 18:20:09','1','1','1','17307761467418575','1');
INSERT INTO `rlb_custom_program_log` VALUES ('517','1','Valve 0','V','0','2016-07-04 13:45:04','2016-07-04 13:46:04','1','1','2','29662001467665104','0');
INSERT INTO `rlb_custom_program_log` VALUES ('518','6','Valve 1','V','1','2016-07-04 13:45:20','2016-07-04 13:46:20','1','1','2','76860221467665120','0');
INSERT INTO `rlb_custom_program_log` VALUES ('519','6','Valve 2','V','2','2016-07-04 13:45:21','2016-07-04 13:46:21','1','1','2','76860221467665120','0');
INSERT INTO `rlb_custom_program_log` VALUES ('520','6','Valve 2','V','2','2016-07-04 13:45:21','2016-07-04 13:46:21','1','1','2','76860221467665120','0');
INSERT INTO `rlb_custom_program_log` VALUES ('521','1','Valve 0','V','0','2016-07-04 13:46:02','2016-07-04 13:47:02','1','1','2','29662001467665104','1');
INSERT INTO `rlb_custom_program_log` VALUES ('522','1','Valve 0','V','0','2016-07-04 13:46:48','2016-07-04 13:47:48','1','1','2','86151471467665207','0');
INSERT INTO `rlb_custom_program_log` VALUES ('523','6','Valve 6','V','6','2016-07-04 13:47:02','2016-07-04 13:48:02','1','1','1','76860221467665120','1');
INSERT INTO `rlb_custom_program_log` VALUES ('524','1','Valve 3','V','3','2016-07-04 13:48:02','2016-07-04 13:49:02','1','2','2','86151471467665207','0');
INSERT INTO `rlb_custom_program_log` VALUES ('525','1','Valve 4','V','4','2016-07-04 13:49:02','2016-07-04 13:50:02','1','3','1','86151471467665207','0');
INSERT INTO `rlb_custom_program_log` VALUES ('526','1','Valve 4','V','4','2016-07-04 13:50:02','2016-07-04 13:51:02','1','4','2','86151471467665207','0');
INSERT INTO `rlb_custom_program_log` VALUES ('527','1','Valve 5','V','5','2016-07-04 13:52:02','2016-07-04 13:53:02','1','5','2','86151471467665207','0');
INSERT INTO `rlb_custom_program_log` VALUES ('528','1','Valve 5','V','5','2016-07-04 13:53:02','2016-07-04 13:54:02','1','6','1','86151471467665207','0');
INSERT INTO `rlb_custom_program_log` VALUES ('529','1','Valve 6','V','6','2016-07-04 13:53:02','2016-07-04 13:54:02','1','6','1','86151471467665207','0');
INSERT INTO `rlb_custom_program_log` VALUES ('530','1','Valve 6','V','6','2016-07-04 13:53:02','2016-07-04 13:54:02','1','6','1','86151471467665207','0');
INSERT INTO `rlb_custom_program_log` VALUES ('531','1','Pump 2','PS','2','2016-07-04 13:54:04','2016-07-04 13:55:04','1','7','1','86151471467665207','0');
INSERT INTO `rlb_custom_program_log` VALUES ('532','1','Relay 15','R','15','2016-07-04 13:54:04','2016-07-04 14:49:04','1','7','1','86151471467665207','0');
INSERT INTO `rlb_custom_program_log` VALUES ('533','1','Power Center 0','P','0','2016-07-04 13:54:05','2016-07-04 14:49:05','1','7','1','86151471467665207','0');
INSERT INTO `rlb_custom_program_log` VALUES ('534','1','Valve 0','V','0','2016-07-04 13:57:02','2016-07-04 13:58:02','1','1','2','86151471467665207','1');
INSERT INTO `rlb_custom_program_log` VALUES ('535','1','Valve 4','V','4','2016-07-04 13:58:02','2016-07-04 13:59:02','1','3','1','86151471467665207','1');
INSERT INTO `rlb_custom_program_log` VALUES ('536','1','Valve 5','V','5','2016-07-04 14:00:03','2016-07-04 14:01:03','1','5','2','86151471467665207','1');
INSERT INTO `rlb_custom_program_log` VALUES ('537','45','Valve 5','V','5','2016-07-04 14:06:06','2016-07-04 14:07:06','1','1','1','47124181467666364','0');
INSERT INTO `rlb_custom_program_log` VALUES ('538','45','Valve 6','V','6','2016-07-04 14:08:01','2016-07-04 14:09:01','1','2','1','47124181467666364','0');
INSERT INTO `rlb_custom_program_log` VALUES ('539','45','Valve 2','V','2','2016-07-04 14:08:02','2016-07-04 14:09:02','1','2','2','47124181467666364','0');
INSERT INTO `rlb_custom_program_log` VALUES ('540','45','Valve 2','V','2','2016-07-04 14:08:02','2016-07-04 14:09:02','1','2','2','47124181467666364','0');
INSERT INTO `rlb_custom_program_log` VALUES ('541','45','Valve 0','V','0','2016-07-04 14:09:02','2016-07-04 14:10:02','1','3','2','47124181467666364','0');
INSERT INTO `rlb_custom_program_log` VALUES ('542','45','Valve 3','V','3','2016-07-04 14:09:02','2016-07-04 14:10:02','1','3','2','47124181467666364','0');
INSERT INTO `rlb_custom_program_log` VALUES ('543','45','Valve 3','V','3','2016-07-04 14:09:02','2016-07-04 14:10:02','1','3','2','47124181467666364','0');
INSERT INTO `rlb_custom_program_log` VALUES ('544','45','Valve 4','V','4','2016-07-04 14:11:02','2016-07-04 14:12:02','1','4','1','47124181467666364','0');
INSERT INTO `rlb_custom_program_log` VALUES ('545','45','Valve 5','V','5','2016-07-04 14:11:03','2016-07-04 14:12:03','1','4','2','47124181467666364','0');
INSERT INTO `rlb_custom_program_log` VALUES ('546','45','Valve 5','V','5','2016-07-04 14:11:03','2016-07-04 14:12:03','1','4','2','47124181467666364','0');
INSERT INTO `rlb_custom_program_log` VALUES ('547','45','Valve 4','V','4','2016-07-04 14:13:02','2016-07-04 14:14:02','1','5','2','47124181467666364','0');
INSERT INTO `rlb_custom_program_log` VALUES ('548','45','Pump 1','PS','1','2016-07-04 14:14:02','2016-07-04 15:14:02','1','6','1','47124181467666364','0');
INSERT INTO `rlb_custom_program_log` VALUES ('549','45','Pump 2','PS','2','2016-07-04 14:14:03','2016-07-04 14:29:03','1','6','1','47124181467666364','0');
INSERT INTO `rlb_custom_program_log` VALUES ('550','45','Pump 1','PS','1','2016-07-04 14:14:02','2016-07-04 15:14:02','1','6','1','47124181467666364','0');
INSERT INTO `rlb_custom_program_log` VALUES ('551','45','Valve 5','V','5','2016-07-04 14:31:02','2016-07-04 14:32:02','1','1','1','47124181467666364','1');
INSERT INTO `rlb_custom_program_log` VALUES ('552','45','Valve 2','V','2','2016-07-04 14:32:02','2016-07-04 14:33:02','1','2','2','47124181467666364','1');
INSERT INTO `rlb_custom_program_log` VALUES ('553','45','Valve 3','V','3','2016-07-04 14:33:02','2016-07-04 14:34:02','1','3','2','47124181467666364','1');
INSERT INTO `rlb_custom_program_log` VALUES ('554','45','Valve 4','V','4','2016-07-04 14:35:03','2016-07-04 14:36:03','1','4','1','47124181467666364','1');
INSERT INTO `rlb_custom_program_log` VALUES ('555','45','Valve 4','V','4','2016-07-04 14:37:02','2016-07-04 14:38:02','1','5','2','47124181467666364','1');
INSERT INTO `rlb_custom_program_log` VALUES ('556','1','Valve 0','V','0','2016-07-04 14:38:09','2016-07-04 14:39:09','1','1','2','92299561467668288','0');
INSERT INTO `rlb_custom_program_log` VALUES ('557','1','Valve 3','V','3','2016-07-04 14:40:02','2016-07-04 14:41:02','1','2','2','92299561467668288','0');
INSERT INTO `rlb_custom_program_log` VALUES ('558','1','Valve 4','V','4','2016-07-04 14:42:02','2016-07-04 14:43:02','1','3','1','92299561467668288','0');
INSERT INTO `rlb_custom_program_log` VALUES ('559','1','Valve 4','V','4','2016-07-04 14:43:02','2016-07-04 14:44:02','1','4','2','92299561467668288','0');
INSERT INTO `rlb_custom_program_log` VALUES ('560','1','Valve 5','V','5','2016-07-04 14:45:03','2016-07-04 14:46:03','1','5','2','92299561467668288','0');
INSERT INTO `rlb_custom_program_log` VALUES ('561','1','Valve 5','V','5','2016-07-04 14:47:02','2016-07-04 14:48:02','1','6','1','92299561467668288','0');
INSERT INTO `rlb_custom_program_log` VALUES ('562','1','Valve 6','V','6','2016-07-04 14:47:02','2016-07-04 14:48:02','1','6','1','92299561467668288','0');
INSERT INTO `rlb_custom_program_log` VALUES ('563','1','Valve 6','V','6','2016-07-04 14:47:02','2016-07-04 14:48:02','1','6','1','92299561467668288','0');
INSERT INTO `rlb_custom_program_log` VALUES ('564','1','Pump 2','PS','2','2016-07-04 14:48:02','2016-07-04 14:49:02','1','7','1','92299561467668288','0');
INSERT INTO `rlb_custom_program_log` VALUES ('565','6','Valve 1','V','1','2016-07-04 14:58:24','2016-07-04 14:59:24','1','1','2','18022111467669503','0');
INSERT INTO `rlb_custom_program_log` VALUES ('566','6','Valve 2','V','2','2016-07-04 14:58:24','2016-07-04 14:59:24','1','1','2','18022111467669503','0');
INSERT INTO `rlb_custom_program_log` VALUES ('567','6','Valve 2','V','2','2016-07-04 14:58:24','2016-07-04 14:59:24','1','1','2','18022111467669503','0');
INSERT INTO `rlb_custom_program_log` VALUES ('568','6','Valve 5','V','5','2016-07-04 15:00:03','2016-07-04 15:01:03','1','2','1','18022111467669503','0');
INSERT INTO `rlb_custom_program_log` VALUES ('569','6','Valve 6','V','6','2016-07-04 15:00:04','2016-07-04 15:01:04','1','2','1','18022111467669503','0');
INSERT INTO `rlb_custom_program_log` VALUES ('570','6','Valve 6','V','6','2016-07-04 15:00:04','2016-07-04 15:01:04','1','2','1','18022111467669503','0');
INSERT INTO `rlb_custom_program_log` VALUES ('571','1','Relay 15','R','15','2016-07-04 14:48:02','2016-07-04 15:43:02','1','7','1','92299561467668288','0');
INSERT INTO `rlb_custom_program_log` VALUES ('572','1','Power Center 0','P','0','2016-07-04 14:48:02','2016-07-04 15:43:02','1','7','1','92299561467668288','0');
INSERT INTO `rlb_custom_program_log` VALUES ('573','1','Valve 0','V','0','2016-07-04 15:04:02','2016-07-04 15:05:02','1','1','2','92299561467668288','1');
INSERT INTO `rlb_custom_program_log` VALUES ('574','1','Valve 4','V','4','2016-07-04 15:05:02','2016-07-04 15:06:02','1','3','1','92299561467668288','1');
INSERT INTO `rlb_custom_program_log` VALUES ('575','1','Valve 5','V','5','2016-07-04 15:06:02','2016-07-04 15:07:02','1','5','2','92299561467668288','1');
INSERT INTO `rlb_custom_program_log` VALUES ('576','6','Pump 2','PS','2','2016-07-04 15:02:03','2016-07-04 16:02:03','1','3','1','18022111467669503','0');
INSERT INTO `rlb_custom_program_log` VALUES ('577','6','Valve 6','V','6','2016-07-04 15:40:02','2016-07-04 15:41:02','1','1','1','18022111467669503','1');
INSERT INTO `rlb_custom_program_log` VALUES ('578','6','Valve 1','V','1','2016-07-04 20:34:45','2016-07-04 20:35:45','1','1','2','66557401467689685','0');
INSERT INTO `rlb_custom_program_log` VALUES ('579','6','Valve 2','V','2','2016-07-04 20:34:46','2016-07-04 20:35:46','1','1','2','66557401467689685','0');
INSERT INTO `rlb_custom_program_log` VALUES ('580','6','Valve 2','V','2','2016-07-04 20:34:46','2016-07-04 20:35:46','1','1','2','66557401467689685','0');
INSERT INTO `rlb_custom_program_log` VALUES ('581','6','Valve 5','V','5','2016-07-04 20:36:02','2016-07-04 20:37:02','1','2','1','66557401467689685','0');
INSERT INTO `rlb_custom_program_log` VALUES ('582','6','Valve 6','V','6','2016-07-04 20:36:02','2016-07-04 20:37:02','1','2','1','66557401467689685','0');
INSERT INTO `rlb_custom_program_log` VALUES ('583','6','Valve 6','V','6','2016-07-04 20:36:02','2016-07-04 20:37:02','1','2','1','66557401467689685','0');
INSERT INTO `rlb_custom_program_log` VALUES ('584','6','Pump 2','PS','2','2016-07-04 20:38:02','2016-07-04 21:38:02','1','3','1','66557401467689685','0');
INSERT INTO `rlb_custom_program_log` VALUES ('585','6','Valve 6','V','6','2016-07-04 21:38:02','2016-07-04 21:39:02','1','1','1','66557401467689685','1');
INSERT INTO `rlb_custom_program_log` VALUES ('586','6','Valve 1','V','1','2016-07-04 22:08:56','2016-07-04 22:09:56','1','1','2','79526881467695335','0');
INSERT INTO `rlb_custom_program_log` VALUES ('587','6','Valve 2','V','2','2016-07-04 22:08:56','2016-07-04 22:09:56','1','1','2','79526881467695335','0');
INSERT INTO `rlb_custom_program_log` VALUES ('588','6','Valve 2','V','2','2016-07-04 22:08:56','2016-07-04 22:09:56','1','1','2','79526881467695335','0');
INSERT INTO `rlb_custom_program_log` VALUES ('589','6','Valve 5','V','5','2016-07-04 22:10:02','2016-07-04 22:11:02','1','2','1','79526881467695335','0');
INSERT INTO `rlb_custom_program_log` VALUES ('590','6','Valve 6','V','6','2016-07-04 22:10:02','2016-07-04 22:11:02','1','2','1','79526881467695335','0');
INSERT INTO `rlb_custom_program_log` VALUES ('591','6','Valve 6','V','6','2016-07-04 22:10:02','2016-07-04 22:11:02','1','2','1','79526881467695335','0');
INSERT INTO `rlb_custom_program_log` VALUES ('592','6','Pump 2','PS','2','2016-07-04 22:11:03','2016-07-04 23:11:03','1','3','1','79526881467695335','0');
INSERT INTO `rlb_custom_program_log` VALUES ('593','6','Valve 6','V','6','2016-07-04 23:12:02','2016-07-04 23:13:02','1','1','1','79526881467695335','1');
INSERT INTO `rlb_custom_program_log` VALUES ('594','1','Valve 0','V','0','2016-07-06 17:12:53','2016-07-06 17:13:53','1','1','2','74724021467850373','0');
INSERT INTO `rlb_custom_program_log` VALUES ('595','1','Valve 3','V','3','2016-07-06 17:14:02','2016-07-06 17:15:02','1','2','2','74724021467850373','0');
INSERT INTO `rlb_custom_program_log` VALUES ('596','1','Valve 4','V','4','2016-07-06 17:15:02','2016-07-06 17:16:02','1','3','1','74724021467850373','0');
INSERT INTO `rlb_custom_program_log` VALUES ('597','1','Valve 4','V','4','2016-07-06 17:16:02','2016-07-06 17:17:02','1','4','2','74724021467850373','0');
INSERT INTO `rlb_custom_program_log` VALUES ('598','1','Valve 5','V','5','2016-07-06 17:17:02','2016-07-06 17:18:02','1','5','2','74724021467850373','0');
INSERT INTO `rlb_custom_program_log` VALUES ('599','1','Valve 5','V','5','2016-07-06 17:18:02','2016-07-06 17:19:02','1','6','1','74724021467850373','0');
INSERT INTO `rlb_custom_program_log` VALUES ('600','1','Valve 6','V','6','2016-07-06 17:18:02','2016-07-06 17:19:02','1','6','1','74724021467850373','0');
INSERT INTO `rlb_custom_program_log` VALUES ('601','1','Valve 6','V','6','2016-07-06 17:18:02','2016-07-06 17:19:02','1','6','1','74724021467850373','0');
INSERT INTO `rlb_custom_program_log` VALUES ('602','1','Pump 2','PS','2','2016-07-06 17:19:03','2016-07-06 17:20:03','1','7','1','74724021467850373','0');
INSERT INTO `rlb_custom_program_log` VALUES ('603','1','Relay 15','R','15','2016-07-06 17:19:03','2016-07-06 18:14:03','1','7','1','74724021467850373','0');
INSERT INTO `rlb_custom_program_log` VALUES ('604','1','Power Center 0','P','0','2016-07-06 17:19:03','2016-07-06 18:14:03','1','7','1','74724021467850373','0');
INSERT INTO `rlb_custom_program_log` VALUES ('605','1','Valve 4','V','4','2016-07-06 17:21:02','2016-07-06 17:22:02','1','1','1','74724021467850373','1');
INSERT INTO `rlb_custom_program_log` VALUES ('606','6','Valve 1','V','1','2016-07-06 17:20:43','2016-07-06 17:21:43','1','1','2','82987981467850842','0');
INSERT INTO `rlb_custom_program_log` VALUES ('607','6','Valve 2','V','2','2016-07-06 17:20:43','2016-07-06 17:21:43','1','1','2','82987981467850842','0');
INSERT INTO `rlb_custom_program_log` VALUES ('608','6','Valve 2','V','2','2016-07-06 17:20:43','2016-07-06 17:21:43','1','1','2','82987981467850842','0');
INSERT INTO `rlb_custom_program_log` VALUES ('609','1','Valve 6','V','6','2016-07-06 17:22:03','2016-07-06 17:23:03','1','6','1','74724021467850373','1');
INSERT INTO `rlb_custom_program_log` VALUES ('610','6','Valve 5','V','5','2016-07-06 17:22:04','2016-07-06 17:23:04','1','2','1','82987981467850842','0');
INSERT INTO `rlb_custom_program_log` VALUES ('611','6','Valve 6','V','6','2016-07-06 17:22:04','2016-07-06 17:23:04','1','2','1','82987981467850842','0');
INSERT INTO `rlb_custom_program_log` VALUES ('612','6','Valve 6','V','6','2016-07-06 17:22:04','2016-07-06 17:23:04','1','2','1','82987981467850842','0');
INSERT INTO `rlb_custom_program_log` VALUES ('613','45','Valve 5','V','5','2016-07-07 10:36:50','2016-07-07 10:37:50','1','1','1','46924031467913010','0');
INSERT INTO `rlb_custom_program_log` VALUES ('614','45','Valve 6','V','6','2016-07-07 10:38:03','2016-07-07 10:39:03','1','2','1','46924031467913010','0');
INSERT INTO `rlb_custom_program_log` VALUES ('615','45','Valve 2','V','2','2016-07-07 10:38:03','2016-07-07 10:39:03','1','2','2','46924031467913010','0');
INSERT INTO `rlb_custom_program_log` VALUES ('616','45','Valve 2','V','2','2016-07-07 10:38:03','2016-07-07 10:39:03','1','2','2','46924031467913010','0');
INSERT INTO `rlb_custom_program_log` VALUES ('617','45','Valve 0','V','0','2016-07-07 10:40:02','2016-07-07 10:41:02','1','3','2','46924031467913010','0');
INSERT INTO `rlb_custom_program_log` VALUES ('618','45','Valve 3','V','3','2016-07-07 10:40:02','2016-07-07 10:41:02','1','3','2','46924031467913010','0');
INSERT INTO `rlb_custom_program_log` VALUES ('619','45','Valve 3','V','3','2016-07-07 10:40:02','2016-07-07 10:41:02','1','3','2','46924031467913010','0');
INSERT INTO `rlb_custom_program_log` VALUES ('620','45','Valve 4','V','4','2016-07-07 10:41:02','2016-07-07 10:42:02','1','4','1','46924031467913010','0');
INSERT INTO `rlb_custom_program_log` VALUES ('621','45','Valve 5','V','5','2016-07-07 10:41:03','2016-07-07 10:42:03','1','4','2','46924031467913010','0');
INSERT INTO `rlb_custom_program_log` VALUES ('622','45','Valve 5','V','5','2016-07-07 10:41:03','2016-07-07 10:42:03','1','4','2','46924031467913010','0');
INSERT INTO `rlb_custom_program_log` VALUES ('623','45','Valve 4','V','4','2016-07-07 10:43:02','2016-07-07 10:44:02','1','5','2','46924031467913010','0');
INSERT INTO `rlb_custom_program_log` VALUES ('624','45','Pump 1','PS','1','2016-07-07 10:44:03','2016-07-07 11:44:03','1','6','1','46924031467913010','0');
INSERT INTO `rlb_custom_program_log` VALUES ('625','45','Pump 2','PS','2','2016-07-07 10:44:03','2016-07-07 10:59:03','1','6','1','46924031467913010','0');
INSERT INTO `rlb_custom_program_log` VALUES ('626','45','Pump 2','PS','2','2016-07-07 10:44:03','2016-07-07 10:59:03','1','6','1','46924031467913010','0');
INSERT INTO `rlb_custom_program_log` VALUES ('627','45','Valve 5','V','5','2016-07-07 10:48:02','2016-07-07 10:49:02','1','1','1','46924031467913010','1');
INSERT INTO `rlb_custom_program_log` VALUES ('628','45','Valve 2','V','2','2016-07-07 10:49:02','2016-07-07 10:50:02','1','2','2','46924031467913010','1');
INSERT INTO `rlb_custom_program_log` VALUES ('629','45','Valve 3','V','3','2016-07-07 10:50:02','2016-07-07 10:51:02','1','3','2','46924031467913010','1');
INSERT INTO `rlb_custom_program_log` VALUES ('630','45','Valve 5','V','5','2016-07-07 10:51:02','2016-07-07 10:52:02','1','4','2','46924031467913010','1');
INSERT INTO `rlb_custom_program_log` VALUES ('631','45','Valve 4','V','4','2016-07-07 10:52:02','2016-07-07 10:53:02','1','5','2','46924031467913010','1');
INSERT INTO `rlb_custom_program_log` VALUES ('632','1','Valve 0','V','0','2016-07-07 10:55:08','2016-07-07 10:56:08','1','1','2','73360801467914107','0');
INSERT INTO `rlb_custom_program_log` VALUES ('633','1','Valve 3','V','3','2016-07-07 10:57:02','2016-07-07 10:58:02','1','2','2','73360801467914107','0');
INSERT INTO `rlb_custom_program_log` VALUES ('634','1','Valve 4','V','4','2016-07-07 10:59:02','2016-07-07 11:00:02','1','3','1','73360801467914107','0');
INSERT INTO `rlb_custom_program_log` VALUES ('635','1','Valve 4','V','4','2016-07-07 11:00:02','2016-07-07 11:01:02','1','4','2','73360801467914107','0');
INSERT INTO `rlb_custom_program_log` VALUES ('636','1','Valve 5','V','5','2016-07-07 11:02:02','2016-07-07 11:03:02','1','5','2','73360801467914107','0');
INSERT INTO `rlb_custom_program_log` VALUES ('637','1','Valve 5','V','5','2016-07-07 11:03:02','2016-07-07 11:04:02','1','6','1','73360801467914107','0');
INSERT INTO `rlb_custom_program_log` VALUES ('638','1','Valve 6','V','6','2016-07-07 11:03:02','2016-07-07 11:04:02','1','6','1','73360801467914107','0');
INSERT INTO `rlb_custom_program_log` VALUES ('639','1','Valve 6','V','6','2016-07-07 11:03:02','2016-07-07 11:04:02','1','6','1','73360801467914107','0');
INSERT INTO `rlb_custom_program_log` VALUES ('640','1','Pump 2','PS','2','2016-07-07 11:04:02','2016-07-07 11:05:02','1','7','1','73360801467914107','0');
INSERT INTO `rlb_custom_program_log` VALUES ('641','6','Valve 1','V','1','2016-07-07 11:27:59','2016-07-07 11:28:59','1','1','2','38328531467916078','0');
INSERT INTO `rlb_custom_program_log` VALUES ('642','6','Valve 2','V','2','2016-07-07 11:27:59','2016-07-07 11:28:59','1','1','2','38328531467916078','0');
INSERT INTO `rlb_custom_program_log` VALUES ('643','6','Valve 2','V','2','2016-07-07 11:27:59','2016-07-07 11:28:59','1','1','2','38328531467916078','0');
INSERT INTO `rlb_custom_program_log` VALUES ('644','6','Valve 5','V','5','2016-07-07 11:29:02','2016-07-07 11:30:02','1','2','1','38328531467916078','0');
INSERT INTO `rlb_custom_program_log` VALUES ('645','6','Valve 6','V','6','2016-07-07 11:29:03','2016-07-07 11:30:03','1','2','1','38328531467916078','0');
INSERT INTO `rlb_custom_program_log` VALUES ('646','6','Valve 6','V','6','2016-07-07 11:29:03','2016-07-07 11:30:03','1','2','1','38328531467916078','0');
INSERT INTO `rlb_custom_program_log` VALUES ('647','6','Valve 5','V','5','2016-07-07 11:30:02','2016-07-07 11:31:02','1','1','1','38328531467916078','1');
INSERT INTO `rlb_custom_program_log` VALUES ('648','6','Valve 1','V','1','2016-07-07 11:50:18','2016-07-07 11:51:18','1','1','2','44421861467917418','0');
INSERT INTO `rlb_custom_program_log` VALUES ('649','6','Valve 2','V','2','2016-07-07 11:50:18','2016-07-07 11:51:18','1','1','2','44421861467917418','0');
INSERT INTO `rlb_custom_program_log` VALUES ('650','6','Valve 2','V','2','2016-07-07 11:50:18','2016-07-07 11:51:18','1','1','2','44421861467917418','0');
INSERT INTO `rlb_custom_program_log` VALUES ('651','6','Valve 5','V','5','2016-07-07 11:52:03','2016-07-07 11:53:03','1','2','1','44421861467917418','0');
INSERT INTO `rlb_custom_program_log` VALUES ('652','6','Valve 6','V','6','2016-07-07 11:52:03','2016-07-07 11:53:03','1','2','1','44421861467917418','0');
INSERT INTO `rlb_custom_program_log` VALUES ('653','6','Valve 6','V','6','2016-07-07 11:52:03','2016-07-07 11:53:03','1','2','1','44421861467917418','0');
INSERT INTO `rlb_custom_program_log` VALUES ('654','1','Relay 15','R','15','2016-07-07 11:04:02','2016-07-07 11:59:02','1','7','1','73360801467914107','0');
INSERT INTO `rlb_custom_program_log` VALUES ('655','1','Power Center 0','P','0','2016-07-07 11:04:04','2016-07-07 11:59:04','1','7','1','73360801467914107','0');
INSERT INTO `rlb_custom_program_log` VALUES ('656','1','Valve 4','V','4','2016-07-07 12:00:03','2016-07-07 12:01:03','1','1','1','73360801467914107','1');
INSERT INTO `rlb_custom_program_log` VALUES ('657','1','Valve 6','V','6','2016-07-07 12:02:02','2016-07-07 12:03:02','1','6','1','73360801467914107','1');
INSERT INTO `rlb_custom_program_log` VALUES ('658','6','Pump 2','PS','2','2016-07-07 11:54:03','2016-07-07 12:54:03','1','3','1','44421861467917418','0');
INSERT INTO `rlb_custom_program_log` VALUES ('659','6','Valve 5','V','5','2016-07-07 12:55:02','2016-07-07 12:56:02','1','1','1','44421861467917418','1');
INSERT INTO `rlb_custom_program_log` VALUES ('660','3','Valve 0','V','0','2016-07-07 16:01:29','2016-07-07 16:02:29','1','1','1','41662961467932488','0');
INSERT INTO `rlb_custom_program_log` VALUES ('661','3','Valve 4','V','4','2016-07-07 16:01:30','2016-07-07 16:02:30','1','1','1','41662961467932488','0');
INSERT INTO `rlb_custom_program_log` VALUES ('662','3','Valve 4','V','4','2016-07-07 16:01:30','2016-07-07 16:02:30','1','1','1','41662961467932488','0');
INSERT INTO `rlb_custom_program_log` VALUES ('663','3','Valve 0','V','0','2016-07-07 16:03:02','2016-07-07 16:04:02','1','2','2','41662961467932488','0');
INSERT INTO `rlb_custom_program_log` VALUES ('664','3','Valve 4','V','4','2016-07-07 16:04:02','2016-07-07 16:05:02','1','3','2','41662961467932488','0');
INSERT INTO `rlb_custom_program_log` VALUES ('665','3','Valve 5','V','5','2016-07-07 16:04:02','2016-07-07 16:05:02','1','3','2','41662961467932488','0');
INSERT INTO `rlb_custom_program_log` VALUES ('666','3','Valve 5','V','5','2016-07-07 16:04:02','2016-07-07 16:05:02','1','3','2','41662961467932488','0');
INSERT INTO `rlb_custom_program_log` VALUES ('667','3','Pump 1','PS','1','2016-07-07 16:05:02','2016-07-07 16:06:02','1','4','1','41662961467932488','0');
INSERT INTO `rlb_custom_program_log` VALUES ('668','3','Valve 0','V','0','2016-07-07 16:16:23','2016-07-07 16:17:23','1','1','1','10268661467933383','0');
INSERT INTO `rlb_custom_program_log` VALUES ('669','3','Valve 4','V','4','2016-07-07 16:16:24','2016-07-07 16:17:24','1','1','1','10268661467933383','0');
INSERT INTO `rlb_custom_program_log` VALUES ('670','3','Valve 4','V','4','2016-07-07 16:16:24','2016-07-07 16:17:24','1','1','1','10268661467933383','0');
INSERT INTO `rlb_custom_program_log` VALUES ('671','3','Valve 0','V','0','2016-07-07 16:18:02','2016-07-07 16:19:02','1','2','2','10268661467933383','0');
INSERT INTO `rlb_custom_program_log` VALUES ('672','3','Valve 4','V','4','2016-07-07 16:19:02','2016-07-07 16:20:02','1','3','2','10268661467933383','0');
INSERT INTO `rlb_custom_program_log` VALUES ('673','3','Valve 5','V','5','2016-07-07 16:19:02','2016-07-07 16:20:02','1','3','2','10268661467933383','0');
INSERT INTO `rlb_custom_program_log` VALUES ('674','3','Valve 5','V','5','2016-07-07 16:19:02','2016-07-07 16:20:02','1','3','2','10268661467933383','0');
INSERT INTO `rlb_custom_program_log` VALUES ('675','3','Pump 1','PS','1','2016-07-07 16:20:02','2016-07-07 16:21:02','1','4','1','10268661467933383','0');
INSERT INTO `rlb_custom_program_log` VALUES ('676','3','Valve 0','V','0','2016-07-07 16:25:00','2016-07-07 16:26:00','1','1','1','26321361467933899','0');
INSERT INTO `rlb_custom_program_log` VALUES ('677','3','Valve 4','V','4','2016-07-07 16:25:00','2016-07-07 16:26:00','1','1','1','26321361467933899','0');
INSERT INTO `rlb_custom_program_log` VALUES ('678','3','Valve 4','V','4','2016-07-07 16:25:00','2016-07-07 16:26:00','1','1','1','26321361467933899','0');
INSERT INTO `rlb_custom_program_log` VALUES ('679','3','Valve 0','V','0','2016-07-07 16:26:02','2016-07-07 16:27:02','1','2','2','26321361467933899','0');
INSERT INTO `rlb_custom_program_log` VALUES ('680','3','Valve 4','V','4','2016-07-07 16:27:03','2016-07-07 16:28:03','1','3','2','26321361467933899','0');
INSERT INTO `rlb_custom_program_log` VALUES ('681','3','Valve 5','V','5','2016-07-07 16:27:03','2016-07-07 16:28:03','1','3','2','26321361467933899','0');
INSERT INTO `rlb_custom_program_log` VALUES ('682','3','Valve 5','V','5','2016-07-07 16:27:03','2016-07-07 16:28:03','1','3','2','26321361467933899','0');
INSERT INTO `rlb_custom_program_log` VALUES ('683','3','Pump 1','PS','1','2016-07-07 16:29:03','2016-07-07 16:30:03','1','4','1','26321361467933899','0');
INSERT INTO `rlb_custom_program_log` VALUES ('684','3','Valve 0','V','0','2016-07-07 16:33:55','2016-07-07 16:34:55','1','1','1','15882121467934435','0');
INSERT INTO `rlb_custom_program_log` VALUES ('685','3','Valve 4','V','4','2016-07-07 16:33:56','2016-07-07 16:34:56','1','1','1','15882121467934435','0');
INSERT INTO `rlb_custom_program_log` VALUES ('686','3','Valve 4','V','4','2016-07-07 16:33:56','2016-07-07 16:34:56','1','1','1','15882121467934435','0');
INSERT INTO `rlb_custom_program_log` VALUES ('687','3','Valve 0','V','0','2016-07-07 16:35:02','2016-07-07 16:36:02','1','2','2','15882121467934435','0');
INSERT INTO `rlb_custom_program_log` VALUES ('688','3','Valve 4','V','4','2016-07-07 16:36:02','2016-07-07 16:37:02','1','3','2','15882121467934435','0');
INSERT INTO `rlb_custom_program_log` VALUES ('689','3','Valve 5','V','5','2016-07-07 16:36:03','2016-07-07 16:37:03','1','3','2','15882121467934435','0');
INSERT INTO `rlb_custom_program_log` VALUES ('690','3','Valve 5','V','5','2016-07-07 16:36:03','2016-07-07 16:37:03','1','3','2','15882121467934435','0');
INSERT INTO `rlb_custom_program_log` VALUES ('691','3','Pump 1','PS','1','2016-07-07 16:38:03','2016-07-07 16:48:03','1','4','1','15882121467934435','0');
INSERT INTO `rlb_custom_program_log` VALUES ('692','45','Valve 5','V','5','2016-07-07 17:05:59','2016-07-07 17:06:59','1','1','1','80982391467936359','0');
INSERT INTO `rlb_custom_program_log` VALUES ('693','45','Valve 6','V','6','2016-07-07 17:07:02','2016-07-07 17:08:02','1','2','1','80982391467936359','0');
INSERT INTO `rlb_custom_program_log` VALUES ('694','45','Valve 2','V','2','2016-07-07 17:07:02','2016-07-07 17:08:02','1','2','2','80982391467936359','0');
INSERT INTO `rlb_custom_program_log` VALUES ('695','45','Valve 2','V','2','2016-07-07 17:07:02','2016-07-07 17:08:02','1','2','2','80982391467936359','0');
INSERT INTO `rlb_custom_program_log` VALUES ('696','45','Valve 0','V','0','2016-07-07 17:08:02','2016-07-07 17:09:02','1','3','2','80982391467936359','0');
INSERT INTO `rlb_custom_program_log` VALUES ('697','45','Valve 3','V','3','2016-07-07 17:08:02','2016-07-07 17:09:02','1','3','2','80982391467936359','0');
INSERT INTO `rlb_custom_program_log` VALUES ('698','45','Valve 3','V','3','2016-07-07 17:08:02','2016-07-07 17:09:02','1','3','2','80982391467936359','0');
INSERT INTO `rlb_custom_program_log` VALUES ('699','45','Valve 4','V','4','2016-07-07 17:09:03','2016-07-07 17:10:03','1','4','1','80982391467936359','0');
INSERT INTO `rlb_custom_program_log` VALUES ('700','45','Valve 5','V','5','2016-07-07 17:09:03','2016-07-07 17:10:03','1','4','2','80982391467936359','0');
INSERT INTO `rlb_custom_program_log` VALUES ('701','45','Valve 5','V','5','2016-07-07 17:09:03','2016-07-07 17:10:03','1','4','2','80982391467936359','0');
INSERT INTO `rlb_custom_program_log` VALUES ('702','45','Valve 4','V','4','2016-07-07 17:11:02','2016-07-07 17:12:02','1','5','2','80982391467936359','0');
INSERT INTO `rlb_custom_program_log` VALUES ('703','45','Pump 1','PS','1','2016-07-07 17:12:02','2016-07-07 17:13:02','1','6','1','80982391467936359','0');
INSERT INTO `rlb_custom_program_log` VALUES ('704','45','Valve 5','V','5','2016-07-07 17:13:03','2016-07-07 17:14:03','1','1','1','80982391467936359','1');
INSERT INTO `rlb_custom_program_log` VALUES ('705','45','Valve 2','V','2','2016-07-07 17:15:02','2016-07-07 17:16:02','1','2','2','80982391467936359','1');
INSERT INTO `rlb_custom_program_log` VALUES ('706','45','Valve 3','V','3','2016-07-07 17:17:02','2016-07-07 17:18:02','1','3','2','80982391467936359','1');
INSERT INTO `rlb_custom_program_log` VALUES ('707','45','Valve 5','V','5','2016-07-07 17:19:02','2016-07-07 17:20:02','1','4','2','80982391467936359','1');
INSERT INTO `rlb_custom_program_log` VALUES ('708','45','Valve 4','V','4','2016-07-07 17:20:02','2016-07-07 17:21:02','1','5','2','80982391467936359','1');
INSERT INTO `rlb_custom_program_log` VALUES ('709','6','Valve 1','V','1','2016-07-07 20:06:22','2016-07-07 20:07:22','1','1','2','48743291467947180','0');
INSERT INTO `rlb_custom_program_log` VALUES ('710','6','Valve 2','V','2','2016-07-07 20:06:23','2016-07-07 20:07:23','1','1','2','48743291467947180','0');
INSERT INTO `rlb_custom_program_log` VALUES ('711','6','Valve 2','V','2','2016-07-07 20:06:23','2016-07-07 20:07:23','1','1','2','48743291467947180','0');
INSERT INTO `rlb_custom_program_log` VALUES ('712','6','Valve 5','V','5','2016-07-07 20:08:02','2016-07-07 20:09:02','1','2','1','48743291467947180','0');
INSERT INTO `rlb_custom_program_log` VALUES ('713','6','Valve 6','V','6','2016-07-07 20:08:02','2016-07-07 20:09:02','1','2','1','48743291467947180','0');
INSERT INTO `rlb_custom_program_log` VALUES ('714','6','Valve 6','V','6','2016-07-07 20:08:02','2016-07-07 20:09:02','1','2','1','48743291467947180','0');
INSERT INTO `rlb_custom_program_log` VALUES ('715','6','Pump 2','PS','2','2016-07-07 20:09:02','2016-07-07 21:09:02','1','3','1','48743291467947180','0');
INSERT INTO `rlb_custom_program_log` VALUES ('716','6','Valve 5','V','5','2016-07-07 20:12:02','2016-07-07 20:13:02','1','1','1','48743291467947180','1');
INSERT INTO `rlb_custom_program_log` VALUES ('717','45','Valve 5','V','5','2016-07-08 09:12:25','2016-07-08 09:13:25','1','1','1','29341061467994345','0');
INSERT INTO `rlb_custom_program_log` VALUES ('718','45','Valve 6','V','6','2016-07-08 09:14:03','2016-07-08 09:15:03','1','2','1','29341061467994345','0');
INSERT INTO `rlb_custom_program_log` VALUES ('719','45','Valve 2','V','2','2016-07-08 09:14:03','2016-07-08 09:15:03','1','2','2','29341061467994345','0');
INSERT INTO `rlb_custom_program_log` VALUES ('720','45','Valve 2','V','2','2016-07-08 09:14:03','2016-07-08 09:15:03','1','2','2','29341061467994345','0');
INSERT INTO `rlb_custom_program_log` VALUES ('721','45','Valve 0','V','0','2016-07-08 09:15:03','2016-07-08 09:16:03','1','3','2','29341061467994345','0');
INSERT INTO `rlb_custom_program_log` VALUES ('722','45','Valve 3','V','3','2016-07-08 09:15:03','2016-07-08 09:16:03','1','3','2','29341061467994345','0');
INSERT INTO `rlb_custom_program_log` VALUES ('723','45','Valve 3','V','3','2016-07-08 09:15:03','2016-07-08 09:16:03','1','3','2','29341061467994345','0');
INSERT INTO `rlb_custom_program_log` VALUES ('724','45','Valve 4','V','4','2016-07-08 09:17:02','2016-07-08 09:18:02','1','4','1','29341061467994345','0');
INSERT INTO `rlb_custom_program_log` VALUES ('725','45','Valve 5','V','5','2016-07-08 09:17:02','2016-07-08 09:18:02','1','4','2','29341061467994345','0');
INSERT INTO `rlb_custom_program_log` VALUES ('726','45','Valve 5','V','5','2016-07-08 09:17:02','2016-07-08 09:18:02','1','4','2','29341061467994345','0');
INSERT INTO `rlb_custom_program_log` VALUES ('727','45','Valve 4','V','4','2016-07-08 09:18:02','2016-07-08 09:19:02','1','5','2','29341061467994345','0');
INSERT INTO `rlb_custom_program_log` VALUES ('728','45','Pump 1','PS','1','2016-07-08 09:19:02','2016-07-08 09:20:02','1','6','1','29341061467994345','0');
INSERT INTO `rlb_custom_program_log` VALUES ('729','45','Valve 5','V','5','2016-07-08 09:20:02','2016-07-08 09:21:02','1','1','1','29341061467994345','1');
INSERT INTO `rlb_custom_program_log` VALUES ('730','45','Valve 2','V','2','2016-07-08 09:21:04','2016-07-08 09:22:04','1','2','2','29341061467994345','1');
INSERT INTO `rlb_custom_program_log` VALUES ('731','6','Valve 1','V','1','2016-07-08 19:46:27','2016-07-08 19:47:27','1','1','2','66952181468032386','0');
INSERT INTO `rlb_custom_program_log` VALUES ('732','6','Valve 2','V','2','2016-07-08 19:46:27','2016-07-08 19:47:27','1','1','2','66952181468032386','0');
INSERT INTO `rlb_custom_program_log` VALUES ('733','6','Valve 2','V','2','2016-07-08 19:46:27','2016-07-08 19:47:27','1','1','2','66952181468032386','0');
INSERT INTO `rlb_custom_program_log` VALUES ('734','6','Valve 5','V','5','2016-07-08 19:47:01','2016-07-08 19:48:01','1','1','1','66952181468032386','1');
INSERT INTO `rlb_custom_program_log` VALUES ('735','1','Valve 0','V','0','2016-07-08 19:46:56','2016-07-08 19:47:56','1','1','2','25212311468032416','0');
INSERT INTO `rlb_custom_program_log` VALUES ('736','6','Valve 1','V','1','2016-07-08 19:47:13','2016-07-08 19:48:13','1','1','2','48537361468032432','0');
INSERT INTO `rlb_custom_program_log` VALUES ('737','6','Valve 2','V','2','2016-07-08 19:47:13','2016-07-08 19:48:13','1','1','2','48537361468032432','0');
INSERT INTO `rlb_custom_program_log` VALUES ('738','6','Valve 2','V','2','2016-07-08 19:47:13','2016-07-08 19:48:13','1','1','2','48537361468032432','0');
INSERT INTO `rlb_custom_program_log` VALUES ('739','6','Valve 5','V','5','2016-07-08 19:49:03','2016-07-08 19:50:03','1','2','1','48537361468032432','0');
INSERT INTO `rlb_custom_program_log` VALUES ('740','6','Valve 6','V','6','2016-07-08 19:49:03','2016-07-08 19:50:03','1','2','1','48537361468032432','0');
INSERT INTO `rlb_custom_program_log` VALUES ('741','6','Valve 6','V','6','2016-07-08 19:49:03','2016-07-08 19:50:03','1','2','1','48537361468032432','0');
INSERT INTO `rlb_custom_program_log` VALUES ('742','1','Valve 3','V','3','2016-07-08 19:48:07','2016-07-08 19:49:07','1','2','2','25212311468032416','0');
INSERT INTO `rlb_custom_program_log` VALUES ('743','6','Valve 1','V','1','2016-07-08 19:49:56','2016-07-08 19:50:56','1','1','2','97651321468032596','0');
INSERT INTO `rlb_custom_program_log` VALUES ('744','6','Valve 2','V','2','2016-07-08 19:49:56','2016-07-08 19:50:56','1','1','2','97651321468032596','0');
INSERT INTO `rlb_custom_program_log` VALUES ('745','6','Valve 2','V','2','2016-07-08 19:49:56','2016-07-08 19:50:56','1','1','2','97651321468032596','0');
INSERT INTO `rlb_custom_program_log` VALUES ('746','1','Valve 4','V','4','2016-07-08 19:50:02','2016-07-08 19:51:02','1','3','1','25212311468032416','0');
INSERT INTO `rlb_custom_program_log` VALUES ('747','6','Valve 5','V','5','2016-07-08 19:51:02','2016-07-08 19:52:02','1','2','1','97651321468032596','0');
INSERT INTO `rlb_custom_program_log` VALUES ('748','6','Valve 6','V','6','2016-07-08 19:51:02','2016-07-08 19:52:02','1','2','1','97651321468032596','0');
INSERT INTO `rlb_custom_program_log` VALUES ('749','6','Valve 6','V','6','2016-07-08 19:51:02','2016-07-08 19:52:02','1','2','1','97651321468032596','0');
INSERT INTO `rlb_custom_program_log` VALUES ('750','1','Valve 4','V','4','2016-07-08 19:52:02','2016-07-08 19:53:02','1','4','2','25212311468032416','0');
INSERT INTO `rlb_custom_program_log` VALUES ('751','1','Valve 5','V','5','2016-07-08 19:53:02','2016-07-08 19:54:02','1','5','2','25212311468032416','0');
INSERT INTO `rlb_custom_program_log` VALUES ('752','1','Valve 5','V','5','2016-07-08 19:54:02','2016-07-08 19:55:02','1','6','1','25212311468032416','0');
INSERT INTO `rlb_custom_program_log` VALUES ('753','1','Valve 6','V','6','2016-07-08 19:54:02','2016-07-08 19:55:02','1','6','1','25212311468032416','0');
INSERT INTO `rlb_custom_program_log` VALUES ('754','1','Valve 6','V','6','2016-07-08 19:54:02','2016-07-08 19:55:02','1','6','1','25212311468032416','0');
INSERT INTO `rlb_custom_program_log` VALUES ('755','6','Pump 2','PS','2','2016-07-08 19:52:03','2016-07-08 20:52:03','1','3','1','97651321468032596','0');
INSERT INTO `rlb_custom_program_log` VALUES ('756','1','Pump 2','PS','2','2016-07-08 19:56:03','2016-07-08 19:57:03','1','7','1','25212311468032416','0');
INSERT INTO `rlb_custom_program_log` VALUES ('757','1','Relay 15','R','15','2016-07-08 19:56:03','2016-07-08 20:51:03','1','7','1','25212311468032416','0');
INSERT INTO `rlb_custom_program_log` VALUES ('758','1','Power Center 0','P','0','2016-07-08 19:56:03','2016-07-08 20:51:03','1','7','1','25212311468032416','0');
INSERT INTO `rlb_custom_program_log` VALUES ('759','1','Valve 0','V','0','2016-07-08 19:57:39','2016-07-08 19:58:39','1','1','2','21410621468033058','0');
INSERT INTO `rlb_custom_program_log` VALUES ('760','6','Valve 1','V','1','2016-07-08 19:57:49','2016-07-08 19:58:49','1','1','2','10510371468033069','0');
INSERT INTO `rlb_custom_program_log` VALUES ('761','6','Valve 2','V','2','2016-07-08 19:57:50','2016-07-08 19:58:50','1','1','2','10510371468033069','0');
INSERT INTO `rlb_custom_program_log` VALUES ('762','6','Valve 2','V','2','2016-07-08 19:57:50','2016-07-08 19:58:50','1','1','2','10510371468033069','0');
INSERT INTO `rlb_custom_program_log` VALUES ('763','6','Valve 5','V','5','2016-07-08 19:59:03','2016-07-08 20:00:03','1','2','1','10510371468033069','0');
INSERT INTO `rlb_custom_program_log` VALUES ('764','6','Valve 6','V','6','2016-07-08 19:59:03','2016-07-08 20:00:03','1','2','1','10510371468033069','0');
INSERT INTO `rlb_custom_program_log` VALUES ('765','6','Valve 6','V','6','2016-07-08 19:59:03','2016-07-08 20:00:03','1','2','1','10510371468033069','0');
INSERT INTO `rlb_custom_program_log` VALUES ('766','1','Valve 3','V','3','2016-07-08 19:59:02','2016-07-08 20:00:02','1','2','2','21410621468033058','0');
INSERT INTO `rlb_custom_program_log` VALUES ('767','6','Valve 1','V','1','2016-07-08 19:59:58','2016-07-08 20:00:58','1','1','2','41797281468033198','0');
INSERT INTO `rlb_custom_program_log` VALUES ('768','6','Valve 2','V','2','2016-07-08 19:59:58','2016-07-08 20:00:58','1','1','2','41797281468033198','0');
INSERT INTO `rlb_custom_program_log` VALUES ('769','6','Valve 2','V','2','2016-07-08 19:59:58','2016-07-08 20:00:58','1','1','2','41797281468033198','0');
INSERT INTO `rlb_custom_program_log` VALUES ('770','1','Valve 4','V','4','2016-07-08 20:00:02','2016-07-08 20:01:02','1','1','1','21410621468033058','1');
INSERT INTO `rlb_custom_program_log` VALUES ('771','3','Valve 0','V','0','2016-07-08 19:59:12','2016-07-08 20:00:12','1','1','1','83853071468033152','0');
INSERT INTO `rlb_custom_program_log` VALUES ('772','3','Valve 4','V','4','2016-07-08 19:59:12','2016-07-08 20:00:12','1','1','1','83853071468033152','0');
INSERT INTO `rlb_custom_program_log` VALUES ('773','3','Valve 4','V','4','2016-07-08 19:59:12','2016-07-08 20:00:12','1','1','1','83853071468033152','0');
INSERT INTO `rlb_custom_program_log` VALUES ('774','1','Valve 6','V','6','2016-07-08 20:01:02','2016-07-08 20:02:02','1','6','1','21410621468033058','1');
INSERT INTO `rlb_custom_program_log` VALUES ('775','6','Valve 5','V','5','2016-07-08 20:01:03','2016-07-08 20:02:03','1','1','1','41797281468033198','1');
INSERT INTO `rlb_custom_program_log` VALUES ('776','3','Valve 0','V','0','2016-07-08 20:01:03','2016-07-08 20:02:03','1','2','2','83853071468033152','0');
INSERT INTO `rlb_custom_program_log` VALUES ('777','1','Valve 0','V','0','2016-07-08 20:02:40','2016-07-08 20:03:40','1','1','2','31610251468033360','0');
INSERT INTO `rlb_custom_program_log` VALUES ('778','6','Valve 1','V','1','2016-07-08 20:02:44','2016-07-08 20:03:44','1','1','2','96966421468033364','0');
INSERT INTO `rlb_custom_program_log` VALUES ('779','6','Valve 2','V','2','2016-07-08 20:02:45','2016-07-08 20:03:45','1','1','2','96966421468033364','0');
INSERT INTO `rlb_custom_program_log` VALUES ('780','6','Valve 2','V','2','2016-07-08 20:02:45','2016-07-08 20:03:45','1','1','2','96966421468033364','0');
INSERT INTO `rlb_custom_program_log` VALUES ('781','1','Valve 3','V','3','2016-07-08 20:04:02','2016-07-08 20:05:02','1','2','2','31610251468033360','0');
INSERT INTO `rlb_custom_program_log` VALUES ('782','3','Valve 4','V','4','2016-07-08 20:03:03','2016-07-08 20:04:03','1','3','2','83853071468033152','0');
INSERT INTO `rlb_custom_program_log` VALUES ('783','3','Valve 5','V','5','2016-07-08 20:03:03','2016-07-08 20:04:03','1','3','2','83853071468033152','0');
INSERT INTO `rlb_custom_program_log` VALUES ('784','3','Valve 5','V','5','2016-07-08 20:03:03','2016-07-08 20:04:03','1','3','2','83853071468033152','0');
INSERT INTO `rlb_custom_program_log` VALUES ('785','6','Valve 5','V','5','2016-07-08 20:04:02','2016-07-08 20:05:02','1','2','1','96966421468033364','0');
INSERT INTO `rlb_custom_program_log` VALUES ('786','6','Valve 6','V','6','2016-07-08 20:04:02','2016-07-08 20:05:02','1','2','1','96966421468033364','0');
INSERT INTO `rlb_custom_program_log` VALUES ('787','6','Valve 6','V','6','2016-07-08 20:04:02','2016-07-08 20:05:02','1','2','1','96966421468033364','0');
INSERT INTO `rlb_custom_program_log` VALUES ('788','1','Valve 4','V','4','2016-07-08 20:05:02','2016-07-08 20:06:02','1','3','1','31610251468033360','0');
INSERT INTO `rlb_custom_program_log` VALUES ('789','1','Valve 4','V','4','2016-07-08 20:06:02','2016-07-08 20:07:02','1','4','2','31610251468033360','0');
INSERT INTO `rlb_custom_program_log` VALUES ('790','1','Valve 5','V','5','2016-07-08 20:07:02','2016-07-08 20:08:02','1','5','2','31610251468033360','0');
INSERT INTO `rlb_custom_program_log` VALUES ('791','1','Valve 5','V','5','2016-07-08 20:08:02','2016-07-08 20:09:02','1','6','1','31610251468033360','0');
INSERT INTO `rlb_custom_program_log` VALUES ('792','1','Valve 6','V','6','2016-07-08 20:08:02','2016-07-08 20:09:02','1','6','1','31610251468033360','0');
INSERT INTO `rlb_custom_program_log` VALUES ('793','1','Valve 6','V','6','2016-07-08 20:08:02','2016-07-08 20:09:02','1','6','1','31610251468033360','0');
INSERT INTO `rlb_custom_program_log` VALUES ('794','1','Pump 2','PS','2','2016-07-08 20:09:03','2016-07-08 20:10:03','1','7','1','31610251468033360','0');
INSERT INTO `rlb_custom_program_log` VALUES ('795','3','Pump 1','PS','1','2016-07-08 20:05:02','2016-07-08 20:15:02','1','4','1','83853071468033152','0');
INSERT INTO `rlb_custom_program_log` VALUES ('796','6','Pump 2','PS','2','2016-07-08 20:05:03','2016-07-08 21:05:03','1','3','1','96966421468033364','0');
INSERT INTO `rlb_custom_program_log` VALUES ('797','6','Valve 1','V','1','2016-07-08 20:49:54','2016-07-08 20:50:54','1','1','2','96752961468036194','0');
INSERT INTO `rlb_custom_program_log` VALUES ('798','6','Valve 2','V','2','2016-07-08 20:49:55','2016-07-08 20:50:55','1','1','2','96752961468036194','0');
INSERT INTO `rlb_custom_program_log` VALUES ('799','6','Valve 2','V','2','2016-07-08 20:49:55','2016-07-08 20:50:55','1','1','2','96752961468036194','0');
INSERT INTO `rlb_custom_program_log` VALUES ('800','6','Valve 5','V','5','2016-07-08 20:51:03','2016-07-08 20:52:03','1','2','1','96752961468036194','0');
INSERT INTO `rlb_custom_program_log` VALUES ('801','6','Valve 6','V','6','2016-07-08 20:51:03','2016-07-08 20:52:03','1','2','1','96752961468036194','0');
INSERT INTO `rlb_custom_program_log` VALUES ('802','6','Valve 6','V','6','2016-07-08 20:51:03','2016-07-08 20:52:03','1','2','1','96752961468036194','0');
INSERT INTO `rlb_custom_program_log` VALUES ('803','6','Pump 2','PS','2','2016-07-08 20:53:03','2016-07-08 21:53:03','1','3','1','96752961468036194','0');
INSERT INTO `rlb_custom_program_log` VALUES ('804','6','Valve 1','V','1','2016-07-08 20:53:28','2016-07-08 20:54:28','1','1','2','90219251468036408','0');
INSERT INTO `rlb_custom_program_log` VALUES ('805','6','Valve 2','V','2','2016-07-08 20:53:29','2016-07-08 20:54:29','1','1','2','90219251468036408','0');
INSERT INTO `rlb_custom_program_log` VALUES ('806','6','Valve 2','V','2','2016-07-08 20:53:29','2016-07-08 20:54:29','1','1','2','90219251468036408','0');
INSERT INTO `rlb_custom_program_log` VALUES ('807','6','Valve 5','V','5','2016-07-08 20:55:03','2016-07-08 20:56:03','1','2','1','90219251468036408','0');
INSERT INTO `rlb_custom_program_log` VALUES ('808','6','Valve 6','V','6','2016-07-08 20:55:03','2016-07-08 20:56:03','1','2','1','90219251468036408','0');
INSERT INTO `rlb_custom_program_log` VALUES ('809','6','Valve 6','V','6','2016-07-08 20:55:03','2016-07-08 20:56:03','1','2','1','90219251468036408','0');
INSERT INTO `rlb_custom_program_log` VALUES ('810','1','Relay 15','R','15','2016-07-08 20:09:03','2016-07-08 21:04:03','1','7','1','31610251468033360','0');
INSERT INTO `rlb_custom_program_log` VALUES ('811','1','Power Center 0','P','0','2016-07-08 20:09:03','2016-07-08 21:04:03','1','7','1','31610251468033360','0');
INSERT INTO `rlb_custom_program_log` VALUES ('812','1','Valve 4','V','4','2016-07-08 21:05:02','2016-07-08 21:06:02','1','1','1','31610251468033360','1');
INSERT INTO `rlb_custom_program_log` VALUES ('813','1','Valve 6','V','6','2016-07-08 21:07:02','2016-07-08 21:08:02','1','6','1','31610251468033360','1');
INSERT INTO `rlb_custom_program_log` VALUES ('814','6','Pump 2','PS','2','2016-07-08 20:57:02','2016-07-08 21:57:02','1','3','1','90219251468036408','0');
INSERT INTO `rlb_custom_program_log` VALUES ('815','6','Valve 5','V','5','2016-07-08 21:57:03','2016-07-08 21:58:03','1','1','1','90219251468036408','1');
INSERT INTO `rlb_custom_program_log` VALUES ('816','1','Valve 0','V','0','2016-07-08 22:07:24','2016-07-08 22:08:24','1','1','2','50284611468040844','0');
INSERT INTO `rlb_custom_program_log` VALUES ('817','3','Valve 0','V','0','2016-07-08 22:07:31','2016-07-08 22:08:31','1','1','1','32611031468040851','0');
INSERT INTO `rlb_custom_program_log` VALUES ('818','3','Valve 4','V','4','2016-07-08 22:07:32','2016-07-08 22:08:32','1','1','1','32611031468040851','0');
INSERT INTO `rlb_custom_program_log` VALUES ('819','3','Valve 4','V','4','2016-07-08 22:07:32','2016-07-08 22:08:32','1','1','1','32611031468040851','0');
INSERT INTO `rlb_custom_program_log` VALUES ('820','6','Valve 1','V','1','2016-07-08 22:07:28','2016-07-08 22:08:28','1','1','2','75274201468040848','0');
INSERT INTO `rlb_custom_program_log` VALUES ('821','6','Valve 2','V','2','2016-07-08 22:07:28','2016-07-08 22:08:28','1','1','2','75274201468040848','0');
INSERT INTO `rlb_custom_program_log` VALUES ('822','6','Valve 2','V','2','2016-07-08 22:07:28','2016-07-08 22:08:28','1','1','2','75274201468040848','0');
INSERT INTO `rlb_custom_program_log` VALUES ('823','6','Valve 5','V','5','2016-07-08 22:09:02','2016-07-08 22:10:02','1','2','1','75274201468040848','0');
INSERT INTO `rlb_custom_program_log` VALUES ('824','6','Valve 6','V','6','2016-07-08 22:09:02','2016-07-08 22:10:02','1','2','1','75274201468040848','0');
INSERT INTO `rlb_custom_program_log` VALUES ('825','1','Valve 3','V','3','2016-07-08 22:09:01','2016-07-08 22:10:01','1','2','2','50284611468040844','0');
INSERT INTO `rlb_custom_program_log` VALUES ('826','6','Valve 6','V','6','2016-07-08 22:09:02','2016-07-08 22:10:02','1','2','1','75274201468040848','0');
INSERT INTO `rlb_custom_program_log` VALUES ('827','3','Valve 0','V','0','2016-07-08 22:09:02','2016-07-08 22:10:02','1','2','2','32611031468040851','0');
INSERT INTO `rlb_custom_program_log` VALUES ('828','1','Valve 4','V','4','2016-07-08 22:10:02','2016-07-08 22:11:02','1','3','1','50284611468040844','0');
INSERT INTO `rlb_custom_program_log` VALUES ('829','3','Valve 4','V','4','2016-07-08 22:10:02','2016-07-08 22:11:02','1','3','2','32611031468040851','0');
INSERT INTO `rlb_custom_program_log` VALUES ('830','3','Valve 5','V','5','2016-07-08 22:10:02','2016-07-08 22:11:02','1','3','2','32611031468040851','0');
INSERT INTO `rlb_custom_program_log` VALUES ('831','3','Valve 5','V','5','2016-07-08 22:10:02','2016-07-08 22:11:02','1','3','2','32611031468040851','0');
INSERT INTO `rlb_custom_program_log` VALUES ('832','6','Valve 5','V','5','2016-07-08 22:10:02','2016-07-08 22:11:02','1','1','1','75274201468040848','1');
INSERT INTO `rlb_custom_program_log` VALUES ('833','1','Valve 4','V','4','2016-07-08 22:11:01','2016-07-08 22:12:01','1','1','1','50284611468040844','1');
INSERT INTO `rlb_custom_program_log` VALUES ('834','1','Valve 6','V','6','2016-07-08 22:12:02','2016-07-08 22:13:02','1','6','1','50284611468040844','1');
INSERT INTO `rlb_custom_program_log` VALUES ('835','1','Valve 0','V','0','2016-07-08 22:20:42','2016-07-08 22:21:42','1','1','2','69959521468041642','0');
INSERT INTO `rlb_custom_program_log` VALUES ('836','6','Valve 1','V','1','2016-07-08 22:20:56','2016-07-08 22:21:56','1','1','2','81947821468041656','0');
INSERT INTO `rlb_custom_program_log` VALUES ('837','6','Valve 2','V','2','2016-07-08 22:20:57','2016-07-08 22:21:57','1','1','2','81947821468041656','0');
INSERT INTO `rlb_custom_program_log` VALUES ('838','6','Valve 2','V','2','2016-07-08 22:20:57','2016-07-08 22:21:57','1','1','2','81947821468041656','0');
INSERT INTO `rlb_custom_program_log` VALUES ('839','1','Valve 3','V','3','2016-07-08 22:22:02','2016-07-08 22:23:02','1','2','2','69959521468041642','0');
INSERT INTO `rlb_custom_program_log` VALUES ('840','1','Valve 4','V','4','2016-07-08 22:23:02','2016-07-08 22:24:02','1','3','1','69959521468041642','0');
INSERT INTO `rlb_custom_program_log` VALUES ('841','6','Valve 5','V','5','2016-07-08 22:22:03','2016-07-08 22:23:03','1','2','1','81947821468041656','0');
INSERT INTO `rlb_custom_program_log` VALUES ('842','6','Valve 6','V','6','2016-07-08 22:22:03','2016-07-08 22:23:03','1','2','1','81947821468041656','0');
INSERT INTO `rlb_custom_program_log` VALUES ('843','6','Valve 6','V','6','2016-07-08 22:22:03','2016-07-08 22:23:03','1','2','1','81947821468041656','0');
INSERT INTO `rlb_custom_program_log` VALUES ('844','1','Valve 4','V','4','2016-07-08 22:24:02','2016-07-08 22:25:02','1','4','2','69959521468041642','0');
INSERT INTO `rlb_custom_program_log` VALUES ('845','1','Valve 5','V','5','2016-07-08 22:25:02','2016-07-08 22:26:02','1','5','2','69959521468041642','0');
INSERT INTO `rlb_custom_program_log` VALUES ('846','1','Valve 5','V','5','2016-07-08 22:26:02','2016-07-08 22:27:02','1','6','1','69959521468041642','0');
INSERT INTO `rlb_custom_program_log` VALUES ('847','1','Valve 6','V','6','2016-07-08 22:26:02','2016-07-08 22:27:02','1','6','1','69959521468041642','0');
INSERT INTO `rlb_custom_program_log` VALUES ('848','1','Valve 6','V','6','2016-07-08 22:26:02','2016-07-08 22:27:02','1','6','1','69959521468041642','0');
INSERT INTO `rlb_custom_program_log` VALUES ('849','1','Pump 2','PS','2','2016-07-08 22:27:02','2016-07-08 22:28:02','1','7','1','69959521468041642','0');
INSERT INTO `rlb_custom_program_log` VALUES ('850','1','Relay 15','R','15','2016-07-08 22:27:02','2016-07-08 23:22:02','1','7','1','69959521468041642','0');
INSERT INTO `rlb_custom_program_log` VALUES ('851','1','Power Center 0','P','0','2016-07-08 22:27:02','2016-07-08 23:22:02','1','7','1','69959521468041642','0');
INSERT INTO `rlb_custom_program_log` VALUES ('852','1','Valve 4','V','4','2016-07-08 23:22:02','2016-07-08 23:23:02','1','1','1','69959521468041642','1');
INSERT INTO `rlb_custom_program_log` VALUES ('853','1','Valve 6','V','6','2016-07-08 23:23:02','2016-07-08 23:24:02','1','6','1','69959521468041642','1');
INSERT INTO `rlb_custom_program_log` VALUES ('854','6','Pump 2','PS','2','2016-07-08 22:24:02','2016-07-08 23:24:02','1','3','1','81947821468041656','0');
INSERT INTO `rlb_custom_program_log` VALUES ('855','6','Valve 5','V','5','2016-07-08 23:24:02','2016-07-08 23:25:02','1','1','1','81947821468041656','1');
INSERT INTO `rlb_custom_program_log` VALUES ('856','1','Valve 0','V','0','2016-07-09 10:40:21','2016-07-09 10:41:21','1','1','2','90449231468086021','0');
INSERT INTO `rlb_custom_program_log` VALUES ('857','6','Valve 1','V','1','2016-07-09 10:40:47','2016-07-09 10:41:47','1','1','2','45607181468086047','0');
INSERT INTO `rlb_custom_program_log` VALUES ('858','6','Valve 2','V','2','2016-07-09 10:40:47','2016-07-09 10:41:47','1','1','2','45607181468086047','0');
INSERT INTO `rlb_custom_program_log` VALUES ('859','6','Valve 2','V','2','2016-07-09 10:40:47','2016-07-09 10:41:47','1','1','2','45607181468086047','0');
INSERT INTO `rlb_custom_program_log` VALUES ('860','1','Valve 3','V','3','2016-07-09 10:42:02','2016-07-09 10:43:02','1','2','2','90449231468086021','0');
INSERT INTO `rlb_custom_program_log` VALUES ('861','1','Valve 4','V','4','2016-07-09 10:43:02','2016-07-09 10:44:02','1','3','1','90449231468086021','0');
INSERT INTO `rlb_custom_program_log` VALUES ('862','6','Valve 5','V','5','2016-07-09 10:42:03','2016-07-09 10:43:03','1','2','1','45607181468086047','0');
INSERT INTO `rlb_custom_program_log` VALUES ('863','6','Valve 6','V','6','2016-07-09 10:42:03','2016-07-09 10:43:03','1','2','1','45607181468086047','0');
INSERT INTO `rlb_custom_program_log` VALUES ('864','6','Valve 6','V','6','2016-07-09 10:42:03','2016-07-09 10:43:03','1','2','1','45607181468086047','0');
INSERT INTO `rlb_custom_program_log` VALUES ('865','1','Valve 4','V','4','2016-07-09 10:44:02','2016-07-09 10:45:02','1','4','2','90449231468086021','0');
INSERT INTO `rlb_custom_program_log` VALUES ('866','1','Valve 5','V','5','2016-07-09 10:45:02','2016-07-09 10:46:02','1','5','2','90449231468086021','0');
INSERT INTO `rlb_custom_program_log` VALUES ('867','1','Valve 5','V','5','2016-07-09 10:46:02','2016-07-09 10:47:02','1','6','1','90449231468086021','0');
INSERT INTO `rlb_custom_program_log` VALUES ('868','1','Valve 6','V','6','2016-07-09 10:46:02','2016-07-09 10:47:02','1','6','1','90449231468086021','0');
INSERT INTO `rlb_custom_program_log` VALUES ('869','1','Valve 6','V','6','2016-07-09 10:46:02','2016-07-09 10:47:02','1','6','1','90449231468086021','0');
INSERT INTO `rlb_custom_program_log` VALUES ('870','1','Pump 2','PS','2','2016-07-09 10:47:02','2016-07-09 10:48:02','1','7','1','90449231468086021','0');
INSERT INTO `rlb_custom_program_log` VALUES ('871','1','Relay 15','R','15','2016-07-09 10:47:02','2016-07-09 11:42:02','1','7','1','90449231468086021','0');
INSERT INTO `rlb_custom_program_log` VALUES ('872','1','Power Center 0','P','0','2016-07-09 10:47:03','2016-07-09 11:42:03','1','7','1','90449231468086021','0');
INSERT INTO `rlb_custom_program_log` VALUES ('873','1','Valve 4','V','4','2016-07-09 11:43:02','2016-07-09 11:44:02','1','1','1','90449231468086021','1');
INSERT INTO `rlb_custom_program_log` VALUES ('874','6','Pump 2','PS','2','2016-07-09 10:44:02','2016-07-09 11:44:02','1','3','1','45607181468086047','0');
INSERT INTO `rlb_custom_program_log` VALUES ('875','1','Valve 6','V','6','2016-07-09 11:44:02','2016-07-09 11:45:02','1','6','1','90449231468086021','1');
INSERT INTO `rlb_custom_program_log` VALUES ('876','6','Valve 5','V','5','2016-07-09 11:44:02','2016-07-09 11:45:02','1','1','1','45607181468086047','1');
INSERT INTO `rlb_custom_program_log` VALUES ('877','1','Valve 0','V','0','2016-07-09 15:30:20','2016-07-09 15:31:20','1','1','2','61927491468103420','0');
INSERT INTO `rlb_custom_program_log` VALUES ('878','6','Valve 1','V','1','2016-07-09 15:30:24','2016-07-09 15:31:24','1','1','2','84462931468103423','0');
INSERT INTO `rlb_custom_program_log` VALUES ('879','6','Valve 2','V','2','2016-07-09 15:30:24','2016-07-09 15:31:24','1','1','2','84462931468103423','0');
INSERT INTO `rlb_custom_program_log` VALUES ('880','6','Valve 2','V','2','2016-07-09 15:30:24','2016-07-09 15:31:24','1','1','2','84462931468103423','0');
INSERT INTO `rlb_custom_program_log` VALUES ('881','1','Valve 3','V','3','2016-07-09 15:32:03','2016-07-09 15:33:03','1','2','2','61927491468103420','0');
INSERT INTO `rlb_custom_program_log` VALUES ('882','6','Valve 5','V','5','2016-07-09 15:32:04','2016-07-09 15:33:04','1','2','1','84462931468103423','0');
INSERT INTO `rlb_custom_program_log` VALUES ('883','6','Valve 6','V','6','2016-07-09 15:32:04','2016-07-09 15:33:04','1','2','1','84462931468103423','0');
INSERT INTO `rlb_custom_program_log` VALUES ('884','6','Valve 6','V','6','2016-07-09 15:32:04','2016-07-09 15:33:04','1','2','1','84462931468103423','0');
INSERT INTO `rlb_custom_program_log` VALUES ('885','1','Valve 4','V','4','2016-07-09 15:33:03','2016-07-09 15:34:03','1','3','1','61927491468103420','0');
INSERT INTO `rlb_custom_program_log` VALUES ('886','1','Valve 4','V','4','2016-07-09 15:35:02','2016-07-09 15:36:02','1','4','2','61927491468103420','0');
INSERT INTO `rlb_custom_program_log` VALUES ('887','1','Valve 5','V','5','2016-07-09 15:36:03','2016-07-09 15:37:03','1','5','2','61927491468103420','0');
INSERT INTO `rlb_custom_program_log` VALUES ('888','3','Valve 0','V','0','2016-07-09 15:36:37','2016-07-09 15:37:37','1','1','1','48887791468103795','0');
INSERT INTO `rlb_custom_program_log` VALUES ('889','3','Valve 4','V','4','2016-07-09 15:36:37','2016-07-09 15:37:37','1','1','1','48887791468103795','0');
INSERT INTO `rlb_custom_program_log` VALUES ('890','3','Valve 4','V','4','2016-07-09 15:36:37','2016-07-09 15:37:37','1','1','1','48887791468103795','0');
INSERT INTO `rlb_custom_program_log` VALUES ('891','1','Valve 5','V','5','2016-07-09 15:38:05','2016-07-09 15:39:05','1','6','1','61927491468103420','0');
INSERT INTO `rlb_custom_program_log` VALUES ('892','1','Valve 6','V','6','2016-07-09 15:38:05','2016-07-09 15:39:05','1','6','1','61927491468103420','0');
INSERT INTO `rlb_custom_program_log` VALUES ('893','1','Valve 6','V','6','2016-07-09 15:38:05','2016-07-09 15:39:05','1','6','1','61927491468103420','0');
INSERT INTO `rlb_custom_program_log` VALUES ('894','3','Valve 0','V','0','2016-07-09 15:38:11','2016-07-09 15:39:11','1','2','2','48887791468103795','0');
INSERT INTO `rlb_custom_program_log` VALUES ('895','1','Pump 2','PS','2','2016-07-09 15:40:08','2016-07-09 15:41:08','1','7','1','61927491468103420','0');
INSERT INTO `rlb_custom_program_log` VALUES ('896','3','Valve 4','V','4','2016-07-09 15:40:14','2016-07-09 15:41:14','1','3','2','48887791468103795','0');
INSERT INTO `rlb_custom_program_log` VALUES ('897','3','Valve 5','V','5','2016-07-09 15:40:15','2016-07-09 15:41:15','1','3','2','48887791468103795','0');
INSERT INTO `rlb_custom_program_log` VALUES ('898','3','Valve 5','V','5','2016-07-09 15:40:15','2016-07-09 15:41:15','1','3','2','48887791468103795','0');
INSERT INTO `rlb_custom_program_log` VALUES ('899','3','Pump 1','PS','1','2016-07-09 15:42:11','2016-07-09 15:52:11','1','4','1','48887791468103795','0');
INSERT INTO `rlb_custom_program_log` VALUES ('900','6','Pump 2','PS','2','2016-07-09 15:33:04','2016-07-09 16:33:04','1','3','1','84462931468103423','0');
INSERT INTO `rlb_custom_program_log` VALUES ('901','6','Valve 5','V','5','2016-07-09 16:34:02','2016-07-09 16:35:02','1','1','1','84462931468103423','1');
INSERT INTO `rlb_custom_program_log` VALUES ('902','1','Relay 15','R','15','2016-07-09 15:40:09','2016-07-09 16:35:09','1','7','1','61927491468103420','0');
INSERT INTO `rlb_custom_program_log` VALUES ('903','1','Power Center 0','P','0','2016-07-09 15:40:10','2016-07-09 16:35:10','1','7','1','61927491468103420','0');
INSERT INTO `rlb_custom_program_log` VALUES ('904','1','Valve 4','V','4','2016-07-09 16:36:02','2016-07-09 16:37:02','1','1','1','61927491468103420','1');
INSERT INTO `rlb_custom_program_log` VALUES ('905','1','Valve 6','V','6','2016-07-09 16:37:03','2016-07-09 16:38:03','1','6','1','61927491468103420','1');
INSERT INTO `rlb_custom_program_log` VALUES ('906','1','Valve 0','V','0','2016-07-09 16:37:31','2016-07-09 16:38:31','1','1','2','47807641468107450','0');
INSERT INTO `rlb_custom_program_log` VALUES ('907','6','Valve 1','V','1','2016-07-09 16:37:42','2016-07-09 16:38:42','1','1','2','65568671468107461','0');
INSERT INTO `rlb_custom_program_log` VALUES ('908','6','Valve 2','V','2','2016-07-09 16:37:42','2016-07-09 16:38:42','1','1','2','65568671468107461','0');
INSERT INTO `rlb_custom_program_log` VALUES ('909','6','Valve 2','V','2','2016-07-09 16:37:42','2016-07-09 16:38:42','1','1','2','65568671468107461','0');
INSERT INTO `rlb_custom_program_log` VALUES ('910','1','Valve 3','V','3','2016-07-09 16:39:02','2016-07-09 16:40:02','1','2','2','47807641468107450','0');
INSERT INTO `rlb_custom_program_log` VALUES ('911','1','Valve 4','V','4','2016-07-09 16:40:02','2016-07-09 16:41:02','1','3','1','47807641468107450','0');
INSERT INTO `rlb_custom_program_log` VALUES ('912','6','Valve 5','V','5','2016-07-09 16:39:03','2016-07-09 16:40:03','1','2','1','65568671468107461','0');
INSERT INTO `rlb_custom_program_log` VALUES ('913','6','Valve 6','V','6','2016-07-09 16:39:03','2016-07-09 16:40:03','1','2','1','65568671468107461','0');
INSERT INTO `rlb_custom_program_log` VALUES ('914','6','Valve 6','V','6','2016-07-09 16:39:03','2016-07-09 16:40:03','1','2','1','65568671468107461','0');
INSERT INTO `rlb_custom_program_log` VALUES ('915','1','Valve 0','V','0','2016-07-09 16:40:40','2016-07-09 16:41:40','1','1','2','59998711468107639','0');
INSERT INTO `rlb_custom_program_log` VALUES ('916','3','Valve 0','V','0','2016-07-09 16:40:35','2016-07-09 16:41:35','1','1','1','95696161468107635','0');
INSERT INTO `rlb_custom_program_log` VALUES ('917','3','Valve 4','V','4','2016-07-09 16:40:36','2016-07-09 16:41:36','1','1','1','95696161468107635','0');
INSERT INTO `rlb_custom_program_log` VALUES ('918','3','Valve 4','V','4','2016-07-09 16:40:36','2016-07-09 16:41:36','1','1','1','95696161468107635','0');
INSERT INTO `rlb_custom_program_log` VALUES ('919','6','Valve 1','V','1','2016-07-09 16:40:48','2016-07-09 16:41:48','1','1','2','16789001468107647','0');
INSERT INTO `rlb_custom_program_log` VALUES ('920','6','Valve 2','V','2','2016-07-09 16:40:48','2016-07-09 16:41:48','1','1','2','16789001468107647','0');
INSERT INTO `rlb_custom_program_log` VALUES ('921','6','Valve 2','V','2','2016-07-09 16:40:48','2016-07-09 16:41:48','1','1','2','16789001468107647','0');
INSERT INTO `rlb_custom_program_log` VALUES ('922','1','Valve 3','V','3','2016-07-09 16:42:02','2016-07-09 16:43:02','1','2','2','59998711468107639','0');
INSERT INTO `rlb_custom_program_log` VALUES ('923','3','Valve 0','V','0','2016-07-09 16:42:02','2016-07-09 16:43:02','1','2','2','95696161468107635','0');
INSERT INTO `rlb_custom_program_log` VALUES ('924','6','Valve 5','V','5','2016-07-09 16:42:03','2016-07-09 16:43:03','1','2','1','16789001468107647','0');
INSERT INTO `rlb_custom_program_log` VALUES ('925','6','Valve 6','V','6','2016-07-09 16:42:03','2016-07-09 16:43:03','1','2','1','16789001468107647','0');
INSERT INTO `rlb_custom_program_log` VALUES ('926','6','Valve 6','V','6','2016-07-09 16:42:03','2016-07-09 16:43:03','1','2','1','16789001468107647','0');
INSERT INTO `rlb_custom_program_log` VALUES ('927','1','Valve 4','V','4','2016-07-09 16:43:02','2016-07-09 16:44:02','1','3','1','59998711468107639','0');
INSERT INTO `rlb_custom_program_log` VALUES ('928','3','Valve 4','V','4','2016-07-09 16:43:02','2016-07-09 16:44:02','1','3','2','95696161468107635','0');
INSERT INTO `rlb_custom_program_log` VALUES ('929','3','Valve 5','V','5','2016-07-09 16:43:02','2016-07-09 16:44:02','1','3','2','95696161468107635','0');
INSERT INTO `rlb_custom_program_log` VALUES ('930','3','Valve 5','V','5','2016-07-09 16:43:02','2016-07-09 16:44:02','1','3','2','95696161468107635','0');
INSERT INTO `rlb_custom_program_log` VALUES ('931','1','Valve 4','V','4','2016-07-09 16:44:02','2016-07-09 16:45:02','1','4','2','59998711468107639','0');
INSERT INTO `rlb_custom_program_log` VALUES ('932','1','Valve 5','V','5','2016-07-09 16:45:03','2016-07-09 16:46:03','1','5','2','59998711468107639','0');
INSERT INTO `rlb_custom_program_log` VALUES ('933','1','Valve 5','V','5','2016-07-09 16:47:03','2016-07-09 16:48:03','1','6','1','59998711468107639','0');
INSERT INTO `rlb_custom_program_log` VALUES ('934','1','Valve 6','V','6','2016-07-09 16:47:03','2016-07-09 16:48:03','1','6','1','59998711468107639','0');
INSERT INTO `rlb_custom_program_log` VALUES ('935','1','Valve 6','V','6','2016-07-09 16:47:03','2016-07-09 16:48:03','1','6','1','59998711468107639','0');
INSERT INTO `rlb_custom_program_log` VALUES ('936','1','Pump 2','PS','2','2016-07-09 16:49:03','2016-07-09 16:50:03','1','7','1','59998711468107639','0');
INSERT INTO `rlb_custom_program_log` VALUES ('937','3','Pump 1','PS','1','2016-07-09 16:44:03','2016-07-09 16:54:03','1','4','1','95696161468107635','0');
INSERT INTO `rlb_custom_program_log` VALUES ('938','6','Pump 2','PS','2','2016-07-09 16:43:03','2016-07-09 17:43:03','1','3','1','16789001468107647','0');
INSERT INTO `rlb_custom_program_log` VALUES ('939','1','Relay 15','R','15','2016-07-09 16:49:03','2016-07-09 17:44:03','1','7','1','59998711468107639','0');
INSERT INTO `rlb_custom_program_log` VALUES ('940','1','Power Center 0','P','0','2016-07-09 16:49:03','2016-07-09 17:44:03','1','7','1','59998711468107639','0');
INSERT INTO `rlb_custom_program_log` VALUES ('941','6','Valve 5','V','5','2016-07-09 17:44:03','2016-07-09 17:45:03','1','1','1','16789001468107647','1');
INSERT INTO `rlb_custom_program_log` VALUES ('942','1','Valve 4','V','4','2016-07-09 17:45:03','2016-07-09 17:46:03','1','1','1','59998711468107639','1');
INSERT INTO `rlb_custom_program_log` VALUES ('943','1','Valve 6','V','6','2016-07-09 17:47:02','2016-07-09 17:48:02','1','6','1','59998711468107639','1');
INSERT INTO `rlb_custom_program_log` VALUES ('944','1','Valve 0','V','0','2016-07-09 18:08:23','2016-07-09 18:09:23','1','1','2','44166711468112902','0');
INSERT INTO `rlb_custom_program_log` VALUES ('945','6','Valve 1','V','1','2016-07-09 18:08:53','2016-07-09 18:09:53','1','1','2','32014871468112931','0');
INSERT INTO `rlb_custom_program_log` VALUES ('946','6','Valve 2','V','2','2016-07-09 18:08:54','2016-07-09 18:09:54','1','1','2','32014871468112931','0');
INSERT INTO `rlb_custom_program_log` VALUES ('947','6','Valve 2','V','2','2016-07-09 18:08:54','2016-07-09 18:09:54','1','1','2','32014871468112931','0');
INSERT INTO `rlb_custom_program_log` VALUES ('948','1','Valve 3','V','3','2016-07-09 18:10:02','2016-07-09 18:11:02','1','2','2','44166711468112902','0');
INSERT INTO `rlb_custom_program_log` VALUES ('949','1','Valve 4','V','4','2016-07-09 18:11:02','2016-07-09 18:12:02','1','3','1','44166711468112902','0');
INSERT INTO `rlb_custom_program_log` VALUES ('950','6','Valve 5','V','5','2016-07-09 18:10:03','2016-07-09 18:11:03','1','2','1','32014871468112931','0');
INSERT INTO `rlb_custom_program_log` VALUES ('951','6','Valve 6','V','6','2016-07-09 18:10:03','2016-07-09 18:11:03','1','2','1','32014871468112931','0');
INSERT INTO `rlb_custom_program_log` VALUES ('952','6','Valve 6','V','6','2016-07-09 18:10:03','2016-07-09 18:11:03','1','2','1','32014871468112931','0');
INSERT INTO `rlb_custom_program_log` VALUES ('953','1','Valve 4','V','4','2016-07-09 18:12:04','2016-07-09 18:13:04','1','4','2','44166711468112902','0');
INSERT INTO `rlb_custom_program_log` VALUES ('954','1','Valve 5','V','5','2016-07-09 18:14:02','2016-07-09 18:15:02','1','5','2','44166711468112902','0');
INSERT INTO `rlb_custom_program_log` VALUES ('955','1','Valve 5','V','5','2016-07-09 18:15:04','2016-07-09 18:16:04','1','6','1','44166711468112902','0');
INSERT INTO `rlb_custom_program_log` VALUES ('956','1','Valve 6','V','6','2016-07-09 18:15:04','2016-07-09 18:16:04','1','6','1','44166711468112902','0');
INSERT INTO `rlb_custom_program_log` VALUES ('957','1','Valve 6','V','6','2016-07-09 18:15:04','2016-07-09 18:16:04','1','6','1','44166711468112902','0');
INSERT INTO `rlb_custom_program_log` VALUES ('958','1','Pump 2','PS','2','2016-07-09 18:17:03','2016-07-09 18:18:03','1','7','1','44166711468112902','0');
INSERT INTO `rlb_custom_program_log` VALUES ('959','1','Relay 15','R','15','2016-07-09 18:17:03','2016-07-09 19:12:03','1','7','1','44166711468112902','0');
INSERT INTO `rlb_custom_program_log` VALUES ('960','1','Power Center 0','P','0','2016-07-09 18:17:03','2016-07-09 19:12:03','1','7','1','44166711468112902','0');
INSERT INTO `rlb_custom_program_log` VALUES ('961','6','Pump 2','PS','2','2016-07-09 18:12:04','2016-07-09 19:12:04','1','3','1','32014871468112931','0');
INSERT INTO `rlb_custom_program_log` VALUES ('962','1','Valve 4','V','4','2016-07-09 19:13:02','2016-07-09 19:14:02','1','1','1','44166711468112902','1');
INSERT INTO `rlb_custom_program_log` VALUES ('963','1','Valve 6','V','6','2016-07-09 19:14:02','2016-07-09 19:15:02','1','6','1','44166711468112902','1');
INSERT INTO `rlb_custom_program_log` VALUES ('964','6','Valve 5','V','5','2016-07-09 19:13:03','2016-07-09 19:14:03','1','1','1','32014871468112931','1');
INSERT INTO `rlb_custom_program_log` VALUES ('965','1','Valve 0','V','0','2016-07-11 22:21:03','2016-07-11 22:22:03','1','1','2','41510791468300861','0');
INSERT INTO `rlb_custom_program_log` VALUES ('966','1','Valve 0','V','0','2016-07-11 22:21:03','2016-07-11 22:22:03','1','1','2','41510791468300861','0');
INSERT INTO `rlb_custom_program_log` VALUES ('967','1','Valve 3','V','3','2016-07-11 22:23:02','2016-07-11 22:24:02','1','2','2','41510791468300861','0');
INSERT INTO `rlb_custom_program_log` VALUES ('968','1','Valve 4','V','4','2016-07-11 22:23:02','2016-07-11 22:24:02','1','1','1','41510791468300861','1');
INSERT INTO `rlb_custom_program_log` VALUES ('969','1','Valve 6','V','6','2016-07-11 22:24:02','2016-07-11 22:25:02','1','6','1','41510791468300861','1');
INSERT INTO `rlb_custom_program_log` VALUES ('970','1','Valve 0','V','0','2016-07-11 22:28:05','2016-07-11 22:29:05','1','1','2','91974141468301285','0');
INSERT INTO `rlb_custom_program_log` VALUES ('971','1','Valve 3','V','3','2016-07-11 22:30:02','2016-07-11 22:31:02','1','2','2','91974141468301285','0');
INSERT INTO `rlb_custom_program_log` VALUES ('972','1','Valve 4','V','4','2016-07-11 22:31:02','2016-07-11 22:32:02','1','3','1','91974141468301285','0');
INSERT INTO `rlb_custom_program_log` VALUES ('973','1','Valve 4','V','4','2016-07-11 22:32:02','2016-07-11 22:33:02','1','4','2','91974141468301285','0');
INSERT INTO `rlb_custom_program_log` VALUES ('974','1','Valve 5','V','5','2016-07-11 22:33:02','2016-07-11 22:34:02','1','5','2','91974141468301285','0');
INSERT INTO `rlb_custom_program_log` VALUES ('975','1','Valve 5','V','5','2016-07-11 22:34:02','2016-07-11 22:35:02','1','6','1','91974141468301285','0');
INSERT INTO `rlb_custom_program_log` VALUES ('976','1','Valve 6','V','6','2016-07-11 22:34:03','2016-07-11 22:35:03','1','6','1','91974141468301285','0');
INSERT INTO `rlb_custom_program_log` VALUES ('977','1','Valve 6','V','6','2016-07-11 22:34:03','2016-07-11 22:35:03','1','6','1','91974141468301285','0');
INSERT INTO `rlb_custom_program_log` VALUES ('978','1','Pump 2','PS','2','2016-07-11 22:36:03','2016-07-11 23:31:03','1','7','1','91974141468301285','0');
INSERT INTO `rlb_custom_program_log` VALUES ('979','1','Relay 15','R','15','2016-07-11 22:36:03','2016-07-11 23:31:03','1','7','1','91974141468301285','0');
INSERT INTO `rlb_custom_program_log` VALUES ('980','1','Power Center 0','P','0','2016-07-11 22:36:03','2016-07-11 23:31:03','1','7','1','91974141468301285','0');
INSERT INTO `rlb_custom_program_log` VALUES ('981','1','Valve 4','V','4','2016-07-11 23:32:03','2016-07-11 23:33:03','1','1','1','91974141468301285','1');
INSERT INTO `rlb_custom_program_log` VALUES ('982','1','Valve 6','V','6','2016-07-11 23:34:02','2016-07-11 23:35:02','1','6','1','91974141468301285','1');
INSERT INTO `rlb_custom_program_log` VALUES ('983','45','Valve 5','V','5','2016-07-17 23:42:03','2016-07-17 23:43:03','1','1','1','59288321468824110','0');
INSERT INTO `rlb_custom_program_log` VALUES ('984','45','Valve 5','V','5','2016-07-17 23:43:02','2016-07-17 23:44:02','1','1','1','80454261468824155','0');
INSERT INTO `rlb_custom_program_log` VALUES ('985','45','Valve 6','V','6','2016-07-17 23:44:02','2016-07-17 23:45:02','1','2','1','80454261468824155','0');
INSERT INTO `rlb_custom_program_log` VALUES ('986','45','Valve 2','V','2','2016-07-17 23:44:02','2016-07-17 23:45:02','1','2','2','80454261468824155','0');
INSERT INTO `rlb_custom_program_log` VALUES ('987','45','Valve 2','V','2','2016-07-17 23:44:02','2016-07-17 23:45:02','1','2','2','80454261468824155','0');
INSERT INTO `rlb_custom_program_log` VALUES ('988','45','Valve 0','V','0','2016-07-17 23:45:02','2016-07-17 23:46:02','1','3','2','80454261468824155','0');
INSERT INTO `rlb_custom_program_log` VALUES ('989','45','Valve 3','V','3','2016-07-17 23:45:02','2016-07-17 23:46:02','1','3','2','80454261468824155','0');
INSERT INTO `rlb_custom_program_log` VALUES ('990','45','Valve 3','V','3','2016-07-17 23:45:02','2016-07-17 23:46:02','1','3','2','80454261468824155','0');
INSERT INTO `rlb_custom_program_log` VALUES ('991','45','Valve 4','V','4','2016-07-17 23:46:02','2016-07-17 23:47:02','1','4','1','80454261468824155','0');
INSERT INTO `rlb_custom_program_log` VALUES ('992','45','Valve 5','V','5','2016-07-17 23:46:02','2016-07-17 23:47:02','1','4','2','80454261468824155','0');
INSERT INTO `rlb_custom_program_log` VALUES ('993','45','Valve 5','V','5','2016-07-17 23:46:02','2016-07-17 23:47:02','1','4','2','80454261468824155','0');
INSERT INTO `rlb_custom_program_log` VALUES ('994','45','Valve 4','V','4','2016-07-17 23:47:05','2016-07-17 23:48:05','1','5','2','80454261468824155','0');
INSERT INTO `rlb_custom_program_log` VALUES ('995','45','Valve 5','V','5','2016-07-17 23:48:02','2016-07-17 23:49:02','1','1','1','92163021468824471','0');
INSERT INTO `rlb_custom_program_log` VALUES ('996','45','Valve 6','V','6','2016-07-17 23:49:02','2016-07-17 23:50:02','1','2','1','92163021468824471','0');
INSERT INTO `rlb_custom_program_log` VALUES ('997','45','Valve 2','V','2','2016-07-17 23:49:02','2016-07-17 23:50:02','1','2','2','92163021468824471','0');
INSERT INTO `rlb_custom_program_log` VALUES ('998','45','Valve 2','V','2','2016-07-17 23:49:02','2016-07-17 23:50:02','1','2','2','92163021468824471','0');
INSERT INTO `rlb_custom_program_log` VALUES ('999','45','Valve 0','V','0','2016-07-17 23:50:02','2016-07-17 23:51:02','1','3','2','92163021468824471','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1000','45','Valve 3','V','3','2016-07-17 23:50:02','2016-07-17 23:51:02','1','3','2','92163021468824471','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1001','45','Valve 3','V','3','2016-07-17 23:50:02','2016-07-17 23:51:02','1','3','2','92163021468824471','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1002','45','Valve 4','V','4','2016-07-17 23:51:02','2016-07-17 23:52:02','1','4','1','92163021468824471','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1003','45','Valve 5','V','5','2016-07-17 23:51:03','2016-07-17 23:52:03','1','4','2','92163021468824471','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1004','45','Valve 5','V','5','2016-07-17 23:51:03','2016-07-17 23:52:03','1','4','2','92163021468824471','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1005','45','Valve 4','V','4','2016-07-17 23:53:02','2016-07-17 23:54:02','1','5','2','92163021468824471','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1006','45','Pump 1','PS','1','2016-07-17 23:54:03','2016-07-17 23:55:03','1','6','1','92163021468824471','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1007','45','Valve 2','V','2','2016-07-17 23:56:03','2016-07-17 23:57:03','1','1','2','92163021468824471','1');
INSERT INTO `rlb_custom_program_log` VALUES ('1008','45','Valve 5','V','5','2016-07-17 23:59:02','2016-07-18 00:00:02','1','1','1','15946191468825088','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1009','45','Valve 5','V','5','2016-07-18 00:00:02','2016-07-18 00:01:02','1','1','1','80106881468825188','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1010','45','Valve 5','V','5','2016-07-18 00:01:02','2016-07-18 00:02:02','1','1','1','86919391468825221','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1011','45','Valve 6','V','6','2016-07-18 00:02:02','2016-07-18 00:03:02','1','2','1','86919391468825221','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1012','45','Valve 2','V','2','2016-07-18 00:02:02','2016-07-18 00:03:02','1','2','2','86919391468825221','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1013','45','Valve 2','V','2','2016-07-18 00:02:02','2016-07-18 00:03:02','1','2','2','86919391468825221','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1014','45','Valve 5','V','5','2016-07-18 00:03:03','2016-07-18 00:04:03','1','1','1','98188201468825368','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1015','45','Valve 2','V','2','2016-07-18 00:05:02','2016-07-18 00:06:02','1','1','2','98188201468825368','1');
INSERT INTO `rlb_custom_program_log` VALUES ('1016','45','Valve 5','V','5','2016-07-18 00:07:03','2016-07-18 00:08:03','1','1','1','43641001468825589','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1017','45','Valve 6','V','6','2016-07-18 00:08:03','2016-07-18 00:09:03','1','2','1','43641001468825589','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1018','45','Valve 2','V','2','2016-07-18 00:08:04','2016-07-18 00:09:04','1','2','2','43641001468825589','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1019','45','Valve 2','V','2','2016-07-18 00:08:04','2016-07-18 00:09:04','1','2','2','43641001468825589','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1020','45','Valve 5','V','5','2016-07-18 00:08:38','2016-07-18 00:09:38','1','1','1','31939121468825716','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1021','45','Valve 5','V','5','2016-07-18 00:09:44','2016-07-18 00:10:44','1','1','1','42399741468825783','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1022','45','Valve 6','V','6','2016-07-18 00:11:04','2016-07-18 00:12:04','1','2','1','42399741468825783','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1023','45','Valve 2','V','2','2016-07-18 00:11:04','2016-07-18 00:12:04','1','2','2','42399741468825783','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1024','45','Valve 2','V','2','2016-07-18 00:11:04','2016-07-18 00:12:04','1','2','2','42399741468825783','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1025','45','Valve 2','V','2','2016-07-18 00:12:02','2016-07-18 00:13:02','1','1','2','42399741468825783','1');
INSERT INTO `rlb_custom_program_log` VALUES ('1026','47','Valve 5','V','5','2016-07-18 02:45:03','2016-07-18 02:46:03','1','1','1','81993481468835103','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1027','47','Valve 2','V','2','2016-07-18 02:46:02','2016-07-18 02:47:02','1','1','2','81993481468835103','1');
INSERT INTO `rlb_custom_program_log` VALUES ('1028','47','Valve 5','V','5','2016-07-18 02:50:52','2016-07-18 02:51:52','1','1','1','53174471468835451','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1029','47','Valve 2','V','2','2016-07-18 02:52:02','2016-07-18 02:53:02','1','1','2','53174471468835451','1');
INSERT INTO `rlb_custom_program_log` VALUES ('1030','47','Valve 5','V','5','2016-07-18 04:12:57','2016-07-18 04:13:57','1','1','1','12754701468840376','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1031','47','Valve 6','V','6','2016-07-18 04:14:02','2016-07-18 04:15:02','1','2','1','12754701468840376','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1032','47','Valve 2','V','2','2016-07-18 04:14:02','2016-07-18 04:15:02','1','2','2','12754701468840376','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1033','47','Valve 2','V','2','2016-07-18 04:14:02','2016-07-18 04:15:02','1','2','2','12754701468840376','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1034','47','Valve 0','V','0','2016-07-18 04:15:02','2016-07-18 04:16:02','1','3','2','12754701468840376','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1035','47','Valve 3','V','3','2016-07-18 04:15:02','2016-07-18 04:16:02','1','3','2','12754701468840376','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1036','47','Valve 3','V','3','2016-07-18 04:15:02','2016-07-18 04:16:02','1','3','2','12754701468840376','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1037','47','Valve 4','V','4','2016-07-18 04:16:03','2016-07-18 04:17:03','1','4','1','12754701468840376','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1038','47','Valve 5','V','5','2016-07-18 04:16:03','2016-07-18 04:17:03','1','4','2','12754701468840376','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1039','47','Valve 5','V','5','2016-07-18 04:16:03','2016-07-18 04:17:03','1','4','2','12754701468840376','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1040','47','Valve 4','V','4','2016-07-18 04:18:03','2016-07-18 04:19:03','1','5','2','12754701468840376','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1041','47','Pump 1','PS','1','2016-07-18 04:20:03','2016-07-18 04:21:03','1','6','1','12754701468840376','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1042','47','Valve 2','V','2','2016-07-18 04:22:03','2016-07-18 04:23:03','1','1','2','12754701468840376','1');
INSERT INTO `rlb_custom_program_log` VALUES ('1043','47','Valve 5','V','5','2016-07-18 05:28:06','2016-07-18 05:29:06','1','1','1','41285731468844886','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1044','47','Valve 6','V','6','2016-07-18 05:30:02','2016-07-18 05:31:02','1','2','1','41285731468844886','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1045','47','Valve 2','V','2','2016-07-18 05:30:02','2016-07-18 05:31:02','1','2','2','41285731468844886','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1046','47','Valve 2','V','2','2016-07-18 05:30:02','2016-07-18 05:31:02','1','2','2','41285731468844886','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1047','47','Valve 0','V','0','2016-07-18 05:31:03','2016-07-18 05:32:03','1','3','2','41285731468844886','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1048','47','Valve 3','V','3','2016-07-18 05:31:03','2016-07-18 05:32:03','1','3','2','41285731468844886','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1049','47','Valve 3','V','3','2016-07-18 05:31:03','2016-07-18 05:32:03','1','3','2','41285731468844886','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1050','47','Valve 4','V','4','2016-07-18 05:33:03','2016-07-18 05:34:03','1','4','1','41285731468844886','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1051','47','Valve 5','V','5','2016-07-18 05:33:03','2016-07-18 05:34:03','1','4','2','41285731468844886','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1052','47','Valve 5','V','5','2016-07-18 05:33:03','2016-07-18 05:34:03','1','4','2','41285731468844886','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1053','47','Valve 4','V','4','2016-07-18 05:35:03','2016-07-18 05:36:03','1','5','2','41285731468844886','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1054','47','Pump 1','PS','1','2016-07-18 05:37:03','2016-07-18 05:38:03','1','6','1','41285731468844886','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1055','47','Valve 2','V','2','2016-07-18 05:39:03','2016-07-18 05:40:03','1','1','2','41285731468844886','1');
INSERT INTO `rlb_custom_program_log` VALUES ('1056','47','Valve 5','V','5','2016-07-18 05:44:09','2016-07-18 05:45:09','1','1','1','83899481468845848','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1057','47','Valve 6','V','6','2016-07-18 05:46:02','2016-07-18 05:47:02','1','2','1','83899481468845848','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1058','47','Valve 2','V','2','2016-07-18 05:46:02','2016-07-18 05:47:02','1','2','2','83899481468845848','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1059','47','Valve 2','V','2','2016-07-18 05:46:02','2016-07-18 05:47:02','1','2','2','83899481468845848','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1060','47','Valve 0','V','0','2016-07-18 05:48:02','2016-07-18 05:49:02','1','3','2','83899481468845848','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1061','47','Valve 3','V','3','2016-07-18 05:48:02','2016-07-18 05:49:02','1','3','2','83899481468845848','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1062','47','Valve 3','V','3','2016-07-18 05:48:02','2016-07-18 05:49:02','1','3','2','83899481468845848','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1063','47','Valve 4','V','4','2016-07-18 05:49:03','2016-07-18 05:50:03','1','4','1','83899481468845848','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1064','47','Valve 5','V','5','2016-07-18 05:49:03','2016-07-18 05:50:03','1','4','2','83899481468845848','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1065','47','Valve 5','V','5','2016-07-18 05:49:03','2016-07-18 05:50:03','1','4','2','83899481468845848','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1066','47','Valve 4','V','4','2016-07-18 05:51:03','2016-07-18 05:52:03','1','5','2','83899481468845848','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1067','47','Pump 1','PS','1','2016-07-18 05:53:03','2016-07-18 05:54:03','1','6','1','83899481468845848','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1068','47','Valve 2','V','2','2016-07-18 05:55:03','2016-07-18 05:56:03','1','1','2','83899481468845848','1');
INSERT INTO `rlb_custom_program_log` VALUES ('1069','47','Valve 5','V','5','2016-07-18 06:38:02','2016-07-18 06:39:02','1','1','1','99244581468849080','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1070','47','Valve 5','V','5','2016-07-18 06:38:03','2016-07-18 06:39:03','1','1','1','99244581468849080','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1071','47','Valve 6','V','6','2016-07-18 06:39:02','2016-07-18 06:40:02','1','2','1','99244581468849080','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1072','47','Valve 2','V','2','2016-07-18 06:39:02','2016-07-18 06:40:02','1','2','2','99244581468849080','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1073','47','Valve 2','V','2','2016-07-18 06:39:02','2016-07-18 06:40:02','1','2','2','99244581468849080','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1074','47','Valve 0','V','0','2016-07-18 06:40:03','2016-07-18 06:41:03','1','3','2','99244581468849080','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1075','47','Valve 3','V','3','2016-07-18 06:40:03','2016-07-18 06:41:03','1','3','2','99244581468849080','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1076','47','Valve 3','V','3','2016-07-18 06:40:03','2016-07-18 06:41:03','1','3','2','99244581468849080','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1077','47','Valve 4','V','4','2016-07-18 06:42:03','2016-07-18 06:43:03','1','4','1','99244581468849080','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1078','47','Valve 5','V','5','2016-07-18 06:42:03','2016-07-18 06:43:03','1','4','2','99244581468849080','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1079','47','Valve 5','V','5','2016-07-18 06:42:03','2016-07-18 06:43:03','1','4','2','99244581468849080','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1080','47','Valve 4','V','4','2016-07-18 06:44:03','2016-07-18 06:45:03','1','5','2','99244581468849080','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1081','47','Pump 1','PS','1','2016-07-18 06:46:03','2016-07-18 06:47:03','1','6','1','99244581468849080','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1082','47','Valve 2','V','2','2016-07-18 06:47:02','2016-07-18 06:48:02','1','1','2','99244581468849080','1');
INSERT INTO `rlb_custom_program_log` VALUES ('1083','47','Valve 5','V','5','2016-07-18 06:49:22','2016-07-18 06:50:22','1','1','1','29950871468849759','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1084','47','Valve 2','V','2','2016-07-18 06:50:02','2016-07-18 06:51:02','1','1','2','29950871468849759','1');
INSERT INTO `rlb_custom_program_log` VALUES ('1085','47','Valve 5','V','5','2016-07-18 06:50:11','2016-07-18 06:51:11','1','1','1','99350141468849810','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1086','47','Valve 5','V','5','2016-07-18 06:51:50','2016-07-18 06:52:50','1','1','1','87236771468849910','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1087','47','Valve 5','V','5','2016-07-18 06:52:39','2016-07-18 06:53:39','1','1','1','10874121468849959','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1088','47','Valve 5','V','5','2016-07-18 06:53:55','2016-07-18 06:54:55','1','1','1','69515721468850034','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1089','47','Valve 2','V','2','2016-07-18 06:55:02','2016-07-18 06:56:02','1','1','2','69515721468850034','1');
INSERT INTO `rlb_custom_program_log` VALUES ('1090','45','Valve 5','V','5','2016-07-18 08:19:32','2016-07-18 08:20:32','1','1','1','21866071468855171','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1091','45','Valve 6','V','6','2016-07-18 08:21:02','2016-07-18 08:22:02','1','2','1','21866071468855171','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1092','45','Valve 2','V','2','2016-07-18 08:21:02','2016-07-18 08:22:02','1','2','2','21866071468855171','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1093','45','Valve 2','V','2','2016-07-18 08:21:02','2016-07-18 08:22:02','1','2','2','21866071468855171','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1094','45','Valve 0','V','0','2016-07-18 08:22:02','2016-07-18 08:23:02','1','3','2','21866071468855171','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1095','45','Valve 3','V','3','2016-07-18 08:22:02','2016-07-18 08:23:02','1','3','2','21866071468855171','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1096','45','Valve 3','V','3','2016-07-18 08:22:02','2016-07-18 08:23:02','1','3','2','21866071468855171','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1097','45','Valve 4','V','4','2016-07-18 08:23:03','2016-07-18 08:24:03','1','4','1','21866071468855171','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1098','45','Valve 5','V','5','2016-07-18 08:23:03','2016-07-18 08:24:03','1','4','2','21866071468855171','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1099','45','Valve 5','V','5','2016-07-18 08:23:03','2016-07-18 08:24:03','1','4','2','21866071468855171','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1100','45','Valve 4','V','4','2016-07-18 08:25:03','2016-07-18 08:26:03','1','5','2','21866071468855171','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1101','45','Pump 1','PS','1','2016-07-18 08:27:03','2016-07-18 08:28:03','1','6','1','21866071468855171','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1102','45','Valve 2','V','2','2016-07-18 08:29:03','2016-07-18 08:30:03','1','1','2','21866071468855171','1');
INSERT INTO `rlb_custom_program_log` VALUES ('1103','47','Valve 5','V','5','2016-07-18 22:15:03','2016-07-18 22:16:03','1','1','1','85227751468905302','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1104','47','Valve 5','V','5','2016-07-18 22:15:35','2016-07-18 22:16:35','1','1','1','44404931468905335','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1105','47','Valve 5','V','5','2016-07-18 22:16:21','2016-07-18 22:17:21','1','1','1','21448931468905381','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1106','47','Valve 6','V','6','2016-07-18 22:18:02','2016-07-18 22:19:02','1','2','1','21448931468905381','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1107','47','Valve 2','V','2','2016-07-18 22:18:02','2016-07-18 22:19:02','1','2','2','21448931468905381','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1108','47','Valve 2','V','2','2016-07-18 22:18:02','2016-07-18 22:19:02','1','2','2','21448931468905381','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1109','47','Valve 0','V','0','2016-07-18 22:19:03','2016-07-18 22:20:03','1','3','2','21448931468905381','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1110','47','Valve 3','V','3','2016-07-18 22:19:03','2016-07-18 22:20:03','1','3','2','21448931468905381','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1111','47','Valve 3','V','3','2016-07-18 22:19:03','2016-07-18 22:20:03','1','3','2','21448931468905381','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1112','47','Valve 4','V','4','2016-07-18 22:21:02','2016-07-18 22:22:02','1','4','1','21448931468905381','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1113','47','Valve 5','V','5','2016-07-18 22:21:02','2016-07-18 22:22:02','1','4','2','21448931468905381','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1114','47','Valve 5','V','5','2016-07-18 22:21:02','2016-07-18 22:22:02','1','4','2','21448931468905381','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1115','47','Valve 4','V','4','2016-07-18 22:22:03','2016-07-18 22:23:03','1','5','2','21448931468905381','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1116','47','Pump 1','PS','1','2016-07-18 22:24:03','2016-07-18 22:25:03','1','6','1','21448931468905381','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1117','47','Valve 5','V','5','2016-07-18 22:25:24','2016-07-18 22:26:24','1','1','1','17327241468905924','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1118','47','Valve 5','V','5','2016-07-18 22:26:56','2016-07-18 22:27:56','1','1','1','59510561468906015','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1119','47','Valve 6','V','6','2016-07-18 22:28:02','2016-07-18 22:29:02','1','2','1','59510561468906015','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1120','47','Valve 2','V','2','2016-07-18 22:28:02','2016-07-18 22:29:02','1','2','2','59510561468906015','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1121','47','Valve 2','V','2','2016-07-18 22:28:02','2016-07-18 22:29:02','1','2','2','59510561468906015','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1122','47','Valve 0','V','0','2016-07-18 22:30:02','2016-07-18 22:31:02','1','3','2','59510561468906015','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1123','47','Valve 3','V','3','2016-07-18 22:30:02','2016-07-18 22:31:02','1','3','2','59510561468906015','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1124','47','Valve 3','V','3','2016-07-18 22:30:02','2016-07-18 22:31:02','1','3','2','59510561468906015','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1125','47','Valve 4','V','4','2016-07-18 22:32:02','2016-07-18 22:33:02','1','4','1','59510561468906015','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1126','47','Valve 5','V','5','2016-07-18 22:32:02','2016-07-18 22:33:02','1','4','2','59510561468906015','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1127','47','Valve 5','V','5','2016-07-18 22:32:02','2016-07-18 22:33:02','1','4','2','59510561468906015','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1128','47','Valve 4','V','4','2016-07-18 22:33:02','2016-07-18 22:34:02','1','5','2','59510561468906015','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1129','47','Pump 1','PS','1','2016-07-18 22:34:02','2016-07-18 22:35:02','1','6','1','59510561468906015','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1130','47','Valve 2','V','2','2016-07-18 22:35:03','2016-07-18 22:36:03','1','1','2','59510561468906015','1');
INSERT INTO `rlb_custom_program_log` VALUES ('1131','47','Valve 5','V','5','2016-07-18 23:41:41','2016-07-18 23:42:41','1','1','1','71974981468910500','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1132','47','Valve 6','V','6','2016-07-18 23:43:02','2016-07-18 23:44:02','1','2','1','71974981468910500','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1133','47','Valve 2','V','2','2016-07-18 23:43:02','2016-07-18 23:44:02','1','2','2','71974981468910500','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1134','47','Valve 2','V','2','2016-07-18 23:43:02','2016-07-18 23:44:02','1','2','2','71974981468910500','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1135','47','Valve 0','V','0','2016-07-18 23:44:03','2016-07-18 23:45:03','1','3','2','71974981468910500','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1136','47','Valve 3','V','3','2016-07-18 23:44:03','2016-07-18 23:45:03','1','3','2','71974981468910500','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1137','47','Valve 3','V','3','2016-07-18 23:44:03','2016-07-18 23:45:03','1','3','2','71974981468910500','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1138','47','Valve 5','V','5','2016-07-18 23:44:53','2016-07-18 23:45:53','1','1','1','98387661468910692','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1139','47','Valve 6','V','6','2016-07-18 23:46:02','2016-07-18 23:47:02','1','2','1','98387661468910692','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1140','47','Valve 2','V','2','2016-07-18 23:46:02','2016-07-18 23:47:02','1','2','2','98387661468910692','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1141','47','Valve 2','V','2','2016-07-18 23:46:02','2016-07-18 23:47:02','1','2','2','98387661468910692','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1142','47','Valve 5','V','5','2016-07-18 23:46:53','2016-07-18 23:47:53','1','1','1','34484791468910813','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1143','47','Valve 6','V','6','2016-07-18 23:48:02','2016-07-18 23:49:02','1','2','1','34484791468910813','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1144','47','Valve 2','V','2','2016-07-18 23:48:02','2016-07-18 23:49:02','1','2','2','34484791468910813','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1145','47','Valve 2','V','2','2016-07-18 23:48:02','2016-07-18 23:49:02','1','2','2','34484791468910813','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1146','47','Valve 0','V','0','2016-07-18 23:49:03','2016-07-18 23:50:03','1','3','2','34484791468910813','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1147','47','Valve 3','V','3','2016-07-18 23:49:03','2016-07-18 23:50:03','1','3','2','34484791468910813','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1148','47','Valve 3','V','3','2016-07-18 23:49:03','2016-07-18 23:50:03','1','3','2','34484791468910813','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1149','47','Valve 4','V','4','2016-07-18 23:51:03','2016-07-18 23:52:03','1','4','1','34484791468910813','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1150','47','Valve 5','V','5','2016-07-18 23:51:03','2016-07-18 23:52:03','1','4','2','34484791468910813','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1151','47','Valve 5','V','5','2016-07-18 23:51:03','2016-07-18 23:52:03','1','4','2','34484791468910813','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1152','47','Valve 4','V','4','2016-07-18 23:53:03','2016-07-18 23:54:03','1','5','2','34484791468910813','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1153','47','Valve 5','V','5','2016-07-18 23:53:13','2016-07-18 23:54:13','1','1','1','94786121468911193','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1154','47','Valve 6','V','6','2016-07-18 23:55:02','2016-07-18 23:56:02','1','2','1','94786121468911193','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1155','47','Valve 2','V','2','2016-07-18 23:55:03','2016-07-18 23:56:03','1','2','2','94786121468911193','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1156','47','Valve 2','V','2','2016-07-18 23:55:03','2016-07-18 23:56:03','1','2','2','94786121468911193','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1157','47','Valve 5','V','5','2016-07-18 23:56:51','2016-07-18 23:57:51','1','1','1','32198651468911411','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1158','47','Valve 2','V','2','2016-07-18 23:57:02','2016-07-18 23:58:02','1','1','2','32198651468911411','1');
INSERT INTO `rlb_custom_program_log` VALUES ('1159','45','Valve 5','V','5','2016-07-19 00:03:21','2016-07-19 00:04:21','1','1','1','32009481468911799','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1160','45','Valve 2','V','2','2016-07-19 00:04:02','2016-07-19 00:05:02','1','1','2','32009481468911799','1');
INSERT INTO `rlb_custom_program_log` VALUES ('1161','47','Valve 5','V','5','2016-07-19 00:11:35','2016-07-19 00:12:35','1','1','1','98742691468912294','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1162','47','Valve 2','V','2','2016-07-19 00:12:02','2016-07-19 00:13:02','1','1','2','98742691468912294','1');
INSERT INTO `rlb_custom_program_log` VALUES ('1163','47','Valve 5','V','5','2016-07-19 00:25:41','2016-07-19 00:26:41','1','1','1','15049831468913139','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1164','47','Valve 2','V','2','2016-07-19 00:26:03','2016-07-19 00:27:03','1','1','2','15049831468913139','1');
INSERT INTO `rlb_custom_program_log` VALUES ('1165','47','Valve 5','V','5','2016-07-19 00:30:20','2016-07-19 00:31:20','1','1','1','53368421468913419','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1166','47','Valve 2','V','2','2016-07-19 00:31:02','2016-07-19 00:32:02','1','1','2','53368421468913419','1');
INSERT INTO `rlb_custom_program_log` VALUES ('1167','47','Valve 5','V','5','2016-07-19 01:23:33','2016-07-19 01:24:33','1','1','1','49115861468916612','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1168','47','Valve 2','V','2','2016-07-19 01:24:02','2016-07-19 01:25:02','1','1','2','49115861468916612','1');
INSERT INTO `rlb_custom_program_log` VALUES ('1169','47','Valve 5','V','5','2016-07-19 01:34:47','2016-07-19 01:35:47','1','1','1','93036991468917286','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1170','47','Valve 6','V','6','2016-07-19 01:36:02','2016-07-19 01:37:02','1','2','1','93036991468917286','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1171','47','Valve 2','V','2','2016-07-19 01:36:03','2016-07-19 01:37:03','1','2','2','93036991468917286','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1172','47','Valve 2','V','2','2016-07-19 01:36:03','2016-07-19 01:37:03','1','2','2','93036991468917286','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1173','47','Valve 0','V','0','2016-07-19 01:38:02','2016-07-19 01:39:02','1','3','2','93036991468917286','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1174','47','Valve 3','V','3','2016-07-19 01:38:02','2016-07-19 01:39:02','1','3','2','93036991468917286','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1175','47','Valve 3','V','3','2016-07-19 01:38:02','2016-07-19 01:39:02','1','3','2','93036991468917286','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1176','47','Valve 4','V','4','2016-07-19 01:39:05','2016-07-19 01:40:05','1','4','1','93036991468917286','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1177','47','Valve 5','V','5','2016-07-19 01:39:05','2016-07-19 01:40:05','1','4','2','93036991468917286','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1178','47','Valve 5','V','5','2016-07-19 01:39:05','2016-07-19 01:40:05','1','4','2','93036991468917286','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1179','47','Valve 4','V','4','2016-07-19 01:41:02','2016-07-19 01:42:02','1','5','2','93036991468917286','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1180','47','Pump 1','PS','1','2016-07-19 01:42:02','2016-07-19 01:43:02','1','6','1','93036991468917286','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1181','47','Valve 2','V','2','2016-07-19 01:44:02','2016-07-19 01:45:02','1','1','2','93036991468917286','1');
INSERT INTO `rlb_custom_program_log` VALUES ('1182','47','Valve 5','V','5','2016-07-19 01:47:54','2016-07-19 01:48:54','1','1','1','96285961468918073','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1183','47','Valve 6','V','6','2016-07-19 01:49:01','2016-07-19 01:50:01','1','2','1','96285961468918073','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1184','47','Valve 2','V','2','2016-07-19 01:49:01','2016-07-19 01:50:01','1','2','2','96285961468918073','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1185','47','Valve 2','V','2','2016-07-19 01:49:01','2016-07-19 01:50:01','1','2','2','96285961468918073','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1186','47','Valve 0','V','0','2016-07-19 01:50:02','2016-07-19 01:51:02','1','3','2','96285961468918073','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1187','47','Valve 3','V','3','2016-07-19 01:50:02','2016-07-19 01:51:02','1','3','2','96285961468918073','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1188','47','Valve 3','V','3','2016-07-19 01:50:02','2016-07-19 01:51:02','1','3','2','96285961468918073','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1189','47','Valve 4','V','4','2016-07-19 01:51:02','2016-07-19 01:52:02','1','4','1','96285961468918073','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1190','47','Valve 5','V','5','2016-07-19 01:51:02','2016-07-19 01:52:02','1','4','2','96285961468918073','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1191','47','Valve 5','V','5','2016-07-19 01:51:02','2016-07-19 01:52:02','1','4','2','96285961468918073','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1192','47','Valve 4','V','4','2016-07-19 01:52:02','2016-07-19 01:53:02','1','5','2','96285961468918073','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1193','47','Pump 1','PS','1','2016-07-19 01:53:03','2016-07-19 01:54:03','1','6','1','96285961468918073','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1194','47','Valve 2','V','2','2016-07-19 01:55:03','2016-07-19 01:56:03','1','1','2','96285961468918073','1');
INSERT INTO `rlb_custom_program_log` VALUES ('1195','47','Valve 5','V','5','2016-07-19 02:05:24','2016-07-19 02:06:24','1','1','1','37667291468919123','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1196','47','Valve 6','V','6','2016-07-19 02:07:03','2016-07-19 02:08:03','1','2','1','37667291468919123','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1197','47','Valve 2','V','2','2016-07-19 02:07:03','2016-07-19 02:08:03','1','2','2','37667291468919123','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1198','47','Valve 2','V','2','2016-07-19 02:07:03','2016-07-19 02:08:03','1','2','2','37667291468919123','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1199','47','Valve 0','V','0','2016-07-19 02:09:03','2016-07-19 02:10:03','1','3','2','37667291468919123','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1200','47','Valve 3','V','3','2016-07-19 02:09:03','2016-07-19 02:10:03','1','3','2','37667291468919123','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1201','47','Valve 3','V','3','2016-07-19 02:09:03','2016-07-19 02:10:03','1','3','2','37667291468919123','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1202','47','Valve 4','V','4','2016-07-19 02:11:02','2016-07-19 02:12:02','1','4','1','37667291468919123','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1203','47','Valve 5','V','5','2016-07-19 02:11:02','2016-07-19 02:12:02','1','4','2','37667291468919123','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1204','47','Valve 5','V','5','2016-07-19 02:11:02','2016-07-19 02:12:02','1','4','2','37667291468919123','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1205','47','Valve 4','V','4','2016-07-19 02:12:03','2016-07-19 02:13:03','1','5','2','37667291468919123','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1206','47','Pump 1','PS','1','2016-07-19 02:14:02','2016-07-19 02:15:02','1','6','1','37667291468919123','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1207','47','Valve 2','V','2','2016-07-19 02:15:03','2016-07-19 02:16:03','1','1','2','37667291468919123','1');
INSERT INTO `rlb_custom_program_log` VALUES ('1208','47','Valve 5','V','5','2016-07-19 02:16:02','2016-07-19 02:17:02','1','1','1','41881401468919761','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1209','47','Valve 6','V','6','2016-07-19 02:17:02','2016-07-19 02:18:02','1','2','1','41881401468919761','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1210','47','Valve 2','V','2','2016-07-19 02:17:02','2016-07-19 02:18:02','1','2','2','41881401468919761','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1211','47','Valve 2','V','2','2016-07-19 02:17:02','2016-07-19 02:18:02','1','2','2','41881401468919761','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1212','47','Valve 0','V','0','2016-07-19 02:19:02','2016-07-19 02:20:02','1','3','2','41881401468919761','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1213','47','Valve 3','V','3','2016-07-19 02:19:02','2016-07-19 02:20:02','1','3','2','41881401468919761','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1214','47','Valve 3','V','3','2016-07-19 02:19:02','2016-07-19 02:20:02','1','3','2','41881401468919761','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1215','47','Valve 4','V','4','2016-07-19 02:21:03','2016-07-19 02:22:03','1','4','1','41881401468919761','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1216','47','Valve 5','V','5','2016-07-19 02:21:03','2016-07-19 02:22:03','1','4','2','41881401468919761','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1217','47','Valve 5','V','5','2016-07-19 02:21:03','2016-07-19 02:22:03','1','4','2','41881401468919761','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1218','47','Valve 4','V','4','2016-07-19 02:23:03','2016-07-19 02:24:03','1','5','2','41881401468919761','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1219','47','Pump 1','PS','1','2016-07-19 02:25:03','2016-07-19 02:26:03','1','6','1','41881401468919761','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1220','47','Valve 2','V','2','2016-07-19 02:27:03','2016-07-19 02:28:03','1','1','2','41881401468919761','1');
INSERT INTO `rlb_custom_program_log` VALUES ('1221','47','Valve 5','V','5','2016-07-19 02:34:42','2016-07-19 02:35:42','1','1','1','50747211468920882','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1222','47','Valve 6','V','6','2016-07-19 02:36:03','2016-07-19 02:37:03','1','2','1','50747211468920882','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1223','47','Valve 2','V','2','2016-07-19 02:36:03','2016-07-19 02:37:03','1','2','2','50747211468920882','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1224','47','Valve 2','V','2','2016-07-19 02:36:03','2016-07-19 02:37:03','1','2','2','50747211468920882','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1225','47','Valve 0','V','0','2016-07-19 02:38:03','2016-07-19 02:39:03','1','3','2','50747211468920882','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1226','47','Valve 3','V','3','2016-07-19 02:38:03','2016-07-19 02:39:03','1','3','2','50747211468920882','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1227','47','Valve 3','V','3','2016-07-19 02:38:03','2016-07-19 02:39:03','1','3','2','50747211468920882','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1228','47','Valve 4','V','4','2016-07-19 02:40:03','2016-07-19 02:41:03','1','4','1','50747211468920882','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1229','47','Valve 5','V','5','2016-07-19 02:40:03','2016-07-19 02:41:03','1','4','2','50747211468920882','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1230','47','Valve 5','V','5','2016-07-19 02:40:03','2016-07-19 02:41:03','1','4','2','50747211468920882','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1231','47','Valve 4','V','4','2016-07-19 02:42:03','2016-07-19 02:43:03','1','5','2','50747211468920882','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1232','47','Pump 1','PS','1','2016-07-19 02:44:03','2016-07-19 02:45:03','1','6','1','50747211468920882','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1233','47','Valve 2','V','2','2016-07-19 02:46:03','2016-07-19 02:47:03','1','1','2','50747211468920882','1');
INSERT INTO `rlb_custom_program_log` VALUES ('1234','47','Valve 5','V','5','2016-07-19 02:56:07','2016-07-19 02:57:07','1','1','1','14971791468922167','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1235','47','Valve 6','V','6','2016-07-19 02:58:02','2016-07-19 02:59:02','1','2','1','14971791468922167','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1236','47','Valve 2','V','2','2016-07-19 02:58:02','2016-07-19 02:59:02','1','2','2','14971791468922167','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1237','47','Valve 2','V','2','2016-07-19 02:58:02','2016-07-19 02:59:02','1','2','2','14971791468922167','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1238','47','Valve 0','V','0','2016-07-19 02:59:02','2016-07-19 03:00:02','1','3','2','14971791468922167','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1239','47','Valve 3','V','3','2016-07-19 02:59:02','2016-07-19 03:00:02','1','3','2','14971791468922167','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1240','47','Valve 3','V','3','2016-07-19 02:59:02','2016-07-19 03:00:02','1','3','2','14971791468922167','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1241','47','Valve 4','V','4','2016-07-19 03:00:02','2016-07-19 03:01:02','1','4','1','14971791468922167','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1242','47','Valve 5','V','5','2016-07-19 03:00:02','2016-07-19 03:01:02','1','4','2','14971791468922167','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1243','47','Valve 5','V','5','2016-07-19 03:00:02','2016-07-19 03:01:02','1','4','2','14971791468922167','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1244','47','Valve 4','V','4','2016-07-19 03:01:02','2016-07-19 03:02:02','1','5','2','14971791468922167','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1245','47','Pump 1','PS','1','2016-07-19 03:02:36','2016-07-19 03:03:36','1','6','1','14971791468922167','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1246','47','Valve 2','V','2','2016-07-19 03:04:03','2016-07-19 03:05:03','1','1','2','14971791468922167','1');
INSERT INTO `rlb_custom_program_log` VALUES ('1247','47','Valve 5','V','5','2016-07-19 03:05:54','2016-07-19 03:06:54','1','1','1','64361081468922753','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1248','47','Valve 6','V','6','2016-07-19 03:07:02','2016-07-19 03:08:02','1','2','1','64361081468922753','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1249','47','Valve 2','V','2','2016-07-19 03:07:02','2016-07-19 03:08:02','1','2','2','64361081468922753','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1250','47','Valve 2','V','2','2016-07-19 03:07:02','2016-07-19 03:08:02','1','2','2','64361081468922753','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1251','47','Valve 0','V','0','2016-07-19 03:08:03','2016-07-19 03:09:03','1','3','2','64361081468922753','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1252','47','Valve 3','V','3','2016-07-19 03:08:03','2016-07-19 03:09:03','1','3','2','64361081468922753','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1253','47','Valve 3','V','3','2016-07-19 03:08:03','2016-07-19 03:09:03','1','3','2','64361081468922753','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1254','47','Valve 4','V','4','2016-07-19 03:10:02','2016-07-19 03:11:02','1','4','1','64361081468922753','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1255','47','Valve 5','V','5','2016-07-19 03:10:02','2016-07-19 03:11:02','1','4','2','64361081468922753','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1256','47','Valve 5','V','5','2016-07-19 03:10:02','2016-07-19 03:11:02','1','4','2','64361081468922753','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1257','47','Valve 4','V','4','2016-07-19 03:11:02','2016-07-19 03:12:02','1','5','2','64361081468922753','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1258','47','Pump 1','PS','1','2016-07-19 03:12:03','2016-07-19 03:13:03','1','6','1','64361081468922753','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1259','47','Valve 2','V','2','2016-07-19 03:14:02','2016-07-19 03:15:02','1','1','2','64361081468922753','1');
INSERT INTO `rlb_custom_program_log` VALUES ('1260','47','Valve 5','V','5','2016-07-19 03:15:20','2016-07-19 03:16:20','1','1','1','58240271468923320','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1261','47','Valve 6','V','6','2016-07-19 03:17:02','2016-07-19 03:18:02','1','2','1','58240271468923320','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1262','47','Valve 2','V','2','2016-07-19 03:17:02','2016-07-19 03:18:02','1','2','2','58240271468923320','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1263','47','Valve 2','V','2','2016-07-19 03:17:02','2016-07-19 03:18:02','1','2','2','58240271468923320','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1264','47','Valve 0','V','0','2016-07-19 03:18:03','2016-07-19 03:19:03','1','3','2','58240271468923320','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1265','47','Valve 3','V','3','2016-07-19 03:18:03','2016-07-19 03:19:03','1','3','2','58240271468923320','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1266','47','Valve 3','V','3','2016-07-19 03:18:03','2016-07-19 03:19:03','1','3','2','58240271468923320','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1267','47','Valve 4','V','4','2016-07-19 03:20:03','2016-07-19 03:21:03','1','4','1','58240271468923320','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1268','47','Valve 5','V','5','2016-07-19 03:20:03','2016-07-19 03:21:03','1','4','2','58240271468923320','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1269','47','Valve 5','V','5','2016-07-19 03:20:03','2016-07-19 03:21:03','1','4','2','58240271468923320','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1270','47','Valve 4','V','4','2016-07-19 03:22:02','2016-07-19 03:23:02','1','5','2','58240271468923320','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1271','47','Pump 1','PS','1','2016-07-19 03:23:02','2016-07-19 03:24:02','1','6','1','58240271468923320','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1272','47','Valve 2','V','2','2016-07-19 03:24:03','2016-07-19 03:25:03','1','1','2','58240271468923320','1');
INSERT INTO `rlb_custom_program_log` VALUES ('1273','45','Valve 5','V','5','2016-07-19 03:56:27','2016-07-19 03:57:27','1','1','1','86345481468925787','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1274','45','Valve 2','V','2','2016-07-19 03:57:02','2016-07-19 03:58:02','1','1','2','86345481468925787','1');
INSERT INTO `rlb_custom_program_log` VALUES ('1275','47','Valve 5','V','5','2016-07-19 22:29:26','2016-07-19 22:30:26','1','1','1','46055411468992566','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1276','47','Valve 6','V','6','2016-07-19 22:31:03','2016-07-19 22:32:03','1','2','1','46055411468992566','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1277','47','Valve 2','V','2','2016-07-19 22:31:03','2016-07-19 22:32:03','1','2','2','46055411468992566','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1278','47','Valve 2','V','2','2016-07-19 22:31:03','2016-07-19 22:32:03','1','2','2','46055411468992566','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1279','47','Valve 0','V','0','2016-07-19 22:33:03','2016-07-19 22:34:03','1','3','2','46055411468992566','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1280','47','Valve 3','V','3','2016-07-19 22:33:03','2016-07-19 22:34:03','1','3','2','46055411468992566','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1281','47','Valve 3','V','3','2016-07-19 22:33:03','2016-07-19 22:34:03','1','3','2','46055411468992566','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1282','47','Valve 4','V','4','2016-07-19 22:35:09','2016-07-19 22:36:09','1','4','1','46055411468992566','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1283','47','Valve 5','V','5','2016-07-19 22:35:09','2016-07-19 22:36:09','1','4','2','46055411468992566','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1284','47','Valve 5','V','5','2016-07-19 22:35:09','2016-07-19 22:36:09','1','4','2','46055411468992566','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1285','47','Valve 4','V','4','2016-07-19 22:37:04','2016-07-19 22:38:04','1','5','2','46055411468992566','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1286','47','Pump 1','PS','1','2016-07-19 22:39:03','2016-07-19 22:40:03','1','6','1','46055411468992566','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1287','47','Valve 2','V','2','2016-07-19 22:41:03','2016-07-19 22:42:03','1','1','2','46055411468992566','1');
INSERT INTO `rlb_custom_program_log` VALUES ('1288','47','Valve 4','V','4','2016-07-19 22:43:02','2016-07-19 22:44:02','1','4','1','46055411468992566','1');
INSERT INTO `rlb_custom_program_log` VALUES ('1289','47','Valve 5','V','5','2016-07-19 22:44:08','2016-07-19 22:45:08','1','1','1','95545851468993447','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1290','47','Valve 6','V','6','2016-07-19 22:46:02','2016-07-19 22:47:02','1','2','1','95545851468993447','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1291','47','Valve 2','V','2','2016-07-19 22:46:02','2016-07-19 22:47:02','1','2','2','95545851468993447','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1292','47','Valve 2','V','2','2016-07-19 22:46:02','2016-07-19 22:47:02','1','2','2','95545851468993447','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1293','47','Valve 0','V','0','2016-07-19 22:47:02','2016-07-19 22:48:02','1','3','2','95545851468993447','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1294','47','Valve 3','V','3','2016-07-19 22:47:02','2016-07-19 22:48:02','1','3','2','95545851468993447','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1295','47','Valve 3','V','3','2016-07-19 22:47:02','2016-07-19 22:48:02','1','3','2','95545851468993447','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1296','47','Valve 4','V','4','2016-07-19 22:49:02','2016-07-19 22:50:02','1','4','1','95545851468993447','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1297','47','Valve 5','V','5','2016-07-19 22:49:02','2016-07-19 22:50:02','1','4','2','95545851468993447','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1298','47','Valve 5','V','5','2016-07-19 22:49:02','2016-07-19 22:50:02','1','4','2','95545851468993447','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1299','47','Valve 4','V','4','2016-07-19 22:50:03','2016-07-19 22:51:03','1','5','2','95545851468993447','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1300','47','Pump 1','PS','1','2016-07-19 22:52:02','2016-07-19 22:53:02','1','6','1','95545851468993447','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1301','47','Valve 2','V','2','2016-07-19 22:54:02','2016-07-19 22:55:02','1','1','2','95545851468993447','1');
INSERT INTO `rlb_custom_program_log` VALUES ('1302','47','Valve 4','V','4','2016-07-19 22:56:02','2016-07-19 22:57:02','1','4','1','95545851468993447','1');
INSERT INTO `rlb_custom_program_log` VALUES ('1303','47','Valve 5','V','5','2016-07-19 22:58:20','2016-07-19 22:59:20','1','1','1','91724961468994300','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1304','47','Valve 6','V','6','2016-07-19 23:00:02','2016-07-19 23:01:02','1','2','1','91724961468994300','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1305','47','Valve 2','V','2','2016-07-19 23:00:02','2016-07-19 23:01:02','1','2','2','91724961468994300','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1306','47','Valve 2','V','2','2016-07-19 23:00:02','2016-07-19 23:01:02','1','2','2','91724961468994300','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1307','47','Valve 0','V','0','2016-07-19 23:01:02','2016-07-19 23:02:02','1','3','2','91724961468994300','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1308','47','Valve 3','V','3','2016-07-19 23:01:02','2016-07-19 23:02:02','1','3','2','91724961468994300','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1309','47','Valve 3','V','3','2016-07-19 23:01:02','2016-07-19 23:02:02','1','3','2','91724961468994300','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1310','47','Valve 4','V','4','2016-07-19 23:02:03','2016-07-19 23:03:03','1','4','1','91724961468994300','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1311','47','Valve 5','V','5','2016-07-19 23:02:03','2016-07-19 23:03:03','1','4','2','91724961468994300','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1312','47','Valve 5','V','5','2016-07-19 23:02:03','2016-07-19 23:03:03','1','4','2','91724961468994300','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1313','47','Valve 4','V','4','2016-07-19 23:04:02','2016-07-19 23:05:02','1','5','2','91724961468994300','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1314','47','Pump 1','PS','1','2016-07-19 23:05:02','2016-07-19 23:06:02','1','6','1','91724961468994300','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1315','47','Valve 2','V','2','2016-07-19 23:06:03','2016-07-19 23:07:03','1','1','2','91724961468994300','1');
INSERT INTO `rlb_custom_program_log` VALUES ('1316','47','Valve 5','V','5','2016-07-19 23:06:53','2016-07-19 23:07:53','1','1','1','81961981468994812','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1317','47','Valve 6','V','6','2016-07-19 23:08:02','2016-07-19 23:09:02','1','2','1','81961981468994812','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1318','47','Valve 2','V','2','2016-07-19 23:08:02','2016-07-19 23:09:02','1','2','2','81961981468994812','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1319','47','Valve 2','V','2','2016-07-19 23:08:02','2016-07-19 23:09:02','1','2','2','81961981468994812','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1320','47','Valve 0','V','0','2016-07-19 23:09:03','2016-07-19 23:10:03','1','3','2','81961981468994812','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1321','47','Valve 3','V','3','2016-07-19 23:09:03','2016-07-19 23:10:03','1','3','2','81961981468994812','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1322','47','Valve 3','V','3','2016-07-19 23:09:03','2016-07-19 23:10:03','1','3','2','81961981468994812','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1323','47','Valve 4','V','4','2016-07-19 23:11:02','2016-07-19 23:12:02','1','4','1','81961981468994812','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1324','47','Valve 5','V','5','2016-07-19 23:11:05','2016-07-19 23:12:05','1','4','2','81961981468994812','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1325','47','Valve 5','V','5','2016-07-19 23:11:05','2016-07-19 23:12:05','1','4','2','81961981468994812','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1326','47','Valve 4','V','4','2016-07-19 23:13:02','2016-07-19 23:14:02','1','5','2','81961981468994812','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1327','47','Pump 1','PS','1','2016-07-19 23:14:02','2016-07-19 23:15:02','1','6','1','81961981468994812','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1328','47','Valve 2','V','2','2016-07-19 23:15:03','2016-07-19 23:16:03','1','1','2','81961981468994812','1');
INSERT INTO `rlb_custom_program_log` VALUES ('1329','47','Valve 4','V','4','2016-07-19 23:17:02','2016-07-19 23:18:02','1','4','1','81961981468994812','1');
INSERT INTO `rlb_custom_program_log` VALUES ('1330','47','Valve 5','V','5','2016-07-19 23:26:08','2016-07-19 23:27:08','1','1','1','89603771468995967','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1331','47','Valve 2','V','2','2016-07-19 23:27:02','2016-07-19 23:28:02','1','1','2','89603771468995967','1');
INSERT INTO `rlb_custom_program_log` VALUES ('1332','47','Valve 5','V','5','2016-07-19 23:27:24','2016-07-19 23:28:24','1','1','1','97509571468996043','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1333','47','Valve 6','V','6','2016-07-19 23:29:02','2016-07-19 23:30:02','1','2','1','97509571468996043','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1334','47','Valve 2','V','2','2016-07-19 23:29:02','2016-07-19 23:30:02','1','2','2','97509571468996043','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1335','47','Valve 2','V','2','2016-07-19 23:29:02','2016-07-19 23:30:02','1','2','2','97509571468996043','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1336','47','Valve 0','V','0','2016-07-19 23:30:03','2016-07-19 23:31:03','1','3','2','97509571468996043','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1337','47','Valve 3','V','3','2016-07-19 23:30:03','2016-07-19 23:31:03','1','3','2','97509571468996043','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1338','47','Valve 3','V','3','2016-07-19 23:30:03','2016-07-19 23:31:03','1','3','2','97509571468996043','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1339','47','Valve 4','V','4','2016-07-19 23:32:02','2016-07-19 23:33:02','1','4','1','97509571468996043','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1340','47','Valve 5','V','5','2016-07-19 23:32:03','2016-07-19 23:33:03','1','4','2','97509571468996043','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1341','47','Valve 5','V','5','2016-07-19 23:32:03','2016-07-19 23:33:03','1','4','2','97509571468996043','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1342','47','Valve 4','V','4','2016-07-19 23:34:02','2016-07-19 23:35:02','1','5','2','97509571468996043','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1343','47','Pump 1','PS','1','2016-07-19 23:35:02','2016-07-19 23:36:02','1','6','1','97509571468996043','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1344','47','Valve 2','V','2','2016-07-19 23:36:03','2016-07-19 23:37:03','1','1','2','97509571468996043','1');
INSERT INTO `rlb_custom_program_log` VALUES ('1345','47','Valve 5','V','5','2016-07-19 23:36:39','2016-07-19 23:37:39','1','1','1','84784931468996598','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1346','47','Valve 5','V','5','2016-07-19 23:37:42','2016-07-19 23:38:42','1','1','1','71576761468996661','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1347','47','Valve 5','V','5','2016-07-19 23:38:50','2016-07-19 23:39:50','1','1','1','75425061468996729','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1348','47','Valve 5','V','5','2016-07-19 23:40:00','2016-07-19 23:41:00','1','1','1','36624991468996799','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1349','47','Valve 6','V','6','2016-07-19 23:41:03','2016-07-19 23:42:03','1','2','1','36624991468996799','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1350','47','Valve 2','V','2','2016-07-19 23:41:03','2016-07-19 23:42:03','1','2','2','36624991468996799','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1351','47','Valve 2','V','2','2016-07-19 23:41:03','2016-07-19 23:42:03','1','2','2','36624991468996799','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1352','47','Valve 5','V','5','2016-07-19 23:43:01','2016-07-19 23:44:01','1','1','1','13101291468996980','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1353','47','Valve 5','V','5','2016-07-19 23:43:30','2016-07-19 23:44:30','1','1','1','14674921468997009','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1354','47','Valve 6','V','6','2016-07-19 23:45:02','2016-07-19 23:46:02','1','2','1','14674921468997009','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1355','47','Valve 2','V','2','2016-07-19 23:45:02','2016-07-19 23:46:02','1','2','2','14674921468997009','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1356','47','Valve 2','V','2','2016-07-19 23:45:02','2016-07-19 23:46:02','1','2','2','14674921468997009','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1357','47','Valve 0','V','0','2016-07-19 23:46:03','2016-07-19 23:47:03','1','3','2','14674921468997009','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1358','47','Valve 3','V','3','2016-07-19 23:46:03','2016-07-19 23:47:03','1','3','2','14674921468997009','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1359','47','Valve 3','V','3','2016-07-19 23:46:03','2016-07-19 23:47:03','1','3','2','14674921468997009','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1360','47','Valve 4','V','4','2016-07-19 23:48:06','2016-07-19 23:49:06','1','4','1','14674921468997009','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1361','47','Valve 5','V','5','2016-07-19 23:48:08','2016-07-19 23:49:08','1','4','2','14674921468997009','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1362','47','Valve 5','V','5','2016-07-19 23:48:08','2016-07-19 23:49:08','1','4','2','14674921468997009','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1363','47','Valve 4','V','4','2016-07-19 23:50:02','2016-07-19 23:51:02','1','5','2','14674921468997009','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1364','47','Pump 1','PS','1','2016-07-19 23:51:03','2016-07-19 23:52:03','1','6','1','14674921468997009','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1365','47','Valve 2','V','2','2016-07-19 23:53:03','2016-07-19 23:54:03','1','1','2','14674921468997009','1');
INSERT INTO `rlb_custom_program_log` VALUES ('1366','47','Valve 4','V','4','2016-07-19 23:55:02','2016-07-19 23:56:02','1','4','1','14674921468997009','1');
INSERT INTO `rlb_custom_program_log` VALUES ('1367','45','Valve 5','V','5','2016-07-20 00:01:06','2016-07-20 00:02:06','1','1','1','69662791468998065','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1368','45','Valve 6','V','6','2016-07-20 00:03:02','2016-07-20 00:04:02','1','2','1','69662791468998065','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1369','45','Valve 2','V','2','2016-07-20 00:03:02','2016-07-20 00:04:02','1','2','2','69662791468998065','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1370','45','Valve 2','V','2','2016-07-20 00:03:02','2016-07-20 00:04:02','1','2','2','69662791468998065','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1371','45','Valve 0','V','0','2016-07-20 00:04:03','2016-07-20 00:05:03','1','3','2','69662791468998065','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1372','45','Valve 3','V','3','2016-07-20 00:04:03','2016-07-20 00:05:03','1','3','2','69662791468998065','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1373','45','Valve 3','V','3','2016-07-20 00:04:03','2016-07-20 00:05:03','1','3','2','69662791468998065','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1374','45','Valve 4','V','4','2016-07-20 00:06:02','2016-07-20 00:07:02','1','4','1','69662791468998065','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1375','45','Valve 5','V','5','2016-07-20 00:06:02','2016-07-20 00:07:02','1','4','2','69662791468998065','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1376','45','Valve 5','V','5','2016-07-20 00:06:02','2016-07-20 00:07:02','1','4','2','69662791468998065','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1377','45','Valve 4','V','4','2016-07-20 00:07:02','2016-07-20 00:08:02','1','5','2','69662791468998065','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1378','45','Pump 1','PS','1','2016-07-20 00:08:02','2016-07-20 00:09:02','1','6','1','69662791468998065','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1379','45','Valve 2','V','2','2016-07-20 00:09:03','2016-07-20 00:10:03','1','1','2','69662791468998065','1');
INSERT INTO `rlb_custom_program_log` VALUES ('1380','45','Valve 4','V','4','2016-07-20 00:11:02','2016-07-20 00:12:02','1','4','1','69662791468998065','1');
INSERT INTO `rlb_custom_program_log` VALUES ('1381','45','Valve 5','V','5','2016-07-20 00:12:24','2016-07-20 00:13:24','1','1','1','96238831468998743','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1382','45','Valve 6','V','6','2016-07-20 00:14:02','2016-07-20 00:15:02','1','2','1','96238831468998743','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1383','45','Valve 2','V','2','2016-07-20 00:14:02','2016-07-20 00:15:02','1','2','2','96238831468998743','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1384','45','Valve 2','V','2','2016-07-20 00:14:02','2016-07-20 00:15:02','1','2','2','96238831468998743','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1385','45','Valve 0','V','0','2016-07-20 00:15:03','2016-07-20 00:16:03','1','3','2','96238831468998743','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1386','45','Valve 3','V','3','2016-07-20 00:15:03','2016-07-20 00:16:03','1','3','2','96238831468998743','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1387','45','Valve 3','V','3','2016-07-20 00:15:03','2016-07-20 00:16:03','1','3','2','96238831468998743','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1388','45','Valve 4','V','4','2016-07-20 00:17:03','2016-07-20 00:18:03','1','4','1','96238831468998743','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1389','45','Valve 5','V','5','2016-07-20 00:17:03','2016-07-20 00:18:03','1','4','2','96238831468998743','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1390','45','Valve 5','V','5','2016-07-20 00:17:03','2016-07-20 00:18:03','1','4','2','96238831468998743','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1391','45','Valve 4','V','4','2016-07-20 00:19:03','2016-07-20 00:20:03','1','5','2','96238831468998743','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1392','45','Pump 1','PS','1','2016-07-20 00:21:03','2016-07-20 00:22:03','1','6','1','96238831468998743','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1393','45','Valve 2','V','2','2016-07-20 00:23:03','2016-07-20 00:24:03','1','1','2','96238831468998743','1');
INSERT INTO `rlb_custom_program_log` VALUES ('1394','45','Valve 4','V','4','2016-07-20 00:25:03','2016-07-20 00:26:03','1','4','1','96238831468998743','1');
INSERT INTO `rlb_custom_program_log` VALUES ('1395','6','Valve 1','V','1','2016-07-20 08:16:02','2016-07-20 08:17:02','1','1','2','12986831469027762','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1396','6','Valve 2','V','2','2016-07-20 08:16:03','2016-07-20 08:17:03','1','1','2','12986831469027762','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1397','6','Valve 2','V','2','2016-07-20 08:16:03','2016-07-20 08:17:03','1','1','2','12986831469027762','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1398','6','Valve 5','V','5','2016-07-20 08:18:02','2016-07-20 08:19:02','1','2','1','12986831469027762','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1399','6','Valve 6','V','6','2016-07-20 08:18:02','2016-07-20 08:19:02','1','2','1','12986831469027762','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1400','6','Valve 6','V','6','2016-07-20 08:18:02','2016-07-20 08:19:02','1','2','1','12986831469027762','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1401','6','Pump 2','PS','2','2016-07-20 08:19:02','2016-07-20 09:19:02','1','3','1','12986831469027762','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1402','1','Valve 0','V','0','2016-07-20 14:43:08','2016-07-20 14:44:08','1','1','2','65221671469050988','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1403','1','Valve 3','V','3','2016-07-20 14:45:02','2016-07-20 14:46:02','1','2','2','65221671469050988','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1404','1','Valve 4','V','4','2016-07-20 14:46:03','2016-07-20 14:47:03','1','3','1','65221671469050988','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1405','1','Valve 4','V','4','2016-07-20 14:48:02','2016-07-20 14:49:02','1','4','2','65221671469050988','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1406','1','Valve 5','V','5','2016-07-20 14:49:02','2016-07-20 14:50:02','1','5','2','65221671469050988','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1407','1','Valve 5','V','5','2016-07-20 14:50:03','2016-07-20 14:51:03','1','6','1','65221671469050988','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1408','1','Valve 6','V','6','2016-07-20 14:50:03','2016-07-20 14:51:03','1','6','1','65221671469050988','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1409','1','Valve 6','V','6','2016-07-20 14:50:03','2016-07-20 14:51:03','1','6','1','65221671469050988','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1410','1','Pump 2','PS','2','2016-07-20 14:52:03','2016-07-20 15:47:03','1','7','1','65221671469050988','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1411','1','Relay 15','R','15','2016-07-20 14:52:03','2016-07-20 15:47:03','1','7','1','65221671469050988','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1412','1','Power Center 0','P','0','2016-07-20 14:52:03','2016-07-20 15:47:03','1','7','1','65221671469050988','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1413','1','Valve 3','V','3','2016-07-20 15:48:03','2016-07-20 15:49:03','1','1','2','65221671469050988','1');
INSERT INTO `rlb_custom_program_log` VALUES ('1414','1','Valve 4','V','4','2016-07-20 15:50:03','2016-07-20 15:51:03','1','3','1','65221671469050988','1');
INSERT INTO `rlb_custom_program_log` VALUES ('1415','1','Valve 4','V','4','2016-07-20 15:52:02','2016-07-20 15:53:02','1','4','2','65221671469050988','1');
INSERT INTO `rlb_custom_program_log` VALUES ('1416','1','Valve 5','V','5','2016-07-20 15:54:02','2016-07-20 15:55:02','1','5','2','65221671469050988','1');
INSERT INTO `rlb_custom_program_log` VALUES ('1417','1','Valve 6','V','6','2016-07-20 15:55:02','2016-07-20 15:56:02','1','6','1','65221671469050988','1');
INSERT INTO `rlb_custom_program_log` VALUES ('1418','1','Valve 0','V','0','2016-07-20 16:06:29','2016-07-20 16:07:29','1','1','2','63968251469055988','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1419','1','Valve 3','V','3','2016-07-20 16:08:02','2016-07-20 16:09:02','1','2','2','63968251469055988','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1420','1','Valve 4','V','4','2016-07-20 16:09:02','2016-07-20 16:10:02','1','3','1','63968251469055988','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1421','1','Valve 4','V','4','2016-07-20 16:11:02','2016-07-20 16:12:02','1','4','2','63968251469055988','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1422','1','Valve 5','V','5','2016-07-20 16:12:02','2016-07-20 16:13:02','1','5','2','63968251469055988','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1423','1','Valve 5','V','5','2016-07-20 16:13:02','2016-07-20 16:14:02','1','6','1','63968251469055988','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1424','1','Valve 6','V','6','2016-07-20 16:13:02','2016-07-20 16:14:02','1','6','1','63968251469055988','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1425','1','Valve 6','V','6','2016-07-20 16:13:02','2016-07-20 16:14:02','1','6','1','63968251469055988','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1426','1','Pump 2','PS','2','2016-07-20 16:14:02','2016-07-20 17:09:02','1','7','1','63968251469055988','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1427','1','Relay 15','R','15','2016-07-20 16:14:02','2016-07-20 17:09:02','1','7','1','63968251469055988','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1428','1','Power Center 0','P','0','2016-07-20 16:14:03','2016-07-20 17:09:03','1','7','1','63968251469055988','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1429','1','Valve 3','V','3','2016-07-20 16:22:02','2016-07-20 16:23:02','1','1','2','63968251469055988','1');
INSERT INTO `rlb_custom_program_log` VALUES ('1430','6','Valve 1','V','1','2016-07-20 16:22:10','2016-07-20 16:23:10','1','1','2','72874311469056930','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1431','6','Valve 2','V','2','2016-07-20 16:22:11','2016-07-20 16:23:11','1','1','2','72874311469056930','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1432','6','Valve 2','V','2','2016-07-20 16:22:11','2016-07-20 16:23:11','1','1','2','72874311469056930','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1433','1','Valve 4','V','4','2016-07-20 16:23:02','2016-07-20 16:24:02','1','3','1','63968251469055988','1');
INSERT INTO `rlb_custom_program_log` VALUES ('1434','1','Valve 4','V','4','2016-07-20 16:24:02','2016-07-20 16:25:02','1','4','2','63968251469055988','1');
INSERT INTO `rlb_custom_program_log` VALUES ('1435','1','Valve 5','V','5','2016-07-20 16:26:02','2016-07-20 16:27:02','1','5','2','63968251469055988','1');
INSERT INTO `rlb_custom_program_log` VALUES ('1436','1','Valve 6','V','6','2016-07-20 16:28:02','2016-07-20 16:29:02','1','6','1','63968251469055988','1');
INSERT INTO `rlb_custom_program_log` VALUES ('1437','46','Valve 6','V','6','2016-07-20 21:02:11','2016-07-20 21:03:11','1','1','1','62438661469073731','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1438','46','Valve 0','V','0','2016-07-20 21:02:11','2016-07-20 21:03:11','1','1','2','62438661469073731','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1439','46','Valve 0','V','0','2016-07-20 21:02:11','2016-07-20 21:03:11','1','1','2','62438661469073731','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1440','46','Valve 4','V','4','2016-07-20 21:04:02','2016-07-20 21:05:02','1','2','1','62438661469073731','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1441','46','Valve 3','V','3','2016-07-20 21:04:02','2016-07-20 21:05:02','1','2','2','62438661469073731','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1442','46','Valve 3','V','3','2016-07-20 21:04:02','2016-07-20 21:05:02','1','2','2','62438661469073731','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1443','46','Valve 1','V','1','2016-07-20 21:05:02','2016-07-20 21:06:02','1','3','2','62438661469073731','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1444','46','Valve 4','V','4','2016-07-20 21:05:02','2016-07-20 21:06:02','1','3','2','62438661469073731','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1445','46','Valve 4','V','4','2016-07-20 21:05:02','2016-07-20 21:06:02','1','3','2','62438661469073731','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1446','46','Valve 5','V','5','2016-07-20 21:06:02','2016-07-20 21:07:02','1','4','2','62438661469073731','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1447','46','Valve 3','V','3','2016-07-20 21:07:02','2016-07-20 21:08:02','1','1','2','62438661469073731','1');
INSERT INTO `rlb_custom_program_log` VALUES ('1448','46','Valve 4','V','4','2016-07-20 21:08:02','2016-07-20 21:09:02','1','3','2','62438661469073731','1');
INSERT INTO `rlb_custom_program_log` VALUES ('1449','46','Valve 6','V','6','2016-07-20 21:08:12','2016-07-20 21:09:12','1','1','1','80084801469074091','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1450','46','Valve 0','V','0','2016-07-20 21:08:12','2016-07-20 21:09:12','1','1','2','80084801469074091','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1451','46','Valve 0','V','0','2016-07-20 21:08:12','2016-07-20 21:09:12','1','1','2','80084801469074091','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1452','46','Valve 4','V','4','2016-07-20 21:10:02','2016-07-20 21:11:02','1','2','1','80084801469074091','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1453','46','Valve 3','V','3','2016-07-20 21:10:02','2016-07-20 21:11:02','1','2','2','80084801469074091','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1454','46','Valve 3','V','3','2016-07-20 21:10:02','2016-07-20 21:11:02','1','2','2','80084801469074091','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1455','46','Valve 3','V','3','2016-07-20 21:11:02','2016-07-20 21:12:02','1','1','2','80084801469074091','1');
INSERT INTO `rlb_custom_program_log` VALUES ('1456','46','Valve 6','V','6','2016-07-20 21:11:14','2016-07-20 21:12:14','1','1','1','83980231469074274','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1457','46','Valve 0','V','0','2016-07-20 21:11:14','2016-07-20 21:12:14','1','1','2','83980231469074274','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1458','46','Valve 0','V','0','2016-07-20 21:11:14','2016-07-20 21:12:14','1','1','2','83980231469074274','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1459','46','Valve 4','V','4','2016-07-20 21:13:02','2016-07-20 21:14:02','1','2','1','83980231469074274','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1460','46','Valve 3','V','3','2016-07-20 21:13:02','2016-07-20 21:14:02','1','2','2','83980231469074274','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1461','46','Valve 3','V','3','2016-07-20 21:13:02','2016-07-20 21:14:02','1','2','2','83980231469074274','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1462','46','Valve 3','V','3','2016-07-20 21:14:02','2016-07-20 21:15:02','1','1','2','83980231469074274','1');
INSERT INTO `rlb_custom_program_log` VALUES ('1463','46','Valve 4','V','4','2016-07-20 21:15:02','2016-07-20 21:16:02','1','3','2','83980231469074274','1');
INSERT INTO `rlb_custom_program_log` VALUES ('1464','46','Valve 5','V','5','2016-07-20 21:16:03','2016-07-20 21:17:03','1','4','2','83980231469074274','1');
INSERT INTO `rlb_custom_program_log` VALUES ('1465','1','Valve 0','V','0','2016-07-20 23:00:33','2016-07-20 23:01:33','1','1','2','78331521469080829','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1466','1','Valve 0','V','0','2016-07-20 23:01:30','2016-07-20 23:02:30','1','1','2','89541421469080889','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1467','1','Valve 0','V','0','2016-07-20 23:01:58','2016-07-20 23:02:58','1','1','2','31569021469080917','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1468','1','Valve 0','V','0','2016-07-20 23:02:38','2016-07-20 23:03:38','1','1','2','10101841469080957','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1469','1','Valve 3','V','3','2016-07-20 23:04:02','2016-07-20 23:05:02','1','1','2','10101841469080957','1');
INSERT INTO `rlb_custom_program_log` VALUES ('1470','1','Valve 4','V','4','2016-07-20 23:05:02','2016-07-20 23:06:02','1','3','1','10101841469080957','1');
INSERT INTO `rlb_custom_program_log` VALUES ('1471','1','Valve 0','V','0','2016-07-20 23:05:11','2016-07-20 23:06:11','1','1','2','15106231469081111','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1472','1','Valve 3','V','3','2016-07-20 23:07:02','2016-07-20 23:08:02','1','1','2','15106231469081111','1');
INSERT INTO `rlb_custom_program_log` VALUES ('1473','1','Valve 4','V','4','2016-07-20 23:08:02','2016-07-20 23:09:02','1','3','1','15106231469081111','1');
INSERT INTO `rlb_custom_program_log` VALUES ('1474','1','Valve 0','V','0','2016-07-20 23:08:36','2016-07-20 23:09:36','1','1','2','15737221469081315','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1475','1','Valve 3','V','3','2016-07-20 23:10:02','2016-07-20 23:11:02','1','2','2','15737221469081315','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1476','1','Valve 4','V','4','2016-07-20 23:11:02','2016-07-20 23:12:02','1','3','1','15737221469081315','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1477','1','Valve 4','V','4','2016-07-20 23:12:03','2016-07-20 23:13:03','1','4','2','15737221469081315','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1478','1','Valve 3','V','3','2016-07-20 23:14:02','2016-07-20 23:15:02','1','1','2','15737221469081315','1');
INSERT INTO `rlb_custom_program_log` VALUES ('1479','1','Valve 4','V','4','2016-07-20 23:15:02','2016-07-20 23:16:02','1','3','1','15737221469081315','1');
INSERT INTO `rlb_custom_program_log` VALUES ('1480','1','Valve 4','V','4','2016-07-20 23:16:02','2016-07-20 23:17:02','1','4','2','15737221469081315','1');
INSERT INTO `rlb_custom_program_log` VALUES ('1481','1','Valve 5','V','5','2016-07-20 23:17:02','2016-07-20 23:18:02','1','5','2','15737221469081315','1');
INSERT INTO `rlb_custom_program_log` VALUES ('1482','1','Valve 6','V','6','2016-07-20 23:18:02','2016-07-20 23:19:02','1','6','1','15737221469081315','1');
INSERT INTO `rlb_custom_program_log` VALUES ('1483','47','Valve 5','V','5','2016-07-21 00:06:22','2016-07-21 00:07:22','1','1','1','11261391469084781','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1484','47','Valve 6','V','6','2016-07-21 00:08:02','2016-07-21 00:09:02','1','2','1','11261391469084781','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1485','47','Valve 2','V','2','2016-07-21 00:08:02','2016-07-21 00:09:02','1','2','2','11261391469084781','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1486','47','Valve 2','V','2','2016-07-21 00:08:02','2016-07-21 00:09:02','1','2','2','11261391469084781','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1487','47','Valve 2','V','2','2016-07-21 00:09:02','2016-07-21 00:10:02','1','1','2','11261391469084781','1');
INSERT INTO `rlb_custom_program_log` VALUES ('1488','47','Valve 5','V','5','2016-07-21 00:09:19','2016-07-21 00:10:19','1','1','1','37585561469084959','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1489','47','Valve 2','V','2','2016-07-21 00:10:02','2016-07-21 00:11:02','1','1','2','37585561469084959','1');
INSERT INTO `rlb_custom_program_log` VALUES ('1490','47','Valve 4','V','4','2016-07-21 00:11:02','2016-07-21 00:12:02','1','4','1','37585561469084959','1');
INSERT INTO `rlb_custom_program_log` VALUES ('1491','47','Valve 5','V','5','2016-07-21 01:44:33','2016-07-21 01:45:33','1','1','1','89752501469090672','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1492','47','Valve 2','V','2','2016-07-21 01:45:02','2016-07-21 01:46:02','1','1','2','89752501469090672','1');
INSERT INTO `rlb_custom_program_log` VALUES ('1493','47','Valve 4','V','4','2016-07-21 01:46:02','2016-07-21 01:47:02','1','4','1','89752501469090672','1');
INSERT INTO `rlb_custom_program_log` VALUES ('1494','47','Valve 5','V','5','2016-07-21 01:59:53','2016-07-21 02:00:53','1','1','1','26648351469091593','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1495','47','Valve 2','V','2','2016-07-21 02:01:02','2016-07-21 02:02:02','1','1','2','26648351469091593','1');
INSERT INTO `rlb_custom_program_log` VALUES ('1496','47','Valve 4','V','4','2016-07-21 02:02:03','2016-07-21 02:03:03','1','4','1','26648351469091593','1');
INSERT INTO `rlb_custom_program_log` VALUES ('1497','4','Pump 1','PS','1','2016-07-21 02:26:15','2016-07-21 02:36:15','1','1','1','22092041469093174','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1498','4','Valve 4','V','4','2016-07-21 02:26:15','2016-07-21 02:31:15','1','1','1','22092041469093174','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1499','4','Valve 0','V','0','2016-07-21 02:27:01','2016-07-21 02:47:01','1','1','1','22092041469093174','1');
INSERT INTO `rlb_custom_program_log` VALUES ('1500','45','Valve 5','V','5','2016-07-21 03:12:19','2016-07-21 03:13:19','1','1','1','57591111469095936','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1501','45','Valve 2','V','2','2016-07-21 03:13:02','2016-07-21 03:14:02','1','1','2','57591111469095936','1');
INSERT INTO `rlb_custom_program_log` VALUES ('1502','45','Valve 4','V','4','2016-07-21 03:14:02','2016-07-21 03:15:02','1','4','1','57591111469095936','1');
INSERT INTO `rlb_custom_program_log` VALUES ('1503','1','Valve 0','V','0','2016-07-21 03:20:43','2016-07-21 03:21:43','1','1','2','69436331469096441','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1504','1','Valve 3','V','3','2016-07-21 03:22:02','2016-07-21 03:23:02','1','1','2','69436331469096441','1');
INSERT INTO `rlb_custom_program_log` VALUES ('1505','1','Valve 4','V','4','2016-07-21 03:23:02','2016-07-21 03:24:02','1','3','1','69436331469096441','1');
INSERT INTO `rlb_custom_program_log` VALUES ('1506','1','Valve 4','V','4','2016-07-21 03:24:02','2016-07-21 03:25:02','1','4','2','69436331469096441','1');
INSERT INTO `rlb_custom_program_log` VALUES ('1507','1','Valve 5','V','5','2016-07-21 03:25:02','2016-07-21 03:26:02','1','5','2','69436331469096441','1');
INSERT INTO `rlb_custom_program_log` VALUES ('1508','1','Valve 6','V','6','2016-07-21 03:26:02','2016-07-21 03:27:02','1','6','1','69436331469096441','1');
INSERT INTO `rlb_custom_program_log` VALUES ('1509','1','Valve 0','V','0','2016-07-21 04:11:16','2016-07-21 04:12:16','1','1','2','85331521469099475','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1510','1','Valve 3','V','3','2016-07-21 04:12:02','2016-07-21 04:13:02','1','1','2','85331521469099475','1');
INSERT INTO `rlb_custom_program_log` VALUES ('1511','1','Valve 4','V','4','2016-07-21 04:13:02','2016-07-21 04:14:02','1','3','1','85331521469099475','1');
INSERT INTO `rlb_custom_program_log` VALUES ('1512','1','Valve 4','V','4','2016-07-21 04:14:02','2016-07-21 04:15:02','1','4','2','85331521469099475','1');
INSERT INTO `rlb_custom_program_log` VALUES ('1513','1','Valve 5','V','5','2016-07-21 04:15:02','2016-07-21 04:16:02','1','5','2','85331521469099475','1');
INSERT INTO `rlb_custom_program_log` VALUES ('1514','1','Valve 6','V','6','2016-07-21 04:16:02','2016-07-21 04:17:02','1','6','1','85331521469099475','1');
INSERT INTO `rlb_custom_program_log` VALUES ('1515','47','Valve 5','V','5','2016-07-21 04:35:31','2016-07-21 04:36:31','1','1','1','73170271469100931','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1516','47','Valve 6','V','6','2016-07-21 04:37:02','2016-07-21 04:38:02','1','2','1','73170271469100931','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1517','47','Valve 2','V','2','2016-07-21 04:37:03','2016-07-21 04:38:03','1','2','2','73170271469100931','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1518','47','Valve 2','V','2','2016-07-21 04:37:03','2016-07-21 04:38:03','1','2','2','73170271469100931','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1519','47','Valve 2','V','2','2016-07-21 04:38:02','2016-07-21 04:39:02','1','1','2','73170271469100931','1');
INSERT INTO `rlb_custom_program_log` VALUES ('1520','47','Valve 4','V','4','2016-07-21 04:39:04','2016-07-21 04:40:04','1','4','1','73170271469100931','1');
INSERT INTO `rlb_custom_program_log` VALUES ('1521','47','Valve 5','V','5','2016-07-21 04:46:28','2016-07-21 04:47:28','1','1','1','38899131469101588','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1522','47','Valve 6','V','6','2016-07-21 04:48:02','2016-07-21 04:49:02','1','2','1','38899131469101588','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1523','47','Valve 2','V','2','2016-07-21 04:48:02','2016-07-21 04:49:02','1','2','2','38899131469101588','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1524','47','Valve 2','V','2','2016-07-21 04:48:02','2016-07-21 04:49:02','1','2','2','38899131469101588','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1525','47','Valve 0','V','0','2016-07-21 04:49:02','2016-07-21 04:50:02','1','3','2','38899131469101588','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1526','47','Valve 3','V','3','2016-07-21 04:49:02','2016-07-21 04:50:02','1','3','2','38899131469101588','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1527','47','Valve 3','V','3','2016-07-21 04:49:02','2016-07-21 04:50:02','1','3','2','38899131469101588','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1528','47','Valve 4','V','4','2016-07-21 04:50:03','2016-07-21 04:51:03','1','4','1','38899131469101588','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1529','47','Valve 5','V','5','2016-07-21 04:50:03','2016-07-21 04:51:03','1','4','2','38899131469101588','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1530','47','Valve 5','V','5','2016-07-21 04:50:03','2016-07-21 04:51:03','1','4','2','38899131469101588','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1531','47','Valve 4','V','4','2016-07-21 04:52:03','2016-07-21 04:53:03','1','5','2','38899131469101588','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1532','47','Pump 1','PS','1','2016-07-21 04:54:03','2016-07-21 04:55:03','1','6','1','38899131469101588','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1533','47','Valve 2','V','2','2016-07-21 04:56:03','2016-07-21 04:57:03','1','1','2','38899131469101588','1');
INSERT INTO `rlb_custom_program_log` VALUES ('1534','47','Valve 4','V','4','2016-07-21 04:58:02','2016-07-21 04:59:02','1','4','1','38899131469101588','1');
INSERT INTO `rlb_custom_program_log` VALUES ('1535','47','Valve 5','V','5','2016-07-21 04:59:59','2016-07-21 05:00:59','1','1','1','30804251469102399','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1536','47','Valve 6','V','6','2016-07-21 05:01:02','2016-07-21 05:02:02','1','2','1','30804251469102399','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1537','47','Valve 2','V','2','2016-07-21 05:01:02','2016-07-21 05:02:02','1','2','2','30804251469102399','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1538','47','Valve 2','V','2','2016-07-21 05:01:02','2016-07-21 05:02:02','1','2','2','30804251469102399','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1539','47','Valve 0','V','0','2016-07-21 05:02:03','2016-07-21 05:03:03','1','3','2','30804251469102399','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1540','47','Valve 3','V','3','2016-07-21 05:02:03','2016-07-21 05:03:03','1','3','2','30804251469102399','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1541','47','Valve 3','V','3','2016-07-21 05:02:03','2016-07-21 05:03:03','1','3','2','30804251469102399','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1542','47','Valve 4','V','4','2016-07-21 05:04:02','2016-07-21 05:05:02','1','4','1','30804251469102399','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1543','47','Valve 5','V','5','2016-07-21 05:04:02','2016-07-21 05:05:02','1','4','2','30804251469102399','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1544','47','Valve 5','V','5','2016-07-21 05:04:02','2016-07-21 05:05:02','1','4','2','30804251469102399','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1545','47','Valve 4','V','4','2016-07-21 05:05:03','2016-07-21 05:06:03','1','5','2','30804251469102399','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1546','47','Pump 1','PS','1','2016-07-21 05:07:03','2016-07-21 05:08:03','1','6','1','30804251469102399','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1547','47','Valve 2','V','2','2016-07-21 05:09:02','2016-07-21 05:10:02','1','1','2','30804251469102399','1');
INSERT INTO `rlb_custom_program_log` VALUES ('1548','47','Valve 4','V','4','2016-07-21 05:10:02','2016-07-21 05:11:02','1','4','1','30804251469102399','1');
INSERT INTO `rlb_custom_program_log` VALUES ('1549','47','Valve 5','V','5','2016-07-21 05:14:52','2016-07-21 05:15:52','1','1','1','53982101469103292','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1550','47','Valve 6','V','6','2016-07-21 05:16:03','2016-07-21 05:17:03','1','2','1','53982101469103292','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1551','47','Valve 2','V','2','2016-07-21 05:16:03','2016-07-21 05:17:03','1','2','2','53982101469103292','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1552','47','Valve 2','V','2','2016-07-21 05:16:03','2016-07-21 05:17:03','1','2','2','53982101469103292','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1553','47','Valve 0','V','0','2016-07-21 05:18:03','2016-07-21 05:19:03','1','3','2','53982101469103292','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1554','47','Valve 3','V','3','2016-07-21 05:18:03','2016-07-21 05:19:03','1','3','2','53982101469103292','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1555','47','Valve 3','V','3','2016-07-21 05:18:03','2016-07-21 05:19:03','1','3','2','53982101469103292','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1556','47','Valve 4','V','4','2016-07-21 05:20:03','2016-07-21 05:21:03','1','4','1','53982101469103292','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1557','47','Valve 5','V','5','2016-07-21 05:20:03','2016-07-21 05:21:03','1','4','2','53982101469103292','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1558','47','Valve 5','V','5','2016-07-21 05:20:03','2016-07-21 05:21:03','1','4','2','53982101469103292','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1559','47','Valve 4','V','4','2016-07-21 05:22:02','2016-07-21 05:23:02','1','5','2','53982101469103292','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1560','47','Pump 1','PS','1','2016-07-21 05:23:03','2016-07-21 05:24:03','1','6','1','53982101469103292','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1561','47','Valve 2','V','2','2016-07-21 05:25:03','2016-07-21 05:26:03','1','1','2','53982101469103292','1');
INSERT INTO `rlb_custom_program_log` VALUES ('1562','47','Valve 4','V','4','2016-07-21 05:27:02','2016-07-21 05:28:02','1','4','1','53982101469103292','1');
INSERT INTO `rlb_custom_program_log` VALUES ('1563','5','Pump 1','PS','1','2016-07-21 05:30:00','2016-07-21 05:40:00','1','1','1','55667821469104198','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1564','5','Valve 0','V','0','2016-07-21 05:30:00','2016-07-21 05:50:00','1','1','1','55667821469104198','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1565','5','Valve 0','V','0','2016-07-21 05:31:02','2016-07-21 05:32:02','1','1','1','55667821469104198','1');
INSERT INTO `rlb_custom_program_log` VALUES ('1566','47','Valve 5','V','5','2016-07-21 05:30:22','2016-07-21 05:31:22','1','1','1','98421161469104222','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1567','47','Valve 6','V','6','2016-07-21 05:32:03','2016-07-21 05:33:03','1','2','1','98421161469104222','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1568','47','Valve 2','V','2','2016-07-21 05:32:03','2016-07-21 05:33:03','1','2','2','98421161469104222','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1569','47','Valve 2','V','2','2016-07-21 05:32:03','2016-07-21 05:33:03','1','2','2','98421161469104222','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1570','47','Valve 0','V','0','2016-07-21 05:34:03','2016-07-21 05:35:03','1','3','2','98421161469104222','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1571','47','Valve 3','V','3','2016-07-21 05:34:03','2016-07-21 05:35:03','1','3','2','98421161469104222','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1572','47','Valve 3','V','3','2016-07-21 05:34:03','2016-07-21 05:35:03','1','3','2','98421161469104222','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1573','47','Valve 4','V','4','2016-07-21 05:36:02','2016-07-21 05:37:02','1','4','1','98421161469104222','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1574','47','Valve 5','V','5','2016-07-21 05:36:02','2016-07-21 05:37:02','1','4','2','98421161469104222','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1575','47','Valve 5','V','5','2016-07-21 05:36:02','2016-07-21 05:37:02','1','4','2','98421161469104222','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1576','47','Valve 4','V','4','2016-07-21 05:38:02','2016-07-21 05:39:02','1','5','2','98421161469104222','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1577','47','Pump 1','PS','1','2016-07-21 05:39:02','2016-07-21 05:40:02','1','6','1','98421161469104222','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1578','47','Valve 2','V','2','2016-07-21 05:40:02','2016-07-21 05:41:02','1','1','2','98421161469104222','1');
INSERT INTO `rlb_custom_program_log` VALUES ('1579','47','Valve 4','V','4','2016-07-21 05:41:02','2016-07-21 05:42:02','1','4','1','98421161469104222','1');
INSERT INTO `rlb_custom_program_log` VALUES ('1580','47','Valve 5','V','5','2016-07-21 05:42:34','2016-07-21 05:43:34','1','1','1','61155531469104953','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1581','47','Valve 6','V','6','2016-07-21 05:44:02','2016-07-21 05:45:02','1','2','1','61155531469104953','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1582','47','Valve 2','V','2','2016-07-21 05:44:02','2016-07-21 05:45:02','1','2','2','61155531469104953','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1583','47','Valve 2','V','2','2016-07-21 05:44:02','2016-07-21 05:45:02','1','2','2','61155531469104953','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1584','47','Valve 0','V','0','2016-07-21 05:45:02','2016-07-21 05:46:02','1','3','2','61155531469104953','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1585','47','Valve 3','V','3','2016-07-21 05:45:02','2016-07-21 05:46:02','1','3','2','61155531469104953','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1586','47','Valve 3','V','3','2016-07-21 05:45:02','2016-07-21 05:46:02','1','3','2','61155531469104953','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1587','47','Valve 4','V','4','2016-07-21 05:46:06','2016-07-21 05:47:06','1','4','1','61155531469104953','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1588','47','Valve 5','V','5','2016-07-21 05:46:07','2016-07-21 05:47:07','1','4','2','61155531469104953','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1589','47','Valve 5','V','5','2016-07-21 05:46:07','2016-07-21 05:47:07','1','4','2','61155531469104953','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1590','47','Valve 4','V','4','2016-07-21 05:48:03','2016-07-21 05:49:03','1','5','2','61155531469104953','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1591','47','Valve 2','V','2','2016-07-21 05:50:03','2016-07-21 05:51:03','1','1','2','61155531469104953','1');
INSERT INTO `rlb_custom_program_log` VALUES ('1592','47','Valve 4','V','4','2016-07-21 05:52:02','2016-07-21 05:53:02','1','4','1','61155531469104953','1');
INSERT INTO `rlb_custom_program_log` VALUES ('1593','4','Pump 1','PS','1','2016-07-21 06:13:48','2016-07-21 06:23:48','1','1','1','66007841469106828','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1594','4','Valve 4','V','4','2016-07-21 06:13:49','2016-07-21 06:18:49','1','1','1','66007841469106828','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1595','47','Valve 5','V','5','2016-07-21 06:13:36','2016-07-21 06:14:36','1','1','1','70538471469106816','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1596','47','Valve 6','V','6','2016-07-21 06:15:02','2016-07-21 06:16:02','1','2','1','70538471469106816','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1597','47','Valve 2','V','2','2016-07-21 06:15:02','2016-07-21 06:16:02','1','2','2','70538471469106816','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1598','47','Valve 2','V','2','2016-07-21 06:15:02','2016-07-21 06:16:02','1','2','2','70538471469106816','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1599','47','Valve 2','V','2','2016-07-21 06:16:02','2016-07-21 06:17:02','1','1','2','70538471469106816','1');
INSERT INTO `rlb_custom_program_log` VALUES ('1600','47','Valve 4','V','4','2016-07-21 06:17:02','2016-07-21 06:18:02','1','4','1','70538471469106816','1');
INSERT INTO `rlb_custom_program_log` VALUES ('1601','4','Valve 0','V','0','2016-07-21 06:15:02','2016-07-21 06:35:02','1','1','1','66007841469106828','1');
INSERT INTO `rlb_custom_program_log` VALUES ('1602','46','Valve 6','V','6','2016-07-21 18:31:36','2016-07-21 18:32:36','1','1','1','65314271469151096','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1603','46','Valve 0','V','0','2016-07-21 18:31:36','2016-07-21 18:32:36','1','1','2','65314271469151096','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1604','46','Valve 0','V','0','2016-07-21 18:31:36','2016-07-21 18:32:36','1','1','2','65314271469151096','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1605','46','Valve 4','V','4','2016-07-21 18:33:02','2016-07-21 18:34:02','1','2','1','65314271469151096','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1606','46','Valve 3','V','3','2016-07-21 18:33:02','2016-07-21 18:34:02','1','2','2','65314271469151096','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1607','46','Valve 3','V','3','2016-07-21 18:33:02','2016-07-21 18:34:02','1','2','2','65314271469151096','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1608','46','Valve 1','V','1','2016-07-21 18:34:03','2016-07-21 18:35:03','1','3','2','65314271469151096','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1609','46','Valve 4','V','4','2016-07-21 18:34:03','2016-07-21 18:35:03','1','3','2','65314271469151096','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1610','46','Valve 4','V','4','2016-07-21 18:34:03','2016-07-21 18:35:03','1','3','2','65314271469151096','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1611','46','Valve 5','V','5','2016-07-21 18:36:02','2016-07-21 18:37:02','1','4','2','65314271469151096','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1612','46','Valve 2','V','2','2016-07-21 18:37:02','2016-07-21 18:38:02','1','5','2','65314271469151096','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1613','46','Valve 5','V','5','2016-07-21 18:38:02','2016-07-21 18:39:02','1','6','1','65314271469151096','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1614','46','Relay 15','R','15','2016-07-21 18:39:02','2016-07-21 18:40:02','1','7','1','65314271469151096','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1615','46','Pump 2','PS','2','2016-07-21 18:40:03','2016-07-21 18:41:03','1','8','1','65314271469151096','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1616','46','Power Center 0','P','0','2016-07-21 18:40:03','2016-07-21 18:41:03','1','8','1','65314271469151096','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1617','46','Valve 3','V','3','2016-07-21 18:42:03','2016-07-21 18:43:03','1','1','2','65314271469151096','1');
INSERT INTO `rlb_custom_program_log` VALUES ('1618','1','Valve 0','V','0','2016-07-21 19:03:32','2016-07-21 19:04:32','1','1','2','57373461469153012','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1619','1','Valve 3','V','3','2016-07-21 19:05:02','2016-07-21 19:06:02','1','2','2','57373461469153012','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1620','1','Valve 4','V','4','2016-07-21 19:06:02','2016-07-21 19:07:02','1','3','1','57373461469153012','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1621','1','Valve 4','V','4','2016-07-21 19:08:02','2016-07-21 19:09:02','1','4','2','57373461469153012','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1622','1','Valve 5','V','5','2016-07-21 19:09:02','2016-07-21 19:10:02','1','5','2','57373461469153012','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1623','1','Valve 5','V','5','2016-07-21 19:10:03','2016-07-21 19:11:03','1','6','1','57373461469153012','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1624','1','Valve 6','V','6','2016-07-21 19:10:03','2016-07-21 19:11:03','1','6','1','57373461469153012','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1625','1','Valve 6','V','6','2016-07-21 19:10:03','2016-07-21 19:11:03','1','6','1','57373461469153012','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1626','1','Pump 2','PS','2','2016-07-21 19:12:02','2016-07-21 20:07:02','1','7','1','57373461469153012','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1627','1','Relay 15','R','15','2016-07-21 19:12:02','2016-07-21 20:07:02','1','7','1','57373461469153012','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1628','1','Power Center 0','P','0','2016-07-21 19:12:02','2016-07-21 20:07:02','1','7','1','57373461469153012','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1629','1','Valve 3','V','3','2016-07-21 20:07:03','2016-07-21 20:08:03','1','1','2','57373461469153012','1');
INSERT INTO `rlb_custom_program_log` VALUES ('1630','1','Valve 4','V','4','2016-07-21 20:09:02','2016-07-21 20:10:02','1','3','1','57373461469153012','1');
INSERT INTO `rlb_custom_program_log` VALUES ('1631','1','Valve 6','V','6','2016-07-21 20:10:02','2016-07-21 20:11:02','1','6','1','57373461469153012','1');
INSERT INTO `rlb_custom_program_log` VALUES ('1632','6','Valve 1','V','1','2016-07-21 20:35:57','2016-07-21 20:36:57','1','1','2','43027181469158557','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1633','6','Valve 2','V','2','2016-07-21 20:35:57','2016-07-21 20:36:57','1','1','2','43027181469158557','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1634','6','Valve 2','V','2','2016-07-21 20:35:57','2016-07-21 20:36:57','1','1','2','43027181469158557','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1635','1','Valve 0','V','0','2016-07-21 20:36:48','2016-07-21 20:37:48','1','1','2','21273001469158608','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1636','1','Valve 3','V','3','2016-07-21 20:38:02','2016-07-21 20:39:02','1','2','2','21273001469158608','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1637','1','Valve 4','V','4','2016-07-21 20:39:02','2016-07-21 20:40:02','1','3','1','21273001469158608','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1638','1','Valve 4','V','4','2016-07-21 20:40:02','2016-07-21 20:41:02','1','4','2','21273001469158608','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1639','1','Valve 5','V','5','2016-07-21 20:41:02','2016-07-21 20:42:02','1','5','2','21273001469158608','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1640','1','Valve 5','V','5','2016-07-21 20:42:02','2016-07-21 20:43:02','1','6','1','21273001469158608','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1641','1','Valve 6','V','6','2016-07-21 20:42:02','2016-07-21 20:43:02','1','6','1','21273001469158608','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1642','1','Valve 6','V','6','2016-07-21 20:42:02','2016-07-21 20:43:02','1','6','1','21273001469158608','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1643','1','Pump 2','PS','2','2016-07-21 20:43:03','2016-07-21 21:38:03','1','7','1','21273001469158608','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1644','1','Relay 15','R','15','2016-07-21 20:43:03','2016-07-21 21:38:03','1','7','1','21273001469158608','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1645','1','Power Center 0','P','0','2016-07-21 20:43:03','2016-07-21 21:38:03','1','7','1','21273001469158608','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1646','1','Valve 3','V','3','2016-07-21 21:39:05','2016-07-21 21:40:05','1','1','2','21273001469158608','1');
INSERT INTO `rlb_custom_program_log` VALUES ('1647','1','Valve 4','V','4','2016-07-21 21:41:02','2016-07-21 21:42:02','1','3','1','21273001469158608','1');
INSERT INTO `rlb_custom_program_log` VALUES ('1648','1','Valve 6','V','6','2016-07-21 21:42:02','2016-07-21 21:43:02','1','6','1','21273001469158608','1');
INSERT INTO `rlb_custom_program_log` VALUES ('1649','1','Valve 0','V','0','2016-07-21 23:08:01','2016-07-21 23:09:01','1','1','2','78744001469167680','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1650','1','Valve 3','V','3','2016-07-21 23:09:03','2016-07-21 23:10:03','1','2','2','78744001469167680','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1651','1','Valve 4','V','4','2016-07-21 23:11:02','2016-07-21 23:12:02','1','3','1','78744001469167680','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1652','1','Valve 4','V','4','2016-07-21 23:12:02','2016-07-21 23:13:02','1','4','2','78744001469167680','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1653','1','Valve 5','V','5','2016-07-21 23:13:02','2016-07-21 23:14:02','1','5','2','78744001469167680','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1654','1','Valve 5','V','5','2016-07-21 23:14:02','2016-07-21 23:15:02','1','6','1','78744001469167680','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1655','1','Valve 6','V','6','2016-07-21 23:14:03','2016-07-21 23:15:03','1','6','1','78744001469167680','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1656','1','Valve 6','V','6','2016-07-21 23:14:03','2016-07-21 23:15:03','1','6','1','78744001469167680','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1657','1','Pump 2','PS','2','2016-07-21 23:16:02','2016-07-22 00:11:02','1','7','1','78744001469167680','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1658','1','Relay 15','R','15','2016-07-21 23:16:02','2016-07-22 00:11:02','1','7','1','78744001469167680','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1659','1','Power Center 0','P','0','2016-07-21 23:16:03','2016-07-22 00:11:03','1','7','1','78744001469167680','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1660','1','Valve 3','V','3','2016-07-22 00:12:02','2016-07-22 00:13:02','1','1','2','78744001469167680','1');
INSERT INTO `rlb_custom_program_log` VALUES ('1661','45','Valve 5','V','5','2016-07-22 01:33:58','2016-07-22 01:34:58','1','1','1','28733871469176437','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1662','45','Valve 6','V','6','2016-07-22 01:35:04','2016-07-22 01:36:04','1','2','1','28733871469176437','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1663','45','Valve 2','V','2','2016-07-22 01:35:04','2016-07-22 01:36:04','1','2','2','28733871469176437','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1664','45','Valve 2','V','2','2016-07-22 01:35:04','2016-07-22 01:36:04','1','2','2','28733871469176437','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1665','45','Valve 0','V','0','2016-07-22 01:37:02','2016-07-22 01:38:02','1','3','2','28733871469176437','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1666','45','Valve 3','V','3','2016-07-22 01:37:03','2016-07-22 01:38:03','1','3','2','28733871469176437','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1667','45','Valve 3','V','3','2016-07-22 01:37:03','2016-07-22 01:38:03','1','3','2','28733871469176437','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1668','45','Valve 4','V','4','2016-07-22 01:39:03','2016-07-22 01:40:03','1','4','1','28733871469176437','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1669','45','Valve 5','V','5','2016-07-22 01:39:03','2016-07-22 01:40:03','1','4','2','28733871469176437','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1670','45','Valve 5','V','5','2016-07-22 01:39:03','2016-07-22 01:40:03','1','4','2','28733871469176437','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1671','45','Valve 4','V','4','2016-07-22 01:41:02','2016-07-22 01:42:02','1','5','2','28733871469176437','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1672','45','Pump 1','PS','1','2016-07-22 01:42:03','2016-07-22 01:43:03','1','6','1','28733871469176437','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1673','45','Valve 5','V','5','2016-07-22 01:44:03','2016-07-22 01:45:03','1','1','1','28733871469176437','1');
INSERT INTO `rlb_custom_program_log` VALUES ('1674','45','Valve 5','V','5','2016-07-22 01:44:26','2016-07-22 01:45:26','1','1','1','21526761469177065','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1675','45','Valve 6','V','6','2016-07-22 01:46:03','2016-07-22 01:47:03','1','2','1','21526761469177065','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1676','45','Valve 2','V','2','2016-07-22 01:46:03','2016-07-22 01:47:03','1','2','2','21526761469177065','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1677','45','Valve 2','V','2','2016-07-22 01:46:03','2016-07-22 01:47:03','1','2','2','21526761469177065','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1678','45','Valve 0','V','0','2016-07-22 01:48:03','2016-07-22 01:49:03','1','3','2','21526761469177065','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1679','45','Valve 3','V','3','2016-07-22 01:48:03','2016-07-22 01:49:03','1','3','2','21526761469177065','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1680','45','Valve 3','V','3','2016-07-22 01:48:03','2016-07-22 01:49:03','1','3','2','21526761469177065','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1681','45','Valve 4','V','4','2016-07-22 01:50:03','2016-07-22 01:51:03','1','4','1','21526761469177065','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1682','45','Valve 5','V','5','2016-07-22 01:50:03','2016-07-22 01:51:03','1','4','2','21526761469177065','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1683','45','Valve 5','V','5','2016-07-22 01:50:03','2016-07-22 01:51:03','1','4','2','21526761469177065','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1684','45','Valve 4','V','4','2016-07-22 01:52:02','2016-07-22 01:53:02','1','5','2','21526761469177065','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1685','45','Pump 1','PS','1','2016-07-22 01:53:05','2016-07-22 01:54:05','1','6','1','21526761469177065','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1686','45','Valve 5','V','5','2016-07-22 01:55:02','2016-07-22 01:56:02','1','1','1','21526761469177065','1');
INSERT INTO `rlb_custom_program_log` VALUES ('1687','45','Valve 2','V','2','2016-07-22 01:56:02','2016-07-22 01:57:02','1','2','2','21526761469177065','1');
INSERT INTO `rlb_custom_program_log` VALUES ('1688','6','Valve 1','V','1','2016-07-22 02:15:21','2016-07-22 02:16:21','1','1','2','80527611469178921','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1689','6','Valve 2','V','2','2016-07-22 02:15:21','2016-07-22 02:16:21','1','1','2','80527611469178921','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1690','6','Valve 2','V','2','2016-07-22 02:15:21','2016-07-22 02:16:21','1','1','2','80527611469178921','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1691','3','Valve 0','V','0','2016-07-22 02:14:57','2016-07-22 02:15:57','1','1','1','94340871469178897','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1692','3','Valve 4','V','4','2016-07-22 02:14:58','2016-07-22 02:15:58','1','1','1','94340871469178897','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1693','3','Valve 4','V','4','2016-07-22 02:14:58','2016-07-22 02:15:58','1','1','1','94340871469178897','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1694','3','Valve 0','V','0','2016-07-22 02:16:02','2016-07-22 02:17:02','1','2','2','94340871469178897','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1695','6','Valve 6','V','6','2016-07-22 02:16:02','2016-07-22 02:17:02','1','1','1','80527611469178921','1');
INSERT INTO `rlb_custom_program_log` VALUES ('1696','3','Valve 4','V','4','2016-07-22 02:17:02','2016-07-22 02:18:02','1','3','2','94340871469178897','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1697','3','Valve 5','V','5','2016-07-22 02:17:02','2016-07-22 02:18:02','1','3','2','94340871469178897','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1698','3','Valve 5','V','5','2016-07-22 02:17:02','2016-07-22 02:18:02','1','3','2','94340871469178897','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1699','3','Valve 4','V','4','2016-07-22 02:18:02','2016-07-22 02:19:02','1','1','1','94340871469178897','1');
INSERT INTO `rlb_custom_program_log` VALUES ('1700','3','Valve 0','V','0','2016-07-22 02:18:52','2016-07-22 02:19:52','1','1','1','27218321469179131','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1701','3','Valve 4','V','4','2016-07-22 02:18:52','2016-07-22 02:19:52','1','1','1','27218321469179131','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1702','3','Valve 4','V','4','2016-07-22 02:18:52','2016-07-22 02:19:52','1','1','1','27218321469179131','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1703','3','Valve 0','V','0','2016-07-22 02:20:02','2016-07-22 02:21:02','1','2','2','27218321469179131','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1704','3','Valve 4','V','4','2016-07-22 02:21:02','2016-07-22 02:22:02','1','3','2','27218321469179131','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1705','3','Valve 5','V','5','2016-07-22 02:21:02','2016-07-22 02:22:02','1','3','2','27218321469179131','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1706','3','Valve 5','V','5','2016-07-22 02:21:02','2016-07-22 02:22:02','1','3','2','27218321469179131','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1707','3','Valve 4','V','4','2016-07-22 02:23:02','2016-07-22 02:24:02','1','1','1','27218321469179131','1');
INSERT INTO `rlb_custom_program_log` VALUES ('1708','3','Valve 0','V','0','2016-07-22 02:23:16','2016-07-22 02:24:16','1','1','1','91395441469179395','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1709','3','Valve 4','V','4','2016-07-22 02:23:16','2016-07-22 02:24:16','1','1','1','91395441469179395','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1710','3','Valve 4','V','4','2016-07-22 02:23:16','2016-07-22 02:24:16','1','1','1','91395441469179395','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1711','6','Valve 1','V','1','2016-07-22 02:23:35','2016-07-22 02:24:35','1','1','2','98949351469179414','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1712','6','Valve 2','V','2','2016-07-22 02:23:35','2016-07-22 02:24:35','1','1','2','98949351469179414','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1713','6','Valve 2','V','2','2016-07-22 02:23:35','2016-07-22 02:24:35','1','1','2','98949351469179414','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1714','3','Valve 0','V','0','2016-07-22 02:25:03','2016-07-22 02:26:03','1','2','2','91395441469179395','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1715','6','Valve 5','V','5','2016-07-22 02:25:04','2016-07-22 02:26:04','1','2','1','98949351469179414','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1716','6','Valve 6','V','6','2016-07-22 02:25:04','2016-07-22 02:26:04','1','2','1','98949351469179414','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1717','6','Valve 6','V','6','2016-07-22 02:25:04','2016-07-22 02:26:04','1','2','1','98949351469179414','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1718','3','Valve 4','V','4','2016-07-22 02:27:02','2016-07-22 02:28:02','1','3','2','91395441469179395','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1719','3','Valve 5','V','5','2016-07-22 02:27:02','2016-07-22 02:28:02','1','3','2','91395441469179395','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1720','3','Valve 5','V','5','2016-07-22 02:27:02','2016-07-22 02:28:02','1','3','2','91395441469179395','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1721','6','Pump 2','PS','2','2016-07-22 02:27:02','2016-07-22 03:27:02','1','3','1','98949351469179414','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1722','3','Pump 1','PS','1','2016-07-22 02:28:03','2016-07-22 02:38:03','1','4','1','91395441469179395','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1723','3','Valve 4','V','4','2016-07-22 02:33:02','2016-07-22 02:34:02','1','1','1','91395441469179395','1');
INSERT INTO `rlb_custom_program_log` VALUES ('1724','6','Valve 6','V','6','2016-07-22 02:33:02','2016-07-22 02:34:02','1','1','1','98949351469179414','1');
INSERT INTO `rlb_custom_program_log` VALUES ('1725','3','Valve 5','V','5','2016-07-22 02:34:02','2016-07-22 02:35:02','1','3','2','91395441469179395','1');
INSERT INTO `rlb_custom_program_log` VALUES ('1726','45','Valve 5','V','5','2016-07-22 02:35:24','2016-07-22 02:36:24','1','1','1','30240831469180124','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1727','45','Valve 5','V','5','2016-07-22 02:36:02','2016-07-22 02:37:02','1','1','1','30240831469180124','1');
INSERT INTO `rlb_custom_program_log` VALUES ('1728','45','Valve 2','V','2','2016-07-22 02:38:02','2016-07-22 02:39:02','1','2','2','30240831469180124','1');
INSERT INTO `rlb_custom_program_log` VALUES ('1729','3','Valve 0','V','0','2016-07-22 02:39:47','2016-07-22 02:40:47','1','1','1','13909631469180386','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1730','3','Valve 4','V','4','2016-07-22 02:39:47','2016-07-22 02:40:47','1','1','1','13909631469180386','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1731','3','Valve 4','V','4','2016-07-22 02:39:47','2016-07-22 02:40:47','1','1','1','13909631469180386','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1732','6','Valve 1','V','1','2016-07-22 02:40:06','2016-07-22 02:41:06','1','1','2','67534461469180406','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1733','6','Valve 2','V','2','2016-07-22 02:40:06','2016-07-22 02:41:06','1','1','2','67534461469180406','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1734','6','Valve 2','V','2','2016-07-22 02:40:06','2016-07-22 02:41:06','1','1','2','67534461469180406','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1735','3','Valve 4','V','4','2016-07-22 02:41:02','2016-07-22 02:42:02','1','1','1','13909631469180386','1');
INSERT INTO `rlb_custom_program_log` VALUES ('1736','6','Valve 6','V','6','2016-07-22 02:41:02','2016-07-22 02:42:02','1','1','1','67534461469180406','1');
INSERT INTO `rlb_custom_program_log` VALUES ('1737','3','Valve 5','V','5','2016-07-22 02:42:02','2016-07-22 02:43:02','1','3','2','13909631469180386','1');
INSERT INTO `rlb_custom_program_log` VALUES ('1738','45','Valve 5','V','5','2016-07-22 02:43:44','2016-07-22 02:44:44','1','1','1','17486691469180624','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1739','45','Valve 5','V','5','2016-07-22 02:44:02','2016-07-22 02:45:02','1','1','1','17486691469180624','1');
INSERT INTO `rlb_custom_program_log` VALUES ('1740','45','Valve 2','V','2','2016-07-22 02:45:02','2016-07-22 02:46:02','1','2','2','17486691469180624','1');
INSERT INTO `rlb_custom_program_log` VALUES ('1741','1','Valve 0','V','0','2016-07-22 02:46:04','2016-07-22 02:47:04','1','1','2','16044741469180763','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1742','1','Valve 3','V','3','2016-07-22 02:47:02','2016-07-22 02:48:02','1','1','2','16044741469180763','1');
INSERT INTO `rlb_custom_program_log` VALUES ('1743','1','Valve 4','V','4','2016-07-22 02:48:02','2016-07-22 02:49:02','1','4','2','16044741469180763','1');
INSERT INTO `rlb_custom_program_log` VALUES ('1744','1','Valve 5','V','5','2016-07-22 02:49:03','2016-07-22 02:50:03','1','5','2','16044741469180763','1');
INSERT INTO `rlb_custom_program_log` VALUES ('1745','45','Valve 5','V','5','2016-07-22 02:51:46','2016-07-22 02:52:46','1','1','1','48724321469181105','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1746','45','Valve 5','V','5','2016-07-22 02:52:51','2016-07-22 02:53:51','1','1','1','36048041469181170','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1747','45','Valve 5','V','5','2016-07-22 02:54:02','2016-07-22 02:55:02','1','1','1','36048041469181170','1');
INSERT INTO `rlb_custom_program_log` VALUES ('1748','45','Valve 2','V','2','2016-07-22 02:55:04','2016-07-22 02:56:04','1','2','2','36048041469181170','1');
INSERT INTO `rlb_custom_program_log` VALUES ('1749','3','Valve 0','V','0','2016-07-22 02:59:25','2016-07-22 03:00:25','1','1','1','36737831469181563','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1750','3','Valve 4','V','4','2016-07-22 02:59:28','2016-07-22 03:00:28','1','1','1','36737831469181563','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1751','3','Valve 4','V','4','2016-07-22 02:59:28','2016-07-22 03:00:28','1','1','1','36737831469181563','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1752','45','Valve 5','V','5','2016-07-22 03:00:07','2016-07-22 03:01:07','1','1','1','93659541469181606','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1753','3','Valve 0','V','0','2016-07-22 03:00:37','2016-07-22 03:01:37','1','1','1','67229581469181636','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1754','3','Valve 4','V','4','2016-07-22 03:00:37','2016-07-22 03:01:37','1','1','1','67229581469181636','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1755','3','Valve 4','V','4','2016-07-22 03:00:37','2016-07-22 03:01:37','1','1','1','67229581469181636','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1756','45','Valve 5','V','5','2016-07-22 03:01:03','2016-07-22 03:02:03','1','1','1','93659541469181606','1');
INSERT INTO `rlb_custom_program_log` VALUES ('1757','3','Valve 0','V','0','2016-07-22 03:02:23','2016-07-22 03:03:23','1','2','2','67229581469181636','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1758','45','Valve 5','V','5','2016-07-22 03:03:23','2016-07-22 03:04:23','1','1','1','76804301469181803','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1759','3','Valve 4','V','4','2016-07-22 03:04:02','2016-07-22 03:05:02','1','1','1','67229581469181636','1');
INSERT INTO `rlb_custom_program_log` VALUES ('1760','45','Valve 5','V','5','2016-07-22 03:04:02','2016-07-22 03:05:02','1','1','1','76804301469181803','1');
INSERT INTO `rlb_custom_program_log` VALUES ('1761','3','Valve 0','V','0','2016-07-22 03:04:03','2016-07-22 03:05:03','1','1','1','93276731469181842','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1762','3','Valve 4','V','4','2016-07-22 03:04:03','2016-07-22 03:05:03','1','1','1','93276731469181842','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1763','3','Valve 4','V','4','2016-07-22 03:04:03','2016-07-22 03:05:03','1','1','1','93276731469181842','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1764','45','Valve 2','V','2','2016-07-22 03:05:02','2016-07-22 03:06:02','1','2','2','76804301469181803','1');
INSERT INTO `rlb_custom_program_log` VALUES ('1765','3','Valve 0','V','0','2016-07-22 03:06:02','2016-07-22 03:07:02','1','2','2','93276731469181842','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1766','3','Valve 4','V','4','2016-07-22 03:07:02','2016-07-22 03:08:02','1','3','2','93276731469181842','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1767','3','Valve 5','V','5','2016-07-22 03:07:02','2016-07-22 03:08:02','1','3','2','93276731469181842','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1768','3','Valve 5','V','5','2016-07-22 03:07:02','2016-07-22 03:08:02','1','3','2','93276731469181842','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1769','6','Valve 1','V','1','2016-07-22 03:06:52','2016-07-22 03:07:52','1','1','2','30627911469182012','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1770','6','Valve 2','V','2','2016-07-22 03:06:53','2016-07-22 03:07:53','1','1','2','30627911469182012','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1771','6','Valve 2','V','2','2016-07-22 03:06:53','2016-07-22 03:07:53','1','1','2','30627911469182012','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1772','3','Valve 4','V','4','2016-07-22 03:08:02','2016-07-22 03:09:02','1','1','1','93276731469181842','1');
INSERT INTO `rlb_custom_program_log` VALUES ('1773','6','Valve 6','V','6','2016-07-22 03:08:02','2016-07-22 03:09:02','1','1','1','30627911469182012','1');
INSERT INTO `rlb_custom_program_log` VALUES ('1774','3','Valve 5','V','5','2016-07-22 03:09:02','2016-07-22 03:10:02','1','3','2','93276731469181842','1');
INSERT INTO `rlb_custom_program_log` VALUES ('1775','46','Valve 6','V','6','2016-07-22 03:17:46','2016-07-22 03:18:46','1','1','1','73369751469182665','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1776','46','Valve 0','V','0','2016-07-22 03:17:46','2016-07-22 03:18:46','1','1','2','73369751469182665','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1777','46','Valve 0','V','0','2016-07-22 03:17:46','2016-07-22 03:18:46','1','1','2','73369751469182665','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1778','46','Valve 3','V','3','2016-07-22 03:19:02','2016-07-22 03:20:02','1','1','2','73369751469182665','1');
INSERT INTO `rlb_custom_program_log` VALUES ('1779','46','Valve 4','V','4','2016-07-22 03:20:02','2016-07-22 03:21:02','1','3','2','73369751469182665','1');
INSERT INTO `rlb_custom_program_log` VALUES ('1780','46','Valve 5','V','5','2016-07-22 03:21:03','2016-07-22 03:22:03','1','4','2','73369751469182665','1');
INSERT INTO `rlb_custom_program_log` VALUES ('1781','46','Valve 5','V','5','2016-07-22 03:23:03','2016-07-22 03:24:03','1','6','1','73369751469182665','1');
INSERT INTO `rlb_custom_program_log` VALUES ('1782','3','Valve 0','V','0','2016-07-22 07:33:55','2016-07-22 07:34:55','1','1','1','81895071469198034','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1783','3','Valve 4','V','4','2016-07-22 07:33:55','2016-07-22 07:34:55','1','1','1','81895071469198034','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1784','3','Valve 4','V','4','2016-07-22 07:33:55','2016-07-22 07:34:55','1','1','1','81895071469198034','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1785','3','Valve 0','V','0','2016-07-22 07:35:02','2016-07-22 07:36:02','1','2','2','81895071469198034','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1786','3','Valve 4','V','4','2016-07-22 07:36:02','2016-07-22 07:37:02','1','3','2','81895071469198034','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1787','3','Valve 5','V','5','2016-07-22 07:36:02','2016-07-22 07:37:02','1','3','2','81895071469198034','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1788','3','Valve 5','V','5','2016-07-22 07:36:02','2016-07-22 07:37:02','1','3','2','81895071469198034','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1789','3','Pump 1','PS','1','2016-07-22 07:37:02','2016-07-22 07:47:02','1','4','1','81895071469198034','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1790','3','Valve 4','V','4','2016-07-22 07:47:03','2016-07-22 07:48:03','1','1','1','81895071469198034','1');
INSERT INTO `rlb_custom_program_log` VALUES ('1791','3','Valve 5','V','5','2016-07-22 07:49:02','2016-07-22 07:50:02','1','3','2','81895071469198034','1');
INSERT INTO `rlb_custom_program_log` VALUES ('1792','6','Valve 1','V','1','2016-07-22 13:59:03','2016-07-22 14:00:03','1','1','2','28639821469221143','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1793','6','Valve 2','V','2','2016-07-22 13:59:04','2016-07-22 14:00:04','1','1','2','28639821469221143','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1794','6','Valve 2','V','2','2016-07-22 13:59:04','2016-07-22 14:00:04','1','1','2','28639821469221143','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1795','3','Valve 0','V','0','2016-07-22 14:00:27','2016-07-22 14:01:27','1','1','1','20053681469221226','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1796','3','Valve 4','V','4','2016-07-22 14:00:27','2016-07-22 14:01:27','1','1','1','20053681469221226','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1797','3','Valve 4','V','4','2016-07-22 14:00:27','2016-07-22 14:01:27','1','1','1','20053681469221226','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1798','3','Valve 0','V','0','2016-07-22 14:02:02','2016-07-22 14:03:02','1','2','2','20053681469221226','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1799','6','Valve 5','V','5','2016-07-22 14:01:03','2016-07-22 14:02:03','1','2','1','28639821469221143','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1800','6','Valve 6','V','6','2016-07-22 14:01:03','2016-07-22 14:02:03','1','2','1','28639821469221143','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1801','6','Valve 6','V','6','2016-07-22 14:01:03','2016-07-22 14:02:03','1','2','1','28639821469221143','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1802','6','Pump 2','PS','2','2016-07-22 14:03:03','2016-07-22 15:03:03','1','3','1','28639821469221143','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1803','3','Valve 4','V','4','2016-07-22 14:03:02','2016-07-22 14:04:02','1','3','2','20053681469221226','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1804','3','Valve 5','V','5','2016-07-22 14:03:02','2016-07-22 14:04:02','1','3','2','20053681469221226','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1805','3','Valve 5','V','5','2016-07-22 14:03:02','2016-07-22 14:04:02','1','3','2','20053681469221226','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1806','6','Valve 6','V','6','2016-07-22 14:04:01','2016-07-22 14:05:01','1','1','1','28639821469221143','1');
INSERT INTO `rlb_custom_program_log` VALUES ('1807','3','Pump 1','PS','1','2016-07-22 14:05:02','2016-07-22 14:15:02','1','4','1','20053681469221226','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1808','3','Valve 4','V','4','2016-07-22 14:15:02','2016-07-22 14:16:02','1','1','1','20053681469221226','1');
INSERT INTO `rlb_custom_program_log` VALUES ('1809','3','Valve 5','V','5','2016-07-22 14:16:02','2016-07-22 14:17:02','1','3','2','20053681469221226','1');
INSERT INTO `rlb_custom_program_log` VALUES ('1810','3','Valve 0','V','0','2016-07-22 17:14:29','2016-07-22 17:15:29','1','1','1','78795141469232869','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1811','3','Valve 4','V','4','2016-07-22 17:14:30','2016-07-22 17:15:30','1','1','1','78795141469232869','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1812','3','Valve 4','V','4','2016-07-22 17:14:30','2016-07-22 17:15:30','1','1','1','78795141469232869','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1813','3','Valve 0','V','0','2016-07-22 17:16:03','2016-07-22 17:17:03','1','2','2','78795141469232869','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1814','3','Valve 4','V','4','2016-07-22 17:18:02','2016-07-22 17:19:02','1','3','2','78795141469232869','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1815','3','Valve 5','V','5','2016-07-22 17:18:02','2016-07-22 17:19:02','1','3','2','78795141469232869','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1816','3','Valve 5','V','5','2016-07-22 17:18:02','2016-07-22 17:19:02','1','3','2','78795141469232869','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1817','3','Pump 1','PS','1','2016-07-22 17:19:02','2016-07-22 17:29:02','1','4','1','78795141469232869','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1818','3','Valve 4','V','4','2016-07-22 17:30:02','2016-07-22 17:31:02','1','1','1','78795141469232869','1');
INSERT INTO `rlb_custom_program_log` VALUES ('1819','3','Valve 5','V','5','2016-07-22 17:32:02','2016-07-22 17:33:02','1','3','2','78795141469232869','1');
INSERT INTO `rlb_custom_program_log` VALUES ('1820','1','Valve 0','V','0','2016-07-22 20:54:17','2016-07-22 20:55:17','1','1','2','31262381469246055','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1821','1','Valve 3','V','3','2016-07-22 20:56:02','2016-07-22 20:57:02','1','2','2','31262381469246055','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1822','1','Valve 4','V','4','2016-07-22 20:57:02','2016-07-22 20:58:02','1','3','1','31262381469246055','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1823','1','Valve 4','V','4','2016-07-22 20:58:02','2016-07-22 20:59:02','1','4','2','31262381469246055','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1824','1','Valve 5','V','5','2016-07-22 20:59:02','2016-07-22 21:00:02','1','5','2','31262381469246055','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1825','1','Valve 5','V','5','2016-07-22 21:00:02','2016-07-22 21:01:02','1','6','1','31262381469246055','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1826','1','Valve 6','V','6','2016-07-22 21:00:02','2016-07-22 21:01:02','1','6','1','31262381469246055','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1827','1','Valve 6','V','6','2016-07-22 21:00:02','2016-07-22 21:01:02','1','6','1','31262381469246055','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1828','1','Pump 2','PS','2','2016-07-22 21:01:02','2016-07-22 21:56:02','1','7','1','31262381469246055','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1829','1','Relay 15','R','15','2016-07-22 21:01:02','2016-07-22 21:56:02','1','7','1','31262381469246055','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1830','1','Power Center 0','P','0','2016-07-22 21:01:03','2016-07-22 21:56:03','1','7','1','31262381469246055','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1831','1','Valve 3','V','3','2016-07-22 21:22:02','2016-07-22 21:23:02','1','1','2','31262381469246055','1');
INSERT INTO `rlb_custom_program_log` VALUES ('1832','46','Valve 6','V','6','2016-07-22 21:21:59','2016-07-22 21:22:59','1','1','1','52728071469247719','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1833','46','Valve 0','V','0','2016-07-22 21:22:00','2016-07-22 21:23:00','1','1','2','52728071469247719','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1834','46','Valve 0','V','0','2016-07-22 21:22:00','2016-07-22 21:23:00','1','1','2','52728071469247719','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1835','1','Valve 4','V','4','2016-07-22 21:23:02','2016-07-22 21:24:02','1','4','2','31262381469246055','1');
INSERT INTO `rlb_custom_program_log` VALUES ('1836','46','Valve 4','V','4','2016-07-22 21:23:02','2016-07-22 21:24:02','1','2','1','52728071469247719','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1837','46','Valve 3','V','3','2016-07-22 21:23:02','2016-07-22 21:24:02','1','2','2','52728071469247719','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1838','46','Valve 3','V','3','2016-07-22 21:23:02','2016-07-22 21:24:02','1','2','2','52728071469247719','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1839','1','Valve 5','V','5','2016-07-22 21:24:02','2016-07-22 21:25:02','1','5','2','31262381469246055','1');
INSERT INTO `rlb_custom_program_log` VALUES ('1840','46','Valve 1','V','1','2016-07-22 21:24:09','2016-07-22 21:25:09','1','3','2','52728071469247719','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1841','46','Valve 4','V','4','2016-07-22 21:24:10','2016-07-22 21:25:10','1','3','2','52728071469247719','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1842','46','Valve 4','V','4','2016-07-22 21:24:10','2016-07-22 21:25:10','1','3','2','52728071469247719','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1843','46','Valve 5','V','5','2016-07-22 21:26:03','2016-07-22 21:27:03','1','4','2','52728071469247719','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1844','46','Valve 2','V','2','2016-07-22 21:28:02','2016-07-22 21:29:02','1','5','2','52728071469247719','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1845','46','Valve 5','V','5','2016-07-22 21:29:02','2016-07-22 21:30:02','1','6','1','52728071469247719','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1846','46','Relay 15','R','15','2016-07-22 21:30:02','2016-07-22 21:31:02','1','7','1','52728071469247719','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1847','46','Pump 2','PS','2','2016-07-22 21:31:02','2016-07-22 21:32:02','1','8','1','52728071469247719','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1848','46','Power Center 0','P','0','2016-07-22 21:31:02','2016-07-22 21:32:02','1','8','1','52728071469247719','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1849','46','Valve 3','V','3','2016-07-22 21:32:03','2016-07-22 21:33:03','1','1','2','52728071469247719','1');
INSERT INTO `rlb_custom_program_log` VALUES ('1850','46','Valve 4','V','4','2016-07-22 21:34:02','2016-07-22 21:35:02','1','3','2','52728071469247719','1');
INSERT INTO `rlb_custom_program_log` VALUES ('1851','46','Valve 5','V','5','2016-07-22 21:35:03','2016-07-22 21:36:03','1','4','2','52728071469247719','1');
INSERT INTO `rlb_custom_program_log` VALUES ('1852','46','Valve 5','V','5','2016-07-22 21:37:02','2016-07-22 21:38:02','1','6','1','52728071469247719','1');
INSERT INTO `rlb_custom_program_log` VALUES ('1853','1','Valve 0','V','0','2016-07-22 22:06:41','2016-07-22 22:07:41','1','1','2','83656941469250400','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1854','1','Valve 3','V','3','2016-07-22 22:08:02','2016-07-22 22:09:02','1','2','2','83656941469250400','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1855','1','Valve 4','V','4','2016-07-22 22:09:03','2016-07-22 22:10:03','1','3','1','83656941469250400','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1856','1','Valve 4','V','4','2016-07-22 22:11:02','2016-07-22 22:12:02','1','4','2','83656941469250400','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1857','1','Valve 5','V','5','2016-07-22 22:12:02','2016-07-22 22:13:02','1','5','2','83656941469250400','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1858','1','Valve 5','V','5','2016-07-22 22:13:02','2016-07-22 22:14:02','1','6','1','83656941469250400','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1859','1','Valve 6','V','6','2016-07-22 22:13:02','2016-07-22 22:14:02','1','6','1','83656941469250400','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1860','1','Valve 6','V','6','2016-07-22 22:13:02','2016-07-22 22:14:02','1','6','1','83656941469250400','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1861','1','Pump 2','PS','2','2016-07-22 22:14:02','2016-07-22 23:09:02','1','7','1','83656941469250400','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1862','1','Relay 15','R','15','2016-07-22 22:14:02','2016-07-22 23:09:02','1','7','1','83656941469250400','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1863','1','Power Center 0','P','0','2016-07-22 22:14:03','2016-07-22 23:09:03','1','7','1','83656941469250400','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1864','1','Valve 3','V','3','2016-07-22 22:30:02','2016-07-22 22:31:02','1','1','2','83656941469250400','1');
INSERT INTO `rlb_custom_program_log` VALUES ('1865','1','Valve 4','V','4','2016-07-22 22:31:03','2016-07-22 22:32:03','1','4','2','83656941469250400','1');
INSERT INTO `rlb_custom_program_log` VALUES ('1866','1','Valve 5','V','5','2016-07-22 22:33:03','2016-07-22 22:34:03','1','5','2','83656941469250400','1');
INSERT INTO `rlb_custom_program_log` VALUES ('1867','3','Valve 0','V','0','2016-07-27 12:12:35','2016-07-27 12:13:35','1','1','1','27479371469646751','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1868','3','Valve 4','V','4','2016-07-27 12:12:35','2016-07-27 12:13:35','1','1','1','27479371469646751','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1869','3','Valve 4','V','4','2016-07-27 12:12:35','2016-07-27 12:13:35','1','1','1','27479371469646751','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1870','3','Valve 0','V','0','2016-07-27 12:14:03','2016-07-27 12:15:03','1','2','2','27479371469646751','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1871','3','Valve 4','V','4','2016-07-27 12:16:03','2016-07-27 12:17:03','1','3','2','27479371469646751','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1872','3','Valve 5','V','5','2016-07-27 12:16:03','2016-07-27 12:17:03','1','3','2','27479371469646751','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1873','3','Valve 5','V','5','2016-07-27 12:16:03','2016-07-27 12:17:03','1','3','2','27479371469646751','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1874','3','Pump 1','PS','1','2016-07-27 12:18:02','2016-07-27 12:28:02','1','4','1','27479371469646751','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1875','3','Valve 4','V','4','2016-07-27 12:28:03','2016-07-27 12:29:03','1','1','1','27479371469646751','1');
INSERT INTO `rlb_custom_program_log` VALUES ('1876','3','Valve 5','V','5','2016-07-27 12:30:03','2016-07-27 12:31:03','1','3','2','27479371469646751','1');
INSERT INTO `rlb_custom_program_log` VALUES ('1877','6','Valve 1','V','1','2016-07-27 12:51:09','2016-07-27 12:52:09','1','1','2','70889001469649068','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1878','6','Valve 2','V','2','2016-07-27 12:51:09','2016-07-27 12:52:09','1','1','2','70889001469649068','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1879','6','Valve 2','V','2','2016-07-27 12:51:09','2016-07-27 12:52:09','1','1','2','70889001469649068','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1880','6','Valve 6','V','6','2016-07-27 12:52:02','2016-07-27 12:53:02','1','1','1','70889001469649068','1');
INSERT INTO `rlb_custom_program_log` VALUES ('1881','6','Valve 1','V','1','2016-07-27 15:17:19','2016-07-27 15:18:19','1','1','2','79698761469657838','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1882','6','Valve 2','V','2','2016-07-27 15:17:19','2016-07-27 15:18:19','1','1','2','79698761469657838','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1883','6','Valve 2','V','2','2016-07-27 15:17:19','2016-07-27 15:18:19','1','1','2','79698761469657838','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1884','3','Valve 0','V','0','2016-07-27 15:19:34','2016-07-27 15:20:34','1','1','1','69894511469657974','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1885','3','Valve 4','V','4','2016-07-27 15:19:35','2016-07-27 15:20:35','1','1','1','69894511469657974','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1886','3','Valve 4','V','4','2016-07-27 15:19:35','2016-07-27 15:20:35','1','1','1','69894511469657974','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1887','6','Valve 5','V','5','2016-07-27 15:19:02','2016-07-27 15:20:02','1','2','1','79698761469657838','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1888','6','Valve 6','V','6','2016-07-27 15:19:02','2016-07-27 15:20:02','1','2','1','79698761469657838','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1889','6','Valve 6','V','6','2016-07-27 15:19:02','2016-07-27 15:20:02','1','2','1','79698761469657838','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1890','3','Valve 5','V','5','2016-07-27 15:20:02','2016-07-27 15:21:02','1','1','2','69894511469657974','1');
INSERT INTO `rlb_custom_program_log` VALUES ('1891','6','Pump 2','PS','2','2016-07-27 15:20:02','2016-07-27 16:20:02','1','3','1','79698761469657838','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1892','6','Valve 6','V','6','2016-07-27 15:23:02','2016-07-27 15:24:02','1','1','1','79698761469657838','1');
INSERT INTO `rlb_custom_program_log` VALUES ('1893','6','Valve 1','V','1','2016-07-28 08:26:29','2016-07-28 08:27:29','1','1','2','57781621469719588','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1894','6','Valve 2','V','2','2016-07-28 08:26:30','2016-07-28 08:27:30','1','1','2','57781621469719588','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1895','6','Valve 2','V','2','2016-07-28 08:26:30','2016-07-28 08:27:30','1','1','2','57781621469719588','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1896','6','Valve 5','V','5','2016-07-28 08:28:02','2016-07-28 08:29:02','1','2','1','57781621469719588','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1897','6','Valve 6','V','6','2016-07-28 08:28:02','2016-07-28 08:29:02','1','2','1','57781621469719588','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1898','6','Valve 6','V','6','2016-07-28 08:28:02','2016-07-28 08:29:02','1','2','1','57781621469719588','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1899','6','Pump 2','PS','2','2016-07-28 08:29:02','2016-07-28 09:29:02','1','3','1','57781621469719588','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1900','6','Valve 6','V','6','2016-07-28 08:31:02','2016-07-28 08:32:02','1','1','1','57781621469719588','1');
INSERT INTO `rlb_custom_program_log` VALUES ('1901','3','Valve 0','V','0','2016-07-28 08:34:08','2016-07-28 08:35:08','1','1','1','95906491469720048','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1902','3','Valve 4','V','4','2016-07-28 08:34:09','2016-07-28 08:35:09','1','1','1','95906491469720048','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1903','3','Valve 4','V','4','2016-07-28 08:34:09','2016-07-28 08:35:09','1','1','1','95906491469720048','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1904','3','Valve 0','V','0','2016-07-28 08:36:02','2016-07-28 08:37:02','1','2','2','95906491469720048','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1905','3','Valve 4','V','4','2016-07-28 08:37:03','2016-07-28 08:38:03','1','3','2','95906491469720048','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1906','3','Valve 5','V','5','2016-07-28 08:37:03','2016-07-28 08:38:03','1','3','2','95906491469720048','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1907','3','Valve 5','V','5','2016-07-28 08:37:03','2016-07-28 08:38:03','1','3','2','95906491469720048','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1908','3','Pump 1','PS','1','2016-07-28 08:39:03','2016-07-28 08:49:03','1','4','1','95906491469720048','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1909','45','Valve 5','V','5','2016-07-28 09:05:21','2016-07-28 09:06:21','1','1','1','64427801469721920','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1910','45','Valve 6','V','6','2016-07-28 09:07:03','2016-07-28 09:08:03','1','2','1','64427801469721920','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1911','45','Valve 2','V','2','2016-07-28 09:07:04','2016-07-28 09:08:04','1','2','2','64427801469721920','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1912','45','Valve 2','V','2','2016-07-28 09:07:04','2016-07-28 09:08:04','1','2','2','64427801469721920','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1913','45','Valve 0','V','0','2016-07-28 09:09:02','2016-07-28 09:10:02','1','3','2','64427801469721920','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1914','45','Valve 3','V','3','2016-07-28 09:09:02','2016-07-28 09:10:02','1','3','2','64427801469721920','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1915','45','Valve 3','V','3','2016-07-28 09:09:02','2016-07-28 09:10:02','1','3','2','64427801469721920','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1916','45','Valve 4','V','4','2016-07-28 09:11:02','2016-07-28 09:12:02','1','4','1','64427801469721920','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1917','45','Valve 5','V','5','2016-07-28 09:11:02','2016-07-28 09:12:02','1','4','2','64427801469721920','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1918','45','Valve 5','V','5','2016-07-28 09:11:02','2016-07-28 09:12:02','1','4','2','64427801469721920','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1919','45','Valve 4','V','4','2016-07-28 09:12:02','2016-07-28 09:13:02','1','5','2','64427801469721920','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1920','45','Pump 1','PS','1','2016-07-28 09:14:02','2016-07-28 09:15:02','1','6','1','64427801469721920','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1921','45','Valve 2','V','2','2016-07-28 09:16:02','2016-07-28 09:17:02','1','1','2','64427801469721920','1');
INSERT INTO `rlb_custom_program_log` VALUES ('1922','45','Valve 5','V','5','2016-07-28 09:45:52','2016-07-28 09:46:52','1','1','1','23920801469724352','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1923','45','Valve 6','V','6','2016-07-28 09:47:03','2016-07-28 09:48:03','1','2','1','23920801469724352','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1924','45','Valve 2','V','2','2016-07-28 09:47:03','2016-07-28 09:48:03','1','2','2','23920801469724352','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1925','45','Valve 2','V','2','2016-07-28 09:47:03','2016-07-28 09:48:03','1','2','2','23920801469724352','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1926','45','Valve 0','V','0','2016-07-28 09:49:02','2016-07-28 09:50:02','1','3','2','23920801469724352','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1927','45','Valve 3','V','3','2016-07-28 09:49:02','2016-07-28 09:50:02','1','3','2','23920801469724352','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1928','45','Valve 3','V','3','2016-07-28 09:49:02','2016-07-28 09:50:02','1','3','2','23920801469724352','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1929','45','Valve 4','V','4','2016-07-28 09:50:02','2016-07-28 09:51:02','1','4','1','23920801469724352','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1930','45','Valve 5','V','5','2016-07-28 09:50:02','2016-07-28 09:51:02','1','4','2','23920801469724352','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1931','45','Valve 5','V','5','2016-07-28 09:50:02','2016-07-28 09:51:02','1','4','2','23920801469724352','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1932','45','Valve 4','V','4','2016-07-28 09:51:02','2016-07-28 09:52:02','1','5','2','23920801469724352','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1933','45','Pump 1','PS','1','2016-07-28 09:52:02','2016-07-28 09:53:02','1','6','1','23920801469724352','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1934','45','Valve 2','V','2','2016-07-28 09:54:02','2016-07-28 09:55:02','1','1','2','23920801469724352','1');
INSERT INTO `rlb_custom_program_log` VALUES ('1935','45','Valve 5','V','5','2016-07-28 09:59:40','2016-07-28 10:00:40','1','1','1','63424711469725180','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1936','45','Valve 6','V','6','2016-07-28 10:01:02','2016-07-28 10:02:02','1','2','1','63424711469725180','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1937','45','Valve 2','V','2','2016-07-28 10:01:02','2016-07-28 10:02:02','1','2','2','63424711469725180','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1938','45','Valve 2','V','2','2016-07-28 10:01:02','2016-07-28 10:02:02','1','2','2','63424711469725180','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1939','45','Valve 0','V','0','2016-07-28 10:02:02','2016-07-28 10:03:02','1','3','2','63424711469725180','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1940','45','Valve 3','V','3','2016-07-28 10:02:02','2016-07-28 10:03:02','1','3','2','63424711469725180','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1941','45','Valve 3','V','3','2016-07-28 10:02:02','2016-07-28 10:03:02','1','3','2','63424711469725180','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1942','45','Valve 4','V','4','2016-07-28 10:04:02','2016-07-28 10:05:02','1','4','1','63424711469725180','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1943','45','Valve 5','V','5','2016-07-28 10:04:02','2016-07-28 10:05:02','1','4','2','63424711469725180','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1944','45','Valve 5','V','5','2016-07-28 10:04:02','2016-07-28 10:05:02','1','4','2','63424711469725180','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1945','45','Valve 4','V','4','2016-07-28 10:05:03','2016-07-28 10:06:03','1','5','2','63424711469725180','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1946','45','Pump 1','PS','1','2016-07-28 10:07:02','2016-07-28 10:08:02','1','6','1','63424711469725180','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1947','45','Valve 2','V','2','2016-07-28 10:08:03','2016-07-28 10:09:03','1','1','2','63424711469725180','1');
INSERT INTO `rlb_custom_program_log` VALUES ('1948','46','Valve 6','V','6','2016-07-28 10:10:22','2016-07-28 10:11:22','1','1','1','37729621469725821','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1949','46','Valve 0','V','0','2016-07-28 10:10:22','2016-07-28 10:11:22','1','1','2','37729621469725821','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1950','46','Valve 0','V','0','2016-07-28 10:10:22','2016-07-28 10:11:22','1','1','2','37729621469725821','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1951','46','Valve 4','V','4','2016-07-28 10:12:02','2016-07-28 10:13:02','1','2','1','37729621469725821','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1952','46','Valve 3','V','3','2016-07-28 10:12:02','2016-07-28 10:13:02','1','2','2','37729621469725821','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1953','46','Valve 3','V','3','2016-07-28 10:12:02','2016-07-28 10:13:02','1','2','2','37729621469725821','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1954','46','Valve 1','V','1','2016-07-28 10:13:03','2016-07-28 10:14:03','1','3','2','37729621469725821','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1955','46','Valve 4','V','4','2016-07-28 10:13:03','2016-07-28 10:14:03','1','3','2','37729621469725821','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1956','46','Valve 4','V','4','2016-07-28 10:13:03','2016-07-28 10:14:03','1','3','2','37729621469725821','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1957','46','Valve 5','V','5','2016-07-28 10:15:02','2016-07-28 10:16:02','1','4','2','37729621469725821','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1958','46','Valve 2','V','2','2016-07-28 10:16:02','2016-07-28 10:17:02','1','5','2','37729621469725821','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1959','46','Valve 5','V','5','2016-07-28 10:17:02','2016-07-28 10:18:02','1','6','1','37729621469725821','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1960','46','Relay 15','R','15','2016-07-28 10:19:02','2016-07-28 10:20:02','1','7','1','37729621469725821','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1961','46','Pump 2','PS','2','2016-07-28 10:20:02','2016-07-28 10:21:02','1','8','1','37729621469725821','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1962','46','Power Center 0','P','0','2016-07-28 10:20:03','2016-07-28 10:21:03','1','8','1','37729621469725821','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1963','46','Valve 3','V','3','2016-07-28 10:22:02','2016-07-28 10:23:02','1','1','2','37729621469725821','1');
INSERT INTO `rlb_custom_program_log` VALUES ('1964','46','Valve 4','V','4','2016-07-28 10:23:02','2016-07-28 10:24:02','1','3','2','37729621469725821','1');
INSERT INTO `rlb_custom_program_log` VALUES ('1965','46','Valve 5','V','5','2016-07-28 10:24:02','2016-07-28 10:25:02','1','4','2','37729621469725821','1');
INSERT INTO `rlb_custom_program_log` VALUES ('1966','6','Valve 1','V','1','2016-07-28 12:54:50','2016-07-28 12:55:50','1','1','2','51306941469735690','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1967','6','Valve 2','V','2','2016-07-28 12:54:51','2016-07-28 12:55:51','1','1','2','51306941469735690','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1968','6','Valve 2','V','2','2016-07-28 12:54:51','2016-07-28 12:55:51','1','1','2','51306941469735690','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1969','6','Valve 5','V','5','2016-07-28 12:56:03','2016-07-28 12:57:03','1','2','1','51306941469735690','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1970','6','Valve 6','V','6','2016-07-28 12:56:03','2016-07-28 12:57:03','1','2','1','51306941469735690','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1971','6','Valve 6','V','6','2016-07-28 12:56:03','2016-07-28 12:57:03','1','2','1','51306941469735690','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1972','6','Pump 2','PS','2','2016-07-28 12:58:03','2016-07-28 13:58:03','1','3','1','51306941469735690','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1973','6','Valve 1','V','1','2016-07-29 02:21:41','2016-07-29 02:22:41','1','1','2','78580481469784101','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1974','6','Valve 2','V','2','2016-07-29 02:21:42','2016-07-29 02:22:42','1','1','2','78580481469784101','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1975','6','Valve 2','V','2','2016-07-29 02:21:42','2016-07-29 02:22:42','1','1','2','78580481469784101','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1976','6','Valve 5','V','5','2016-07-29 02:23:03','2016-07-29 02:24:03','1','2','1','78580481469784101','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1977','6','Valve 6','V','6','2016-07-29 02:23:03','2016-07-29 02:24:03','1','2','1','78580481469784101','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1978','6','Valve 6','V','6','2016-07-29 02:23:03','2016-07-29 02:24:03','1','2','1','78580481469784101','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1979','6','Pump 2','PS','2','2016-07-29 02:25:03','2016-07-29 03:25:03','1','3','1','78580481469784101','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1980','6','Valve 1','V','1','2016-07-29 08:31:00','2016-07-29 08:32:00','1','1','2','77614901469806260','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1981','6','Valve 2','V','2','2016-07-29 08:31:00','2016-07-29 08:32:00','1','1','2','77614901469806260','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1982','6','Valve 2','V','2','2016-07-29 08:31:00','2016-07-29 08:32:00','1','1','2','77614901469806260','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1983','3','Valve 0','V','0','2016-07-29 08:31:33','2016-07-29 08:32:33','1','1','1','59335011469806293','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1984','3','Valve 4','V','4','2016-07-29 08:31:34','2016-07-29 08:32:34','1','1','1','59335011469806293','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1985','3','Valve 4','V','4','2016-07-29 08:31:34','2016-07-29 08:32:34','1','1','1','59335011469806293','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1986','6','Valve 5','V','5','2016-07-29 08:32:02','2016-07-29 08:33:02','1','2','1','77614901469806260','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1987','6','Valve 6','V','6','2016-07-29 08:32:02','2016-07-29 08:33:02','1','2','1','77614901469806260','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1988','6','Valve 6','V','6','2016-07-29 08:32:02','2016-07-29 08:33:02','1','2','1','77614901469806260','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1989','6','Pump 2','PS','2','2016-07-29 08:33:03','2016-07-29 09:33:03','1','3','1','77614901469806260','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1990','3','Valve 0','V','0','2016-07-29 08:33:02','2016-07-29 08:34:02','1','2','2','59335011469806293','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1991','3','Valve 4','V','4','2016-07-29 08:34:02','2016-07-29 08:35:02','1','3','2','59335011469806293','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1992','3','Valve 5','V','5','2016-07-29 08:34:02','2016-07-29 08:35:02','1','3','2','59335011469806293','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1993','3','Valve 5','V','5','2016-07-29 08:34:02','2016-07-29 08:35:02','1','3','2','59335011469806293','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1994','3','Pump 1','PS','1','2016-07-29 08:36:02','2016-07-29 08:46:02','1','4','1','59335011469806293','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1995','3','Valve 5','V','5','2016-07-29 08:46:03','2016-07-29 08:47:03','1','1','2','59335011469806293','1');
INSERT INTO `rlb_custom_program_log` VALUES ('1996','1','Valve 0','V','0','2016-07-29 09:37:38','2016-07-29 09:38:38','1','1','2','26562201469810257','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1997','1','Valve 4','V','4','2016-07-29 09:39:02','2016-07-29 09:40:02','1','1','1','26562201469810257','1');
INSERT INTO `rlb_custom_program_log` VALUES ('1998','46','Valve 6','V','6','2016-07-29 09:38:11','2016-07-29 09:39:11','1','1','1','31610481469810291','0');
INSERT INTO `rlb_custom_program_log` VALUES ('1999','46','Valve 0','V','0','2016-07-29 09:38:12','2016-07-29 09:39:12','1','1','2','31610481469810291','0');
INSERT INTO `rlb_custom_program_log` VALUES ('2000','46','Valve 0','V','0','2016-07-29 09:38:12','2016-07-29 09:39:12','1','1','2','31610481469810291','0');
INSERT INTO `rlb_custom_program_log` VALUES ('2001','1','Valve 4','V','4','2016-07-29 09:40:02','2016-07-29 09:41:02','1','4','2','26562201469810257','1');
INSERT INTO `rlb_custom_program_log` VALUES ('2002','46','Valve 4','V','4','2016-07-29 09:40:02','2016-07-29 09:41:02','1','2','1','31610481469810291','0');
INSERT INTO `rlb_custom_program_log` VALUES ('2003','46','Valve 3','V','3','2016-07-29 09:40:02','2016-07-29 09:41:02','1','2','2','31610481469810291','0');
INSERT INTO `rlb_custom_program_log` VALUES ('2004','46','Valve 3','V','3','2016-07-29 09:40:02','2016-07-29 09:41:02','1','2','2','31610481469810291','0');
INSERT INTO `rlb_custom_program_log` VALUES ('2005','1','Valve 5','V','5','2016-07-29 09:42:02','2016-07-29 09:43:02','1','5','2','26562201469810257','1');
INSERT INTO `rlb_custom_program_log` VALUES ('2006','46','Valve 1','V','1','2016-07-29 09:42:02','2016-07-29 09:43:02','1','3','2','31610481469810291','0');
INSERT INTO `rlb_custom_program_log` VALUES ('2007','46','Valve 4','V','4','2016-07-29 09:42:02','2016-07-29 09:43:02','1','3','2','31610481469810291','0');
INSERT INTO `rlb_custom_program_log` VALUES ('2008','46','Valve 4','V','4','2016-07-29 09:42:02','2016-07-29 09:43:02','1','3','2','31610481469810291','0');
INSERT INTO `rlb_custom_program_log` VALUES ('2009','1','Valve 6','V','6','2016-07-29 09:43:02','2016-07-29 09:44:02','1','6','1','26562201469810257','1');
INSERT INTO `rlb_custom_program_log` VALUES ('2010','46','Valve 5','V','5','2016-07-29 09:43:02','2016-07-29 09:44:02','1','4','2','31610481469810291','0');
INSERT INTO `rlb_custom_program_log` VALUES ('2011','46','Valve 2','V','2','2016-07-29 09:44:02','2016-07-29 09:45:02','1','5','2','31610481469810291','0');
INSERT INTO `rlb_custom_program_log` VALUES ('2012','46','Valve 5','V','5','2016-07-29 09:45:03','2016-07-29 09:46:03','1','6','1','31610481469810291','0');
INSERT INTO `rlb_custom_program_log` VALUES ('2013','46','Relay 15','R','15','2016-07-29 09:47:03','2016-07-29 09:48:03','1','7','1','31610481469810291','0');
INSERT INTO `rlb_custom_program_log` VALUES ('2014','3','Valve 0','V','0','2016-07-29 09:48:44','2016-07-29 09:49:44','1','1','1','45710261469810923','0');
INSERT INTO `rlb_custom_program_log` VALUES ('2015','3','Valve 4','V','4','2016-07-29 09:48:44','2016-07-29 09:49:44','1','1','1','45710261469810923','0');
INSERT INTO `rlb_custom_program_log` VALUES ('2016','3','Valve 4','V','4','2016-07-29 09:48:44','2016-07-29 09:49:44','1','1','1','45710261469810923','0');
INSERT INTO `rlb_custom_program_log` VALUES ('2017','46','Valve 4','V','4','2016-07-29 09:49:02','2016-07-29 09:50:02','1','1','1','31610481469810291','1');
INSERT INTO `rlb_custom_program_log` VALUES ('2018','3','Valve 0','V','0','2016-07-29 09:50:03','2016-07-29 09:51:03','1','2','2','45710261469810923','0');
INSERT INTO `rlb_custom_program_log` VALUES ('2019','46','Valve 4','V','4','2016-07-29 09:50:03','2016-07-29 09:51:03','1','3','2','31610481469810291','1');
INSERT INTO `rlb_custom_program_log` VALUES ('2020','3','Valve 4','V','4','2016-07-29 09:52:02','2016-07-29 09:53:02','1','3','2','45710261469810923','0');
INSERT INTO `rlb_custom_program_log` VALUES ('2021','3','Valve 5','V','5','2016-07-29 09:52:02','2016-07-29 09:53:02','1','3','2','45710261469810923','0');
INSERT INTO `rlb_custom_program_log` VALUES ('2022','3','Valve 5','V','5','2016-07-29 09:52:02','2016-07-29 09:53:02','1','3','2','45710261469810923','0');
INSERT INTO `rlb_custom_program_log` VALUES ('2023','46','Valve 5','V','5','2016-07-29 09:52:02','2016-07-29 09:53:02','1','4','2','31610481469810291','1');
INSERT INTO `rlb_custom_program_log` VALUES ('2024','3','Pump 1','PS','1','2016-07-29 09:53:03','2016-07-29 10:03:03','1','4','1','45710261469810923','0');
INSERT INTO `rlb_custom_program_log` VALUES ('2025','3','Valve 5','V','5','2016-07-29 09:59:02','2016-07-29 10:00:02','1','1','2','45710261469810923','1');
INSERT INTO `rlb_custom_program_log` VALUES ('2026','6','Valve 1','V','1','2016-07-29 11:07:08','2016-07-29 11:08:08','1','1','2','78594511469815627','0');
INSERT INTO `rlb_custom_program_log` VALUES ('2027','6','Valve 2','V','2','2016-07-29 11:07:13','2016-07-29 11:08:13','1','1','2','78594511469815627','0');
INSERT INTO `rlb_custom_program_log` VALUES ('2028','6','Valve 2','V','2','2016-07-29 11:07:13','2016-07-29 11:08:13','1','1','2','78594511469815627','0');
INSERT INTO `rlb_custom_program_log` VALUES ('2029','46','Valve 6','V','6','2016-07-29 11:08:40','2016-07-29 11:09:40','1','1','1','19799311469815719','0');
INSERT INTO `rlb_custom_program_log` VALUES ('2030','46','Valve 0','V','0','2016-07-29 11:08:41','2016-07-29 11:09:41','1','1','2','19799311469815719','0');
INSERT INTO `rlb_custom_program_log` VALUES ('2031','46','Valve 0','V','0','2016-07-29 11:08:41','2016-07-29 11:09:41','1','1','2','19799311469815719','0');
INSERT INTO `rlb_custom_program_log` VALUES ('2032','6','Valve 1','V','1','2016-07-29 11:09:23','2016-07-29 11:10:23','1','1','2','26596781469815762','0');
INSERT INTO `rlb_custom_program_log` VALUES ('2033','6','Valve 2','V','2','2016-07-29 11:09:23','2016-07-29 11:10:23','1','1','2','26596781469815762','0');
INSERT INTO `rlb_custom_program_log` VALUES ('2034','6','Valve 2','V','2','2016-07-29 11:09:23','2016-07-29 11:10:23','1','1','2','26596781469815762','0');
INSERT INTO `rlb_custom_program_log` VALUES ('2035','3','Valve 0','V','0','2016-07-29 11:09:55','2016-07-29 11:10:55','1','1','1','37556411469815795','0');
INSERT INTO `rlb_custom_program_log` VALUES ('2036','3','Valve 4','V','4','2016-07-29 11:09:56','2016-07-29 11:10:56','1','1','1','37556411469815795','0');
INSERT INTO `rlb_custom_program_log` VALUES ('2037','3','Valve 4','V','4','2016-07-29 11:09:56','2016-07-29 11:10:56','1','1','1','37556411469815795','0');
INSERT INTO `rlb_custom_program_log` VALUES ('2038','46','Valve 4','V','4','2016-07-29 11:10:03','2016-07-29 11:11:03','1','1','1','19799311469815719','1');
INSERT INTO `rlb_custom_program_log` VALUES ('2039','6','Valve 1','V','1','2016-07-29 11:10:06','2016-07-29 11:11:06','1','1','2','81563881469815805','0');
INSERT INTO `rlb_custom_program_log` VALUES ('2040','6','Valve 2','V','2','2016-07-29 11:10:06','2016-07-29 11:11:06','1','1','2','81563881469815805','0');
INSERT INTO `rlb_custom_program_log` VALUES ('2041','6','Valve 2','V','2','2016-07-29 11:10:06','2016-07-29 11:11:06','1','1','2','81563881469815805','0');
INSERT INTO `rlb_custom_program_log` VALUES ('2042','3','Valve 0','V','0','2016-07-29 11:11:03','2016-07-29 11:12:03','1','2','2','37556411469815795','0');
INSERT INTO `rlb_custom_program_log` VALUES ('2043','6','Valve 5','V','5','2016-07-29 11:12:02','2016-07-29 11:13:02','1','2','1','81563881469815805','0');
INSERT INTO `rlb_custom_program_log` VALUES ('2044','6','Valve 6','V','6','2016-07-29 11:12:02','2016-07-29 11:13:02','1','2','1','81563881469815805','0');
INSERT INTO `rlb_custom_program_log` VALUES ('2045','6','Valve 6','V','6','2016-07-29 11:12:02','2016-07-29 11:13:02','1','2','1','81563881469815805','0');
INSERT INTO `rlb_custom_program_log` VALUES ('2046','46','Valve 4','V','4','2016-07-29 11:11:03','2016-07-29 11:12:03','1','3','2','19799311469815719','1');
INSERT INTO `rlb_custom_program_log` VALUES ('2047','6','Pump 2','PS','2','2016-07-29 11:13:03','2016-07-29 12:13:03','1','3','1','81563881469815805','0');
INSERT INTO `rlb_custom_program_log` VALUES ('2048','3','Valve 4','V','4','2016-07-29 11:13:03','2016-07-29 11:14:03','1','3','2','37556411469815795','0');
INSERT INTO `rlb_custom_program_log` VALUES ('2049','3','Valve 5','V','5','2016-07-29 11:13:03','2016-07-29 11:14:03','1','3','2','37556411469815795','0');
INSERT INTO `rlb_custom_program_log` VALUES ('2050','3','Valve 5','V','5','2016-07-29 11:13:03','2016-07-29 11:14:03','1','3','2','37556411469815795','0');
INSERT INTO `rlb_custom_program_log` VALUES ('2051','46','Valve 6','V','6','2016-07-29 11:13:59','2016-07-29 11:14:59','1','1','1','79544481469816039','0');
INSERT INTO `rlb_custom_program_log` VALUES ('2052','46','Valve 0','V','0','2016-07-29 11:14:00','2016-07-29 11:15:00','1','1','2','79544481469816039','0');
INSERT INTO `rlb_custom_program_log` VALUES ('2053','46','Valve 0','V','0','2016-07-29 11:14:00','2016-07-29 11:15:00','1','1','2','79544481469816039','0');
INSERT INTO `rlb_custom_program_log` VALUES ('2054','3','Valve 5','V','5','2016-07-29 11:15:02','2016-07-29 11:16:02','1','1','2','37556411469815795','1');
INSERT INTO `rlb_custom_program_log` VALUES ('2055','6','Valve 1','V','1','2016-07-29 11:14:29','2016-07-29 11:15:29','1','1','2','92582761469816068','0');
INSERT INTO `rlb_custom_program_log` VALUES ('2056','6','Valve 2','V','2','2016-07-29 11:14:29','2016-07-29 11:15:29','1','1','2','92582761469816068','0');
INSERT INTO `rlb_custom_program_log` VALUES ('2057','6','Valve 2','V','2','2016-07-29 11:14:29','2016-07-29 11:15:29','1','1','2','92582761469816068','0');
INSERT INTO `rlb_custom_program_log` VALUES ('2058','46','Valve 4','V','4','2016-07-29 11:15:03','2016-07-29 11:16:03','1','1','1','79544481469816039','1');
INSERT INTO `rlb_custom_program_log` VALUES ('2059','3','Valve 0','V','0','2016-07-29 11:15:07','2016-07-29 11:16:07','1','1','1','62822461469816107','0');
INSERT INTO `rlb_custom_program_log` VALUES ('2060','3','Valve 4','V','4','2016-07-29 11:15:08','2016-07-29 11:16:08','1','1','1','62822461469816107','0');
INSERT INTO `rlb_custom_program_log` VALUES ('2061','3','Valve 4','V','4','2016-07-29 11:15:08','2016-07-29 11:16:08','1','1','1','62822461469816107','0');
INSERT INTO `rlb_custom_program_log` VALUES ('2062','46','Valve 4','V','4','2016-07-29 11:16:03','2016-07-29 11:17:03','1','3','2','79544481469816039','1');
INSERT INTO `rlb_custom_program_log` VALUES ('2063','3','Valve 0','V','0','2016-07-29 11:17:02','2016-07-29 11:18:02','1','2','2','62822461469816107','0');
INSERT INTO `rlb_custom_program_log` VALUES ('2064','6','Valve 5','V','5','2016-07-29 11:16:03','2016-07-29 11:17:03','1','2','1','92582761469816068','0');
INSERT INTO `rlb_custom_program_log` VALUES ('2065','6','Valve 6','V','6','2016-07-29 11:16:03','2016-07-29 11:17:03','1','2','1','92582761469816068','0');
INSERT INTO `rlb_custom_program_log` VALUES ('2066','6','Valve 6','V','6','2016-07-29 11:16:03','2016-07-29 11:17:03','1','2','1','92582761469816068','0');
INSERT INTO `rlb_custom_program_log` VALUES ('2067','46','Valve 5','V','5','2016-07-29 11:17:03','2016-07-29 11:18:03','1','4','2','79544481469816039','1');
INSERT INTO `rlb_custom_program_log` VALUES ('2068','3','Valve 4','V','4','2016-07-29 11:18:02','2016-07-29 11:19:02','1','3','2','62822461469816107','0');
INSERT INTO `rlb_custom_program_log` VALUES ('2069','3','Valve 5','V','5','2016-07-29 11:18:02','2016-07-29 11:19:02','1','3','2','62822461469816107','0');
INSERT INTO `rlb_custom_program_log` VALUES ('2070','3','Valve 5','V','5','2016-07-29 11:18:02','2016-07-29 11:19:02','1','3','2','62822461469816107','0');
INSERT INTO `rlb_custom_program_log` VALUES ('2071','6','Pump 2','PS','2','2016-07-29 11:18:03','2016-07-29 12:18:03','1','3','1','92582761469816068','0');
INSERT INTO `rlb_custom_program_log` VALUES ('2072','3','Pump 1','PS','1','2016-07-29 11:19:02','2016-07-29 11:29:02','1','4','1','62822461469816107','0');
INSERT INTO `rlb_custom_program_log` VALUES ('2073','46','Valve 6','V','6','2016-07-29 11:21:24','2016-07-29 11:22:24','1','1','1','94948301469816484','0');
INSERT INTO `rlb_custom_program_log` VALUES ('2074','46','Valve 0','V','0','2016-07-29 11:21:25','2016-07-29 11:22:25','1','1','2','94948301469816484','0');
INSERT INTO `rlb_custom_program_log` VALUES ('2075','46','Valve 0','V','0','2016-07-29 11:21:25','2016-07-29 11:22:25','1','1','2','94948301469816484','0');
INSERT INTO `rlb_custom_program_log` VALUES ('2076','3','Valve 5','V','5','2016-07-29 11:22:02','2016-07-29 11:23:02','1','1','2','62822461469816107','1');
INSERT INTO `rlb_custom_program_log` VALUES ('2077','46','Valve 4','V','4','2016-07-29 11:23:02','2016-07-29 11:24:02','1','2','1','94948301469816484','0');
INSERT INTO `rlb_custom_program_log` VALUES ('2078','46','Valve 3','V','3','2016-07-29 11:23:02','2016-07-29 11:24:02','1','2','2','94948301469816484','0');
INSERT INTO `rlb_custom_program_log` VALUES ('2079','46','Valve 3','V','3','2016-07-29 11:23:02','2016-07-29 11:24:02','1','2','2','94948301469816484','0');
INSERT INTO `rlb_custom_program_log` VALUES ('2080','46','Valve 1','V','1','2016-07-29 11:24:03','2016-07-29 11:25:03','1','3','2','94948301469816484','0');
INSERT INTO `rlb_custom_program_log` VALUES ('2081','46','Valve 4','V','4','2016-07-29 11:24:03','2016-07-29 11:25:03','1','3','2','94948301469816484','0');
INSERT INTO `rlb_custom_program_log` VALUES ('2082','46','Valve 4','V','4','2016-07-29 11:24:03','2016-07-29 11:25:03','1','3','2','94948301469816484','0');
INSERT INTO `rlb_custom_program_log` VALUES ('2083','46','Valve 5','V','5','2016-07-29 11:26:03','2016-07-29 11:27:03','1','4','2','94948301469816484','0');
INSERT INTO `rlb_custom_program_log` VALUES ('2084','46','Valve 2','V','2','2016-07-29 11:28:02','2016-07-29 11:29:02','1','5','2','94948301469816484','0');
INSERT INTO `rlb_custom_program_log` VALUES ('2085','46','Valve 5','V','5','2016-07-29 11:29:02','2016-07-29 11:30:02','1','6','1','94948301469816484','0');
INSERT INTO `rlb_custom_program_log` VALUES ('2086','46','Relay 15','R','15','2016-07-29 11:30:02','2016-07-29 11:31:02','1','7','1','94948301469816484','0');
INSERT INTO `rlb_custom_program_log` VALUES ('2087','46','Pump 2','PS','2','2016-07-29 11:32:02','2016-07-29 11:33:02','1','8','1','94948301469816484','0');
INSERT INTO `rlb_custom_program_log` VALUES ('2088','46','Power Center 0','P','0','2016-07-29 11:32:03','2016-07-29 11:33:03','1','8','1','94948301469816484','0');
INSERT INTO `rlb_custom_program_log` VALUES ('2089','46','Valve 4','V','4','2016-07-29 11:34:02','2016-07-29 11:35:02','1','1','1','94948301469816484','1');
INSERT INTO `rlb_custom_program_log` VALUES ('2090','46','Valve 4','V','4','2016-07-29 11:36:02','2016-07-29 11:37:02','1','3','2','94948301469816484','1');
INSERT INTO `rlb_custom_program_log` VALUES ('2091','46','Valve 5','V','5','2016-07-29 11:37:02','2016-07-29 11:38:02','1','4','2','94948301469816484','1');
INSERT INTO `rlb_custom_program_log` VALUES ('2092','46','Valve 6','V','6','2016-07-29 11:41:33','2016-07-29 11:42:33','1','1','1','44791471469817693','0');
INSERT INTO `rlb_custom_program_log` VALUES ('2093','46','Valve 0','V','0','2016-07-29 11:41:35','2016-07-29 11:42:35','1','1','2','44791471469817693','0');
INSERT INTO `rlb_custom_program_log` VALUES ('2094','46','Valve 0','V','0','2016-07-29 11:41:35','2016-07-29 11:42:35','1','1','2','44791471469817693','0');
INSERT INTO `rlb_custom_program_log` VALUES ('2095','46','Valve 4','V','4','2016-07-29 11:43:02','2016-07-29 11:44:02','1','2','1','44791471469817693','0');
INSERT INTO `rlb_custom_program_log` VALUES ('2096','46','Valve 3','V','3','2016-07-29 11:43:03','2016-07-29 11:44:03','1','2','2','44791471469817693','0');
INSERT INTO `rlb_custom_program_log` VALUES ('2097','46','Valve 3','V','3','2016-07-29 11:43:03','2016-07-29 11:44:03','1','2','2','44791471469817693','0');
INSERT INTO `rlb_custom_program_log` VALUES ('2098','46','Valve 1','V','1','2016-07-29 11:45:02','2016-07-29 11:46:02','1','3','2','44791471469817693','0');
INSERT INTO `rlb_custom_program_log` VALUES ('2099','46','Valve 4','V','4','2016-07-29 11:45:02','2016-07-29 11:46:02','1','3','2','44791471469817693','0');
INSERT INTO `rlb_custom_program_log` VALUES ('2100','46','Valve 4','V','4','2016-07-29 11:45:02','2016-07-29 11:46:02','1','3','2','44791471469817693','0');
INSERT INTO `rlb_custom_program_log` VALUES ('2101','46','Valve 5','V','5','2016-07-29 11:47:03','2016-07-29 11:48:03','1','4','2','44791471469817693','0');
INSERT INTO `rlb_custom_program_log` VALUES ('2102','46','Valve 2','V','2','2016-07-29 11:49:02','2016-07-29 11:50:02','1','5','2','44791471469817693','0');
INSERT INTO `rlb_custom_program_log` VALUES ('2103','46','Valve 5','V','5','2016-07-29 11:50:02','2016-07-29 11:51:02','1','6','1','44791471469817693','0');
INSERT INTO `rlb_custom_program_log` VALUES ('2104','46','Relay 15','R','15','2016-07-29 11:51:02','2016-07-29 11:52:02','1','7','1','44791471469817693','0');
INSERT INTO `rlb_custom_program_log` VALUES ('2105','46','Pump 2','PS','2','2016-07-29 11:52:02','2016-07-29 11:53:02','1','8','1','44791471469817693','0');
INSERT INTO `rlb_custom_program_log` VALUES ('2106','46','Power Center 0','P','0','2016-07-29 11:52:03','2016-07-29 11:53:03','1','8','1','44791471469817693','0');
INSERT INTO `rlb_custom_program_log` VALUES ('2107','46','Valve 4','V','4','2016-07-29 11:54:02','2016-07-29 11:55:02','1','1','1','44791471469817693','1');
INSERT INTO `rlb_custom_program_log` VALUES ('2108','46','Valve 4','V','4','2016-07-29 11:55:03','2016-07-29 11:56:03','1','3','2','44791471469817693','1');
INSERT INTO `rlb_custom_program_log` VALUES ('2109','46','Valve 5','V','5','2016-07-29 11:57:02','2016-07-29 11:58:02','1','4','2','44791471469817693','1');
INSERT INTO `rlb_custom_program_log` VALUES ('2110','6','Valve 1','V','1','2016-07-30 20:31:24','2016-07-30 20:32:24','1','1','2','69845181469935883','0');
INSERT INTO `rlb_custom_program_log` VALUES ('2111','6','Valve 2','V','2','2016-07-30 20:31:24','2016-07-30 20:32:24','1','1','2','69845181469935883','0');
INSERT INTO `rlb_custom_program_log` VALUES ('2112','6','Valve 2','V','2','2016-07-30 20:31:24','2016-07-30 20:32:24','1','1','2','69845181469935883','0');
INSERT INTO `rlb_custom_program_log` VALUES ('2113','6','Valve 5','V','5','2016-07-30 20:33:03','2016-07-30 20:34:03','1','2','1','69845181469935883','0');
INSERT INTO `rlb_custom_program_log` VALUES ('2114','6','Valve 6','V','6','2016-07-30 20:33:03','2016-07-30 20:34:03','1','2','1','69845181469935883','0');
INSERT INTO `rlb_custom_program_log` VALUES ('2115','6','Valve 6','V','6','2016-07-30 20:33:03','2016-07-30 20:34:03','1','2','1','69845181469935883','0');
INSERT INTO `rlb_custom_program_log` VALUES ('2116','6','Pump 2','PS','2','2016-07-30 20:35:03','2016-07-30 21:35:03','1','3','1','69845181469935883','0');

/*---------------------------------------------------------------
  TABLE: `rlb_device`
  ---------------------------------------------------------------*/
DROP TABLE IF EXISTS `rlb_device`;
CREATE TABLE `rlb_device` (
  `device_id` int(10) NOT NULL AUTO_INCREMENT,
  `device_number` int(10) NOT NULL,
  `device_name` varchar(150) NOT NULL,
  `device_type` varchar(100) NOT NULL,
  `device_power_type` varchar(10) DEFAULT NULL COMMENT '0=24VAC,1=12VDC',
  `device_position` text,
  `device_total_time` varchar(100) NOT NULL,
  `device_start_time` varchar(100) NOT NULL,
  `device_end_time` varchar(100) NOT NULL,
  `last_updated_date` datetime NOT NULL,
  `is_pool_or_spa` enum('0','1','2') NOT NULL DEFAULT '0' COMMENT '0=Other,1=Spa,2=Pool',
  `valve_relay_number` varchar(150) NOT NULL,
  `light_relay_number` text NOT NULL,
  `ip_id` int(5) NOT NULL,
  `show_dashboard` enum('0','1') NOT NULL DEFAULT '0',
  `valvePump` text NOT NULL,
  `temperature_offset` float(10,2) NOT NULL,
  PRIMARY KEY (`device_id`)
) ENGINE=InnoDB AUTO_INCREMENT=165 DEFAULT CHARSET=latin1;
INSERT INTO `rlb_device` VALUES   ('1','0','Spa Heater','P',NULL,NULL,'','','','2016-06-22 15:33:30','2','','','1','0','','0.00');
INSERT INTO `rlb_device` VALUES ('2','0','RelayName0','R',NULL,NULL,'20','','','2015-10-05 11:20:33','0','','','1','0','','0.00');
INSERT INTO `rlb_device` VALUES ('3','1','Pool Heater','P',NULL,NULL,'','','','2016-06-22 15:33:55','2','','','1','0','','0.00');
INSERT INTO `rlb_device` VALUES ('4','1','Test Relay 2','R',NULL,NULL,'','','','2015-09-19 13:25:31','1','','','1','0','','0.00');
INSERT INTO `rlb_device` VALUES ('8','2','','R',NULL,NULL,'30','','','2015-10-07 13:30:36','1','','','1','0','','0.00');
INSERT INTO `rlb_device` VALUES ('9','10','','R',NULL,NULL,'','08:13:57','08:23:57','2015-08-21 14:20:01','0','','','1','0','','0.00');
INSERT INTO `rlb_device` VALUES ('10','0','Board Temperature','T',NULL,NULL,'','','','2015-11-06 11:10:14','0','','0000000000000000','1','0','','0.00');
INSERT INTO `rlb_device` VALUES ('11','12','','R','0',NULL,'','','','2015-08-12 10:22:14','0','','','1','0','','0.00');
INSERT INTO `rlb_device` VALUES ('12','2','','P','1',NULL,'','','','2015-09-23 10:30:03','0','','','1','0','','0.00');
INSERT INTO `rlb_device` VALUES ('15','6','Spa 2 Blower','R',NULL,NULL,'20','','','2016-06-22 10:17:01','1','','','1','0','','0.00');
INSERT INTO `rlb_device` VALUES ('31','3','','P',NULL,NULL,'','','','2015-09-21 08:41:48','2','','','1','0','','0.00');
INSERT INTO `rlb_device` VALUES ('34','1','Spa 2','T',NULL,NULL,'','','','2016-07-17 21:23:22','0','','','1','1','','3.50');
INSERT INTO `rlb_device` VALUES ('35','3','','R',NULL,NULL,'','','','2015-09-23 07:12:35','1','','','1','0','','0.00');
INSERT INTO `rlb_device` VALUES ('36','2','Test','T',NULL,NULL,'','','','2016-06-22 15:40:26','0','','28FF2070501400B4','1','1','','0.00');
INSERT INTO `rlb_device` VALUES ('40','0','Garage Light','L',NULL,NULL,'','','','2016-07-01 04:50:39','1','','a:6:{s:10:\"sRelayType\";s:2:\"12\";s:12:\"sRelayNumber\";s:1:\"7\";s:11:\"Temeprature\";N;s:4:\"Pump\";N;s:7:\"maxTemp\";N;s:10:\"desireTemp\";N;}','1','0','','0.00');
INSERT INTO `rlb_device` VALUES ('44','0','Pool Heater','H',NULL,NULL,'','','','2016-07-14 03:20:06','1','','a:7:{s:10:\"sRelayType\";s:2:\"12\";s:12:\"sRelayNumber\";s:1:\"1\";s:11:\"Temeprature\";s:1:\"2\";s:4:\"Pump\";s:1:\"1\";s:7:\"maxTemp\";s:3:\"100\";s:10:\"desireTemp\";s:2:\"90\";s:6:\"maxRun\";s:2:\"50\";}','1','0','','0.00');
INSERT INTO `rlb_device` VALUES ('93','1','Spa Heater','H',NULL,NULL,'','','','2016-07-14 03:21:06','0','','a:7:{s:10:\"sRelayType\";s:2:\"12\";s:12:\"sRelayNumber\";s:1:\"0\";s:11:\"Temeprature\";s:1:\"1\";s:4:\"Pump\";s:1:\"1\";s:7:\"maxTemp\";s:3:\"100\";s:10:\"desireTemp\";s:2:\"83\";s:6:\"maxRun\";s:2:\"60\";}','1','0','','0.00');
INSERT INTO `rlb_device` VALUES ('98','0','','B',NULL,NULL,'','','','2016-01-21 14:07:25','1','','a:2:{s:10:\"sRelayType\";s:2:\"12\";s:12:\"sRelayNumber\";s:1:\"1\";}','1','0','','0.00');
INSERT INTO `rlb_device` VALUES ('100','0','misc1','M',NULL,NULL,'','','','2016-06-24 00:21:35','1','','a:2:{s:10:\"sRelayType\";s:2:\"24\";s:12:\"sRelayNumber\";s:2:\"14\";}','1','0','','0.00');
INSERT INTO `rlb_device` VALUES ('101','1','misc2','M',NULL,NULL,'','','','2016-06-24 00:21:14','2','','a:2:{s:10:\"sRelayType\";s:2:\"24\";s:12:\"sRelayNumber\";s:1:\"7\";}','1','0','','0.00');
INSERT INTO `rlb_device` VALUES ('118','4','','R',NULL,NULL,'','','','0000-00-00 00:00:00','0','','','1','0','','0.00');
INSERT INTO `rlb_device` VALUES ('119','7','Auto fill Indoor Pool','R',NULL,NULL,'','','','2016-06-22 10:15:05','1','','','1','0','','0.00');
INSERT INTO `rlb_device` VALUES ('120','0','RelayName1Device2','R',NULL,NULL,'20','','','2016-01-25 11:39:39','2','','','2','0','','0.00');
INSERT INTO `rlb_device` VALUES ('122','0','Testing','P',NULL,NULL,'','','','2016-01-14 11:20:41','1','','','2','0','','0.00');
INSERT INTO `rlb_device` VALUES ('123','1','','P',NULL,NULL,'','','','2016-01-14 11:08:56','2','','','2','0','','0.00');
INSERT INTO `rlb_device` VALUES ('124','0','Board Temperature','T',NULL,NULL,'','','','2016-01-14 12:46:39','0','','','2','0','','0.00');
INSERT INTO `rlb_device` VALUES ('129','0','#13 Solar On Off','V',NULL,'a:2:{s:9:\"position1\";s:2:\"20\";s:9:\"position2\";s:2:\"19\";}','','','','2016-06-22 10:12:31','2','a:2:{s:6:\"Relay1\";s:1:\"0\";s:6:\"Relay2\";s:1:\"1\";}','','1','0','{\"pump\":\"1\",\"valve_type\":\"1\"}','0.00');
INSERT INTO `rlb_device` VALUES ('131','0','','B',NULL,NULL,'','','','2016-06-24 00:19:52','2','','a:2:{s:10:\"sRelayType\";s:2:\"24\";s:12:\"sRelayNumber\";s:2:\"13\";}','2','0','','0.00');
INSERT INTO `rlb_device` VALUES ('134','1','','L',NULL,NULL,'','','','2016-06-24 00:20:44','2','','a:2:{s:10:\"sRelayType\";s:2:\"24\";s:12:\"sRelayNumber\";s:2:\"15\";}','2','0','','0.00');
INSERT INTO `rlb_device` VALUES ('135','0','','L',NULL,NULL,'','','','2016-02-02 12:35:50','1','','a:2:{s:10:\"sRelayType\";s:2:\"12\";s:12:\"sRelayNumber\";s:1:\"0\";}','2','0','','0.00');
INSERT INTO `rlb_device` VALUES ('142','14','F Pool Pump','R',NULL,NULL,'35','','','2016-06-22 10:14:10','0','','','1','0','','0.00');
INSERT INTO `rlb_device` VALUES ('143','0','#9 Pump 1 Return Spa or Pool','V',NULL,'a:2:{s:9:\"position1\";s:1:\"2\";s:9:\"position2\";s:1:\"3\";}','','','','2016-06-22 09:31:50','0','a:2:{s:6:\"Relay1\";s:1:\"0\";s:6:\"Relay2\";s:1:\"1\";}','','2','0','{\"pump\":\"2\",\"valve_type\":\"0\"}','0.00');
INSERT INTO `rlb_device` VALUES ('144','1','','H',NULL,NULL,'','','','2016-02-02 11:37:40','0','','a:2:{s:10:\"sRelayType\";s:2:\"12\";s:12:\"sRelayNumber\";s:1:\"1\";}','2','0','','0.00');
INSERT INTO `rlb_device` VALUES ('145','0','Testing','M',NULL,NULL,'','','','2016-06-24 00:21:36','0','','a:2:{s:10:\"sRelayType\";s:2:\"24\";s:12:\"sRelayNumber\";s:2:\"14\";}','2','0','','0.00');
INSERT INTO `rlb_device` VALUES ('146','1','Pump 1','PS',NULL,NULL,'','','','2016-06-29 12:00:58','1','','','1','0','','0.00');
INSERT INTO `rlb_device` VALUES ('147','2','Jet Pump','PS',NULL,NULL,'','','','2016-07-01 17:21:01','0','','','1','0','','0.00');
INSERT INTO `rlb_device` VALUES ('148','1','#1 return f Pool waterfall or Jet stream','V',NULL,'a:2:{s:9:\"position1\";s:2:\"17\";s:9:\"position2\";s:2:\"18\";}','','','','2016-06-22 10:09:16','0','a:2:{s:6:\"Relay1\";s:1:\"2\";s:6:\"Relay2\";s:1:\"3\";}','','1','0','{\"pump\":\"3\",\"valve_type\":\"1\"}','0.00');
INSERT INTO `rlb_device` VALUES ('149','2','#2 Return F Pool or F Waterfall','V',NULL,'a:2:{s:9:\"position1\";s:2:\"17\";s:9:\"position2\";s:2:\"16\";}','','','','2016-06-22 10:00:22','0','a:2:{s:6:\"Relay1\";s:1:\"4\";s:6:\"Relay2\";s:1:\"5\";}','','1','0','{\"pump\":\"3\",\"valve_type\":\"1\"}','0.00');
INSERT INTO `rlb_device` VALUES ('150','4','#7 Pump 1 suction Spa or Pool','V',NULL,'a:2:{s:9:\"position1\";s:1:\"2\";s:9:\"position2\";s:1:\"3\";}','','','','2016-06-22 10:01:51','0','a:2:{s:6:\"Relay1\";s:1:\"8\";s:6:\"Relay2\";s:1:\"9\";}','','1','0','{\"pump\":\"1\",\"valve_type\":\"0\"}','0.00');
INSERT INTO `rlb_device` VALUES ('151','5','#5 Jet Pump Return  Spa 1 or Spa 2','V',NULL,'a:2:{s:9:\"position1\";s:2:\"10\";s:9:\"position2\";s:2:\"11\";}','','','','2016-06-22 10:03:50','0','a:2:{s:6:\"Relay1\";s:2:\"10\";s:6:\"Relay2\";s:2:\"11\";}','','1','0','{\"pump\":\"2\",\"valve_type\":\"1\"}','0.00');
INSERT INTO `rlb_device` VALUES ('152','6','#6 Jet Pump Suction Spa1 or Spa 2','V',NULL,'a:2:{s:9:\"position1\";s:2:\"11\";s:9:\"position2\";s:2:\"10\";}','','','','2016-06-22 10:05:20','0','a:2:{s:6:\"Relay1\";s:2:\"12\";s:6:\"Relay2\";s:2:\"13\";}','','1','0','{\"pump\":\"2\",\"valve_type\":\"0\"}','0.00');
INSERT INTO `rlb_device` VALUES ('153','1','#3 Waterfall on or off','V',NULL,'a:2:{s:9:\"position1\";s:2:\"14\";s:9:\"position2\";s:2:\"15\";}','','','','2016-06-22 09:49:02','0','a:2:{s:6:\"Relay1\";s:1:\"2\";s:6:\"Relay2\";s:1:\"3\";}','','2','0','{\"pump\":\"1\",\"valve_type\":\"1\"}','0.00');
INSERT INTO `rlb_device` VALUES ('154','2','#4 Spa 2 Jets on and off','V',NULL,'a:2:{s:9:\"position1\";s:2:\"12\";s:9:\"position2\";s:2:\"13\";}','','','','2016-06-22 09:46:27','0','a:2:{s:6:\"Relay1\";s:1:\"4\";s:6:\"Relay2\";s:1:\"5\";}','','2','0','','0.00');
INSERT INTO `rlb_device` VALUES ('155','3','#8 Suction spa 1 or spa 2','V',NULL,'a:2:{s:9:\"position1\";s:2:\"11\";s:9:\"position2\";s:2:\"10\";}','','','','2016-06-22 09:42:54','0','a:2:{s:6:\"Relay1\";s:1:\"6\";s:6:\"Relay2\";s:1:\"7\";}','','2','0','{\"pump\":\"1\",\"valve_type\":\"0\"}','0.00');
INSERT INTO `rlb_device` VALUES ('156','4','#10 Spa 1 Return On or Off','V',NULL,'a:2:{s:9:\"position1\";s:1:\"6\";s:9:\"position2\";s:1:\"7\";}','','','','2016-06-22 09:35:18','0','a:2:{s:6:\"Relay1\";s:1:\"8\";s:6:\"Relay2\";s:1:\"9\";}','','2','0','','0.00');
INSERT INTO `rlb_device` VALUES ('157','5','#11 Spa 2 Return','V',NULL,'a:2:{s:9:\"position1\";s:1:\"8\";s:9:\"position2\";s:1:\"9\";}','','','','2016-06-22 09:37:26','0','a:2:{s:6:\"Relay1\";s:2:\"10\";s:6:\"Relay2\";s:2:\"11\";}','','2','0','','0.00');
INSERT INTO `rlb_device` VALUES ('158','15','Spa 1 Blower','R',NULL,NULL,'','','','2016-06-22 10:16:14','0','','','1','0','','0.00');
INSERT INTO `rlb_device` VALUES ('159','14','Auto fill f pool','R',NULL,NULL,'','','','2016-06-22 10:18:16','0','','','2','0','','0.00');
INSERT INTO `rlb_device` VALUES ('160','15','Auto fill Spa 2','R',NULL,NULL,'','','','2016-06-22 10:18:46','0','','','2','0','','0.00');
INSERT INTO `rlb_device` VALUES ('161','3','Fiberglass Pool Pump','PS',NULL,NULL,'','','','2016-06-27 11:06:00','0','','','1','0','','0.00');
INSERT INTO `rlb_device` VALUES ('162','3','Spa 1','T',NULL,NULL,'','','','2016-06-29 12:03:43','0','','','1','1','','0.00');
INSERT INTO `rlb_device` VALUES ('163','4','','T',NULL,NULL,'','','','0000-00-00 00:00:00','0','','','1','1','','0.00');
INSERT INTO `rlb_device` VALUES ('164','5','','T',NULL,NULL,'','','','0000-00-00 00:00:00','0','','','1','1','','0.00');

/*---------------------------------------------------------------
  TABLE: `rlb_device_last_run_details`
  ---------------------------------------------------------------*/
DROP TABLE IF EXISTS `rlb_device_last_run_details`;
CREATE TABLE `rlb_device_last_run_details` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `device_number` int(5) NOT NULL,
  `device_type` varchar(100) NOT NULL,
  `device_position` varchar(100) NOT NULL,
  `ip_id` int(5) NOT NULL,
  `added_date` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=latin1;
INSERT INTO `rlb_device_last_run_details` VALUES   ('1','2','V','1','1','2016-07-08 09:23:31');
INSERT INTO `rlb_device_last_run_details` VALUES ('2','0','V','2','2','2016-07-17 17:39:08');
INSERT INTO `rlb_device_last_run_details` VALUES ('3','5','V','1','2','2016-07-17 17:37:03');
INSERT INTO `rlb_device_last_run_details` VALUES ('4','1','V','1','1','2016-07-08 09:22:57');
INSERT INTO `rlb_device_last_run_details` VALUES ('5','6','V','1','1','2016-07-28 09:47:33');
INSERT INTO `rlb_device_last_run_details` VALUES ('6','0','V','1','1','2016-07-28 08:35:32');
INSERT INTO `rlb_device_last_run_details` VALUES ('8','4','V','1','1','2016-07-28 12:17:04');
INSERT INTO `rlb_device_last_run_details` VALUES ('9','5','V','2','1','2016-07-28 09:46:03');
INSERT INTO `rlb_device_last_run_details` VALUES ('10','4','V','2','2','2016-07-17 12:46:20');
INSERT INTO `rlb_device_last_run_details` VALUES ('11','3','V','2','2','2016-07-28 12:17:08');
INSERT INTO `rlb_device_last_run_details` VALUES ('12','2','V','2','2','2016-07-17 17:39:11');
INSERT INTO `rlb_device_last_run_details` VALUES ('13','1','V','1','2','2016-07-17 17:36:23');

/*---------------------------------------------------------------
  TABLE: `rlb_exclude_device`
  ---------------------------------------------------------------*/
DROP TABLE IF EXISTS `rlb_exclude_device`;
CREATE TABLE `rlb_exclude_device` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `exclude_devices` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
INSERT INTO `rlb_exclude_device` VALUES   ('1','a:8:{s:1:\"R\";a:3:{i:0;s:3:\"7_1\";i:1;s:4:\"14_2\";i:2;s:4:\"15_2\";}s:1:\"P\";b:0;s:1:\"V\";b:0;s:2:\"PS\";b:0;s:1:\"H\";b:0;s:1:\"B\";b:0;s:1:\"L\";b:0;s:1:\"M\";b:0;}');

/*---------------------------------------------------------------
  TABLE: `rlb_heater_run`
  ---------------------------------------------------------------*/
DROP TABLE IF EXISTS `rlb_heater_run`;
CREATE TABLE `rlb_heater_run` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `heaterNumber` int(5) NOT NULL,
  `ip_id` int(5) NOT NULL,
  `heaterRun` enum('0','1') NOT NULL DEFAULT '0',
  `heaterStart` datetime NOT NULL,
  `heaterEnd` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;
INSERT INTO `rlb_heater_run` VALUES   ('1','1','1','0','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `rlb_heater_run` VALUES ('2','0','1','0','0000-00-00 00:00:00','0000-00-00 00:00:00');
INSERT INTO `rlb_heater_run` VALUES ('3','1','2','0','0000-00-00 00:00:00','0000-00-00 00:00:00');

/*---------------------------------------------------------------
  TABLE: `rlb_mode_questions`
  ---------------------------------------------------------------*/
DROP TABLE IF EXISTS `rlb_mode_questions`;
CREATE TABLE `rlb_mode_questions` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `general` text NOT NULL,
  `device` text NOT NULL,
  `heater` text NOT NULL,
  `more` text NOT NULL,
  `added_date` datetime NOT NULL,
  `last_modified` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
INSERT INTO `rlb_mode_questions` VALUES   ('1','a:11:{s:4:\"type\";s:4:\"pool\";s:13:\"pool_max_temp\";s:2:\"50\";s:9:\"pool_temp\";s:2:\"50\";s:11:\"pool_manual\";s:3:\"480\";s:12:\"spa_max_temp\";s:0:\"\";s:15:\"spa_temperature\";s:0:\"\";s:10:\"spa_manual\";s:0:\"\";s:12:\"temperature1\";s:3:\"0_1\";s:12:\"temperature2\";s:3:\"0_1\";s:17:\"display_pool_temp\";s:3:\"Yes\";s:16:\"display_spa_temp\";s:3:\"Yes\";}','','','','2016-07-11 21:29:26','2016-07-17 19:31:53');

/*---------------------------------------------------------------
  TABLE: `rlb_modes`
  ---------------------------------------------------------------*/
DROP TABLE IF EXISTS `rlb_modes`;
CREATE TABLE `rlb_modes` (
  `mode_id` int(11) NOT NULL AUTO_INCREMENT,
  `mode_name` varchar(255) NOT NULL,
  `mode_status` int(1) NOT NULL DEFAULT '0',
  `start_time` datetime NOT NULL,
  `timer_total` varchar(150) NOT NULL,
  `timer_start` varchar(150) NOT NULL,
  `timer_end` varchar(150) NOT NULL,
  `unique_id` varchar(100) NOT NULL,
  PRIMARY KEY (`mode_id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;
INSERT INTO `rlb_modes` VALUES   ('1','Auto','1','2016-07-28 12:54:50','','','','');
INSERT INTO `rlb_modes` VALUES ('2','Manual','0','0000-00-00 00:00:00','480','2016-07-28 12:16:22','2016-07-28 20:16:22','');
INSERT INTO `rlb_modes` VALUES ('3','Time-Out','0','0000-00-00 00:00:00','','','','');

/*---------------------------------------------------------------
  TABLE: `rlb_pool_spa_current`
  ---------------------------------------------------------------*/
DROP TABLE IF EXISTS `rlb_pool_spa_current`;
CREATE TABLE `rlb_pool_spa_current` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `mode_id` int(5) NOT NULL,
  `current_on_device` varchar(255) NOT NULL,
  `device_type` varchar(10) NOT NULL,
  `device_number` varchar(10) NOT NULL,
  `current_on_time` datetime NOT NULL,
  `current_off_time` datetime NOT NULL,
  `current_device_complete` enum('0','1') NOT NULL,
  `current_unique_id` varchar(100) NOT NULL,
  `current_sequence` int(5) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*---------------------------------------------------------------
  TABLE: `rlb_pool_spa_log`
  ---------------------------------------------------------------*/
DROP TABLE IF EXISTS `rlb_pool_spa_log`;
CREATE TABLE `rlb_pool_spa_log` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `mode_id` int(5) NOT NULL,
  `unique_id` varchar(100) NOT NULL,
  `device` varchar(150) NOT NULL,
  `device_type` varchar(10) NOT NULL,
  `device_number` varchar(10) NOT NULL,
  `device_start` datetime NOT NULL,
  `device_stop` datetime NOT NULL,
  `device_complete_run` enum('0','1','2') NOT NULL DEFAULT '0',
  `current_sequence` int(5) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*---------------------------------------------------------------
  TABLE: `rlb_pool_spa_mode`
  ---------------------------------------------------------------*/
DROP TABLE IF EXISTS `rlb_pool_spa_mode`;
CREATE TABLE `rlb_pool_spa_mode` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `mode_name` varchar(150) NOT NULL,
  `mode_status` enum('0','1') NOT NULL DEFAULT '0',
  `total_run_time` varchar(100) NOT NULL,
  `last_start_date` datetime NOT NULL,
  `last_end_date` datetime NOT NULL,
  `unique_id` varchar(100) NOT NULL,
  `all_device_on` enum('0','1') NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
INSERT INTO `rlb_pool_spa_mode` VALUES   ('1','Pool','1','','0000-00-00 00:00:00','0000-00-00 00:00:00','','0');
INSERT INTO `rlb_pool_spa_mode` VALUES ('2','Spa','0','','0000-00-00 00:00:00','0000-00-00 00:00:00','','0');
INSERT INTO `rlb_pool_spa_mode` VALUES ('3','Both','0','','0000-00-00 00:00:00','0000-00-00 00:00:00','','0');
INSERT INTO `rlb_pool_spa_mode` VALUES ('4','Pool Auto','0','','0000-00-00 00:00:00','0000-00-00 00:00:00','','0');

/*---------------------------------------------------------------
  TABLE: `rlb_position`
  ---------------------------------------------------------------*/
DROP TABLE IF EXISTS `rlb_position`;
CREATE TABLE `rlb_position` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `position_name` varchar(250) NOT NULL,
  `position_device` varchar(100) NOT NULL,
  `position_active` enum('0','1') NOT NULL DEFAULT '0',
  `position_added_date` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=latin1;
INSERT INTO `rlb_position` VALUES   ('2','Pool','','1','2015-12-04 07:51:03');
INSERT INTO `rlb_position` VALUES ('3','Spa','','1','2015-12-04 07:51:08');
INSERT INTO `rlb_position` VALUES ('4','Other','','1','2015-12-04 07:51:16');
INSERT INTO `rlb_position` VALUES ('5','Waterfall','','1','2015-12-04 07:55:54');
INSERT INTO `rlb_position` VALUES ('6','Spa 1 Open','','1','2016-06-22 09:34:15');
INSERT INTO `rlb_position` VALUES ('7','Spa 1 Closed','','1','2016-06-22 09:34:33');
INSERT INTO `rlb_position` VALUES ('8','Spa 2 open','','1','2016-06-22 09:36:23');
INSERT INTO `rlb_position` VALUES ('9','Spa 2 closed','','1','2016-06-22 09:36:36');
INSERT INTO `rlb_position` VALUES ('10','Spa 1 ','','1','2016-06-22 09:39:24');
INSERT INTO `rlb_position` VALUES ('11','Spa 2','','1','2016-06-22 09:39:34');
INSERT INTO `rlb_position` VALUES ('12','Spa 2 Jets On','','1','2016-06-22 09:45:28');
INSERT INTO `rlb_position` VALUES ('13','Spa 2 Jets Off','','1','2016-06-22 09:45:39');
INSERT INTO `rlb_position` VALUES ('14','Waterfall on','','1','2016-06-22 09:48:39');
INSERT INTO `rlb_position` VALUES ('15','Waterfall off','','1','2016-06-22 09:48:48');
INSERT INTO `rlb_position` VALUES ('16','F Pool Return','','1','2016-06-22 09:53:41');
INSERT INTO `rlb_position` VALUES ('17','F Pool Waterfall','','1','2016-06-22 09:59:16');
INSERT INTO `rlb_position` VALUES ('18','Jet Stream','','1','2016-06-22 10:08:53');
INSERT INTO `rlb_position` VALUES ('19','Solar On','','1','2016-06-22 10:11:09');
INSERT INTO `rlb_position` VALUES ('20','Solar Off','','1','2016-06-22 10:11:22');

/*---------------------------------------------------------------
  TABLE: `rlb_powercenters`
  ---------------------------------------------------------------*/
DROP TABLE IF EXISTS `rlb_powercenters`;
CREATE TABLE `rlb_powercenters` (
  `powercenter_id` int(11) NOT NULL AUTO_INCREMENT,
  `powercenter_number` int(11) NOT NULL,
  `powercenter_name` varchar(100) NOT NULL,
  PRIMARY KEY (`powercenter_id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
INSERT INTO `rlb_powercenters` VALUES   ('1','0','Test powercenter0');
INSERT INTO `rlb_powercenters` VALUES ('2','4','pc4 edit');
INSERT INTO `rlb_powercenters` VALUES ('3','2','Testing');
INSERT INTO `rlb_powercenters` VALUES ('4','1','PowerCenter1');

/*---------------------------------------------------------------
  TABLE: `rlb_program`
  ---------------------------------------------------------------*/
DROP TABLE IF EXISTS `rlb_program`;
CREATE TABLE `rlb_program` (
  `program_id` int(11) NOT NULL AUTO_INCREMENT,
  `program_name` varchar(255) NOT NULL,
  `device_number` varchar(8) NOT NULL,
  `device_type` varchar(8) NOT NULL,
  `program_type` int(2) NOT NULL COMMENT '1-Daily, 2-Weekly',
  `program_days` varchar(255) NOT NULL COMMENT '0-All, 1-Mon, 2-Tue...7-Sun',
  `start_time` varchar(255) NOT NULL,
  `end_time` varchar(255) NOT NULL,
  `program_created_date` datetime NOT NULL,
  `program_modified_date` datetime NOT NULL,
  `program_delete` int(1) NOT NULL DEFAULT '0',
  `program_active` int(1) NOT NULL DEFAULT '0',
  `program_absolute` enum('0','1') NOT NULL DEFAULT '0',
  `program_absolute_start_time` varchar(100) DEFAULT NULL,
  `program_absolute_end_time` varchar(100) DEFAULT NULL,
  `program_absolute_total_time` varchar(100) DEFAULT NULL,
  `program_absolute_run_time` varchar(100) DEFAULT NULL,
  `program_absolute_start_date` date DEFAULT NULL,
  `program_absolute_run` enum('0','1') NOT NULL DEFAULT '0',
  `is_on_after_reboot` enum('0','1') NOT NULL DEFAULT '0',
  `program_work_in_mode` enum('0','1') NOT NULL DEFAULT '0',
  `ip_id` int(5) NOT NULL,
  `valvePosition` int(5) NOT NULL DEFAULT '0',
  PRIMARY KEY (`program_id`)
) ENGINE=MyISAM AUTO_INCREMENT=32 DEFAULT CHARSET=latin1;
INSERT INTO `rlb_program` VALUES   ('1','Daily Filtering','1','PS','1','0','06:00:00','12:00:00','2016-06-22 16:17:41','2016-06-23 09:01:42','1','0','0',NULL,NULL,'06:00:00',NULL,NULL,'0','0','0','1','0');
INSERT INTO `rlb_program` VALUES ('2','Daily Filtering F Pool','3','PS','1','0','11:05:00','20:05:00','2016-06-22 16:21:13','0000-00-00 00:00:00','0','0','0',NULL,NULL,'09:00:00',NULL,NULL,'0','0','1','1','0');
INSERT INTO `rlb_program` VALUES ('3','Spa 2 Filtering','4','V','1','0','11:00:00','12:00:00','2016-06-23 09:03:07','0000-00-00 00:00:00','1','0','',NULL,NULL,'01:00:00',NULL,NULL,'0','0','0','1','2');
INSERT INTO `rlb_program` VALUES ('4','Daily Filtering','3','V','1','0','11:00:00','12:05:00','2016-06-23 09:04:28','0000-00-00 00:00:00','1','0','',NULL,NULL,'01:05:00',NULL,NULL,'0','0','0','2','1');
INSERT INTO `rlb_program` VALUES ('5','Daily 11:00 Filtering Start','0','V','1','0','11:01:00','12:00:00','2016-06-23 09:06:33','0000-00-00 00:00:00','1','0','',NULL,NULL,'00:59:00',NULL,NULL,'0','0','0','2','1');
INSERT INTO `rlb_program` VALUES ('6','Daily 11:00 Filtering Start','5','V','1','0','11:01:00','12:00:00','2016-06-23 09:08:26','0000-00-00 00:00:00','1','0','',NULL,NULL,'00:59:00',NULL,NULL,'0','0','0','2','1');
INSERT INTO `rlb_program` VALUES ('7','Daily 11:00 Filtering Start','4','V','1','0','11:01:00','12:00:00','2016-06-23 09:09:37','0000-00-00 00:00:00','1','0','',NULL,NULL,'00:59:00',NULL,NULL,'0','0','0','2','2');
INSERT INTO `rlb_program` VALUES ('8','Daily 11:00 Filtering End','4','V','1','0','12:05:00','12:10:00','2016-06-23 09:11:26','0000-00-00 00:00:00','1','0','',NULL,NULL,'00:05:00',NULL,NULL,'0','0','0','2','1');
INSERT INTO `rlb_program` VALUES ('9','Daily 11:00 Filtering End','5','V','1','0','12:05:00','12:10:00','2016-06-23 09:12:56','0000-00-00 00:00:00','1','0','',NULL,NULL,'00:05:00',NULL,NULL,'0','0','0','2','2');
INSERT INTO `rlb_program` VALUES ('10','Daily 11:00 Filtering End','4','V','1','0','12:05:00','12:10:00','2016-06-23 09:14:09','0000-00-00 00:00:00','1','0','',NULL,NULL,'00:05:00',NULL,NULL,'0','0','0','1','1');
INSERT INTO `rlb_program` VALUES ('11','Daily 11:00 Filtering End','0','V','1','0','12:04:00','12:10:00','2016-06-23 09:16:27','0000-00-00 00:00:00','1','0','',NULL,NULL,'00:06:00',NULL,NULL,'0','0','0','2','1');
INSERT INTO `rlb_program` VALUES ('12','Daily 11:00 Filtering End','3','V','1','0','12:05:00','12:10:00','2016-06-23 09:17:49','0000-00-00 00:00:00','1','0','',NULL,NULL,'00:05:00',NULL,NULL,'0','0','0','2','2');
INSERT INTO `rlb_program` VALUES ('13','Test Program','0','V','1','0','01:00:00','01:10:00','2016-06-24 01:17:39','0000-00-00 00:00:00','1','0','',NULL,NULL,'00:10:00',NULL,NULL,'0','0','0','1','1');
INSERT INTO `rlb_program` VALUES ('14','Test Program','1','PS','1','0','01:05:00','01:10:00','2016-06-24 01:18:08','0000-00-00 00:00:00','1','0','',NULL,NULL,'00:05:00',NULL,NULL,'0','0','0','1','0');
INSERT INTO `rlb_program` VALUES ('15','Test Program','6','R','1','0','01:05:00','01:10:00','2016-06-24 01:18:59','0000-00-00 00:00:00','1','0','',NULL,NULL,'00:05:00',NULL,NULL,'0','0','0','1','0');
INSERT INTO `rlb_program` VALUES ('16','Test Program','1','PS','1','0','04:35:00','05:55:00','2016-06-24 02:01:29','2016-06-24 04:35:26','1','0','1','','','01:20:00','','2016-06-24','1','0','1','1','0');
INSERT INTO `rlb_program` VALUES ('17','Test Program','0','V','1','0','03:15:00','03:50:00','2016-06-24 02:02:12','2016-06-24 03:15:42','1','0','0','','','00:35:00','00:00:00','2016-06-24','0','0','0','1','1');
INSERT INTO `rlb_program` VALUES ('18','Test Program','6','R','1','0','01:00:00','01:10:00','2016-06-24 02:02:55','0000-00-00 00:00:00','0','0','',NULL,NULL,'00:10:00',NULL,NULL,'0','0','0','1','0');
INSERT INTO `rlb_program` VALUES ('19','Test Program 2','2','PS','1','0','04:30:00','05:55:00','2016-06-24 03:26:07','2016-06-24 04:35:53','0','0','0',NULL,NULL,'01:25:00',NULL,NULL,'0','0','0','1','0');
INSERT INTO `rlb_program` VALUES ('31','test 1','4','V','1','0','22:20:00','22:35:00','2016-06-27 22:14:56','0000-00-00 00:00:00','1','0','',NULL,NULL,'00:15:00',NULL,NULL,'0','0','1','1','1');
INSERT INTO `rlb_program` VALUES ('20','Daily Filtering','1','PS','1','0','11:40:00','16:40:00','2016-06-27 11:36:36','2016-06-27 22:18:52','0','0','1','','','05:00:00','','2016-06-27','1','0','1','1','0');
INSERT INTO `rlb_program` VALUES ('21','Spa 2 Filtering On','4','V','1','0','12:00:00','12:01:00','2016-06-27 11:40:24','2016-06-27 11:42:08','1','0','',NULL,NULL,'00:01:00',NULL,NULL,'0','0','1','1','2');
INSERT INTO `rlb_program` VALUES ('22','Spa 2 Daily Filtering','4','V','1','0','13:01:00','13:02:00','2016-06-27 11:43:19','0000-00-00 00:00:00','1','0','',NULL,NULL,'00:01:00',NULL,NULL,'0','0','1','1','1');
INSERT INTO `rlb_program` VALUES ('23','Spa 2 Daily Filtering','3','V','1','0','12:01:00','12:02:00','2016-06-27 11:44:46','0000-00-00 00:00:00','1','0','',NULL,NULL,'00:01:00',NULL,NULL,'0','0','1','2','1');
INSERT INTO `rlb_program` VALUES ('24','Spa 2 Daily Filtering Off','3','V','1','0','13:01:00','13:02:00','2016-06-27 11:45:31','0000-00-00 00:00:00','1','0','',NULL,NULL,'00:01:00',NULL,NULL,'0','0','1','2','2');
INSERT INTO `rlb_program` VALUES ('25','Spa 2 Daily Filtering','0','V','1','0','12:03:00','12:04:00','2016-06-27 11:46:28','0000-00-00 00:00:00','1','0','',NULL,NULL,'00:01:00',NULL,NULL,'0','0','1','2','2');
INSERT INTO `rlb_program` VALUES ('26','Spa 2 Daily Filtering Off','0','V','1','0','13:03:00','13:04:00','2016-06-27 11:47:33','0000-00-00 00:00:00','1','0','',NULL,NULL,'00:01:00',NULL,NULL,'0','0','1','2','1');
INSERT INTO `rlb_program` VALUES ('27','Spa 2 Daily Filtering','5','V','1','0','12:04:00','12:05:00','2016-06-27 11:48:58','0000-00-00 00:00:00','1','0','',NULL,NULL,'00:01:00',NULL,NULL,'0','0','1','2','1');
INSERT INTO `rlb_program` VALUES ('28','Spa 2 Daily Filtering Off','5','V','1','0','13:04:00','13:05:00','2016-06-27 11:49:44','0000-00-00 00:00:00','1','0','',NULL,NULL,'00:01:00',NULL,NULL,'0','0','1','2','1');
INSERT INTO `rlb_program` VALUES ('29','Spa 2 Daily Filtering','4','V','1','0','12:04:00','12:05:00','2016-06-27 11:50:40','0000-00-00 00:00:00','1','0','',NULL,NULL,'00:01:00',NULL,NULL,'0','0','1','2','2');
INSERT INTO `rlb_program` VALUES ('30','Spa 2 Daily Filtering Off','4','V','1','0','13:04:00','13:05:00','2016-06-27 11:51:07','0000-00-00 00:00:00','1','0','',NULL,NULL,'00:01:00',NULL,NULL,'0','0','1','2','1');

/*---------------------------------------------------------------
  TABLE: `rlb_pump_device`
  ---------------------------------------------------------------*/
DROP TABLE IF EXISTS `rlb_pump_device`;
CREATE TABLE `rlb_pump_device` (
  `pump_id` int(10) NOT NULL AUTO_INCREMENT,
  `pump_number` int(5) NOT NULL,
  `pump_type` enum('12','24','Intellicom','Emulator','Intellicom12','Intellicom24','Emulator12','Emulator24','2Speed') NOT NULL,
  `pump_sub_type` enum('VS','VF','12','24') NOT NULL,
  `pump_speed` varchar(150) NOT NULL,
  `pump_flow` varchar(250) NOT NULL,
  `pump_closure` varchar(150) NOT NULL,
  `relay_number` varchar(10) NOT NULL,
  `pump_address` varchar(50) NOT NULL,
  `pump_modified_date` datetime NOT NULL,
  `relay_number_1` varchar(10) NOT NULL,
  `status` enum('0','1','2') NOT NULL DEFAULT '0',
  `ip_id` int(5) NOT NULL,
  `pump_on` enum('0','1') NOT NULL DEFAULT '0',
  PRIMARY KEY (`pump_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;
INSERT INTO `rlb_pump_device` VALUES   ('1','1','Emulator','VS','3110','','1','','60','2016-06-21 23:29:32','','0','1','0');
INSERT INTO `rlb_pump_device` VALUES ('2','2','Emulator','VS','3100','','0','','61','2016-06-22 10:33:30','','0','1','0');
INSERT INTO `rlb_pump_device` VALUES ('3','3','24','','','','1','14','','2016-06-22 16:19:09','','0','1','0');

/*---------------------------------------------------------------
  TABLE: `rlb_pump_heater`
  ---------------------------------------------------------------*/
DROP TABLE IF EXISTS `rlb_pump_heater`;
CREATE TABLE `rlb_pump_heater` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `pump` varchar(10) NOT NULL,
  `end_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*---------------------------------------------------------------
  TABLE: `rlb_pump_response`
  ---------------------------------------------------------------*/
DROP TABLE IF EXISTS `rlb_pump_response`;
CREATE TABLE `rlb_pump_response` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `pump_number` int(5) NOT NULL,
  `pump_response_time` datetime NOT NULL,
  `pump_response` varchar(255) DEFAULT NULL,
  `ip_id` int(5) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*---------------------------------------------------------------
  TABLE: `rlb_reboot_history`
  ---------------------------------------------------------------*/
DROP TABLE IF EXISTS `rlb_reboot_history`;
CREATE TABLE `rlb_reboot_history` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `details` text NOT NULL,
  `ip_id` int(5) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=79 DEFAULT CHARSET=latin1;
INSERT INTO `rlb_reboot_history` VALUES   ('1','a:5:{s:9:\"sResponse\";s:120:\"S,145,0,1,12:22:00,3,06,000.000.,......00......00,00000000,0,0,0,0,12515,98.9F,89.0F,,87.6F,88.7F,85.3F,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"000.000.\";s:7:\"sRelays\";s:16:\"......00......00\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','1');
INSERT INTO `rlb_reboot_history` VALUES ('2','a:5:{s:9:\"sResponse\";s:101:\"S,181,0,1,12:21:54,3,06,000000..,............0000,00000000,0,0,0,0,12515,100.0F,,,,,,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"000000..\";s:7:\"sRelays\";s:16:\"............0000\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','2');
INSERT INTO `rlb_reboot_history` VALUES ('3','a:5:{s:9:\"sResponse\";s:126:\"S,003,0,0,11:39:13,3,06,000.000.,......00......10,00000000,0,0,0,0,12531,101.5F,86.9F,86.8F,85.7F,81.5F,84.7F,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"000.000.\";s:7:\"sRelays\";s:16:\"......00......10\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:3:{i:0;s:1:\"1\";i:1;s:1:\"2\";i:2;s:1:\"3\";}}','1');
INSERT INTO `rlb_reboot_history` VALUES ('4','a:5:{s:9:\"sResponse\";s:100:\"S,192,0,0,11:39:14,3,06,000000..,............0000,00000000,0,0,0,0,12531,98.8F,,,,,,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"000000..\";s:7:\"sRelays\";s:16:\"............0000\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','2');
INSERT INTO `rlb_reboot_history` VALUES ('5','a:5:{s:9:\"sResponse\";s:126:\"S,006,0,0,23:54:36,3,06,000.000.,......00......00,00000000,0,0,0,0,12515,101.4F,86.5F,86.6F,84.9F,86.0F,84.0F,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"000.000.\";s:7:\"sRelays\";s:16:\"......00......00\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','1');
INSERT INTO `rlb_reboot_history` VALUES ('6','a:5:{s:9:\"sResponse\";s:100:\"S,146,0,1,11:38:52,3,06,000000..,............0000,00000000,0,0,0,0,12515,97.8F,,,,,,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"000000..\";s:7:\"sRelays\";s:16:\"............0000\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','2');
INSERT INTO `rlb_reboot_history` VALUES ('7','a:5:{s:9:\"sResponse\";s:126:\"S,065,0,0,23:59:17,3,06,000.000.,......00......00,00000000,0,0,0,0,12500,100.0F,83.9F,84.0F,83.2F,84.2F,83.0F,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"000.000.\";s:7:\"sRelays\";s:16:\"......00......00\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','1');
INSERT INTO `rlb_reboot_history` VALUES ('8','a:5:{s:9:\"sResponse\";s:100:\"S,111,0,2,11:38:31,3,06,000000..,............0000,00000000,0,0,0,0,12515,97.8F,,,,,,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"000000..\";s:7:\"sRelays\";s:16:\"............0000\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','2');
INSERT INTO `rlb_reboot_history` VALUES ('9','a:5:{s:9:\"sResponse\";s:126:\"S,023,0,0,23:59:19,3,06,000.000.,......00......00,00000000,0,0,0,0,12515,102.5F,86.8F,87.2F,85.7F,86.9F,85.2F,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"000.000.\";s:7:\"sRelays\";s:16:\"......00......00\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','1');
INSERT INTO `rlb_reboot_history` VALUES ('10','a:5:{s:9:\"sResponse\";s:100:\"S,175,0,3,11:38:10,3,06,000000..,............0000,00000000,0,0,0,0,12531,98.8F,,,,,,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"000000..\";s:7:\"sRelays\";s:16:\"............0000\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','2');
INSERT INTO `rlb_reboot_history` VALUES ('11','a:5:{s:9:\"sResponse\";s:126:\"S,244,0,0,23:59:16,3,06,000.000.,......00......00,00000000,0,0,0,0,12500,103.6F,86.0F,86.1F,85.8F,86.0F,86.2F,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"000.000.\";s:7:\"sRelays\";s:16:\"......00......00\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','1');
INSERT INTO `rlb_reboot_history` VALUES ('12','a:5:{s:9:\"sResponse\";s:101:\"S,006,0,4,11:37:48,3,06,000000..,............0000,00000000,0,0,0,0,12531,103.3F,,,,,,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"000000..\";s:7:\"sRelays\";s:16:\"............0000\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','2');
INSERT INTO `rlb_reboot_history` VALUES ('13','a:5:{s:9:\"sResponse\";s:125:\"S,143,0,0,23:59:19,3,06,000.000.,......00......00,00000000,0,0,0,0,12500,99.2F,92.1F,92.6F,90.3F,92.3F,93.0F,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"000.000.\";s:7:\"sRelays\";s:16:\"......00......00\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','1');
INSERT INTO `rlb_reboot_history` VALUES ('14','a:5:{s:9:\"sResponse\";s:101:\"S,078,0,5,11:37:27,3,06,000000..,............0000,00000000,0,0,0,0,12515,103.4F,,,,,,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"000000..\";s:7:\"sRelays\";s:16:\"............0000\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','2');
INSERT INTO `rlb_reboot_history` VALUES ('15','a:5:{s:9:\"sResponse\";s:125:\"S,026,0,0,23:59:24,3,06,000.000.,......00......00,00000000,0,0,0,0,12500,93.4F,85.8F,86.3F,86.0F,86.0F,86.6F,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"000.000.\";s:7:\"sRelays\";s:16:\"......00......00\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','1');
INSERT INTO `rlb_reboot_history` VALUES ('16','a:5:{s:9:\"sResponse\";s:100:\"S,213,0,6,11:37:06,3,06,000000..,............0000,00000000,0,0,0,0,12515,97.5F,,,,,,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"000000..\";s:7:\"sRelays\";s:16:\"............0000\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','2');
INSERT INTO `rlb_reboot_history` VALUES ('17','a:5:{s:9:\"sResponse\";s:125:\"S,189,0,0,23:59:19,3,06,000.000.,......00......00,01000000,0,0,0,0,12484,97.6F,88.7F,88.5F,86.9F,88.7F,90.1F,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"000.000.\";s:7:\"sRelays\";s:16:\"......00......00\";s:12:\"sPowercenter\";s:8:\"01000000\";s:5:\"sPump\";a:0:{}}','1');
INSERT INTO `rlb_reboot_history` VALUES ('18','a:5:{s:9:\"sResponse\";s:101:\"S,014,0,7,11:36:45,3,06,000000..,............0000,00000000,0,0,0,0,12515,101.2F,,,,,,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"000000..\";s:7:\"sRelays\";s:16:\"............0000\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','2');
INSERT INTO `rlb_reboot_history` VALUES ('19','a:5:{s:9:\"sResponse\";s:125:\"S,085,0,0,23:59:25,3,06,000.000.,......00......00,00000000,0,0,0,0,12484,83.6F,74.4F,73.2F,74.1F,77.0F,76.9F,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"000.000.\";s:7:\"sRelays\";s:16:\"......00......00\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','1');
INSERT INTO `rlb_reboot_history` VALUES ('20','a:5:{s:9:\"sResponse\";s:100:\"S,210,0,1,11:36:28,3,06,000000..,............0000,00000000,0,0,0,0,12515,87.8F,,,,,,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"000000..\";s:7:\"sRelays\";s:16:\"............0000\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','2');
INSERT INTO `rlb_reboot_history` VALUES ('21','a:5:{s:9:\"sResponse\";s:125:\"S,226,0,0,19:37:08,3,06,000.000.,......00......00,00000000,0,0,0,0,12484,89.4F,80.0F,80.0F,80.8F,80.6F,82.9F,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"000.000.\";s:7:\"sRelays\";s:16:\"......00......00\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','1');
INSERT INTO `rlb_reboot_history` VALUES ('22','a:5:{s:9:\"sResponse\";s:100:\"S,252,0,0,19:37:04,3,06,000000..,............0000,00000000,0,0,0,0,12500,93.3F,,,,,,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"000000..\";s:7:\"sRelays\";s:16:\"............0000\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','2');
INSERT INTO `rlb_reboot_history` VALUES ('23','a:5:{s:9:\"sResponse\";s:125:\"S,138,0,0,23:59:22,3,06,000.000.,......00......00,00000000,0,0,0,0,12484,92.4F,85.6F,86.1F,84.9F,86.0F,86.7F,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"000.000.\";s:7:\"sRelays\";s:16:\"......00......00\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','1');
INSERT INTO `rlb_reboot_history` VALUES ('24','a:5:{s:9:\"sResponse\";s:100:\"S,169,0,1,19:36:45,3,06,000000..,............0000,00000000,0,0,0,0,12500,96.5F,,,,,,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"000000..\";s:7:\"sRelays\";s:16:\"............0000\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','2');
INSERT INTO `rlb_reboot_history` VALUES ('25','a:5:{s:9:\"sResponse\";s:125:\"S,030,0,0,23:59:19,3,06,000.000.,......00......00,00000000,0,0,0,0,12500,91.2F,84.4F,84.5F,83.8F,84.2F,85.4F,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"000.000.\";s:7:\"sRelays\";s:16:\"......00......00\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','1');
INSERT INTO `rlb_reboot_history` VALUES ('26','a:5:{s:9:\"sResponse\";s:100:\"S,078,0,2,19:36:26,3,06,010000..,............0000,00000000,0,0,0,0,12515,95.5F,,,,,,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"010000..\";s:7:\"sRelays\";s:16:\"............0000\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','2');
INSERT INTO `rlb_reboot_history` VALUES ('27','a:5:{s:9:\"sResponse\";s:125:\"S,117,0,0,23:59:18,3,06,000.100.,......00......00,00000000,0,0,0,0,12500,90.5F,84.1F,84.1F,82.6F,79.7F,84.5F,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"000.100.\";s:7:\"sRelays\";s:16:\"......00......00\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:1:{i:0;s:1:\"1\";}}','1');
INSERT INTO `rlb_reboot_history` VALUES ('28','a:5:{s:9:\"sResponse\";s:100:\"S,152,0,3,19:36:08,3,06,210202..,............0000,00000000,0,0,0,0,12515,95.9F,,,,,,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"210202..\";s:7:\"sRelays\";s:16:\"............0000\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','2');
INSERT INTO `rlb_reboot_history` VALUES ('29','a:5:{s:9:\"sResponse\";s:125:\"S,148,0,0,23:59:24,3,06,000.000.,......00......00,00000000,0,0,0,0,12500,88.8F,82.1F,82.1F,80.9F,77.9F,83.3F,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"000.000.\";s:7:\"sRelays\";s:16:\"......00......00\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:1:{i:0;s:1:\"1\";}}','1');
INSERT INTO `rlb_reboot_history` VALUES ('30','a:5:{s:9:\"sResponse\";s:100:\"S,169,0,4,19:35:51,3,06,000000..,............0000,00000000,0,0,0,0,12515,92.9F,,,,,,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"000000..\";s:7:\"sRelays\";s:16:\"............0000\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','2');
INSERT INTO `rlb_reboot_history` VALUES ('31','a:5:{s:9:\"sResponse\";s:125:\"S,127,0,0,23:59:26,3,06,100.000.,......00......00,00000000,0,0,0,0,12500,90.4F,83.1F,83.1F,81.5F,82.4F,83.8F,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"100.000.\";s:7:\"sRelays\";s:16:\"......00......00\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','1');
INSERT INTO `rlb_reboot_history` VALUES ('32','a:5:{s:9:\"sResponse\";s:100:\"S,003,0,5,19:35:33,3,06,010000..,............0000,00000000,0,0,0,0,12515,94.1F,,,,,,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"010000..\";s:7:\"sRelays\";s:16:\"............0000\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','2');
INSERT INTO `rlb_reboot_history` VALUES ('33','a:5:{s:9:\"sResponse\";s:125:\"S,163,0,0,23:59:24,3,06,000.001.,......00......00,00000000,0,0,0,0,12500,96.0F,83.9F,84.0F,81.6F,83.3F,82.2F,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"000.001.\";s:7:\"sRelays\";s:16:\"......00......00\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','1');
INSERT INTO `rlb_reboot_history` VALUES ('34','a:5:{s:9:\"sResponse\";s:100:\"S,075,0,6,19:35:16,3,06,000000..,............0000,00000000,0,0,0,0,12531,94.8F,,,,,,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"000000..\";s:7:\"sRelays\";s:16:\"............0000\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','2');
INSERT INTO `rlb_reboot_history` VALUES ('35','a:5:{s:9:\"sResponse\";s:125:\"S,147,0,0,23:59:19,3,06,000.001.,......00......00,00000000,0,0,0,0,12500,92.3F,83.9F,84.0F,82.7F,83.3F,82.0F,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"000.001.\";s:7:\"sRelays\";s:16:\"......00......00\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','1');
INSERT INTO `rlb_reboot_history` VALUES ('36','a:5:{s:9:\"sResponse\";s:100:\"S,172,0,7,19:34:57,3,06,000000..,............0000,00000000,0,0,0,0,12531,94.2F,,,,,,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"000000..\";s:7:\"sRelays\";s:16:\"............0000\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','2');
INSERT INTO `rlb_reboot_history` VALUES ('37','a:5:{s:9:\"sResponse\";s:125:\"S,062,0,0,23:59:28,3,06,000.000.,......00......00,00000000,0,0,0,0,12500,93.9F,79.7F,79.4F,80.7F,78.8F,78.4F,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"000.000.\";s:7:\"sRelays\";s:16:\"......00......00\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','1');
INSERT INTO `rlb_reboot_history` VALUES ('38','a:5:{s:9:\"sResponse\";s:100:\"S,237,0,1,19:34:40,3,06,000000..,............0000,00000000,0,0,0,0,12531,90.6F,,,,,,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"000000..\";s:7:\"sRelays\";s:16:\"............0000\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','2');
INSERT INTO `rlb_reboot_history` VALUES ('39','a:5:{s:9:\"sResponse\";s:125:\"S,249,0,0,23:59:22,3,06,000.000.,......00......00,00000000,0,0,0,0,12484,94.3F,82.2F,82.4F,81.6F,81.5F,81.1F,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"000.000.\";s:7:\"sRelays\";s:16:\"......00......00\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','1');
INSERT INTO `rlb_reboot_history` VALUES ('40','a:5:{s:9:\"sResponse\";s:100:\"S,150,0,2,19:34:23,3,06,000200..,............0000,00000000,0,0,0,0,12531,93.7F,,,,,,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"000200..\";s:7:\"sRelays\";s:16:\"............0000\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','2');
INSERT INTO `rlb_reboot_history` VALUES ('41','a:5:{s:9:\"sResponse\";s:125:\"S,071,0,0,23:59:17,3,06,000.000.,......00......00,00000000,0,0,0,0,12500,96.6F,83.3F,83.6F,81.5F,78.8F,81.7F,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"000.000.\";s:7:\"sRelays\";s:16:\"......00......00\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','1');
INSERT INTO `rlb_reboot_history` VALUES ('42','a:5:{s:9:\"sResponse\";s:100:\"S,253,0,3,19:34:04,3,06,000200..,............0000,00000000,0,0,0,0,12515,95.3F,,,,,,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"000200..\";s:7:\"sRelays\";s:16:\"............0000\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','2');
INSERT INTO `rlb_reboot_history` VALUES ('43','a:5:{s:9:\"sResponse\";s:125:\"S,015,0,0,23:59:21,3,06,000.000.,......00......00,00000000,0,0,0,0,12515,98.7F,81.6F,81.3F,80.7F,81.5F,81.8F,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"000.000.\";s:7:\"sRelays\";s:16:\"......00......00\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','1');
INSERT INTO `rlb_reboot_history` VALUES ('44','a:5:{s:9:\"sResponse\";s:100:\"S,100,0,4,19:33:46,3,06,000200..,............0000,00000000,0,0,0,0,12531,97.5F,,,,,,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"000200..\";s:7:\"sRelays\";s:16:\"............0000\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','2');
INSERT INTO `rlb_reboot_history` VALUES ('45','a:5:{s:9:\"sResponse\";s:126:\"S,153,0,0,23:59:15,3,06,000.100.,......00......00,00000000,0,0,0,0,12515,101.4F,84.3F,84.3F,83.2F,79.7F,83.4F,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"000.100.\";s:7:\"sRelays\";s:16:\"......00......00\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:1:{i:0;s:1:\"1\";}}','1');
INSERT INTO `rlb_reboot_history` VALUES ('46','a:5:{s:9:\"sResponse\";s:100:\"S,047,0,5,19:33:26,3,06,200212..,............0000,00000000,0,0,0,0,12515,98.7F,,,,,,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"200212..\";s:7:\"sRelays\";s:16:\"............0000\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','2');
INSERT INTO `rlb_reboot_history` VALUES ('47','a:5:{s:9:\"sResponse\";s:125:\"S,185,0,0,23:59:20,3,06,000.000.,......00......00,00000000,0,0,0,0,12500,95.8F,87.6F,87.6F,86.6F,86.9F,84.7F,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"000.000.\";s:7:\"sRelays\";s:16:\"......00......00\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:1:{i:0;s:1:\"1\";}}','1');
INSERT INTO `rlb_reboot_history` VALUES ('48','a:5:{s:9:\"sResponse\";s:100:\"S,113,0,6,19:33:06,3,06,200212..,............0000,00000000,0,0,0,0,12515,99.6F,,,,,,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"200212..\";s:7:\"sRelays\";s:16:\"............0000\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','2');
INSERT INTO `rlb_reboot_history` VALUES ('49','a:5:{s:9:\"sResponse\";s:125:\"S,115,0,0,23:59:23,3,06,000.000.,......00......00,00000000,0,0,0,0,12500,94.4F,86.9F,87.1F,85.9F,86.9F,83.6F,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"000.000.\";s:7:\"sRelays\";s:16:\"......00......00\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:1:{i:0;s:1:\"1\";}}','1');
INSERT INTO `rlb_reboot_history` VALUES ('50','a:5:{s:9:\"sResponse\";s:100:\"S,177,0,7,19:32:47,3,06,200212..,............0000,00000000,0,0,0,0,12515,98.6F,,,,,,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"200212..\";s:7:\"sRelays\";s:16:\"............0000\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','2');
INSERT INTO `rlb_reboot_history` VALUES ('51','a:5:{s:9:\"sResponse\";s:125:\"S,185,0,0,23:59:25,3,06,000.000.,......10......00,10000000,0,0,0,0,12515,99.6F,86.3F,86.7F,85.8F,86.9F,83.8F,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"000.000.\";s:7:\"sRelays\";s:16:\"......10......00\";s:12:\"sPowercenter\";s:8:\"10000000\";s:5:\"sPump\";a:1:{i:0;s:1:\"2\";}}','1');
INSERT INTO `rlb_reboot_history` VALUES ('52','a:5:{s:9:\"sResponse\";s:100:\"S,221,0,1,19:32:29,3,06,000000..,............0000,00000000,0,0,0,0,12531,98.2F,,,,,,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"000000..\";s:7:\"sRelays\";s:16:\"............0000\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','2');
INSERT INTO `rlb_reboot_history` VALUES ('53','a:5:{s:9:\"sResponse\";s:125:\"S,021,0,0,23:59:23,3,06,000.200.,......00......00,00000000,0,0,0,0,12500,98.4F,83.5F,87.5F,85.2F,86.9F,84.2F,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"000.200.\";s:7:\"sRelays\";s:16:\"......00......00\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:1:{i:0;s:1:\"2\";}}','1');
INSERT INTO `rlb_reboot_history` VALUES ('54','a:5:{s:9:\"sResponse\";s:100:\"S,007,0,2,19:32:10,3,06,000001..,............0000,00000000,0,0,0,0,12531,98.6F,,,,,,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"000001..\";s:7:\"sRelays\";s:16:\"............0000\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','2');
INSERT INTO `rlb_reboot_history` VALUES ('55','a:5:{s:9:\"sResponse\";s:126:\"S,117,0,0,23:59:15,3,06,000.000.,......00......00,00000000,0,0,0,0,12500,100.5F,85.6F,86.5F,84.9F,86.0F,83.9F,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"000.000.\";s:7:\"sRelays\";s:16:\"......00......00\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:1:{i:0;s:1:\"2\";}}','1');
INSERT INTO `rlb_reboot_history` VALUES ('56','a:5:{s:9:\"sResponse\";s:100:\"S,239,0,3,19:31:52,3,06,000000..,............0000,00000000,0,0,0,0,12531,97.4F,,,,,,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"000000..\";s:7:\"sRelays\";s:16:\"............0000\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','2');
INSERT INTO `rlb_reboot_history` VALUES ('57','a:5:{s:9:\"sResponse\";s:126:\"S,054,0,0,23:59:16,3,06,000.000.,......00......00,00000000,0,0,0,0,12500,104.3F,87.6F,88.1F,86.0F,87.8F,85.7F,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"000.000.\";s:7:\"sRelays\";s:16:\"......00......00\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','1');
INSERT INTO `rlb_reboot_history` VALUES ('58','a:5:{s:9:\"sResponse\";s:101:\"S,068,0,4,19:31:31,3,06,000000..,............0000,00000000,0,0,0,0,12515,100.4F,,,,,,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"000000..\";s:7:\"sRelays\";s:16:\"............0000\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','2');
INSERT INTO `rlb_reboot_history` VALUES ('59','a:5:{s:9:\"sResponse\";s:126:\"S,226,0,0,23:59:20,3,06,100.100.,......00......00,00000000,0,0,0,0,12500,102.4F,88.8F,89.5F,87.1F,86.9F,87.0F,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"100.100.\";s:7:\"sRelays\";s:16:\"......00......00\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','1');
INSERT INTO `rlb_reboot_history` VALUES ('60','a:5:{s:9:\"sResponse\";s:101:\"S,134,0,5,19:31:11,3,06,000000..,............0000,00000000,0,0,0,0,12531,100.7F,,,,,,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"000000..\";s:7:\"sRelays\";s:16:\"............0000\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','2');
INSERT INTO `rlb_reboot_history` VALUES ('61','a:5:{s:9:\"sResponse\";s:125:\"S,206,0,0,23:59:23,3,06,100.000.,......00......00,00000000,0,0,0,0,12515,99.7F,90.8F,91.6F,89.3F,91.4F,87.9F,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"100.000.\";s:7:\"sRelays\";s:16:\"......00......00\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','1');
INSERT INTO `rlb_reboot_history` VALUES ('62','a:5:{s:9:\"sResponse\";s:101:\"S,113,0,6,19:30:49,3,06,010000..,............0000,00000000,0,0,0,0,12515,101.9F,,,,,,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"010000..\";s:7:\"sRelays\";s:16:\"............0000\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','2');
INSERT INTO `rlb_reboot_history` VALUES ('63','a:5:{s:9:\"sResponse\";s:126:\"S,145,0,0,23:59:15,3,06,000.000.,......00......00,00000000,0,0,0,0,12515,102.5F,91.6F,92.1F,90.3F,91.4F,88.4F,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"000.000.\";s:7:\"sRelays\";s:16:\"......00......00\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','1');
INSERT INTO `rlb_reboot_history` VALUES ('64','a:5:{s:9:\"sResponse\";s:101:\"S,177,0,7,19:30:27,3,06,010000..,............0000,00000000,0,0,0,0,12515,103.0F,,,,,,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"010000..\";s:7:\"sRelays\";s:16:\"............0000\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','2');
INSERT INTO `rlb_reboot_history` VALUES ('65','a:5:{s:9:\"sResponse\";s:125:\"S,045,0,0,23:59:18,3,06,000.000.,......00......00,00000000,0,0,0,0,12500,99.1F,91.4F,91.9F,90.3F,91.4F,88.4F,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"000.000.\";s:7:\"sRelays\";s:16:\"......00......00\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','1');
INSERT INTO `rlb_reboot_history` VALUES ('66','a:5:{s:9:\"sResponse\";s:101:\"S,251,0,1,19:30:06,3,06,010000..,............0000,00000000,0,0,0,0,12515,102.5F,,,,,,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"010000..\";s:7:\"sRelays\";s:16:\"............0000\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','2');
INSERT INTO `rlb_reboot_history` VALUES ('67','a:5:{s:9:\"sResponse\";s:126:\"S,115,0,0,23:59:18,3,06,000.000.,......00......00,00000000,0,0,0,0,12500,105.7F,91.4F,91.9F,90.5F,91.4F,88.8F,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"000.000.\";s:7:\"sRelays\";s:16:\"......00......00\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','1');
INSERT INTO `rlb_reboot_history` VALUES ('68','a:5:{s:9:\"sResponse\";s:101:\"S,060,0,2,19:29:45,3,06,010000..,............0000,00000000,0,0,0,0,12515,103.6F,,,,,,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"010000..\";s:7:\"sRelays\";s:16:\"............0000\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','2');
INSERT INTO `rlb_reboot_history` VALUES ('69','a:5:{s:9:\"sResponse\";s:126:\"S,132,0,0,23:59:15,3,06,000.000.,......00......00,00000000,0,0,0,0,12500,100.0F,92.5F,92.9F,92.0F,92.3F,93.1F,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"000.000.\";s:7:\"sRelays\";s:16:\"......00......00\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','1');
INSERT INTO `rlb_reboot_history` VALUES ('70','a:5:{s:9:\"sResponse\";s:101:\"S,127,0,3,19:29:24,3,06,010000..,............0000,00000000,0,0,0,0,12515,104.2F,,,,,,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"010000..\";s:7:\"sRelays\";s:16:\"............0000\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','2');
INSERT INTO `rlb_reboot_history` VALUES ('71','a:5:{s:9:\"sResponse\";s:126:\"S,205,0,0,23:59:19,3,06,000.100.,......00......00,00000000,0,0,0,0,12484,101.0F,92.2F,92.3F,91.7F,83.3F,93.7F,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"000.100.\";s:7:\"sRelays\";s:16:\"......00......00\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','1');
INSERT INTO `rlb_reboot_history` VALUES ('72','a:5:{s:9:\"sResponse\";s:101:\"S,247,0,4,19:29:03,3,06,210112..,............0000,00000000,0,0,0,0,12515,105.9F,,,,,,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"210112..\";s:7:\"sRelays\";s:16:\"............0000\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','2');
INSERT INTO `rlb_reboot_history` VALUES ('73','a:5:{s:9:\"sResponse\";s:126:\"S,194,0,0,23:59:16,3,06,100.101.,......00......00,00000000,0,0,0,0,12500,108.6F,93.5F,93.9F,92.0F,84.2F,90.8F,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"100.101.\";s:7:\"sRelays\";s:16:\"......00......00\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','1');
INSERT INTO `rlb_reboot_history` VALUES ('74','a:5:{s:9:\"sResponse\";s:101:\"S,248,0,5,19:28:42,3,06,210012..,............0000,00000000,0,0,0,0,12515,109.2F,,,,,,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"210012..\";s:7:\"sRelays\";s:16:\"............0000\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','2');
INSERT INTO `rlb_reboot_history` VALUES ('75','a:5:{s:9:\"sResponse\";s:126:\"S,148,0,0,23:59:19,3,06,000.001.,......00......00,00000000,0,0,0,0,12500,104.6F,92.3F,92.2F,90.8F,92.3F,90.2F,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"000.001.\";s:7:\"sRelays\";s:16:\"......00......00\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','1');
INSERT INTO `rlb_reboot_history` VALUES ('76','a:5:{s:9:\"sResponse\";s:101:\"S,183,0,6,19:28:21,3,06,012000..,............0000,00000000,0,0,0,0,12515,106.8F,,,,,,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"012000..\";s:7:\"sRelays\";s:16:\"............0000\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','2');
INSERT INTO `rlb_reboot_history` VALUES ('77','a:5:{s:9:\"sResponse\";s:126:\"S,119,0,0,23:59:19,3,06,000.000.,......00......00,00000000,0,0,0,0,12500,104.0F,87.5F,87.2F,86.9F,86.9F,87.2F,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"000.000.\";s:7:\"sRelays\";s:16:\"......00......00\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','1');
INSERT INTO `rlb_reboot_history` VALUES ('78','a:5:{s:9:\"sResponse\";s:101:\"S,029,0,7,19:28:01,3,06,012000..,............0000,00000000,0,0,0,0,12500,100.5F,,,,,,0.00,000000,0.00\";s:7:\"sValves\";s:8:\"012000..\";s:7:\"sRelays\";s:16:\"............0000\";s:12:\"sPowercenter\";s:8:\"00000000\";s:5:\"sPump\";a:0:{}}','2');

/*---------------------------------------------------------------
  TABLE: `rlb_relay_prog`
  ---------------------------------------------------------------*/
DROP TABLE IF EXISTS `rlb_relay_prog`;
CREATE TABLE `rlb_relay_prog` (
  `relay_prog_id` int(11) NOT NULL AUTO_INCREMENT,
  `relay_prog_name` varchar(255) NOT NULL,
  `relay_number` varchar(8) NOT NULL,
  `relay_prog_type` int(2) NOT NULL COMMENT '1-Daily, 2-Weekly',
  `relay_prog_days` varchar(255) NOT NULL COMMENT '0-All, 1-Mon, 2-Tue...7-Sun',
  `relay_start_time` varchar(255) NOT NULL,
  `relay_end_time` varchar(255) NOT NULL,
  `relay_prog_created_date` datetime NOT NULL,
  `relay_prog_modified_date` datetime NOT NULL,
  `relay_prog_delete` int(1) NOT NULL DEFAULT '0',
  `relay_prog_active` int(1) NOT NULL DEFAULT '0',
  `relay_prog_absolute` enum('0','1') NOT NULL DEFAULT '0',
  `relay_prog_absolute_start_time` varchar(100) DEFAULT NULL,
  `relay_prog_absolute_end_time` varchar(100) DEFAULT NULL,
  `relay_prog_absolute_total_time` varchar(100) DEFAULT NULL,
  `relay_prog_absolute_run_time` varchar(100) DEFAULT NULL,
  `relay_prog_absolute_start_date` date DEFAULT NULL,
  `relay_prog_absolute_run` enum('0','1') NOT NULL DEFAULT '0',
  PRIMARY KEY (`relay_prog_id`)
) ENGINE=MyISAM AUTO_INCREMENT=12 DEFAULT CHARSET=latin1;
INSERT INTO `rlb_relay_prog` VALUES   ('1','test','0','1','0','23:00:00','23:30:00','2015-04-03 15:40:46','2015-07-10 12:37:12','0','0','0',NULL,NULL,NULL,NULL,NULL,'0');
INSERT INTO `rlb_relay_prog` VALUES ('2','newtest1','0','2','2,3,6','14:00:00','20:00:00','2015-04-07 00:00:00','2015-04-07 00:00:00','0','0','0',NULL,NULL,NULL,NULL,NULL,'0');
INSERT INTO `rlb_relay_prog` VALUES ('3','testrelay0','0','2','1,4,5','22:00:00','23:30:00','2015-04-07 00:00:00','2015-04-07 00:00:00','0','0','0',NULL,NULL,NULL,NULL,NULL,'0');
INSERT INTO `rlb_relay_prog` VALUES ('4','testrelay1','1','1','0','10:00:00','13:00:00','2015-04-08 00:00:00','2015-04-08 00:00:00','0','0','0',NULL,NULL,NULL,NULL,NULL,'0');
INSERT INTO `rlb_relay_prog` VALUES ('5','Weeklytest','0','2','2,6','01:00:00','01:30:00','2015-04-20 00:00:00','2015-04-20 00:00:00','1','0','0',NULL,NULL,NULL,NULL,NULL,'0');
INSERT INTO `rlb_relay_prog` VALUES ('6','</>','0','1','0','</>','</>','2015-04-24 00:00:00','2015-04-24 00:00:00','1','0','0',NULL,NULL,NULL,NULL,NULL,'0');
INSERT INTO `rlb_relay_prog` VALUES ('7','dhiraj Test','0','1','0','02:00:00','02:30:00','2015-07-06 00:00:00','2015-07-13 12:50:40','0','0','1',NULL,NULL,'00:30:00','',NULL,'0');
INSERT INTO `rlb_relay_prog` VALUES ('8','Test','0','2','2,4,6','00:00:00','01:00:00','2015-07-09 07:31:37','0000-00-00 00:00:00','1','0','0',NULL,NULL,NULL,NULL,NULL,'0');
INSERT INTO `rlb_relay_prog` VALUES ('9','Test Relay 1','1','2','2,3,4','00:30:00','01:00:00','2015-07-09 08:38:46','2015-07-09 08:40:21','1','0','0',NULL,NULL,NULL,NULL,NULL,'0');
INSERT INTO `rlb_relay_prog` VALUES ('10','Program2','1','2','2,3','02:00:00','04:00:00','2015-07-09 09:05:11','2015-07-09 09:05:23','0','0','0',NULL,NULL,NULL,NULL,NULL,'0');
INSERT INTO `rlb_relay_prog` VALUES ('11','Test Relay Number','0','2','3','01:00:00','02:00:00','2015-07-09 11:41:53','2015-07-10 14:56:21','0','0','1',NULL,NULL,'01:00:00',NULL,NULL,'0');

/*---------------------------------------------------------------
  TABLE: `rlb_relays`
  ---------------------------------------------------------------*/
DROP TABLE IF EXISTS `rlb_relays`;
CREATE TABLE `rlb_relays` (
  `relay_id` int(11) NOT NULL AUTO_INCREMENT,
  `relay_number` int(11) NOT NULL,
  `relay_name` varchar(100) NOT NULL,
  PRIMARY KEY (`relay_id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;
INSERT INTO `rlb_relays` VALUES   ('1','0','Test Realy 1');
INSERT INTO `rlb_relays` VALUES ('2','2','Test for relay 2');
INSERT INTO `rlb_relays` VALUES ('3','3','Test for relay3 editedaf');
INSERT INTO `rlb_relays` VALUES ('4','5','rl5');
INSERT INTO `rlb_relays` VALUES ('5','10','relay 10');
INSERT INTO `rlb_relays` VALUES ('6','1','Test Relay 11111');

/*---------------------------------------------------------------
  TABLE: `rlb_run_after_heater`
  ---------------------------------------------------------------*/
DROP TABLE IF EXISTS `rlb_run_after_heater`;
CREATE TABLE `rlb_run_after_heater` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `heaterNumber` int(10) NOT NULL,
  `pumpNumber` int(10) NOT NULL,
  `heaterStopTime` datetime NOT NULL,
  `PumpStopTime` datetime NOT NULL,
  `ip_id` int(5) NOT NULL,
  `runComplete` enum('0','1') NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
INSERT INTO `rlb_run_after_heater` VALUES   ('1','0','1','2016-07-17 18:37:14','2016-07-17 18:42:14','1','1');
INSERT INTO `rlb_run_after_heater` VALUES ('2','1','1','2016-07-29 11:54:02','2016-07-29 11:59:02','1','1');

/*---------------------------------------------------------------
  TABLE: `rlb_setting`
  ---------------------------------------------------------------*/
DROP TABLE IF EXISTS `rlb_setting`;
CREATE TABLE `rlb_setting` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `ip_address` varchar(100) DEFAULT NULL,
  `port_no` varchar(100) DEFAULT NULL,
  `port_no_2` varchar(150) NOT NULL,
  `extra` text NOT NULL,
  `ip_external` varchar(150) NOT NULL,
  `old_ip` varchar(200) NOT NULL,
  `is_updated` enum('0','1') NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
INSERT INTO `rlb_setting` VALUES   ('1','192.168.0.103','13330','13331','a:23:{s:9:\"Pool_Temp\";s:1:\"1\";s:17:\"Pool_Temp_Address\";s:3:\"TS0\";s:8:\"Spa_Temp\";s:1:\"0\";s:16:\"Spa_Temp_Address\";s:0:\"\";s:11:\"PumpsNumber\";s:1:\"3\";s:11:\"ValveNumber\";s:1:\"6\";s:10:\"Remote_Spa\";s:1:\"1\";s:11:\"LightNumber\";s:1:\"1\";s:12:\"HeaterNumber\";s:1:\"2\";s:12:\"BlowerNumber\";s:1:\"1\";s:10:\"MiscNumber\";s:1:\"2\";s:18:\"Remote_Spa_display\";s:1:\"1\";s:12:\"PumpsNumber2\";s:1:\"1\";s:12:\"ValveNumber2\";s:1:\"6\";s:12:\"LightNumber2\";s:1:\"2\";s:13:\"HeaterNumber2\";s:1:\"1\";s:13:\"BlowerNumber2\";s:1:\"4\";s:11:\"MiscNumber2\";s:1:\"1\";s:11:\"Remote_Spa2\";s:1:\"0\";s:19:\"Remote_Spa_display2\";s:1:\"0\";s:8:\"SecondIP\";s:1:\"1\";s:15:\"showTemperature\";s:1:\"1\";s:16:\"showTemperature2\";s:1:\"1\";}','72.193.38.98','72.193.38.98','0');

/*---------------------------------------------------------------
  TABLE: `rlb_site_modules`
  ---------------------------------------------------------------*/
DROP TABLE IF EXISTS `rlb_site_modules`;
CREATE TABLE `rlb_site_modules` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `module_name` varchar(250) NOT NULL,
  `module_active` enum('0','1') NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=latin1;
INSERT INTO `rlb_site_modules` VALUES   ('2','24V AC Relay','1');
INSERT INTO `rlb_site_modules` VALUES ('3','12V DC Power Center Relay','1');
INSERT INTO `rlb_site_modules` VALUES ('4','Modes','1');
INSERT INTO `rlb_site_modules` VALUES ('5','Lights','1');
INSERT INTO `rlb_site_modules` VALUES ('6','Spa Devices','1');
INSERT INTO `rlb_site_modules` VALUES ('7','Pool Devices','1');
INSERT INTO `rlb_site_modules` VALUES ('8','Valve','1');
INSERT INTO `rlb_site_modules` VALUES ('9','Pump','1');
INSERT INTO `rlb_site_modules` VALUES ('10','Temperature Sensors','1');
INSERT INTO `rlb_site_modules` VALUES ('11','Input','1');
INSERT INTO `rlb_site_modules` VALUES ('12','Settings','1');
INSERT INTO `rlb_site_modules` VALUES ('13','Status','1');
INSERT INTO `rlb_site_modules` VALUES ('15','Log','1');
INSERT INTO `rlb_site_modules` VALUES ('16','Light','1');
INSERT INTO `rlb_site_modules` VALUES ('17','Heater','1');
INSERT INTO `rlb_site_modules` VALUES ('18','Pool and Spa','1');
INSERT INTO `rlb_site_modules` VALUES ('19','Blower','1');
INSERT INTO `rlb_site_modules` VALUES ('20','Miscellaneous','1');
INSERT INTO `rlb_site_modules` VALUES ('21','Advance Settings','1');

/*---------------------------------------------------------------
  TABLE: `rlb_valves`
  ---------------------------------------------------------------*/
DROP TABLE IF EXISTS `rlb_valves`;
CREATE TABLE `rlb_valves` (
  `valve_id` int(11) NOT NULL AUTO_INCREMENT,
  `valve_number` int(11) NOT NULL,
  `valve_name` varchar(100) NOT NULL,
  PRIMARY KEY (`valve_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
