#!/bin/sh
if [ `whoami` != "root" ] ; then echo YOU NEED TO BE root TO DO THIS ; exit 1; fi
apt-get update
SYSTEMD=`pgrep systemd | grep "^1$"`
if [ "$SYSTEMD" != "" ]; then
  apt-get -y install sysvinit-core sysvinit-utils
  apt-get remove --purge --auto-remove systemd -y
  echo "Package: systemd\nPin: release *\nPin-Priority: -1" > /etc/apt/preferences.d/systemd
  echo "Package: *systemd*\nPin: release *\nPin-Priority: -1" >> /etc/apt/preferences.d/systemd
  # useless for a headless system without GUI
  apt-get remove --purge --auto-remove dbus -y
  apt-get remove --purge --auto-remove triggerhappy -y
  apt-get remove --purge --auto-remove plymouth -y
  apt-get remove --purge --auto-remove triggerhappy -y
  if [ -r /etc/inittab ]; then
    rm -f /etc/rc2.d/S??lightdm
    rm -f /etc/rc2.d/S??xdm
    rm -f /etc/rc2.d/S??rmnologin
  fi
fi
apt-get install apache2 -y
apt-get install php5 -y
apt-get install avrdude -y
sync
echo ""
echo "You should reboot NOW"
echo ""
exit 0
