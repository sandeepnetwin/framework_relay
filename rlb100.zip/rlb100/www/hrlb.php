<?php
$dbg = 1;
$srv = '/usr/local/bin/l2grlb ';
$nhr = (isset($_GET['nhr']) ? $_GET['nhr'] : 2);

if (($cmd = (isset($_POST['cmd']) ? $_POST['cmd'] : null)) != null) {	// AJAX, data call from client
	if ($dbg) { exec('echo AJAX '.$srv.$cmd.' >> /tmp/log'); passthru($srv.$cmd.' | tee /tmp/tt'); } else
	passthru($srv.$cmd);
	return;
}

function dhdr()
{
	echo '<meta name=viewport content="width=device-width, initial-scale=1.0" />';
	echo '<title>Relay Board history</title>';
}

function seldata()
{
//  S,059,0,5,16:02:00,5,14,........,0000000000000000,00000000,0,0,29,0,0,69.8F,,,,,,0.00,000000,0.00
// 0 1   2 3 4        5 6  7        8                9        0 1 2  3 4 5     678901    2      3    4
	global	$slw; $slw = 100;	// signal label width (px)
	global	$nhb; $nhb = 11;	// number of horizontal bars in analog display

	sadd('S,22.0', 0,'cyan','d','Input 0');
	sadd('S,22.1', 0,'cyan','d','Input 1');
	sadd('S,22.2', 0,'cyan','d','Input 2');
	sadd('S,22.3', 0,'cyan','d','Input 3');
	sadd('S,22.4', 0,'cyan','d','Input 4');
	sadd('S,22.5', 0,'cyan','d','Input 5');
	sadd('S,8.0',  0,'yellow','d','Relay 0');
	sadd('S,8.1',  0,'yellow','d','Relay 1');
	sadd('S,8.2',  0,'yellow','d','Relay 2');
	sadd('S,8.3',  0,'yellow','d','Relay 3');
	sadd('S,8.4',  0,'yellow','d','Relay 4');
	sadd('S,8.5',  0,'yellow','d','Relay 5');
	sadd('S,8.6',  0,'yellow','d','Relay 6');
	sadd('S,8.7',  0,'yellow','d','Relay 7');
	sadd('S,8.8',  0,'yellow','d','Relay 8');
	sadd('S,8.9',  0,'yellow','d','Relay 9');
	sadd('S,8.10', 0,'yellow','d','Relay 10');
	sadd('S,8.11', 0,'yellow','d','Relay 11');
	sadd('S,8.12', 0,'yellow','d','Relay 12');
	sadd('S,8.13', 0,'yellow','d','Relay 13');
	sadd('S,8.14', 0,'yellow','d','Relay 14');
	sadd('S,8.15', 0,'yellow','d','Relay 15');
	sadd('S,7.0',  0,'lime','v','Valve 0');
	sadd('S,7.1',  0,'lime','v','Valve 1');
	sadd('S,7.2',  0,'lime','v','Valve 2');
	sadd('S,7.3',  0,'lime','v','Valve 3');
	sadd('S,7.4',  0,'lime','v','Valve 4');
	sadd('S,7.5',  0,'lime','v','Valve 5');
	sadd('S,7.6',  0,'lime','v','Valve 6');
	sadd('S,7.7',  0,'lime','v','Valve 7');
	sadd('S,9.0',  0,'yellow','d','Power 0');
	sadd('S,9.1',  0,'yellow','d','Power 1');
	sadd('S,9.2',  0,'yellow','d','Power 2');
	sadd('S,9.3',  0,'yellow','d','Power 3');
	sadd('S,9.4',  0,'yellow','d','Power 4');
	sadd('S,9.5',  0,'yellow','d','Power 5');
	sadd('S,9.6',  0,'yellow','d','Power 6');
	sadd('S,9.7',  0,'yellow','d','Power 7');

	sadd('S,15',  100,'magenta','a','T controller');
	sadd('S,16',  100,'khaki','a','T sensor 1');
	sadd('S,17',  100,'khaki','a','T sensor 2');
	sadd('S,18',  100,'khaki','a','T sensor 3');
	sadd('S,19',  100,'khaki','a','T sensor 4');
	sadd('S,20',  100,'khaki','a','T sensor 5');
}

$nac = $ndc = 0;
$lrs = '';
$slw = 80;
$nhb = 11;
$sel = '';
$sca = '';
$col = '';
$ctp = '';
$leg = '';

function sadd($f,$s,$c,$t,$l)
{
	global	$nac, $ndc, $nhb, $lrs;
	global	$sel, $sca, $col, $ctp, $leg;

	$rf = explode(",",$f);
	if ($lrs == '') $sel = ' -s '.($lrs=$rf[0]).',';
	else {
		if ($rf[0] != $lrs) $sel .= ' -s '.($lrs=$rf[0]);
		$sel .= ','; $sca .= ','; $col .= ','; $ctp .= ','; $leg .= ',';
	}
	$sel .= $rf[1];
	$ctp .= '"'.$t.'"';
	$col .= '"'.$c.'"';
	$leg .= '"'.$l.'"';
	if ($t == 'd' || $t == 'v') { $sca .= $s; $ndc++; } else { $sca .= ($s*$nhb/10); $nac++; }
}
function gphp2js()
{
	global	$nac, $ndc, $nhb, $dbg;
	global	$sel, $sca, $col, $ctp, $leg;

   	echo 'var nac='.$nac.';';
   	echo 'var ndc='.$ndc.';';
   	echo 'var nhb='.$nhb.';'; 
   	echo 'var dbg='.$dbg.';'; 
   	echo 'var sel="'.$sel.'";'; 
   	echo 'var sca=['.$sca.'];'; 
   	echo 'var col=['.$col.'];'; 
   	echo 'var ctp=['.$ctp.'];'; 
   	echo 'var leg=['.$leg.'];'; 
}
/*
 * Java Script
 */
function djsc()
{
	echo "<script language=javascript type=text/javascript>";

	seldata();
	gphp2js();

	echo <<<EOJSC
var data=new Array();
var drvv=0;
var dfwv=0;
var iref=0;
var bdtp=0;
var ueor=0;
var nhr=0;
var nsb=0;
var ndr=0;
var rqaf=window.requestAnimationFrame || window.mozRequestAnimmationFrame || window.webkitRequestAnimmationFrame || window.msRequestAnimmationFrame;
var drol=0;
var drsi=0;
var drdq=0;
var rfto=null;
function srvpost(cmd,ans) {
 var r;
 try { r = new XMLHttpRequest(); }
 catch (e) { try { r = new ActiveXObject("MSXML2.XMLHTTP"); }
 catch (e) { try { r = new ActiveXObject("Microsoft.XMLHTTP"); }
 catch (e) { alert("Browser ancient or broken!"); return null; }
 }}
 r.onreadystatechange = function() { if (r.readyState == 4) ans(r.responseText.trim(),r.status); }
 r.open("POST",location.pathname.substr(location.pathname.lastIndexOf('/')+1),true);
 r.setRequestHeader("Content-type","application/x-www-form-urlencoded");
 r.timeout = 60000;
 r.send('cmd='+cmd);
}
var tdx = "";
function mdn(e) {
	tdx = "";
	var c; if ((c = nm2el("cn2")) == null) return;
	var x; if ((x = e.pageX - c.offsetLeft - 8) < 0 || x >= c.width) return;
	tdx = dtptadd(bdtp,(x*nhr*3600)/c.width);
	settext("evb",tdx);
}
function mmv(e) { if (tdx != "") e.preventDefault(); }
function mup(e) { if (tdx != "") dreq(5,tdx); tdx = ""; settext("evb",""); }
function evini(nm) {
 var c; if ((c = nm2el(nm)) == null) return;
 c.addEventListener("mousedown",mdn,false);
 c.addEventListener("touchstart",mdn,false);
 c.addEventListener("mousemove",mmv,false);
 c.addEventListener("touchmove",mmv,true);
 c.addEventListener("touchend",mup,false);
 document.body.addEventListener("mouseup",mup,false);
 document.body.addEventListener("touchcancel",mup,false);
}
function ndbuf(nr,nc) { data = new Array(nr); while (--nr >= 0) data[nr] = new Array(nc); }
function nm2el(nm) { return document.getElementById(nm); }
function settext(nm,txt) { var el = nm2el(nm); if (el != null) el.innerHTML = txt; }
function setclas(nm,cls) { var el = nm2el(nm); if (el != null) el.className = cls; }
function setbrol() { setclas("pref",drol<0?"btg":"btn"); setclas("nref",drol>0?"btg":"btn"); }
function chkd(v) {
	var y, m, d;
	v = parseInt(v);
	if ((y = v) < 100000 || y > 990000) return -1;	/* year 10mmdd ... 99mmdd */
	if ((d = y % 100) < 1 || d > 31) return -1;	/* month day */
	y = (y-d)/100;					/* strip month day */
	if ((m = y % 100) < 1 || m > 12) return -1;	/* month */
	switch (m) {
	case 2: y /= 100; if (d > ((y%4) ? 28 : 29)) return -1; break;
	case 4: case 6: case 9: case 11: if (d > 30) return -1; break;
	}
	return v;
}
function incd(d) {
	var m;
	if ((d = chkd(d)) <= 0) return -1;
	if ((m = chkd(d+1)) > 0) return m;
	d = parseInt(d/100);			/* strip month day */
	m = d % 100; d = parseInt(d/100);	/* extract and strip month, remainder is year */
	if (++m > 12) m = 1, d++;		/* increment month (year) */
	d *= 100; d += m; d *= 100;		/* rebuild date */
	return d + 1;
}
function decd(d)
{
	var y, m;
	if ((d = chkd(d)) <= 0) return -1;
	if ((m = chkd(d-1)) > 0) return m;
	d = parseInt(d/100);			/* strip month day */
	m = d % 100; d = parseInt(d/100);	/* extract and strip month, remainder is year */
	if (--m == 0) m = 12, d--;		/* decrement month (year) */
	y = d;					/* remember year */
	d *= 100; d += m; d *= 100;		/* rebuild date */
	switch (m) {				/* set last day of month */
	case  2: d += (y%4) ? 28 : 29; break;
	case  4: case 6: case 9: case 11: d += 30; break;
	default: d += 31; break;
	}
	return d;
}
function str2tb(str) {
	var t = str.split(":");
	return parseInt(t[0],10)*3600+parseInt(t[1],10)*60+parseInt(t[2]);
}
function tb2str(sec) {
	var h, m, s;
	sec%=86400;
	h = parseInt(sec/3600);
	s = parseInt(sec%3600);
	m = parseInt(s/60);
	s %= 60;
	return (h<10?"0":"")+h+":"+(m<10?"0":"")+m+":"+(s<10?"0":"")+s;
}
function dtptadd(dtp,nsec) {
	var s = dtp.split(","); s[1] = str2tb(s[1]) + nsec;
	while (s[1] <      0) s[0] = decd(s[0]), s[1] += 86400;
	while (s[1] >= 86400) s[0] = incd(s[0]), s[1] -= 86400;
	return s[0]+","+tb2str(s[1]);
}
function dtptdif(a,b) {
	var d = 0;
	a = a.split(","); a[1] = str2tb(a[1]);
	b = b.split(","); b[1] = str2tb(b[1]);
	while (a[0] > b[0]) b[0] = incd(b[0]), d += 86400;
	while (a[0] < b[0]) b[0] = decd(b[0]), d -= 86400;
	d += a[1] - b[1];
	return d;
}
function idx2tb(i) {
	var t = (i-iref)*nsb;
	while (t < 0) t += 86400;
	return (str2tb(bdtp.split(",")[1])+t)%86400;
}
function vgrid(c,s,sx,ox) {
	var x = c.getContext("2d"); x.beginPath(); x.lineWidth = 1; x.strokeStyle = s;
	var i, p; for (p = ox%sx; p < c.width; x.lineTo(i,c.height), p += sx) x.moveTo(i=parseInt(p),0);
	x.stroke();
}
function hgrid(c,s,sy) {
	var x = c.getContext("2d"); x.beginPath(); x.lineWidth = 1; x.strokeStyle = s;
	var p; for (p = c.height; (p -= sy) > 0; x.lineTo(c.width,p)) x.moveTo(0,p);
	x.stroke();
}
function pgrid(c1,c2,c3,c4,di) {
	var x1, r, i, k, ho, bt, db, tb, tw, hi, nv, ox, sx;
	x1 = c1.getContext("2d");
	x1.font = "14px Arial";
	x1.fillStyle = "white";
	x1.textAlign = "center";
	tw = parseInt(x1.measureText("_00:00_").width);
	tb = c2.offsetTop + c2.height + 20 - 5;
	if (nhr <= 0 || ndr <= 0 || nsb <= 0) return -1;
	if ((hi = 3600/nsb) < 1 || (nhr*hi) != ndr) return -1;
	bt = idx2tb(di);
	if ((db=1) && (ho=(86400-bt)/nsb)>=ndr) db=0, ho=(3600-(bt%3600))/nsb;	// full day|hour record index
	for (r=[1,2,3,4,6,8,12,24],i=0;i<r.length;i++) if ((((k=r[i]*hi)*c2.width)/ndr)>=tw) break;
	if ((nv = nhr) <= 12) nv *= 2;
	if (k == hi) { for (r=[1,2,4,6],i=r.length;--i>0&&((k*c2.width)/(r[i]*ndr))<tw;); k/=r[i],nv*=r[i]; }
	ox = c2.offsetLeft;
	sx = c2.width/ndr;
	for (i = ho; i < ndr; i += k) x1.fillText(tb2str(bt+i*nsb).substr(0,5),ox+parseInt(i*sx),tb);
	for (i = ho; (i -= k) >= 0;)  x1.fillText(tb2str(bt+i*nsb).substr(0,5),ox+parseInt(i*sx),tb);
	vgrid(c2,"#404060",c2.width/nv,c2.width*ho/ndr);
	if (db) vgrid(c2,"#ffffff",(24*c2.width)/nhr,c2.width*ho/ndr);
	hgrid(c2,"#404060",1*c2.height/nhb);
	hgrid(c2,"#6060a0",5*c2.height/nhb);
	if (ndc) {
		vgrid(c3,"#404060",c3.width/nv,c3.width*ho/ndr);
		if (db) vgrid(c3,"#ffffff",(24*c3.width)/nhr,c3.width*ho/ndr);
		hgrid(c3,"#404060",c3.height/ndc);
	}
	bt = dtptadd(bdtp,ndr*nsb);
	i = "20"+bt.substr(0,2)+"/"+bt.substr(2,2)+"/"+bt.substr(4,2)+" "+bt.substr(7,8);
	if (ueor==1&&dfwv==ndr) i+=" >|";
	x1.textAlign = "right";
	x1.fillText(i,c2.offsetLeft+c2.width+2,c3.offsetTop+c3.height+20-5);
	if (nhr >= 24 && (nhr%24) == 0) i = (nhr/24)+"D"; else i = nhr+"H"; i += " @ ";
	if (nsb >= 60 && (nsb%60) == 0) i += (nsb/60)+"M"; else i += nsb+"S";
	x1.font = "12px Arial"; x1.textAlign = "right";
	x1.fillText(i,c4.offsetLeft+c4.width,c3.offsetTop+c3.height+20-5);
	return 0;
}
function pdata(c,w,sg,di,sy,oy)
{
	var x = c.getContext("2d");
	var k, n, m = data.length;
	var sx = c.width/ndr;
	oy += c.height;
	x.beginPath(); x.lineWidth = w; x.strokeStyle = col[sg];
	n = c.width - 1;
	x.moveTo(0,data[di%=m][sg]*sy+oy);
	for (k = 0; (k += sx) < c.width; x.lineTo(k,data[di%=m][sg]*sy+oy)) di++;
	x.stroke();
}
function adata(c,sg,di) { pdata(c,2,sg,di,-c.height/sca[sg],0); }
function ddata(c,ci,sg,di) {
	var sy, oy;
	sy = -c.height/ndc; oy = ci * sy; sy *= 0.7;
	if (ctp[sg] == "v") { if (0) oy -= sy; else sy *= 0.5; }
	pdata(c,2,sg,di,sy,oy);
}
function dlbls(ca,cd) {
	var i, ia, id;
	var xa = ca.getContext("2d"); xa.font = "12px Arial"; xa.textAlign = "left";
	var xd = cd.getContext("2d"); xd.font = "12px Arial"; xd.textAlign = "left";
	for (ia = id = i = 0; i < leg.length; i++)
		if (ctp[i] == "a")
			xa.fillStyle = col[i], xa.fillText(leg[i],4,ca.height-(((ia++)*ca.height)/nhb)-5);
		else	xd.fillStyle = col[i], xd.fillText(leg[i],4,cd.height-(((id++)*cd.height)/ndc)-4);
}
function dcpy(sb,nb,di) {
	var n, i, k, r;
	for (n = 0; n < nb; n++) {
		r = sb[n].substr(0,sb[n].indexOf("]")).split(",");
		i = (di + n) % data.length;
		for (k = 0; k < r.length; k++) data[i][k] = r[k];
	}
}
function drcv(msg,stat)
{
	var n, i, d, s, bsiz, ndat, nbdt, nueo, dnhr, dnsb, dndr;
	d = msg.split("=");
	if (d.length != 6) return;
	s = d[1].split(";"); ndat = s[0].split("["); ndat.shift(); ndat.shift();
	s = d[2].split(";"); nbdt = s[0].replace(/[ "]/g,"");
	s = d[3].split(";"); nueo = s[0].replace(/[ "]/g,"");
	s = d[4].split(";"); dnhr = s[0].replace(/[ "]/g,"");
	s = d[5].split(";"); dnsb = s[0].replace(/[ "]/g,"");
	dndr = ndat.length;
	if (dbg==1) console.log("DRCV dndr="+dndr+" dnsb="+dnsb+" dnhr="+dnhr+" data.length="+data.length+" bdt="+nbdt+" ueo="+nueo);
	drdq = 0;
	ueor = nueo;
	bsiz = dndr * 3;
	if (data.length == bsiz && dnsb == nsb && dnhr == nhr) {
		if (nbdt == dtptadd(bdtp,-(drvv+ndr)*nsb)) {
			if ((i = iref - drvv - ndr) < 0) i += bsiz;
			dcpy(ndat,ndr,i);
			if ((n = dfwv+drvv+ndr-bsiz) > 0) dfwv -= n;
			drvv += ndr;
			if (dbg==1) console.log("left splice at i="+i+" drvv="+drvv+" dfwv="+dfwv+" sum="+(dfwv+drvv));
			return;
		}
		if (nbdt == dtptadd(bdtp,dfwv*nsb)) {
			if ((i = iref + dfwv) >= bsiz) i -= bsiz;
			dcpy(ndat,ndr,i);
			if ((n = dfwv+ndr+drvv-bsiz) > 0) drvv -= n;
			dfwv += ndr;
			if (dbg==1) console.log("right splice at i="+i+" drvv="+drvv+" dfwv="+dfwv+" sum="+(dfwv+drvv));
			return;
		}
		if (nueo==1 && (n = dtptdif(nbdt,bdtp)) >= nsb && (n%nsb) == 0 && (n/=nsb) <= dfwv) {
			if ((i = iref + n) >= bsiz) i -= bsiz;
			dcpy(ndat,ndr,i);
			if ((d = n+ndr+drvv-bsiz) > 0) drvv -= d;
			dfwv = n + ndr;
			if (drol == 0) drol = 1, droller();
			if (dbg==1) console.log("overlay right splice i="+i+" n="+n+" drvv="+drvv+" dfwv="+dfwv+" sum="+(dfwv+drvv));
			return;
		}
	}
	if (dbg==1) console.log("DBUF rebuild");
	nhr = dnhr;
	nsb = dnsb;
	ndr = dndr;
	setclas("resi","btn");
	setclas("resd","btn");
	ndbuf(bsiz,ctp.length);
	bdtp = nbdt;
	iref = dfwv = ndr;
	drvv = drol = 0;
	dcpy(ndat,ndr,iref);
	droller();
}
function nhr2nsb(nh) {
	var r, i, m; for (m=(3600*nh)/720,r=[3600,1800,900,600,300,120,60,30,10,5,2],i=r.length;--i>0&&m>r[i];);
	return r[i];
}
function dreq(rq,arg) {
	var req = "";
	switch (rq) {
	case 0:	/* ini */ req = "-h"+arg+" -r"+nhr2nsb(arg); break;
	case 1:	/* upd */ req = "-h"+nhr+" -r"+nsb; break;
	case 2:	/* lft */ drdq = -(drvv*nsb+nhr*3600); req = dtptadd(bdtp,drdq)+" -h"+nhr+" -r"+nsb; break;
	case 3:	/* rgt */ drdq =  (dfwv*nsb); req = dtptadd(bdtp,drdq)+" -h"+nhr+" -r"+nsb; break;
	case 4:	/* nhr change */
		if (ueor==1) drdq = nhr*3600; else drdq = (nhr-arg)*1800;
		req = dtptadd(bdtp,drdq)+" -h"+arg+" -r"+nhr2nsb(arg);
		break;
	case 5:	/* center time reference */
		drdq = -(nhr*3600/2); req = dtptadd(arg,drdq)+" -h"+nhr+" -r"+nsb;
		break;
	default: return; break;
	}
	if (dbg==1) console.log("DREQ "+req);
	srvpost(req+sel,drcv);
}
function drct(act)
{
	if (act == 0) {
		var rol = 0;
		if (drol != 0 && (drsi += 1) >= 200) {
			drsi = 0;
			if (drol < 0 && drol > -2) drol--;
			if (drol > 0 && drol < +2) drol++;
		}
		if (drol < 0) {
			if (drvv < (ndr*0.75) && drdq == 0) dreq(2);
			if ((rol = -drvv) < drol) rol = drol;
		}
		else if (drol > 0) {
			if (dfwv < (ndr*1.75) && drdq == 0 && ueor == 0) dreq(3);
			if ((rol = dfwv - ndr) > drol) rol = drol;
			if (rol == 0 && ueor == 1) drol = 0;
		}
		if (rol) {
			if ((iref += rol) < 0) iref += data.length; else if (iref >= data.length) iref -= data.length;
			drvv += rol; dfwv -= rol;
			bdtp = dtptadd(bdtp,rol*nsb);
		}
		return 1;
	}
	if (act < 0) {
		if (drol < 0) drol = 0;
		else { drsi = 0; drol = -1; setbrol(); ueor = 0; droller(); }
	}
	else if (act > 0) {
		if (drol > 0 || (ueor == 1 && dfwv <= ndr)) drol = 0;
		else { drsi = 0; drol = +1; setbrol(); droller(); }
	}
	return 0;
}
function droller() {
	if (rfto!=null) clearTimeout(rfto), rfto = null;
	if (drct(0)==1) {
		var ci, sg;
		var c1 = nm2el("cn1"); c1.getContext("2d").clearRect(0,0,c1.width,c1.height);
		var c2 = nm2el("cn2"); c2.getContext("2d").clearRect(0,0,c2.width,c2.height);
		var c3 = nm2el("cn3"); c3.getContext("2d").clearRect(0,0,c3.width,c3.height);
		if (pgrid(c1,c2,c3,nm2el("cn4"),iref) == 0)
			for (ci = sg = 0; sg < data[0].length; sg++)
				if (ctp[sg] == "a") adata(c2,sg,iref); else ddata(c3,ci++,sg,iref);
	}
	if (drol) rqaf(droller);
	else {
		setbrol();
		if (ueor==1 && dfwv==ndr) rfto=setTimeout(eref,nsb*1000);
	}
}
var reso = [1,2,4,8,12,1*24,2*24,3*24];
function rchg(nm,d) {
	if (d>0) for (d = 0; d < reso.length && reso[d] <= nhr; d++); else
	if (d<0) for (d = reso.length; --d >= 0 && reso[d] >= nhr; ); else return;
	if (drol == 0 && d >= 0 && d < reso.length && reso[d] != nhr) setclas(nm,"btw"), dreq(4,reso[d]);
}
function eref() { if (ueor==1 && dfwv== ndr && drol==0) dreq(1); }
function uref() { location.replace(location.pathname.substr(location.pathname.lastIndexOf("/")+2)); }
EOJSC;

	echo '</script>';
}

function dhtm()
{
	global	$nhr, $ndc, $slw;

	$wl = 25;
	$h2 = 250; 
	$w2 = 720;
	$w4 = $slw;
	$w1 = $wl + $w2 + $w4 + 4;
	$h3 = $ndc * 20; 
	$h1 = 20 + $h2 + 20 + $h3 + 20;
	$t2 = 20;
	$t3 = $t2 + $h2 + 20;
	echo '<div class=c0>';
		echo '<canvas class=c1 id=cn1 width='.$w1.' height='.$h1.' >CANVAS not supported</canvas>';
		echo '<canvas class=c2 id=cn2 width='.$w2.' height='.$h2.' style="left:'.$wl.'px; top:',$t2.'px"></canvas>';
		echo '<canvas class=c2 id=cn3 width='.$w2.' height='.$h3.' style="left:'.$wl.'px; top:'.$t3.'px"></canvas>';
		echo '<canvas class=c3 id=cn4 width='.$w4.' height='.$h2.' style="left:'.($wl+$w2+2).'px; top:'.$t2.'px"></canvas>';
		echo '<canvas class=c3 id=cn5 width='.$w4.' height='.$h3.' style="left:'.($wl+$w2+2).'px; top:'.$t3.'px"></canvas>';
	echo '</div>';
	$bb = 4 + 4; // button boundary, border and margin
	$bw = $w1/5 - 2*$bb;
	$cs = ' class=btn style="width:'.$bw.'px;"';
	echo '<div style="position:absolute; left:'.$bb.'px; top:'.($h1+10).'px; width:'.$w1.'px;">';
		echo '<div'.$cs.' id=resi onclick=rchg("resi",-1)>Zoom +</div>';
		echo '<div'.$cs.' id=resd onclick=rchg("resd",+1)>Zoom -</div>';
		echo '<div'.$cs.' id=pref onclick=drct(-1)><<</div>';
		echo '<div'.$cs.' id=nref onclick=drct(+1)>>></div>';
		echo '<div'.$cs.' onclick=uref()>Controller</div>';
	echo '</div>';
	echo '<script>dlbls(nm2el("cn4"),nm2el("cn5"));</script>';
echo '<div class=btn id=evb style="width:30%;">evb</div>';
echo '<script>evini("cn1");</script>';
echo '<script>evini("cn2");</script>';
echo '<script>evini("cn3");</script>';
	echo '<script>dreq(0,'.$nhr.');</script>'; // initial fill buffer
}

/*
 * CSS
 */
function dcss()
{
	echo "<style>";

	echo <<<EOCSS
body { background-color: #000; color: #fff; }
.c0 { position: relative; }
.c1 { position: absolute; border: 1px solid #000000; z-index: 0; }
.c2 { position: absolute; border: 1px solid #404060; z-index: 1; }
.c3 { position: absolute; border: 1px solid #000000; z-index: 1; background-color: #283966; }
.btg, .btw, .btn {
 width: 100px;
 border: 4px solid #4e6096; border-radius: 10px;
 margin: 2px 4px;
 box-shadow: 0px 0px 0px 2px #9fb4f2;
 font-size: 16px; font-weight: bold;
 text-shadow: 2px 2px 0px #283966; text-align: center;
 padding: 0.5em 0;
 cursor: pointer;
 background: #7892c2;
 float: left;
}
.btg { background: #008000; }
.btw { background: #808080; }
EOCSS;
	echo "</style>";
}

?>
<!DOCTYPE html>
<html>
<head>
<?php dhdr(); ?>
<?php dcss(); ?>
</head>
<body>
<?php djsc(); ?>
<?php dhtm(); ?>
</body>
</html>

